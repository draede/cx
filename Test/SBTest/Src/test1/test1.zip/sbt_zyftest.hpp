
#pragma once


#include "sbt_zyF.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_JTest.hpp"
#include "sbt_qTest.hpp"
#include "sbt_Ov5Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_zyF &p)
{
	p.sbt_35ebXzB = 598661762;
	p.sbt_4DF8K[0.589740] = 56;
	p.sbt_4DF8K[0.777933] = 81;
	p.sbt_4DF8K[0.435478] = 241;
	p.sbt_5FUceD1 = false;
	p.sbt_C = 153;
	TestInit(p.sbt_PUenjMM9a);
	p.sbt_YHNdz.push_back(-28271);
	TestInit(p.sbt__hC);
	p.sbt_ioF["mO)-!uKw'}YsU]y[KA)"] = 37;
	p.sbt_ioF["wA%IIu5K!gq+kG/U9?{#Y9Y#I?k"] = 108;
	p.sbt_ioF["%G%Ow-3kwwE"] = -68;
	p.sbt_ioF["E}kg#'"] = -68;
	p.sbt_ioF["3a!MUcYUIE!u-%%O++#;SW_"] = -60;
	TestInit(p.sbt_y4q);
}

static inline void RandInit(sbt_zyF &p)
{
	p.sbt_35ebXzB = CX::Util::RndGen::Get().GetInt32();
	p.sbt_4DF8K[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_4DF8K[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_4DF8K[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_5FUceD1 = CX::Util::RndGen::Get().GetBool();
	p.sbt_C = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_PUenjMM9a);
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_YHNdz.push_back(CX::Util::RndGen::Get().GetInt16());
	RandInit(p.sbt__hC);
	p.sbt_ioF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_ioF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_ioF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_y4q);
}

}//namespace SB

}//namespace CX

