
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_J.hpp"


class sbt_Ov5
{
public:

	CX::SB::Vector<CX::Int32>::Type sbt_I1vasjR;
	CX::SB::Map<sbt_J, sbt_J>::Type sbt_bmhta;
	CX::UInt32 sbt_k;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Ov5 &p)
{
	DefInit(p.sbt_I1vasjR);
	DefInit(p.sbt_bmhta);
	DefInit(p.sbt_k);
}

template <> static inline int Compare<sbt_Ov5>(const sbt_Ov5 &a, const sbt_Ov5 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_I1vasjR, b.sbt_I1vasjR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bmhta, b.sbt_bmhta)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_k, b.sbt_k)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Ov5>(const sbt_Ov5 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_I1vasjR, pHasher);
	Hash(p.sbt_bmhta, pHasher);
	Hash(p.sbt_k, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Ov5>(sbt_Ov5 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_I1vasjR", p.sbt_I1vasjR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bmhta", p.sbt_bmhta)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Ov5>(sbt_Ov5 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_I1vasjR", p.sbt_I1vasjR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bmhta", p.sbt_bmhta)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

