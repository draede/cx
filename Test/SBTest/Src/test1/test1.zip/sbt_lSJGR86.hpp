
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_J.hpp"
#include "sbt_q.hpp"


class sbt_lSJGR86
{
public:

	CX::SB::Map<sbt_J, sbt_J>::Type sbt_5iejVMx;
	sbt_q sbt_Db5w4at;
	CX::SB::Vector<CX::UInt32>::Type sbt_Fk1;
	CX::Int8 sbt_bM2TbDO;
	CX::Int32 sbt_d_8;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_lSJGR86 &p)
{
	DefInit(p.sbt_5iejVMx);
	DefInit(p.sbt_Db5w4at);
	DefInit(p.sbt_Fk1);
	DefInit(p.sbt_bM2TbDO);
	DefInit(p.sbt_d_8);
}

template <> static inline int Compare<sbt_lSJGR86>(const sbt_lSJGR86 &a, const sbt_lSJGR86 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5iejVMx, b.sbt_5iejVMx)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Db5w4at, b.sbt_Db5w4at)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Fk1, b.sbt_Fk1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bM2TbDO, b.sbt_bM2TbDO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_d_8, b.sbt_d_8)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_lSJGR86>(const sbt_lSJGR86 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5iejVMx, pHasher);
	Hash(p.sbt_Db5w4at, pHasher);
	Hash(p.sbt_Fk1, pHasher);
	Hash(p.sbt_bM2TbDO, pHasher);
	Hash(p.sbt_d_8, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_lSJGR86>(sbt_lSJGR86 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5iejVMx", p.sbt_5iejVMx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Db5w4at", p.sbt_Db5w4at)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Fk1", p.sbt_Fk1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bM2TbDO", p.sbt_bM2TbDO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_d_8", p.sbt_d_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_lSJGR86>(sbt_lSJGR86 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5iejVMx", p.sbt_5iejVMx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Db5w4at", p.sbt_Db5w4at)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Fk1", p.sbt_Fk1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bM2TbDO", p.sbt_bM2TbDO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_d_8", p.sbt_d_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

