
#pragma once


#include "sbt_J.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_qTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_J &p)
{
	TestInit(p.sbt_5_7gA);
	p.sbt_P.push_back(true);
	p.sbt_m = -1586923359;
}

static inline void RandInit(sbt_J &p)
{
	RandInit(p.sbt_5_7gA);
	p.sbt_P.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_P.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_P.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_m = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

