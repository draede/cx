
#pragma once


#include "CX/SB/Tester.hpp"
#include "CX/Print.hpp"
#include "sbt_JTest.hpp"
#include "sbt_lSJGR86Test.hpp"
#include "sbt_Ov5Test.hpp"
#include "sbt_qTest.hpp"
#include "sbt_zyFTest.hpp"


void Run_Tests()
{
	CX::SB::StatsData trd;
	CX::SB::StatsData twd;
	CX::Size cAll = 0;
	CX::Size cOK = 0;
	CX::Status status;

	trd.Reset();
	twd.Reset();
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_J>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_J failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_lSJGR86>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_lSJGR86 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Ov5>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Ov5 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_q>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_q failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_zyF>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_zyF failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	CX::Print(stdout, "All tests : {1}\n", cAll);
	CX::Print(stdout, "OK tests  : {1}\n", cOK);
	CX::Print(stdout, "===== READ STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", trd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", trd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", trd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", trd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", trd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", trd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", trd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", trd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", trd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", trd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", trd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", trd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", trd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", trd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", trd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", trd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", trd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", trd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", trd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {:.3} MB\n", trd.m_cbTotalSize / 1048576.0);
	CX::Print(stdout, "===== WRITE STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", twd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", twd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", twd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", twd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", twd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", twd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", twd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", twd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", twd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", twd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", twd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", twd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", twd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", twd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", twd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", twd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", twd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", twd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", twd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {1:.3} MB\n", twd.m_cbTotalSize / 1048576.0);
}
