
#pragma once


#include "sbt_Ov5.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_JTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Ov5 &p)
{
	p.sbt_I1vasjR.push_back(-1749064574);
	p.sbt_I1vasjR.push_back(1737925232);
	p.sbt_I1vasjR.push_back(1788350143);
	p.sbt_I1vasjR.push_back(1045070899);
	p.sbt_I1vasjR.push_back(-2029418863);
	p.sbt_I1vasjR.push_back(1064234365);
	p.sbt_I1vasjR.push_back(501296606);
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	p.sbt_k = 3614656446;
}

static inline void RandInit(sbt_Ov5 &p)
{
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_I1vasjR.push_back(CX::Util::RndGen::Get().GetInt32());
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_bmhta[k] = v;
	}
	p.sbt_k = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

