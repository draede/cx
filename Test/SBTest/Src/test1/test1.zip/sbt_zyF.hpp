
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_J.hpp"
#include "sbt_q.hpp"
#include "sbt_Ov5.hpp"


class sbt_zyF
{
public:

	CX::Int32 sbt_35ebXzB;
	CX::SB::Map<CX::Double, CX::UInt8>::Type sbt_4DF8K;
	CX::Bool sbt_5FUceD1;
	CX::UInt8 sbt_C;
	sbt_J sbt_PUenjMM9a;
	CX::SB::Vector<CX::Int16>::Type sbt_YHNdz;
	sbt_q sbt__hC;
	CX::SB::Map<CX::String, CX::Int8>::Type sbt_ioF;
	sbt_Ov5 sbt_y4q;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_zyF &p)
{
	DefInit(p.sbt_35ebXzB);
	DefInit(p.sbt_4DF8K);
	DefInit(p.sbt_5FUceD1);
	DefInit(p.sbt_C);
	DefInit(p.sbt_PUenjMM9a);
	DefInit(p.sbt_YHNdz);
	DefInit(p.sbt__hC);
	DefInit(p.sbt_ioF);
	DefInit(p.sbt_y4q);
}

template <> static inline int Compare<sbt_zyF>(const sbt_zyF &a, const sbt_zyF &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_35ebXzB, b.sbt_35ebXzB)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_4DF8K, b.sbt_4DF8K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5FUceD1, b.sbt_5FUceD1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_C, b.sbt_C)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PUenjMM9a, b.sbt_PUenjMM9a)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YHNdz, b.sbt_YHNdz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__hC, b.sbt__hC)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ioF, b.sbt_ioF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y4q, b.sbt_y4q)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_zyF>(const sbt_zyF &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_35ebXzB, pHasher);
	Hash(p.sbt_4DF8K, pHasher);
	Hash(p.sbt_5FUceD1, pHasher);
	Hash(p.sbt_C, pHasher);
	Hash(p.sbt_PUenjMM9a, pHasher);
	Hash(p.sbt_YHNdz, pHasher);
	Hash(p.sbt__hC, pHasher);
	Hash(p.sbt_ioF, pHasher);
	Hash(p.sbt_y4q, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_zyF>(sbt_zyF p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_35ebXzB", p.sbt_35ebXzB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4DF8K", p.sbt_4DF8K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5FUceD1", p.sbt_5FUceD1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_C", p.sbt_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PUenjMM9a", p.sbt_PUenjMM9a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YHNdz", p.sbt_YHNdz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__hC", p.sbt__hC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ioF", p.sbt_ioF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y4q", p.sbt_y4q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_zyF>(sbt_zyF &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_35ebXzB", p.sbt_35ebXzB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_4DF8K", p.sbt_4DF8K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5FUceD1", p.sbt_5FUceD1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_C", p.sbt_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PUenjMM9a", p.sbt_PUenjMM9a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YHNdz", p.sbt_YHNdz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__hC", p.sbt__hC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ioF", p.sbt_ioF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y4q", p.sbt_y4q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

