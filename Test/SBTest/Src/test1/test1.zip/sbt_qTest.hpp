
#pragma once


#include "sbt_q.hpp"
#include "CX/Util/RndGen.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_q &p)
{
	p.sbt_DJyhv[-70718526] = 0.178531;
	p.sbt_DJyhv[-838626953] = 0.467628;
	p.sbt_DJyhv[1134161721] = 0.783577;
	p.sbt_DJyhv[-372687899] = 0.407815;
	p.sbt_DJyhv[-543619416] = 0.447445;
	p.sbt_DJyhv[-675744708] = 0.080301;
	p.sbt_DJyhv[-1425637115] = 0.539290;
}

static inline void RandInit(sbt_q &p)
{
	p.sbt_DJyhv[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

