
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_q.hpp"


class sbt_J
{
public:

	sbt_q sbt_5_7gA;
	CX::SB::Vector<CX::Bool>::Type sbt_P;
	CX::Int32 sbt_m;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_J &p)
{
	DefInit(p.sbt_5_7gA);
	DefInit(p.sbt_P);
	DefInit(p.sbt_m);
}

template <> static inline int Compare<sbt_J>(const sbt_J &a, const sbt_J &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5_7gA, b.sbt_5_7gA)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_P, b.sbt_P)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m, b.sbt_m)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_J>(const sbt_J &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5_7gA, pHasher);
	Hash(p.sbt_P, pHasher);
	Hash(p.sbt_m, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_J>(sbt_J p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5_7gA", p.sbt_5_7gA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_P", p.sbt_P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_J>(sbt_J &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5_7gA", p.sbt_5_7gA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_P", p.sbt_P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

