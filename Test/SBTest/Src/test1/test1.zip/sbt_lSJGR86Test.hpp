
#pragma once


#include "sbt_lSJGR86.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_JTest.hpp"
#include "sbt_qTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_lSJGR86 &p)
{
	{
		sbt_J k;
		sbt_J v;

		TestInit(k);
		TestInit(v);
		p.sbt_5iejVMx[k] = v;
	}
	TestInit(p.sbt_Db5w4at);
	p.sbt_Fk1.push_back(2261126391);
	p.sbt_Fk1.push_back(3299044974);
	p.sbt_Fk1.push_back(201676317);
	p.sbt_bM2TbDO = -31;
	p.sbt_d_8 = 1908932092;
}

static inline void RandInit(sbt_lSJGR86 &p)
{
	{
		sbt_J k;
		sbt_J v;

		RandInit(k);
		TestInit(v);
		p.sbt_5iejVMx[k] = v;
	}
	RandInit(p.sbt_Db5w4at);
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_Fk1.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_bM2TbDO = CX::Util::RndGen::Get().GetInt8();
	p.sbt_d_8 = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

