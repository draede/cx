
#pragma once


#include "sbt_YRlXF96.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_v8_4oQnksTest.hpp"
#include "sbt_ziHWqp4Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_YRlXF96 &p)
{
	p.sbt_6ea.push_back(0.889219f);
	p.sbt_6ea.push_back(0.977296f);
	p.sbt_6ea.push_back(0.524714f);
	p.sbt_6ea.push_back(0.241773f);
	p.sbt_6ea.push_back(0.400494f);
	p.sbt_6ea.push_back(0.338980f);
	p.sbt_6ea.push_back(0.988834f);
	p.sbt_6kJqu = 38269;
	TestInit(p.sbt_KCrTy7MRZ);
	p.sbt_UCv = 0;
	p.sbt_XuV[true] = 9057073165071865968;
	p.sbt_XuV[true] = -5550345573398654346;
	p.sbt_XuV[true] = -8606400985426538546;
	p.sbt_XuV[true] = -5825623919472402330;
	p.sbt_XuV[true] = 1899872572481398480;
	p.sbt_Yypncm9 = L"yQYCyO[So9Es[+[/eQ!%q9#)}Ea";
	TestInit(p.sbt__);
	p.sbt_rtLSxiJ = 0.312464;
	TestInit(p.sbt_z);
}

static inline void RandInit(sbt_YRlXF96 &p)
{
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6ea.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_6kJqu = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_KCrTy7MRZ);
	p.sbt_UCv = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_XuV[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_Yypncm9 = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt__);
	p.sbt_rtLSxiJ = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_z);
}

}//namespace SB

}//namespace CX

