
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_XpRGlsG8F1Eg9.hpp"
#include "sbt_cdxtwwTUWUe2l.hpp"
#include "sbt_8ft4kg2bXtvQtsj.hpp"


class sbt_1pplnhNbya7or
{
public:

	sbt_XpRGlsG8F1Eg9 sbt_66W;
	CX::UInt64 sbt_EYGV54ARO;
	CX::UInt32 sbt_Sr9zbieZJ;
	CX::SB::Map<CX::Int16, CX::String>::Type sbt_YanwO1s;
	CX::SB::Vector<sbt_cdxtwwTUWUe2l>::Type sbt_ZkJ;
	CX::Int64 sbt_fMxtxQ2tY;
	sbt_8ft4kg2bXtvQtsj sbt_uLYGqat;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_1pplnhNbya7or &p)
{
	DefInit(p.sbt_66W);
	DefInit(p.sbt_EYGV54ARO);
	DefInit(p.sbt_Sr9zbieZJ);
	DefInit(p.sbt_YanwO1s);
	DefInit(p.sbt_ZkJ);
	DefInit(p.sbt_fMxtxQ2tY);
	DefInit(p.sbt_uLYGqat);
}

template <> static inline int Compare<sbt_1pplnhNbya7or>(const sbt_1pplnhNbya7or &a, const sbt_1pplnhNbya7or &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_66W, b.sbt_66W)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EYGV54ARO, b.sbt_EYGV54ARO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sr9zbieZJ, b.sbt_Sr9zbieZJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YanwO1s, b.sbt_YanwO1s)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ZkJ, b.sbt_ZkJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fMxtxQ2tY, b.sbt_fMxtxQ2tY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_uLYGqat, b.sbt_uLYGqat)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_1pplnhNbya7or>(const sbt_1pplnhNbya7or &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_66W, pHasher);
	Hash(p.sbt_EYGV54ARO, pHasher);
	Hash(p.sbt_Sr9zbieZJ, pHasher);
	Hash(p.sbt_YanwO1s, pHasher);
	Hash(p.sbt_ZkJ, pHasher);
	Hash(p.sbt_fMxtxQ2tY, pHasher);
	Hash(p.sbt_uLYGqat, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_1pplnhNbya7or>(sbt_1pplnhNbya7or p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_66W", p.sbt_66W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EYGV54ARO", p.sbt_EYGV54ARO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sr9zbieZJ", p.sbt_Sr9zbieZJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YanwO1s", p.sbt_YanwO1s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ZkJ", p.sbt_ZkJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fMxtxQ2tY", p.sbt_fMxtxQ2tY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_uLYGqat", p.sbt_uLYGqat)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_1pplnhNbya7or>(sbt_1pplnhNbya7or &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_66W", p.sbt_66W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EYGV54ARO", p.sbt_EYGV54ARO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sr9zbieZJ", p.sbt_Sr9zbieZJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YanwO1s", p.sbt_YanwO1s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ZkJ", p.sbt_ZkJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fMxtxQ2tY", p.sbt_fMxtxQ2tY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_uLYGqat", p.sbt_uLYGqat)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

