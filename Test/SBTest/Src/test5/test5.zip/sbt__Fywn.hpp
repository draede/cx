
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_9z87obF.hpp"
#include "sbt_v8_4oQnks.hpp"
#include "sbt_dkU.hpp"


class sbt__Fywn
{
public:

	CX::Int8 sbt_3b7;
	CX::WString sbt_V;
	CX::UInt32 sbt_XxGKDpnPw;
	CX::Bool sbt_ZEinI;
	sbt_9z87obF sbt_bMHAWScei;
	CX::WString sbt_r7U20DNVY;
	CX::SB::Map<CX::Bool, CX::UInt8>::Type sbt_uHee58Qa9;
	CX::SB::Vector<sbt_v8_4oQnks>::Type sbt_ycxjO6UxF;
	sbt_dkU sbt_yea;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt__Fywn &p)
{
	DefInit(p.sbt_3b7);
	DefInit(p.sbt_V);
	DefInit(p.sbt_XxGKDpnPw);
	DefInit(p.sbt_ZEinI);
	DefInit(p.sbt_bMHAWScei);
	DefInit(p.sbt_r7U20DNVY);
	DefInit(p.sbt_uHee58Qa9);
	DefInit(p.sbt_ycxjO6UxF);
	DefInit(p.sbt_yea);
}

template <> static inline int Compare<sbt__Fywn>(const sbt__Fywn &a, const sbt__Fywn &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3b7, b.sbt_3b7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_V, b.sbt_V)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XxGKDpnPw, b.sbt_XxGKDpnPw)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ZEinI, b.sbt_ZEinI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bMHAWScei, b.sbt_bMHAWScei)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_r7U20DNVY, b.sbt_r7U20DNVY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_uHee58Qa9, b.sbt_uHee58Qa9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ycxjO6UxF, b.sbt_ycxjO6UxF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yea, b.sbt_yea)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt__Fywn>(const sbt__Fywn &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3b7, pHasher);
	Hash(p.sbt_V, pHasher);
	Hash(p.sbt_XxGKDpnPw, pHasher);
	Hash(p.sbt_ZEinI, pHasher);
	Hash(p.sbt_bMHAWScei, pHasher);
	Hash(p.sbt_r7U20DNVY, pHasher);
	Hash(p.sbt_uHee58Qa9, pHasher);
	Hash(p.sbt_ycxjO6UxF, pHasher);
	Hash(p.sbt_yea, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt__Fywn>(sbt__Fywn p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3b7", p.sbt_3b7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_V", p.sbt_V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XxGKDpnPw", p.sbt_XxGKDpnPw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ZEinI", p.sbt_ZEinI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bMHAWScei", p.sbt_bMHAWScei)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_r7U20DNVY", p.sbt_r7U20DNVY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_uHee58Qa9", p.sbt_uHee58Qa9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ycxjO6UxF", p.sbt_ycxjO6UxF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yea", p.sbt_yea)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt__Fywn>(sbt__Fywn &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3b7", p.sbt_3b7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_V", p.sbt_V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XxGKDpnPw", p.sbt_XxGKDpnPw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ZEinI", p.sbt_ZEinI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bMHAWScei", p.sbt_bMHAWScei)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_r7U20DNVY", p.sbt_r7U20DNVY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_uHee58Qa9", p.sbt_uHee58Qa9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ycxjO6UxF", p.sbt_ycxjO6UxF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yea", p.sbt_yea)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

