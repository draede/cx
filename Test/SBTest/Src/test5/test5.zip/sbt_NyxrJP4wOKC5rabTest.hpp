
#pragma once


#include "sbt_NyxrJP4wOKC5rab.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_UhyVfA0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_NyxrJP4wOKC5rab &p)
{
	TestInit(p.sbt_tOTdYRBDK);
}

static inline void RandInit(sbt_NyxrJP4wOKC5rab &p)
{
	RandInit(p.sbt_tOTdYRBDK);
}

}//namespace SB

}//namespace CX

