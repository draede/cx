
#pragma once


#include "sbt_z4bmN8S.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_z4bmN8S &p)
{
	{
		sbt_dkU k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_1IU[k] = v;
	}
}

static inline void RandInit(sbt_z4bmN8S &p)
{
	{
		sbt_dkU k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_1IU[k] = v;
	}
	{
		sbt_dkU k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_1IU[k] = v;
	}
	{
		sbt_dkU k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_1IU[k] = v;
	}
	{
		sbt_dkU k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_1IU[k] = v;
	}
	{
		sbt_dkU k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_1IU[k] = v;
	}
}

}//namespace SB

}//namespace CX

