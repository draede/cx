
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_z4bmN8S.hpp"


class sbt_f82QobRCyKhx4nRixtr
{
public:

	CX::UInt64 sbt_H8gIo;
	CX::SB::Vector<sbt_z4bmN8S>::Type sbt_S;
	CX::Double sbt_j2N4x6F;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_f82QobRCyKhx4nRixtr &p)
{
	DefInit(p.sbt_H8gIo);
	DefInit(p.sbt_S);
	DefInit(p.sbt_j2N4x6F);
}

template <> static inline int Compare<sbt_f82QobRCyKhx4nRixtr>(const sbt_f82QobRCyKhx4nRixtr &a, const sbt_f82QobRCyKhx4nRixtr &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_H8gIo, b.sbt_H8gIo)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_S, b.sbt_S)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j2N4x6F, b.sbt_j2N4x6F)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_f82QobRCyKhx4nRixtr>(const sbt_f82QobRCyKhx4nRixtr &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_H8gIo, pHasher);
	Hash(p.sbt_S, pHasher);
	Hash(p.sbt_j2N4x6F, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_f82QobRCyKhx4nRixtr>(sbt_f82QobRCyKhx4nRixtr p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_H8gIo", p.sbt_H8gIo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j2N4x6F", p.sbt_j2N4x6F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_f82QobRCyKhx4nRixtr>(sbt_f82QobRCyKhx4nRixtr &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_H8gIo", p.sbt_H8gIo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j2N4x6F", p.sbt_j2N4x6F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

