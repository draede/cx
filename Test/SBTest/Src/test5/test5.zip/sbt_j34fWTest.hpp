
#pragma once


#include "sbt_j34fW.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_DTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_j34fW &p)
{
	TestInit(p.sbt_XnD6Sfr3f);
}

static inline void RandInit(sbt_j34fW &p)
{
	RandInit(p.sbt_XnD6Sfr3f);
}

}//namespace SB

}//namespace CX

