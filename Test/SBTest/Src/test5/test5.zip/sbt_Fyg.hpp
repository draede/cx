
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_XpRGlsG8F1Eg9.hpp"
#include "sbt_5As.hpp"
#include "sbt_13GajuRnBvPtmdezHGN.hpp"


class sbt_Fyg
{
public:

	CX::Int32 sbt_4Adhe;
	CX::SB::Vector<sbt_XpRGlsG8F1Eg9>::Type sbt_P;
	sbt_5As sbt_ZmlRC_v;
	CX::Float sbt_gJtFs7Y;
	sbt_13GajuRnBvPtmdezHGN sbt_h;
	CX::Float sbt_ohCpe;
	CX::UInt32 sbt_u;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Fyg &p)
{
	DefInit(p.sbt_4Adhe);
	DefInit(p.sbt_P);
	DefInit(p.sbt_ZmlRC_v);
	DefInit(p.sbt_gJtFs7Y);
	DefInit(p.sbt_h);
	DefInit(p.sbt_ohCpe);
	DefInit(p.sbt_u);
}

template <> static inline int Compare<sbt_Fyg>(const sbt_Fyg &a, const sbt_Fyg &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4Adhe, b.sbt_4Adhe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_P, b.sbt_P)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ZmlRC_v, b.sbt_ZmlRC_v)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gJtFs7Y, b.sbt_gJtFs7Y)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_h, b.sbt_h)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ohCpe, b.sbt_ohCpe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_u, b.sbt_u)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Fyg>(const sbt_Fyg &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4Adhe, pHasher);
	Hash(p.sbt_P, pHasher);
	Hash(p.sbt_ZmlRC_v, pHasher);
	Hash(p.sbt_gJtFs7Y, pHasher);
	Hash(p.sbt_h, pHasher);
	Hash(p.sbt_ohCpe, pHasher);
	Hash(p.sbt_u, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Fyg>(sbt_Fyg p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4Adhe", p.sbt_4Adhe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_P", p.sbt_P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ZmlRC_v", p.sbt_ZmlRC_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gJtFs7Y", p.sbt_gJtFs7Y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ohCpe", p.sbt_ohCpe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_u", p.sbt_u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Fyg>(sbt_Fyg &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4Adhe", p.sbt_4Adhe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_P", p.sbt_P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ZmlRC_v", p.sbt_ZmlRC_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gJtFs7Y", p.sbt_gJtFs7Y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ohCpe", p.sbt_ohCpe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_u", p.sbt_u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

