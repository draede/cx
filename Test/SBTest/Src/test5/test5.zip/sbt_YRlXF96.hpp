
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_v8_4oQnks.hpp"
#include "sbt_ziHWqp4.hpp"


class sbt_YRlXF96
{
public:

	CX::SB::Vector<CX::Float>::Type sbt_6ea;
	CX::UInt16 sbt_6kJqu;
	sbt_v8_4oQnks sbt_KCrTy7MRZ;
	CX::UInt8 sbt_UCv;
	CX::SB::Map<CX::Bool, CX::Int64>::Type sbt_XuV;
	CX::WString sbt_Yypncm9;
	sbt_v8_4oQnks sbt__;
	CX::Double sbt_rtLSxiJ;
	sbt_ziHWqp4 sbt_z;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_YRlXF96 &p)
{
	DefInit(p.sbt_6ea);
	DefInit(p.sbt_6kJqu);
	DefInit(p.sbt_KCrTy7MRZ);
	DefInit(p.sbt_UCv);
	DefInit(p.sbt_XuV);
	DefInit(p.sbt_Yypncm9);
	DefInit(p.sbt__);
	DefInit(p.sbt_rtLSxiJ);
	DefInit(p.sbt_z);
}

template <> static inline int Compare<sbt_YRlXF96>(const sbt_YRlXF96 &a, const sbt_YRlXF96 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6ea, b.sbt_6ea)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6kJqu, b.sbt_6kJqu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KCrTy7MRZ, b.sbt_KCrTy7MRZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UCv, b.sbt_UCv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XuV, b.sbt_XuV)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Yypncm9, b.sbt_Yypncm9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__, b.sbt__)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rtLSxiJ, b.sbt_rtLSxiJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_z, b.sbt_z)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_YRlXF96>(const sbt_YRlXF96 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6ea, pHasher);
	Hash(p.sbt_6kJqu, pHasher);
	Hash(p.sbt_KCrTy7MRZ, pHasher);
	Hash(p.sbt_UCv, pHasher);
	Hash(p.sbt_XuV, pHasher);
	Hash(p.sbt_Yypncm9, pHasher);
	Hash(p.sbt__, pHasher);
	Hash(p.sbt_rtLSxiJ, pHasher);
	Hash(p.sbt_z, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_YRlXF96>(sbt_YRlXF96 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6ea", p.sbt_6ea)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6kJqu", p.sbt_6kJqu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KCrTy7MRZ", p.sbt_KCrTy7MRZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UCv", p.sbt_UCv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XuV", p.sbt_XuV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Yypncm9", p.sbt_Yypncm9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rtLSxiJ", p.sbt_rtLSxiJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_z", p.sbt_z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_YRlXF96>(sbt_YRlXF96 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6ea", p.sbt_6ea)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6kJqu", p.sbt_6kJqu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KCrTy7MRZ", p.sbt_KCrTy7MRZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UCv", p.sbt_UCv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XuV", p.sbt_XuV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Yypncm9", p.sbt_Yypncm9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rtLSxiJ", p.sbt_rtLSxiJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_z", p.sbt_z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

