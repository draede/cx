
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_f82QobRCyKhx4nRixtr.hpp"
#include "sbt_UhyVfA0.hpp"


class sbt_9Ag3OVyhW21Fxly
{
public:

	CX::Double sbt_0zSKO;
	sbt_f82QobRCyKhx4nRixtr sbt_1;
	CX::SB::Vector<sbt_f82QobRCyKhx4nRixtr>::Type sbt_47npdugCs;
	CX::UInt16 sbt_9;
	sbt_UhyVfA0 sbt_POvBt;
	CX::SB::Vector<CX::Float>::Type sbt_Sn9;
	CX::SB::Map<CX::UInt16, CX::Int16>::Type sbt_X7r63;
	CX::Int32 sbt_a;
	CX::WString sbt_amOtL;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_9Ag3OVyhW21Fxly &p)
{
	DefInit(p.sbt_0zSKO);
	DefInit(p.sbt_1);
	DefInit(p.sbt_47npdugCs);
	DefInit(p.sbt_9);
	DefInit(p.sbt_POvBt);
	DefInit(p.sbt_Sn9);
	DefInit(p.sbt_X7r63);
	DefInit(p.sbt_a);
	DefInit(p.sbt_amOtL);
}

template <> static inline int Compare<sbt_9Ag3OVyhW21Fxly>(const sbt_9Ag3OVyhW21Fxly &a, const sbt_9Ag3OVyhW21Fxly &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0zSKO, b.sbt_0zSKO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_1, b.sbt_1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_47npdugCs, b.sbt_47npdugCs)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_9, b.sbt_9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_POvBt, b.sbt_POvBt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sn9, b.sbt_Sn9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X7r63, b.sbt_X7r63)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_a, b.sbt_a)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_amOtL, b.sbt_amOtL)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_9Ag3OVyhW21Fxly>(const sbt_9Ag3OVyhW21Fxly &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0zSKO, pHasher);
	Hash(p.sbt_1, pHasher);
	Hash(p.sbt_47npdugCs, pHasher);
	Hash(p.sbt_9, pHasher);
	Hash(p.sbt_POvBt, pHasher);
	Hash(p.sbt_Sn9, pHasher);
	Hash(p.sbt_X7r63, pHasher);
	Hash(p.sbt_a, pHasher);
	Hash(p.sbt_amOtL, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_9Ag3OVyhW21Fxly>(sbt_9Ag3OVyhW21Fxly p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0zSKO", p.sbt_0zSKO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1", p.sbt_1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_47npdugCs", p.sbt_47npdugCs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9", p.sbt_9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_POvBt", p.sbt_POvBt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sn9", p.sbt_Sn9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X7r63", p.sbt_X7r63)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_a", p.sbt_a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_amOtL", p.sbt_amOtL)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_9Ag3OVyhW21Fxly>(sbt_9Ag3OVyhW21Fxly &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0zSKO", p.sbt_0zSKO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_1", p.sbt_1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_47npdugCs", p.sbt_47npdugCs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_9", p.sbt_9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_POvBt", p.sbt_POvBt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sn9", p.sbt_Sn9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X7r63", p.sbt_X7r63)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_a", p.sbt_a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_amOtL", p.sbt_amOtL)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

