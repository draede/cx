
#pragma once


#include "sbt_5FjbRJX.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_v8_4oQnksTest.hpp"
#include "sbt_E8rJi4sPLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_5FjbRJX &p)
{
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	TestInit(p.sbt_ELz);
	p.sbt_TksXB[0.243904] = 0.182781f;
	p.sbt_TksXB[0.697079] = 0.465103f;
	p.sbt_TksXB[0.641934] = 0.361658f;
	p.sbt_Y = 3253233844;
	p.sbt_uSkkG = 7785386186721503724;
}

static inline void RandInit(sbt_5FjbRJX &p)
{
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_9n2b3Vh.push_back(k);
	}
	RandInit(p.sbt_ELz);
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TksXB[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_Y = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_uSkkG = CX::Util::RndGen::Get().GetUInt64();
}

}//namespace SB

}//namespace CX

