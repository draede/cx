
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_dkU.hpp"
#include "sbt_l99Hbqs.hpp"


class sbt_9dYl7KuIf8m0FVG
{
public:

	CX::SB::Vector<sbt_dkU>::Type sbt_9DmETDo;
	CX::UInt32 sbt_LdwIJ;
	CX::UInt16 sbt_RoOAR7JNp;
	CX::UInt64 sbt_Y;
	sbt_l99Hbqs sbt_w5S;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_9dYl7KuIf8m0FVG &p)
{
	DefInit(p.sbt_9DmETDo);
	DefInit(p.sbt_LdwIJ);
	DefInit(p.sbt_RoOAR7JNp);
	DefInit(p.sbt_Y);
	DefInit(p.sbt_w5S);
}

template <> static inline int Compare<sbt_9dYl7KuIf8m0FVG>(const sbt_9dYl7KuIf8m0FVG &a, const sbt_9dYl7KuIf8m0FVG &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_9DmETDo, b.sbt_9DmETDo)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LdwIJ, b.sbt_LdwIJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_RoOAR7JNp, b.sbt_RoOAR7JNp)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Y, b.sbt_Y)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_w5S, b.sbt_w5S)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_9dYl7KuIf8m0FVG>(const sbt_9dYl7KuIf8m0FVG &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_9DmETDo, pHasher);
	Hash(p.sbt_LdwIJ, pHasher);
	Hash(p.sbt_RoOAR7JNp, pHasher);
	Hash(p.sbt_Y, pHasher);
	Hash(p.sbt_w5S, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_9dYl7KuIf8m0FVG>(sbt_9dYl7KuIf8m0FVG p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9DmETDo", p.sbt_9DmETDo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LdwIJ", p.sbt_LdwIJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_RoOAR7JNp", p.sbt_RoOAR7JNp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Y", p.sbt_Y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_w5S", p.sbt_w5S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_9dYl7KuIf8m0FVG>(sbt_9dYl7KuIf8m0FVG &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_9DmETDo", p.sbt_9DmETDo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LdwIJ", p.sbt_LdwIJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_RoOAR7JNp", p.sbt_RoOAR7JNp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Y", p.sbt_Y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_w5S", p.sbt_w5S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

