
#pragma once


#include "sbt_SqF1sTE.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_tTest.hpp"
#include "sbt_EbuTest.hpp"
#include "sbt__FywnTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_SqF1sTE &p)
{
	p.sbt_0 = "CEc3!";
	p.sbt_A = 0.540591f;
	p.sbt_KvR = 16811;
	TestInit(p.sbt_Llrkm);
	p.sbt_YSI6y = 135168038;
	TestInit(p.sbt_aR2KH);
	p.sbt_cLUjl = 1360770266910117994;
	TestInit(p.sbt_eFeJa);
	p.sbt_hNRxl = 25119;
}

static inline void RandInit(sbt_SqF1sTE &p)
{
	p.sbt_0 = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_A = CX::Util::RndGen::Get().GetFloat();
	p.sbt_KvR = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_Llrkm);
	p.sbt_YSI6y = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_aR2KH);
	p.sbt_cLUjl = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_eFeJa);
	p.sbt_hNRxl = CX::Util::RndGen::Get().GetUInt16();
}

}//namespace SB

}//namespace CX

