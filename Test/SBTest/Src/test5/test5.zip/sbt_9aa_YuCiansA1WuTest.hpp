
#pragma once


#include "sbt_9aa_YuCiansA1Wu.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt__FywnTest.hpp"
#include "sbt_LytLrTest.hpp"
#include "sbt_z4bmN8STest.hpp"
#include "sbt_ITest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_9aa_YuCiansA1Wu &p)
{
	p.sbt_1vVTEq4 = 1002334103;
	p.sbt_3Wu = 36401;
	{
		sbt__Fywn k;
		sbt_LytLr v;

		TestInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_LytLr v;

		TestInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_LytLr v;

		TestInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	p.sbt_EkION.push_back(true);
	p.sbt_EkION.push_back(true);
	p.sbt_EkION.push_back(false);
	p.sbt_EkION.push_back(false);
	p.sbt_EkION.push_back(false);
	p.sbt_EkION.push_back(false);
	p.sbt_EkION.push_back(false);
	TestInit(p.sbt_I2505TYur);
	p.sbt_dwwKF.push_back(35);
	p.sbt_dwwKF.push_back(-22);
	p.sbt_dwwKF.push_back(-81);
	p.sbt_dwwKF.push_back(-51);
	p.sbt_dwwKF.push_back(-97);
	p.sbt_dwwKF.push_back(-108);
	p.sbt_dwwKF.push_back(12);
	p.sbt_kRX = 18239;
	TestInit(p.sbt_l);
	p.sbt_rGoY_mP = 49173;
}

static inline void RandInit(sbt_9aa_YuCiansA1Wu &p)
{
	p.sbt_1vVTEq4 = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_3Wu = CX::Util::RndGen::Get().GetUInt16();
	{
		sbt__Fywn k;
		sbt_LytLr v;

		RandInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_LytLr v;

		RandInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_LytLr v;

		RandInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_LytLr v;

		RandInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_LytLr v;

		RandInit(k);
		TestInit(v);
		p.sbt_9qJ3yNOR7[k] = v;
	}
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_EkION.push_back(CX::Util::RndGen::Get().GetBool());
	RandInit(p.sbt_I2505TYur);
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_dwwKF.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_kRX = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_l);
	p.sbt_rGoY_mP = CX::Util::RndGen::Get().GetUInt16();
}

}//namespace SB

}//namespace CX

