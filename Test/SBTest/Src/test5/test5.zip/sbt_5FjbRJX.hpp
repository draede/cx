
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_v8_4oQnks.hpp"
#include "sbt_E8rJi4sPL.hpp"


class sbt_5FjbRJX
{
public:

	CX::SB::Vector<sbt_v8_4oQnks>::Type sbt_9n2b3Vh;
	sbt_E8rJi4sPL sbt_ELz;
	CX::SB::Map<CX::Double, CX::Float>::Type sbt_TksXB;
	CX::UInt32 sbt_Y;
	CX::UInt64 sbt_uSkkG;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_5FjbRJX &p)
{
	DefInit(p.sbt_9n2b3Vh);
	DefInit(p.sbt_ELz);
	DefInit(p.sbt_TksXB);
	DefInit(p.sbt_Y);
	DefInit(p.sbt_uSkkG);
}

template <> static inline int Compare<sbt_5FjbRJX>(const sbt_5FjbRJX &a, const sbt_5FjbRJX &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_9n2b3Vh, b.sbt_9n2b3Vh)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ELz, b.sbt_ELz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TksXB, b.sbt_TksXB)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Y, b.sbt_Y)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_uSkkG, b.sbt_uSkkG)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_5FjbRJX>(const sbt_5FjbRJX &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_9n2b3Vh, pHasher);
	Hash(p.sbt_ELz, pHasher);
	Hash(p.sbt_TksXB, pHasher);
	Hash(p.sbt_Y, pHasher);
	Hash(p.sbt_uSkkG, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_5FjbRJX>(sbt_5FjbRJX p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9n2b3Vh", p.sbt_9n2b3Vh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ELz", p.sbt_ELz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TksXB", p.sbt_TksXB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Y", p.sbt_Y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_uSkkG", p.sbt_uSkkG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_5FjbRJX>(sbt_5FjbRJX &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_9n2b3Vh", p.sbt_9n2b3Vh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ELz", p.sbt_ELz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TksXB", p.sbt_TksXB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Y", p.sbt_Y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_uSkkG", p.sbt_uSkkG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

