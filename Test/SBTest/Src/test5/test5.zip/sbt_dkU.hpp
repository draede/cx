
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"


class sbt_dkU
{
public:

	CX::UInt16 sbt_EICHC3FLr;
	CX::SB::Map<CX::Bool, CX::UInt16>::Type sbt_ITUqr4G;
	CX::SB::Map<CX::UInt32, CX::UInt64>::Type sbt_Lg_nOGTND;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_dkU &p)
{
	DefInit(p.sbt_EICHC3FLr);
	DefInit(p.sbt_ITUqr4G);
	DefInit(p.sbt_Lg_nOGTND);
}

template <> static inline int Compare<sbt_dkU>(const sbt_dkU &a, const sbt_dkU &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_EICHC3FLr, b.sbt_EICHC3FLr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ITUqr4G, b.sbt_ITUqr4G)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Lg_nOGTND, b.sbt_Lg_nOGTND)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_dkU>(const sbt_dkU &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_EICHC3FLr, pHasher);
	Hash(p.sbt_ITUqr4G, pHasher);
	Hash(p.sbt_Lg_nOGTND, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_dkU>(sbt_dkU p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EICHC3FLr", p.sbt_EICHC3FLr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ITUqr4G", p.sbt_ITUqr4G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Lg_nOGTND", p.sbt_Lg_nOGTND)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_dkU>(sbt_dkU &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_EICHC3FLr", p.sbt_EICHC3FLr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ITUqr4G", p.sbt_ITUqr4G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Lg_nOGTND", p.sbt_Lg_nOGTND)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

