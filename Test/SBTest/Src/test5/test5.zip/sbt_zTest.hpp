
#pragma once


#include "sbt_z.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"
#include "sbt_cdxtwwTUWUe2lTest.hpp"
#include "sbt_9aa_YuCiansA1WuTest.hpp"
#include "sbt_EGwE1AfTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_z &p)
{
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		TestInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	p.sbt_P[1753248711] = 0.917941;
	p.sbt_P[-2024193239] = 0.565903;
	p.sbt_P[-634524288] = 0.739807;
	p.sbt_P[1719569389] = 0.158385;
	p.sbt_P[1963449096] = 0.959378;
	p.sbt_PeuBnet = 0.732422f;
	p.sbt_RTMYhL2cP = 471353592363761886;
	TestInit(p.sbt_XGqjd);
	TestInit(p.sbt_k);
	p.sbt_kn1FI = 1471708598;
	p.sbt_r = -5339764298610233776;
	p.sbt_tgDbKmqUe[0.905806f] = 40;
	p.sbt_tgDbKmqUe[0.296865f] = 64;
	p.sbt_tgDbKmqUe[0.350131f] = 15;
}

static inline void RandInit(sbt_z &p)
{
	{
		sbt_dkU k;
		sbt_cdxtwwTUWUe2l v;

		RandInit(k);
		TestInit(v);
		p.sbt_6vt[k] = v;
	}
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_P[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_PeuBnet = CX::Util::RndGen::Get().GetFloat();
	p.sbt_RTMYhL2cP = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_XGqjd);
	RandInit(p.sbt_k);
	p.sbt_kn1FI = CX::Util::RndGen::Get().GetInt32();
	p.sbt_r = CX::Util::RndGen::Get().GetInt64();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tgDbKmqUe[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt8();
}

}//namespace SB

}//namespace CX

