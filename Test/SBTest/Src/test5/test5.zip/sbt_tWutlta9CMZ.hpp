
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_dkU.hpp"


class sbt_tWutlta9CMZ
{
public:

	sbt_dkU sbt_O_Xqt;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_tWutlta9CMZ &p)
{
	DefInit(p.sbt_O_Xqt);
}

template <> static inline int Compare<sbt_tWutlta9CMZ>(const sbt_tWutlta9CMZ &a, const sbt_tWutlta9CMZ &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_O_Xqt, b.sbt_O_Xqt)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_tWutlta9CMZ>(const sbt_tWutlta9CMZ &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_O_Xqt, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_tWutlta9CMZ>(sbt_tWutlta9CMZ p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_O_Xqt", p.sbt_O_Xqt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_tWutlta9CMZ>(sbt_tWutlta9CMZ &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (1 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 1 members");
	}
	if ((status = pDataReader->ReadMember("sbt_O_Xqt", p.sbt_O_Xqt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

