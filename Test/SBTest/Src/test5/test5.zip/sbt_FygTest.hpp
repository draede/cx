
#pragma once


#include "sbt_Fyg.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_XpRGlsG8F1Eg9Test.hpp"
#include "sbt_5AsTest.hpp"
#include "sbt_13GajuRnBvPtmdezHGNTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Fyg &p)
{
	p.sbt_4Adhe = 1612027956;
	{
		sbt_XpRGlsG8F1Eg9 k;

		TestInit(k);
		p.sbt_P.push_back(k);
	}
	{
		sbt_XpRGlsG8F1Eg9 k;

		TestInit(k);
		p.sbt_P.push_back(k);
	}
	{
		sbt_XpRGlsG8F1Eg9 k;

		TestInit(k);
		p.sbt_P.push_back(k);
	}
	TestInit(p.sbt_ZmlRC_v);
	p.sbt_gJtFs7Y = 0.732940f;
	TestInit(p.sbt_h);
	p.sbt_ohCpe = 0.817985f;
	p.sbt_u = 2360991483;
}

static inline void RandInit(sbt_Fyg &p)
{
	p.sbt_4Adhe = CX::Util::RndGen::Get().GetInt32();
	{
		sbt_XpRGlsG8F1Eg9 k;

		TestInit(k);
		p.sbt_P.push_back(k);
	}
	{
		sbt_XpRGlsG8F1Eg9 k;

		TestInit(k);
		p.sbt_P.push_back(k);
	}
	{
		sbt_XpRGlsG8F1Eg9 k;

		TestInit(k);
		p.sbt_P.push_back(k);
	}
	RandInit(p.sbt_ZmlRC_v);
	p.sbt_gJtFs7Y = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_h);
	p.sbt_ohCpe = CX::Util::RndGen::Get().GetFloat();
	p.sbt_u = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

