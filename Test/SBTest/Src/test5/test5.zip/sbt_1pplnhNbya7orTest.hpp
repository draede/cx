
#pragma once


#include "sbt_1pplnhNbya7or.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_XpRGlsG8F1Eg9Test.hpp"
#include "sbt_cdxtwwTUWUe2lTest.hpp"
#include "sbt_8ft4kg2bXtvQtsjTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_1pplnhNbya7or &p)
{
	TestInit(p.sbt_66W);
	p.sbt_EYGV54ARO = 11852217298934555998;
	p.sbt_Sr9zbieZJ = 1691280046;
	p.sbt_YanwO1s[-6916] = "qS{As'9g9{_1e[{}WQ/WMQGw5OK=";
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	p.sbt_fMxtxQ2tY = 8685435973716600340;
	TestInit(p.sbt_uLYGqat);
}

static inline void RandInit(sbt_1pplnhNbya7or &p)
{
	RandInit(p.sbt_66W);
	p.sbt_EYGV54ARO = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_Sr9zbieZJ = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_YanwO1s[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	{
		sbt_cdxtwwTUWUe2l k;

		TestInit(k);
		p.sbt_ZkJ.push_back(k);
	}
	p.sbt_fMxtxQ2tY = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_uLYGqat);
}

}//namespace SB

}//namespace CX

