
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_dkU.hpp"
#include "sbt__Fywn.hpp"
#include "sbt_AvrDhwJyr3qach0.hpp"


class sbt_LytLr
{
public:

	CX::Int16 sbt_AOLGO4P;
	sbt_dkU sbt_MTw1z8n1K;
	CX::String sbt_Sv5oIPJ3H;
	CX::SB::Vector<CX::WString>::Type sbt_dvLqj;
	sbt__Fywn sbt_jVzcsz6;
	sbt_AvrDhwJyr3qach0 sbt_n2GpII7;
	CX::SB::Vector<CX::UInt32>::Type sbt_uz8;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_LytLr &p)
{
	DefInit(p.sbt_AOLGO4P);
	DefInit(p.sbt_MTw1z8n1K);
	DefInit(p.sbt_Sv5oIPJ3H);
	DefInit(p.sbt_dvLqj);
	DefInit(p.sbt_jVzcsz6);
	DefInit(p.sbt_n2GpII7);
	DefInit(p.sbt_uz8);
}

template <> static inline int Compare<sbt_LytLr>(const sbt_LytLr &a, const sbt_LytLr &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_AOLGO4P, b.sbt_AOLGO4P)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_MTw1z8n1K, b.sbt_MTw1z8n1K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sv5oIPJ3H, b.sbt_Sv5oIPJ3H)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_dvLqj, b.sbt_dvLqj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jVzcsz6, b.sbt_jVzcsz6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_n2GpII7, b.sbt_n2GpII7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_uz8, b.sbt_uz8)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_LytLr>(const sbt_LytLr &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_AOLGO4P, pHasher);
	Hash(p.sbt_MTw1z8n1K, pHasher);
	Hash(p.sbt_Sv5oIPJ3H, pHasher);
	Hash(p.sbt_dvLqj, pHasher);
	Hash(p.sbt_jVzcsz6, pHasher);
	Hash(p.sbt_n2GpII7, pHasher);
	Hash(p.sbt_uz8, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_LytLr>(sbt_LytLr p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_AOLGO4P", p.sbt_AOLGO4P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_MTw1z8n1K", p.sbt_MTw1z8n1K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sv5oIPJ3H", p.sbt_Sv5oIPJ3H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_dvLqj", p.sbt_dvLqj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jVzcsz6", p.sbt_jVzcsz6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_n2GpII7", p.sbt_n2GpII7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_uz8", p.sbt_uz8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_LytLr>(sbt_LytLr &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_AOLGO4P", p.sbt_AOLGO4P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_MTw1z8n1K", p.sbt_MTw1z8n1K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sv5oIPJ3H", p.sbt_Sv5oIPJ3H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_dvLqj", p.sbt_dvLqj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jVzcsz6", p.sbt_jVzcsz6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_n2GpII7", p.sbt_n2GpII7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_uz8", p.sbt_uz8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

