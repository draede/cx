
#pragma once


#include "sbt_EGwE1Af.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ITest.hpp"
#include "sbt__FywnTest.hpp"
#include "sbt_5AsTest.hpp"
#include "sbt_FygTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_EGwE1Af &p)
{
	p.sbt_dI4 = -3024146317347130450;
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		TestInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	TestInit(p.sbt_nQuwtiQ);
	p.sbt_rnOwu = false;
	p.sbt_v = L"c];eUaMW";
	p.sbt_yDX = 0.161139f;
}

static inline void RandInit(sbt_EGwE1Af &p)
{
	p.sbt_dI4 = CX::Util::RndGen::Get().GetInt64();
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt_I k;

		TestInit(k);
		p.sbt_l.push_back(k);
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	{
		sbt__Fywn k;
		sbt_5As v;

		RandInit(k);
		TestInit(v);
		p.sbt_ljeVgOr[k] = v;
	}
	RandInit(p.sbt_nQuwtiQ);
	p.sbt_rnOwu = CX::Util::RndGen::Get().GetBool();
	p.sbt_v = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_yDX = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

