
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_5As.hpp"
#include "sbt_tWutlta9CMZ.hpp"
#include "sbt_Fyg.hpp"
#include "sbt_9z87obF.hpp"


class sbt_dqkBk
{
public:

	CX::Int16 sbt_5ho5rYeV0;
	CX::Float sbt_76T6V;
	CX::Int32 sbt_C;
	CX::Int64 sbt_UmOGR;
	CX::SB::Map<sbt_5As, sbt_tWutlta9CMZ>::Type sbt_ceOFhOjdZ;
	sbt_Fyg sbt_naJua2Cga;
	sbt_9z87obF sbt_sPWlJjh7n;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_dqkBk &p)
{
	DefInit(p.sbt_5ho5rYeV0);
	DefInit(p.sbt_76T6V);
	DefInit(p.sbt_C);
	DefInit(p.sbt_UmOGR);
	DefInit(p.sbt_ceOFhOjdZ);
	DefInit(p.sbt_naJua2Cga);
	DefInit(p.sbt_sPWlJjh7n);
}

template <> static inline int Compare<sbt_dqkBk>(const sbt_dqkBk &a, const sbt_dqkBk &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5ho5rYeV0, b.sbt_5ho5rYeV0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_76T6V, b.sbt_76T6V)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_C, b.sbt_C)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UmOGR, b.sbt_UmOGR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ceOFhOjdZ, b.sbt_ceOFhOjdZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_naJua2Cga, b.sbt_naJua2Cga)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_sPWlJjh7n, b.sbt_sPWlJjh7n)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_dqkBk>(const sbt_dqkBk &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5ho5rYeV0, pHasher);
	Hash(p.sbt_76T6V, pHasher);
	Hash(p.sbt_C, pHasher);
	Hash(p.sbt_UmOGR, pHasher);
	Hash(p.sbt_ceOFhOjdZ, pHasher);
	Hash(p.sbt_naJua2Cga, pHasher);
	Hash(p.sbt_sPWlJjh7n, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_dqkBk>(sbt_dqkBk p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5ho5rYeV0", p.sbt_5ho5rYeV0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_76T6V", p.sbt_76T6V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_C", p.sbt_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UmOGR", p.sbt_UmOGR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ceOFhOjdZ", p.sbt_ceOFhOjdZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_naJua2Cga", p.sbt_naJua2Cga)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_sPWlJjh7n", p.sbt_sPWlJjh7n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_dqkBk>(sbt_dqkBk &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5ho5rYeV0", p.sbt_5ho5rYeV0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_76T6V", p.sbt_76T6V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_C", p.sbt_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UmOGR", p.sbt_UmOGR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ceOFhOjdZ", p.sbt_ceOFhOjdZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_naJua2Cga", p.sbt_naJua2Cga)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_sPWlJjh7n", p.sbt_sPWlJjh7n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

