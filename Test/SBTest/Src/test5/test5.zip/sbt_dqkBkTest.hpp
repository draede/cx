
#pragma once


#include "sbt_dqkBk.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_5AsTest.hpp"
#include "sbt_tWutlta9CMZTest.hpp"
#include "sbt_FygTest.hpp"
#include "sbt_9z87obFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_dqkBk &p)
{
	p.sbt_5ho5rYeV0 = -26118;
	p.sbt_76T6V = 0.893338f;
	p.sbt_C = -975965304;
	p.sbt_UmOGR = -6592198902505674596;
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		TestInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		TestInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		TestInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		TestInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		TestInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	TestInit(p.sbt_naJua2Cga);
	TestInit(p.sbt_sPWlJjh7n);
}

static inline void RandInit(sbt_dqkBk &p)
{
	p.sbt_5ho5rYeV0 = CX::Util::RndGen::Get().GetInt16();
	p.sbt_76T6V = CX::Util::RndGen::Get().GetFloat();
	p.sbt_C = CX::Util::RndGen::Get().GetInt32();
	p.sbt_UmOGR = CX::Util::RndGen::Get().GetInt64();
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		RandInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		RandInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		RandInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		RandInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	{
		sbt_5As k;
		sbt_tWutlta9CMZ v;

		RandInit(k);
		TestInit(v);
		p.sbt_ceOFhOjdZ[k] = v;
	}
	RandInit(p.sbt_naJua2Cga);
	RandInit(p.sbt_sPWlJjh7n);
}

}//namespace SB

}//namespace CX

