
#pragma once


#include "sbt_v8_4oQnks.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_z4bmN8STest.hpp"
#include "sbt_AvrDhwJyr3qach0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_v8_4oQnks &p)
{
	TestInit(p.sbt_80GRQw6K2);
	p.sbt_E5ENFmJ = 10123;
	p.sbt_QSz2GbO[L"1=I}qgKO35om/[m/"] = "9Y)]u?73S5+99;w3e59";
	p.sbt_QSz2GbO[L"{kwI'%yk-K?="] = "Q5--5a[]U'5iS?[m-{=]W--i1iK";
	p.sbt_QSz2GbO[L"+-A/ks][=kaMS/A[m]cq5"] = "S!M?q]_!7AGOs_u{";
	p.sbt_QSz2GbO[L"K)3y!YAS5y'Agm}1cOu{S'AG/e+"] = "!9K}g%sM#{!+y_s#)W#ikSi;I";
	p.sbt_QSz2GbO[L"/{aW1{"] = "3-O3+q?W7=-A";
	p.sbt_fi79m2T[0.532871f] = -1258508003;
	p.sbt_fi79m2T[0.999674f] = -1417850901;
	p.sbt_fi79m2T[0.927633f] = 486077878;
	TestInit(p.sbt_ho_);
	p.sbt_k = 1413486048;
	TestInit(p.sbt_p);
}

static inline void RandInit(sbt_v8_4oQnks &p)
{
	RandInit(p.sbt_80GRQw6K2);
	p.sbt_E5ENFmJ = CX::Util::RndGen::Get().GetInt16();
	p.sbt_QSz2GbO[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_QSz2GbO[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_QSz2GbO[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fi79m2T[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_ho_);
	p.sbt_k = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_p);
}

}//namespace SB

}//namespace CX

