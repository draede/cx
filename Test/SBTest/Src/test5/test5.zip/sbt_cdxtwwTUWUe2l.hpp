
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_tWutlta9CMZ.hpp"
#include "sbt_f82QobRCyKhx4nRixtr.hpp"
#include "sbt_9dYl7KuIf8m0FVG.hpp"
#include "sbt_dkU.hpp"


class sbt_cdxtwwTUWUe2l
{
public:

	sbt_tWutlta9CMZ sbt_F0LAM;
	CX::Int8 sbt_N_g;
	CX::String sbt_T;
	CX::SB::Vector<CX::String>::Type sbt_Xzj8o5YJB;
	CX::Double sbt_YEHpc;
	CX::SB::Map<sbt_f82QobRCyKhx4nRixtr, sbt_9dYl7KuIf8m0FVG>::Type sbt_eTfxglFgE;
	sbt_dkU sbt_wZQn7r4;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_cdxtwwTUWUe2l &p)
{
	DefInit(p.sbt_F0LAM);
	DefInit(p.sbt_N_g);
	DefInit(p.sbt_T);
	DefInit(p.sbt_Xzj8o5YJB);
	DefInit(p.sbt_YEHpc);
	DefInit(p.sbt_eTfxglFgE);
	DefInit(p.sbt_wZQn7r4);
}

template <> static inline int Compare<sbt_cdxtwwTUWUe2l>(const sbt_cdxtwwTUWUe2l &a, const sbt_cdxtwwTUWUe2l &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_F0LAM, b.sbt_F0LAM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_N_g, b.sbt_N_g)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_T, b.sbt_T)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Xzj8o5YJB, b.sbt_Xzj8o5YJB)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YEHpc, b.sbt_YEHpc)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_eTfxglFgE, b.sbt_eTfxglFgE)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wZQn7r4, b.sbt_wZQn7r4)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_cdxtwwTUWUe2l>(const sbt_cdxtwwTUWUe2l &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_F0LAM, pHasher);
	Hash(p.sbt_N_g, pHasher);
	Hash(p.sbt_T, pHasher);
	Hash(p.sbt_Xzj8o5YJB, pHasher);
	Hash(p.sbt_YEHpc, pHasher);
	Hash(p.sbt_eTfxglFgE, pHasher);
	Hash(p.sbt_wZQn7r4, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_cdxtwwTUWUe2l>(sbt_cdxtwwTUWUe2l p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F0LAM", p.sbt_F0LAM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_N_g", p.sbt_N_g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_T", p.sbt_T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Xzj8o5YJB", p.sbt_Xzj8o5YJB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YEHpc", p.sbt_YEHpc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_eTfxglFgE", p.sbt_eTfxglFgE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wZQn7r4", p.sbt_wZQn7r4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_cdxtwwTUWUe2l>(sbt_cdxtwwTUWUe2l &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_F0LAM", p.sbt_F0LAM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_N_g", p.sbt_N_g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_T", p.sbt_T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Xzj8o5YJB", p.sbt_Xzj8o5YJB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YEHpc", p.sbt_YEHpc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_eTfxglFgE", p.sbt_eTfxglFgE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wZQn7r4", p.sbt_wZQn7r4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

