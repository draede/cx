
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_t.hpp"
#include "sbt_Ebu.hpp"
#include "sbt__Fywn.hpp"


class sbt_SqF1sTE
{
public:

	CX::String sbt_0;
	CX::Float sbt_A;
	CX::UInt16 sbt_KvR;
	sbt_t sbt_Llrkm;
	CX::Int32 sbt_YSI6y;
	sbt_Ebu sbt_aR2KH;
	CX::Int64 sbt_cLUjl;
	sbt__Fywn sbt_eFeJa;
	CX::UInt16 sbt_hNRxl;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_SqF1sTE &p)
{
	DefInit(p.sbt_0);
	DefInit(p.sbt_A);
	DefInit(p.sbt_KvR);
	DefInit(p.sbt_Llrkm);
	DefInit(p.sbt_YSI6y);
	DefInit(p.sbt_aR2KH);
	DefInit(p.sbt_cLUjl);
	DefInit(p.sbt_eFeJa);
	DefInit(p.sbt_hNRxl);
}

template <> static inline int Compare<sbt_SqF1sTE>(const sbt_SqF1sTE &a, const sbt_SqF1sTE &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0, b.sbt_0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_A, b.sbt_A)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KvR, b.sbt_KvR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Llrkm, b.sbt_Llrkm)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YSI6y, b.sbt_YSI6y)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aR2KH, b.sbt_aR2KH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_cLUjl, b.sbt_cLUjl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_eFeJa, b.sbt_eFeJa)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_hNRxl, b.sbt_hNRxl)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_SqF1sTE>(const sbt_SqF1sTE &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0, pHasher);
	Hash(p.sbt_A, pHasher);
	Hash(p.sbt_KvR, pHasher);
	Hash(p.sbt_Llrkm, pHasher);
	Hash(p.sbt_YSI6y, pHasher);
	Hash(p.sbt_aR2KH, pHasher);
	Hash(p.sbt_cLUjl, pHasher);
	Hash(p.sbt_eFeJa, pHasher);
	Hash(p.sbt_hNRxl, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_SqF1sTE>(sbt_SqF1sTE p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0", p.sbt_0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_A", p.sbt_A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KvR", p.sbt_KvR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Llrkm", p.sbt_Llrkm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YSI6y", p.sbt_YSI6y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aR2KH", p.sbt_aR2KH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_cLUjl", p.sbt_cLUjl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_eFeJa", p.sbt_eFeJa)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_hNRxl", p.sbt_hNRxl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_SqF1sTE>(sbt_SqF1sTE &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0", p.sbt_0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_A", p.sbt_A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KvR", p.sbt_KvR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Llrkm", p.sbt_Llrkm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YSI6y", p.sbt_YSI6y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aR2KH", p.sbt_aR2KH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_cLUjl", p.sbt_cLUjl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_eFeJa", p.sbt_eFeJa)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_hNRxl", p.sbt_hNRxl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

