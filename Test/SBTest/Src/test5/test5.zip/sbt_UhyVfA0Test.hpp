
#pragma once


#include "sbt_UhyVfA0.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ziHWqp4Test.hpp"
#include "sbt_9z87obFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_UhyVfA0 &p)
{
	p.sbt_8k8 = true;
	TestInit(p.sbt_BYHQc);
	p.sbt_FVaXF3D = false;
	p.sbt_Nz5bschor.push_back(0.154802);
	p.sbt_Nz5bschor.push_back(0.904360);
	p.sbt_Nz5bschor.push_back(0.362927);
	p.sbt_Nz5bschor.push_back(0.520847);
	p.sbt_Nz5bschor.push_back(0.468677);
	p.sbt_Nz5bschor.push_back(0.178385);
	p.sbt_Nz5bschor.push_back(0.877459);
	p.sbt_Nz5bschor.push_back(0.137080);
	p.sbt_Nz5bschor.push_back(0.369116);
	TestInit(p.sbt_Q_1);
	p.sbt_V3hXr = -26;
	p.sbt_jEZ = false;
	TestInit(p.sbt_krazS);
	p.sbt_or_jr = 307466641;
}

static inline void RandInit(sbt_UhyVfA0 &p)
{
	p.sbt_8k8 = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_BYHQc);
	p.sbt_FVaXF3D = CX::Util::RndGen::Get().GetBool();
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_Nz5bschor.push_back(CX::Util::RndGen::Get().GetDouble());
	RandInit(p.sbt_Q_1);
	p.sbt_V3hXr = CX::Util::RndGen::Get().GetInt8();
	p.sbt_jEZ = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_krazS);
	p.sbt_or_jr = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

