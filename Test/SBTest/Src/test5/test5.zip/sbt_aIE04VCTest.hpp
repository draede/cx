
#pragma once


#include "sbt_aIE04VC.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_E8rJi4sPLTest.hpp"
#include "sbt_SSrQaTest.hpp"
#include "sbt_l99HbqsTest.hpp"
#include "sbt_XpRGlsG8F1Eg9Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_aIE04VC &p)
{
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		TestInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	p.sbt_TBjmchS = -48;
	TestInit(p.sbt_U);
	p.sbt_j3b3ioo.push_back(1193024447);
	p.sbt_lNs.push_back(L";'_;g#IU3KgK9[[o[");
	p.sbt_lNs.push_back(L"99?%Usw3/]qoa7#W!')i))KS");
	p.sbt_lNs.push_back(L"#w[S=[;#sWGEa_9i5)9M_S13]}){");
	p.sbt_p = 15006;
	TestInit(p.sbt_xR6FM);
}

static inline void RandInit(sbt_aIE04VC &p)
{
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	{
		sbt_E8rJi4sPL k;
		sbt_SSrQa v;

		RandInit(k);
		TestInit(v);
		p.sbt_Ld42sxYMa[k] = v;
	}
	p.sbt_TBjmchS = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_U);
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_j3b3ioo.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_lNs.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_p = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_xR6FM);
}

}//namespace SB

}//namespace CX

