
#pragma once


#include "sbt_SZyOjMczz_rIH.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_5AsTest.hpp"
#include "sbt_YRlXF96Test.hpp"
#include "sbt_DTest.hpp"
#include "sbt_l99HbqsTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_SZyOjMczz_rIH &p)
{
	p.sbt_Gza[68] = 812;
	p.sbt_Gza[10] = -21208;
	p.sbt_Gza[225] = 8603;
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		TestInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	p.sbt_UmTnV.push_back(19845);
	p.sbt_UmTnV.push_back(63085);
	p.sbt_UmTnV.push_back(22897);
	p.sbt_UmTnV.push_back(41715);
	p.sbt_UmTnV.push_back(2285);
	p.sbt_UmTnV.push_back(46676);
	p.sbt_UmTnV.push_back(7890);
	p.sbt_UmTnV.push_back(59940);
	p.sbt_UmTnV.push_back(54187);
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	TestInit(p.sbt_aANlsfmJ3);
	p.sbt_bXN = 20906;
	p.sbt_pqE = 6147240346094303724;
}

static inline void RandInit(sbt_SZyOjMczz_rIH &p)
{
	p.sbt_Gza[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_Gza[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_Gza[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_Gza[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_Gza[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetInt16();
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	{
		sbt_5As k;
		sbt_YRlXF96 v;

		RandInit(k);
		TestInit(v);
		p.sbt_HAZm8[k] = v;
	}
	p.sbt_UmTnV.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_UmTnV.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_UmTnV.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_UmTnV.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_UmTnV.push_back(CX::Util::RndGen::Get().GetUInt16());
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_Yp1e4p_BN.push_back(k);
	}
	RandInit(p.sbt_aANlsfmJ3);
	p.sbt_bXN = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_pqE = CX::Util::RndGen::Get().GetInt64();
}

}//namespace SB

}//namespace CX

