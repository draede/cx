
#pragma once


#include "sbt_D.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_9aa_YuCiansA1WuTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_D &p)
{
	p.sbt_10DxM = -99;
	TestInit(p.sbt_iXM);
	p.sbt_zhqn3ZbyO = 1008350841;
}

static inline void RandInit(sbt_D &p)
{
	p.sbt_10DxM = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_iXM);
	p.sbt_zhqn3ZbyO = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

