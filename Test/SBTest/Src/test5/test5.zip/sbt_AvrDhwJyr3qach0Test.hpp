
#pragma once


#include "sbt_AvrDhwJyr3qach0.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_f82QobRCyKhx4nRixtrTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_AvrDhwJyr3qach0 &p)
{
	TestInit(p.sbt_0lvUVvSCM);
}

static inline void RandInit(sbt_AvrDhwJyr3qach0 &p)
{
	RandInit(p.sbt_0lvUVvSCM);
}

}//namespace SB

}//namespace CX

