
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_5As.hpp"
#include "sbt_YRlXF96.hpp"
#include "sbt_D.hpp"
#include "sbt_l99Hbqs.hpp"


class sbt_SZyOjMczz_rIH
{
public:

	CX::SB::Map<CX::UInt8, CX::Int16>::Type sbt_Gza;
	CX::SB::Map<sbt_5As, sbt_YRlXF96>::Type sbt_HAZm8;
	CX::SB::Vector<CX::UInt16>::Type sbt_UmTnV;
	CX::SB::Vector<sbt_D>::Type sbt_Yp1e4p_BN;
	sbt_l99Hbqs sbt_aANlsfmJ3;
	CX::UInt16 sbt_bXN;
	CX::Int64 sbt_pqE;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_SZyOjMczz_rIH &p)
{
	DefInit(p.sbt_Gza);
	DefInit(p.sbt_HAZm8);
	DefInit(p.sbt_UmTnV);
	DefInit(p.sbt_Yp1e4p_BN);
	DefInit(p.sbt_aANlsfmJ3);
	DefInit(p.sbt_bXN);
	DefInit(p.sbt_pqE);
}

template <> static inline int Compare<sbt_SZyOjMczz_rIH>(const sbt_SZyOjMczz_rIH &a, const sbt_SZyOjMczz_rIH &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Gza, b.sbt_Gza)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_HAZm8, b.sbt_HAZm8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UmTnV, b.sbt_UmTnV)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Yp1e4p_BN, b.sbt_Yp1e4p_BN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aANlsfmJ3, b.sbt_aANlsfmJ3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bXN, b.sbt_bXN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pqE, b.sbt_pqE)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_SZyOjMczz_rIH>(const sbt_SZyOjMczz_rIH &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Gza, pHasher);
	Hash(p.sbt_HAZm8, pHasher);
	Hash(p.sbt_UmTnV, pHasher);
	Hash(p.sbt_Yp1e4p_BN, pHasher);
	Hash(p.sbt_aANlsfmJ3, pHasher);
	Hash(p.sbt_bXN, pHasher);
	Hash(p.sbt_pqE, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_SZyOjMczz_rIH>(sbt_SZyOjMczz_rIH p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Gza", p.sbt_Gza)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_HAZm8", p.sbt_HAZm8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UmTnV", p.sbt_UmTnV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Yp1e4p_BN", p.sbt_Yp1e4p_BN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aANlsfmJ3", p.sbt_aANlsfmJ3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bXN", p.sbt_bXN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pqE", p.sbt_pqE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_SZyOjMczz_rIH>(sbt_SZyOjMczz_rIH &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Gza", p.sbt_Gza)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_HAZm8", p.sbt_HAZm8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UmTnV", p.sbt_UmTnV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Yp1e4p_BN", p.sbt_Yp1e4p_BN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aANlsfmJ3", p.sbt_aANlsfmJ3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bXN", p.sbt_bXN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pqE", p.sbt_pqE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

