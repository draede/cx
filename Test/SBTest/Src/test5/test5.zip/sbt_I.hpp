
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_z4bmN8S.hpp"
#include "sbt_UhyVfA0.hpp"
#include "sbt_cdxtwwTUWUe2l.hpp"


class sbt_I
{
public:

	CX::Double sbt_9TE7V3V;
	CX::SB::Map<CX::Bool, CX::WString>::Type sbt_Cx1DWWzE8;
	sbt_z4bmN8S sbt_HzgyVpn;
	CX::Int64 sbt_IPR;
	CX::Int16 sbt_S;
	sbt_UhyVfA0 sbt_UmNr9aRXe;
	sbt_cdxtwwTUWUe2l sbt_gHC;
	CX::Int64 sbt_k;
	CX::Double sbt_v;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_I &p)
{
	DefInit(p.sbt_9TE7V3V);
	DefInit(p.sbt_Cx1DWWzE8);
	DefInit(p.sbt_HzgyVpn);
	DefInit(p.sbt_IPR);
	DefInit(p.sbt_S);
	DefInit(p.sbt_UmNr9aRXe);
	DefInit(p.sbt_gHC);
	DefInit(p.sbt_k);
	DefInit(p.sbt_v);
}

template <> static inline int Compare<sbt_I>(const sbt_I &a, const sbt_I &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_9TE7V3V, b.sbt_9TE7V3V)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Cx1DWWzE8, b.sbt_Cx1DWWzE8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_HzgyVpn, b.sbt_HzgyVpn)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_IPR, b.sbt_IPR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_S, b.sbt_S)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UmNr9aRXe, b.sbt_UmNr9aRXe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gHC, b.sbt_gHC)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_k, b.sbt_k)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_v, b.sbt_v)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_I>(const sbt_I &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_9TE7V3V, pHasher);
	Hash(p.sbt_Cx1DWWzE8, pHasher);
	Hash(p.sbt_HzgyVpn, pHasher);
	Hash(p.sbt_IPR, pHasher);
	Hash(p.sbt_S, pHasher);
	Hash(p.sbt_UmNr9aRXe, pHasher);
	Hash(p.sbt_gHC, pHasher);
	Hash(p.sbt_k, pHasher);
	Hash(p.sbt_v, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_I>(sbt_I p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9TE7V3V", p.sbt_9TE7V3V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Cx1DWWzE8", p.sbt_Cx1DWWzE8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_HzgyVpn", p.sbt_HzgyVpn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_IPR", p.sbt_IPR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UmNr9aRXe", p.sbt_UmNr9aRXe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gHC", p.sbt_gHC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_I>(sbt_I &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_9TE7V3V", p.sbt_9TE7V3V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Cx1DWWzE8", p.sbt_Cx1DWWzE8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_HzgyVpn", p.sbt_HzgyVpn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_IPR", p.sbt_IPR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UmNr9aRXe", p.sbt_UmNr9aRXe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gHC", p.sbt_gHC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

