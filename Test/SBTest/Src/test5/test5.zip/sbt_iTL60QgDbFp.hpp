
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_f82QobRCyKhx4nRixtr.hpp"
#include "sbt_dkU.hpp"


class sbt_iTL60QgDbFp
{
public:

	CX::SB::Map<sbt_f82QobRCyKhx4nRixtr, sbt_dkU>::Type sbt_43yfgIXAo;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_iTL60QgDbFp &p)
{
	DefInit(p.sbt_43yfgIXAo);
}

template <> static inline int Compare<sbt_iTL60QgDbFp>(const sbt_iTL60QgDbFp &a, const sbt_iTL60QgDbFp &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_43yfgIXAo, b.sbt_43yfgIXAo)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_iTL60QgDbFp>(const sbt_iTL60QgDbFp &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_43yfgIXAo, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_iTL60QgDbFp>(sbt_iTL60QgDbFp p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_43yfgIXAo", p.sbt_43yfgIXAo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_iTL60QgDbFp>(sbt_iTL60QgDbFp &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (1 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 1 members");
	}
	if ((status = pDataReader->ReadMember("sbt_43yfgIXAo", p.sbt_43yfgIXAo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

