
#pragma once


#include "sbt_f82QobRCyKhx4nRixtr.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_z4bmN8STest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_f82QobRCyKhx4nRixtr &p)
{
	p.sbt_H8gIo = 16870813351894932732;
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	p.sbt_j2N4x6F = 0.216363;
}

static inline void RandInit(sbt_f82QobRCyKhx4nRixtr &p)
{
	p.sbt_H8gIo = CX::Util::RndGen::Get().GetUInt64();
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	{
		sbt_z4bmN8S k;

		TestInit(k);
		p.sbt_S.push_back(k);
	}
	p.sbt_j2N4x6F = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

