
#pragma once


#include "sbt_LytLr.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"
#include "sbt__FywnTest.hpp"
#include "sbt_AvrDhwJyr3qach0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_LytLr &p)
{
	p.sbt_AOLGO4P = 6533;
	TestInit(p.sbt_MTw1z8n1K);
	p.sbt_Sv5oIPJ3H = "1OQ'GuSMyE)cM#u=CgsW_1yGwU";
	p.sbt_dvLqj.push_back(L"=W1{O53}+Q/qm7me-q;1=q+m/[i1%3");
	p.sbt_dvLqj.push_back(L"1CmaqOQ=3?IcwK_G!9W-/7=%Q");
	p.sbt_dvLqj.push_back(L"YWyGGu--%3WcCMq5C");
	p.sbt_dvLqj.push_back(L"1aee+}3gG1{);1-c3AOoq?95;U;i3");
	p.sbt_dvLqj.push_back(L";[Qw/O5");
	TestInit(p.sbt_jVzcsz6);
	TestInit(p.sbt_n2GpII7);
	p.sbt_uz8.push_back(3053202923);
	p.sbt_uz8.push_back(462834869);
	p.sbt_uz8.push_back(2942298295);
	p.sbt_uz8.push_back(2580136109);
	p.sbt_uz8.push_back(830509967);
	p.sbt_uz8.push_back(4038210407);
	p.sbt_uz8.push_back(1886776764);
	p.sbt_uz8.push_back(3394983314);
	p.sbt_uz8.push_back(2098666462);
}

static inline void RandInit(sbt_LytLr &p)
{
	p.sbt_AOLGO4P = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_MTw1z8n1K);
	p.sbt_Sv5oIPJ3H = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_dvLqj.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_dvLqj.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_dvLqj.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	RandInit(p.sbt_jVzcsz6);
	RandInit(p.sbt_n2GpII7);
	p.sbt_uz8.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_uz8.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_uz8.push_back(CX::Util::RndGen::Get().GetUInt32());
}

}//namespace SB

}//namespace CX

