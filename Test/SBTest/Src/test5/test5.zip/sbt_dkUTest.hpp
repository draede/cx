
#pragma once


#include "sbt_dkU.hpp"
#include "CX/Util/RndGen.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_dkU &p)
{
	p.sbt_EICHC3FLr = 35923;
	p.sbt_ITUqr4G[true] = 53482;
	p.sbt_Lg_nOGTND[3933849122] = 6507662942283418338;
	p.sbt_Lg_nOGTND[2163306779] = 15170407473014152338;
	p.sbt_Lg_nOGTND[3338597305] = 12294345549233728358;
	p.sbt_Lg_nOGTND[3954119610] = 6649013286379595506;
	p.sbt_Lg_nOGTND[3245171430] = 14961415426404632650;
}

static inline void RandInit(sbt_dkU &p)
{
	p.sbt_EICHC3FLr = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_ITUqr4G[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_Lg_nOGTND[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetUInt64();
}

}//namespace SB

}//namespace CX

