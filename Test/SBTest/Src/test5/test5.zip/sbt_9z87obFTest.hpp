
#pragma once


#include "sbt_9z87obF.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_f82QobRCyKhx4nRixtrTest.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_9z87obF &p)
{
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
}

static inline void RandInit(sbt_9z87obF &p)
{
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_II_JKgw[k] = v;
	}
}

}//namespace SB

}//namespace CX

