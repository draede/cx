
#pragma once


#include "sbt_Ebu.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_cdxtwwTUWUe2lTest.hpp"
#include "sbt_NyxrJP4wOKC5rabTest.hpp"
#include "sbt_9aa_YuCiansA1WuTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Ebu &p)
{
	p.sbt_1xJ = 53449;
	TestInit(p.sbt_7Wg);
	p.sbt_F = 51;
	p.sbt_LBamP = true;
	TestInit(p.sbt_gmX);
	TestInit(p.sbt_oxp);
	p.sbt_w2Fou1z = 0.000723f;
}

static inline void RandInit(sbt_Ebu &p)
{
	p.sbt_1xJ = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_7Wg);
	p.sbt_F = CX::Util::RndGen::Get().GetInt8();
	p.sbt_LBamP = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_gmX);
	RandInit(p.sbt_oxp);
	p.sbt_w2Fou1z = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

