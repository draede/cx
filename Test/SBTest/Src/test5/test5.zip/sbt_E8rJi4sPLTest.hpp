
#pragma once


#include "sbt_E8rJi4sPL.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_9dYl7KuIf8m0FVGTest.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_E8rJi4sPL &p)
{
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	p.sbt_RqcfGEj = 0.627866;
	p.sbt_TES = -6710006319035353656;
	p.sbt_VU6_2Wo9q.push_back(L"");
	p.sbt_VU6_2Wo9q.push_back(L"5;M");
	p.sbt_VU6_2Wo9q.push_back(L"Sy3Q}GOGE}AK7--as=}s'-");
	p.sbt_VU6_2Wo9q.push_back(L"io[u#qk{oMUc");
	p.sbt_VU6_2Wo9q.push_back(L"k");
	p.sbt_VU6_2Wo9q.push_back(L"W9og)/E_mWqweiSuq7]eg/");
	p.sbt_VU6_2Wo9q.push_back(L"Y_SM=uM/#Um{aEimkuaGAkO");
	p.sbt_VU6_2Wo9q.push_back(L"_g=oK};/Yu/Su%geie");
	p.sbt_VU6_2Wo9q.push_back(L"SCM=!-5Ga;");
	TestInit(p.sbt_d);
}

static inline void RandInit(sbt_E8rJi4sPL &p)
{
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	{
		sbt_9dYl7KuIf8m0FVG k;

		TestInit(k);
		p.sbt_Ep4m2zz.push_back(k);
	}
	p.sbt_RqcfGEj = CX::Util::RndGen::Get().GetDouble();
	p.sbt_TES = CX::Util::RndGen::Get().GetInt64();
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_VU6_2Wo9q.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	RandInit(p.sbt_d);
}

}//namespace SB

}//namespace CX

