
#pragma once


#include "sbt_iTL60QgDbFp.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_f82QobRCyKhx4nRixtrTest.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_iTL60QgDbFp &p)
{
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		TestInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
}

static inline void RandInit(sbt_iTL60QgDbFp &p)
{
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_dkU v;

		RandInit(k);
		TestInit(v);
		p.sbt_43yfgIXAo[k] = v;
	}
}

}//namespace SB

}//namespace CX

