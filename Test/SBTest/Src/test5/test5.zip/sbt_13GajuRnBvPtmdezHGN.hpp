
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_NyxrJP4wOKC5rab.hpp"
#include "sbt_XpRGlsG8F1Eg9.hpp"
#include "sbt_UhyVfA0.hpp"


class sbt_13GajuRnBvPtmdezHGN
{
public:

	CX::Int16 sbt_1mTwqlm;
	CX::String sbt_A90Vp4k;
	sbt_NyxrJP4wOKC5rab sbt_GLQie3K;
	CX::SB::Map<CX::Double, CX::WString>::Type sbt_Kfs;
	sbt_XpRGlsG8F1Eg9 sbt_NtxfevG;
	sbt_UhyVfA0 sbt_TDsTNBD9d;
	CX::Int64 sbt_U49;
	CX::UInt32 sbt_u;
	CX::Double sbt_vBp2bUeH1;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_13GajuRnBvPtmdezHGN &p)
{
	DefInit(p.sbt_1mTwqlm);
	DefInit(p.sbt_A90Vp4k);
	DefInit(p.sbt_GLQie3K);
	DefInit(p.sbt_Kfs);
	DefInit(p.sbt_NtxfevG);
	DefInit(p.sbt_TDsTNBD9d);
	DefInit(p.sbt_U49);
	DefInit(p.sbt_u);
	DefInit(p.sbt_vBp2bUeH1);
}

template <> static inline int Compare<sbt_13GajuRnBvPtmdezHGN>(const sbt_13GajuRnBvPtmdezHGN &a, const sbt_13GajuRnBvPtmdezHGN &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1mTwqlm, b.sbt_1mTwqlm)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_A90Vp4k, b.sbt_A90Vp4k)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_GLQie3K, b.sbt_GLQie3K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Kfs, b.sbt_Kfs)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_NtxfevG, b.sbt_NtxfevG)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TDsTNBD9d, b.sbt_TDsTNBD9d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_U49, b.sbt_U49)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_u, b.sbt_u)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_vBp2bUeH1, b.sbt_vBp2bUeH1)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_13GajuRnBvPtmdezHGN>(const sbt_13GajuRnBvPtmdezHGN &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1mTwqlm, pHasher);
	Hash(p.sbt_A90Vp4k, pHasher);
	Hash(p.sbt_GLQie3K, pHasher);
	Hash(p.sbt_Kfs, pHasher);
	Hash(p.sbt_NtxfevG, pHasher);
	Hash(p.sbt_TDsTNBD9d, pHasher);
	Hash(p.sbt_U49, pHasher);
	Hash(p.sbt_u, pHasher);
	Hash(p.sbt_vBp2bUeH1, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_13GajuRnBvPtmdezHGN>(sbt_13GajuRnBvPtmdezHGN p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1mTwqlm", p.sbt_1mTwqlm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_A90Vp4k", p.sbt_A90Vp4k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_GLQie3K", p.sbt_GLQie3K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Kfs", p.sbt_Kfs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_NtxfevG", p.sbt_NtxfevG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TDsTNBD9d", p.sbt_TDsTNBD9d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_U49", p.sbt_U49)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_u", p.sbt_u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_vBp2bUeH1", p.sbt_vBp2bUeH1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_13GajuRnBvPtmdezHGN>(sbt_13GajuRnBvPtmdezHGN &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1mTwqlm", p.sbt_1mTwqlm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_A90Vp4k", p.sbt_A90Vp4k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_GLQie3K", p.sbt_GLQie3K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Kfs", p.sbt_Kfs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_NtxfevG", p.sbt_NtxfevG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TDsTNBD9d", p.sbt_TDsTNBD9d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_U49", p.sbt_U49)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_u", p.sbt_u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_vBp2bUeH1", p.sbt_vBp2bUeH1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

