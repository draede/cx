
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_D.hpp"
#include "sbt_13GajuRnBvPtmdezHGN.hpp"


class sbt_t
{
public:

	CX::SB::Vector<sbt_D>::Type sbt_7mTre;
	CX::SB::Vector<CX::Bool>::Type sbt_8UyDD;
	CX::Int8 sbt_ACMgL;
	CX::UInt16 sbt_WpCj_Yl;
	sbt_13GajuRnBvPtmdezHGN sbt_YnlXErVYp;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_t &p)
{
	DefInit(p.sbt_7mTre);
	DefInit(p.sbt_8UyDD);
	DefInit(p.sbt_ACMgL);
	DefInit(p.sbt_WpCj_Yl);
	DefInit(p.sbt_YnlXErVYp);
}

template <> static inline int Compare<sbt_t>(const sbt_t &a, const sbt_t &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_7mTre, b.sbt_7mTre)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_8UyDD, b.sbt_8UyDD)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ACMgL, b.sbt_ACMgL)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_WpCj_Yl, b.sbt_WpCj_Yl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YnlXErVYp, b.sbt_YnlXErVYp)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_t>(const sbt_t &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_7mTre, pHasher);
	Hash(p.sbt_8UyDD, pHasher);
	Hash(p.sbt_ACMgL, pHasher);
	Hash(p.sbt_WpCj_Yl, pHasher);
	Hash(p.sbt_YnlXErVYp, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_t>(sbt_t p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7mTre", p.sbt_7mTre)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8UyDD", p.sbt_8UyDD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ACMgL", p.sbt_ACMgL)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_WpCj_Yl", p.sbt_WpCj_Yl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YnlXErVYp", p.sbt_YnlXErVYp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_t>(sbt_t &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_7mTre", p.sbt_7mTre)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_8UyDD", p.sbt_8UyDD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ACMgL", p.sbt_ACMgL)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_WpCj_Yl", p.sbt_WpCj_Yl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YnlXErVYp", p.sbt_YnlXErVYp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

