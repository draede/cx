
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_E8rJi4sPL.hpp"
#include "sbt_SSrQa.hpp"
#include "sbt_l99Hbqs.hpp"
#include "sbt_XpRGlsG8F1Eg9.hpp"


class sbt_aIE04VC
{
public:

	CX::SB::Map<sbt_E8rJi4sPL, sbt_SSrQa>::Type sbt_Ld42sxYMa;
	CX::Int8 sbt_TBjmchS;
	sbt_l99Hbqs sbt_U;
	CX::SB::Vector<CX::UInt32>::Type sbt_j3b3ioo;
	CX::SB::Vector<CX::WString>::Type sbt_lNs;
	CX::UInt16 sbt_p;
	sbt_XpRGlsG8F1Eg9 sbt_xR6FM;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_aIE04VC &p)
{
	DefInit(p.sbt_Ld42sxYMa);
	DefInit(p.sbt_TBjmchS);
	DefInit(p.sbt_U);
	DefInit(p.sbt_j3b3ioo);
	DefInit(p.sbt_lNs);
	DefInit(p.sbt_p);
	DefInit(p.sbt_xR6FM);
}

template <> static inline int Compare<sbt_aIE04VC>(const sbt_aIE04VC &a, const sbt_aIE04VC &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Ld42sxYMa, b.sbt_Ld42sxYMa)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TBjmchS, b.sbt_TBjmchS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_U, b.sbt_U)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j3b3ioo, b.sbt_j3b3ioo)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_lNs, b.sbt_lNs)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_xR6FM, b.sbt_xR6FM)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_aIE04VC>(const sbt_aIE04VC &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Ld42sxYMa, pHasher);
	Hash(p.sbt_TBjmchS, pHasher);
	Hash(p.sbt_U, pHasher);
	Hash(p.sbt_j3b3ioo, pHasher);
	Hash(p.sbt_lNs, pHasher);
	Hash(p.sbt_p, pHasher);
	Hash(p.sbt_xR6FM, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_aIE04VC>(sbt_aIE04VC p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Ld42sxYMa", p.sbt_Ld42sxYMa)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TBjmchS", p.sbt_TBjmchS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j3b3ioo", p.sbt_j3b3ioo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_lNs", p.sbt_lNs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_xR6FM", p.sbt_xR6FM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_aIE04VC>(sbt_aIE04VC &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Ld42sxYMa", p.sbt_Ld42sxYMa)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TBjmchS", p.sbt_TBjmchS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j3b3ioo", p.sbt_j3b3ioo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_lNs", p.sbt_lNs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_xR6FM", p.sbt_xR6FM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

