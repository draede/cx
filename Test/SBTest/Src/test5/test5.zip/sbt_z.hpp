
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_dkU.hpp"
#include "sbt_cdxtwwTUWUe2l.hpp"
#include "sbt_9aa_YuCiansA1Wu.hpp"
#include "sbt_EGwE1Af.hpp"


class sbt_z
{
public:

	CX::SB::Map<sbt_dkU, sbt_cdxtwwTUWUe2l>::Type sbt_6vt;
	CX::SB::Map<CX::Int32, CX::Double>::Type sbt_P;
	CX::Float sbt_PeuBnet;
	CX::UInt64 sbt_RTMYhL2cP;
	sbt_9aa_YuCiansA1Wu sbt_XGqjd;
	sbt_EGwE1Af sbt_k;
	CX::Int32 sbt_kn1FI;
	CX::Int64 sbt_r;
	CX::SB::Map<CX::Float, CX::UInt8>::Type sbt_tgDbKmqUe;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_z &p)
{
	DefInit(p.sbt_6vt);
	DefInit(p.sbt_P);
	DefInit(p.sbt_PeuBnet);
	DefInit(p.sbt_RTMYhL2cP);
	DefInit(p.sbt_XGqjd);
	DefInit(p.sbt_k);
	DefInit(p.sbt_kn1FI);
	DefInit(p.sbt_r);
	DefInit(p.sbt_tgDbKmqUe);
}

template <> static inline int Compare<sbt_z>(const sbt_z &a, const sbt_z &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6vt, b.sbt_6vt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_P, b.sbt_P)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PeuBnet, b.sbt_PeuBnet)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_RTMYhL2cP, b.sbt_RTMYhL2cP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XGqjd, b.sbt_XGqjd)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_k, b.sbt_k)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_kn1FI, b.sbt_kn1FI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_r, b.sbt_r)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tgDbKmqUe, b.sbt_tgDbKmqUe)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_z>(const sbt_z &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6vt, pHasher);
	Hash(p.sbt_P, pHasher);
	Hash(p.sbt_PeuBnet, pHasher);
	Hash(p.sbt_RTMYhL2cP, pHasher);
	Hash(p.sbt_XGqjd, pHasher);
	Hash(p.sbt_k, pHasher);
	Hash(p.sbt_kn1FI, pHasher);
	Hash(p.sbt_r, pHasher);
	Hash(p.sbt_tgDbKmqUe, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_z>(sbt_z p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6vt", p.sbt_6vt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_P", p.sbt_P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PeuBnet", p.sbt_PeuBnet)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_RTMYhL2cP", p.sbt_RTMYhL2cP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XGqjd", p.sbt_XGqjd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_kn1FI", p.sbt_kn1FI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tgDbKmqUe", p.sbt_tgDbKmqUe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_z>(sbt_z &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6vt", p.sbt_6vt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_P", p.sbt_P)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PeuBnet", p.sbt_PeuBnet)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_RTMYhL2cP", p.sbt_RTMYhL2cP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XGqjd", p.sbt_XGqjd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_kn1FI", p.sbt_kn1FI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tgDbKmqUe", p.sbt_tgDbKmqUe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

