
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_cdxtwwTUWUe2l.hpp"
#include "sbt_NyxrJP4wOKC5rab.hpp"
#include "sbt_9aa_YuCiansA1Wu.hpp"


class sbt_Ebu
{
public:

	CX::UInt16 sbt_1xJ;
	sbt_cdxtwwTUWUe2l sbt_7Wg;
	CX::Int8 sbt_F;
	CX::Bool sbt_LBamP;
	sbt_NyxrJP4wOKC5rab sbt_gmX;
	sbt_9aa_YuCiansA1Wu sbt_oxp;
	CX::Float sbt_w2Fou1z;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Ebu &p)
{
	DefInit(p.sbt_1xJ);
	DefInit(p.sbt_7Wg);
	DefInit(p.sbt_F);
	DefInit(p.sbt_LBamP);
	DefInit(p.sbt_gmX);
	DefInit(p.sbt_oxp);
	DefInit(p.sbt_w2Fou1z);
}

template <> static inline int Compare<sbt_Ebu>(const sbt_Ebu &a, const sbt_Ebu &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1xJ, b.sbt_1xJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_7Wg, b.sbt_7Wg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F, b.sbt_F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LBamP, b.sbt_LBamP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gmX, b.sbt_gmX)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_oxp, b.sbt_oxp)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_w2Fou1z, b.sbt_w2Fou1z)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Ebu>(const sbt_Ebu &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1xJ, pHasher);
	Hash(p.sbt_7Wg, pHasher);
	Hash(p.sbt_F, pHasher);
	Hash(p.sbt_LBamP, pHasher);
	Hash(p.sbt_gmX, pHasher);
	Hash(p.sbt_oxp, pHasher);
	Hash(p.sbt_w2Fou1z, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Ebu>(sbt_Ebu p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1xJ", p.sbt_1xJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7Wg", p.sbt_7Wg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LBamP", p.sbt_LBamP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gmX", p.sbt_gmX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_oxp", p.sbt_oxp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_w2Fou1z", p.sbt_w2Fou1z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Ebu>(sbt_Ebu &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1xJ", p.sbt_1xJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_7Wg", p.sbt_7Wg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LBamP", p.sbt_LBamP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gmX", p.sbt_gmX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_oxp", p.sbt_oxp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_w2Fou1z", p.sbt_w2Fou1z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

