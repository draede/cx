
#pragma once


#include "CX/SB/Tester.hpp"
#include "CX/Print.hpp"
#include "sbt_13GajuRnBvPtmdezHGNTest.hpp"
#include "sbt_1pplnhNbya7orTest.hpp"
#include "sbt_5AsTest.hpp"
#include "sbt_5FjbRJXTest.hpp"
#include "sbt_8ft4kg2bXtvQtsjTest.hpp"
#include "sbt_9aa_YuCiansA1WuTest.hpp"
#include "sbt_9Ag3OVyhW21FxlyTest.hpp"
#include "sbt_9dYl7KuIf8m0FVGTest.hpp"
#include "sbt_9z87obFTest.hpp"
#include "sbt__FywnTest.hpp"
#include "sbt_aIE04VCTest.hpp"
#include "sbt_AvrDhwJyr3qach0Test.hpp"
#include "sbt_cdxtwwTUWUe2lTest.hpp"
#include "sbt_DTest.hpp"
#include "sbt_dkUTest.hpp"
#include "sbt_dqkBkTest.hpp"
#include "sbt_E8rJi4sPLTest.hpp"
#include "sbt_EbuTest.hpp"
#include "sbt_EGwE1AfTest.hpp"
#include "sbt_f82QobRCyKhx4nRixtrTest.hpp"
#include "sbt_FygTest.hpp"
#include "sbt_G20Test.hpp"
#include "sbt_ITest.hpp"
#include "sbt_iTL60QgDbFpTest.hpp"
#include "sbt_j34fWTest.hpp"
#include "sbt_l99HbqsTest.hpp"
#include "sbt_LytLrTest.hpp"
#include "sbt_NyxrJP4wOKC5rabTest.hpp"
#include "sbt_SqF1sTETest.hpp"
#include "sbt_SSrQaTest.hpp"
#include "sbt_SZyOjMczz_rIHTest.hpp"
#include "sbt_tTest.hpp"
#include "sbt_tWutlta9CMZTest.hpp"
#include "sbt_UhyVfA0Test.hpp"
#include "sbt_v8_4oQnksTest.hpp"
#include "sbt_XpRGlsG8F1Eg9Test.hpp"
#include "sbt_YRlXF96Test.hpp"
#include "sbt_zTest.hpp"
#include "sbt_z4bmN8STest.hpp"
#include "sbt_ziHWqp4Test.hpp"


void Run_Tests()
{
	CX::SB::StatsData trd;
	CX::SB::StatsData twd;
	CX::Size cAll = 0;
	CX::Size cOK = 0;
	CX::Status status;

	trd.Reset();
	twd.Reset();
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_13GajuRnBvPtmdezHGN>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_13GajuRnBvPtmdezHGN failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_1pplnhNbya7or>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_1pplnhNbya7or failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_5As>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_5As failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_5FjbRJX>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_5FjbRJX failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_8ft4kg2bXtvQtsj>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_8ft4kg2bXtvQtsj failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_9aa_YuCiansA1Wu>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_9aa_YuCiansA1Wu failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_9Ag3OVyhW21Fxly>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_9Ag3OVyhW21Fxly failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_9dYl7KuIf8m0FVG>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_9dYl7KuIf8m0FVG failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_9z87obF>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_9z87obF failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt__Fywn>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt__Fywn failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_aIE04VC>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_aIE04VC failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_AvrDhwJyr3qach0>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_AvrDhwJyr3qach0 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_cdxtwwTUWUe2l>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_cdxtwwTUWUe2l failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_D>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_D failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_dkU>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_dkU failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_dqkBk>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_dqkBk failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_E8rJi4sPL>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_E8rJi4sPL failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Ebu>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Ebu failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_EGwE1Af>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_EGwE1Af failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_f82QobRCyKhx4nRixtr>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_f82QobRCyKhx4nRixtr failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Fyg>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Fyg failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_G20>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_G20 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_I>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_I failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_iTL60QgDbFp>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_iTL60QgDbFp failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_j34fW>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_j34fW failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_l99Hbqs>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_l99Hbqs failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_LytLr>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_LytLr failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_NyxrJP4wOKC5rab>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_NyxrJP4wOKC5rab failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_SqF1sTE>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_SqF1sTE failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_SSrQa>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_SSrQa failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_SZyOjMczz_rIH>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_SZyOjMczz_rIH failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_t>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_t failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_tWutlta9CMZ>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_tWutlta9CMZ failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_UhyVfA0>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_UhyVfA0 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_v8_4oQnks>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_v8_4oQnks failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_XpRGlsG8F1Eg9>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_XpRGlsG8F1Eg9 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_YRlXF96>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_YRlXF96 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_z>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_z failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_z4bmN8S>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_z4bmN8S failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_ziHWqp4>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_ziHWqp4 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	CX::Print(stdout, "All tests : {1}\n", cAll);
	CX::Print(stdout, "OK tests  : {1}\n", cOK);
	CX::Print(stdout, "===== READ STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", trd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", trd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", trd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", trd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", trd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", trd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", trd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", trd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", trd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", trd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", trd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", trd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", trd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", trd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", trd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", trd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", trd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", trd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", trd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {:.3} MB\n", trd.m_cbTotalSize / 1048576.0);
	CX::Print(stdout, "===== WRITE STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", twd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", twd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", twd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", twd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", twd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", twd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", twd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", twd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", twd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", twd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", twd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", twd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", twd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", twd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", twd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", twd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", twd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", twd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", twd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {1:.3} MB\n", twd.m_cbTotalSize / 1048576.0);
}
