
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_I.hpp"
#include "sbt__Fywn.hpp"
#include "sbt_5As.hpp"
#include "sbt_Fyg.hpp"


class sbt_EGwE1Af
{
public:

	CX::Int64 sbt_dI4;
	CX::SB::Vector<sbt_I>::Type sbt_l;
	CX::SB::Map<sbt__Fywn, sbt_5As>::Type sbt_ljeVgOr;
	sbt_Fyg sbt_nQuwtiQ;
	CX::Bool sbt_rnOwu;
	CX::WString sbt_v;
	CX::Float sbt_yDX;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_EGwE1Af &p)
{
	DefInit(p.sbt_dI4);
	DefInit(p.sbt_l);
	DefInit(p.sbt_ljeVgOr);
	DefInit(p.sbt_nQuwtiQ);
	DefInit(p.sbt_rnOwu);
	DefInit(p.sbt_v);
	DefInit(p.sbt_yDX);
}

template <> static inline int Compare<sbt_EGwE1Af>(const sbt_EGwE1Af &a, const sbt_EGwE1Af &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_dI4, b.sbt_dI4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l, b.sbt_l)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ljeVgOr, b.sbt_ljeVgOr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nQuwtiQ, b.sbt_nQuwtiQ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rnOwu, b.sbt_rnOwu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_v, b.sbt_v)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yDX, b.sbt_yDX)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_EGwE1Af>(const sbt_EGwE1Af &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_dI4, pHasher);
	Hash(p.sbt_l, pHasher);
	Hash(p.sbt_ljeVgOr, pHasher);
	Hash(p.sbt_nQuwtiQ, pHasher);
	Hash(p.sbt_rnOwu, pHasher);
	Hash(p.sbt_v, pHasher);
	Hash(p.sbt_yDX, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_EGwE1Af>(sbt_EGwE1Af p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_dI4", p.sbt_dI4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ljeVgOr", p.sbt_ljeVgOr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nQuwtiQ", p.sbt_nQuwtiQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rnOwu", p.sbt_rnOwu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yDX", p.sbt_yDX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_EGwE1Af>(sbt_EGwE1Af &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_dI4", p.sbt_dI4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ljeVgOr", p.sbt_ljeVgOr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nQuwtiQ", p.sbt_nQuwtiQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rnOwu", p.sbt_rnOwu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yDX", p.sbt_yDX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

