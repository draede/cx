
#pragma once


#include "sbt_5As.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_5As &p)
{
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
}

static inline void RandInit(sbt_5As &p)
{
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_ufanu.push_back(k);
	}
}

}//namespace SB

}//namespace CX

