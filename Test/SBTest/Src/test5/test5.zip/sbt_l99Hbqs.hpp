
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_z4bmN8S.hpp"
#include "sbt_ziHWqp4.hpp"
#include "sbt_dkU.hpp"


class sbt_l99Hbqs
{
public:

	sbt_z4bmN8S sbt_4vf;
	sbt_ziHWqp4 sbt_82C74jFOi;
	CX::Bool sbt_8ZRrkau;
	sbt_dkU sbt_EMw;
	CX::WString sbt__;
	CX::WString sbt_jaiTdAf;
	CX::UInt32 sbt_l_4OY;
	CX::SB::Map<CX::Bool, CX::Int16>::Type sbt_rQhg_nw;
	CX::SB::Vector<CX::Bool>::Type sbt_yNM0g;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_l99Hbqs &p)
{
	DefInit(p.sbt_4vf);
	DefInit(p.sbt_82C74jFOi);
	DefInit(p.sbt_8ZRrkau);
	DefInit(p.sbt_EMw);
	DefInit(p.sbt__);
	DefInit(p.sbt_jaiTdAf);
	DefInit(p.sbt_l_4OY);
	DefInit(p.sbt_rQhg_nw);
	DefInit(p.sbt_yNM0g);
}

template <> static inline int Compare<sbt_l99Hbqs>(const sbt_l99Hbqs &a, const sbt_l99Hbqs &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4vf, b.sbt_4vf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_82C74jFOi, b.sbt_82C74jFOi)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_8ZRrkau, b.sbt_8ZRrkau)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EMw, b.sbt_EMw)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__, b.sbt__)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jaiTdAf, b.sbt_jaiTdAf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l_4OY, b.sbt_l_4OY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rQhg_nw, b.sbt_rQhg_nw)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yNM0g, b.sbt_yNM0g)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_l99Hbqs>(const sbt_l99Hbqs &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4vf, pHasher);
	Hash(p.sbt_82C74jFOi, pHasher);
	Hash(p.sbt_8ZRrkau, pHasher);
	Hash(p.sbt_EMw, pHasher);
	Hash(p.sbt__, pHasher);
	Hash(p.sbt_jaiTdAf, pHasher);
	Hash(p.sbt_l_4OY, pHasher);
	Hash(p.sbt_rQhg_nw, pHasher);
	Hash(p.sbt_yNM0g, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_l99Hbqs>(sbt_l99Hbqs p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4vf", p.sbt_4vf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_82C74jFOi", p.sbt_82C74jFOi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8ZRrkau", p.sbt_8ZRrkau)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EMw", p.sbt_EMw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jaiTdAf", p.sbt_jaiTdAf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l_4OY", p.sbt_l_4OY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rQhg_nw", p.sbt_rQhg_nw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yNM0g", p.sbt_yNM0g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_l99Hbqs>(sbt_l99Hbqs &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4vf", p.sbt_4vf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_82C74jFOi", p.sbt_82C74jFOi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_8ZRrkau", p.sbt_8ZRrkau)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EMw", p.sbt_EMw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jaiTdAf", p.sbt_jaiTdAf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l_4OY", p.sbt_l_4OY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rQhg_nw", p.sbt_rQhg_nw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yNM0g", p.sbt_yNM0g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

