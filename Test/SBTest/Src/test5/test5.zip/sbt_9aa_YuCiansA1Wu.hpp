
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt__Fywn.hpp"
#include "sbt_LytLr.hpp"
#include "sbt_z4bmN8S.hpp"
#include "sbt_I.hpp"


class sbt_9aa_YuCiansA1Wu
{
public:

	CX::UInt32 sbt_1vVTEq4;
	CX::UInt16 sbt_3Wu;
	CX::SB::Map<sbt__Fywn, sbt_LytLr>::Type sbt_9qJ3yNOR7;
	CX::SB::Vector<CX::Bool>::Type sbt_EkION;
	sbt_z4bmN8S sbt_I2505TYur;
	CX::SB::Vector<CX::Int8>::Type sbt_dwwKF;
	CX::Int16 sbt_kRX;
	sbt_I sbt_l;
	CX::UInt16 sbt_rGoY_mP;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_9aa_YuCiansA1Wu &p)
{
	DefInit(p.sbt_1vVTEq4);
	DefInit(p.sbt_3Wu);
	DefInit(p.sbt_9qJ3yNOR7);
	DefInit(p.sbt_EkION);
	DefInit(p.sbt_I2505TYur);
	DefInit(p.sbt_dwwKF);
	DefInit(p.sbt_kRX);
	DefInit(p.sbt_l);
	DefInit(p.sbt_rGoY_mP);
}

template <> static inline int Compare<sbt_9aa_YuCiansA1Wu>(const sbt_9aa_YuCiansA1Wu &a, const sbt_9aa_YuCiansA1Wu &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1vVTEq4, b.sbt_1vVTEq4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_3Wu, b.sbt_3Wu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_9qJ3yNOR7, b.sbt_9qJ3yNOR7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EkION, b.sbt_EkION)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_I2505TYur, b.sbt_I2505TYur)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_dwwKF, b.sbt_dwwKF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_kRX, b.sbt_kRX)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l, b.sbt_l)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rGoY_mP, b.sbt_rGoY_mP)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_9aa_YuCiansA1Wu>(const sbt_9aa_YuCiansA1Wu &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1vVTEq4, pHasher);
	Hash(p.sbt_3Wu, pHasher);
	Hash(p.sbt_9qJ3yNOR7, pHasher);
	Hash(p.sbt_EkION, pHasher);
	Hash(p.sbt_I2505TYur, pHasher);
	Hash(p.sbt_dwwKF, pHasher);
	Hash(p.sbt_kRX, pHasher);
	Hash(p.sbt_l, pHasher);
	Hash(p.sbt_rGoY_mP, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_9aa_YuCiansA1Wu>(sbt_9aa_YuCiansA1Wu p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1vVTEq4", p.sbt_1vVTEq4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3Wu", p.sbt_3Wu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9qJ3yNOR7", p.sbt_9qJ3yNOR7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EkION", p.sbt_EkION)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_I2505TYur", p.sbt_I2505TYur)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_dwwKF", p.sbt_dwwKF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_kRX", p.sbt_kRX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rGoY_mP", p.sbt_rGoY_mP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_9aa_YuCiansA1Wu>(sbt_9aa_YuCiansA1Wu &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1vVTEq4", p.sbt_1vVTEq4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_3Wu", p.sbt_3Wu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_9qJ3yNOR7", p.sbt_9qJ3yNOR7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EkION", p.sbt_EkION)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_I2505TYur", p.sbt_I2505TYur)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_dwwKF", p.sbt_dwwKF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_kRX", p.sbt_kRX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rGoY_mP", p.sbt_rGoY_mP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

