
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_9dYl7KuIf8m0FVG.hpp"
#include "sbt_dkU.hpp"


class sbt_E8rJi4sPL
{
public:

	CX::SB::Vector<sbt_9dYl7KuIf8m0FVG>::Type sbt_Ep4m2zz;
	CX::Double sbt_RqcfGEj;
	CX::Int64 sbt_TES;
	CX::SB::Vector<CX::WString>::Type sbt_VU6_2Wo9q;
	sbt_dkU sbt_d;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_E8rJi4sPL &p)
{
	DefInit(p.sbt_Ep4m2zz);
	DefInit(p.sbt_RqcfGEj);
	DefInit(p.sbt_TES);
	DefInit(p.sbt_VU6_2Wo9q);
	DefInit(p.sbt_d);
}

template <> static inline int Compare<sbt_E8rJi4sPL>(const sbt_E8rJi4sPL &a, const sbt_E8rJi4sPL &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Ep4m2zz, b.sbt_Ep4m2zz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_RqcfGEj, b.sbt_RqcfGEj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TES, b.sbt_TES)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VU6_2Wo9q, b.sbt_VU6_2Wo9q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_d, b.sbt_d)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_E8rJi4sPL>(const sbt_E8rJi4sPL &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Ep4m2zz, pHasher);
	Hash(p.sbt_RqcfGEj, pHasher);
	Hash(p.sbt_TES, pHasher);
	Hash(p.sbt_VU6_2Wo9q, pHasher);
	Hash(p.sbt_d, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_E8rJi4sPL>(sbt_E8rJi4sPL p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Ep4m2zz", p.sbt_Ep4m2zz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_RqcfGEj", p.sbt_RqcfGEj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TES", p.sbt_TES)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VU6_2Wo9q", p.sbt_VU6_2Wo9q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_E8rJi4sPL>(sbt_E8rJi4sPL &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Ep4m2zz", p.sbt_Ep4m2zz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_RqcfGEj", p.sbt_RqcfGEj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TES", p.sbt_TES)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VU6_2Wo9q", p.sbt_VU6_2Wo9q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

