
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_iTL60QgDbFp.hpp"
#include "sbt_E8rJi4sPL.hpp"
#include "sbt_9aa_YuCiansA1Wu.hpp"


class sbt_SSrQa
{
public:

	CX::Int32 sbt_8;
	CX::UInt64 sbt_DpN;
	sbt_iTL60QgDbFp sbt_MDXCp;
	CX::Int32 sbt_X;
	sbt_E8rJi4sPL sbt_XBYW14bZt;
	CX::Int64 sbt__2O;
	CX::UInt16 sbt_bHw5TUn;
	sbt_9aa_YuCiansA1Wu sbt_mNIqCuQ;
	CX::Double sbt_o;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_SSrQa &p)
{
	DefInit(p.sbt_8);
	DefInit(p.sbt_DpN);
	DefInit(p.sbt_MDXCp);
	DefInit(p.sbt_X);
	DefInit(p.sbt_XBYW14bZt);
	DefInit(p.sbt__2O);
	DefInit(p.sbt_bHw5TUn);
	DefInit(p.sbt_mNIqCuQ);
	DefInit(p.sbt_o);
}

template <> static inline int Compare<sbt_SSrQa>(const sbt_SSrQa &a, const sbt_SSrQa &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8, b.sbt_8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_DpN, b.sbt_DpN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_MDXCp, b.sbt_MDXCp)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X, b.sbt_X)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XBYW14bZt, b.sbt_XBYW14bZt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__2O, b.sbt__2O)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bHw5TUn, b.sbt_bHw5TUn)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_mNIqCuQ, b.sbt_mNIqCuQ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_o, b.sbt_o)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_SSrQa>(const sbt_SSrQa &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8, pHasher);
	Hash(p.sbt_DpN, pHasher);
	Hash(p.sbt_MDXCp, pHasher);
	Hash(p.sbt_X, pHasher);
	Hash(p.sbt_XBYW14bZt, pHasher);
	Hash(p.sbt__2O, pHasher);
	Hash(p.sbt_bHw5TUn, pHasher);
	Hash(p.sbt_mNIqCuQ, pHasher);
	Hash(p.sbt_o, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_SSrQa>(sbt_SSrQa p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DpN", p.sbt_DpN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_MDXCp", p.sbt_MDXCp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X", p.sbt_X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XBYW14bZt", p.sbt_XBYW14bZt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__2O", p.sbt__2O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bHw5TUn", p.sbt_bHw5TUn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_mNIqCuQ", p.sbt_mNIqCuQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_o", p.sbt_o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_SSrQa>(sbt_SSrQa &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_DpN", p.sbt_DpN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_MDXCp", p.sbt_MDXCp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X", p.sbt_X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XBYW14bZt", p.sbt_XBYW14bZt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__2O", p.sbt__2O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bHw5TUn", p.sbt_bHw5TUn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_mNIqCuQ", p.sbt_mNIqCuQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_o", p.sbt_o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

