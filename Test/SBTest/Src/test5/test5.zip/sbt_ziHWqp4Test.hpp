
#pragma once


#include "sbt_ziHWqp4.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_ziHWqp4 &p)
{
	TestInit(p.sbt_3Ey);
	TestInit(p.sbt_5BYGb);
	p.sbt_7eEdsbVnI = 572822416;
	p.sbt_IkKMLDTfw = -3647783584079483620;
	p.sbt_M1BTEvl = -650423107508534060;
	p.sbt_m.push_back(0.783050);
	p.sbt_m.push_back(0.844318);
	p.sbt_m.push_back(0.350465);
	p.sbt_m.push_back(0.043817);
	p.sbt_m.push_back(0.508042);
	p.sbt_m.push_back(0.588038);
	p.sbt_m.push_back(0.191436);
	TestInit(p.sbt_xuaxqkg);
}

static inline void RandInit(sbt_ziHWqp4 &p)
{
	RandInit(p.sbt_3Ey);
	RandInit(p.sbt_5BYGb);
	p.sbt_7eEdsbVnI = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_IkKMLDTfw = CX::Util::RndGen::Get().GetInt64();
	p.sbt_M1BTEvl = CX::Util::RndGen::Get().GetInt64();
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_m.push_back(CX::Util::RndGen::Get().GetDouble());
	RandInit(p.sbt_xuaxqkg);
}

}//namespace SB

}//namespace CX

