
#pragma once


#include "sbt_I.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_z4bmN8STest.hpp"
#include "sbt_UhyVfA0Test.hpp"
#include "sbt_cdxtwwTUWUe2lTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_I &p)
{
	p.sbt_9TE7V3V = 0.480419;
	p.sbt_Cx1DWWzE8[false] = L"q7GyiqcM_1_)9A=";
	p.sbt_Cx1DWWzE8[true] = L"C7g=7?M'Ukg1W-{)Qw}]]#]si;cy'";
	p.sbt_Cx1DWWzE8[true] = L"+%Y/1auYCQWEE%MGs'A";
	p.sbt_Cx1DWWzE8[true] = L"";
	p.sbt_Cx1DWWzE8[false] = L"am+-31)a;M7K_[skkIEu";
	p.sbt_Cx1DWWzE8[false] = L"S]I1-";
	p.sbt_Cx1DWWzE8[true] = L"{QU9m";
	TestInit(p.sbt_HzgyVpn);
	p.sbt_IPR = 2288397408076538578;
	p.sbt_S = 26659;
	TestInit(p.sbt_UmNr9aRXe);
	TestInit(p.sbt_gHC);
	p.sbt_k = -4697485639869186764;
	p.sbt_v = 0.884759;
}

static inline void RandInit(sbt_I &p)
{
	p.sbt_9TE7V3V = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Cx1DWWzE8[CX::Util::RndGen::Get().GetBool()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Cx1DWWzE8[CX::Util::RndGen::Get().GetBool()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Cx1DWWzE8[CX::Util::RndGen::Get().GetBool()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Cx1DWWzE8[CX::Util::RndGen::Get().GetBool()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Cx1DWWzE8[CX::Util::RndGen::Get().GetBool()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_HzgyVpn);
	p.sbt_IPR = CX::Util::RndGen::Get().GetInt64();
	p.sbt_S = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_UmNr9aRXe);
	RandInit(p.sbt_gHC);
	p.sbt_k = CX::Util::RndGen::Get().GetInt64();
	p.sbt_v = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

