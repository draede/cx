
#pragma once


#include "sbt__Fywn.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_9z87obFTest.hpp"
#include "sbt_v8_4oQnksTest.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt__Fywn &p)
{
	p.sbt_3b7 = -56;
	p.sbt_V = L"y+_oWAOC[A?[9]";
	p.sbt_XxGKDpnPw = 1942259111;
	p.sbt_ZEinI = true;
	TestInit(p.sbt_bMHAWScei);
	p.sbt_r7U20DNVY = L"yUmAo+qiOQ])YAMq?OUSM[ysW=";
	p.sbt_uHee58Qa9[false] = 202;
	p.sbt_uHee58Qa9[false] = 198;
	p.sbt_uHee58Qa9[false] = 104;
	p.sbt_uHee58Qa9[false] = 152;
	p.sbt_uHee58Qa9[false] = 200;
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_ycxjO6UxF.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_ycxjO6UxF.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_ycxjO6UxF.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_ycxjO6UxF.push_back(k);
	}
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_ycxjO6UxF.push_back(k);
	}
	TestInit(p.sbt_yea);
}

static inline void RandInit(sbt__Fywn &p)
{
	p.sbt_3b7 = CX::Util::RndGen::Get().GetInt8();
	p.sbt_V = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_XxGKDpnPw = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_ZEinI = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_bMHAWScei);
	p.sbt_r7U20DNVY = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_uHee58Qa9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_uHee58Qa9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_uHee58Qa9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_uHee58Qa9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_uHee58Qa9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetUInt8();
	{
		sbt_v8_4oQnks k;

		TestInit(k);
		p.sbt_ycxjO6UxF.push_back(k);
	}
	RandInit(p.sbt_yea);
}

}//namespace SB

}//namespace CX

