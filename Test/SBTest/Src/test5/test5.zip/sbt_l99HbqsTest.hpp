
#pragma once


#include "sbt_l99Hbqs.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_z4bmN8STest.hpp"
#include "sbt_ziHWqp4Test.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_l99Hbqs &p)
{
	TestInit(p.sbt_4vf);
	TestInit(p.sbt_82C74jFOi);
	p.sbt_8ZRrkau = false;
	TestInit(p.sbt_EMw);
	p.sbt__ = L"";
	p.sbt_jaiTdAf = L"QGG]{%km%si%7yI";
	p.sbt_l_4OY = 4004143850;
	p.sbt_rQhg_nw[true] = -26979;
	p.sbt_yNM0g.push_back(true);
	p.sbt_yNM0g.push_back(true);
	p.sbt_yNM0g.push_back(true);
	p.sbt_yNM0g.push_back(true);
	p.sbt_yNM0g.push_back(false);
	p.sbt_yNM0g.push_back(true);
	p.sbt_yNM0g.push_back(true);
	p.sbt_yNM0g.push_back(false);
	p.sbt_yNM0g.push_back(false);
}

static inline void RandInit(sbt_l99Hbqs &p)
{
	RandInit(p.sbt_4vf);
	RandInit(p.sbt_82C74jFOi);
	p.sbt_8ZRrkau = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_EMw);
	p.sbt__ = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_jaiTdAf = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_l_4OY = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_rQhg_nw[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_rQhg_nw[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_rQhg_nw[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_rQhg_nw[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_rQhg_nw[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_yNM0g.push_back(CX::Util::RndGen::Get().GetBool());
}

}//namespace SB

}//namespace CX

