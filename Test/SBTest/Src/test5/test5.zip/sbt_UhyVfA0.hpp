
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_ziHWqp4.hpp"
#include "sbt_9z87obF.hpp"


class sbt_UhyVfA0
{
public:

	CX::Bool sbt_8k8;
	sbt_ziHWqp4 sbt_BYHQc;
	CX::Bool sbt_FVaXF3D;
	CX::SB::Vector<CX::Double>::Type sbt_Nz5bschor;
	sbt_ziHWqp4 sbt_Q_1;
	CX::Int8 sbt_V3hXr;
	CX::Bool sbt_jEZ;
	sbt_9z87obF sbt_krazS;
	CX::UInt32 sbt_or_jr;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_UhyVfA0 &p)
{
	DefInit(p.sbt_8k8);
	DefInit(p.sbt_BYHQc);
	DefInit(p.sbt_FVaXF3D);
	DefInit(p.sbt_Nz5bschor);
	DefInit(p.sbt_Q_1);
	DefInit(p.sbt_V3hXr);
	DefInit(p.sbt_jEZ);
	DefInit(p.sbt_krazS);
	DefInit(p.sbt_or_jr);
}

template <> static inline int Compare<sbt_UhyVfA0>(const sbt_UhyVfA0 &a, const sbt_UhyVfA0 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8k8, b.sbt_8k8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_BYHQc, b.sbt_BYHQc)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_FVaXF3D, b.sbt_FVaXF3D)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Nz5bschor, b.sbt_Nz5bschor)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Q_1, b.sbt_Q_1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_V3hXr, b.sbt_V3hXr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jEZ, b.sbt_jEZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_krazS, b.sbt_krazS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_or_jr, b.sbt_or_jr)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_UhyVfA0>(const sbt_UhyVfA0 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8k8, pHasher);
	Hash(p.sbt_BYHQc, pHasher);
	Hash(p.sbt_FVaXF3D, pHasher);
	Hash(p.sbt_Nz5bschor, pHasher);
	Hash(p.sbt_Q_1, pHasher);
	Hash(p.sbt_V3hXr, pHasher);
	Hash(p.sbt_jEZ, pHasher);
	Hash(p.sbt_krazS, pHasher);
	Hash(p.sbt_or_jr, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_UhyVfA0>(sbt_UhyVfA0 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8k8", p.sbt_8k8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BYHQc", p.sbt_BYHQc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_FVaXF3D", p.sbt_FVaXF3D)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Nz5bschor", p.sbt_Nz5bschor)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Q_1", p.sbt_Q_1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_V3hXr", p.sbt_V3hXr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jEZ", p.sbt_jEZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_krazS", p.sbt_krazS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_or_jr", p.sbt_or_jr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_UhyVfA0>(sbt_UhyVfA0 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8k8", p.sbt_8k8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_BYHQc", p.sbt_BYHQc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_FVaXF3D", p.sbt_FVaXF3D)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Nz5bschor", p.sbt_Nz5bschor)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Q_1", p.sbt_Q_1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_V3hXr", p.sbt_V3hXr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jEZ", p.sbt_jEZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_krazS", p.sbt_krazS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_or_jr", p.sbt_or_jr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

