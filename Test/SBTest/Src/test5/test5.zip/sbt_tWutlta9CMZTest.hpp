
#pragma once


#include "sbt_tWutlta9CMZ.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_tWutlta9CMZ &p)
{
	TestInit(p.sbt_O_Xqt);
}

static inline void RandInit(sbt_tWutlta9CMZ &p)
{
	RandInit(p.sbt_O_Xqt);
}

}//namespace SB

}//namespace CX

