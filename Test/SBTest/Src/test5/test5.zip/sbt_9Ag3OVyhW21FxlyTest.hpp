
#pragma once


#include "sbt_9Ag3OVyhW21Fxly.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_f82QobRCyKhx4nRixtrTest.hpp"
#include "sbt_UhyVfA0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_9Ag3OVyhW21Fxly &p)
{
	p.sbt_0zSKO = 0.569782;
	TestInit(p.sbt_1);
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	p.sbt_9 = 60432;
	TestInit(p.sbt_POvBt);
	p.sbt_Sn9.push_back(0.962557f);
	p.sbt_Sn9.push_back(0.652559f);
	p.sbt_Sn9.push_back(0.504362f);
	p.sbt_X7r63[25455] = -9660;
	p.sbt_X7r63[12711] = -12674;
	p.sbt_X7r63[15580] = 12584;
	p.sbt_X7r63[7780] = -9127;
	p.sbt_X7r63[34069] = -23886;
	p.sbt_X7r63[36058] = -31074;
	p.sbt_X7r63[36578] = -10447;
	p.sbt_a = -875810932;
	p.sbt_amOtL = L"?Y1GCSygwo1{Q5w=";
}

static inline void RandInit(sbt_9Ag3OVyhW21Fxly &p)
{
	p.sbt_0zSKO = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_1);
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;

		TestInit(k);
		p.sbt_47npdugCs.push_back(k);
	}
	p.sbt_9 = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_POvBt);
	p.sbt_Sn9.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_X7r63[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_a = CX::Util::RndGen::Get().GetInt32();
	p.sbt_amOtL = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

