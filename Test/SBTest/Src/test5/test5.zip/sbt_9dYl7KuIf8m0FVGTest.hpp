
#pragma once


#include "sbt_9dYl7KuIf8m0FVG.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dkUTest.hpp"
#include "sbt_l99HbqsTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_9dYl7KuIf8m0FVG &p)
{
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	p.sbt_LdwIJ = 2036301516;
	p.sbt_RoOAR7JNp = 27681;
	p.sbt_Y = 3995254765352789962;
	TestInit(p.sbt_w5S);
}

static inline void RandInit(sbt_9dYl7KuIf8m0FVG &p)
{
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	{
		sbt_dkU k;

		TestInit(k);
		p.sbt_9DmETDo.push_back(k);
	}
	p.sbt_LdwIJ = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_RoOAR7JNp = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_Y = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_w5S);
}

}//namespace SB

}//namespace CX

