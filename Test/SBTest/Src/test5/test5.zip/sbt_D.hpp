
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_9aa_YuCiansA1Wu.hpp"


class sbt_D
{
public:

	CX::Int8 sbt_10DxM;
	sbt_9aa_YuCiansA1Wu sbt_iXM;
	CX::Int32 sbt_zhqn3ZbyO;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_D &p)
{
	DefInit(p.sbt_10DxM);
	DefInit(p.sbt_iXM);
	DefInit(p.sbt_zhqn3ZbyO);
}

template <> static inline int Compare<sbt_D>(const sbt_D &a, const sbt_D &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_10DxM, b.sbt_10DxM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iXM, b.sbt_iXM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zhqn3ZbyO, b.sbt_zhqn3ZbyO)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_D>(const sbt_D &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_10DxM, pHasher);
	Hash(p.sbt_iXM, pHasher);
	Hash(p.sbt_zhqn3ZbyO, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_D>(sbt_D p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_10DxM", p.sbt_10DxM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iXM", p.sbt_iXM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zhqn3ZbyO", p.sbt_zhqn3ZbyO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_D>(sbt_D &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_10DxM", p.sbt_10DxM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iXM", p.sbt_iXM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zhqn3ZbyO", p.sbt_zhqn3ZbyO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

