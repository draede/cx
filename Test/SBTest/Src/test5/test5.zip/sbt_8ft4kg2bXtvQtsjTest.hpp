
#pragma once


#include "sbt_8ft4kg2bXtvQtsj.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_AvrDhwJyr3qach0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_8ft4kg2bXtvQtsj &p)
{
	TestInit(p.sbt_jaNrM);
}

static inline void RandInit(sbt_8ft4kg2bXtvQtsj &p)
{
	RandInit(p.sbt_jaNrM);
}

}//namespace SB

}//namespace CX

