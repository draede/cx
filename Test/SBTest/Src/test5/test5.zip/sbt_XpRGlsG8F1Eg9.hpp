
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_ziHWqp4.hpp"
#include "sbt_AvrDhwJyr3qach0.hpp"


class sbt_XpRGlsG8F1Eg9
{
public:

	CX::Bool sbt_6;
	sbt_ziHWqp4 sbt_Bxp;
	sbt_AvrDhwJyr3qach0 sbt_EFg;
	sbt_ziHWqp4 sbt_Fldq1;
	CX::UInt8 sbt_WKwzepT;
	CX::Bool sbt_i;
	CX::Double sbt_zHkPhuMed;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_XpRGlsG8F1Eg9 &p)
{
	DefInit(p.sbt_6);
	DefInit(p.sbt_Bxp);
	DefInit(p.sbt_EFg);
	DefInit(p.sbt_Fldq1);
	DefInit(p.sbt_WKwzepT);
	DefInit(p.sbt_i);
	DefInit(p.sbt_zHkPhuMed);
}

template <> static inline int Compare<sbt_XpRGlsG8F1Eg9>(const sbt_XpRGlsG8F1Eg9 &a, const sbt_XpRGlsG8F1Eg9 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6, b.sbt_6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Bxp, b.sbt_Bxp)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EFg, b.sbt_EFg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Fldq1, b.sbt_Fldq1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_WKwzepT, b.sbt_WKwzepT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_i, b.sbt_i)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zHkPhuMed, b.sbt_zHkPhuMed)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_XpRGlsG8F1Eg9>(const sbt_XpRGlsG8F1Eg9 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6, pHasher);
	Hash(p.sbt_Bxp, pHasher);
	Hash(p.sbt_EFg, pHasher);
	Hash(p.sbt_Fldq1, pHasher);
	Hash(p.sbt_WKwzepT, pHasher);
	Hash(p.sbt_i, pHasher);
	Hash(p.sbt_zHkPhuMed, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_XpRGlsG8F1Eg9>(sbt_XpRGlsG8F1Eg9 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6", p.sbt_6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Bxp", p.sbt_Bxp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EFg", p.sbt_EFg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Fldq1", p.sbt_Fldq1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_WKwzepT", p.sbt_WKwzepT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_i", p.sbt_i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zHkPhuMed", p.sbt_zHkPhuMed)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_XpRGlsG8F1Eg9>(sbt_XpRGlsG8F1Eg9 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6", p.sbt_6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Bxp", p.sbt_Bxp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EFg", p.sbt_EFg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Fldq1", p.sbt_Fldq1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_WKwzepT", p.sbt_WKwzepT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_i", p.sbt_i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zHkPhuMed", p.sbt_zHkPhuMed)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

