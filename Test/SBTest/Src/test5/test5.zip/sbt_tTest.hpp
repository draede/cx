
#pragma once


#include "sbt_t.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_DTest.hpp"
#include "sbt_13GajuRnBvPtmdezHGNTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_t &p)
{
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	p.sbt_8UyDD.push_back(false);
	p.sbt_ACMgL = 40;
	p.sbt_WpCj_Yl = 20203;
	TestInit(p.sbt_YnlXErVYp);
}

static inline void RandInit(sbt_t &p)
{
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	{
		sbt_D k;

		TestInit(k);
		p.sbt_7mTre.push_back(k);
	}
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_8UyDD.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_ACMgL = CX::Util::RndGen::Get().GetInt8();
	p.sbt_WpCj_Yl = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_YnlXErVYp);
}

}//namespace SB

}//namespace CX

