
#pragma once


#include "sbt_XpRGlsG8F1Eg9.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ziHWqp4Test.hpp"
#include "sbt_AvrDhwJyr3qach0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_XpRGlsG8F1Eg9 &p)
{
	p.sbt_6 = true;
	TestInit(p.sbt_Bxp);
	TestInit(p.sbt_EFg);
	TestInit(p.sbt_Fldq1);
	p.sbt_WKwzepT = 217;
	p.sbt_i = false;
	p.sbt_zHkPhuMed = 0.316088;
}

static inline void RandInit(sbt_XpRGlsG8F1Eg9 &p)
{
	p.sbt_6 = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_Bxp);
	RandInit(p.sbt_EFg);
	RandInit(p.sbt_Fldq1);
	p.sbt_WKwzepT = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_i = CX::Util::RndGen::Get().GetBool();
	p.sbt_zHkPhuMed = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

