
#pragma once


#include "sbt_G20.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dqkBkTest.hpp"
#include "sbt_AvrDhwJyr3qach0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_G20 &p)
{
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		TestInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
}

static inline void RandInit(sbt_G20 &p)
{
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		RandInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		RandInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		RandInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		RandInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
	{
		sbt_dqkBk k;
		sbt_AvrDhwJyr3qach0 v;

		RandInit(k);
		TestInit(v);
		p.sbt_Py5[k] = v;
	}
}

}//namespace SB

}//namespace CX

