
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_dkU.hpp"


class sbt_ziHWqp4
{
public:

	sbt_dkU sbt_3Ey;
	sbt_dkU sbt_5BYGb;
	CX::UInt32 sbt_7eEdsbVnI;
	CX::Int64 sbt_IkKMLDTfw;
	CX::Int64 sbt_M1BTEvl;
	CX::SB::Vector<CX::Double>::Type sbt_m;
	sbt_dkU sbt_xuaxqkg;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_ziHWqp4 &p)
{
	DefInit(p.sbt_3Ey);
	DefInit(p.sbt_5BYGb);
	DefInit(p.sbt_7eEdsbVnI);
	DefInit(p.sbt_IkKMLDTfw);
	DefInit(p.sbt_M1BTEvl);
	DefInit(p.sbt_m);
	DefInit(p.sbt_xuaxqkg);
}

template <> static inline int Compare<sbt_ziHWqp4>(const sbt_ziHWqp4 &a, const sbt_ziHWqp4 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3Ey, b.sbt_3Ey)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5BYGb, b.sbt_5BYGb)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_7eEdsbVnI, b.sbt_7eEdsbVnI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_IkKMLDTfw, b.sbt_IkKMLDTfw)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_M1BTEvl, b.sbt_M1BTEvl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m, b.sbt_m)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_xuaxqkg, b.sbt_xuaxqkg)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_ziHWqp4>(const sbt_ziHWqp4 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3Ey, pHasher);
	Hash(p.sbt_5BYGb, pHasher);
	Hash(p.sbt_7eEdsbVnI, pHasher);
	Hash(p.sbt_IkKMLDTfw, pHasher);
	Hash(p.sbt_M1BTEvl, pHasher);
	Hash(p.sbt_m, pHasher);
	Hash(p.sbt_xuaxqkg, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_ziHWqp4>(sbt_ziHWqp4 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3Ey", p.sbt_3Ey)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5BYGb", p.sbt_5BYGb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7eEdsbVnI", p.sbt_7eEdsbVnI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_IkKMLDTfw", p.sbt_IkKMLDTfw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_M1BTEvl", p.sbt_M1BTEvl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_xuaxqkg", p.sbt_xuaxqkg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_ziHWqp4>(sbt_ziHWqp4 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3Ey", p.sbt_3Ey)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5BYGb", p.sbt_5BYGb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_7eEdsbVnI", p.sbt_7eEdsbVnI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_IkKMLDTfw", p.sbt_IkKMLDTfw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_M1BTEvl", p.sbt_M1BTEvl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_xuaxqkg", p.sbt_xuaxqkg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

