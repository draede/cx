
#pragma once


#include "sbt_cdxtwwTUWUe2l.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_tWutlta9CMZTest.hpp"
#include "sbt_f82QobRCyKhx4nRixtrTest.hpp"
#include "sbt_9dYl7KuIf8m0FVGTest.hpp"
#include "sbt_dkUTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_cdxtwwTUWUe2l &p)
{
	TestInit(p.sbt_F0LAM);
	p.sbt_N_g = 4;
	p.sbt_T = "Aww+AAKYUc1+/%?9%y{{U{]e";
	p.sbt_Xzj8o5YJB.push_back("uYYOq5s%m");
	p.sbt_Xzj8o5YJB.push_back("s/]sAu;KU");
	p.sbt_Xzj8o5YJB.push_back("}SKSm");
	p.sbt_YEHpc = 0.062632;
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		TestInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		TestInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		TestInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	TestInit(p.sbt_wZQn7r4);
}

static inline void RandInit(sbt_cdxtwwTUWUe2l &p)
{
	RandInit(p.sbt_F0LAM);
	p.sbt_N_g = CX::Util::RndGen::Get().GetInt8();
	p.sbt_T = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Xzj8o5YJB.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_Xzj8o5YJB.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_Xzj8o5YJB.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_YEHpc = CX::Util::RndGen::Get().GetDouble();
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		RandInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		RandInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		RandInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		RandInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	{
		sbt_f82QobRCyKhx4nRixtr k;
		sbt_9dYl7KuIf8m0FVG v;

		RandInit(k);
		TestInit(v);
		p.sbt_eTfxglFgE[k] = v;
	}
	RandInit(p.sbt_wZQn7r4);
}

}//namespace SB

}//namespace CX

