
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_z4bmN8S.hpp"
#include "sbt_AvrDhwJyr3qach0.hpp"


class sbt_v8_4oQnks
{
public:

	sbt_z4bmN8S sbt_80GRQw6K2;
	CX::Int16 sbt_E5ENFmJ;
	CX::SB::Map<CX::WString, CX::String>::Type sbt_QSz2GbO;
	CX::SB::Map<CX::Float, CX::Int32>::Type sbt_fi79m2T;
	sbt_AvrDhwJyr3qach0 sbt_ho_;
	CX::Int32 sbt_k;
	sbt_z4bmN8S sbt_p;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_v8_4oQnks &p)
{
	DefInit(p.sbt_80GRQw6K2);
	DefInit(p.sbt_E5ENFmJ);
	DefInit(p.sbt_QSz2GbO);
	DefInit(p.sbt_fi79m2T);
	DefInit(p.sbt_ho_);
	DefInit(p.sbt_k);
	DefInit(p.sbt_p);
}

template <> static inline int Compare<sbt_v8_4oQnks>(const sbt_v8_4oQnks &a, const sbt_v8_4oQnks &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_80GRQw6K2, b.sbt_80GRQw6K2)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_E5ENFmJ, b.sbt_E5ENFmJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_QSz2GbO, b.sbt_QSz2GbO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fi79m2T, b.sbt_fi79m2T)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ho_, b.sbt_ho_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_k, b.sbt_k)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_v8_4oQnks>(const sbt_v8_4oQnks &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_80GRQw6K2, pHasher);
	Hash(p.sbt_E5ENFmJ, pHasher);
	Hash(p.sbt_QSz2GbO, pHasher);
	Hash(p.sbt_fi79m2T, pHasher);
	Hash(p.sbt_ho_, pHasher);
	Hash(p.sbt_k, pHasher);
	Hash(p.sbt_p, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_v8_4oQnks>(sbt_v8_4oQnks p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_80GRQw6K2", p.sbt_80GRQw6K2)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_E5ENFmJ", p.sbt_E5ENFmJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_QSz2GbO", p.sbt_QSz2GbO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fi79m2T", p.sbt_fi79m2T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ho_", p.sbt_ho_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_v8_4oQnks>(sbt_v8_4oQnks &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_80GRQw6K2", p.sbt_80GRQw6K2)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_E5ENFmJ", p.sbt_E5ENFmJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_QSz2GbO", p.sbt_QSz2GbO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fi79m2T", p.sbt_fi79m2T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ho_", p.sbt_ho_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

