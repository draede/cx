
#pragma once


#include "sbt_SSrQa.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_iTL60QgDbFpTest.hpp"
#include "sbt_E8rJi4sPLTest.hpp"
#include "sbt_9aa_YuCiansA1WuTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_SSrQa &p)
{
	p.sbt_8 = 2021147263;
	p.sbt_DpN = 11711321002076527082;
	TestInit(p.sbt_MDXCp);
	p.sbt_X = 1238528108;
	TestInit(p.sbt_XBYW14bZt);
	p.sbt__2O = 3895725980064986324;
	p.sbt_bHw5TUn = 13049;
	TestInit(p.sbt_mNIqCuQ);
	p.sbt_o = 0.571962;
}

static inline void RandInit(sbt_SSrQa &p)
{
	p.sbt_8 = CX::Util::RndGen::Get().GetInt32();
	p.sbt_DpN = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_MDXCp);
	p.sbt_X = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_XBYW14bZt);
	p.sbt__2O = CX::Util::RndGen::Get().GetInt64();
	p.sbt_bHw5TUn = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_mNIqCuQ);
	p.sbt_o = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

