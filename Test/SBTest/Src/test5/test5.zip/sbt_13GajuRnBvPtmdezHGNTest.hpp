
#pragma once


#include "sbt_13GajuRnBvPtmdezHGN.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_NyxrJP4wOKC5rabTest.hpp"
#include "sbt_XpRGlsG8F1Eg9Test.hpp"
#include "sbt_UhyVfA0Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_13GajuRnBvPtmdezHGN &p)
{
	p.sbt_1mTwqlm = -7871;
	p.sbt_A90Vp4k = "}wQyg%Y!OI=}wU1UwsU15Gi";
	TestInit(p.sbt_GLQie3K);
	p.sbt_Kfs[0.201187] = L"_7;+";
	p.sbt_Kfs[0.506075] = L"7Gq9+)E/w/51/amE)}E7ao-Cm%m'";
	p.sbt_Kfs[0.163508] = L"CwO!s";
	TestInit(p.sbt_NtxfevG);
	TestInit(p.sbt_TDsTNBD9d);
	p.sbt_U49 = 4320604738939297892;
	p.sbt_u = 481830684;
	p.sbt_vBp2bUeH1 = 0.847351;
}

static inline void RandInit(sbt_13GajuRnBvPtmdezHGN &p)
{
	p.sbt_1mTwqlm = CX::Util::RndGen::Get().GetInt16();
	p.sbt_A90Vp4k = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_GLQie3K);
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kfs[CX::Util::RndGen::Get().GetDouble()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_NtxfevG);
	RandInit(p.sbt_TDsTNBD9d);
	p.sbt_U49 = CX::Util::RndGen::Get().GetInt64();
	p.sbt_u = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_vBp2bUeH1 = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

