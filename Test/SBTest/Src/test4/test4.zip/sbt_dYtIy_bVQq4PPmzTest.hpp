
#pragma once


#include "sbt_dYtIy_bVQq4PPmz.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3Test.hpp"
#include "sbt_TFd8kvEQNcJOHTest.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_dYtIy_bVQq4PPmz &p)
{
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	p.sbt_69UtO = -6062;
	p.sbt_DeG2Q = 0.861897;
	p.sbt_J3Kvf[420142358] = 28;
	p.sbt_J3Kvf[-284741735] = 84;
	p.sbt_J3Kvf[652519458] = -76;
	p.sbt_J3Kvf[-1067565420] = 1;
	p.sbt_J3Kvf[1661313666] = -32;
	p.sbt_J3Kvf[-1540255869] = -46;
	p.sbt_J3Kvf[166623927] = 111;
	p.sbt_J3Kvf[-1455784155] = 56;
	p.sbt_J3Kvf[379124983] = -28;
	p.sbt_noBoi = "9QGek;Ie/U7I";
	TestInit(p.sbt_tvk5JpU0t);
	TestInit(p.sbt_vNU6I);
}

static inline void RandInit(sbt_dYtIy_bVQq4PPmz &p)
{
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;

		TestInit(k);
		p.sbt_0.push_back(k);
	}
	p.sbt_69UtO = CX::Util::RndGen::Get().GetInt16();
	p.sbt_DeG2Q = CX::Util::RndGen::Get().GetDouble();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J3Kvf[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_noBoi = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_tvk5JpU0t);
	RandInit(p.sbt_vNU6I);
}

}//namespace SB

}//namespace CX

