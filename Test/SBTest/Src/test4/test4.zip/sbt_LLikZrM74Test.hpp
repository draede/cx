
#pragma once


#include "sbt_LLikZrM74.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_LIwN7PlXmz7vqE5enPSTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_LLikZrM74 &p)
{
	TestInit(p.sbt_4);
	p.sbt_7 = false;
	p.sbt_j5SPfJ_1d = 0.545440f;
}

static inline void RandInit(sbt_LLikZrM74 &p)
{
	RandInit(p.sbt_4);
	p.sbt_7 = CX::Util::RndGen::Get().GetBool();
	p.sbt_j5SPfJ_1d = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

