
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3.hpp"
#include "sbt_blQjnFN.hpp"
#include "sbt_Y79fr9DqeML.hpp"


class sbt_zpjYR
{
public:

	CX::UInt64 sbt_4d45XKB5z;
	sbt_v90wMwa8Kv5LfsEk3 sbt_6Pk4d;
	CX::Float sbt_B7p;
	CX::SB::Vector<CX::WString>::Type sbt_E;
	CX::SB::Vector<CX::Int64>::Type sbt_FZWxY;
	sbt_blQjnFN sbt_Vxrmedb;
	CX::Float sbt_j6t;
	CX::SB::Map<CX::UInt32, CX::Float>::Type sbt_jLz;
	CX::SB::Vector<sbt_Y79fr9DqeML>::Type sbt_w3NlskUbp;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_zpjYR &p)
{
	DefInit(p.sbt_4d45XKB5z);
	DefInit(p.sbt_6Pk4d);
	DefInit(p.sbt_B7p);
	DefInit(p.sbt_E);
	DefInit(p.sbt_FZWxY);
	DefInit(p.sbt_Vxrmedb);
	DefInit(p.sbt_j6t);
	DefInit(p.sbt_jLz);
	DefInit(p.sbt_w3NlskUbp);
}

template <> static inline int Compare<sbt_zpjYR>(const sbt_zpjYR &a, const sbt_zpjYR &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4d45XKB5z, b.sbt_4d45XKB5z)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6Pk4d, b.sbt_6Pk4d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_B7p, b.sbt_B7p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_E, b.sbt_E)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_FZWxY, b.sbt_FZWxY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Vxrmedb, b.sbt_Vxrmedb)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j6t, b.sbt_j6t)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jLz, b.sbt_jLz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_w3NlskUbp, b.sbt_w3NlskUbp)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_zpjYR>(const sbt_zpjYR &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4d45XKB5z, pHasher);
	Hash(p.sbt_6Pk4d, pHasher);
	Hash(p.sbt_B7p, pHasher);
	Hash(p.sbt_E, pHasher);
	Hash(p.sbt_FZWxY, pHasher);
	Hash(p.sbt_Vxrmedb, pHasher);
	Hash(p.sbt_j6t, pHasher);
	Hash(p.sbt_jLz, pHasher);
	Hash(p.sbt_w3NlskUbp, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_zpjYR>(sbt_zpjYR p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4d45XKB5z", p.sbt_4d45XKB5z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6Pk4d", p.sbt_6Pk4d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_B7p", p.sbt_B7p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_E", p.sbt_E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_FZWxY", p.sbt_FZWxY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Vxrmedb", p.sbt_Vxrmedb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j6t", p.sbt_j6t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jLz", p.sbt_jLz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_w3NlskUbp", p.sbt_w3NlskUbp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_zpjYR>(sbt_zpjYR &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4d45XKB5z", p.sbt_4d45XKB5z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6Pk4d", p.sbt_6Pk4d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_B7p", p.sbt_B7p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_E", p.sbt_E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_FZWxY", p.sbt_FZWxY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Vxrmedb", p.sbt_Vxrmedb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j6t", p.sbt_j6t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jLz", p.sbt_jLz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_w3NlskUbp", p.sbt_w3NlskUbp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

