
#pragma once


#include "sbt_LIwN7PlXmz7vqE5enPS.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_blQjnFNTest.hpp"
#include "sbt_wsukD_eTest.hpp"
#include "sbt_6TmYrzcowIGNpkFCSnyTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_LIwN7PlXmz7vqE5enPS &p)
{
	p.sbt_5BLS5.push_back(0.913254f);
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		TestInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	TestInit(p.sbt_R);
	p.sbt_l.push_back(113);
	p.sbt_lnPut = -1861452649091229294;
}

static inline void RandInit(sbt_LIwN7PlXmz7vqE5enPS &p)
{
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5BLS5.push_back(CX::Util::RndGen::Get().GetFloat());
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_wsukD_e v;

		RandInit(k);
		TestInit(v);
		p.sbt_K6p[k] = v;
	}
	RandInit(p.sbt_R);
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_l.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_lnPut = CX::Util::RndGen::Get().GetInt64();
}

}//namespace SB

}//namespace CX

