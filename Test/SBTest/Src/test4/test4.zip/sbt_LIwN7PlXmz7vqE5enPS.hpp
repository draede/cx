
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_blQjnFN.hpp"
#include "sbt_wsukD_e.hpp"
#include "sbt_6TmYrzcowIGNpkFCSny.hpp"


class sbt_LIwN7PlXmz7vqE5enPS
{
public:

	CX::SB::Vector<CX::Float>::Type sbt_5BLS5;
	CX::SB::Map<sbt_blQjnFN, sbt_wsukD_e>::Type sbt_K6p;
	sbt_6TmYrzcowIGNpkFCSny sbt_R;
	CX::SB::Vector<CX::Int8>::Type sbt_l;
	CX::Int64 sbt_lnPut;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_LIwN7PlXmz7vqE5enPS &p)
{
	DefInit(p.sbt_5BLS5);
	DefInit(p.sbt_K6p);
	DefInit(p.sbt_R);
	DefInit(p.sbt_l);
	DefInit(p.sbt_lnPut);
}

template <> static inline int Compare<sbt_LIwN7PlXmz7vqE5enPS>(const sbt_LIwN7PlXmz7vqE5enPS &a, const sbt_LIwN7PlXmz7vqE5enPS &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5BLS5, b.sbt_5BLS5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_K6p, b.sbt_K6p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_R, b.sbt_R)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l, b.sbt_l)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_lnPut, b.sbt_lnPut)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_LIwN7PlXmz7vqE5enPS>(const sbt_LIwN7PlXmz7vqE5enPS &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5BLS5, pHasher);
	Hash(p.sbt_K6p, pHasher);
	Hash(p.sbt_R, pHasher);
	Hash(p.sbt_l, pHasher);
	Hash(p.sbt_lnPut, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_LIwN7PlXmz7vqE5enPS>(sbt_LIwN7PlXmz7vqE5enPS p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5BLS5", p.sbt_5BLS5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_K6p", p.sbt_K6p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_R", p.sbt_R)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_lnPut", p.sbt_lnPut)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_LIwN7PlXmz7vqE5enPS>(sbt_LIwN7PlXmz7vqE5enPS &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5BLS5", p.sbt_5BLS5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_K6p", p.sbt_K6p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_R", p.sbt_R)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_lnPut", p.sbt_lnPut)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

