
#pragma once


#include "sbt_vjwgxflbl.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_dYtIy_bVQq4PPmzTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_vjwgxflbl &p)
{
	TestInit(p.sbt_R3DJPhr);
}

static inline void RandInit(sbt_vjwgxflbl &p)
{
	RandInit(p.sbt_R3DJPhr);
}

}//namespace SB

}//namespace CX

