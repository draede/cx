
#pragma once


#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"
#include "CX/Util/RndGen.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_0b8xsQ5PynBzTQ6Z5OG &p)
{
	p.sbt_4hZ = L"sEC5KuK}ES?mEg+O_MO}";
	p.sbt_BaFC4[60] = 3650325408;
	p.sbt_BaFC4[178] = 4165813435;
	p.sbt_BaFC4[72] = 1581454612;
	p.sbt_GWX2_.push_back(1893714059);
	p.sbt_GWX2_.push_back(4218792564);
	p.sbt_GWX2_.push_back(894898343);
	p.sbt_HhP = true;
	p.sbt_IydFm = 0.277877f;
}

static inline void RandInit(sbt_0b8xsQ5PynBzTQ6Z5OG &p)
{
	p.sbt_4hZ = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_BaFC4[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_BaFC4[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_BaFC4[CX::Util::RndGen::Get().GetUInt8()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_GWX2_.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_GWX2_.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_GWX2_.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_GWX2_.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_GWX2_.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_HhP = CX::Util::RndGen::Get().GetBool();
	p.sbt_IydFm = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

