
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"


class sbt_0b8xsQ5PynBzTQ6Z5OG
{
public:

	CX::WString sbt_4hZ;
	CX::SB::Map<CX::UInt8, CX::UInt32>::Type sbt_BaFC4;
	CX::SB::Vector<CX::UInt32>::Type sbt_GWX2_;
	CX::Bool sbt_HhP;
	CX::Float sbt_IydFm;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_0b8xsQ5PynBzTQ6Z5OG &p)
{
	DefInit(p.sbt_4hZ);
	DefInit(p.sbt_BaFC4);
	DefInit(p.sbt_GWX2_);
	DefInit(p.sbt_HhP);
	DefInit(p.sbt_IydFm);
}

template <> static inline int Compare<sbt_0b8xsQ5PynBzTQ6Z5OG>(const sbt_0b8xsQ5PynBzTQ6Z5OG &a, const sbt_0b8xsQ5PynBzTQ6Z5OG &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4hZ, b.sbt_4hZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_BaFC4, b.sbt_BaFC4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_GWX2_, b.sbt_GWX2_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_HhP, b.sbt_HhP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_IydFm, b.sbt_IydFm)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_0b8xsQ5PynBzTQ6Z5OG>(const sbt_0b8xsQ5PynBzTQ6Z5OG &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4hZ, pHasher);
	Hash(p.sbt_BaFC4, pHasher);
	Hash(p.sbt_GWX2_, pHasher);
	Hash(p.sbt_HhP, pHasher);
	Hash(p.sbt_IydFm, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_0b8xsQ5PynBzTQ6Z5OG>(sbt_0b8xsQ5PynBzTQ6Z5OG p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4hZ", p.sbt_4hZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BaFC4", p.sbt_BaFC4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_GWX2_", p.sbt_GWX2_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_HhP", p.sbt_HhP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_IydFm", p.sbt_IydFm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_0b8xsQ5PynBzTQ6Z5OG>(sbt_0b8xsQ5PynBzTQ6Z5OG &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4hZ", p.sbt_4hZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_BaFC4", p.sbt_BaFC4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_GWX2_", p.sbt_GWX2_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_HhP", p.sbt_HhP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_IydFm", p.sbt_IydFm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

