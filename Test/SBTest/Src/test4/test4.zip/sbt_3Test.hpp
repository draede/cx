
#pragma once


#include "sbt_3.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_OyjDyTest.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_3 &p)
{
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
}

static inline void RandInit(sbt_3 &p)
{
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
	{
		sbt_OyjDy k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_5ss[k] = v;
	}
}

}//namespace SB

}//namespace CX

