
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3.hpp"
#include "sbt_IIMFt.hpp"


class sbt_sheB2oUDspLIM
{
public:

	CX::SB::Vector<sbt_0b8xsQ5PynBzTQ6Z5OG>::Type sbt_10t9wXi;
	CX::SB::Map<sbt_v90wMwa8Kv5LfsEk3, sbt_IIMFt>::Type sbt_D89;
	CX::SB::Vector<CX::Double>::Type sbt_LFhw_;
	CX::String sbt_T;
	CX::UInt16 sbt_t8Y8uVUx4;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_sheB2oUDspLIM &p)
{
	DefInit(p.sbt_10t9wXi);
	DefInit(p.sbt_D89);
	DefInit(p.sbt_LFhw_);
	DefInit(p.sbt_T);
	DefInit(p.sbt_t8Y8uVUx4);
}

template <> static inline int Compare<sbt_sheB2oUDspLIM>(const sbt_sheB2oUDspLIM &a, const sbt_sheB2oUDspLIM &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_10t9wXi, b.sbt_10t9wXi)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_D89, b.sbt_D89)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LFhw_, b.sbt_LFhw_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_T, b.sbt_T)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_t8Y8uVUx4, b.sbt_t8Y8uVUx4)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_sheB2oUDspLIM>(const sbt_sheB2oUDspLIM &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_10t9wXi, pHasher);
	Hash(p.sbt_D89, pHasher);
	Hash(p.sbt_LFhw_, pHasher);
	Hash(p.sbt_T, pHasher);
	Hash(p.sbt_t8Y8uVUx4, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_sheB2oUDspLIM>(sbt_sheB2oUDspLIM p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_10t9wXi", p.sbt_10t9wXi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_D89", p.sbt_D89)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LFhw_", p.sbt_LFhw_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_T", p.sbt_T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_t8Y8uVUx4", p.sbt_t8Y8uVUx4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_sheB2oUDspLIM>(sbt_sheB2oUDspLIM &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_10t9wXi", p.sbt_10t9wXi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_D89", p.sbt_D89)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LFhw_", p.sbt_LFhw_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_T", p.sbt_T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_t8Y8uVUx4", p.sbt_t8Y8uVUx4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

