
#pragma once


#include "sbt_blQjnFN.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_OyjDyTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_blQjnFN &p)
{
	p.sbt_4.push_back(-7754301731811919416);
	p.sbt_4.push_back(-6644667845320710578);
	p.sbt_4.push_back(-4729176061993022728);
	p.sbt_4.push_back(-1256022081781358874);
	p.sbt_4.push_back(-4328059031036776506);
	p.sbt_4.push_back(3106915588210677138);
	p.sbt_4.push_back(-6156977361595647272);
	TestInit(p.sbt_6);
	TestInit(p.sbt_7EPcxNs6Z);
	p.sbt_KlsBFNH = 0.155685f;
	{
		sbt_OyjDy k;

		TestInit(k);
		p.sbt_LB79d6llS.push_back(k);
	}
	p.sbt_SvqGFWz = 3163300335066198028;
	p.sbt_duI49 = 0.418442f;
	p.sbt_iwBdCCr = -13437;
	p.sbt_lVp2u1GGa[-1880] = "[Io)scc]!y?/C[e!'=s/1UYEc%Y?Q";
	p.sbt_lVp2u1GGa[30676] = "[?Y}oa)cs!/WQUUw";
	p.sbt_lVp2u1GGa[-29405] = "wO!G_S?qkoEI'I5ycS)ay?";
}

static inline void RandInit(sbt_blQjnFN &p)
{
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_4.push_back(CX::Util::RndGen::Get().GetInt64());
	RandInit(p.sbt_6);
	RandInit(p.sbt_7EPcxNs6Z);
	p.sbt_KlsBFNH = CX::Util::RndGen::Get().GetFloat();
	{
		sbt_OyjDy k;

		TestInit(k);
		p.sbt_LB79d6llS.push_back(k);
	}
	{
		sbt_OyjDy k;

		TestInit(k);
		p.sbt_LB79d6llS.push_back(k);
	}
	{
		sbt_OyjDy k;

		TestInit(k);
		p.sbt_LB79d6llS.push_back(k);
	}
	{
		sbt_OyjDy k;

		TestInit(k);
		p.sbt_LB79d6llS.push_back(k);
	}
	{
		sbt_OyjDy k;

		TestInit(k);
		p.sbt_LB79d6llS.push_back(k);
	}
	p.sbt_SvqGFWz = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_duI49 = CX::Util::RndGen::Get().GetFloat();
	p.sbt_iwBdCCr = CX::Util::RndGen::Get().GetInt16();
	p.sbt_lVp2u1GGa[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_lVp2u1GGa[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_lVp2u1GGa[CX::Util::RndGen::Get().GetInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

