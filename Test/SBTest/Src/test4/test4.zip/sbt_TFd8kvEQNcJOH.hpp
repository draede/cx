
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"
#include "sbt_IIMFt.hpp"


class sbt_TFd8kvEQNcJOH
{
public:

	CX::SB::Map<sbt_0b8xsQ5PynBzTQ6Z5OG, sbt_IIMFt>::Type sbt_1hAlI5t;
	CX::UInt64 sbt_2yk;
	CX::String sbt_G4t;
	CX::SB::Map<sbt_IIMFt, sbt_IIMFt>::Type sbt__;
	CX::Int8 sbt_y;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_TFd8kvEQNcJOH &p)
{
	DefInit(p.sbt_1hAlI5t);
	DefInit(p.sbt_2yk);
	DefInit(p.sbt_G4t);
	DefInit(p.sbt__);
	DefInit(p.sbt_y);
}

template <> static inline int Compare<sbt_TFd8kvEQNcJOH>(const sbt_TFd8kvEQNcJOH &a, const sbt_TFd8kvEQNcJOH &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1hAlI5t, b.sbt_1hAlI5t)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_2yk, b.sbt_2yk)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_G4t, b.sbt_G4t)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__, b.sbt__)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y, b.sbt_y)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_TFd8kvEQNcJOH>(const sbt_TFd8kvEQNcJOH &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1hAlI5t, pHasher);
	Hash(p.sbt_2yk, pHasher);
	Hash(p.sbt_G4t, pHasher);
	Hash(p.sbt__, pHasher);
	Hash(p.sbt_y, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_TFd8kvEQNcJOH>(sbt_TFd8kvEQNcJOH p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1hAlI5t", p.sbt_1hAlI5t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_2yk", p.sbt_2yk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_G4t", p.sbt_G4t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y", p.sbt_y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_TFd8kvEQNcJOH>(sbt_TFd8kvEQNcJOH &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1hAlI5t", p.sbt_1hAlI5t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_2yk", p.sbt_2yk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_G4t", p.sbt_G4t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y", p.sbt_y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

