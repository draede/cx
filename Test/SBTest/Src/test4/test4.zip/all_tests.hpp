
#pragma once


#include "CX/SB/Tester.hpp"
#include "CX/Print.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"
#include "sbt_3Test.hpp"
#include "sbt_6TmYrzcowIGNpkFCSnyTest.hpp"
#include "sbt_blQjnFNTest.hpp"
#include "sbt_dYtIy_bVQq4PPmzTest.hpp"
#include "sbt_gTest.hpp"
#include "sbt_h6PUKTest.hpp"
#include "sbt_HFZGcMbfz6GTest.hpp"
#include "sbt_IIMFtTest.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"
#include "sbt_LIwN7PlXmz7vqE5enPSTest.hpp"
#include "sbt_LLikZrM74Test.hpp"
#include "sbt_lvJ4MruTest.hpp"
#include "sbt_OyjDyTest.hpp"
#include "sbt_PB0pycetvpBTest.hpp"
#include "sbt_pdRaJvKTesXcJANTest.hpp"
#include "sbt_Q1VRcjz6rD33FTest.hpp"
#include "sbt_qvVSCU7FUXvTest.hpp"
#include "sbt_sheB2oUDspLIMTest.hpp"
#include "sbt_sM1xaRdyg8vTest.hpp"
#include "sbt_TFd8kvEQNcJOHTest.hpp"
#include "sbt_UTest.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3Test.hpp"
#include "sbt_vjwgxflblTest.hpp"
#include "sbt_wsukD_eTest.hpp"
#include "sbt_XhFoqTest.hpp"
#include "sbt_Y79fr9DqeMLTest.hpp"
#include "sbt_YQlTest.hpp"
#include "sbt_zpjYRTest.hpp"
#include "sbt_zvZKlHBI_Zy9qW3vETest.hpp"


void Run_Tests()
{
	CX::SB::StatsData trd;
	CX::SB::StatsData twd;
	CX::Size cAll = 0;
	CX::Size cOK = 0;
	CX::Status status;

	trd.Reset();
	twd.Reset();
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_0b8xsQ5PynBzTQ6Z5OG>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_0b8xsQ5PynBzTQ6Z5OG failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_3>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_3 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_6TmYrzcowIGNpkFCSny>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_6TmYrzcowIGNpkFCSny failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_blQjnFN>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_blQjnFN failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_dYtIy_bVQq4PPmz>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_dYtIy_bVQq4PPmz failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_g>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_g failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_h6PUK>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_h6PUK failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_HFZGcMbfz6G>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_HFZGcMbfz6G failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_IIMFt>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_IIMFt failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_JsTKJfhaZmiIjNz6Y>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_JsTKJfhaZmiIjNz6Y failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_LIwN7PlXmz7vqE5enPS>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_LIwN7PlXmz7vqE5enPS failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_LLikZrM74>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_LLikZrM74 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_lvJ4Mru>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_lvJ4Mru failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_OyjDy>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_OyjDy failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_PB0pycetvpB>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_PB0pycetvpB failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_pdRaJvKTesXcJAN>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_pdRaJvKTesXcJAN failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Q1VRcjz6rD33F>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Q1VRcjz6rD33F failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_qvVSCU7FUXv>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_qvVSCU7FUXv failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_sheB2oUDspLIM>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_sheB2oUDspLIM failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_sM1xaRdyg8v>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_sM1xaRdyg8v failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_TFd8kvEQNcJOH>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_TFd8kvEQNcJOH failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_U>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_U failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_v90wMwa8Kv5LfsEk3>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_v90wMwa8Kv5LfsEk3 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_vjwgxflbl>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_vjwgxflbl failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_wsukD_e>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_wsukD_e failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_XhFoq>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_XhFoq failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Y79fr9DqeML>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Y79fr9DqeML failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_YQl>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_YQl failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_zpjYR>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_zpjYR failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_zvZKlHBI_Zy9qW3vE>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_zvZKlHBI_Zy9qW3vE failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	CX::Print(stdout, "All tests : {1}\n", cAll);
	CX::Print(stdout, "OK tests  : {1}\n", cOK);
	CX::Print(stdout, "===== READ STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", trd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", trd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", trd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", trd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", trd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", trd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", trd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", trd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", trd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", trd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", trd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", trd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", trd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", trd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", trd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", trd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", trd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", trd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", trd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {:.3} MB\n", trd.m_cbTotalSize / 1048576.0);
	CX::Print(stdout, "===== WRITE STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", twd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", twd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", twd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", twd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", twd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", twd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", twd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", twd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", twd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", twd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", twd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", twd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", twd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", twd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", twd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", twd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", twd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", twd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", twd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {1:.3} MB\n", twd.m_cbTotalSize / 1048576.0);
}
