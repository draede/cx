
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_6TmYrzcowIGNpkFCSny.hpp"
#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"


class sbt_OyjDy
{
public:

	CX::SB::Map<CX::Int32, CX::UInt32>::Type sbt_FK0poIdnK;
	CX::SB::Map<CX::Float, CX::String>::Type sbt_ItrVINf;
	CX::Int16 sbt_SrM;
	CX::SB::Map<sbt_6TmYrzcowIGNpkFCSny, sbt_6TmYrzcowIGNpkFCSny>::Type sbt_jgdax;
	sbt_JsTKJfhaZmiIjNz6Y sbt_m;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_OyjDy &p)
{
	DefInit(p.sbt_FK0poIdnK);
	DefInit(p.sbt_ItrVINf);
	DefInit(p.sbt_SrM);
	DefInit(p.sbt_jgdax);
	DefInit(p.sbt_m);
}

template <> static inline int Compare<sbt_OyjDy>(const sbt_OyjDy &a, const sbt_OyjDy &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_FK0poIdnK, b.sbt_FK0poIdnK)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ItrVINf, b.sbt_ItrVINf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SrM, b.sbt_SrM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jgdax, b.sbt_jgdax)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m, b.sbt_m)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_OyjDy>(const sbt_OyjDy &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_FK0poIdnK, pHasher);
	Hash(p.sbt_ItrVINf, pHasher);
	Hash(p.sbt_SrM, pHasher);
	Hash(p.sbt_jgdax, pHasher);
	Hash(p.sbt_m, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_OyjDy>(sbt_OyjDy p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_FK0poIdnK", p.sbt_FK0poIdnK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ItrVINf", p.sbt_ItrVINf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SrM", p.sbt_SrM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jgdax", p.sbt_jgdax)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_OyjDy>(sbt_OyjDy &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_FK0poIdnK", p.sbt_FK0poIdnK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ItrVINf", p.sbt_ItrVINf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SrM", p.sbt_SrM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jgdax", p.sbt_jgdax)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

