
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_blQjnFN.hpp"
#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"


class sbt_pdRaJvKTesXcJAN
{
public:

	CX::SB::Map<sbt_blQjnFN, sbt_JsTKJfhaZmiIjNz6Y>::Type sbt_3AX;
	CX::Float sbt_O;
	CX::Bool sbt_zIF;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_pdRaJvKTesXcJAN &p)
{
	DefInit(p.sbt_3AX);
	DefInit(p.sbt_O);
	DefInit(p.sbt_zIF);
}

template <> static inline int Compare<sbt_pdRaJvKTesXcJAN>(const sbt_pdRaJvKTesXcJAN &a, const sbt_pdRaJvKTesXcJAN &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3AX, b.sbt_3AX)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_O, b.sbt_O)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zIF, b.sbt_zIF)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_pdRaJvKTesXcJAN>(const sbt_pdRaJvKTesXcJAN &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3AX, pHasher);
	Hash(p.sbt_O, pHasher);
	Hash(p.sbt_zIF, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_pdRaJvKTesXcJAN>(sbt_pdRaJvKTesXcJAN p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3AX", p.sbt_3AX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_O", p.sbt_O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zIF", p.sbt_zIF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_pdRaJvKTesXcJAN>(sbt_pdRaJvKTesXcJAN &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3AX", p.sbt_3AX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_O", p.sbt_O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zIF", p.sbt_zIF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

