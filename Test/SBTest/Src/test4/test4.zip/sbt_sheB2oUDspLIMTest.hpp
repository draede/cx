
#pragma once


#include "sbt_sheB2oUDspLIM.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3Test.hpp"
#include "sbt_IIMFtTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_sheB2oUDspLIM &p)
{
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;

		TestInit(k);
		p.sbt_10t9wXi.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	p.sbt_LFhw_.push_back(0.668391);
	p.sbt_T = "5U}5%qiSu;eq;KAi51{O%u#IE7S[Ea";
	p.sbt_t8Y8uVUx4 = 41608;
}

static inline void RandInit(sbt_sheB2oUDspLIM &p)
{
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;

		TestInit(k);
		p.sbt_10t9wXi.push_back(k);
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;

		TestInit(k);
		p.sbt_10t9wXi.push_back(k);
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;

		TestInit(k);
		p.sbt_10t9wXi.push_back(k);
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;

		TestInit(k);
		p.sbt_10t9wXi.push_back(k);
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;

		TestInit(k);
		p.sbt_10t9wXi.push_back(k);
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_D89[k] = v;
	}
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_LFhw_.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_T = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_t8Y8uVUx4 = CX::Util::RndGen::Get().GetUInt16();
}

}//namespace SB

}//namespace CX

