
#pragma once


#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_JsTKJfhaZmiIjNz6Y &p)
{
	p.sbt_5 = -4891828361784305168;
	TestInit(p.sbt_Ubym5f20Q);
	p.sbt_X1cti = 82;
	TestInit(p.sbt_Z8VQ8dN);
	p.sbt_sgstxVgON = 1917634808;
}

static inline void RandInit(sbt_JsTKJfhaZmiIjNz6Y &p)
{
	p.sbt_5 = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_Ubym5f20Q);
	p.sbt_X1cti = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_Z8VQ8dN);
	p.sbt_sgstxVgON = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

