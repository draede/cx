
#pragma once


#include "sbt_sM1xaRdyg8v.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_PB0pycetvpBTest.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"
#include "sbt_blQjnFNTest.hpp"
#include "sbt_Y79fr9DqeMLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_sM1xaRdyg8v &p)
{
	TestInit(p.sbt_K);
	p.sbt_ROnPz_C.push_back(1939162892);
	p.sbt_ROnPz_C.push_back(198987379);
	p.sbt_ROnPz_C.push_back(1809116915);
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		TestInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	p.sbt_geP = -2050250015;
	p.sbt_ntqe8jmg9.push_back(0.452135);
	p.sbt_ntqe8jmg9.push_back(0.230718);
	p.sbt_ntqe8jmg9.push_back(0.023374);
	p.sbt_ntqe8jmg9.push_back(0.403247);
	p.sbt_ntqe8jmg9.push_back(0.213667);
	p.sbt_p = "1#5MCs3U!G7GGO}/)q)sk?";
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
}

static inline void RandInit(sbt_sM1xaRdyg8v &p)
{
	RandInit(p.sbt_K);
	p.sbt_ROnPz_C.push_back(CX::Util::RndGen::Get().GetUInt32());
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	{
		sbt_PB0pycetvpB k;
		sbt_0b8xsQ5PynBzTQ6Z5OG v;

		RandInit(k);
		TestInit(v);
		p.sbt_W[k] = v;
	}
	p.sbt_geP = CX::Util::RndGen::Get().GetInt32();
	p.sbt_ntqe8jmg9.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_p = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_qSJ[k] = v;
	}
}

}//namespace SB

}//namespace CX

