
#pragma once


#include "sbt_YQl.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_6TmYrzcowIGNpkFCSnyTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_YQl &p)
{
	p.sbt_3TuS5 = -13;
	p.sbt_O = 0.363440;
	TestInit(p.sbt_tPsgEXv);
}

static inline void RandInit(sbt_YQl &p)
{
	p.sbt_3TuS5 = CX::Util::RndGen::Get().GetInt8();
	p.sbt_O = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_tPsgEXv);
}

}//namespace SB

}//namespace CX

