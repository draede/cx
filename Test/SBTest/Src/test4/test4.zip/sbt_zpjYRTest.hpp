
#pragma once


#include "sbt_zpjYR.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3Test.hpp"
#include "sbt_blQjnFNTest.hpp"
#include "sbt_Y79fr9DqeMLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_zpjYR &p)
{
	p.sbt_4d45XKB5z = 7366175066466662186;
	TestInit(p.sbt_6Pk4d);
	p.sbt_B7p = 0.886913f;
	p.sbt_E.push_back(L"CS7ASqckqowCUi%SI9#ki");
	p.sbt_E.push_back(L"'a[5Gi{O};-'gMCwQiKU=u/]");
	p.sbt_E.push_back(L"C3Q");
	p.sbt_E.push_back(L"[)w9)UweUmi?;k-/e={[Koouy");
	p.sbt_E.push_back(L"%yGmUGAm");
	p.sbt_E.push_back(L"[+KEqI7+YI9u}7");
	p.sbt_E.push_back(L"KWg_=M_msKIS=aaA7]A!![1Qg{");
	p.sbt_E.push_back(L"?u{)Ua]W}_wo3)%;OCEWok-9m;");
	p.sbt_E.push_back(L"'[%!3'{MQa?cewo;kq[c{]%9YK7K9");
	p.sbt_FZWxY.push_back(-4782765284232967860);
	p.sbt_FZWxY.push_back(2249908251787355448);
	p.sbt_FZWxY.push_back(-6795505684342969684);
	TestInit(p.sbt_Vxrmedb);
	p.sbt_j6t = 0.770435f;
	p.sbt_jLz[3760825914] = 0.546827f;
	p.sbt_jLz[1807889566] = 0.879150f;
	p.sbt_jLz[3673851104] = 0.261274f;
	p.sbt_jLz[3692147659] = 0.599534f;
	p.sbt_jLz[1187691593] = 0.846594f;
	p.sbt_jLz[2012095749] = 0.796078f;
	p.sbt_jLz[3953364733] = 0.693709f;
	p.sbt_jLz[803872503] = 0.615169f;
	p.sbt_jLz[3296489805] = 0.520041f;
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
}

static inline void RandInit(sbt_zpjYR &p)
{
	p.sbt_4d45XKB5z = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_6Pk4d);
	p.sbt_B7p = CX::Util::RndGen::Get().GetFloat();
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_E.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_FZWxY.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_FZWxY.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_FZWxY.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_FZWxY.push_back(CX::Util::RndGen::Get().GetInt64());
	p.sbt_FZWxY.push_back(CX::Util::RndGen::Get().GetInt64());
	RandInit(p.sbt_Vxrmedb);
	p.sbt_j6t = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_jLz[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetFloat();
	{
		sbt_Y79fr9DqeML k;

		TestInit(k);
		p.sbt_w3NlskUbp.push_back(k);
	}
}

}//namespace SB

}//namespace CX

