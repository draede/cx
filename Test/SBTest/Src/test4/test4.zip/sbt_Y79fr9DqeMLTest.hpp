
#pragma once


#include "sbt_Y79fr9DqeML.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Y79fr9DqeML &p)
{
	p.sbt_0fASoiR = false;
	p.sbt_jwZ = true;
	TestInit(p.sbt_kDJZfdZte);
}

static inline void RandInit(sbt_Y79fr9DqeML &p)
{
	p.sbt_0fASoiR = CX::Util::RndGen::Get().GetBool();
	p.sbt_jwZ = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_kDJZfdZte);
}

}//namespace SB

}//namespace CX

