
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_PB0pycetvpB.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"
#include "sbt_blQjnFN.hpp"
#include "sbt_Y79fr9DqeML.hpp"


class sbt_sM1xaRdyg8v
{
public:

	sbt_PB0pycetvpB sbt_K;
	CX::SB::Vector<CX::UInt32>::Type sbt_ROnPz_C;
	CX::SB::Map<sbt_PB0pycetvpB, sbt_0b8xsQ5PynBzTQ6Z5OG>::Type sbt_W;
	CX::Int32 sbt_geP;
	CX::SB::Vector<CX::Double>::Type sbt_ntqe8jmg9;
	CX::String sbt_p;
	CX::SB::Map<sbt_blQjnFN, sbt_Y79fr9DqeML>::Type sbt_qSJ;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_sM1xaRdyg8v &p)
{
	DefInit(p.sbt_K);
	DefInit(p.sbt_ROnPz_C);
	DefInit(p.sbt_W);
	DefInit(p.sbt_geP);
	DefInit(p.sbt_ntqe8jmg9);
	DefInit(p.sbt_p);
	DefInit(p.sbt_qSJ);
}

template <> static inline int Compare<sbt_sM1xaRdyg8v>(const sbt_sM1xaRdyg8v &a, const sbt_sM1xaRdyg8v &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_K, b.sbt_K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ROnPz_C, b.sbt_ROnPz_C)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_W, b.sbt_W)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_geP, b.sbt_geP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ntqe8jmg9, b.sbt_ntqe8jmg9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qSJ, b.sbt_qSJ)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_sM1xaRdyg8v>(const sbt_sM1xaRdyg8v &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_K, pHasher);
	Hash(p.sbt_ROnPz_C, pHasher);
	Hash(p.sbt_W, pHasher);
	Hash(p.sbt_geP, pHasher);
	Hash(p.sbt_ntqe8jmg9, pHasher);
	Hash(p.sbt_p, pHasher);
	Hash(p.sbt_qSJ, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_sM1xaRdyg8v>(sbt_sM1xaRdyg8v p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_K", p.sbt_K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ROnPz_C", p.sbt_ROnPz_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_W", p.sbt_W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_geP", p.sbt_geP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ntqe8jmg9", p.sbt_ntqe8jmg9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qSJ", p.sbt_qSJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_sM1xaRdyg8v>(sbt_sM1xaRdyg8v &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_K", p.sbt_K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ROnPz_C", p.sbt_ROnPz_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_W", p.sbt_W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_geP", p.sbt_geP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ntqe8jmg9", p.sbt_ntqe8jmg9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qSJ", p.sbt_qSJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

