
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"


class sbt_JsTKJfhaZmiIjNz6Y
{
public:

	CX::Int64 sbt_5;
	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_Ubym5f20Q;
	CX::Int8 sbt_X1cti;
	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_Z8VQ8dN;
	CX::UInt32 sbt_sgstxVgON;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_JsTKJfhaZmiIjNz6Y &p)
{
	DefInit(p.sbt_5);
	DefInit(p.sbt_Ubym5f20Q);
	DefInit(p.sbt_X1cti);
	DefInit(p.sbt_Z8VQ8dN);
	DefInit(p.sbt_sgstxVgON);
}

template <> static inline int Compare<sbt_JsTKJfhaZmiIjNz6Y>(const sbt_JsTKJfhaZmiIjNz6Y &a, const sbt_JsTKJfhaZmiIjNz6Y &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5, b.sbt_5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Ubym5f20Q, b.sbt_Ubym5f20Q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X1cti, b.sbt_X1cti)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Z8VQ8dN, b.sbt_Z8VQ8dN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_sgstxVgON, b.sbt_sgstxVgON)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_JsTKJfhaZmiIjNz6Y>(const sbt_JsTKJfhaZmiIjNz6Y &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5, pHasher);
	Hash(p.sbt_Ubym5f20Q, pHasher);
	Hash(p.sbt_X1cti, pHasher);
	Hash(p.sbt_Z8VQ8dN, pHasher);
	Hash(p.sbt_sgstxVgON, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_JsTKJfhaZmiIjNz6Y>(sbt_JsTKJfhaZmiIjNz6Y p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5", p.sbt_5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Ubym5f20Q", p.sbt_Ubym5f20Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X1cti", p.sbt_X1cti)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Z8VQ8dN", p.sbt_Z8VQ8dN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_sgstxVgON", p.sbt_sgstxVgON)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_JsTKJfhaZmiIjNz6Y>(sbt_JsTKJfhaZmiIjNz6Y &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5", p.sbt_5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Ubym5f20Q", p.sbt_Ubym5f20Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X1cti", p.sbt_X1cti)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Z8VQ8dN", p.sbt_Z8VQ8dN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_sgstxVgON", p.sbt_sgstxVgON)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

