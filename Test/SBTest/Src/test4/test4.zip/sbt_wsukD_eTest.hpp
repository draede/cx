
#pragma once


#include "sbt_wsukD_e.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_wsukD_e &p)
{
	p.sbt_J5rtMSD8T = "Uu'[}}oIc)][Y#{a";
	p.sbt_d3e[12869928295285066646] = 8997604424290072596;
	p.sbt_d3e[2326503345766300728] = 7000425535211499332;
	p.sbt_d3e[8504656938593799838] = 8149121095658333126;
	p.sbt_d3e[8431176262100001312] = 4696544968368778468;
	p.sbt_d3e[517210936837456002] = 4308725171158309828;
	p.sbt_d3e[2863296795965783966] = -7097444120294454814;
	p.sbt_d3e[7434532482581908778] = -8459643780789898246;
	p.sbt_d3e[330230071015842130] = 5810345791341117262;
	p.sbt_d3e[12370957586362005388] = -482273342818865456;
	TestInit(p.sbt_tJm3Fwqxc);
}

static inline void RandInit(sbt_wsukD_e &p)
{
	p.sbt_J5rtMSD8T = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_d3e[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_tJm3Fwqxc);
}

}//namespace SB

}//namespace CX

