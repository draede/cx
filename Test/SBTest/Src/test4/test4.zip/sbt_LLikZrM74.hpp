
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_LIwN7PlXmz7vqE5enPS.hpp"


class sbt_LLikZrM74
{
public:

	sbt_LIwN7PlXmz7vqE5enPS sbt_4;
	CX::Bool sbt_7;
	CX::Float sbt_j5SPfJ_1d;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_LLikZrM74 &p)
{
	DefInit(p.sbt_4);
	DefInit(p.sbt_7);
	DefInit(p.sbt_j5SPfJ_1d);
}

template <> static inline int Compare<sbt_LLikZrM74>(const sbt_LLikZrM74 &a, const sbt_LLikZrM74 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4, b.sbt_4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_7, b.sbt_7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j5SPfJ_1d, b.sbt_j5SPfJ_1d)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_LLikZrM74>(const sbt_LLikZrM74 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4, pHasher);
	Hash(p.sbt_7, pHasher);
	Hash(p.sbt_j5SPfJ_1d, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_LLikZrM74>(sbt_LLikZrM74 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7", p.sbt_7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j5SPfJ_1d", p.sbt_j5SPfJ_1d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_LLikZrM74>(sbt_LLikZrM74 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_7", p.sbt_7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j5SPfJ_1d", p.sbt_j5SPfJ_1d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

