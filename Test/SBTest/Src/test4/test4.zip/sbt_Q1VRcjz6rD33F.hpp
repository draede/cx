
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_TFd8kvEQNcJOH.hpp"


class sbt_Q1VRcjz6rD33F
{
public:

	sbt_TFd8kvEQNcJOH sbt_9ji;
	CX::UInt32 sbt_HRJ;
	CX::SB::Vector<CX::UInt64>::Type sbt_VRT2s;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Q1VRcjz6rD33F &p)
{
	DefInit(p.sbt_9ji);
	DefInit(p.sbt_HRJ);
	DefInit(p.sbt_VRT2s);
}

template <> static inline int Compare<sbt_Q1VRcjz6rD33F>(const sbt_Q1VRcjz6rD33F &a, const sbt_Q1VRcjz6rD33F &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_9ji, b.sbt_9ji)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_HRJ, b.sbt_HRJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VRT2s, b.sbt_VRT2s)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Q1VRcjz6rD33F>(const sbt_Q1VRcjz6rD33F &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_9ji, pHasher);
	Hash(p.sbt_HRJ, pHasher);
	Hash(p.sbt_VRT2s, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Q1VRcjz6rD33F>(sbt_Q1VRcjz6rD33F p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9ji", p.sbt_9ji)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_HRJ", p.sbt_HRJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VRT2s", p.sbt_VRT2s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Q1VRcjz6rD33F>(sbt_Q1VRcjz6rD33F &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_9ji", p.sbt_9ji)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_HRJ", p.sbt_HRJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VRT2s", p.sbt_VRT2s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

