
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_XhFoq.hpp"
#include "sbt_3.hpp"


class sbt_h6PUK
{
public:

	sbt_XhFoq sbt_A;
	CX::Float sbt_I45mmPz0n;
	sbt_3 sbt_P4X;
	CX::UInt16 sbt_Q;
	CX::Int64 sbt_V;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_h6PUK &p)
{
	DefInit(p.sbt_A);
	DefInit(p.sbt_I45mmPz0n);
	DefInit(p.sbt_P4X);
	DefInit(p.sbt_Q);
	DefInit(p.sbt_V);
}

template <> static inline int Compare<sbt_h6PUK>(const sbt_h6PUK &a, const sbt_h6PUK &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_A, b.sbt_A)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_I45mmPz0n, b.sbt_I45mmPz0n)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_P4X, b.sbt_P4X)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Q, b.sbt_Q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_V, b.sbt_V)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_h6PUK>(const sbt_h6PUK &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_A, pHasher);
	Hash(p.sbt_I45mmPz0n, pHasher);
	Hash(p.sbt_P4X, pHasher);
	Hash(p.sbt_Q, pHasher);
	Hash(p.sbt_V, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_h6PUK>(sbt_h6PUK p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_A", p.sbt_A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_I45mmPz0n", p.sbt_I45mmPz0n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_P4X", p.sbt_P4X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Q", p.sbt_Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_V", p.sbt_V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_h6PUK>(sbt_h6PUK &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_A", p.sbt_A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_I45mmPz0n", p.sbt_I45mmPz0n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_P4X", p.sbt_P4X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Q", p.sbt_Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_V", p.sbt_V)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

