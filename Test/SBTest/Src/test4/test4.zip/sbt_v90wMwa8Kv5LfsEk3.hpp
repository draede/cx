
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"
#include "sbt_6TmYrzcowIGNpkFCSny.hpp"


class sbt_v90wMwa8Kv5LfsEk3
{
public:

	CX::Int64 sbt_E;
	CX::Double sbt_g;
	sbt_JsTKJfhaZmiIjNz6Y sbt_tPt;
	CX::SB::Vector<sbt_6TmYrzcowIGNpkFCSny>::Type sbt_zJg5C_M;
	CX::String sbt_z_ALtGQk_;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_v90wMwa8Kv5LfsEk3 &p)
{
	DefInit(p.sbt_E);
	DefInit(p.sbt_g);
	DefInit(p.sbt_tPt);
	DefInit(p.sbt_zJg5C_M);
	DefInit(p.sbt_z_ALtGQk_);
}

template <> static inline int Compare<sbt_v90wMwa8Kv5LfsEk3>(const sbt_v90wMwa8Kv5LfsEk3 &a, const sbt_v90wMwa8Kv5LfsEk3 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_E, b.sbt_E)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_g, b.sbt_g)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tPt, b.sbt_tPt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zJg5C_M, b.sbt_zJg5C_M)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_z_ALtGQk_, b.sbt_z_ALtGQk_)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_v90wMwa8Kv5LfsEk3>(const sbt_v90wMwa8Kv5LfsEk3 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_E, pHasher);
	Hash(p.sbt_g, pHasher);
	Hash(p.sbt_tPt, pHasher);
	Hash(p.sbt_zJg5C_M, pHasher);
	Hash(p.sbt_z_ALtGQk_, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_v90wMwa8Kv5LfsEk3>(sbt_v90wMwa8Kv5LfsEk3 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_E", p.sbt_E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_g", p.sbt_g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tPt", p.sbt_tPt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zJg5C_M", p.sbt_zJg5C_M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_z_ALtGQk_", p.sbt_z_ALtGQk_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_v90wMwa8Kv5LfsEk3>(sbt_v90wMwa8Kv5LfsEk3 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_E", p.sbt_E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_g", p.sbt_g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tPt", p.sbt_tPt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zJg5C_M", p.sbt_zJg5C_M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_z_ALtGQk_", p.sbt_z_ALtGQk_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

