
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3.hpp"
#include "sbt_Y79fr9DqeML.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"


class sbt_PB0pycetvpB
{
public:

	CX::UInt16 sbt_S;
	CX::SB::Map<sbt_v90wMwa8Kv5LfsEk3, sbt_Y79fr9DqeML>::Type sbt_aFPg0In;
	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_iJlCXiANg;
	CX::SB::Map<CX::Float, CX::UInt16>::Type sbt_psfMO;
	CX::SB::Vector<CX::UInt64>::Type sbt_q9m;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_PB0pycetvpB &p)
{
	DefInit(p.sbt_S);
	DefInit(p.sbt_aFPg0In);
	DefInit(p.sbt_iJlCXiANg);
	DefInit(p.sbt_psfMO);
	DefInit(p.sbt_q9m);
}

template <> static inline int Compare<sbt_PB0pycetvpB>(const sbt_PB0pycetvpB &a, const sbt_PB0pycetvpB &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_S, b.sbt_S)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aFPg0In, b.sbt_aFPg0In)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iJlCXiANg, b.sbt_iJlCXiANg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_psfMO, b.sbt_psfMO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_q9m, b.sbt_q9m)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_PB0pycetvpB>(const sbt_PB0pycetvpB &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_S, pHasher);
	Hash(p.sbt_aFPg0In, pHasher);
	Hash(p.sbt_iJlCXiANg, pHasher);
	Hash(p.sbt_psfMO, pHasher);
	Hash(p.sbt_q9m, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_PB0pycetvpB>(sbt_PB0pycetvpB p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aFPg0In", p.sbt_aFPg0In)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iJlCXiANg", p.sbt_iJlCXiANg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_psfMO", p.sbt_psfMO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_q9m", p.sbt_q9m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_PB0pycetvpB>(sbt_PB0pycetvpB &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aFPg0In", p.sbt_aFPg0In)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iJlCXiANg", p.sbt_iJlCXiANg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_psfMO", p.sbt_psfMO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_q9m", p.sbt_q9m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

