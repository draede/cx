
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_6TmYrzcowIGNpkFCSny.hpp"


class sbt_YQl
{
public:

	CX::Int8 sbt_3TuS5;
	CX::Double sbt_O;
	sbt_6TmYrzcowIGNpkFCSny sbt_tPsgEXv;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_YQl &p)
{
	DefInit(p.sbt_3TuS5);
	DefInit(p.sbt_O);
	DefInit(p.sbt_tPsgEXv);
}

template <> static inline int Compare<sbt_YQl>(const sbt_YQl &a, const sbt_YQl &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3TuS5, b.sbt_3TuS5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_O, b.sbt_O)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tPsgEXv, b.sbt_tPsgEXv)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_YQl>(const sbt_YQl &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3TuS5, pHasher);
	Hash(p.sbt_O, pHasher);
	Hash(p.sbt_tPsgEXv, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_YQl>(sbt_YQl p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3TuS5", p.sbt_3TuS5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_O", p.sbt_O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tPsgEXv", p.sbt_tPsgEXv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_YQl>(sbt_YQl &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3TuS5", p.sbt_3TuS5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_O", p.sbt_O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tPsgEXv", p.sbt_tPsgEXv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

