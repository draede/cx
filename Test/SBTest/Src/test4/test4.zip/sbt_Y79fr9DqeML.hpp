
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"


class sbt_Y79fr9DqeML
{
public:

	CX::Bool sbt_0fASoiR;
	CX::Bool sbt_jwZ;
	sbt_JsTKJfhaZmiIjNz6Y sbt_kDJZfdZte;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Y79fr9DqeML &p)
{
	DefInit(p.sbt_0fASoiR);
	DefInit(p.sbt_jwZ);
	DefInit(p.sbt_kDJZfdZte);
}

template <> static inline int Compare<sbt_Y79fr9DqeML>(const sbt_Y79fr9DqeML &a, const sbt_Y79fr9DqeML &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0fASoiR, b.sbt_0fASoiR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jwZ, b.sbt_jwZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_kDJZfdZte, b.sbt_kDJZfdZte)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Y79fr9DqeML>(const sbt_Y79fr9DqeML &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0fASoiR, pHasher);
	Hash(p.sbt_jwZ, pHasher);
	Hash(p.sbt_kDJZfdZte, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Y79fr9DqeML>(sbt_Y79fr9DqeML p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0fASoiR", p.sbt_0fASoiR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jwZ", p.sbt_jwZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_kDJZfdZte", p.sbt_kDJZfdZte)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Y79fr9DqeML>(sbt_Y79fr9DqeML &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0fASoiR", p.sbt_0fASoiR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jwZ", p.sbt_jwZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_kDJZfdZte", p.sbt_kDJZfdZte)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

