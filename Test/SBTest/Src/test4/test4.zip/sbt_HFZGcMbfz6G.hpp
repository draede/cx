
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_XhFoq.hpp"
#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"


class sbt_HFZGcMbfz6G
{
public:

	CX::UInt64 sbt_KCp;
	CX::UInt16 sbt_a1dFd;
	CX::Int8 sbt_i;
	sbt_XhFoq sbt_oiY4p;
	CX::SB::Vector<sbt_JsTKJfhaZmiIjNz6Y>::Type sbt_upI;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_HFZGcMbfz6G &p)
{
	DefInit(p.sbt_KCp);
	DefInit(p.sbt_a1dFd);
	DefInit(p.sbt_i);
	DefInit(p.sbt_oiY4p);
	DefInit(p.sbt_upI);
}

template <> static inline int Compare<sbt_HFZGcMbfz6G>(const sbt_HFZGcMbfz6G &a, const sbt_HFZGcMbfz6G &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_KCp, b.sbt_KCp)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_a1dFd, b.sbt_a1dFd)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_i, b.sbt_i)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_oiY4p, b.sbt_oiY4p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_upI, b.sbt_upI)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_HFZGcMbfz6G>(const sbt_HFZGcMbfz6G &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_KCp, pHasher);
	Hash(p.sbt_a1dFd, pHasher);
	Hash(p.sbt_i, pHasher);
	Hash(p.sbt_oiY4p, pHasher);
	Hash(p.sbt_upI, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_HFZGcMbfz6G>(sbt_HFZGcMbfz6G p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KCp", p.sbt_KCp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_a1dFd", p.sbt_a1dFd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_i", p.sbt_i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_oiY4p", p.sbt_oiY4p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_upI", p.sbt_upI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_HFZGcMbfz6G>(sbt_HFZGcMbfz6G &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_KCp", p.sbt_KCp)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_a1dFd", p.sbt_a1dFd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_i", p.sbt_i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_oiY4p", p.sbt_oiY4p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_upI", p.sbt_upI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

