
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3.hpp"


class sbt_wsukD_e
{
public:

	CX::String sbt_J5rtMSD8T;
	CX::SB::Map<CX::UInt64, CX::Int64>::Type sbt_d3e;
	sbt_v90wMwa8Kv5LfsEk3 sbt_tJm3Fwqxc;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_wsukD_e &p)
{
	DefInit(p.sbt_J5rtMSD8T);
	DefInit(p.sbt_d3e);
	DefInit(p.sbt_tJm3Fwqxc);
}

template <> static inline int Compare<sbt_wsukD_e>(const sbt_wsukD_e &a, const sbt_wsukD_e &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_J5rtMSD8T, b.sbt_J5rtMSD8T)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_d3e, b.sbt_d3e)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tJm3Fwqxc, b.sbt_tJm3Fwqxc)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_wsukD_e>(const sbt_wsukD_e &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_J5rtMSD8T, pHasher);
	Hash(p.sbt_d3e, pHasher);
	Hash(p.sbt_tJm3Fwqxc, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_wsukD_e>(sbt_wsukD_e p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_J5rtMSD8T", p.sbt_J5rtMSD8T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_d3e", p.sbt_d3e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tJm3Fwqxc", p.sbt_tJm3Fwqxc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_wsukD_e>(sbt_wsukD_e &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_J5rtMSD8T", p.sbt_J5rtMSD8T)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_d3e", p.sbt_d3e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tJm3Fwqxc", p.sbt_tJm3Fwqxc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

