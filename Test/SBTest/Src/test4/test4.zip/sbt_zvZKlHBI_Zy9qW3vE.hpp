
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_HFZGcMbfz6G.hpp"
#include "sbt_blQjnFN.hpp"
#include "sbt_IIMFt.hpp"
#include "sbt_XhFoq.hpp"


class sbt_zvZKlHBI_Zy9qW3vE
{
public:

	CX::SB::Map<sbt_HFZGcMbfz6G, sbt_blQjnFN>::Type sbt_J3M_Cbz;
	CX::SB::Map<sbt_IIMFt, sbt_XhFoq>::Type sbt_MLSstS8;
	CX::SB::Vector<CX::Int8>::Type sbt_XJAezH4;
	CX::SB::Vector<CX::WString>::Type sbt_n;
	CX::Int8 sbt_v;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_zvZKlHBI_Zy9qW3vE &p)
{
	DefInit(p.sbt_J3M_Cbz);
	DefInit(p.sbt_MLSstS8);
	DefInit(p.sbt_XJAezH4);
	DefInit(p.sbt_n);
	DefInit(p.sbt_v);
}

template <> static inline int Compare<sbt_zvZKlHBI_Zy9qW3vE>(const sbt_zvZKlHBI_Zy9qW3vE &a, const sbt_zvZKlHBI_Zy9qW3vE &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_J3M_Cbz, b.sbt_J3M_Cbz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_MLSstS8, b.sbt_MLSstS8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XJAezH4, b.sbt_XJAezH4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_n, b.sbt_n)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_v, b.sbt_v)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_zvZKlHBI_Zy9qW3vE>(const sbt_zvZKlHBI_Zy9qW3vE &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_J3M_Cbz, pHasher);
	Hash(p.sbt_MLSstS8, pHasher);
	Hash(p.sbt_XJAezH4, pHasher);
	Hash(p.sbt_n, pHasher);
	Hash(p.sbt_v, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_zvZKlHBI_Zy9qW3vE>(sbt_zvZKlHBI_Zy9qW3vE p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_J3M_Cbz", p.sbt_J3M_Cbz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_MLSstS8", p.sbt_MLSstS8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XJAezH4", p.sbt_XJAezH4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_n", p.sbt_n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_zvZKlHBI_Zy9qW3vE>(sbt_zvZKlHBI_Zy9qW3vE &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_J3M_Cbz", p.sbt_J3M_Cbz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_MLSstS8", p.sbt_MLSstS8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XJAezH4", p.sbt_XJAezH4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_n", p.sbt_n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

