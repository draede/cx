
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_OyjDy.hpp"


class sbt_blQjnFN
{
public:

	CX::SB::Vector<CX::Int64>::Type sbt_4;
	sbt_OyjDy sbt_6;
	sbt_OyjDy sbt_7EPcxNs6Z;
	CX::Float sbt_KlsBFNH;
	CX::SB::Vector<sbt_OyjDy>::Type sbt_LB79d6llS;
	CX::UInt64 sbt_SvqGFWz;
	CX::Float sbt_duI49;
	CX::Int16 sbt_iwBdCCr;
	CX::SB::Map<CX::Int16, CX::String>::Type sbt_lVp2u1GGa;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_blQjnFN &p)
{
	DefInit(p.sbt_4);
	DefInit(p.sbt_6);
	DefInit(p.sbt_7EPcxNs6Z);
	DefInit(p.sbt_KlsBFNH);
	DefInit(p.sbt_LB79d6llS);
	DefInit(p.sbt_SvqGFWz);
	DefInit(p.sbt_duI49);
	DefInit(p.sbt_iwBdCCr);
	DefInit(p.sbt_lVp2u1GGa);
}

template <> static inline int Compare<sbt_blQjnFN>(const sbt_blQjnFN &a, const sbt_blQjnFN &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4, b.sbt_4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6, b.sbt_6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_7EPcxNs6Z, b.sbt_7EPcxNs6Z)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KlsBFNH, b.sbt_KlsBFNH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LB79d6llS, b.sbt_LB79d6llS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SvqGFWz, b.sbt_SvqGFWz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_duI49, b.sbt_duI49)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iwBdCCr, b.sbt_iwBdCCr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_lVp2u1GGa, b.sbt_lVp2u1GGa)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_blQjnFN>(const sbt_blQjnFN &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4, pHasher);
	Hash(p.sbt_6, pHasher);
	Hash(p.sbt_7EPcxNs6Z, pHasher);
	Hash(p.sbt_KlsBFNH, pHasher);
	Hash(p.sbt_LB79d6llS, pHasher);
	Hash(p.sbt_SvqGFWz, pHasher);
	Hash(p.sbt_duI49, pHasher);
	Hash(p.sbt_iwBdCCr, pHasher);
	Hash(p.sbt_lVp2u1GGa, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_blQjnFN>(sbt_blQjnFN p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6", p.sbt_6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7EPcxNs6Z", p.sbt_7EPcxNs6Z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KlsBFNH", p.sbt_KlsBFNH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LB79d6llS", p.sbt_LB79d6llS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SvqGFWz", p.sbt_SvqGFWz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_duI49", p.sbt_duI49)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iwBdCCr", p.sbt_iwBdCCr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_lVp2u1GGa", p.sbt_lVp2u1GGa)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_blQjnFN>(sbt_blQjnFN &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6", p.sbt_6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_7EPcxNs6Z", p.sbt_7EPcxNs6Z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KlsBFNH", p.sbt_KlsBFNH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LB79d6llS", p.sbt_LB79d6llS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SvqGFWz", p.sbt_SvqGFWz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_duI49", p.sbt_duI49)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iwBdCCr", p.sbt_iwBdCCr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_lVp2u1GGa", p.sbt_lVp2u1GGa)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

