
#pragma once


#include "sbt_h6PUK.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_XhFoqTest.hpp"
#include "sbt_3Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_h6PUK &p)
{
	TestInit(p.sbt_A);
	p.sbt_I45mmPz0n = 0.288665f;
	TestInit(p.sbt_P4X);
	p.sbt_Q = 37104;
	p.sbt_V = 4805676124604966464;
}

static inline void RandInit(sbt_h6PUK &p)
{
	RandInit(p.sbt_A);
	p.sbt_I45mmPz0n = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_P4X);
	p.sbt_Q = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_V = CX::Util::RndGen::Get().GetInt64();
}

}//namespace SB

}//namespace CX

