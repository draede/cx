
#pragma once


#include "sbt_TFd8kvEQNcJOH.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"
#include "sbt_IIMFtTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_TFd8kvEQNcJOH &p)
{
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	p.sbt_2yk = 8012311521851161272;
	p.sbt_G4t = "QQ";
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	p.sbt_y = -67;
}

static inline void RandInit(sbt_TFd8kvEQNcJOH &p)
{
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	{
		sbt_0b8xsQ5PynBzTQ6Z5OG k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt_1hAlI5t[k] = v;
	}
	p.sbt_2yk = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_G4t = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_IIMFt v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	p.sbt_y = CX::Util::RndGen::Get().GetInt8();
}

}//namespace SB

}//namespace CX

