
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"


class sbt_IIMFt
{
public:

	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_04ynS;
	CX::Int32 sbt_1;
	CX::Float sbt_G28BS4t;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_IIMFt &p)
{
	DefInit(p.sbt_04ynS);
	DefInit(p.sbt_1);
	DefInit(p.sbt_G28BS4t);
}

template <> static inline int Compare<sbt_IIMFt>(const sbt_IIMFt &a, const sbt_IIMFt &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_04ynS, b.sbt_04ynS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_1, b.sbt_1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_G28BS4t, b.sbt_G28BS4t)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_IIMFt>(const sbt_IIMFt &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_04ynS, pHasher);
	Hash(p.sbt_1, pHasher);
	Hash(p.sbt_G28BS4t, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_IIMFt>(sbt_IIMFt p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_04ynS", p.sbt_04ynS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1", p.sbt_1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_G28BS4t", p.sbt_G28BS4t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_IIMFt>(sbt_IIMFt &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_04ynS", p.sbt_04ynS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_1", p.sbt_1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_G28BS4t", p.sbt_G28BS4t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

