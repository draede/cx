
#pragma once


#include "sbt_g.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_LLikZrM74Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_g &p)
{
	TestInit(p.sbt_IkEUsAu);
}

static inline void RandInit(sbt_g &p)
{
	RandInit(p.sbt_IkEUsAu);
}

}//namespace SB

}//namespace CX

