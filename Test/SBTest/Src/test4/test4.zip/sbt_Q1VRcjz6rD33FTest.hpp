
#pragma once


#include "sbt_Q1VRcjz6rD33F.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_TFd8kvEQNcJOHTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Q1VRcjz6rD33F &p)
{
	TestInit(p.sbt_9ji);
	p.sbt_HRJ = 2398258663;
	p.sbt_VRT2s.push_back(8875340983394838228);
	p.sbt_VRT2s.push_back(1917314604639963932);
	p.sbt_VRT2s.push_back(7061394966406005874);
	p.sbt_VRT2s.push_back(63248702538412292);
	p.sbt_VRT2s.push_back(5581046957577904082);
	p.sbt_VRT2s.push_back(5458997651125390032);
	p.sbt_VRT2s.push_back(15683201955723235156);
	p.sbt_VRT2s.push_back(5014191508168437226);
	p.sbt_VRT2s.push_back(1680724434907260920);
}

static inline void RandInit(sbt_Q1VRcjz6rD33F &p)
{
	RandInit(p.sbt_9ji);
	p.sbt_HRJ = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_VRT2s.push_back(CX::Util::RndGen::Get().GetUInt64());
}

}//namespace SB

}//namespace CX

