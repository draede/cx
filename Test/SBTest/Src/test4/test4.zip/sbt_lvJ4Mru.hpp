
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_HFZGcMbfz6G.hpp"
#include "sbt_IIMFt.hpp"


class sbt_lvJ4Mru
{
public:

	CX::Int64 sbt_S;
	sbt_HFZGcMbfz6G sbt_TpqhLLg;
	sbt_IIMFt sbt_dkegsSsw3;
	CX::Double sbt_yxq6fnT;
	CX::SB::Map<CX::Bool, CX::Bool>::Type sbt_zJvRsze;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_lvJ4Mru &p)
{
	DefInit(p.sbt_S);
	DefInit(p.sbt_TpqhLLg);
	DefInit(p.sbt_dkegsSsw3);
	DefInit(p.sbt_yxq6fnT);
	DefInit(p.sbt_zJvRsze);
}

template <> static inline int Compare<sbt_lvJ4Mru>(const sbt_lvJ4Mru &a, const sbt_lvJ4Mru &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_S, b.sbt_S)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TpqhLLg, b.sbt_TpqhLLg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_dkegsSsw3, b.sbt_dkegsSsw3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yxq6fnT, b.sbt_yxq6fnT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zJvRsze, b.sbt_zJvRsze)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_lvJ4Mru>(const sbt_lvJ4Mru &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_S, pHasher);
	Hash(p.sbt_TpqhLLg, pHasher);
	Hash(p.sbt_dkegsSsw3, pHasher);
	Hash(p.sbt_yxq6fnT, pHasher);
	Hash(p.sbt_zJvRsze, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_lvJ4Mru>(sbt_lvJ4Mru p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TpqhLLg", p.sbt_TpqhLLg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_dkegsSsw3", p.sbt_dkegsSsw3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yxq6fnT", p.sbt_yxq6fnT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zJvRsze", p.sbt_zJvRsze)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_lvJ4Mru>(sbt_lvJ4Mru &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_S", p.sbt_S)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TpqhLLg", p.sbt_TpqhLLg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_dkegsSsw3", p.sbt_dkegsSsw3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yxq6fnT", p.sbt_yxq6fnT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zJvRsze", p.sbt_zJvRsze)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

