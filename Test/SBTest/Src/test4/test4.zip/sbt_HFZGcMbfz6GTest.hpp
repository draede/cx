
#pragma once


#include "sbt_HFZGcMbfz6G.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_XhFoqTest.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_HFZGcMbfz6G &p)
{
	p.sbt_KCp = 8615360403189582482;
	p.sbt_a1dFd = 7164;
	p.sbt_i = 8;
	TestInit(p.sbt_oiY4p);
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
}

static inline void RandInit(sbt_HFZGcMbfz6G &p)
{
	p.sbt_KCp = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_a1dFd = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_i = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_oiY4p);
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_upI.push_back(k);
	}
}

}//namespace SB

}//namespace CX

