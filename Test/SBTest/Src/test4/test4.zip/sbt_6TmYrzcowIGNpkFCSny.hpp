
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"
#include "sbt_JsTKJfhaZmiIjNz6Y.hpp"


class sbt_6TmYrzcowIGNpkFCSny
{
public:

	CX::Float sbt_Hi5Ky;
	CX::UInt16 sbt_SSZ;
	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_XI8rFdx;
	CX::SB::Vector<sbt_JsTKJfhaZmiIjNz6Y>::Type sbt_XQd;
	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_aFOoKxu;
	CX::Int8 sbt_k;
	CX::Float sbt_nYTSLrn;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_6TmYrzcowIGNpkFCSny &p)
{
	DefInit(p.sbt_Hi5Ky);
	DefInit(p.sbt_SSZ);
	DefInit(p.sbt_XI8rFdx);
	DefInit(p.sbt_XQd);
	DefInit(p.sbt_aFOoKxu);
	DefInit(p.sbt_k);
	DefInit(p.sbt_nYTSLrn);
}

template <> static inline int Compare<sbt_6TmYrzcowIGNpkFCSny>(const sbt_6TmYrzcowIGNpkFCSny &a, const sbt_6TmYrzcowIGNpkFCSny &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Hi5Ky, b.sbt_Hi5Ky)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SSZ, b.sbt_SSZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XI8rFdx, b.sbt_XI8rFdx)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XQd, b.sbt_XQd)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aFOoKxu, b.sbt_aFOoKxu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_k, b.sbt_k)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nYTSLrn, b.sbt_nYTSLrn)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_6TmYrzcowIGNpkFCSny>(const sbt_6TmYrzcowIGNpkFCSny &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Hi5Ky, pHasher);
	Hash(p.sbt_SSZ, pHasher);
	Hash(p.sbt_XI8rFdx, pHasher);
	Hash(p.sbt_XQd, pHasher);
	Hash(p.sbt_aFOoKxu, pHasher);
	Hash(p.sbt_k, pHasher);
	Hash(p.sbt_nYTSLrn, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_6TmYrzcowIGNpkFCSny>(sbt_6TmYrzcowIGNpkFCSny p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Hi5Ky", p.sbt_Hi5Ky)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SSZ", p.sbt_SSZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XI8rFdx", p.sbt_XI8rFdx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XQd", p.sbt_XQd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aFOoKxu", p.sbt_aFOoKxu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nYTSLrn", p.sbt_nYTSLrn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_6TmYrzcowIGNpkFCSny>(sbt_6TmYrzcowIGNpkFCSny &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Hi5Ky", p.sbt_Hi5Ky)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SSZ", p.sbt_SSZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XI8rFdx", p.sbt_XI8rFdx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XQd", p.sbt_XQd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aFOoKxu", p.sbt_aFOoKxu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_k", p.sbt_k)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nYTSLrn", p.sbt_nYTSLrn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

