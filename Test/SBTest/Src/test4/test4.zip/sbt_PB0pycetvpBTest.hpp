
#pragma once


#include "sbt_PB0pycetvpB.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3Test.hpp"
#include "sbt_Y79fr9DqeMLTest.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_PB0pycetvpB &p)
{
	p.sbt_S = 37437;
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		TestInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	TestInit(p.sbt_iJlCXiANg);
	p.sbt_psfMO[0.378380f] = 49150;
	p.sbt_psfMO[0.853523f] = 58173;
	p.sbt_psfMO[0.129469f] = 43657;
	p.sbt_psfMO[0.220437f] = 59833;
	p.sbt_psfMO[0.735064f] = 2400;
	p.sbt_psfMO[0.007074f] = 6876;
	p.sbt_psfMO[0.724021f] = 38075;
	p.sbt_q9m.push_back(4964222854281417106);
	p.sbt_q9m.push_back(12385683505772920482);
	p.sbt_q9m.push_back(15220921995665212962);
	p.sbt_q9m.push_back(15765584179246587588);
	p.sbt_q9m.push_back(17882478764478236690);
	p.sbt_q9m.push_back(3382294251631340906);
	p.sbt_q9m.push_back(10633401013175443178);
	p.sbt_q9m.push_back(15336979495095781036);
	p.sbt_q9m.push_back(13407583929429570890);
}

static inline void RandInit(sbt_PB0pycetvpB &p)
{
	p.sbt_S = CX::Util::RndGen::Get().GetUInt16();
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	{
		sbt_v90wMwa8Kv5LfsEk3 k;
		sbt_Y79fr9DqeML v;

		RandInit(k);
		TestInit(v);
		p.sbt_aFPg0In[k] = v;
	}
	RandInit(p.sbt_iJlCXiANg);
	p.sbt_psfMO[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_psfMO[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_psfMO[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_psfMO[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_psfMO[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_q9m.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_q9m.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_q9m.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_q9m.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_q9m.push_back(CX::Util::RndGen::Get().GetUInt64());
}

}//namespace SB

}//namespace CX

