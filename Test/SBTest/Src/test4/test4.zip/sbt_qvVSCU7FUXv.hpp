
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_U.hpp"


class sbt_qvVSCU7FUXv
{
public:

	sbt_U sbt_Auv;
	CX::Int16 sbt_Rpved;
	CX::Double sbt_VPJHrQR;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_qvVSCU7FUXv &p)
{
	DefInit(p.sbt_Auv);
	DefInit(p.sbt_Rpved);
	DefInit(p.sbt_VPJHrQR);
}

template <> static inline int Compare<sbt_qvVSCU7FUXv>(const sbt_qvVSCU7FUXv &a, const sbt_qvVSCU7FUXv &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Auv, b.sbt_Auv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Rpved, b.sbt_Rpved)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VPJHrQR, b.sbt_VPJHrQR)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_qvVSCU7FUXv>(const sbt_qvVSCU7FUXv &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Auv, pHasher);
	Hash(p.sbt_Rpved, pHasher);
	Hash(p.sbt_VPJHrQR, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_qvVSCU7FUXv>(sbt_qvVSCU7FUXv p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Auv", p.sbt_Auv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Rpved", p.sbt_Rpved)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VPJHrQR", p.sbt_VPJHrQR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_qvVSCU7FUXv>(sbt_qvVSCU7FUXv &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Auv", p.sbt_Auv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Rpved", p.sbt_Rpved)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VPJHrQR", p.sbt_VPJHrQR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

