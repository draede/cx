
#pragma once


#include "sbt_U.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_PB0pycetvpBTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_U &p)
{
	TestInit(p.sbt_gMzZ3BhR0);
}

static inline void RandInit(sbt_U &p)
{
	RandInit(p.sbt_gMzZ3BhR0);
}

}//namespace SB

}//namespace CX

