
#pragma once


#include "sbt_OyjDy.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_6TmYrzcowIGNpkFCSnyTest.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_OyjDy &p)
{
	p.sbt_FK0poIdnK[1692154399] = 2040022948;
	p.sbt_FK0poIdnK[775412736] = 884396575;
	p.sbt_FK0poIdnK[1869069331] = 2767243043;
	p.sbt_ItrVINf[0.157451f] = "mYKSYu7?EmKa]+SGk//gEMu?]5ymy]";
	p.sbt_SrM = 19382;
	{
		sbt_6TmYrzcowIGNpkFCSny k;
		sbt_6TmYrzcowIGNpkFCSny v;

		TestInit(k);
		TestInit(v);
		p.sbt_jgdax[k] = v;
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;
		sbt_6TmYrzcowIGNpkFCSny v;

		TestInit(k);
		TestInit(v);
		p.sbt_jgdax[k] = v;
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;
		sbt_6TmYrzcowIGNpkFCSny v;

		TestInit(k);
		TestInit(v);
		p.sbt_jgdax[k] = v;
	}
	TestInit(p.sbt_m);
}

static inline void RandInit(sbt_OyjDy &p)
{
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_FK0poIdnK[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_ItrVINf[CX::Util::RndGen::Get().GetFloat()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_SrM = CX::Util::RndGen::Get().GetInt16();
	{
		sbt_6TmYrzcowIGNpkFCSny k;
		sbt_6TmYrzcowIGNpkFCSny v;

		RandInit(k);
		TestInit(v);
		p.sbt_jgdax[k] = v;
	}
	RandInit(p.sbt_m);
}

}//namespace SB

}//namespace CX

