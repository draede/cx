
#pragma once


#include "sbt_XhFoq.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_XhFoq &p)
{
	TestInit(p.sbt_FjThvfkgu);
}

static inline void RandInit(sbt_XhFoq &p)
{
	RandInit(p.sbt_FjThvfkgu);
}

}//namespace SB

}//namespace CX

