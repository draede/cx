
#pragma once


#include "sbt_IIMFt.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_IIMFt &p)
{
	TestInit(p.sbt_04ynS);
	p.sbt_1 = 606047636;
	p.sbt_G28BS4t = 0.479421f;
}

static inline void RandInit(sbt_IIMFt &p)
{
	RandInit(p.sbt_04ynS);
	p.sbt_1 = CX::Util::RndGen::Get().GetInt32();
	p.sbt_G28BS4t = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

