
#pragma once


#include "sbt_lvJ4Mru.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_HFZGcMbfz6GTest.hpp"
#include "sbt_IIMFtTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_lvJ4Mru &p)
{
	p.sbt_S = 2758491225808418672;
	TestInit(p.sbt_TpqhLLg);
	TestInit(p.sbt_dkegsSsw3);
	p.sbt_yxq6fnT = 0.713457;
	p.sbt_zJvRsze[true] = true;
}

static inline void RandInit(sbt_lvJ4Mru &p)
{
	p.sbt_S = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_TpqhLLg);
	RandInit(p.sbt_dkegsSsw3);
	p.sbt_yxq6fnT = CX::Util::RndGen::Get().GetDouble();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_zJvRsze[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetBool();
}

}//namespace SB

}//namespace CX

