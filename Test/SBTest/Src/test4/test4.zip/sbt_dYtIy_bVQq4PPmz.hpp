
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_v90wMwa8Kv5LfsEk3.hpp"
#include "sbt_TFd8kvEQNcJOH.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OG.hpp"


class sbt_dYtIy_bVQq4PPmz
{
public:

	CX::SB::Vector<sbt_v90wMwa8Kv5LfsEk3>::Type sbt_0;
	CX::Int16 sbt_69UtO;
	CX::Double sbt_DeG2Q;
	CX::SB::Map<CX::Int32, CX::Int8>::Type sbt_J3Kvf;
	CX::String sbt_noBoi;
	sbt_TFd8kvEQNcJOH sbt_tvk5JpU0t;
	sbt_0b8xsQ5PynBzTQ6Z5OG sbt_vNU6I;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_dYtIy_bVQq4PPmz &p)
{
	DefInit(p.sbt_0);
	DefInit(p.sbt_69UtO);
	DefInit(p.sbt_DeG2Q);
	DefInit(p.sbt_J3Kvf);
	DefInit(p.sbt_noBoi);
	DefInit(p.sbt_tvk5JpU0t);
	DefInit(p.sbt_vNU6I);
}

template <> static inline int Compare<sbt_dYtIy_bVQq4PPmz>(const sbt_dYtIy_bVQq4PPmz &a, const sbt_dYtIy_bVQq4PPmz &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0, b.sbt_0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_69UtO, b.sbt_69UtO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_DeG2Q, b.sbt_DeG2Q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_J3Kvf, b.sbt_J3Kvf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_noBoi, b.sbt_noBoi)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tvk5JpU0t, b.sbt_tvk5JpU0t)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_vNU6I, b.sbt_vNU6I)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_dYtIy_bVQq4PPmz>(const sbt_dYtIy_bVQq4PPmz &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0, pHasher);
	Hash(p.sbt_69UtO, pHasher);
	Hash(p.sbt_DeG2Q, pHasher);
	Hash(p.sbt_J3Kvf, pHasher);
	Hash(p.sbt_noBoi, pHasher);
	Hash(p.sbt_tvk5JpU0t, pHasher);
	Hash(p.sbt_vNU6I, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_dYtIy_bVQq4PPmz>(sbt_dYtIy_bVQq4PPmz p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0", p.sbt_0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_69UtO", p.sbt_69UtO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DeG2Q", p.sbt_DeG2Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_J3Kvf", p.sbt_J3Kvf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_noBoi", p.sbt_noBoi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tvk5JpU0t", p.sbt_tvk5JpU0t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_vNU6I", p.sbt_vNU6I)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_dYtIy_bVQq4PPmz>(sbt_dYtIy_bVQq4PPmz &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0", p.sbt_0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_69UtO", p.sbt_69UtO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_DeG2Q", p.sbt_DeG2Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_J3Kvf", p.sbt_J3Kvf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_noBoi", p.sbt_noBoi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tvk5JpU0t", p.sbt_tvk5JpU0t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_vNU6I", p.sbt_vNU6I)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

