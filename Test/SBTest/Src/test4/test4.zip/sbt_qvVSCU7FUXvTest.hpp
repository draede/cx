
#pragma once


#include "sbt_qvVSCU7FUXv.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_UTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_qvVSCU7FUXv &p)
{
	TestInit(p.sbt_Auv);
	p.sbt_Rpved = -21551;
	p.sbt_VPJHrQR = 0.426180;
}

static inline void RandInit(sbt_qvVSCU7FUXv &p)
{
	RandInit(p.sbt_Auv);
	p.sbt_Rpved = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VPJHrQR = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

