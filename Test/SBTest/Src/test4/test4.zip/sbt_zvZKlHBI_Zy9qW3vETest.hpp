
#pragma once


#include "sbt_zvZKlHBI_Zy9qW3vE.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_HFZGcMbfz6GTest.hpp"
#include "sbt_blQjnFNTest.hpp"
#include "sbt_IIMFtTest.hpp"
#include "sbt_XhFoqTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_zvZKlHBI_Zy9qW3vE &p)
{
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		TestInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		TestInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	p.sbt_XJAezH4.push_back(19);
	p.sbt_n.push_back(L"aQ{");
	p.sbt_n.push_back(L"auI-3e{Uw+7I3IW");
	p.sbt_n.push_back(L"%Q1C'+IWE=]EykQ5)CsW?[}q9?y");
	p.sbt_v = -109;
}

static inline void RandInit(sbt_zvZKlHBI_Zy9qW3vE &p)
{
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_HFZGcMbfz6G k;
		sbt_blQjnFN v;

		RandInit(k);
		TestInit(v);
		p.sbt_J3M_Cbz[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		RandInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		RandInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		RandInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		RandInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	{
		sbt_IIMFt k;
		sbt_XhFoq v;

		RandInit(k);
		TestInit(v);
		p.sbt_MLSstS8[k] = v;
	}
	p.sbt_XJAezH4.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_XJAezH4.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_XJAezH4.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_XJAezH4.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_XJAezH4.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_n.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_v = CX::Util::RndGen::Get().GetInt8();
}

}//namespace SB

}//namespace CX

