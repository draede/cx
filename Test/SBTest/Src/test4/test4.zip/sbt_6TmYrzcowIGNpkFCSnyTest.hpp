
#pragma once


#include "sbt_6TmYrzcowIGNpkFCSny.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0b8xsQ5PynBzTQ6Z5OGTest.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_6TmYrzcowIGNpkFCSny &p)
{
	p.sbt_Hi5Ky = 0.625357f;
	p.sbt_SSZ = 32950;
	TestInit(p.sbt_XI8rFdx);
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_XQd.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_XQd.push_back(k);
	}
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_XQd.push_back(k);
	}
	TestInit(p.sbt_aFOoKxu);
	p.sbt_k = 55;
	p.sbt_nYTSLrn = 0.069861f;
}

static inline void RandInit(sbt_6TmYrzcowIGNpkFCSny &p)
{
	p.sbt_Hi5Ky = CX::Util::RndGen::Get().GetFloat();
	p.sbt_SSZ = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_XI8rFdx);
	{
		sbt_JsTKJfhaZmiIjNz6Y k;

		TestInit(k);
		p.sbt_XQd.push_back(k);
	}
	RandInit(p.sbt_aFOoKxu);
	p.sbt_k = CX::Util::RndGen::Get().GetInt8();
	p.sbt_nYTSLrn = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

