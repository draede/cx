
#pragma once


#include "sbt_v90wMwa8Kv5LfsEk3.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"
#include "sbt_6TmYrzcowIGNpkFCSnyTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_v90wMwa8Kv5LfsEk3 &p)
{
	p.sbt_E = -5698377563455141124;
	p.sbt_g = 0.281295;
	TestInit(p.sbt_tPt);
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	p.sbt_z_ALtGQk_ = "Cge/QqQKO%A5Q+";
}

static inline void RandInit(sbt_v90wMwa8Kv5LfsEk3 &p)
{
	p.sbt_E = CX::Util::RndGen::Get().GetInt64();
	p.sbt_g = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_tPt);
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	{
		sbt_6TmYrzcowIGNpkFCSny k;

		TestInit(k);
		p.sbt_zJg5C_M.push_back(k);
	}
	p.sbt_z_ALtGQk_ = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

