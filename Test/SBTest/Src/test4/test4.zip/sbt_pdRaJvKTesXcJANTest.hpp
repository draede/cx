
#pragma once


#include "sbt_pdRaJvKTesXcJAN.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_blQjnFNTest.hpp"
#include "sbt_JsTKJfhaZmiIjNz6YTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_pdRaJvKTesXcJAN &p)
{
	{
		sbt_blQjnFN k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_3AX[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_3AX[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_3AX[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_3AX[k] = v;
	}
	{
		sbt_blQjnFN k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		TestInit(k);
		TestInit(v);
		p.sbt_3AX[k] = v;
	}
	p.sbt_O = 0.198949f;
	p.sbt_zIF = true;
}

static inline void RandInit(sbt_pdRaJvKTesXcJAN &p)
{
	{
		sbt_blQjnFN k;
		sbt_JsTKJfhaZmiIjNz6Y v;

		RandInit(k);
		TestInit(v);
		p.sbt_3AX[k] = v;
	}
	p.sbt_O = CX::Util::RndGen::Get().GetFloat();
	p.sbt_zIF = CX::Util::RndGen::Get().GetBool();
}

}//namespace SB

}//namespace CX

