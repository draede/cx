
#pragma once


#include "sbt_rYjEZXOTRmN.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_rYjEZXOTRmN &p)
{
	TestInit(p.sbt_4L8);
	p.sbt_4oYMbEl5u = 160;
	p.sbt_I = 0.498505f;
	p.sbt_NScBfTv = 2005;
	TestInit(p.sbt_PCiEAmFu3);
	p.sbt_WcLxuAc6v = 0.644478;
	TestInit(p.sbt_dhd62);
}

static inline void RandInit(sbt_rYjEZXOTRmN &p)
{
	RandInit(p.sbt_4L8);
	p.sbt_4oYMbEl5u = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_I = CX::Util::RndGen::Get().GetFloat();
	p.sbt_NScBfTv = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_PCiEAmFu3);
	p.sbt_WcLxuAc6v = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_dhd62);
}

}//namespace SB

}//namespace CX

