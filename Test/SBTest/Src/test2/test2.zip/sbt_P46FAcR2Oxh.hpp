
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_YKAOn5i.hpp"
#include "sbt_x.hpp"
#include "sbt_zZi7NUSuTy1dp.hpp"


class sbt_P46FAcR2Oxh
{
public:

	CX::Int64 sbt_4QQiCYUqL;
	CX::UInt16 sbt_F;
	CX::WString sbt_PbxJe3jjn;
	sbt_YKAOn5i sbt_b_ZJwJDRz;
	sbt_x sbt_eqf;
	CX::String sbt_i2rRq;
	sbt_zZi7NUSuTy1dp sbt_rH7Aj;
	CX::SB::Vector<CX::UInt64>::Type sbt_wLJih;
	CX::SB::Vector<CX::Int8>::Type sbt_y;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_P46FAcR2Oxh &p)
{
	DefInit(p.sbt_4QQiCYUqL);
	DefInit(p.sbt_F);
	DefInit(p.sbt_PbxJe3jjn);
	DefInit(p.sbt_b_ZJwJDRz);
	DefInit(p.sbt_eqf);
	DefInit(p.sbt_i2rRq);
	DefInit(p.sbt_rH7Aj);
	DefInit(p.sbt_wLJih);
	DefInit(p.sbt_y);
}

template <> static inline int Compare<sbt_P46FAcR2Oxh>(const sbt_P46FAcR2Oxh &a, const sbt_P46FAcR2Oxh &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4QQiCYUqL, b.sbt_4QQiCYUqL)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F, b.sbt_F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PbxJe3jjn, b.sbt_PbxJe3jjn)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_b_ZJwJDRz, b.sbt_b_ZJwJDRz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_eqf, b.sbt_eqf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_i2rRq, b.sbt_i2rRq)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rH7Aj, b.sbt_rH7Aj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wLJih, b.sbt_wLJih)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y, b.sbt_y)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_P46FAcR2Oxh>(const sbt_P46FAcR2Oxh &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4QQiCYUqL, pHasher);
	Hash(p.sbt_F, pHasher);
	Hash(p.sbt_PbxJe3jjn, pHasher);
	Hash(p.sbt_b_ZJwJDRz, pHasher);
	Hash(p.sbt_eqf, pHasher);
	Hash(p.sbt_i2rRq, pHasher);
	Hash(p.sbt_rH7Aj, pHasher);
	Hash(p.sbt_wLJih, pHasher);
	Hash(p.sbt_y, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_P46FAcR2Oxh>(sbt_P46FAcR2Oxh p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4QQiCYUqL", p.sbt_4QQiCYUqL)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PbxJe3jjn", p.sbt_PbxJe3jjn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_b_ZJwJDRz", p.sbt_b_ZJwJDRz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_eqf", p.sbt_eqf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_i2rRq", p.sbt_i2rRq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rH7Aj", p.sbt_rH7Aj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wLJih", p.sbt_wLJih)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y", p.sbt_y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_P46FAcR2Oxh>(sbt_P46FAcR2Oxh &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4QQiCYUqL", p.sbt_4QQiCYUqL)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PbxJe3jjn", p.sbt_PbxJe3jjn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_b_ZJwJDRz", p.sbt_b_ZJwJDRz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_eqf", p.sbt_eqf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_i2rRq", p.sbt_i2rRq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rH7Aj", p.sbt_rH7Aj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wLJih", p.sbt_wLJih)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y", p.sbt_y)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

