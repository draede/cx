
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_Bu3qlIpyzGJvF.hpp"


class sbt_RccwRRbSoKp
{
public:

	CX::UInt32 sbt_NEUQ_Rm;
	sbt_Bu3qlIpyzGJvF sbt_YXU0ZAA;
	CX::SB::Vector<CX::UInt16>::Type sbt_fSpQt;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_RccwRRbSoKp &p)
{
	DefInit(p.sbt_NEUQ_Rm);
	DefInit(p.sbt_YXU0ZAA);
	DefInit(p.sbt_fSpQt);
}

template <> static inline int Compare<sbt_RccwRRbSoKp>(const sbt_RccwRRbSoKp &a, const sbt_RccwRRbSoKp &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_NEUQ_Rm, b.sbt_NEUQ_Rm)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YXU0ZAA, b.sbt_YXU0ZAA)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fSpQt, b.sbt_fSpQt)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_RccwRRbSoKp>(const sbt_RccwRRbSoKp &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_NEUQ_Rm, pHasher);
	Hash(p.sbt_YXU0ZAA, pHasher);
	Hash(p.sbt_fSpQt, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_RccwRRbSoKp>(sbt_RccwRRbSoKp p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_NEUQ_Rm", p.sbt_NEUQ_Rm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YXU0ZAA", p.sbt_YXU0ZAA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fSpQt", p.sbt_fSpQt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_RccwRRbSoKp>(sbt_RccwRRbSoKp &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_NEUQ_Rm", p.sbt_NEUQ_Rm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YXU0ZAA", p.sbt_YXU0ZAA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fSpQt", p.sbt_fSpQt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

