
#pragma once


#include "sbt_N1nMICD.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_tTest.hpp"
#include "sbt_rYjEZXOTRmNTest.hpp"
#include "sbt_xTest.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_N1nMICD &p)
{
	p.sbt_38FTXuw = -548694229;
	TestInit(p.sbt_5XZUecO2f);
	p.sbt_B9A = 0.499102f;
	{
		sbt_rYjEZXOTRmN k;

		TestInit(k);
		p.sbt_Dq4.push_back(k);
	}
	{
		sbt_x k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_TcZXwKy[k] = v;
	}
	{
		sbt_x k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_TcZXwKy[k] = v;
	}
	{
		sbt_x k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_TcZXwKy[k] = v;
	}
	p.sbt_U.push_back(0.194242f);
	p.sbt_U.push_back(0.907094f);
	p.sbt_U.push_back(0.722398f);
	p.sbt_U.push_back(0.970909f);
	p.sbt_U.push_back(0.267412f);
	p.sbt_U.push_back(0.201299f);
	p.sbt_U.push_back(0.978658f);
	p.sbt_nzB = 6618080708147027740;
	p.sbt_pLyUQtF = 699269464103566876;
	p.sbt_rsK[1800284602] = -1570360421;
	p.sbt_rsK[604780050] = 1466407407;
	p.sbt_rsK[1897310807] = -1077815386;
}

static inline void RandInit(sbt_N1nMICD &p)
{
	p.sbt_38FTXuw = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_5XZUecO2f);
	p.sbt_B9A = CX::Util::RndGen::Get().GetFloat();
	{
		sbt_rYjEZXOTRmN k;

		TestInit(k);
		p.sbt_Dq4.push_back(k);
	}
	{
		sbt_x k;
		sbt_Bu3qlIpyzGJvF v;

		RandInit(k);
		TestInit(v);
		p.sbt_TcZXwKy[k] = v;
	}
	{
		sbt_x k;
		sbt_Bu3qlIpyzGJvF v;

		RandInit(k);
		TestInit(v);
		p.sbt_TcZXwKy[k] = v;
	}
	{
		sbt_x k;
		sbt_Bu3qlIpyzGJvF v;

		RandInit(k);
		TestInit(v);
		p.sbt_TcZXwKy[k] = v;
	}
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_U.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_nzB = CX::Util::RndGen::Get().GetInt64();
	p.sbt_pLyUQtF = CX::Util::RndGen::Get().GetInt64();
	p.sbt_rsK[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_rsK[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_rsK[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

