
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_Bu3qlIpyzGJvF.hpp"
#include "sbt_rYjEZXOTRmN.hpp"


class sbt_zMOJTac0RKelo
{
public:

	CX::UInt8 sbt_N;
	CX::SB::Vector<sbt_Bu3qlIpyzGJvF>::Type sbt_ddSDPCPIJ;
	sbt_rYjEZXOTRmN sbt_m;
	CX::Int8 sbt_m92xVg1;
	CX::Int32 sbt_p;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_zMOJTac0RKelo &p)
{
	DefInit(p.sbt_N);
	DefInit(p.sbt_ddSDPCPIJ);
	DefInit(p.sbt_m);
	DefInit(p.sbt_m92xVg1);
	DefInit(p.sbt_p);
}

template <> static inline int Compare<sbt_zMOJTac0RKelo>(const sbt_zMOJTac0RKelo &a, const sbt_zMOJTac0RKelo &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_N, b.sbt_N)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ddSDPCPIJ, b.sbt_ddSDPCPIJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m, b.sbt_m)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m92xVg1, b.sbt_m92xVg1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_zMOJTac0RKelo>(const sbt_zMOJTac0RKelo &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_N, pHasher);
	Hash(p.sbt_ddSDPCPIJ, pHasher);
	Hash(p.sbt_m, pHasher);
	Hash(p.sbt_m92xVg1, pHasher);
	Hash(p.sbt_p, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_zMOJTac0RKelo>(sbt_zMOJTac0RKelo p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_N", p.sbt_N)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ddSDPCPIJ", p.sbt_ddSDPCPIJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m92xVg1", p.sbt_m92xVg1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_zMOJTac0RKelo>(sbt_zMOJTac0RKelo &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_N", p.sbt_N)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ddSDPCPIJ", p.sbt_ddSDPCPIJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m92xVg1", p.sbt_m92xVg1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

