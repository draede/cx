
#pragma once


#include "sbt_t.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_YKAOn5iTest.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_t &p)
{
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_4oZ_Yk1bv.push_back(k);
	}
	p.sbt_G6vDb[46473] = "Km=55Y}=/m?#W";
	p.sbt_G6vDb[38239] = "e}/gQ}G?#5_O9#QSg3%%=)u!um#";
	p.sbt_G6vDb[60941] = "]7)C)MiMY/!so{m3_;%y['A+'m";
	p.sbt_H[-114] = 3163806266628949410;
	p.sbt_H[-11] = 4043668360556598412;
	p.sbt_H[85] = 3158379937029572576;
	p.sbt_i329Ysd = "1QM3w'We}EU;eUeW%c1]/#uO%w";
	p.sbt_o7u_g[1918165200] = 0.921147;
	p.sbt_q = false;
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		TestInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	p.sbt_wT2e2gT = -415332272;
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_wXfB5.push_back(k);
	}
}

static inline void RandInit(sbt_t &p)
{
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_4oZ_Yk1bv.push_back(k);
	}
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_4oZ_Yk1bv.push_back(k);
	}
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_4oZ_Yk1bv.push_back(k);
	}
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_4oZ_Yk1bv.push_back(k);
	}
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_4oZ_Yk1bv.push_back(k);
	}
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6vDb[CX::Util::RndGen::Get().GetUInt16()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_H[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_i329Ysd = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_o7u_g[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_o7u_g[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_o7u_g[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_q = CX::Util::RndGen::Get().GetBool();
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		RandInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		RandInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	{
		sbt_Bu3qlIpyzGJvF k;
		sbt_Bu3qlIpyzGJvF v;

		RandInit(k);
		TestInit(v);
		p.sbt_wOBj9QaV7[k] = v;
	}
	p.sbt_wT2e2gT = CX::Util::RndGen::Get().GetInt32();
	{
		sbt_YKAOn5i k;

		TestInit(k);
		p.sbt_wXfB5.push_back(k);
	}
}

}//namespace SB

}//namespace CX

