
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_YKAOn5i.hpp"
#include "sbt_Bu3qlIpyzGJvF.hpp"


class sbt_t
{
public:

	CX::SB::Vector<sbt_YKAOn5i>::Type sbt_4oZ_Yk1bv;
	CX::SB::Map<CX::UInt16, CX::String>::Type sbt_G6vDb;
	CX::SB::Map<CX::Int8, CX::Int64>::Type sbt_H;
	CX::String sbt_i329Ysd;
	CX::SB::Map<CX::Int32, CX::Double>::Type sbt_o7u_g;
	CX::Bool sbt_q;
	CX::SB::Map<sbt_Bu3qlIpyzGJvF, sbt_Bu3qlIpyzGJvF>::Type sbt_wOBj9QaV7;
	CX::Int32 sbt_wT2e2gT;
	CX::SB::Vector<sbt_YKAOn5i>::Type sbt_wXfB5;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_t &p)
{
	DefInit(p.sbt_4oZ_Yk1bv);
	DefInit(p.sbt_G6vDb);
	DefInit(p.sbt_H);
	DefInit(p.sbt_i329Ysd);
	DefInit(p.sbt_o7u_g);
	DefInit(p.sbt_q);
	DefInit(p.sbt_wOBj9QaV7);
	DefInit(p.sbt_wT2e2gT);
	DefInit(p.sbt_wXfB5);
}

template <> static inline int Compare<sbt_t>(const sbt_t &a, const sbt_t &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4oZ_Yk1bv, b.sbt_4oZ_Yk1bv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_G6vDb, b.sbt_G6vDb)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_H, b.sbt_H)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_i329Ysd, b.sbt_i329Ysd)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_o7u_g, b.sbt_o7u_g)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_q, b.sbt_q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wOBj9QaV7, b.sbt_wOBj9QaV7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wT2e2gT, b.sbt_wT2e2gT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wXfB5, b.sbt_wXfB5)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_t>(const sbt_t &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4oZ_Yk1bv, pHasher);
	Hash(p.sbt_G6vDb, pHasher);
	Hash(p.sbt_H, pHasher);
	Hash(p.sbt_i329Ysd, pHasher);
	Hash(p.sbt_o7u_g, pHasher);
	Hash(p.sbt_q, pHasher);
	Hash(p.sbt_wOBj9QaV7, pHasher);
	Hash(p.sbt_wT2e2gT, pHasher);
	Hash(p.sbt_wXfB5, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_t>(sbt_t p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4oZ_Yk1bv", p.sbt_4oZ_Yk1bv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_G6vDb", p.sbt_G6vDb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_H", p.sbt_H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_i329Ysd", p.sbt_i329Ysd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_o7u_g", p.sbt_o7u_g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_q", p.sbt_q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wOBj9QaV7", p.sbt_wOBj9QaV7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wT2e2gT", p.sbt_wT2e2gT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wXfB5", p.sbt_wXfB5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_t>(sbt_t &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4oZ_Yk1bv", p.sbt_4oZ_Yk1bv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_G6vDb", p.sbt_G6vDb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_H", p.sbt_H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_i329Ysd", p.sbt_i329Ysd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_o7u_g", p.sbt_o7u_g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_q", p.sbt_q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wOBj9QaV7", p.sbt_wOBj9QaV7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wT2e2gT", p.sbt_wT2e2gT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wXfB5", p.sbt_wXfB5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

