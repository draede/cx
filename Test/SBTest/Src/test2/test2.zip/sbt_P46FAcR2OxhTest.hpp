
#pragma once


#include "sbt_P46FAcR2Oxh.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_YKAOn5iTest.hpp"
#include "sbt_xTest.hpp"
#include "sbt_zZi7NUSuTy1dpTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_P46FAcR2Oxh &p)
{
	p.sbt_4QQiCYUqL = 4629577347307036084;
	p.sbt_F = 27219;
	p.sbt_PbxJe3jjn = L"eyM?qe";
	TestInit(p.sbt_b_ZJwJDRz);
	TestInit(p.sbt_eqf);
	p.sbt_i2rRq = "-KiuE+w+/'ge";
	TestInit(p.sbt_rH7Aj);
	p.sbt_wLJih.push_back(13683657849385195584);
	p.sbt_wLJih.push_back(14154284160545526842);
	p.sbt_wLJih.push_back(6922060353039232536);
	p.sbt_y.push_back(105);
}

static inline void RandInit(sbt_P46FAcR2Oxh &p)
{
	p.sbt_4QQiCYUqL = CX::Util::RndGen::Get().GetInt64();
	p.sbt_F = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_PbxJe3jjn = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_b_ZJwJDRz);
	RandInit(p.sbt_eqf);
	p.sbt_i2rRq = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_rH7Aj);
	p.sbt_wLJih.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_wLJih.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_wLJih.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_wLJih.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_wLJih.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_y.push_back(CX::Util::RndGen::Get().GetInt8());
}

}//namespace SB

}//namespace CX

