
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_YKAOn5i.hpp"


class sbt_Bu3qlIpyzGJvF
{
public:

	CX::UInt32 sbt_6AY;
	CX::SB::Vector<CX::UInt64>::Type sbt_L;
	sbt_YKAOn5i sbt_R;
	sbt_YKAOn5i sbt_cfvlCsDzI;
	CX::Int32 sbt_t11;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Bu3qlIpyzGJvF &p)
{
	DefInit(p.sbt_6AY);
	DefInit(p.sbt_L);
	DefInit(p.sbt_R);
	DefInit(p.sbt_cfvlCsDzI);
	DefInit(p.sbt_t11);
}

template <> static inline int Compare<sbt_Bu3qlIpyzGJvF>(const sbt_Bu3qlIpyzGJvF &a, const sbt_Bu3qlIpyzGJvF &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6AY, b.sbt_6AY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_L, b.sbt_L)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_R, b.sbt_R)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_cfvlCsDzI, b.sbt_cfvlCsDzI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_t11, b.sbt_t11)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Bu3qlIpyzGJvF>(const sbt_Bu3qlIpyzGJvF &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6AY, pHasher);
	Hash(p.sbt_L, pHasher);
	Hash(p.sbt_R, pHasher);
	Hash(p.sbt_cfvlCsDzI, pHasher);
	Hash(p.sbt_t11, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Bu3qlIpyzGJvF>(sbt_Bu3qlIpyzGJvF p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6AY", p.sbt_6AY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_L", p.sbt_L)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_R", p.sbt_R)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_cfvlCsDzI", p.sbt_cfvlCsDzI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_t11", p.sbt_t11)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Bu3qlIpyzGJvF>(sbt_Bu3qlIpyzGJvF &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6AY", p.sbt_6AY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_L", p.sbt_L)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_R", p.sbt_R)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_cfvlCsDzI", p.sbt_cfvlCsDzI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_t11", p.sbt_t11)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

