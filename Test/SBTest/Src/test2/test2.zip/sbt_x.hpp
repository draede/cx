
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_YKAOn5i.hpp"


class sbt_x
{
public:

	CX::SB::Map<sbt_YKAOn5i, sbt_YKAOn5i>::Type sbt_9sdXPhg;
	CX::UInt8 sbt_MIkO1l2jz;
	CX::WString sbt_XBEpaPO;
	sbt_YKAOn5i sbt_o3RXgTuBz;
	CX::SB::Map<CX::Int8, CX::Int32>::Type sbt_y1yadGA;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_x &p)
{
	DefInit(p.sbt_9sdXPhg);
	DefInit(p.sbt_MIkO1l2jz);
	DefInit(p.sbt_XBEpaPO);
	DefInit(p.sbt_o3RXgTuBz);
	DefInit(p.sbt_y1yadGA);
}

template <> static inline int Compare<sbt_x>(const sbt_x &a, const sbt_x &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_9sdXPhg, b.sbt_9sdXPhg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_MIkO1l2jz, b.sbt_MIkO1l2jz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_XBEpaPO, b.sbt_XBEpaPO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_o3RXgTuBz, b.sbt_o3RXgTuBz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y1yadGA, b.sbt_y1yadGA)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_x>(const sbt_x &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_9sdXPhg, pHasher);
	Hash(p.sbt_MIkO1l2jz, pHasher);
	Hash(p.sbt_XBEpaPO, pHasher);
	Hash(p.sbt_o3RXgTuBz, pHasher);
	Hash(p.sbt_y1yadGA, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_x>(sbt_x p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9sdXPhg", p.sbt_9sdXPhg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_MIkO1l2jz", p.sbt_MIkO1l2jz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_XBEpaPO", p.sbt_XBEpaPO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_o3RXgTuBz", p.sbt_o3RXgTuBz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y1yadGA", p.sbt_y1yadGA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_x>(sbt_x &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_9sdXPhg", p.sbt_9sdXPhg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_MIkO1l2jz", p.sbt_MIkO1l2jz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_XBEpaPO", p.sbt_XBEpaPO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_o3RXgTuBz", p.sbt_o3RXgTuBz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y1yadGA", p.sbt_y1yadGA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

