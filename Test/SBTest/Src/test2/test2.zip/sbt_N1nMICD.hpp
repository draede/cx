
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_t.hpp"
#include "sbt_rYjEZXOTRmN.hpp"
#include "sbt_x.hpp"
#include "sbt_Bu3qlIpyzGJvF.hpp"


class sbt_N1nMICD
{
public:

	CX::Int32 sbt_38FTXuw;
	sbt_t sbt_5XZUecO2f;
	CX::Float sbt_B9A;
	CX::SB::Vector<sbt_rYjEZXOTRmN>::Type sbt_Dq4;
	CX::SB::Map<sbt_x, sbt_Bu3qlIpyzGJvF>::Type sbt_TcZXwKy;
	CX::SB::Vector<CX::Float>::Type sbt_U;
	CX::Int64 sbt_nzB;
	CX::Int64 sbt_pLyUQtF;
	CX::SB::Map<CX::UInt32, CX::Int32>::Type sbt_rsK;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_N1nMICD &p)
{
	DefInit(p.sbt_38FTXuw);
	DefInit(p.sbt_5XZUecO2f);
	DefInit(p.sbt_B9A);
	DefInit(p.sbt_Dq4);
	DefInit(p.sbt_TcZXwKy);
	DefInit(p.sbt_U);
	DefInit(p.sbt_nzB);
	DefInit(p.sbt_pLyUQtF);
	DefInit(p.sbt_rsK);
}

template <> static inline int Compare<sbt_N1nMICD>(const sbt_N1nMICD &a, const sbt_N1nMICD &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_38FTXuw, b.sbt_38FTXuw)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5XZUecO2f, b.sbt_5XZUecO2f)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_B9A, b.sbt_B9A)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Dq4, b.sbt_Dq4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TcZXwKy, b.sbt_TcZXwKy)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_U, b.sbt_U)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nzB, b.sbt_nzB)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pLyUQtF, b.sbt_pLyUQtF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rsK, b.sbt_rsK)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_N1nMICD>(const sbt_N1nMICD &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_38FTXuw, pHasher);
	Hash(p.sbt_5XZUecO2f, pHasher);
	Hash(p.sbt_B9A, pHasher);
	Hash(p.sbt_Dq4, pHasher);
	Hash(p.sbt_TcZXwKy, pHasher);
	Hash(p.sbt_U, pHasher);
	Hash(p.sbt_nzB, pHasher);
	Hash(p.sbt_pLyUQtF, pHasher);
	Hash(p.sbt_rsK, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_N1nMICD>(sbt_N1nMICD p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_38FTXuw", p.sbt_38FTXuw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5XZUecO2f", p.sbt_5XZUecO2f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_B9A", p.sbt_B9A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Dq4", p.sbt_Dq4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TcZXwKy", p.sbt_TcZXwKy)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nzB", p.sbt_nzB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pLyUQtF", p.sbt_pLyUQtF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rsK", p.sbt_rsK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_N1nMICD>(sbt_N1nMICD &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_38FTXuw", p.sbt_38FTXuw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5XZUecO2f", p.sbt_5XZUecO2f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_B9A", p.sbt_B9A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Dq4", p.sbt_Dq4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TcZXwKy", p.sbt_TcZXwKy)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nzB", p.sbt_nzB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pLyUQtF", p.sbt_pLyUQtF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rsK", p.sbt_rsK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

