
#pragma once


#include "sbt_Bu3qlIpyzGJvF.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_YKAOn5iTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Bu3qlIpyzGJvF &p)
{
	p.sbt_6AY = 3206403461;
	p.sbt_L.push_back(11252945105712307964);
	p.sbt_L.push_back(16763288049882906052);
	p.sbt_L.push_back(6853974004908428388);
	p.sbt_L.push_back(9930561073904341254);
	p.sbt_L.push_back(25131750533364634);
	TestInit(p.sbt_R);
	TestInit(p.sbt_cfvlCsDzI);
	p.sbt_t11 = -23082617;
}

static inline void RandInit(sbt_Bu3qlIpyzGJvF &p)
{
	p.sbt_6AY = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_L.push_back(CX::Util::RndGen::Get().GetUInt64());
	RandInit(p.sbt_R);
	RandInit(p.sbt_cfvlCsDzI);
	p.sbt_t11 = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

