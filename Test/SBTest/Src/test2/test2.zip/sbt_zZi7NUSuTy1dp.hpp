
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_RccwRRbSoKp.hpp"
#include "sbt_Bu3qlIpyzGJvF.hpp"


class sbt_zZi7NUSuTy1dp
{
public:

	CX::Int8 sbt_7;
	CX::Int8 sbt_EbD;
	CX::Float sbt_J;
	CX::SB::Vector<sbt_RccwRRbSoKp>::Type sbt_W;
	CX::UInt8 sbt_h;
	sbt_Bu3qlIpyzGJvF sbt_j;
	CX::SB::Map<CX::Double, CX::Bool>::Type sbt_m;
	CX::SB::Map<CX::Float, CX::Float>::Type sbt_n_NhjeDXN;
	sbt_Bu3qlIpyzGJvF sbt_oUYdmVB;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_zZi7NUSuTy1dp &p)
{
	DefInit(p.sbt_7);
	DefInit(p.sbt_EbD);
	DefInit(p.sbt_J);
	DefInit(p.sbt_W);
	DefInit(p.sbt_h);
	DefInit(p.sbt_j);
	DefInit(p.sbt_m);
	DefInit(p.sbt_n_NhjeDXN);
	DefInit(p.sbt_oUYdmVB);
}

template <> static inline int Compare<sbt_zZi7NUSuTy1dp>(const sbt_zZi7NUSuTy1dp &a, const sbt_zZi7NUSuTy1dp &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_7, b.sbt_7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EbD, b.sbt_EbD)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_J, b.sbt_J)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_W, b.sbt_W)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_h, b.sbt_h)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j, b.sbt_j)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m, b.sbt_m)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_n_NhjeDXN, b.sbt_n_NhjeDXN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_oUYdmVB, b.sbt_oUYdmVB)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_zZi7NUSuTy1dp>(const sbt_zZi7NUSuTy1dp &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_7, pHasher);
	Hash(p.sbt_EbD, pHasher);
	Hash(p.sbt_J, pHasher);
	Hash(p.sbt_W, pHasher);
	Hash(p.sbt_h, pHasher);
	Hash(p.sbt_j, pHasher);
	Hash(p.sbt_m, pHasher);
	Hash(p.sbt_n_NhjeDXN, pHasher);
	Hash(p.sbt_oUYdmVB, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_zZi7NUSuTy1dp>(sbt_zZi7NUSuTy1dp p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7", p.sbt_7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EbD", p.sbt_EbD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_J", p.sbt_J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_W", p.sbt_W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j", p.sbt_j)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_n_NhjeDXN", p.sbt_n_NhjeDXN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_oUYdmVB", p.sbt_oUYdmVB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_zZi7NUSuTy1dp>(sbt_zZi7NUSuTy1dp &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_7", p.sbt_7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EbD", p.sbt_EbD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_J", p.sbt_J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_W", p.sbt_W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j", p.sbt_j)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_n_NhjeDXN", p.sbt_n_NhjeDXN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_oUYdmVB", p.sbt_oUYdmVB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

