
#pragma once


#include "sbt_RccwRRbSoKp.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_RccwRRbSoKp &p)
{
	p.sbt_NEUQ_Rm = 1658339840;
	TestInit(p.sbt_YXU0ZAA);
	p.sbt_fSpQt.push_back(48655);
	p.sbt_fSpQt.push_back(55495);
	p.sbt_fSpQt.push_back(39233);
	p.sbt_fSpQt.push_back(14612);
	p.sbt_fSpQt.push_back(31777);
	p.sbt_fSpQt.push_back(56870);
	p.sbt_fSpQt.push_back(27763);
}

static inline void RandInit(sbt_RccwRRbSoKp &p)
{
	p.sbt_NEUQ_Rm = CX::Util::RndGen::Get().GetUInt32();
	RandInit(p.sbt_YXU0ZAA);
	p.sbt_fSpQt.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_fSpQt.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_fSpQt.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_fSpQt.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_fSpQt.push_back(CX::Util::RndGen::Get().GetUInt16());
}

}//namespace SB

}//namespace CX

