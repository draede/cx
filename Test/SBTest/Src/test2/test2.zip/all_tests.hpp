
#pragma once


#include "CX/SB/Tester.hpp"
#include "CX/Print.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"
#include "sbt_N1nMICDTest.hpp"
#include "sbt_P46FAcR2OxhTest.hpp"
#include "sbt_RccwRRbSoKpTest.hpp"
#include "sbt_rYjEZXOTRmNTest.hpp"
#include "sbt_tTest.hpp"
#include "sbt_xTest.hpp"
#include "sbt_YKAOn5iTest.hpp"
#include "sbt_zMOJTac0RKeloTest.hpp"
#include "sbt_zZi7NUSuTy1dpTest.hpp"


void Run_Tests()
{
	CX::SB::StatsData trd;
	CX::SB::StatsData twd;
	CX::Size cAll = 0;
	CX::Size cOK = 0;
	CX::Status status;

	trd.Reset();
	twd.Reset();
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Bu3qlIpyzGJvF>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Bu3qlIpyzGJvF failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_N1nMICD>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_N1nMICD failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_P46FAcR2Oxh>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_P46FAcR2Oxh failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_RccwRRbSoKp>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_RccwRRbSoKp failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_rYjEZXOTRmN>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_rYjEZXOTRmN failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_t>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_t failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_x>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_x failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_YKAOn5i>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_YKAOn5i failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_zMOJTac0RKelo>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_zMOJTac0RKelo failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_zZi7NUSuTy1dp>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_zZi7NUSuTy1dp failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	CX::Print(stdout, "All tests : {1}\n", cAll);
	CX::Print(stdout, "OK tests  : {1}\n", cOK);
	CX::Print(stdout, "===== READ STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", trd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", trd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", trd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", trd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", trd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", trd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", trd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", trd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", trd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", trd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", trd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", trd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", trd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", trd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", trd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", trd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", trd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", trd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", trd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {:.3} MB\n", trd.m_cbTotalSize / 1048576.0);
	CX::Print(stdout, "===== WRITE STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", twd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", twd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", twd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", twd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", twd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", twd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", twd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", twd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", twd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", twd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", twd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", twd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", twd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", twd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", twd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", twd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", twd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", twd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", twd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {1:.3} MB\n", twd.m_cbTotalSize / 1048576.0);
}
