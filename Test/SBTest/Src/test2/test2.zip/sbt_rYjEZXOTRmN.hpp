
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_Bu3qlIpyzGJvF.hpp"


class sbt_rYjEZXOTRmN
{
public:

	sbt_Bu3qlIpyzGJvF sbt_4L8;
	CX::UInt8 sbt_4oYMbEl5u;
	CX::Float sbt_I;
	CX::Int16 sbt_NScBfTv;
	sbt_Bu3qlIpyzGJvF sbt_PCiEAmFu3;
	CX::Double sbt_WcLxuAc6v;
	sbt_Bu3qlIpyzGJvF sbt_dhd62;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_rYjEZXOTRmN &p)
{
	DefInit(p.sbt_4L8);
	DefInit(p.sbt_4oYMbEl5u);
	DefInit(p.sbt_I);
	DefInit(p.sbt_NScBfTv);
	DefInit(p.sbt_PCiEAmFu3);
	DefInit(p.sbt_WcLxuAc6v);
	DefInit(p.sbt_dhd62);
}

template <> static inline int Compare<sbt_rYjEZXOTRmN>(const sbt_rYjEZXOTRmN &a, const sbt_rYjEZXOTRmN &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4L8, b.sbt_4L8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_4oYMbEl5u, b.sbt_4oYMbEl5u)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_I, b.sbt_I)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_NScBfTv, b.sbt_NScBfTv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PCiEAmFu3, b.sbt_PCiEAmFu3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_WcLxuAc6v, b.sbt_WcLxuAc6v)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_dhd62, b.sbt_dhd62)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_rYjEZXOTRmN>(const sbt_rYjEZXOTRmN &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4L8, pHasher);
	Hash(p.sbt_4oYMbEl5u, pHasher);
	Hash(p.sbt_I, pHasher);
	Hash(p.sbt_NScBfTv, pHasher);
	Hash(p.sbt_PCiEAmFu3, pHasher);
	Hash(p.sbt_WcLxuAc6v, pHasher);
	Hash(p.sbt_dhd62, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_rYjEZXOTRmN>(sbt_rYjEZXOTRmN p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4L8", p.sbt_4L8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4oYMbEl5u", p.sbt_4oYMbEl5u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_I", p.sbt_I)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_NScBfTv", p.sbt_NScBfTv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PCiEAmFu3", p.sbt_PCiEAmFu3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_WcLxuAc6v", p.sbt_WcLxuAc6v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_dhd62", p.sbt_dhd62)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_rYjEZXOTRmN>(sbt_rYjEZXOTRmN &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4L8", p.sbt_4L8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_4oYMbEl5u", p.sbt_4oYMbEl5u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_I", p.sbt_I)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_NScBfTv", p.sbt_NScBfTv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PCiEAmFu3", p.sbt_PCiEAmFu3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_WcLxuAc6v", p.sbt_WcLxuAc6v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_dhd62", p.sbt_dhd62)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

