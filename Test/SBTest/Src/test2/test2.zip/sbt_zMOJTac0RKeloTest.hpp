
#pragma once


#include "sbt_zMOJTac0RKelo.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"
#include "sbt_rYjEZXOTRmNTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_zMOJTac0RKelo &p)
{
	p.sbt_N = 238;
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	TestInit(p.sbt_m);
	p.sbt_m92xVg1 = -11;
	p.sbt_p = -193778122;
}

static inline void RandInit(sbt_zMOJTac0RKelo &p)
{
	p.sbt_N = CX::Util::RndGen::Get().GetUInt8();
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	{
		sbt_Bu3qlIpyzGJvF k;

		TestInit(k);
		p.sbt_ddSDPCPIJ.push_back(k);
	}
	RandInit(p.sbt_m);
	p.sbt_m92xVg1 = CX::Util::RndGen::Get().GetInt8();
	p.sbt_p = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

