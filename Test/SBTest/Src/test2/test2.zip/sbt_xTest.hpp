
#pragma once


#include "sbt_x.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_YKAOn5iTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_x &p)
{
	{
		sbt_YKAOn5i k;
		sbt_YKAOn5i v;

		TestInit(k);
		TestInit(v);
		p.sbt_9sdXPhg[k] = v;
	}
	{
		sbt_YKAOn5i k;
		sbt_YKAOn5i v;

		TestInit(k);
		TestInit(v);
		p.sbt_9sdXPhg[k] = v;
	}
	{
		sbt_YKAOn5i k;
		sbt_YKAOn5i v;

		TestInit(k);
		TestInit(v);
		p.sbt_9sdXPhg[k] = v;
	}
	p.sbt_MIkO1l2jz = 58;
	p.sbt_XBEpaPO = L"/I-/%;YACI!1";
	TestInit(p.sbt_o3RXgTuBz);
	p.sbt_y1yadGA[-84] = 924008286;
}

static inline void RandInit(sbt_x &p)
{
	{
		sbt_YKAOn5i k;
		sbt_YKAOn5i v;

		RandInit(k);
		TestInit(v);
		p.sbt_9sdXPhg[k] = v;
	}
	p.sbt_MIkO1l2jz = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_XBEpaPO = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_o3RXgTuBz);
	p.sbt_y1yadGA[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_y1yadGA[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_y1yadGA[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_y1yadGA[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_y1yadGA[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

