
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"


class sbt_YKAOn5i
{
public:

	CX::SB::Vector<CX::UInt32>::Type sbt_3;
	CX::Double sbt_R0M;
	CX::UInt64 sbt_y2R5l1Q7c;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_YKAOn5i &p)
{
	DefInit(p.sbt_3);
	DefInit(p.sbt_R0M);
	DefInit(p.sbt_y2R5l1Q7c);
}

template <> static inline int Compare<sbt_YKAOn5i>(const sbt_YKAOn5i &a, const sbt_YKAOn5i &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3, b.sbt_3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_R0M, b.sbt_R0M)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y2R5l1Q7c, b.sbt_y2R5l1Q7c)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_YKAOn5i>(const sbt_YKAOn5i &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3, pHasher);
	Hash(p.sbt_R0M, pHasher);
	Hash(p.sbt_y2R5l1Q7c, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_YKAOn5i>(sbt_YKAOn5i p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3", p.sbt_3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_R0M", p.sbt_R0M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y2R5l1Q7c", p.sbt_y2R5l1Q7c)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_YKAOn5i>(sbt_YKAOn5i &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3", p.sbt_3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_R0M", p.sbt_R0M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y2R5l1Q7c", p.sbt_y2R5l1Q7c)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

