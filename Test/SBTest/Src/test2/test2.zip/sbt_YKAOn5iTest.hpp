
#pragma once


#include "sbt_YKAOn5i.hpp"
#include "CX/Util/RndGen.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_YKAOn5i &p)
{
	p.sbt_3.push_back(3314113198);
	p.sbt_3.push_back(70775258);
	p.sbt_3.push_back(2447392010);
	p.sbt_3.push_back(4229281811);
	p.sbt_3.push_back(2442348529);
	p.sbt_R0M = 0.835504;
	p.sbt_y2R5l1Q7c = 15928475711827797226;
}

static inline void RandInit(sbt_YKAOn5i &p)
{
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_3.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_R0M = CX::Util::RndGen::Get().GetDouble();
	p.sbt_y2R5l1Q7c = CX::Util::RndGen::Get().GetUInt64();
}

}//namespace SB

}//namespace CX

