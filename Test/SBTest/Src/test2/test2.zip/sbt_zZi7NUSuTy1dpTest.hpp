
#pragma once


#include "sbt_zZi7NUSuTy1dp.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_RccwRRbSoKpTest.hpp"
#include "sbt_Bu3qlIpyzGJvFTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_zZi7NUSuTy1dp &p)
{
	p.sbt_7 = -40;
	p.sbt_EbD = -120;
	p.sbt_J = 0.408630f;
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	p.sbt_h = 152;
	TestInit(p.sbt_j);
	p.sbt_m[0.877142] = true;
	p.sbt_m[0.687719] = false;
	p.sbt_m[0.458932] = true;
	p.sbt_m[0.645131] = false;
	p.sbt_m[0.736999] = true;
	p.sbt_n_NhjeDXN[0.760081f] = 0.756242f;
	p.sbt_n_NhjeDXN[0.052628f] = 0.952087f;
	p.sbt_n_NhjeDXN[0.598258f] = 0.656525f;
	p.sbt_n_NhjeDXN[0.805106f] = 0.480042f;
	p.sbt_n_NhjeDXN[0.336600f] = 0.402978f;
	TestInit(p.sbt_oUYdmVB);
}

static inline void RandInit(sbt_zZi7NUSuTy1dp &p)
{
	p.sbt_7 = CX::Util::RndGen::Get().GetInt8();
	p.sbt_EbD = CX::Util::RndGen::Get().GetInt8();
	p.sbt_J = CX::Util::RndGen::Get().GetFloat();
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	{
		sbt_RccwRRbSoKp k;

		TestInit(k);
		p.sbt_W.push_back(k);
	}
	p.sbt_h = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_j);
	p.sbt_m[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_n_NhjeDXN[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_oUYdmVB);
}

}//namespace SB

}//namespace CX

