
#pragma once


#include "sbt_q.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_M5eTest.hpp"
#include "sbt_aWVTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_q &p)
{
	TestInit(p.sbt_2);
	p.sbt_SZspdub = L"CQecY=!WOyMqe!WE=W";
	TestInit(p.sbt_Ts39OIuj0);
	p.sbt_b62D_gJgP = 8314345511275314806;
	TestInit(p.sbt_f);
	p.sbt_v.push_back(false);
	p.sbt_v.push_back(false);
	p.sbt_v.push_back(true);
	p.sbt_v.push_back(true);
	p.sbt_v.push_back(false);
	p.sbt_v.push_back(true);
	p.sbt_v.push_back(false);
	p.sbt_v.push_back(false);
	p.sbt_v.push_back(false);
	p.sbt_wf1gIOs = 54;
}

static inline void RandInit(sbt_q &p)
{
	RandInit(p.sbt_2);
	p.sbt_SZspdub = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_Ts39OIuj0);
	p.sbt_b62D_gJgP = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_f);
	p.sbt_v.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_wf1gIOs = CX::Util::RndGen::Get().GetInt8();
}

}//namespace SB

}//namespace CX

