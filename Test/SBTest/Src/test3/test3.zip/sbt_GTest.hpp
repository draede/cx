
#pragma once


#include "sbt_G.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_4pQokJJuMkkTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_G &p)
{
	p.sbt_4BkEM.push_back(2028927751);
	p.sbt_H = -140614106;
	TestInit(p.sbt_TovUJ);
	TestInit(p.sbt_pd4);
	p.sbt_s = 167795627;
}

static inline void RandInit(sbt_G &p)
{
	p.sbt_4BkEM.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_4BkEM.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_4BkEM.push_back(CX::Util::RndGen::Get().GetInt32());
	p.sbt_H = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_TovUJ);
	RandInit(p.sbt_pd4);
	p.sbt_s = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

