
#pragma once


#include "sbt_rsmoHoWL9_yvLvM.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_w9UXxcuLlKoTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_rsmoHoWL9_yvLvM &p)
{
	TestInit(p.sbt_BLBbwV7ww);
}

static inline void RandInit(sbt_rsmoHoWL9_yvLvM &p)
{
	RandInit(p.sbt_BLBbwV7ww);
}

}//namespace SB

}//namespace CX

