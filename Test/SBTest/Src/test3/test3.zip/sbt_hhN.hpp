
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_aWV.hpp"
#include "sbt_q.hpp"
#include "sbt_4pQokJJuMkk.hpp"


class sbt_hhN
{
public:

	CX::Int64 sbt_4cfe3;
	sbt_aWV sbt_8r0TW;
	CX::Double sbt_P6T8c4DP5;
	CX::String sbt_Sc5Eq6G;
	CX::SB::Map<sbt_q, sbt_4pQokJJuMkk>::Type sbt__;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_hhN &p)
{
	DefInit(p.sbt_4cfe3);
	DefInit(p.sbt_8r0TW);
	DefInit(p.sbt_P6T8c4DP5);
	DefInit(p.sbt_Sc5Eq6G);
	DefInit(p.sbt__);
}

template <> static inline int Compare<sbt_hhN>(const sbt_hhN &a, const sbt_hhN &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4cfe3, b.sbt_4cfe3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_8r0TW, b.sbt_8r0TW)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_P6T8c4DP5, b.sbt_P6T8c4DP5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sc5Eq6G, b.sbt_Sc5Eq6G)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__, b.sbt__)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_hhN>(const sbt_hhN &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4cfe3, pHasher);
	Hash(p.sbt_8r0TW, pHasher);
	Hash(p.sbt_P6T8c4DP5, pHasher);
	Hash(p.sbt_Sc5Eq6G, pHasher);
	Hash(p.sbt__, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_hhN>(sbt_hhN p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4cfe3", p.sbt_4cfe3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8r0TW", p.sbt_8r0TW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_P6T8c4DP5", p.sbt_P6T8c4DP5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sc5Eq6G", p.sbt_Sc5Eq6G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_hhN>(sbt_hhN &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4cfe3", p.sbt_4cfe3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_8r0TW", p.sbt_8r0TW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_P6T8c4DP5", p.sbt_P6T8c4DP5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sc5Eq6G", p.sbt_Sc5Eq6G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__", p.sbt__)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

