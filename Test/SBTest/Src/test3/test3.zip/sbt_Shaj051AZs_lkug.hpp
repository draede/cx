
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_q.hpp"
#include "sbt_HLgxkrJiwhiZFPFl9.hpp"
#include "sbt_Yq7xpUGG9EHTsOV1oRR.hpp"


class sbt_Shaj051AZs_lkug
{
public:

	CX::SB::Map<CX::Int64, CX::WString>::Type sbt_4v78Z;
	sbt_q sbt_8RvdQDS;
	CX::UInt16 sbt_EE1CM;
	CX::SB::Vector<CX::UInt64>::Type sbt_R_oiW9B9u;
	sbt_HLgxkrJiwhiZFPFl9 sbt_Tdim5d5rM;
	CX::Float sbt_VyOAP;
	sbt_Yq7xpUGG9EHTsOV1oRR sbt__qDc02d;
	CX::Int32 sbt_a;
	CX::SB::Map<CX::Double, CX::Float>::Type sbt_pmPErj1R5;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Shaj051AZs_lkug &p)
{
	DefInit(p.sbt_4v78Z);
	DefInit(p.sbt_8RvdQDS);
	DefInit(p.sbt_EE1CM);
	DefInit(p.sbt_R_oiW9B9u);
	DefInit(p.sbt_Tdim5d5rM);
	DefInit(p.sbt_VyOAP);
	DefInit(p.sbt__qDc02d);
	DefInit(p.sbt_a);
	DefInit(p.sbt_pmPErj1R5);
}

template <> static inline int Compare<sbt_Shaj051AZs_lkug>(const sbt_Shaj051AZs_lkug &a, const sbt_Shaj051AZs_lkug &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4v78Z, b.sbt_4v78Z)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_8RvdQDS, b.sbt_8RvdQDS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EE1CM, b.sbt_EE1CM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_R_oiW9B9u, b.sbt_R_oiW9B9u)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Tdim5d5rM, b.sbt_Tdim5d5rM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VyOAP, b.sbt_VyOAP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__qDc02d, b.sbt__qDc02d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_a, b.sbt_a)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pmPErj1R5, b.sbt_pmPErj1R5)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Shaj051AZs_lkug>(const sbt_Shaj051AZs_lkug &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4v78Z, pHasher);
	Hash(p.sbt_8RvdQDS, pHasher);
	Hash(p.sbt_EE1CM, pHasher);
	Hash(p.sbt_R_oiW9B9u, pHasher);
	Hash(p.sbt_Tdim5d5rM, pHasher);
	Hash(p.sbt_VyOAP, pHasher);
	Hash(p.sbt__qDc02d, pHasher);
	Hash(p.sbt_a, pHasher);
	Hash(p.sbt_pmPErj1R5, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Shaj051AZs_lkug>(sbt_Shaj051AZs_lkug p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4v78Z", p.sbt_4v78Z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8RvdQDS", p.sbt_8RvdQDS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EE1CM", p.sbt_EE1CM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_R_oiW9B9u", p.sbt_R_oiW9B9u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Tdim5d5rM", p.sbt_Tdim5d5rM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VyOAP", p.sbt_VyOAP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__qDc02d", p.sbt__qDc02d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_a", p.sbt_a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pmPErj1R5", p.sbt_pmPErj1R5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Shaj051AZs_lkug>(sbt_Shaj051AZs_lkug &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4v78Z", p.sbt_4v78Z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_8RvdQDS", p.sbt_8RvdQDS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EE1CM", p.sbt_EE1CM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_R_oiW9B9u", p.sbt_R_oiW9B9u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Tdim5d5rM", p.sbt_Tdim5d5rM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VyOAP", p.sbt_VyOAP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__qDc02d", p.sbt__qDc02d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_a", p.sbt_a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pmPErj1R5", p.sbt_pmPErj1R5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

