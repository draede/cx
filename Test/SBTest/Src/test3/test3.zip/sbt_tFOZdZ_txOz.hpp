
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_RQIcYaFdzwqjAui.hpp"
#include "sbt_4pQokJJuMkk.hpp"


class sbt_tFOZdZ_txOz
{
public:

	CX::WString sbt_ButmB27;
	CX::UInt8 sbt_Kf3;
	sbt_RQIcYaFdzwqjAui sbt_TWAdN5Wsq;
	CX::Bool sbt_U;
	CX::SB::Vector<sbt_4pQokJJuMkk>::Type sbt_cCE9J;
	CX::UInt8 sbt_gKF021BqH;
	CX::Float sbt_h;
	sbt_RQIcYaFdzwqjAui sbt_l31QO;
	CX::UInt64 sbt_rUPveuy;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_tFOZdZ_txOz &p)
{
	DefInit(p.sbt_ButmB27);
	DefInit(p.sbt_Kf3);
	DefInit(p.sbt_TWAdN5Wsq);
	DefInit(p.sbt_U);
	DefInit(p.sbt_cCE9J);
	DefInit(p.sbt_gKF021BqH);
	DefInit(p.sbt_h);
	DefInit(p.sbt_l31QO);
	DefInit(p.sbt_rUPveuy);
}

template <> static inline int Compare<sbt_tFOZdZ_txOz>(const sbt_tFOZdZ_txOz &a, const sbt_tFOZdZ_txOz &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_ButmB27, b.sbt_ButmB27)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Kf3, b.sbt_Kf3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TWAdN5Wsq, b.sbt_TWAdN5Wsq)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_U, b.sbt_U)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_cCE9J, b.sbt_cCE9J)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gKF021BqH, b.sbt_gKF021BqH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_h, b.sbt_h)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l31QO, b.sbt_l31QO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rUPveuy, b.sbt_rUPveuy)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_tFOZdZ_txOz>(const sbt_tFOZdZ_txOz &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_ButmB27, pHasher);
	Hash(p.sbt_Kf3, pHasher);
	Hash(p.sbt_TWAdN5Wsq, pHasher);
	Hash(p.sbt_U, pHasher);
	Hash(p.sbt_cCE9J, pHasher);
	Hash(p.sbt_gKF021BqH, pHasher);
	Hash(p.sbt_h, pHasher);
	Hash(p.sbt_l31QO, pHasher);
	Hash(p.sbt_rUPveuy, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_tFOZdZ_txOz>(sbt_tFOZdZ_txOz p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ButmB27", p.sbt_ButmB27)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Kf3", p.sbt_Kf3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TWAdN5Wsq", p.sbt_TWAdN5Wsq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_cCE9J", p.sbt_cCE9J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gKF021BqH", p.sbt_gKF021BqH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l31QO", p.sbt_l31QO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rUPveuy", p.sbt_rUPveuy)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_tFOZdZ_txOz>(sbt_tFOZdZ_txOz &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_ButmB27", p.sbt_ButmB27)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Kf3", p.sbt_Kf3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TWAdN5Wsq", p.sbt_TWAdN5Wsq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_cCE9J", p.sbt_cCE9J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gKF021BqH", p.sbt_gKF021BqH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l31QO", p.sbt_l31QO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rUPveuy", p.sbt_rUPveuy)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

