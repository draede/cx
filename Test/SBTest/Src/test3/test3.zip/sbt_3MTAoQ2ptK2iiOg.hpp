
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_aWV.hpp"
#include "sbt_RQIcYaFdzwqjAui.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcb.hpp"


class sbt_3MTAoQ2ptK2iiOg
{
public:

	CX::WString sbt_21QtmBtcf;
	CX::Int8 sbt_3v8a9H7EF;
	CX::Float sbt_6sxu9e9qI;
	CX::UInt64 sbt_ERuaN;
	CX::Int32 sbt_IFn;
	sbt_aWV sbt_N;
	sbt_RQIcYaFdzwqjAui sbt_R;
	CX::String sbt_gOqLsaD;
	sbt_xBJ2EuxHbF8Qm3ScYcb sbt_qi4EdzT28;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_3MTAoQ2ptK2iiOg &p)
{
	DefInit(p.sbt_21QtmBtcf);
	DefInit(p.sbt_3v8a9H7EF);
	DefInit(p.sbt_6sxu9e9qI);
	DefInit(p.sbt_ERuaN);
	DefInit(p.sbt_IFn);
	DefInit(p.sbt_N);
	DefInit(p.sbt_R);
	DefInit(p.sbt_gOqLsaD);
	DefInit(p.sbt_qi4EdzT28);
}

template <> static inline int Compare<sbt_3MTAoQ2ptK2iiOg>(const sbt_3MTAoQ2ptK2iiOg &a, const sbt_3MTAoQ2ptK2iiOg &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_21QtmBtcf, b.sbt_21QtmBtcf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_3v8a9H7EF, b.sbt_3v8a9H7EF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6sxu9e9qI, b.sbt_6sxu9e9qI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ERuaN, b.sbt_ERuaN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_IFn, b.sbt_IFn)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_N, b.sbt_N)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_R, b.sbt_R)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gOqLsaD, b.sbt_gOqLsaD)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qi4EdzT28, b.sbt_qi4EdzT28)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_3MTAoQ2ptK2iiOg>(const sbt_3MTAoQ2ptK2iiOg &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_21QtmBtcf, pHasher);
	Hash(p.sbt_3v8a9H7EF, pHasher);
	Hash(p.sbt_6sxu9e9qI, pHasher);
	Hash(p.sbt_ERuaN, pHasher);
	Hash(p.sbt_IFn, pHasher);
	Hash(p.sbt_N, pHasher);
	Hash(p.sbt_R, pHasher);
	Hash(p.sbt_gOqLsaD, pHasher);
	Hash(p.sbt_qi4EdzT28, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_3MTAoQ2ptK2iiOg>(sbt_3MTAoQ2ptK2iiOg p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_21QtmBtcf", p.sbt_21QtmBtcf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3v8a9H7EF", p.sbt_3v8a9H7EF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6sxu9e9qI", p.sbt_6sxu9e9qI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ERuaN", p.sbt_ERuaN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_IFn", p.sbt_IFn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_N", p.sbt_N)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_R", p.sbt_R)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gOqLsaD", p.sbt_gOqLsaD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qi4EdzT28", p.sbt_qi4EdzT28)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_3MTAoQ2ptK2iiOg>(sbt_3MTAoQ2ptK2iiOg &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_21QtmBtcf", p.sbt_21QtmBtcf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_3v8a9H7EF", p.sbt_3v8a9H7EF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6sxu9e9qI", p.sbt_6sxu9e9qI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ERuaN", p.sbt_ERuaN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_IFn", p.sbt_IFn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_N", p.sbt_N)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_R", p.sbt_R)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gOqLsaD", p.sbt_gOqLsaD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qi4EdzT28", p.sbt_qi4EdzT28)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

