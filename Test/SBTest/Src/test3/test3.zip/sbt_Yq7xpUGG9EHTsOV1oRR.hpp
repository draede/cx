
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_M5e.hpp"
#include "sbt_rsmoHoWL9_yvLvM.hpp"


class sbt_Yq7xpUGG9EHTsOV1oRR
{
public:

	sbt_M5e sbt_8;
	CX::SB::Map<sbt_M5e, sbt_rsmoHoWL9_yvLvM>::Type sbt_KSDAY;
	CX::SB::Vector<CX::Int8>::Type sbt_Pdl;
	CX::Int16 sbt_U;
	CX::SB::Map<CX::UInt16, CX::Bool>::Type sbt_cSXkg;
	CX::SB::Vector<sbt_rsmoHoWL9_yvLvM>::Type sbt_ndPj_cx;
	CX::Int32 sbt_p;
	CX::UInt8 sbt_sVP;
	CX::SB::Map<CX::Float, CX::Int64>::Type sbt_wRLq3;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Yq7xpUGG9EHTsOV1oRR &p)
{
	DefInit(p.sbt_8);
	DefInit(p.sbt_KSDAY);
	DefInit(p.sbt_Pdl);
	DefInit(p.sbt_U);
	DefInit(p.sbt_cSXkg);
	DefInit(p.sbt_ndPj_cx);
	DefInit(p.sbt_p);
	DefInit(p.sbt_sVP);
	DefInit(p.sbt_wRLq3);
}

template <> static inline int Compare<sbt_Yq7xpUGG9EHTsOV1oRR>(const sbt_Yq7xpUGG9EHTsOV1oRR &a, const sbt_Yq7xpUGG9EHTsOV1oRR &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8, b.sbt_8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KSDAY, b.sbt_KSDAY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Pdl, b.sbt_Pdl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_U, b.sbt_U)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_cSXkg, b.sbt_cSXkg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ndPj_cx, b.sbt_ndPj_cx)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_sVP, b.sbt_sVP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wRLq3, b.sbt_wRLq3)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Yq7xpUGG9EHTsOV1oRR>(const sbt_Yq7xpUGG9EHTsOV1oRR &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8, pHasher);
	Hash(p.sbt_KSDAY, pHasher);
	Hash(p.sbt_Pdl, pHasher);
	Hash(p.sbt_U, pHasher);
	Hash(p.sbt_cSXkg, pHasher);
	Hash(p.sbt_ndPj_cx, pHasher);
	Hash(p.sbt_p, pHasher);
	Hash(p.sbt_sVP, pHasher);
	Hash(p.sbt_wRLq3, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Yq7xpUGG9EHTsOV1oRR>(sbt_Yq7xpUGG9EHTsOV1oRR p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KSDAY", p.sbt_KSDAY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Pdl", p.sbt_Pdl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_cSXkg", p.sbt_cSXkg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ndPj_cx", p.sbt_ndPj_cx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_sVP", p.sbt_sVP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wRLq3", p.sbt_wRLq3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Yq7xpUGG9EHTsOV1oRR>(sbt_Yq7xpUGG9EHTsOV1oRR &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KSDAY", p.sbt_KSDAY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Pdl", p.sbt_Pdl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_U", p.sbt_U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_cSXkg", p.sbt_cSXkg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ndPj_cx", p.sbt_ndPj_cx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_sVP", p.sbt_sVP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wRLq3", p.sbt_wRLq3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

