
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_w9UXxcuLlKo.hpp"
#include "sbt_Yq7xpUGG9EHTsOV1oRR.hpp"
#include "sbt_ulu.hpp"
#include "sbt_AbAtHD1hlEGM3.hpp"


class sbt_RQIcYaFdzwqjAui
{
public:

	CX::String sbt_9bgUh;
	sbt_w9UXxcuLlKo sbt_Rpy;
	CX::Float sbt_Vmb_r;
	sbt_Yq7xpUGG9EHTsOV1oRR sbt_cD2VAKZ;
	CX::Int32 sbt_eZMa0FQ;
	CX::SB::Map<CX::Int64, CX::Int32>::Type sbt_fXspkYtqJ;
	CX::Double sbt_jq7Cu;
	CX::Int64 sbt_pAO;
	CX::SB::Map<sbt_ulu, sbt_AbAtHD1hlEGM3>::Type sbt_xx613j3nN;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_RQIcYaFdzwqjAui &p)
{
	DefInit(p.sbt_9bgUh);
	DefInit(p.sbt_Rpy);
	DefInit(p.sbt_Vmb_r);
	DefInit(p.sbt_cD2VAKZ);
	DefInit(p.sbt_eZMa0FQ);
	DefInit(p.sbt_fXspkYtqJ);
	DefInit(p.sbt_jq7Cu);
	DefInit(p.sbt_pAO);
	DefInit(p.sbt_xx613j3nN);
}

template <> static inline int Compare<sbt_RQIcYaFdzwqjAui>(const sbt_RQIcYaFdzwqjAui &a, const sbt_RQIcYaFdzwqjAui &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_9bgUh, b.sbt_9bgUh)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Rpy, b.sbt_Rpy)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Vmb_r, b.sbt_Vmb_r)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_cD2VAKZ, b.sbt_cD2VAKZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_eZMa0FQ, b.sbt_eZMa0FQ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fXspkYtqJ, b.sbt_fXspkYtqJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jq7Cu, b.sbt_jq7Cu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pAO, b.sbt_pAO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_xx613j3nN, b.sbt_xx613j3nN)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_RQIcYaFdzwqjAui>(const sbt_RQIcYaFdzwqjAui &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_9bgUh, pHasher);
	Hash(p.sbt_Rpy, pHasher);
	Hash(p.sbt_Vmb_r, pHasher);
	Hash(p.sbt_cD2VAKZ, pHasher);
	Hash(p.sbt_eZMa0FQ, pHasher);
	Hash(p.sbt_fXspkYtqJ, pHasher);
	Hash(p.sbt_jq7Cu, pHasher);
	Hash(p.sbt_pAO, pHasher);
	Hash(p.sbt_xx613j3nN, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_RQIcYaFdzwqjAui>(sbt_RQIcYaFdzwqjAui p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9bgUh", p.sbt_9bgUh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Rpy", p.sbt_Rpy)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Vmb_r", p.sbt_Vmb_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_cD2VAKZ", p.sbt_cD2VAKZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_eZMa0FQ", p.sbt_eZMa0FQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fXspkYtqJ", p.sbt_fXspkYtqJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jq7Cu", p.sbt_jq7Cu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pAO", p.sbt_pAO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_xx613j3nN", p.sbt_xx613j3nN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_RQIcYaFdzwqjAui>(sbt_RQIcYaFdzwqjAui &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_9bgUh", p.sbt_9bgUh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Rpy", p.sbt_Rpy)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Vmb_r", p.sbt_Vmb_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_cD2VAKZ", p.sbt_cD2VAKZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_eZMa0FQ", p.sbt_eZMa0FQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fXspkYtqJ", p.sbt_fXspkYtqJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jq7Cu", p.sbt_jq7Cu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pAO", p.sbt_pAO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_xx613j3nN", p.sbt_xx613j3nN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

