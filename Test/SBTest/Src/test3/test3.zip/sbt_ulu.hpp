
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_Shaj051AZs_lkug.hpp"
#include "sbt_q.hpp"


class sbt_ulu
{
public:

	CX::Int32 sbt_BrAAKrMvs;
	CX::UInt32 sbt_HTq;
	CX::Bool sbt_OLACEZFUv;
	sbt_Shaj051AZs_lkug sbt_OLYu_;
	CX::Bool sbt_VVu;
	sbt_q sbt_a4nGcZ3;
	CX::Int32 sbt_p;
	sbt_Shaj051AZs_lkug sbt_t;
	CX::Int8 sbt_z;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_ulu &p)
{
	DefInit(p.sbt_BrAAKrMvs);
	DefInit(p.sbt_HTq);
	DefInit(p.sbt_OLACEZFUv);
	DefInit(p.sbt_OLYu_);
	DefInit(p.sbt_VVu);
	DefInit(p.sbt_a4nGcZ3);
	DefInit(p.sbt_p);
	DefInit(p.sbt_t);
	DefInit(p.sbt_z);
}

template <> static inline int Compare<sbt_ulu>(const sbt_ulu &a, const sbt_ulu &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_BrAAKrMvs, b.sbt_BrAAKrMvs)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_HTq, b.sbt_HTq)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_OLACEZFUv, b.sbt_OLACEZFUv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_OLYu_, b.sbt_OLYu_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VVu, b.sbt_VVu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_a4nGcZ3, b.sbt_a4nGcZ3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_t, b.sbt_t)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_z, b.sbt_z)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_ulu>(const sbt_ulu &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_BrAAKrMvs, pHasher);
	Hash(p.sbt_HTq, pHasher);
	Hash(p.sbt_OLACEZFUv, pHasher);
	Hash(p.sbt_OLYu_, pHasher);
	Hash(p.sbt_VVu, pHasher);
	Hash(p.sbt_a4nGcZ3, pHasher);
	Hash(p.sbt_p, pHasher);
	Hash(p.sbt_t, pHasher);
	Hash(p.sbt_z, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_ulu>(sbt_ulu p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BrAAKrMvs", p.sbt_BrAAKrMvs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_HTq", p.sbt_HTq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_OLACEZFUv", p.sbt_OLACEZFUv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_OLYu_", p.sbt_OLYu_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VVu", p.sbt_VVu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_a4nGcZ3", p.sbt_a4nGcZ3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_t", p.sbt_t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_z", p.sbt_z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_ulu>(sbt_ulu &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_BrAAKrMvs", p.sbt_BrAAKrMvs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_HTq", p.sbt_HTq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_OLACEZFUv", p.sbt_OLACEZFUv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_OLYu_", p.sbt_OLYu_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VVu", p.sbt_VVu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_a4nGcZ3", p.sbt_a4nGcZ3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_t", p.sbt_t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_z", p.sbt_z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

