
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_RQIcYaFdzwqjAui.hpp"


class sbt_uGEyjJ9Oa
{
public:

	CX::UInt16 sbt_1gsce93Rd;
	CX::SB::Vector<sbt_RQIcYaFdzwqjAui>::Type sbt_9QIQhu3jz;
	CX::Float sbt_DC0;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_uGEyjJ9Oa &p)
{
	DefInit(p.sbt_1gsce93Rd);
	DefInit(p.sbt_9QIQhu3jz);
	DefInit(p.sbt_DC0);
}

template <> static inline int Compare<sbt_uGEyjJ9Oa>(const sbt_uGEyjJ9Oa &a, const sbt_uGEyjJ9Oa &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1gsce93Rd, b.sbt_1gsce93Rd)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_9QIQhu3jz, b.sbt_9QIQhu3jz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_DC0, b.sbt_DC0)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_uGEyjJ9Oa>(const sbt_uGEyjJ9Oa &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1gsce93Rd, pHasher);
	Hash(p.sbt_9QIQhu3jz, pHasher);
	Hash(p.sbt_DC0, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_uGEyjJ9Oa>(sbt_uGEyjJ9Oa p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1gsce93Rd", p.sbt_1gsce93Rd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9QIQhu3jz", p.sbt_9QIQhu3jz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DC0", p.sbt_DC0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_uGEyjJ9Oa>(sbt_uGEyjJ9Oa &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1gsce93Rd", p.sbt_1gsce93Rd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_9QIQhu3jz", p.sbt_9QIQhu3jz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_DC0", p.sbt_DC0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

