
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_rsmoHoWL9_yvLvM.hpp"


class sbt_M5e
{
public:

	CX::String sbt_EWa__0o;
	CX::Int16 sbt_G6fNO;
	CX::UInt64 sbt_K;
	sbt_rsmoHoWL9_yvLvM sbt_f1WKFJ7;
	sbt_rsmoHoWL9_yvLvM sbt_zTf;
	CX::SB::Map<sbt_rsmoHoWL9_yvLvM, sbt_rsmoHoWL9_yvLvM>::Type sbt_zUHcut5;
	CX::UInt32 sbt_zmW;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_M5e &p)
{
	DefInit(p.sbt_EWa__0o);
	DefInit(p.sbt_G6fNO);
	DefInit(p.sbt_K);
	DefInit(p.sbt_f1WKFJ7);
	DefInit(p.sbt_zTf);
	DefInit(p.sbt_zUHcut5);
	DefInit(p.sbt_zmW);
}

template <> static inline int Compare<sbt_M5e>(const sbt_M5e &a, const sbt_M5e &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_EWa__0o, b.sbt_EWa__0o)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_G6fNO, b.sbt_G6fNO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_K, b.sbt_K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_f1WKFJ7, b.sbt_f1WKFJ7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zTf, b.sbt_zTf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zUHcut5, b.sbt_zUHcut5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zmW, b.sbt_zmW)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_M5e>(const sbt_M5e &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_EWa__0o, pHasher);
	Hash(p.sbt_G6fNO, pHasher);
	Hash(p.sbt_K, pHasher);
	Hash(p.sbt_f1WKFJ7, pHasher);
	Hash(p.sbt_zTf, pHasher);
	Hash(p.sbt_zUHcut5, pHasher);
	Hash(p.sbt_zmW, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_M5e>(sbt_M5e p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EWa__0o", p.sbt_EWa__0o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_G6fNO", p.sbt_G6fNO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_K", p.sbt_K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_f1WKFJ7", p.sbt_f1WKFJ7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zTf", p.sbt_zTf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zUHcut5", p.sbt_zUHcut5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zmW", p.sbt_zmW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_M5e>(sbt_M5e &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_EWa__0o", p.sbt_EWa__0o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_G6fNO", p.sbt_G6fNO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_K", p.sbt_K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_f1WKFJ7", p.sbt_f1WKFJ7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zTf", p.sbt_zTf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zUHcut5", p.sbt_zUHcut5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zmW", p.sbt_zmW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

