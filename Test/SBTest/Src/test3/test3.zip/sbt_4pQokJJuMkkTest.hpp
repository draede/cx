
#pragma once


#include "sbt_4pQokJJuMkk.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_qTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_4pQokJJuMkk &p)
{
	TestInit(p.sbt___gYC5s);
}

static inline void RandInit(sbt_4pQokJJuMkk &p)
{
	RandInit(p.sbt___gYC5s);
}

}//namespace SB

}//namespace CX

