
#pragma once


#include "sbt_HLgxkrJiwhiZFPFl9.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_M5eTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_HLgxkrJiwhiZFPFl9 &p)
{
	p.sbt_8iC = -77;
	p.sbt_9N9 = 51939;
	TestInit(p.sbt_Eae);
}

static inline void RandInit(sbt_HLgxkrJiwhiZFPFl9 &p)
{
	p.sbt_8iC = CX::Util::RndGen::Get().GetInt8();
	p.sbt_9N9 = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_Eae);
}

}//namespace SB

}//namespace CX

