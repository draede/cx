
#pragma once


#include "sbt_M5e.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_rsmoHoWL9_yvLvMTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_M5e &p)
{
	p.sbt_EWa__0o = "i;SmK#3u]'!'kA5;M3e95#wCK59U";
	p.sbt_G6fNO = 19132;
	p.sbt_K = 16713626188954540020;
	TestInit(p.sbt_f1WKFJ7);
	TestInit(p.sbt_zTf);
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	p.sbt_zmW = 1060782384;
}

static inline void RandInit(sbt_M5e &p)
{
	p.sbt_EWa__0o = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G6fNO = CX::Util::RndGen::Get().GetInt16();
	p.sbt_K = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_f1WKFJ7);
	RandInit(p.sbt_zTf);
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	{
		sbt_rsmoHoWL9_yvLvM k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_zUHcut5[k] = v;
	}
	p.sbt_zmW = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

