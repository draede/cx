
#pragma once


#include "sbt_aWV.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_w9UXxcuLlKoTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_aWV &p)
{
	p.sbt_73wNCr_ = 2122189011;
	p.sbt_D.push_back(false);
	p.sbt_D.push_back(false);
	p.sbt_D.push_back(true);
	p.sbt_D.push_back(true);
	p.sbt_D.push_back(false);
	p.sbt_D.push_back(true);
	p.sbt_D.push_back(true);
	p.sbt_D.push_back(true);
	p.sbt_D.push_back(false);
	TestInit(p.sbt_T6GfkaNRZ);
	p.sbt_f7CILsse9 = true;
	TestInit(p.sbt_w);
}

static inline void RandInit(sbt_aWV &p)
{
	p.sbt_73wNCr_ = CX::Util::RndGen::Get().GetInt32();
	p.sbt_D.push_back(CX::Util::RndGen::Get().GetBool());
	RandInit(p.sbt_T6GfkaNRZ);
	p.sbt_f7CILsse9 = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_w);
}

}//namespace SB

}//namespace CX

