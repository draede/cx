
#pragma once


#include "sbt_w9UXxcuLlKo.hpp"
#include "CX/Util/RndGen.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_w9UXxcuLlKo &p)
{
	p.sbt_0o5E_xt = 674663226;
	p.sbt_9 = 1944877120;
	p.sbt_CCZwmfo = 122;
	p.sbt_PHC8t4nfP = 0.141407;
	p.sbt_Sez = false;
	p.sbt_gyO5_ = 0.128564f;
	p.sbt_l = 0.814304;
}

static inline void RandInit(sbt_w9UXxcuLlKo &p)
{
	p.sbt_0o5E_xt = CX::Util::RndGen::Get().GetInt32();
	p.sbt_9 = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_CCZwmfo = CX::Util::RndGen::Get().GetInt8();
	p.sbt_PHC8t4nfP = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Sez = CX::Util::RndGen::Get().GetBool();
	p.sbt_gyO5_ = CX::Util::RndGen::Get().GetFloat();
	p.sbt_l = CX::Util::RndGen::Get().GetDouble();
}

}//namespace SB

}//namespace CX

