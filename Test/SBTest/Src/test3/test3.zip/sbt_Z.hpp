
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcb.hpp"
#include "sbt_rsmoHoWL9_yvLvM.hpp"


class sbt_Z
{
public:

	CX::Int8 sbt_0;
	CX::SB::Vector<sbt_xBJ2EuxHbF8Qm3ScYcb>::Type sbt_5YdltaFeS;
	CX::UInt64 sbt_Bm2HeVi;
	CX::Int16 sbt_C;
	CX::UInt16 sbt_M;
	CX::Int32 sbt_UGT;
	sbt_rsmoHoWL9_yvLvM sbt_ZIvKj;
	sbt_rsmoHoWL9_yvLvM sbt_nM4CZ;
	CX::SB::Map<CX::Int8, CX::UInt8>::Type sbt_sZJX7;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Z &p)
{
	DefInit(p.sbt_0);
	DefInit(p.sbt_5YdltaFeS);
	DefInit(p.sbt_Bm2HeVi);
	DefInit(p.sbt_C);
	DefInit(p.sbt_M);
	DefInit(p.sbt_UGT);
	DefInit(p.sbt_ZIvKj);
	DefInit(p.sbt_nM4CZ);
	DefInit(p.sbt_sZJX7);
}

template <> static inline int Compare<sbt_Z>(const sbt_Z &a, const sbt_Z &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0, b.sbt_0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5YdltaFeS, b.sbt_5YdltaFeS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Bm2HeVi, b.sbt_Bm2HeVi)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_C, b.sbt_C)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_M, b.sbt_M)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UGT, b.sbt_UGT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ZIvKj, b.sbt_ZIvKj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nM4CZ, b.sbt_nM4CZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_sZJX7, b.sbt_sZJX7)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Z>(const sbt_Z &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0, pHasher);
	Hash(p.sbt_5YdltaFeS, pHasher);
	Hash(p.sbt_Bm2HeVi, pHasher);
	Hash(p.sbt_C, pHasher);
	Hash(p.sbt_M, pHasher);
	Hash(p.sbt_UGT, pHasher);
	Hash(p.sbt_ZIvKj, pHasher);
	Hash(p.sbt_nM4CZ, pHasher);
	Hash(p.sbt_sZJX7, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Z>(sbt_Z p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0", p.sbt_0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5YdltaFeS", p.sbt_5YdltaFeS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Bm2HeVi", p.sbt_Bm2HeVi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_C", p.sbt_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_M", p.sbt_M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UGT", p.sbt_UGT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ZIvKj", p.sbt_ZIvKj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nM4CZ", p.sbt_nM4CZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_sZJX7", p.sbt_sZJX7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Z>(sbt_Z &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0", p.sbt_0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5YdltaFeS", p.sbt_5YdltaFeS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Bm2HeVi", p.sbt_Bm2HeVi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_C", p.sbt_C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_M", p.sbt_M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UGT", p.sbt_UGT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ZIvKj", p.sbt_ZIvKj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nM4CZ", p.sbt_nM4CZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_sZJX7", p.sbt_sZJX7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

