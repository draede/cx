
#pragma once


#include "sbt_ulu.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_Shaj051AZs_lkugTest.hpp"
#include "sbt_qTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_ulu &p)
{
	p.sbt_BrAAKrMvs = -553446652;
	p.sbt_HTq = 3925783054;
	p.sbt_OLACEZFUv = false;
	TestInit(p.sbt_OLYu_);
	p.sbt_VVu = false;
	TestInit(p.sbt_a4nGcZ3);
	p.sbt_p = -181672102;
	TestInit(p.sbt_t);
	p.sbt_z = 39;
}

static inline void RandInit(sbt_ulu &p)
{
	p.sbt_BrAAKrMvs = CX::Util::RndGen::Get().GetInt32();
	p.sbt_HTq = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_OLACEZFUv = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_OLYu_);
	p.sbt_VVu = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_a4nGcZ3);
	p.sbt_p = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_t);
	p.sbt_z = CX::Util::RndGen::Get().GetInt8();
}

}//namespace SB

}//namespace CX

