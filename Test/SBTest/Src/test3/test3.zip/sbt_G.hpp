
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_4pQokJJuMkk.hpp"


class sbt_G
{
public:

	CX::SB::Vector<CX::Int32>::Type sbt_4BkEM;
	CX::Int32 sbt_H;
	sbt_4pQokJJuMkk sbt_TovUJ;
	sbt_4pQokJJuMkk sbt_pd4;
	CX::UInt32 sbt_s;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_G &p)
{
	DefInit(p.sbt_4BkEM);
	DefInit(p.sbt_H);
	DefInit(p.sbt_TovUJ);
	DefInit(p.sbt_pd4);
	DefInit(p.sbt_s);
}

template <> static inline int Compare<sbt_G>(const sbt_G &a, const sbt_G &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4BkEM, b.sbt_4BkEM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_H, b.sbt_H)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TovUJ, b.sbt_TovUJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pd4, b.sbt_pd4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_s, b.sbt_s)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_G>(const sbt_G &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4BkEM, pHasher);
	Hash(p.sbt_H, pHasher);
	Hash(p.sbt_TovUJ, pHasher);
	Hash(p.sbt_pd4, pHasher);
	Hash(p.sbt_s, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_G>(sbt_G p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4BkEM", p.sbt_4BkEM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_H", p.sbt_H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TovUJ", p.sbt_TovUJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pd4", p.sbt_pd4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_s", p.sbt_s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_G>(sbt_G &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4BkEM", p.sbt_4BkEM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_H", p.sbt_H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TovUJ", p.sbt_TovUJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pd4", p.sbt_pd4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_s", p.sbt_s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

