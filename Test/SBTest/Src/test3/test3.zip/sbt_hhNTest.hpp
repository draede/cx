
#pragma once


#include "sbt_hhN.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_aWVTest.hpp"
#include "sbt_qTest.hpp"
#include "sbt_4pQokJJuMkkTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_hhN &p)
{
	p.sbt_4cfe3 = -5386454999746016302;
	TestInit(p.sbt_8r0TW);
	p.sbt_P6T8c4DP5 = 0.179771;
	p.sbt_Sc5Eq6G = "_u+G-OGQQ%sG";
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		TestInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
}

static inline void RandInit(sbt_hhN &p)
{
	p.sbt_4cfe3 = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_8r0TW);
	p.sbt_P6T8c4DP5 = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Sc5Eq6G = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
	{
		sbt_q k;
		sbt_4pQokJJuMkk v;

		RandInit(k);
		TestInit(v);
		p.sbt__[k] = v;
	}
}

}//namespace SB

}//namespace CX

