
#pragma once


#include "sbt_AbAtHD1hlEGM3.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_HLgxkrJiwhiZFPFl9Test.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcbTest.hpp"
#include "sbt_7ReUkTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_AbAtHD1hlEGM3 &p)
{
	TestInit(p.sbt_4);
	TestInit(p.sbt_6WhYlY2T6);
	p.sbt_6xuAUggp0 = -3944;
	p.sbt_N63gXFrGz = 88;
	p.sbt_SwJ87 = L"E9uc!5CkguAoI?MgC-;#Sw7ueCwu";
	TestInit(p.sbt_c9FNE);
	p.sbt_iKe[0.296505] = -6320259119371207920;
}

static inline void RandInit(sbt_AbAtHD1hlEGM3 &p)
{
	RandInit(p.sbt_4);
	RandInit(p.sbt_6WhYlY2T6);
	p.sbt_6xuAUggp0 = CX::Util::RndGen::Get().GetInt16();
	p.sbt_N63gXFrGz = CX::Util::RndGen::Get().GetInt8();
	p.sbt_SwJ87 = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_c9FNE);
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_iKe[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt64();
}

}//namespace SB

}//namespace CX

