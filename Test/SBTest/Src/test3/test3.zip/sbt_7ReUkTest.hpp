
#pragma once


#include "sbt_7ReUk.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_M5eTest.hpp"
#include "sbt_aWVTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_7ReUk &p)
{
	p.sbt_IRG = true;
	TestInit(p.sbt_MDZ);
	p.sbt_Rp_ = -6305043794313360366;
	p.sbt_m = 57;
	TestInit(p.sbt_z);
}

static inline void RandInit(sbt_7ReUk &p)
{
	p.sbt_IRG = CX::Util::RndGen::Get().GetBool();
	RandInit(p.sbt_MDZ);
	p.sbt_Rp_ = CX::Util::RndGen::Get().GetInt64();
	p.sbt_m = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_z);
}

}//namespace SB

}//namespace CX

