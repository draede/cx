
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_w9UXxcuLlKo.hpp"


class sbt_aWV
{
public:

	CX::Int32 sbt_73wNCr_;
	CX::SB::Vector<CX::Bool>::Type sbt_D;
	sbt_w9UXxcuLlKo sbt_T6GfkaNRZ;
	CX::Bool sbt_f7CILsse9;
	sbt_w9UXxcuLlKo sbt_w;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_aWV &p)
{
	DefInit(p.sbt_73wNCr_);
	DefInit(p.sbt_D);
	DefInit(p.sbt_T6GfkaNRZ);
	DefInit(p.sbt_f7CILsse9);
	DefInit(p.sbt_w);
}

template <> static inline int Compare<sbt_aWV>(const sbt_aWV &a, const sbt_aWV &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_73wNCr_, b.sbt_73wNCr_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_D, b.sbt_D)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_T6GfkaNRZ, b.sbt_T6GfkaNRZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_f7CILsse9, b.sbt_f7CILsse9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_w, b.sbt_w)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_aWV>(const sbt_aWV &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_73wNCr_, pHasher);
	Hash(p.sbt_D, pHasher);
	Hash(p.sbt_T6GfkaNRZ, pHasher);
	Hash(p.sbt_f7CILsse9, pHasher);
	Hash(p.sbt_w, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_aWV>(sbt_aWV p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_73wNCr_", p.sbt_73wNCr_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_D", p.sbt_D)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_T6GfkaNRZ", p.sbt_T6GfkaNRZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_f7CILsse9", p.sbt_f7CILsse9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_w", p.sbt_w)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_aWV>(sbt_aWV &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_73wNCr_", p.sbt_73wNCr_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_D", p.sbt_D)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_T6GfkaNRZ", p.sbt_T6GfkaNRZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_f7CILsse9", p.sbt_f7CILsse9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_w", p.sbt_w)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

