
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_M5e.hpp"
#include "sbt_aWV.hpp"


class sbt_7ReUk
{
public:

	CX::Bool sbt_IRG;
	sbt_M5e sbt_MDZ;
	CX::Int64 sbt_Rp_;
	CX::Int8 sbt_m;
	sbt_aWV sbt_z;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_7ReUk &p)
{
	DefInit(p.sbt_IRG);
	DefInit(p.sbt_MDZ);
	DefInit(p.sbt_Rp_);
	DefInit(p.sbt_m);
	DefInit(p.sbt_z);
}

template <> static inline int Compare<sbt_7ReUk>(const sbt_7ReUk &a, const sbt_7ReUk &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_IRG, b.sbt_IRG)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_MDZ, b.sbt_MDZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Rp_, b.sbt_Rp_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m, b.sbt_m)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_z, b.sbt_z)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_7ReUk>(const sbt_7ReUk &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_IRG, pHasher);
	Hash(p.sbt_MDZ, pHasher);
	Hash(p.sbt_Rp_, pHasher);
	Hash(p.sbt_m, pHasher);
	Hash(p.sbt_z, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_7ReUk>(sbt_7ReUk p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_IRG", p.sbt_IRG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_MDZ", p.sbt_MDZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Rp_", p.sbt_Rp_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_z", p.sbt_z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_7ReUk>(sbt_7ReUk &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_IRG", p.sbt_IRG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_MDZ", p.sbt_MDZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Rp_", p.sbt_Rp_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m", p.sbt_m)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_z", p.sbt_z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

