
#pragma once


#include "sbt_3MTAoQ2ptK2iiOg.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_aWVTest.hpp"
#include "sbt_RQIcYaFdzwqjAuiTest.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcbTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_3MTAoQ2ptK2iiOg &p)
{
	p.sbt_21QtmBtcf = L"3}I?o9m+S;?W%+kkKIam'}]kK%=a_";
	p.sbt_3v8a9H7EF = 40;
	p.sbt_6sxu9e9qI = 0.483060f;
	p.sbt_ERuaN = 18090252539153216996;
	p.sbt_IFn = -271918418;
	TestInit(p.sbt_N);
	TestInit(p.sbt_R);
	p.sbt_gOqLsaD = "3uU]O3y#E9uy{EE";
	TestInit(p.sbt_qi4EdzT28);
}

static inline void RandInit(sbt_3MTAoQ2ptK2iiOg &p)
{
	p.sbt_21QtmBtcf = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_3v8a9H7EF = CX::Util::RndGen::Get().GetInt8();
	p.sbt_6sxu9e9qI = CX::Util::RndGen::Get().GetFloat();
	p.sbt_ERuaN = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_IFn = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_N);
	RandInit(p.sbt_R);
	p.sbt_gOqLsaD = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_qi4EdzT28);
}

}//namespace SB

}//namespace CX

