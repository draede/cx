
#pragma once


#include "sbt_Z.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcbTest.hpp"
#include "sbt_rsmoHoWL9_yvLvMTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Z &p)
{
	p.sbt_0 = -27;
	{
		sbt_xBJ2EuxHbF8Qm3ScYcb k;

		TestInit(k);
		p.sbt_5YdltaFeS.push_back(k);
	}
	{
		sbt_xBJ2EuxHbF8Qm3ScYcb k;

		TestInit(k);
		p.sbt_5YdltaFeS.push_back(k);
	}
	{
		sbt_xBJ2EuxHbF8Qm3ScYcb k;

		TestInit(k);
		p.sbt_5YdltaFeS.push_back(k);
	}
	p.sbt_Bm2HeVi = 15487014574831843184;
	p.sbt_C = 3755;
	p.sbt_M = 54785;
	p.sbt_UGT = 1243410861;
	TestInit(p.sbt_ZIvKj);
	TestInit(p.sbt_nM4CZ);
	p.sbt_sZJX7[98] = 175;
	p.sbt_sZJX7[52] = 16;
	p.sbt_sZJX7[-86] = 180;
	p.sbt_sZJX7[49] = 203;
	p.sbt_sZJX7[104] = 227;
}

static inline void RandInit(sbt_Z &p)
{
	p.sbt_0 = CX::Util::RndGen::Get().GetInt8();
	{
		sbt_xBJ2EuxHbF8Qm3ScYcb k;

		TestInit(k);
		p.sbt_5YdltaFeS.push_back(k);
	}
	p.sbt_Bm2HeVi = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_C = CX::Util::RndGen::Get().GetInt16();
	p.sbt_M = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_UGT = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_ZIvKj);
	RandInit(p.sbt_nM4CZ);
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_sZJX7[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetUInt8();
}

}//namespace SB

}//namespace CX

