
#pragma once


#include "CX/SB/Tester.hpp"
#include "CX/Print.hpp"
#include "sbt_3MTAoQ2ptK2iiOgTest.hpp"
#include "sbt_4pQokJJuMkkTest.hpp"
#include "sbt_7ReUkTest.hpp"
#include "sbt_AbAtHD1hlEGM3Test.hpp"
#include "sbt_aWVTest.hpp"
#include "sbt_GTest.hpp"
#include "sbt_hhNTest.hpp"
#include "sbt_HLgxkrJiwhiZFPFl9Test.hpp"
#include "sbt_M5eTest.hpp"
#include "sbt_qTest.hpp"
#include "sbt_RQIcYaFdzwqjAuiTest.hpp"
#include "sbt_rsmoHoWL9_yvLvMTest.hpp"
#include "sbt_Shaj051AZs_lkugTest.hpp"
#include "sbt_tFOZdZ_txOzTest.hpp"
#include "sbt_uGEyjJ9OaTest.hpp"
#include "sbt_uluTest.hpp"
#include "sbt_w9UXxcuLlKoTest.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcbTest.hpp"
#include "sbt_Yq7xpUGG9EHTsOV1oRRTest.hpp"
#include "sbt_ZTest.hpp"


void Run_Tests()
{
	CX::SB::StatsData trd;
	CX::SB::StatsData twd;
	CX::Size cAll = 0;
	CX::Size cOK = 0;
	CX::Status status;

	trd.Reset();
	twd.Reset();
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_3MTAoQ2ptK2iiOg>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_3MTAoQ2ptK2iiOg failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_4pQokJJuMkk>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_4pQokJJuMkk failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_7ReUk>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_7ReUk failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_AbAtHD1hlEGM3>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_AbAtHD1hlEGM3 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_aWV>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_aWV failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_G>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_G failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_hhN>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_hhN failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_HLgxkrJiwhiZFPFl9>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_HLgxkrJiwhiZFPFl9 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_M5e>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_M5e failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_q>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_q failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_RQIcYaFdzwqjAui>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_RQIcYaFdzwqjAui failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_rsmoHoWL9_yvLvM>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_rsmoHoWL9_yvLvM failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Shaj051AZs_lkug>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Shaj051AZs_lkug failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_tFOZdZ_txOz>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_tFOZdZ_txOz failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_uGEyjJ9Oa>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_uGEyjJ9Oa failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_ulu>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_ulu failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_w9UXxcuLlKo>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_w9UXxcuLlKo failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_xBJ2EuxHbF8Qm3ScYcb>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_xBJ2EuxHbF8Qm3ScYcb failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Yq7xpUGG9EHTsOV1oRR>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Yq7xpUGG9EHTsOV1oRR failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Z>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Z failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	CX::Print(stdout, "All tests : {1}\n", cAll);
	CX::Print(stdout, "OK tests  : {1}\n", cOK);
	CX::Print(stdout, "===== READ STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", trd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", trd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", trd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", trd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", trd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", trd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", trd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", trd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", trd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", trd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", trd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", trd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", trd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", trd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", trd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", trd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", trd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", trd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", trd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {:.3} MB\n", trd.m_cbTotalSize / 1048576.0);
	CX::Print(stdout, "===== WRITE STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", twd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", twd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", twd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", twd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", twd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", twd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", twd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", twd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", twd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", twd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", twd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", twd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", twd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", twd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", twd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", twd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", twd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", twd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", twd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {1:.3} MB\n", twd.m_cbTotalSize / 1048576.0);
}
