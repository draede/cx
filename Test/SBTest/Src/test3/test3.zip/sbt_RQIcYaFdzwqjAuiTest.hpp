
#pragma once


#include "sbt_RQIcYaFdzwqjAui.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_w9UXxcuLlKoTest.hpp"
#include "sbt_Yq7xpUGG9EHTsOV1oRRTest.hpp"
#include "sbt_uluTest.hpp"
#include "sbt_AbAtHD1hlEGM3Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_RQIcYaFdzwqjAui &p)
{
	p.sbt_9bgUh = "GKci[c[aA3)))O/==+yo";
	TestInit(p.sbt_Rpy);
	p.sbt_Vmb_r = 0.362165f;
	TestInit(p.sbt_cD2VAKZ);
	p.sbt_eZMa0FQ = -582005316;
	p.sbt_fXspkYtqJ[-6830042609558417348] = 514035673;
	p.sbt_fXspkYtqJ[3883184773012574796] = 1835046846;
	p.sbt_fXspkYtqJ[-2482424179972401954] = -1484082300;
	p.sbt_fXspkYtqJ[5184485852944045292] = -399757374;
	p.sbt_fXspkYtqJ[-4312164067295847676] = 756096252;
	p.sbt_fXspkYtqJ[1004664143588155482] = 483701902;
	p.sbt_fXspkYtqJ[3429288928061753048] = 457665152;
	p.sbt_fXspkYtqJ[-241604091086766320] = -1715300815;
	p.sbt_fXspkYtqJ[7737982702067184386] = -1743015088;
	p.sbt_jq7Cu = 0.518647;
	p.sbt_pAO = 6169765461684346626;
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		TestInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
}

static inline void RandInit(sbt_RQIcYaFdzwqjAui &p)
{
	p.sbt_9bgUh = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_Rpy);
	p.sbt_Vmb_r = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_cD2VAKZ);
	p.sbt_eZMa0FQ = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fXspkYtqJ[CX::Util::RndGen::Get().GetInt64()] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_jq7Cu = CX::Util::RndGen::Get().GetDouble();
	p.sbt_pAO = CX::Util::RndGen::Get().GetInt64();
	{
		sbt_ulu k;
		sbt_AbAtHD1hlEGM3 v;

		RandInit(k);
		TestInit(v);
		p.sbt_xx613j3nN[k] = v;
	}
}

}//namespace SB

}//namespace CX

