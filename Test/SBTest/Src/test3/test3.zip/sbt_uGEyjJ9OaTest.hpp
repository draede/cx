
#pragma once


#include "sbt_uGEyjJ9Oa.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_RQIcYaFdzwqjAuiTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_uGEyjJ9Oa &p)
{
	p.sbt_1gsce93Rd = 58279;
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	p.sbt_DC0 = 0.121877f;
}

static inline void RandInit(sbt_uGEyjJ9Oa &p)
{
	p.sbt_1gsce93Rd = CX::Util::RndGen::Get().GetUInt16();
	{
		sbt_RQIcYaFdzwqjAui k;

		TestInit(k);
		p.sbt_9QIQhu3jz.push_back(k);
	}
	p.sbt_DC0 = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

