
#pragma once


#include "sbt_Yq7xpUGG9EHTsOV1oRR.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_M5eTest.hpp"
#include "sbt_rsmoHoWL9_yvLvMTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Yq7xpUGG9EHTsOV1oRR &p)
{
	TestInit(p.sbt_8);
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		TestInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	p.sbt_Pdl.push_back(-87);
	p.sbt_Pdl.push_back(3);
	p.sbt_Pdl.push_back(92);
	p.sbt_Pdl.push_back(-71);
	p.sbt_Pdl.push_back(6);
	p.sbt_U = 8512;
	p.sbt_cSXkg[38542] = false;
	p.sbt_cSXkg[20050] = false;
	p.sbt_cSXkg[63047] = false;
	p.sbt_cSXkg[6977] = false;
	p.sbt_cSXkg[16922] = false;
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	p.sbt_p = 1556227965;
	p.sbt_sVP = 69;
	p.sbt_wRLq3[0.168917f] = 1611235479813188580;
	p.sbt_wRLq3[0.070491f] = -8458485902178723066;
	p.sbt_wRLq3[0.006103f] = 5153760959846279322;
	p.sbt_wRLq3[0.965216f] = 7030387894626219306;
	p.sbt_wRLq3[0.806044f] = 458473301340452324;
	p.sbt_wRLq3[0.067569f] = -5917945425023729404;
	p.sbt_wRLq3[0.728140f] = 7498293326844082688;
}

static inline void RandInit(sbt_Yq7xpUGG9EHTsOV1oRR &p)
{
	RandInit(p.sbt_8);
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	{
		sbt_M5e k;
		sbt_rsmoHoWL9_yvLvM v;

		RandInit(k);
		TestInit(v);
		p.sbt_KSDAY[k] = v;
	}
	p.sbt_Pdl.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_U = CX::Util::RndGen::Get().GetInt16();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_cSXkg[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetBool();
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_ndPj_cx.push_back(k);
	}
	p.sbt_p = CX::Util::RndGen::Get().GetInt32();
	p.sbt_sVP = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_wRLq3[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetInt64();
}

}//namespace SB

}//namespace CX

