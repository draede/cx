
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_M5e.hpp"
#include "sbt_aWV.hpp"


class sbt_q
{
public:

	sbt_M5e sbt_2;
	CX::WString sbt_SZspdub;
	sbt_aWV sbt_Ts39OIuj0;
	CX::UInt64 sbt_b62D_gJgP;
	sbt_M5e sbt_f;
	CX::SB::Vector<CX::Bool>::Type sbt_v;
	CX::Int8 sbt_wf1gIOs;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_q &p)
{
	DefInit(p.sbt_2);
	DefInit(p.sbt_SZspdub);
	DefInit(p.sbt_Ts39OIuj0);
	DefInit(p.sbt_b62D_gJgP);
	DefInit(p.sbt_f);
	DefInit(p.sbt_v);
	DefInit(p.sbt_wf1gIOs);
}

template <> static inline int Compare<sbt_q>(const sbt_q &a, const sbt_q &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_2, b.sbt_2)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SZspdub, b.sbt_SZspdub)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Ts39OIuj0, b.sbt_Ts39OIuj0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_b62D_gJgP, b.sbt_b62D_gJgP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_f, b.sbt_f)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_v, b.sbt_v)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wf1gIOs, b.sbt_wf1gIOs)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_q>(const sbt_q &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_2, pHasher);
	Hash(p.sbt_SZspdub, pHasher);
	Hash(p.sbt_Ts39OIuj0, pHasher);
	Hash(p.sbt_b62D_gJgP, pHasher);
	Hash(p.sbt_f, pHasher);
	Hash(p.sbt_v, pHasher);
	Hash(p.sbt_wf1gIOs, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_q>(sbt_q p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_2", p.sbt_2)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SZspdub", p.sbt_SZspdub)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Ts39OIuj0", p.sbt_Ts39OIuj0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_b62D_gJgP", p.sbt_b62D_gJgP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_f", p.sbt_f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wf1gIOs", p.sbt_wf1gIOs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_q>(sbt_q &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_2", p.sbt_2)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SZspdub", p.sbt_SZspdub)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Ts39OIuj0", p.sbt_Ts39OIuj0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_b62D_gJgP", p.sbt_b62D_gJgP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_f", p.sbt_f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_v", p.sbt_v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wf1gIOs", p.sbt_wf1gIOs)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

