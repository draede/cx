
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"


class sbt_w9UXxcuLlKo
{
public:

	CX::Int32 sbt_0o5E_xt;
	CX::UInt32 sbt_9;
	CX::Int8 sbt_CCZwmfo;
	CX::Double sbt_PHC8t4nfP;
	CX::Bool sbt_Sez;
	CX::Float sbt_gyO5_;
	CX::Double sbt_l;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_w9UXxcuLlKo &p)
{
	DefInit(p.sbt_0o5E_xt);
	DefInit(p.sbt_9);
	DefInit(p.sbt_CCZwmfo);
	DefInit(p.sbt_PHC8t4nfP);
	DefInit(p.sbt_Sez);
	DefInit(p.sbt_gyO5_);
	DefInit(p.sbt_l);
}

template <> static inline int Compare<sbt_w9UXxcuLlKo>(const sbt_w9UXxcuLlKo &a, const sbt_w9UXxcuLlKo &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0o5E_xt, b.sbt_0o5E_xt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_9, b.sbt_9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_CCZwmfo, b.sbt_CCZwmfo)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PHC8t4nfP, b.sbt_PHC8t4nfP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sez, b.sbt_Sez)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gyO5_, b.sbt_gyO5_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l, b.sbt_l)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_w9UXxcuLlKo>(const sbt_w9UXxcuLlKo &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0o5E_xt, pHasher);
	Hash(p.sbt_9, pHasher);
	Hash(p.sbt_CCZwmfo, pHasher);
	Hash(p.sbt_PHC8t4nfP, pHasher);
	Hash(p.sbt_Sez, pHasher);
	Hash(p.sbt_gyO5_, pHasher);
	Hash(p.sbt_l, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_w9UXxcuLlKo>(sbt_w9UXxcuLlKo p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0o5E_xt", p.sbt_0o5E_xt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9", p.sbt_9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_CCZwmfo", p.sbt_CCZwmfo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PHC8t4nfP", p.sbt_PHC8t4nfP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sez", p.sbt_Sez)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gyO5_", p.sbt_gyO5_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_w9UXxcuLlKo>(sbt_w9UXxcuLlKo &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0o5E_xt", p.sbt_0o5E_xt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_9", p.sbt_9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_CCZwmfo", p.sbt_CCZwmfo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PHC8t4nfP", p.sbt_PHC8t4nfP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sez", p.sbt_Sez)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gyO5_", p.sbt_gyO5_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

