
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_HLgxkrJiwhiZFPFl9.hpp"
#include "sbt_xBJ2EuxHbF8Qm3ScYcb.hpp"
#include "sbt_7ReUk.hpp"


class sbt_AbAtHD1hlEGM3
{
public:

	sbt_HLgxkrJiwhiZFPFl9 sbt_4;
	sbt_xBJ2EuxHbF8Qm3ScYcb sbt_6WhYlY2T6;
	CX::Int16 sbt_6xuAUggp0;
	CX::Int8 sbt_N63gXFrGz;
	CX::WString sbt_SwJ87;
	sbt_7ReUk sbt_c9FNE;
	CX::SB::Map<CX::Double, CX::Int64>::Type sbt_iKe;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_AbAtHD1hlEGM3 &p)
{
	DefInit(p.sbt_4);
	DefInit(p.sbt_6WhYlY2T6);
	DefInit(p.sbt_6xuAUggp0);
	DefInit(p.sbt_N63gXFrGz);
	DefInit(p.sbt_SwJ87);
	DefInit(p.sbt_c9FNE);
	DefInit(p.sbt_iKe);
}

template <> static inline int Compare<sbt_AbAtHD1hlEGM3>(const sbt_AbAtHD1hlEGM3 &a, const sbt_AbAtHD1hlEGM3 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4, b.sbt_4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6WhYlY2T6, b.sbt_6WhYlY2T6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6xuAUggp0, b.sbt_6xuAUggp0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_N63gXFrGz, b.sbt_N63gXFrGz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SwJ87, b.sbt_SwJ87)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_c9FNE, b.sbt_c9FNE)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iKe, b.sbt_iKe)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_AbAtHD1hlEGM3>(const sbt_AbAtHD1hlEGM3 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4, pHasher);
	Hash(p.sbt_6WhYlY2T6, pHasher);
	Hash(p.sbt_6xuAUggp0, pHasher);
	Hash(p.sbt_N63gXFrGz, pHasher);
	Hash(p.sbt_SwJ87, pHasher);
	Hash(p.sbt_c9FNE, pHasher);
	Hash(p.sbt_iKe, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_AbAtHD1hlEGM3>(sbt_AbAtHD1hlEGM3 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6WhYlY2T6", p.sbt_6WhYlY2T6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6xuAUggp0", p.sbt_6xuAUggp0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_N63gXFrGz", p.sbt_N63gXFrGz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SwJ87", p.sbt_SwJ87)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_c9FNE", p.sbt_c9FNE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iKe", p.sbt_iKe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_AbAtHD1hlEGM3>(sbt_AbAtHD1hlEGM3 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6WhYlY2T6", p.sbt_6WhYlY2T6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6xuAUggp0", p.sbt_6xuAUggp0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_N63gXFrGz", p.sbt_N63gXFrGz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SwJ87", p.sbt_SwJ87)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_c9FNE", p.sbt_c9FNE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iKe", p.sbt_iKe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

