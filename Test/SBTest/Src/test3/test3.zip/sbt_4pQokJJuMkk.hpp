
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_q.hpp"


class sbt_4pQokJJuMkk
{
public:

	sbt_q sbt___gYC5s;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_4pQokJJuMkk &p)
{
	DefInit(p.sbt___gYC5s);
}

template <> static inline int Compare<sbt_4pQokJJuMkk>(const sbt_4pQokJJuMkk &a, const sbt_4pQokJJuMkk &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt___gYC5s, b.sbt___gYC5s)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_4pQokJJuMkk>(const sbt_4pQokJJuMkk &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt___gYC5s, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_4pQokJJuMkk>(sbt_4pQokJJuMkk p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt___gYC5s", p.sbt___gYC5s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_4pQokJJuMkk>(sbt_4pQokJJuMkk &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (1 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 1 members");
	}
	if ((status = pDataReader->ReadMember("sbt___gYC5s", p.sbt___gYC5s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

