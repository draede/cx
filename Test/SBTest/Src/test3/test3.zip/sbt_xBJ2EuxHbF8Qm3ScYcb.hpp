
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_M5e.hpp"
#include "sbt_rsmoHoWL9_yvLvM.hpp"


class sbt_xBJ2EuxHbF8Qm3ScYcb
{
public:

	CX::SB::Map<CX::WString, CX::WString>::Type sbt_5Lbk1IHn1;
	sbt_M5e sbt_ABMwT;
	CX::SB::Vector<sbt_rsmoHoWL9_yvLvM>::Type sbt_DfToHQ0g5;
	CX::Int16 sbt_OzDNukffh;
	CX::Int16 sbt_aXZbSeK;
	CX::SB::Vector<CX::Int16>::Type sbt_biLlRIPgb;
	CX::UInt16 sbt_jZQhN;
	CX::Int8 sbt_o;
	CX::SB::Vector<sbt_rsmoHoWL9_yvLvM>::Type sbt_s;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_xBJ2EuxHbF8Qm3ScYcb &p)
{
	DefInit(p.sbt_5Lbk1IHn1);
	DefInit(p.sbt_ABMwT);
	DefInit(p.sbt_DfToHQ0g5);
	DefInit(p.sbt_OzDNukffh);
	DefInit(p.sbt_aXZbSeK);
	DefInit(p.sbt_biLlRIPgb);
	DefInit(p.sbt_jZQhN);
	DefInit(p.sbt_o);
	DefInit(p.sbt_s);
}

template <> static inline int Compare<sbt_xBJ2EuxHbF8Qm3ScYcb>(const sbt_xBJ2EuxHbF8Qm3ScYcb &a, const sbt_xBJ2EuxHbF8Qm3ScYcb &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5Lbk1IHn1, b.sbt_5Lbk1IHn1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ABMwT, b.sbt_ABMwT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_DfToHQ0g5, b.sbt_DfToHQ0g5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_OzDNukffh, b.sbt_OzDNukffh)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aXZbSeK, b.sbt_aXZbSeK)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_biLlRIPgb, b.sbt_biLlRIPgb)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jZQhN, b.sbt_jZQhN)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_o, b.sbt_o)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_s, b.sbt_s)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_xBJ2EuxHbF8Qm3ScYcb>(const sbt_xBJ2EuxHbF8Qm3ScYcb &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5Lbk1IHn1, pHasher);
	Hash(p.sbt_ABMwT, pHasher);
	Hash(p.sbt_DfToHQ0g5, pHasher);
	Hash(p.sbt_OzDNukffh, pHasher);
	Hash(p.sbt_aXZbSeK, pHasher);
	Hash(p.sbt_biLlRIPgb, pHasher);
	Hash(p.sbt_jZQhN, pHasher);
	Hash(p.sbt_o, pHasher);
	Hash(p.sbt_s, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_xBJ2EuxHbF8Qm3ScYcb>(sbt_xBJ2EuxHbF8Qm3ScYcb p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5Lbk1IHn1", p.sbt_5Lbk1IHn1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ABMwT", p.sbt_ABMwT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DfToHQ0g5", p.sbt_DfToHQ0g5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_OzDNukffh", p.sbt_OzDNukffh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aXZbSeK", p.sbt_aXZbSeK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_biLlRIPgb", p.sbt_biLlRIPgb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jZQhN", p.sbt_jZQhN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_o", p.sbt_o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_s", p.sbt_s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_xBJ2EuxHbF8Qm3ScYcb>(sbt_xBJ2EuxHbF8Qm3ScYcb &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5Lbk1IHn1", p.sbt_5Lbk1IHn1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ABMwT", p.sbt_ABMwT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_DfToHQ0g5", p.sbt_DfToHQ0g5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_OzDNukffh", p.sbt_OzDNukffh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aXZbSeK", p.sbt_aXZbSeK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_biLlRIPgb", p.sbt_biLlRIPgb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jZQhN", p.sbt_jZQhN)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_o", p.sbt_o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_s", p.sbt_s)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

