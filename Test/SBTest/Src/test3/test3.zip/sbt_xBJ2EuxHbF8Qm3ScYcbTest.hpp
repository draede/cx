
#pragma once


#include "sbt_xBJ2EuxHbF8Qm3ScYcb.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_M5eTest.hpp"
#include "sbt_rsmoHoWL9_yvLvMTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_xBJ2EuxHbF8Qm3ScYcb &p)
{
	p.sbt_5Lbk1IHn1[L"GcOcy_%Ku[3kqQ!"] = L"5Y_Iy%G";
	p.sbt_5Lbk1IHn1[L"C9[!'Ey'#["] = L"?SyqQEqQaE]";
	p.sbt_5Lbk1IHn1[L"/;1SM;;;qmA[i%k"] = L"M5?EOKe/mqEwi";
	TestInit(p.sbt_ABMwT);
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	p.sbt_OzDNukffh = 29354;
	p.sbt_aXZbSeK = -3636;
	p.sbt_biLlRIPgb.push_back(19135);
	p.sbt_biLlRIPgb.push_back(15462);
	p.sbt_biLlRIPgb.push_back(-29962);
	p.sbt_biLlRIPgb.push_back(7786);
	p.sbt_biLlRIPgb.push_back(-17857);
	p.sbt_biLlRIPgb.push_back(-27535);
	p.sbt_biLlRIPgb.push_back(28929);
	p.sbt_biLlRIPgb.push_back(10917);
	p.sbt_biLlRIPgb.push_back(18552);
	p.sbt_jZQhN = 30466;
	p.sbt_o = 107;
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
}

static inline void RandInit(sbt_xBJ2EuxHbF8Qm3ScYcb &p)
{
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_5Lbk1IHn1[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_ABMwT);
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_DfToHQ0g5.push_back(k);
	}
	p.sbt_OzDNukffh = CX::Util::RndGen::Get().GetInt16();
	p.sbt_aXZbSeK = CX::Util::RndGen::Get().GetInt16();
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_biLlRIPgb.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_jZQhN = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_o = CX::Util::RndGen::Get().GetInt8();
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
	{
		sbt_rsmoHoWL9_yvLvM k;

		TestInit(k);
		p.sbt_s.push_back(k);
	}
}

}//namespace SB

}//namespace CX

