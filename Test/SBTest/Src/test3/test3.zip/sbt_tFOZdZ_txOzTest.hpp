
#pragma once


#include "sbt_tFOZdZ_txOz.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_RQIcYaFdzwqjAuiTest.hpp"
#include "sbt_4pQokJJuMkkTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_tFOZdZ_txOz &p)
{
	p.sbt_ButmB27 = L"c]9=uU}sy!I/K'qcGA=aUiW";
	p.sbt_Kf3 = 251;
	TestInit(p.sbt_TWAdN5Wsq);
	p.sbt_U = true;
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	p.sbt_gKF021BqH = 122;
	p.sbt_h = 0.758219f;
	TestInit(p.sbt_l31QO);
	p.sbt_rUPveuy = 11173229447239668278;
}

static inline void RandInit(sbt_tFOZdZ_txOz &p)
{
	p.sbt_ButmB27 = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_Kf3 = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_TWAdN5Wsq);
	p.sbt_U = CX::Util::RndGen::Get().GetBool();
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	{
		sbt_4pQokJJuMkk k;

		TestInit(k);
		p.sbt_cCE9J.push_back(k);
	}
	p.sbt_gKF021BqH = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_h = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_l31QO);
	p.sbt_rUPveuy = CX::Util::RndGen::Get().GetUInt64();
}

}//namespace SB

}//namespace CX

