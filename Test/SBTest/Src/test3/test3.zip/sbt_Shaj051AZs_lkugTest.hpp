
#pragma once


#include "sbt_Shaj051AZs_lkug.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_qTest.hpp"
#include "sbt_HLgxkrJiwhiZFPFl9Test.hpp"
#include "sbt_Yq7xpUGG9EHTsOV1oRRTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Shaj051AZs_lkug &p)
{
	p.sbt_4v78Z[645958072277160268] = L"?}mg3)-#";
	p.sbt_4v78Z[-5236414731665894738] = L"kc!+Q{YE%7cqI1=cqA]usAw)GA/Igk";
	p.sbt_4v78Z[-8478473168229020220] = L"uegSsw}U!#-9yWG]/#";
	p.sbt_4v78Z[-3155643037142116636] = L"q-9IUCwG1%1Iq_Q{5i9i";
	p.sbt_4v78Z[-6053129601950729042] = L"u";
	p.sbt_4v78Z[-8135812785737824582] = L"#9wIgGk'?+G7'5C7aC_=GWS#5i";
	p.sbt_4v78Z[5298117552518602506] = L"e[U9%=17KO'UsG_ASC+k";
	TestInit(p.sbt_8RvdQDS);
	p.sbt_EE1CM = 65173;
	p.sbt_R_oiW9B9u.push_back(17705449919295858354);
	p.sbt_R_oiW9B9u.push_back(16007889035007432390);
	p.sbt_R_oiW9B9u.push_back(9748973084732367142);
	TestInit(p.sbt_Tdim5d5rM);
	p.sbt_VyOAP = 0.784612f;
	TestInit(p.sbt__qDc02d);
	p.sbt_a = -515195466;
	p.sbt_pmPErj1R5[0.044048] = 0.055100f;
}

static inline void RandInit(sbt_Shaj051AZs_lkug &p)
{
	p.sbt_4v78Z[CX::Util::RndGen::Get().GetInt64()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_4v78Z[CX::Util::RndGen::Get().GetInt64()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_4v78Z[CX::Util::RndGen::Get().GetInt64()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_8RvdQDS);
	p.sbt_EE1CM = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	p.sbt_R_oiW9B9u.push_back(CX::Util::RndGen::Get().GetUInt64());
	RandInit(p.sbt_Tdim5d5rM);
	p.sbt_VyOAP = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt__qDc02d);
	p.sbt_a = CX::Util::RndGen::Get().GetInt32();
	p.sbt_pmPErj1R5[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

