
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_5sgGyJJOYBQ8tRa.hpp"
#include "sbt_nmlP8GM6WCm_C8wEs.hpp"
#include "sbt_iS77q.hpp"


class sbt_gCnAZ4Srk0wKwMRpk
{
public:

	CX::Double sbt_0N_98EIdV;
	sbt_5sgGyJJOYBQ8tRa sbt_0tjN68F;
	CX::Double sbt_6oR1d;
	sbt_nmlP8GM6WCm_C8wEs sbt_StI4C42;
	CX::SB::Map<CX::String, CX::Int16>::Type sbt_VBlyGMGJK;
	sbt_iS77q sbt_YM0;
	CX::UInt8 sbt__Iljn8h;
	CX::Double sbt_kXyzElSdM;
	CX::Int32 sbt_tuT;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_gCnAZ4Srk0wKwMRpk &p)
{
	DefInit(p.sbt_0N_98EIdV);
	DefInit(p.sbt_0tjN68F);
	DefInit(p.sbt_6oR1d);
	DefInit(p.sbt_StI4C42);
	DefInit(p.sbt_VBlyGMGJK);
	DefInit(p.sbt_YM0);
	DefInit(p.sbt__Iljn8h);
	DefInit(p.sbt_kXyzElSdM);
	DefInit(p.sbt_tuT);
}

template <> static inline int Compare<sbt_gCnAZ4Srk0wKwMRpk>(const sbt_gCnAZ4Srk0wKwMRpk &a, const sbt_gCnAZ4Srk0wKwMRpk &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0N_98EIdV, b.sbt_0N_98EIdV)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_0tjN68F, b.sbt_0tjN68F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_6oR1d, b.sbt_6oR1d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_StI4C42, b.sbt_StI4C42)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VBlyGMGJK, b.sbt_VBlyGMGJK)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YM0, b.sbt_YM0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__Iljn8h, b.sbt__Iljn8h)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_kXyzElSdM, b.sbt_kXyzElSdM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tuT, b.sbt_tuT)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_gCnAZ4Srk0wKwMRpk>(const sbt_gCnAZ4Srk0wKwMRpk &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0N_98EIdV, pHasher);
	Hash(p.sbt_0tjN68F, pHasher);
	Hash(p.sbt_6oR1d, pHasher);
	Hash(p.sbt_StI4C42, pHasher);
	Hash(p.sbt_VBlyGMGJK, pHasher);
	Hash(p.sbt_YM0, pHasher);
	Hash(p.sbt__Iljn8h, pHasher);
	Hash(p.sbt_kXyzElSdM, pHasher);
	Hash(p.sbt_tuT, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_gCnAZ4Srk0wKwMRpk>(sbt_gCnAZ4Srk0wKwMRpk p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0N_98EIdV", p.sbt_0N_98EIdV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0tjN68F", p.sbt_0tjN68F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6oR1d", p.sbt_6oR1d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_StI4C42", p.sbt_StI4C42)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VBlyGMGJK", p.sbt_VBlyGMGJK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YM0", p.sbt_YM0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__Iljn8h", p.sbt__Iljn8h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_kXyzElSdM", p.sbt_kXyzElSdM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tuT", p.sbt_tuT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_gCnAZ4Srk0wKwMRpk>(sbt_gCnAZ4Srk0wKwMRpk &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0N_98EIdV", p.sbt_0N_98EIdV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_0tjN68F", p.sbt_0tjN68F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_6oR1d", p.sbt_6oR1d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_StI4C42", p.sbt_StI4C42)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VBlyGMGJK", p.sbt_VBlyGMGJK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YM0", p.sbt_YM0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__Iljn8h", p.sbt__Iljn8h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_kXyzElSdM", p.sbt_kXyzElSdM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tuT", p.sbt_tuT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

