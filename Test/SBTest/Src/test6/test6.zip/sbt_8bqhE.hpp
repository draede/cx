
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_k.hpp"
#include "sbt_Nq7.hpp"


class sbt_8bqhE
{
public:

	sbt_k sbt_BGc;
	CX::UInt32 sbt_QHTEQXX;
	CX::Int64 sbt_fJyZlSgTZ;
	CX::Float sbt_is3;
	sbt_Nq7 sbt_j8C;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_8bqhE &p)
{
	DefInit(p.sbt_BGc);
	DefInit(p.sbt_QHTEQXX);
	DefInit(p.sbt_fJyZlSgTZ);
	DefInit(p.sbt_is3);
	DefInit(p.sbt_j8C);
}

template <> static inline int Compare<sbt_8bqhE>(const sbt_8bqhE &a, const sbt_8bqhE &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_BGc, b.sbt_BGc)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_QHTEQXX, b.sbt_QHTEQXX)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fJyZlSgTZ, b.sbt_fJyZlSgTZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_is3, b.sbt_is3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j8C, b.sbt_j8C)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_8bqhE>(const sbt_8bqhE &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_BGc, pHasher);
	Hash(p.sbt_QHTEQXX, pHasher);
	Hash(p.sbt_fJyZlSgTZ, pHasher);
	Hash(p.sbt_is3, pHasher);
	Hash(p.sbt_j8C, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_8bqhE>(sbt_8bqhE p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BGc", p.sbt_BGc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_QHTEQXX", p.sbt_QHTEQXX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fJyZlSgTZ", p.sbt_fJyZlSgTZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_is3", p.sbt_is3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j8C", p.sbt_j8C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_8bqhE>(sbt_8bqhE &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_BGc", p.sbt_BGc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_QHTEQXX", p.sbt_QHTEQXX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fJyZlSgTZ", p.sbt_fJyZlSgTZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_is3", p.sbt_is3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j8C", p.sbt_j8C)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

