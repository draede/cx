
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6Bx.hpp"
#include "sbt_k.hpp"


class sbt_6
{
public:

	CX::UInt16 sbt_Q_WzUgeAk;
	CX::Bool sbt_d;
	CX::SB::Map<sbt_4zanj_ga3ZYRmUoH6Bx, sbt_k>::Type sbt_gKnZr;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_6 &p)
{
	DefInit(p.sbt_Q_WzUgeAk);
	DefInit(p.sbt_d);
	DefInit(p.sbt_gKnZr);
}

template <> static inline int Compare<sbt_6>(const sbt_6 &a, const sbt_6 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Q_WzUgeAk, b.sbt_Q_WzUgeAk)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_d, b.sbt_d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gKnZr, b.sbt_gKnZr)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_6>(const sbt_6 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Q_WzUgeAk, pHasher);
	Hash(p.sbt_d, pHasher);
	Hash(p.sbt_gKnZr, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_6>(sbt_6 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Q_WzUgeAk", p.sbt_Q_WzUgeAk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gKnZr", p.sbt_gKnZr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_6>(sbt_6 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Q_WzUgeAk", p.sbt_Q_WzUgeAk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gKnZr", p.sbt_gKnZr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

