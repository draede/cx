
#pragma once


#include "sbt_ekP_c1S.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ATest.hpp"
#include "sbt_8bqhETest.hpp"
#include "sbt_y4nqlCNALJ9Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_ekP_c1S &p)
{
	p.sbt_2FADxlpyH.push_back(0.142318f);
	p.sbt_2FADxlpyH.push_back(0.598280f);
	p.sbt_2FADxlpyH.push_back(0.318803f);
	p.sbt_2FADxlpyH.push_back(0.911075f);
	p.sbt_2FADxlpyH.push_back(0.776576f);
	p.sbt_2FADxlpyH.push_back(0.428876f);
	p.sbt_2FADxlpyH.push_back(0.260798f);
	p.sbt_3 = 0.146150f;
	p.sbt_EWx = -116;
	TestInit(p.sbt_Ex5p_);
	TestInit(p.sbt_FJ3do);
	p.sbt_O[false] = 0.079214;
	p.sbt_O[true] = 0.566668;
	p.sbt_O[false] = 0.564228;
	p.sbt_e = 25487;
	TestInit(p.sbt_qa7m8);
	p.sbt_xOGM15crT = -10295;
}

static inline void RandInit(sbt_ekP_c1S &p)
{
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_2FADxlpyH.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_3 = CX::Util::RndGen::Get().GetFloat();
	p.sbt_EWx = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_Ex5p_);
	RandInit(p.sbt_FJ3do);
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_e = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_qa7m8);
	p.sbt_xOGM15crT = CX::Util::RndGen::Get().GetInt16();
}

}//namespace SB

}//namespace CX

