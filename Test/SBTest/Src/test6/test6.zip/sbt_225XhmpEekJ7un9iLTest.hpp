
#pragma once


#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_4IFneIqInTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_225XhmpEekJ7un9iL &p)
{
	TestInit(p.sbt_Qv9JtfQQS);
	p.sbt_VQD_J = 16289230686842484290;
	p.sbt__FLcHyA = -1113347095747502232;
	p.sbt_bPx = "_9a{O-{q!Q]+gM#m}W?iCI";
	TestInit(p.sbt_e);
	p.sbt_k6j = false;
	p.sbt_knS7C98tZ = 108;
	p.sbt_tne = 3000012955;
	TestInit(p.sbt_uAK);
}

static inline void RandInit(sbt_225XhmpEekJ7un9iL &p)
{
	RandInit(p.sbt_Qv9JtfQQS);
	p.sbt_VQD_J = CX::Util::RndGen::Get().GetUInt64();
	p.sbt__FLcHyA = CX::Util::RndGen::Get().GetInt64();
	p.sbt_bPx = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_e);
	p.sbt_k6j = CX::Util::RndGen::Get().GetBool();
	p.sbt_knS7C98tZ = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_tne = CX::Util::RndGen::Get().GetUInt32();
	RandInit(p.sbt_uAK);
}

}//namespace SB

}//namespace CX

