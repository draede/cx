
#pragma once


#include "sbt_BnE.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_8bqhETest.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_BnE &p)
{
	p.sbt_91U = 3539047366771417952;
	TestInit(p.sbt_PfiDw);
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_TVO19gt[k] = v;
	}
	p.sbt_q.push_back(-100);
	p.sbt_q.push_back(79);
	p.sbt_q.push_back(77);
	p.sbt_q.push_back(-83);
	p.sbt_q.push_back(-97);
	p.sbt_q.push_back(-97);
	p.sbt_q.push_back(67);
	p.sbt_q.push_back(117);
	p.sbt_q.push_back(-62);
	p.sbt_qhLGVag = 4230228179;
}

static inline void RandInit(sbt_BnE &p)
{
	p.sbt_91U = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_PfiDw);
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_8bqhE v;

		RandInit(k);
		TestInit(v);
		p.sbt_TVO19gt[k] = v;
	}
	p.sbt_q.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_qhLGVag = CX::Util::RndGen::Get().GetUInt32();
}

}//namespace SB

}//namespace CX

