
#pragma once


#include "sbt_ZLIQ7iEI8.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_OBbTest.hpp"
#include "sbt_y4nqlCNALJ9Test.hpp"
#include "sbt_C7P8zUDllnpTest.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_ZLIQ7iEI8 &p)
{
	p.sbt_5z9 = 0.074460;
	TestInit(p.sbt_9JwUb);
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	p.sbt_JVXDJ.push_back(70);
	p.sbt_JVXDJ.push_back(-8);
	p.sbt_JVXDJ.push_back(-68);
	p.sbt_JVXDJ.push_back(-24);
	p.sbt_JVXDJ.push_back(-55);
	p.sbt_Jcjdz[true] = 0.728091;
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		TestInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		TestInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		TestInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	p.sbt_Zb2vV.push_back(252);
	p.sbt_Zb2vV.push_back(37);
	p.sbt_Zb2vV.push_back(43);
	p.sbt_l = -25719;
	p.sbt_nHT[11796160979151238428] = "aua;M_g/";
	p.sbt_nHT[245873576887615844] = "]5i";
	p.sbt_nHT[4132009136594547804] = "1mc[u%'q}%KiE";
	p.sbt_nHT[5941559292179972842] = "}QIwmM[195q])7eywMO";
	p.sbt_nHT[5395477126399607636] = "9o}C%M7aYQ#o[Sc[ewa;_3-1q}";
	p.sbt_nHT[7621769525445385056] = "'c)i1W7Ks+qAu-S[)wi)7=W{'[";
	p.sbt_nHT[15693824184205733410] = "C";
	p.sbt_nHT[17504208560295257202] = "c)g-7?=oKQ+C3a9ygS3";
	p.sbt_nHT[4781205052467287248] = "_UkA={m=M'IsC%{]qcWQ;";
}

static inline void RandInit(sbt_ZLIQ7iEI8 &p)
{
	p.sbt_5z9 = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_9JwUb);
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	{
		sbt_y4nqlCNALJ9 k;

		TestInit(k);
		p.sbt_DUyNPSe.push_back(k);
	}
	p.sbt_JVXDJ.push_back(CX::Util::RndGen::Get().GetInt8());
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Jcjdz[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetDouble();
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	{
		sbt_C7P8zUDllnp k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_Z[k] = v;
	}
	p.sbt_Zb2vV.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_Zb2vV.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_Zb2vV.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_l = CX::Util::RndGen::Get().GetInt16();
	p.sbt_nHT[CX::Util::RndGen::Get().GetUInt64()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_nHT[CX::Util::RndGen::Get().GetUInt64()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_nHT[CX::Util::RndGen::Get().GetUInt64()] = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

