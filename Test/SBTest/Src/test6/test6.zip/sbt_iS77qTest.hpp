
#pragma once


#include "sbt_iS77q.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0Se0hGnpT5kldTest.hpp"
#include "sbt_iBQiryWTest.hpp"
#include "sbt_gNiZ3WOkV1jeetbhLzJTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_iS77q &p)
{
	TestInit(p.sbt_5co58Eo);
	p.sbt_X96kc = L"Q_Q)5o{AA";
	p.sbt_d[-78] = -27784;
	p.sbt_d[46] = 22471;
	p.sbt_d[11] = -18246;
	p.sbt_euQuEdOtv = 59464;
	p.sbt_hv_ = 131;
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	p.sbt_qQ5aJ = 62;
	p.sbt_ryWnB3X = L"}Oy7=";
	TestInit(p.sbt_w);
}

static inline void RandInit(sbt_iS77q &p)
{
	RandInit(p.sbt_5co58Eo);
	p.sbt_X96kc = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_d[CX::Util::RndGen::Get().GetInt8()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_euQuEdOtv = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_hv_ = CX::Util::RndGen::Get().GetUInt8();
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	{
		sbt_iBQiryW k;

		TestInit(k);
		p.sbt_nzX.push_back(k);
	}
	p.sbt_qQ5aJ = CX::Util::RndGen::Get().GetInt8();
	p.sbt_ryWnB3X = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	RandInit(p.sbt_w);
}

}//namespace SB

}//namespace CX

