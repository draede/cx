
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_4IFneIqIn.hpp"


class sbt_uE_IyAxSbkvGbDlAe
{
public:

	sbt_225XhmpEekJ7un9iL sbt_6v7FD8srk;
	sbt_4IFneIqIn sbt_BcKZkboSz;
	CX::SB::Map<CX::Int64, CX::UInt32>::Type sbt_LAnBXCF;
	CX::SB::Map<CX::WString, CX::Float>::Type sbt_MjI;
	CX::String sbt_TL2rW;
	CX::UInt32 sbt_X;
	CX::UInt16 sbt_h;
	CX::Bool sbt_okdOIk0ls;
	CX::SB::Map<sbt_4IFneIqIn, sbt_4IFneIqIn>::Type sbt_sSNle;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_uE_IyAxSbkvGbDlAe &p)
{
	DefInit(p.sbt_6v7FD8srk);
	DefInit(p.sbt_BcKZkboSz);
	DefInit(p.sbt_LAnBXCF);
	DefInit(p.sbt_MjI);
	DefInit(p.sbt_TL2rW);
	DefInit(p.sbt_X);
	DefInit(p.sbt_h);
	DefInit(p.sbt_okdOIk0ls);
	DefInit(p.sbt_sSNle);
}

template <> static inline int Compare<sbt_uE_IyAxSbkvGbDlAe>(const sbt_uE_IyAxSbkvGbDlAe &a, const sbt_uE_IyAxSbkvGbDlAe &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6v7FD8srk, b.sbt_6v7FD8srk)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_BcKZkboSz, b.sbt_BcKZkboSz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LAnBXCF, b.sbt_LAnBXCF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_MjI, b.sbt_MjI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TL2rW, b.sbt_TL2rW)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X, b.sbt_X)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_h, b.sbt_h)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_okdOIk0ls, b.sbt_okdOIk0ls)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_sSNle, b.sbt_sSNle)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_uE_IyAxSbkvGbDlAe>(const sbt_uE_IyAxSbkvGbDlAe &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6v7FD8srk, pHasher);
	Hash(p.sbt_BcKZkboSz, pHasher);
	Hash(p.sbt_LAnBXCF, pHasher);
	Hash(p.sbt_MjI, pHasher);
	Hash(p.sbt_TL2rW, pHasher);
	Hash(p.sbt_X, pHasher);
	Hash(p.sbt_h, pHasher);
	Hash(p.sbt_okdOIk0ls, pHasher);
	Hash(p.sbt_sSNle, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_uE_IyAxSbkvGbDlAe>(sbt_uE_IyAxSbkvGbDlAe p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6v7FD8srk", p.sbt_6v7FD8srk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BcKZkboSz", p.sbt_BcKZkboSz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LAnBXCF", p.sbt_LAnBXCF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_MjI", p.sbt_MjI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TL2rW", p.sbt_TL2rW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X", p.sbt_X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_okdOIk0ls", p.sbt_okdOIk0ls)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_sSNle", p.sbt_sSNle)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_uE_IyAxSbkvGbDlAe>(sbt_uE_IyAxSbkvGbDlAe &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6v7FD8srk", p.sbt_6v7FD8srk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_BcKZkboSz", p.sbt_BcKZkboSz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LAnBXCF", p.sbt_LAnBXCF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_MjI", p.sbt_MjI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TL2rW", p.sbt_TL2rW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X", p.sbt_X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_okdOIk0ls", p.sbt_okdOIk0ls)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_sSNle", p.sbt_sSNle)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

