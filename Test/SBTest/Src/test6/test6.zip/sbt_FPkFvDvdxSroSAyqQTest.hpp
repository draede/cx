
#pragma once


#include "sbt_FPkFvDvdxSroSAyqQ.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_4IFneIqInTest.hpp"
#include "sbt_oX6waTest.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_FPkFvDvdxSroSAyqQ &p)
{
	p.sbt_7CM = ";e/uGw#gq)g{";
	p.sbt_KDr7a = -1007740770;
	TestInit(p.sbt_UIShr);
	p.sbt_V1obJ = -1998115830971100012;
	TestInit(p.sbt_hyl);
	TestInit(p.sbt_l);
	p.sbt_nto = "CA-g}+QWKC;)5W";
	p.sbt_vBr = 242;
	p.sbt_y0dpoVIlE = 4638;
}

static inline void RandInit(sbt_FPkFvDvdxSroSAyqQ &p)
{
	p.sbt_7CM = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_KDr7a = CX::Util::RndGen::Get().GetInt32();
	RandInit(p.sbt_UIShr);
	p.sbt_V1obJ = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_hyl);
	RandInit(p.sbt_l);
	p.sbt_nto = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_vBr = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_y0dpoVIlE = CX::Util::RndGen::Get().GetUInt16();
}

}//namespace SB

}//namespace CX

