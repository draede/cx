
#pragma once


#include "sbt_gvj_DWPqkRZ0XCFOndC.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_4IFneIqInTest.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxFTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_kTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_gvj_DWPqkRZ0XCFOndC &p)
{
	p.sbt_J6eXh1JJT = 0.506215f;
	p.sbt_SRDRt = L"1]K;9i'eyUG7I=I/7MAk";
	{
		sbt_4IFneIqIn k;
		sbt_aGqmCqmCkLer6NUtTxF v;

		TestInit(k);
		TestInit(v);
		p.sbt_Sdl[k] = v;
	}
	p.sbt_c0A = 24759;
	TestInit(p.sbt_pEehP);
	p.sbt_r["mcMc_!W!![i7GsKi_]MK1A{{I[-"] = -27;
	TestInit(p.sbt_yfw_g4q);
}

static inline void RandInit(sbt_gvj_DWPqkRZ0XCFOndC &p)
{
	p.sbt_J6eXh1JJT = CX::Util::RndGen::Get().GetFloat();
	p.sbt_SRDRt = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_4IFneIqIn k;
		sbt_aGqmCqmCkLer6NUtTxF v;

		RandInit(k);
		TestInit(v);
		p.sbt_Sdl[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_aGqmCqmCkLer6NUtTxF v;

		RandInit(k);
		TestInit(v);
		p.sbt_Sdl[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_aGqmCqmCkLer6NUtTxF v;

		RandInit(k);
		TestInit(v);
		p.sbt_Sdl[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_aGqmCqmCkLer6NUtTxF v;

		RandInit(k);
		TestInit(v);
		p.sbt_Sdl[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_aGqmCqmCkLer6NUtTxF v;

		RandInit(k);
		TestInit(v);
		p.sbt_Sdl[k] = v;
	}
	p.sbt_c0A = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_pEehP);
	p.sbt_r[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_r[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_r[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_r[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_r[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_yfw_g4q);
}

}//namespace SB

}//namespace CX

