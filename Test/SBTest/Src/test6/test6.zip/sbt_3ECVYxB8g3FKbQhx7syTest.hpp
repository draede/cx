
#pragma once


#include "sbt_3ECVYxB8g3FKbQhx7sy.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"
#include "sbt_iBQiryWTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_3ECVYxB8g3FKbQhx7sy &p)
{
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		TestInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		TestInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		TestInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
}

static inline void RandInit(sbt_3ECVYxB8g3FKbQhx7sy &p)
{
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		RandInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		RandInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		RandInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		RandInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;
		sbt_iBQiryW v;

		RandInit(k);
		TestInit(v);
		p.sbt_Pa2xP7DIW[k] = v;
	}
}

}//namespace SB

}//namespace CX

