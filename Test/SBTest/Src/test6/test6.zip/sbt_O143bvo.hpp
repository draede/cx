
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_HBYCFckMOOiNb.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"


class sbt_O143bvo
{
public:

	CX::SB::Map<CX::WString, CX::Int8>::Type sbt_DGMQt;
	sbt_HBYCFckMOOiNb sbt_KFZI5;
	CX::UInt8 sbt_Xkj;
	CX::WString sbt__rsAycCA9;
	CX::SB::Vector<sbt_225XhmpEekJ7un9iL>::Type sbt_ghYNwFNIV;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_O143bvo &p)
{
	DefInit(p.sbt_DGMQt);
	DefInit(p.sbt_KFZI5);
	DefInit(p.sbt_Xkj);
	DefInit(p.sbt__rsAycCA9);
	DefInit(p.sbt_ghYNwFNIV);
}

template <> static inline int Compare<sbt_O143bvo>(const sbt_O143bvo &a, const sbt_O143bvo &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_DGMQt, b.sbt_DGMQt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KFZI5, b.sbt_KFZI5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Xkj, b.sbt_Xkj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__rsAycCA9, b.sbt__rsAycCA9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ghYNwFNIV, b.sbt_ghYNwFNIV)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_O143bvo>(const sbt_O143bvo &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_DGMQt, pHasher);
	Hash(p.sbt_KFZI5, pHasher);
	Hash(p.sbt_Xkj, pHasher);
	Hash(p.sbt__rsAycCA9, pHasher);
	Hash(p.sbt_ghYNwFNIV, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_O143bvo>(sbt_O143bvo p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DGMQt", p.sbt_DGMQt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KFZI5", p.sbt_KFZI5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Xkj", p.sbt_Xkj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__rsAycCA9", p.sbt__rsAycCA9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ghYNwFNIV", p.sbt_ghYNwFNIV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_O143bvo>(sbt_O143bvo &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_DGMQt", p.sbt_DGMQt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KFZI5", p.sbt_KFZI5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Xkj", p.sbt_Xkj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__rsAycCA9", p.sbt__rsAycCA9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ghYNwFNIV", p.sbt_ghYNwFNIV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

