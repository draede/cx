
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_k.hpp"
#include "sbt_BqQpOQzSt4u.hpp"


class sbt_p
{
public:

	sbt_k sbt_1i8q_;
	CX::Int8 sbt_3jR;
	sbt_BqQpOQzSt4u sbt_B;
	CX::SB::Map<CX::Bool, CX::WString>::Type sbt_BKF;
	CX::UInt8 sbt_nXY;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_p &p)
{
	DefInit(p.sbt_1i8q_);
	DefInit(p.sbt_3jR);
	DefInit(p.sbt_B);
	DefInit(p.sbt_BKF);
	DefInit(p.sbt_nXY);
}

template <> static inline int Compare<sbt_p>(const sbt_p &a, const sbt_p &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1i8q_, b.sbt_1i8q_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_3jR, b.sbt_3jR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_B, b.sbt_B)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_BKF, b.sbt_BKF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nXY, b.sbt_nXY)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_p>(const sbt_p &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1i8q_, pHasher);
	Hash(p.sbt_3jR, pHasher);
	Hash(p.sbt_B, pHasher);
	Hash(p.sbt_BKF, pHasher);
	Hash(p.sbt_nXY, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_p>(sbt_p p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1i8q_", p.sbt_1i8q_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3jR", p.sbt_3jR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_B", p.sbt_B)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BKF", p.sbt_BKF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nXY", p.sbt_nXY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_p>(sbt_p &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1i8q_", p.sbt_1i8q_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_3jR", p.sbt_3jR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_B", p.sbt_B)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_BKF", p.sbt_BKF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nXY", p.sbt_nXY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

