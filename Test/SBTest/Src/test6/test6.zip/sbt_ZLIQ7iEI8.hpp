
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_OBb.hpp"
#include "sbt_y4nqlCNALJ9.hpp"
#include "sbt_C7P8zUDllnp.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"


class sbt_ZLIQ7iEI8
{
public:

	CX::Double sbt_5z9;
	sbt_OBb sbt_9JwUb;
	CX::SB::Vector<sbt_y4nqlCNALJ9>::Type sbt_DUyNPSe;
	CX::SB::Vector<CX::Int8>::Type sbt_JVXDJ;
	CX::SB::Map<CX::Bool, CX::Double>::Type sbt_Jcjdz;
	CX::SB::Map<sbt_C7P8zUDllnp, sbt_FPkFvDvdxSroSAyqQ>::Type sbt_Z;
	CX::SB::Vector<CX::UInt8>::Type sbt_Zb2vV;
	CX::Int16 sbt_l;
	CX::SB::Map<CX::UInt64, CX::String>::Type sbt_nHT;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_ZLIQ7iEI8 &p)
{
	DefInit(p.sbt_5z9);
	DefInit(p.sbt_9JwUb);
	DefInit(p.sbt_DUyNPSe);
	DefInit(p.sbt_JVXDJ);
	DefInit(p.sbt_Jcjdz);
	DefInit(p.sbt_Z);
	DefInit(p.sbt_Zb2vV);
	DefInit(p.sbt_l);
	DefInit(p.sbt_nHT);
}

template <> static inline int Compare<sbt_ZLIQ7iEI8>(const sbt_ZLIQ7iEI8 &a, const sbt_ZLIQ7iEI8 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5z9, b.sbt_5z9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_9JwUb, b.sbt_9JwUb)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_DUyNPSe, b.sbt_DUyNPSe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_JVXDJ, b.sbt_JVXDJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Jcjdz, b.sbt_Jcjdz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Z, b.sbt_Z)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Zb2vV, b.sbt_Zb2vV)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l, b.sbt_l)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nHT, b.sbt_nHT)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_ZLIQ7iEI8>(const sbt_ZLIQ7iEI8 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5z9, pHasher);
	Hash(p.sbt_9JwUb, pHasher);
	Hash(p.sbt_DUyNPSe, pHasher);
	Hash(p.sbt_JVXDJ, pHasher);
	Hash(p.sbt_Jcjdz, pHasher);
	Hash(p.sbt_Z, pHasher);
	Hash(p.sbt_Zb2vV, pHasher);
	Hash(p.sbt_l, pHasher);
	Hash(p.sbt_nHT, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_ZLIQ7iEI8>(sbt_ZLIQ7iEI8 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5z9", p.sbt_5z9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9JwUb", p.sbt_9JwUb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DUyNPSe", p.sbt_DUyNPSe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_JVXDJ", p.sbt_JVXDJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Jcjdz", p.sbt_Jcjdz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Z", p.sbt_Z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Zb2vV", p.sbt_Zb2vV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nHT", p.sbt_nHT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_ZLIQ7iEI8>(sbt_ZLIQ7iEI8 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5z9", p.sbt_5z9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_9JwUb", p.sbt_9JwUb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_DUyNPSe", p.sbt_DUyNPSe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_JVXDJ", p.sbt_JVXDJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Jcjdz", p.sbt_Jcjdz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Z", p.sbt_Z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Zb2vV", p.sbt_Zb2vV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nHT", p.sbt_nHT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

