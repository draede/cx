
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_5sgGyJJOYBQ8tRa.hpp"
#include "sbt_0Se0hGnpT5kld.hpp"


class sbt_INFB9BDuanqhAnJ
{
public:

	CX::UInt16 sbt_4xf;
	CX::WString sbt_B;
	CX::SB::Vector<CX::Int16>::Type sbt_G;
	sbt_5sgGyJJOYBQ8tRa sbt_JcaJPQg6o;
	sbt_0Se0hGnpT5kld sbt_q8aft;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_INFB9BDuanqhAnJ &p)
{
	DefInit(p.sbt_4xf);
	DefInit(p.sbt_B);
	DefInit(p.sbt_G);
	DefInit(p.sbt_JcaJPQg6o);
	DefInit(p.sbt_q8aft);
}

template <> static inline int Compare<sbt_INFB9BDuanqhAnJ>(const sbt_INFB9BDuanqhAnJ &a, const sbt_INFB9BDuanqhAnJ &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4xf, b.sbt_4xf)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_B, b.sbt_B)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_G, b.sbt_G)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_JcaJPQg6o, b.sbt_JcaJPQg6o)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_q8aft, b.sbt_q8aft)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_INFB9BDuanqhAnJ>(const sbt_INFB9BDuanqhAnJ &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4xf, pHasher);
	Hash(p.sbt_B, pHasher);
	Hash(p.sbt_G, pHasher);
	Hash(p.sbt_JcaJPQg6o, pHasher);
	Hash(p.sbt_q8aft, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_INFB9BDuanqhAnJ>(sbt_INFB9BDuanqhAnJ p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4xf", p.sbt_4xf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_B", p.sbt_B)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_G", p.sbt_G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_JcaJPQg6o", p.sbt_JcaJPQg6o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_q8aft", p.sbt_q8aft)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_INFB9BDuanqhAnJ>(sbt_INFB9BDuanqhAnJ &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4xf", p.sbt_4xf)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_B", p.sbt_B)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_G", p.sbt_G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_JcaJPQg6o", p.sbt_JcaJPQg6o)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_q8aft", p.sbt_q8aft)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

