
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_A.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"
#include "sbt_k.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6Bx.hpp"


class sbt_p0PAX
{
public:

	CX::SB::Map<sbt_A, sbt_FPkFvDvdxSroSAyqQ>::Type sbt_I3yBTvc;
	CX::SB::Map<CX::Float, CX::Bool>::Type sbt_Rg4eUHi;
	CX::Int64 sbt_Zg9;
	sbt_k sbt_aHlisy3cv;
	CX::Int32 sbt_f;
	CX::SB::Vector<CX::Int16>::Type sbt_o9BwH;
	sbt_4zanj_ga3ZYRmUoH6Bx sbt_p;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_p0PAX &p)
{
	DefInit(p.sbt_I3yBTvc);
	DefInit(p.sbt_Rg4eUHi);
	DefInit(p.sbt_Zg9);
	DefInit(p.sbt_aHlisy3cv);
	DefInit(p.sbt_f);
	DefInit(p.sbt_o9BwH);
	DefInit(p.sbt_p);
}

template <> static inline int Compare<sbt_p0PAX>(const sbt_p0PAX &a, const sbt_p0PAX &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_I3yBTvc, b.sbt_I3yBTvc)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Rg4eUHi, b.sbt_Rg4eUHi)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Zg9, b.sbt_Zg9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aHlisy3cv, b.sbt_aHlisy3cv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_f, b.sbt_f)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_o9BwH, b.sbt_o9BwH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_p, b.sbt_p)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_p0PAX>(const sbt_p0PAX &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_I3yBTvc, pHasher);
	Hash(p.sbt_Rg4eUHi, pHasher);
	Hash(p.sbt_Zg9, pHasher);
	Hash(p.sbt_aHlisy3cv, pHasher);
	Hash(p.sbt_f, pHasher);
	Hash(p.sbt_o9BwH, pHasher);
	Hash(p.sbt_p, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_p0PAX>(sbt_p0PAX p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_I3yBTvc", p.sbt_I3yBTvc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Rg4eUHi", p.sbt_Rg4eUHi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Zg9", p.sbt_Zg9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aHlisy3cv", p.sbt_aHlisy3cv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_f", p.sbt_f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_o9BwH", p.sbt_o9BwH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_p0PAX>(sbt_p0PAX &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_I3yBTvc", p.sbt_I3yBTvc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Rg4eUHi", p.sbt_Rg4eUHi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Zg9", p.sbt_Zg9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aHlisy3cv", p.sbt_aHlisy3cv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_f", p.sbt_f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_o9BwH", p.sbt_o9BwH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_p", p.sbt_p)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

