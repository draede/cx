
#pragma once


#include "sbt_C7P8zUDllnp.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_5sgGyJJOYBQ8tRaTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_C7P8zUDllnp &p)
{
	TestInit(p.sbt_jFFPw5S7d);
}

static inline void RandInit(sbt_C7P8zUDllnp &p)
{
	RandInit(p.sbt_jFFPw5S7d);
}

}//namespace SB

}//namespace CX

