
#pragma once


#include "sbt_Lv6Cc5HdY.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ZTIUWTest.hpp"
#include "sbt_ATest.hpp"
#include "sbt_Lu55mymTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Lv6Cc5HdY &p)
{
	p.sbt_8Wtbx = -73;
	TestInit(p.sbt_9_T0BvqEC);
	p.sbt_F = 0.670729;
	p.sbt_F8e9Fy4.push_back("Q%5{U]");
	TestInit(p.sbt_LXl);
	p.sbt_SVW6e = 44;
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	p.sbt_fJCRr_nOW = 2544585185;
	p.sbt_scWE48n = 16180519;
}

static inline void RandInit(sbt_Lv6Cc5HdY &p)
{
	p.sbt_8Wtbx = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_9_T0BvqEC);
	p.sbt_F = CX::Util::RndGen::Get().GetDouble();
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_F8e9Fy4.push_back(Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	RandInit(p.sbt_LXl);
	p.sbt_SVW6e = CX::Util::RndGen::Get().GetUInt8();
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	{
		sbt_Lu55mym k;

		TestInit(k);
		p.sbt_Sk1Kx2Cce.push_back(k);
	}
	p.sbt_fJCRr_nOW = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_scWE48n = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

