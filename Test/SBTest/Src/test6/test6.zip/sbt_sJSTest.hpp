
#pragma once


#include "sbt_sJS.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"
#include "sbt_kTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_sJS &p)
{
	p.sbt_0JD.push_back(64379);
	p.sbt_0JD.push_back(46651);
	p.sbt_0JD.push_back(38119);
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	p.sbt_JERpiLnmM = "7#O]Au[#q";
	p.sbt_jXhaptj0z = "Oqo=U-eq[{!7_yY#cK9[Mm9";
}

static inline void RandInit(sbt_sJS &p)
{
	p.sbt_0JD.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_0JD.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_0JD.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_0JD.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_0JD.push_back(CX::Util::RndGen::Get().GetUInt16());
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_8yz4yJO.push_back(k);
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_HO_[k] = v;
	}
	p.sbt_JERpiLnmM = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_jXhaptj0z = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

