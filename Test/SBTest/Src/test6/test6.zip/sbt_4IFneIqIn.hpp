
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"


class sbt_4IFneIqIn
{
public:

	CX::Double sbt_5;
	CX::Double sbt_APfw8;
	CX::Bool sbt_Vba;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_4IFneIqIn &p)
{
	DefInit(p.sbt_5);
	DefInit(p.sbt_APfw8);
	DefInit(p.sbt_Vba);
}

template <> static inline int Compare<sbt_4IFneIqIn>(const sbt_4IFneIqIn &a, const sbt_4IFneIqIn &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5, b.sbt_5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_APfw8, b.sbt_APfw8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Vba, b.sbt_Vba)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_4IFneIqIn>(const sbt_4IFneIqIn &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5, pHasher);
	Hash(p.sbt_APfw8, pHasher);
	Hash(p.sbt_Vba, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_4IFneIqIn>(sbt_4IFneIqIn p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5", p.sbt_5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_APfw8", p.sbt_APfw8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Vba", p.sbt_Vba)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_4IFneIqIn>(sbt_4IFneIqIn &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5", p.sbt_5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_APfw8", p.sbt_APfw8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Vba", p.sbt_Vba)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

