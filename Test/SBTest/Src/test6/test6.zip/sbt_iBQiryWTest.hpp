
#pragma once


#include "sbt_iBQiryW.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_BqQpOQzSt4uTest.hpp"
#include "sbt_uE_IyAxSbkvGbDlAeTest.hpp"
#include "sbt_ATest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_iBQiryW &p)
{
	p.sbt_3 = 116;
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	p.sbt_SNPGRnDB2 = "!C?5K/cwMM]c!";
	p.sbt__Cu = 0.773334;
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		TestInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
}

static inline void RandInit(sbt_iBQiryW &p)
{
	p.sbt_3 = CX::Util::RndGen::Get().GetUInt8();
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	{
		sbt_BqQpOQzSt4u k;

		TestInit(k);
		p.sbt_8o0.push_back(k);
	}
	p.sbt_SNPGRnDB2 = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt__Cu = CX::Util::RndGen::Get().GetDouble();
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
	{
		sbt_uE_IyAxSbkvGbDlAe k;
		sbt_A v;

		RandInit(k);
		TestInit(v);
		p.sbt_bFk[k] = v;
	}
}

}//namespace SB

}//namespace CX

