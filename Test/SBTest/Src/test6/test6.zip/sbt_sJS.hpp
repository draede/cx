
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_HBYCFckMOOiNb.hpp"
#include "sbt_k.hpp"


class sbt_sJS
{
public:

	CX::SB::Vector<CX::UInt16>::Type sbt_0JD;
	CX::SB::Vector<sbt_225XhmpEekJ7un9iL>::Type sbt_8yz4yJO;
	CX::SB::Map<sbt_HBYCFckMOOiNb, sbt_k>::Type sbt_HO_;
	CX::String sbt_JERpiLnmM;
	CX::String sbt_jXhaptj0z;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_sJS &p)
{
	DefInit(p.sbt_0JD);
	DefInit(p.sbt_8yz4yJO);
	DefInit(p.sbt_HO_);
	DefInit(p.sbt_JERpiLnmM);
	DefInit(p.sbt_jXhaptj0z);
}

template <> static inline int Compare<sbt_sJS>(const sbt_sJS &a, const sbt_sJS &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0JD, b.sbt_0JD)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_8yz4yJO, b.sbt_8yz4yJO)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_HO_, b.sbt_HO_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_JERpiLnmM, b.sbt_JERpiLnmM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_jXhaptj0z, b.sbt_jXhaptj0z)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_sJS>(const sbt_sJS &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0JD, pHasher);
	Hash(p.sbt_8yz4yJO, pHasher);
	Hash(p.sbt_HO_, pHasher);
	Hash(p.sbt_JERpiLnmM, pHasher);
	Hash(p.sbt_jXhaptj0z, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_sJS>(sbt_sJS p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0JD", p.sbt_0JD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8yz4yJO", p.sbt_8yz4yJO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_HO_", p.sbt_HO_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_JERpiLnmM", p.sbt_JERpiLnmM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_jXhaptj0z", p.sbt_jXhaptj0z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_sJS>(sbt_sJS &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0JD", p.sbt_0JD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_8yz4yJO", p.sbt_8yz4yJO)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_HO_", p.sbt_HO_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_JERpiLnmM", p.sbt_JERpiLnmM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_jXhaptj0z", p.sbt_jXhaptj0z)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

