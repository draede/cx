
#pragma once


#include "sbt_3YcOGtzqwTtSwgm3E.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_3YcOGtzqwTtSwgm3E &p)
{
	p.sbt_IPOvb2pj9[true] = -73;
	p.sbt_IPOvb2pj9[true] = 12;
	p.sbt_IPOvb2pj9[false] = -122;
	p.sbt_IPOvb2pj9[false] = -21;
	p.sbt_IPOvb2pj9[true] = 56;
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	p.sbt_VeX0aWrjE = L"3UK5_mmc/Ys";
}

static inline void RandInit(sbt_3YcOGtzqwTtSwgm3E &p)
{
	p.sbt_IPOvb2pj9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_IPOvb2pj9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_IPOvb2pj9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_IPOvb2pj9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_IPOvb2pj9[CX::Util::RndGen::Get().GetBool()] = CX::Util::RndGen::Get().GetInt8();
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_NIW8rz4[k] = v;
	}
	p.sbt_VeX0aWrjE = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

