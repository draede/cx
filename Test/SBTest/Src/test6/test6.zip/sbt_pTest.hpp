
#pragma once


#include "sbt_p.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_kTest.hpp"
#include "sbt_BqQpOQzSt4uTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_p &p)
{
	TestInit(p.sbt_1i8q_);
	p.sbt_3jR = -84;
	TestInit(p.sbt_B);
	p.sbt_BKF[true] = L"+#quIC5emogyk]E{W=9WCees";
	p.sbt_BKF[false] = L"mckYo7}Ai]+9_sM=yyC?";
	p.sbt_BKF[false] = L"'+i;m";
	p.sbt_BKF[true] = L"1ykM#S7WMaI){1cUk3#m1#A_y?/3";
	p.sbt_BKF[true] = L"M]'c!I{";
	p.sbt_BKF[true] = L"31EO}9g/GGm[S";
	p.sbt_BKF[true] = L"_C}G]ae?y);5=e!Mw";
	p.sbt_nXY = 1;
}

static inline void RandInit(sbt_p &p)
{
	RandInit(p.sbt_1i8q_);
	p.sbt_3jR = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_B);
	p.sbt_BKF[CX::Util::RndGen::Get().GetBool()] = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_nXY = CX::Util::RndGen::Get().GetUInt8();
}

}//namespace SB

}//namespace CX

