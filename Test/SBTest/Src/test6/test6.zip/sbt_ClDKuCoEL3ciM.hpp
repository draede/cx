
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_qCP3a4QA8VG.hpp"
#include "sbt_FwDSmFyQ8yGqWNv19.hpp"
#include "sbt_gvj_DWPqkRZ0XCFOndC.hpp"


class sbt_ClDKuCoEL3ciM
{
public:

	CX::Int64 sbt_CFQC2mI;
	CX::SB::Vector<CX::UInt16>::Type sbt_FPY;
	CX::SB::Vector<CX::Bool>::Type sbt_T5nkMNK0n;
	sbt_qCP3a4QA8VG sbt_iM6;
	CX::SB::Map<CX::Float, CX::UInt32>::Type sbt_wQvj5UR;
	sbt_FwDSmFyQ8yGqWNv19 sbt_yml7XsOq7;
	sbt_gvj_DWPqkRZ0XCFOndC sbt_zdNY7;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_ClDKuCoEL3ciM &p)
{
	DefInit(p.sbt_CFQC2mI);
	DefInit(p.sbt_FPY);
	DefInit(p.sbt_T5nkMNK0n);
	DefInit(p.sbt_iM6);
	DefInit(p.sbt_wQvj5UR);
	DefInit(p.sbt_yml7XsOq7);
	DefInit(p.sbt_zdNY7);
}

template <> static inline int Compare<sbt_ClDKuCoEL3ciM>(const sbt_ClDKuCoEL3ciM &a, const sbt_ClDKuCoEL3ciM &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_CFQC2mI, b.sbt_CFQC2mI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_FPY, b.sbt_FPY)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_T5nkMNK0n, b.sbt_T5nkMNK0n)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iM6, b.sbt_iM6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wQvj5UR, b.sbt_wQvj5UR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yml7XsOq7, b.sbt_yml7XsOq7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zdNY7, b.sbt_zdNY7)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_ClDKuCoEL3ciM>(const sbt_ClDKuCoEL3ciM &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_CFQC2mI, pHasher);
	Hash(p.sbt_FPY, pHasher);
	Hash(p.sbt_T5nkMNK0n, pHasher);
	Hash(p.sbt_iM6, pHasher);
	Hash(p.sbt_wQvj5UR, pHasher);
	Hash(p.sbt_yml7XsOq7, pHasher);
	Hash(p.sbt_zdNY7, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_ClDKuCoEL3ciM>(sbt_ClDKuCoEL3ciM p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_CFQC2mI", p.sbt_CFQC2mI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_FPY", p.sbt_FPY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_T5nkMNK0n", p.sbt_T5nkMNK0n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iM6", p.sbt_iM6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wQvj5UR", p.sbt_wQvj5UR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yml7XsOq7", p.sbt_yml7XsOq7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zdNY7", p.sbt_zdNY7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_ClDKuCoEL3ciM>(sbt_ClDKuCoEL3ciM &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_CFQC2mI", p.sbt_CFQC2mI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_FPY", p.sbt_FPY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_T5nkMNK0n", p.sbt_T5nkMNK0n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iM6", p.sbt_iM6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wQvj5UR", p.sbt_wQvj5UR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yml7XsOq7", p.sbt_yml7XsOq7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zdNY7", p.sbt_zdNY7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

