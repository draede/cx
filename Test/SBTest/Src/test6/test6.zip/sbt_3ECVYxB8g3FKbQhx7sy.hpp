
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"
#include "sbt_iBQiryW.hpp"


class sbt_3ECVYxB8g3FKbQhx7sy
{
public:

	CX::SB::Map<sbt_FPkFvDvdxSroSAyqQ, sbt_iBQiryW>::Type sbt_Pa2xP7DIW;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_3ECVYxB8g3FKbQhx7sy &p)
{
	DefInit(p.sbt_Pa2xP7DIW);
}

template <> static inline int Compare<sbt_3ECVYxB8g3FKbQhx7sy>(const sbt_3ECVYxB8g3FKbQhx7sy &a, const sbt_3ECVYxB8g3FKbQhx7sy &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Pa2xP7DIW, b.sbt_Pa2xP7DIW)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_3ECVYxB8g3FKbQhx7sy>(const sbt_3ECVYxB8g3FKbQhx7sy &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Pa2xP7DIW, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_3ECVYxB8g3FKbQhx7sy>(sbt_3ECVYxB8g3FKbQhx7sy p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Pa2xP7DIW", p.sbt_Pa2xP7DIW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_3ECVYxB8g3FKbQhx7sy>(sbt_3ECVYxB8g3FKbQhx7sy &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (1 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 1 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Pa2xP7DIW", p.sbt_Pa2xP7DIW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

