
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_4IFneIqIn.hpp"
#include "sbt_oX6wa.hpp"
#include "sbt_HBYCFckMOOiNb.hpp"


class sbt_FPkFvDvdxSroSAyqQ
{
public:

	CX::String sbt_7CM;
	CX::Int32 sbt_KDr7a;
	sbt_4IFneIqIn sbt_UIShr;
	CX::Int64 sbt_V1obJ;
	sbt_oX6wa sbt_hyl;
	sbt_HBYCFckMOOiNb sbt_l;
	CX::String sbt_nto;
	CX::UInt8 sbt_vBr;
	CX::UInt16 sbt_y0dpoVIlE;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_FPkFvDvdxSroSAyqQ &p)
{
	DefInit(p.sbt_7CM);
	DefInit(p.sbt_KDr7a);
	DefInit(p.sbt_UIShr);
	DefInit(p.sbt_V1obJ);
	DefInit(p.sbt_hyl);
	DefInit(p.sbt_l);
	DefInit(p.sbt_nto);
	DefInit(p.sbt_vBr);
	DefInit(p.sbt_y0dpoVIlE);
}

template <> static inline int Compare<sbt_FPkFvDvdxSroSAyqQ>(const sbt_FPkFvDvdxSroSAyqQ &a, const sbt_FPkFvDvdxSroSAyqQ &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_7CM, b.sbt_7CM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KDr7a, b.sbt_KDr7a)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UIShr, b.sbt_UIShr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_V1obJ, b.sbt_V1obJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_hyl, b.sbt_hyl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_l, b.sbt_l)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nto, b.sbt_nto)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_vBr, b.sbt_vBr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y0dpoVIlE, b.sbt_y0dpoVIlE)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_FPkFvDvdxSroSAyqQ>(const sbt_FPkFvDvdxSroSAyqQ &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_7CM, pHasher);
	Hash(p.sbt_KDr7a, pHasher);
	Hash(p.sbt_UIShr, pHasher);
	Hash(p.sbt_V1obJ, pHasher);
	Hash(p.sbt_hyl, pHasher);
	Hash(p.sbt_l, pHasher);
	Hash(p.sbt_nto, pHasher);
	Hash(p.sbt_vBr, pHasher);
	Hash(p.sbt_y0dpoVIlE, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_FPkFvDvdxSroSAyqQ>(sbt_FPkFvDvdxSroSAyqQ p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7CM", p.sbt_7CM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KDr7a", p.sbt_KDr7a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UIShr", p.sbt_UIShr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_V1obJ", p.sbt_V1obJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_hyl", p.sbt_hyl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nto", p.sbt_nto)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_vBr", p.sbt_vBr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y0dpoVIlE", p.sbt_y0dpoVIlE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_FPkFvDvdxSroSAyqQ>(sbt_FPkFvDvdxSroSAyqQ &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_7CM", p.sbt_7CM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KDr7a", p.sbt_KDr7a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UIShr", p.sbt_UIShr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_V1obJ", p.sbt_V1obJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_hyl", p.sbt_hyl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_l", p.sbt_l)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nto", p.sbt_nto)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_vBr", p.sbt_vBr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y0dpoVIlE", p.sbt_y0dpoVIlE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

