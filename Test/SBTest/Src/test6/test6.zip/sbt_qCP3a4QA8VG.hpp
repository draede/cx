
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"


class sbt_qCP3a4QA8VG
{
public:

	sbt_FPkFvDvdxSroSAyqQ sbt_5znlIlV;
	CX::SB::Map<CX::UInt64, CX::Int8>::Type sbt_H;
	CX::UInt32 sbt_L;
	CX::SB::Vector<sbt_225XhmpEekJ7un9iL>::Type sbt_afp49Uv0F;
	CX::UInt16 sbt_e82IsIT;
	CX::Double sbt_iVuHLn7;
	sbt_225XhmpEekJ7un9iL sbt_yCNIV5vNA;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_qCP3a4QA8VG &p)
{
	DefInit(p.sbt_5znlIlV);
	DefInit(p.sbt_H);
	DefInit(p.sbt_L);
	DefInit(p.sbt_afp49Uv0F);
	DefInit(p.sbt_e82IsIT);
	DefInit(p.sbt_iVuHLn7);
	DefInit(p.sbt_yCNIV5vNA);
}

template <> static inline int Compare<sbt_qCP3a4QA8VG>(const sbt_qCP3a4QA8VG &a, const sbt_qCP3a4QA8VG &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5znlIlV, b.sbt_5znlIlV)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_H, b.sbt_H)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_L, b.sbt_L)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_afp49Uv0F, b.sbt_afp49Uv0F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_e82IsIT, b.sbt_e82IsIT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iVuHLn7, b.sbt_iVuHLn7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yCNIV5vNA, b.sbt_yCNIV5vNA)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_qCP3a4QA8VG>(const sbt_qCP3a4QA8VG &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5znlIlV, pHasher);
	Hash(p.sbt_H, pHasher);
	Hash(p.sbt_L, pHasher);
	Hash(p.sbt_afp49Uv0F, pHasher);
	Hash(p.sbt_e82IsIT, pHasher);
	Hash(p.sbt_iVuHLn7, pHasher);
	Hash(p.sbt_yCNIV5vNA, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_qCP3a4QA8VG>(sbt_qCP3a4QA8VG p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5znlIlV", p.sbt_5znlIlV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_H", p.sbt_H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_L", p.sbt_L)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_afp49Uv0F", p.sbt_afp49Uv0F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_e82IsIT", p.sbt_e82IsIT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iVuHLn7", p.sbt_iVuHLn7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yCNIV5vNA", p.sbt_yCNIV5vNA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_qCP3a4QA8VG>(sbt_qCP3a4QA8VG &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5znlIlV", p.sbt_5znlIlV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_H", p.sbt_H)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_L", p.sbt_L)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_afp49Uv0F", p.sbt_afp49Uv0F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_e82IsIT", p.sbt_e82IsIT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iVuHLn7", p.sbt_iVuHLn7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yCNIV5vNA", p.sbt_yCNIV5vNA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

