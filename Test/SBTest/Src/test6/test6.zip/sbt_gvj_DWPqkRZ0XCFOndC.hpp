
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_4IFneIqIn.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxF.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_k.hpp"


class sbt_gvj_DWPqkRZ0XCFOndC
{
public:

	CX::Float sbt_J6eXh1JJT;
	CX::WString sbt_SRDRt;
	CX::SB::Map<sbt_4IFneIqIn, sbt_aGqmCqmCkLer6NUtTxF>::Type sbt_Sdl;
	CX::Int16 sbt_c0A;
	sbt_225XhmpEekJ7un9iL sbt_pEehP;
	CX::SB::Map<CX::String, CX::Int8>::Type sbt_r;
	sbt_k sbt_yfw_g4q;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_gvj_DWPqkRZ0XCFOndC &p)
{
	DefInit(p.sbt_J6eXh1JJT);
	DefInit(p.sbt_SRDRt);
	DefInit(p.sbt_Sdl);
	DefInit(p.sbt_c0A);
	DefInit(p.sbt_pEehP);
	DefInit(p.sbt_r);
	DefInit(p.sbt_yfw_g4q);
}

template <> static inline int Compare<sbt_gvj_DWPqkRZ0XCFOndC>(const sbt_gvj_DWPqkRZ0XCFOndC &a, const sbt_gvj_DWPqkRZ0XCFOndC &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_J6eXh1JJT, b.sbt_J6eXh1JJT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SRDRt, b.sbt_SRDRt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sdl, b.sbt_Sdl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_c0A, b.sbt_c0A)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pEehP, b.sbt_pEehP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_r, b.sbt_r)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_yfw_g4q, b.sbt_yfw_g4q)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_gvj_DWPqkRZ0XCFOndC>(const sbt_gvj_DWPqkRZ0XCFOndC &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_J6eXh1JJT, pHasher);
	Hash(p.sbt_SRDRt, pHasher);
	Hash(p.sbt_Sdl, pHasher);
	Hash(p.sbt_c0A, pHasher);
	Hash(p.sbt_pEehP, pHasher);
	Hash(p.sbt_r, pHasher);
	Hash(p.sbt_yfw_g4q, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_gvj_DWPqkRZ0XCFOndC>(sbt_gvj_DWPqkRZ0XCFOndC p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_J6eXh1JJT", p.sbt_J6eXh1JJT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SRDRt", p.sbt_SRDRt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sdl", p.sbt_Sdl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_c0A", p.sbt_c0A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pEehP", p.sbt_pEehP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_yfw_g4q", p.sbt_yfw_g4q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_gvj_DWPqkRZ0XCFOndC>(sbt_gvj_DWPqkRZ0XCFOndC &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_J6eXh1JJT", p.sbt_J6eXh1JJT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SRDRt", p.sbt_SRDRt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sdl", p.sbt_Sdl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_c0A", p.sbt_c0A)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pEehP", p.sbt_pEehP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_yfw_g4q", p.sbt_yfw_g4q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

