
#pragma once


#include "sbt_ClDKuCoEL3ciM.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_qCP3a4QA8VGTest.hpp"
#include "sbt_FwDSmFyQ8yGqWNv19Test.hpp"
#include "sbt_gvj_DWPqkRZ0XCFOndCTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_ClDKuCoEL3ciM &p)
{
	p.sbt_CFQC2mI = -8783868295018599992;
	p.sbt_FPY.push_back(50071);
	p.sbt_FPY.push_back(56098);
	p.sbt_FPY.push_back(60046);
	p.sbt_T5nkMNK0n.push_back(false);
	p.sbt_T5nkMNK0n.push_back(true);
	p.sbt_T5nkMNK0n.push_back(true);
	p.sbt_T5nkMNK0n.push_back(false);
	p.sbt_T5nkMNK0n.push_back(true);
	p.sbt_T5nkMNK0n.push_back(false);
	p.sbt_T5nkMNK0n.push_back(true);
	TestInit(p.sbt_iM6);
	p.sbt_wQvj5UR[0.257124f] = 886849329;
	p.sbt_wQvj5UR[0.550966f] = 1876793903;
	p.sbt_wQvj5UR[0.400561f] = 3968494844;
	p.sbt_wQvj5UR[0.013904f] = 835500726;
	p.sbt_wQvj5UR[0.276310f] = 1409765295;
	p.sbt_wQvj5UR[0.907185f] = 3420538187;
	p.sbt_wQvj5UR[0.185801f] = 2661051965;
	p.sbt_wQvj5UR[0.720191f] = 3030877602;
	p.sbt_wQvj5UR[0.805707f] = 433844821;
	TestInit(p.sbt_yml7XsOq7);
	TestInit(p.sbt_zdNY7);
}

static inline void RandInit(sbt_ClDKuCoEL3ciM &p)
{
	p.sbt_CFQC2mI = CX::Util::RndGen::Get().GetInt64();
	p.sbt_FPY.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_T5nkMNK0n.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_T5nkMNK0n.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_T5nkMNK0n.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_T5nkMNK0n.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_T5nkMNK0n.push_back(CX::Util::RndGen::Get().GetBool());
	RandInit(p.sbt_iM6);
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_wQvj5UR[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetUInt32();
	RandInit(p.sbt_yml7XsOq7);
	RandInit(p.sbt_zdNY7);
}

}//namespace SB

}//namespace CX

