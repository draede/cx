
#pragma once


#include "sbt_4zanj_ga3ZYRmUoH6Bx.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxFTest.hpp"
#include "sbt_O143bvoTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_4zanj_ga3ZYRmUoH6Bx &p)
{
	p.sbt_3WN8Es8bd = 14982502046074982654;
	TestInit(p.sbt_4);
	p.sbt_Aii1EpxwH[0.179978] = 18179;
	p.sbt_Aii1EpxwH[0.573029] = 20464;
	p.sbt_Aii1EpxwH[0.206464] = -945;
	p.sbt_Aii1EpxwH[0.591180] = 3126;
	p.sbt_Aii1EpxwH[0.128436] = 16781;
	p.sbt_BBiE7 = 0.032245;
	p.sbt_O6Lbu = -16826;
	TestInit(p.sbt_YHFMP);
	p.sbt_d = 15963646385573523848;
	TestInit(p.sbt_dP_NokC);
	p.sbt_urK.push_back(-9203);
	p.sbt_urK.push_back(26615);
	p.sbt_urK.push_back(-6155);
}

static inline void RandInit(sbt_4zanj_ga3ZYRmUoH6Bx &p)
{
	p.sbt_3WN8Es8bd = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_4);
	p.sbt_Aii1EpxwH[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_Aii1EpxwH[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_Aii1EpxwH[CX::Util::RndGen::Get().GetDouble()] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_BBiE7 = CX::Util::RndGen::Get().GetDouble();
	p.sbt_O6Lbu = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_YHFMP);
	p.sbt_d = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_dP_NokC);
	p.sbt_urK.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_urK.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_urK.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_urK.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_urK.push_back(CX::Util::RndGen::Get().GetInt16());
}

}//namespace SB

}//namespace CX

