
#pragma once


#include "sbt_aUW9C30.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"
#include "sbt_3ECVYxB8g3FKbQhx7syTest.hpp"
#include "sbt_xCVTest.hpp"
#include "sbt_kTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_aUW9C30 &p)
{
	p.sbt_8 = -7961;
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		TestInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	p.sbt_J.push_back(0.245123);
	p.sbt_J.push_back(0.219043);
	p.sbt_J.push_back(0.242692);
	{
		sbt_xCV k;

		TestInit(k);
		p.sbt_ZxiXDd9gS.push_back(k);
	}
	p.sbt_aBfsRUe[L"ceU3"] = 1200959923408224736;
	p.sbt_eLnYOiUwR[-1515502820] = 7375663202150203724;
	p.sbt_h9Abea3 = L"o-)OaY/[S%?AYQ''}";
	p.sbt_hQP[19916933] = 0.475719f;
	p.sbt_hQP[815418913] = 0.543977f;
	p.sbt_hQP[529017388] = 0.209141f;
	p.sbt_hQP[1963138340] = 0.810096f;
	p.sbt_hQP[-163292837] = 0.402029f;
	p.sbt_hQP[30961956] = 0.443542f;
	p.sbt_hQP[-1337235871] = 0.930308f;
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
}

static inline void RandInit(sbt_aUW9C30 &p)
{
	p.sbt_8 = CX::Util::RndGen::Get().GetInt16();
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		RandInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		RandInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		RandInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		RandInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	{
		sbt_HBYCFckMOOiNb k;
		sbt_3ECVYxB8g3FKbQhx7sy v;

		RandInit(k);
		TestInit(v);
		p.sbt_F[k] = v;
	}
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	p.sbt_J.push_back(CX::Util::RndGen::Get().GetDouble());
	{
		sbt_xCV k;

		TestInit(k);
		p.sbt_ZxiXDd9gS.push_back(k);
	}
	{
		sbt_xCV k;

		TestInit(k);
		p.sbt_ZxiXDd9gS.push_back(k);
	}
	{
		sbt_xCV k;

		TestInit(k);
		p.sbt_ZxiXDd9gS.push_back(k);
	}
	{
		sbt_xCV k;

		TestInit(k);
		p.sbt_ZxiXDd9gS.push_back(k);
	}
	{
		sbt_xCV k;

		TestInit(k);
		p.sbt_ZxiXDd9gS.push_back(k);
	}
	p.sbt_aBfsRUe[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_eLnYOiUwR[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_h9Abea3 = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_hQP[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetFloat();
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
	{
		sbt_k k;

		TestInit(k);
		p.sbt_oHTQuQQ.push_back(k);
	}
}

}//namespace SB

}//namespace CX

