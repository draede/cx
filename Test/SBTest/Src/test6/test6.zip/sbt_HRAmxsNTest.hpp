
#pragma once


#include "sbt_HRAmxsN.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_3YcOGtzqwTtSwgm3ETest.hpp"
#include "sbt_oX6waTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_HRAmxsN &p)
{
	p.sbt_2koZFA1.push_back(L"c]+S)q+/%i=M[q_yU}_-");
	p.sbt_2koZFA1.push_back(L"go}We3u/]II1a!QAy/Q=!");
	p.sbt_2koZFA1.push_back(L"Am_-");
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	TestInit(p.sbt_aA9MU7CKH);
	p.sbt_fMw30 = 1103675473;
	p.sbt_m1hYlkab6 = 2063904868543761762;
	p.sbt_nfnxZyfYH = 35443;
	p.sbt_pPX = 0.295152;
	TestInit(p.sbt_tcS);
	p.sbt_ydsIv7i = "oOe][]Ww)c'=eK)%3[UYWCQyY)_";
}

static inline void RandInit(sbt_HRAmxsN &p)
{
	p.sbt_2koZFA1.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_2koZFA1.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	p.sbt_2koZFA1.push_back(Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"));
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_Z0AZFbc03.push_back(k);
	}
	RandInit(p.sbt_aA9MU7CKH);
	p.sbt_fMw30 = CX::Util::RndGen::Get().GetInt32();
	p.sbt_m1hYlkab6 = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_nfnxZyfYH = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_pPX = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_tcS);
	p.sbt_ydsIv7i = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

