
#pragma once


#include "sbt_gNiZ3WOkV1jeetbhLzJ.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_Nq7Test.hpp"
#include "sbt_qCP3a4QA8VGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_gNiZ3WOkV1jeetbhLzJ &p)
{
	p.sbt_YKpPH4sfH = 219;
	TestInit(p.sbt_c);
	p.sbt_pbERo = 0.290414f;
	p.sbt_xjlGvkS55 = 641619877;
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
}

static inline void RandInit(sbt_gNiZ3WOkV1jeetbhLzJ &p)
{
	p.sbt_YKpPH4sfH = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_c);
	p.sbt_pbERo = CX::Util::RndGen::Get().GetFloat();
	p.sbt_xjlGvkS55 = CX::Util::RndGen::Get().GetInt32();
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_zxmExO5G_.push_back(k);
	}
}

}//namespace SB

}//namespace CX

