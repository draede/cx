
#pragma once


#include "sbt_qCP3a4QA8VG.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_qCP3a4QA8VG &p)
{
	TestInit(p.sbt_5znlIlV);
	p.sbt_H[5930615356796724186] = -92;
	p.sbt_H[17919943566627986172] = -42;
	p.sbt_H[10263226242436104056] = -52;
	p.sbt_H[6645368292831081638] = 76;
	p.sbt_H[848470876733278496] = -74;
	p.sbt_H[15196755736119433632] = 92;
	p.sbt_H[15452300708048384998] = 83;
	p.sbt_H[2920660876461386146] = -83;
	p.sbt_H[18244912652175376112] = 35;
	p.sbt_L = 2546326328;
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	p.sbt_e82IsIT = 8149;
	p.sbt_iVuHLn7 = 0.322381;
	TestInit(p.sbt_yCNIV5vNA);
}

static inline void RandInit(sbt_qCP3a4QA8VG &p)
{
	RandInit(p.sbt_5znlIlV);
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_H[CX::Util::RndGen::Get().GetUInt64()] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_L = CX::Util::RndGen::Get().GetUInt32();
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_afp49Uv0F.push_back(k);
	}
	p.sbt_e82IsIT = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_iVuHLn7 = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_yCNIV5vNA);
}

}//namespace SB

}//namespace CX

