
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_3YcOGtzqwTtSwgm3E.hpp"
#include "sbt_4IFneIqIn.hpp"


class sbt_aGqmCqmCkLer6NUtTxF
{
public:

	CX::SB::Vector<CX::Float>::Type sbt_6;
	CX::Int16 sbt_Wtl;
	CX::SB::Map<sbt_3YcOGtzqwTtSwgm3E, sbt_4IFneIqIn>::Type sbt_r;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_aGqmCqmCkLer6NUtTxF &p)
{
	DefInit(p.sbt_6);
	DefInit(p.sbt_Wtl);
	DefInit(p.sbt_r);
}

template <> static inline int Compare<sbt_aGqmCqmCkLer6NUtTxF>(const sbt_aGqmCqmCkLer6NUtTxF &a, const sbt_aGqmCqmCkLer6NUtTxF &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6, b.sbt_6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Wtl, b.sbt_Wtl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_r, b.sbt_r)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_aGqmCqmCkLer6NUtTxF>(const sbt_aGqmCqmCkLer6NUtTxF &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6, pHasher);
	Hash(p.sbt_Wtl, pHasher);
	Hash(p.sbt_r, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_aGqmCqmCkLer6NUtTxF>(sbt_aGqmCqmCkLer6NUtTxF p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6", p.sbt_6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Wtl", p.sbt_Wtl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_aGqmCqmCkLer6NUtTxF>(sbt_aGqmCqmCkLer6NUtTxF &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6", p.sbt_6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Wtl", p.sbt_Wtl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

