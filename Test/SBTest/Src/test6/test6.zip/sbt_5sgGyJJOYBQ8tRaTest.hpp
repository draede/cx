
#pragma once


#include "sbt_5sgGyJJOYBQ8tRa.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_0Se0hGnpT5kldTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_5sgGyJJOYBQ8tRa &p)
{
	TestInit(p.sbt_pUV);
}

static inline void RandInit(sbt_5sgGyJJOYBQ8tRa &p)
{
	RandInit(p.sbt_pUV);
}

}//namespace SB

}//namespace CX

