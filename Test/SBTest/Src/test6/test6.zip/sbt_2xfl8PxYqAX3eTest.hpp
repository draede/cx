
#pragma once


#include "sbt_2xfl8PxYqAX3e.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_iBQiryWTest.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_2xfl8PxYqAX3e &p)
{
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		TestInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		TestInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		TestInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
}

static inline void RandInit(sbt_2xfl8PxYqAX3e &p)
{
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
	{
		sbt_iBQiryW k;
		sbt_HBYCFckMOOiNb v;

		RandInit(k);
		TestInit(v);
		p.sbt_NNXYA[k] = v;
	}
}

}//namespace SB

}//namespace CX

