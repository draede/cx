
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_5sgGyJJOYBQ8tRa.hpp"
#include "sbt_qCP3a4QA8VG.hpp"


class sbt_ZTIUW
{
public:

	CX::SB::Vector<sbt_5sgGyJJOYBQ8tRa>::Type sbt_NSrARGSXS;
	CX::UInt32 sbt_ToZvB;
	CX::Int16 sbt_UHzZDZD1F;
	CX::SB::Vector<CX::Bool>::Type sbt_YXO3K;
	CX::UInt8 sbt_aocxr;
	sbt_qCP3a4QA8VG sbt_kTJ;
	sbt_qCP3a4QA8VG sbt_zQ7;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_ZTIUW &p)
{
	DefInit(p.sbt_NSrARGSXS);
	DefInit(p.sbt_ToZvB);
	DefInit(p.sbt_UHzZDZD1F);
	DefInit(p.sbt_YXO3K);
	DefInit(p.sbt_aocxr);
	DefInit(p.sbt_kTJ);
	DefInit(p.sbt_zQ7);
}

template <> static inline int Compare<sbt_ZTIUW>(const sbt_ZTIUW &a, const sbt_ZTIUW &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_NSrARGSXS, b.sbt_NSrARGSXS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ToZvB, b.sbt_ToZvB)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UHzZDZD1F, b.sbt_UHzZDZD1F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YXO3K, b.sbt_YXO3K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aocxr, b.sbt_aocxr)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_kTJ, b.sbt_kTJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zQ7, b.sbt_zQ7)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_ZTIUW>(const sbt_ZTIUW &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_NSrARGSXS, pHasher);
	Hash(p.sbt_ToZvB, pHasher);
	Hash(p.sbt_UHzZDZD1F, pHasher);
	Hash(p.sbt_YXO3K, pHasher);
	Hash(p.sbt_aocxr, pHasher);
	Hash(p.sbt_kTJ, pHasher);
	Hash(p.sbt_zQ7, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_ZTIUW>(sbt_ZTIUW p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_NSrARGSXS", p.sbt_NSrARGSXS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ToZvB", p.sbt_ToZvB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UHzZDZD1F", p.sbt_UHzZDZD1F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YXO3K", p.sbt_YXO3K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aocxr", p.sbt_aocxr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_kTJ", p.sbt_kTJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zQ7", p.sbt_zQ7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_ZTIUW>(sbt_ZTIUW &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_NSrARGSXS", p.sbt_NSrARGSXS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ToZvB", p.sbt_ToZvB)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UHzZDZD1F", p.sbt_UHzZDZD1F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YXO3K", p.sbt_YXO3K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aocxr", p.sbt_aocxr)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_kTJ", p.sbt_kTJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zQ7", p.sbt_zQ7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

