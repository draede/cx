
#pragma once


#include "sbt_y4nqlCNALJ9.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_qCP3a4QA8VGTest.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_y4nqlCNALJ9 &p)
{
	p.sbt_6pl1G[-727461217] = 154;
	p.sbt_6pl1G[-1554265838] = 79;
	p.sbt_6pl1G[1681732467] = 118;
	p.sbt_6pl1G[1974730487] = 70;
	p.sbt_6pl1G[-1026918391] = 193;
	p.sbt_6pl1G[157892491] = 253;
	p.sbt_6pl1G[-816801318] = 129;
	p.sbt_7e15rbH = 1389368933;
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_DfOMWFD[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_DfOMWFD[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_DfOMWFD[k] = v;
	}
	p.sbt_GJTK4iBSG = true;
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	p.sbt_QI5mITANA[29857] = 6849656376345873956;
	p.sbt_QI5mITANA[21161] = 1098547734247392200;
	p.sbt_QI5mITANA[6400] = 11534523937372465002;
	p.sbt_QI5mITANA[9571] = 14126975074730016098;
	p.sbt_QI5mITANA[43569] = 17082394116101646952;
	p.sbt_QI5mITANA[28376] = 2763118950997973646;
	p.sbt_QI5mITANA[39684] = 2584393955930627680;
	p.sbt_QI5mITANA[35193] = 745459656319586598;
	p.sbt_QI5mITANA[43987] = 17068925153099919968;
	p.sbt_Z8a = 634993441;
	p.sbt_sVCCP = 0.905942f;
	TestInit(p.sbt_vNqRt3E);
}

static inline void RandInit(sbt_y4nqlCNALJ9 &p)
{
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_6pl1G[CX::Util::RndGen::Get().GetInt32()] = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_7e15rbH = CX::Util::RndGen::Get().GetUInt32();
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_DfOMWFD[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_DfOMWFD[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_DfOMWFD[k] = v;
	}
	p.sbt_GJTK4iBSG = CX::Util::RndGen::Get().GetBool();
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	{
		sbt_qCP3a4QA8VG k;

		TestInit(k);
		p.sbt_M.push_back(k);
	}
	p.sbt_QI5mITANA[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_QI5mITANA[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_QI5mITANA[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_QI5mITANA[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_QI5mITANA[CX::Util::RndGen::Get().GetUInt16()] = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_Z8a = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_sVCCP = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_vNqRt3E);
}

}//namespace SB

}//namespace CX

