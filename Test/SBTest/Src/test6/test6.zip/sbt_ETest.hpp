
#pragma once


#include "sbt_E.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_O143bvoTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_E &p)
{
	TestInit(p.sbt_3MufHsg);
}

static inline void RandInit(sbt_E &p)
{
	RandInit(p.sbt_3MufHsg);
}

}//namespace SB

}//namespace CX

