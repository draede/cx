
#pragma once


#include "sbt_HBYCFckMOOiNb.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_4IFneIqInTest.hpp"
#include "sbt_3YcOGtzqwTtSwgm3ETest.hpp"
#include "sbt_HRAmxsNTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_HBYCFckMOOiNb &p)
{
	p.sbt_2IwgK = 0.518182f;
	p.sbt_5fK.push_back(0.445526f);
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		TestInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		TestInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		TestInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		TestInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		TestInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	TestInit(p.sbt_KID);
	p.sbt_RqN4K = 1204464713229962436;
	p.sbt_UCbE7R6n5 = 57211;
	TestInit(p.sbt_cvtykut);
}

static inline void RandInit(sbt_HBYCFckMOOiNb &p)
{
	p.sbt_2IwgK = CX::Util::RndGen::Get().GetFloat();
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_5fK.push_back(CX::Util::RndGen::Get().GetFloat());
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_3YcOGtzqwTtSwgm3E v;

		RandInit(k);
		TestInit(v);
		p.sbt_F_zwz0Q[k] = v;
	}
	RandInit(p.sbt_KID);
	p.sbt_RqN4K = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_UCbE7R6n5 = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_cvtykut);
}

}//namespace SB

}//namespace CX

