
#pragma once


#include "sbt_4IFneIqIn.hpp"
#include "CX/Util/RndGen.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_4IFneIqIn &p)
{
	p.sbt_5 = 0.310791;
	p.sbt_APfw8 = 0.442153;
	p.sbt_Vba = true;
}

static inline void RandInit(sbt_4IFneIqIn &p)
{
	p.sbt_5 = CX::Util::RndGen::Get().GetDouble();
	p.sbt_APfw8 = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Vba = CX::Util::RndGen::Get().GetBool();
}

}//namespace SB

}//namespace CX

