
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_8bqhE.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"


class sbt_BnE
{
public:

	CX::UInt64 sbt_91U;
	sbt_8bqhE sbt_PfiDw;
	CX::SB::Map<sbt_FPkFvDvdxSroSAyqQ, sbt_8bqhE>::Type sbt_TVO19gt;
	CX::SB::Vector<CX::Int8>::Type sbt_q;
	CX::UInt32 sbt_qhLGVag;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_BnE &p)
{
	DefInit(p.sbt_91U);
	DefInit(p.sbt_PfiDw);
	DefInit(p.sbt_TVO19gt);
	DefInit(p.sbt_q);
	DefInit(p.sbt_qhLGVag);
}

template <> static inline int Compare<sbt_BnE>(const sbt_BnE &a, const sbt_BnE &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_91U, b.sbt_91U)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PfiDw, b.sbt_PfiDw)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_TVO19gt, b.sbt_TVO19gt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_q, b.sbt_q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qhLGVag, b.sbt_qhLGVag)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_BnE>(const sbt_BnE &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_91U, pHasher);
	Hash(p.sbt_PfiDw, pHasher);
	Hash(p.sbt_TVO19gt, pHasher);
	Hash(p.sbt_q, pHasher);
	Hash(p.sbt_qhLGVag, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_BnE>(sbt_BnE p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_91U", p.sbt_91U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PfiDw", p.sbt_PfiDw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_TVO19gt", p.sbt_TVO19gt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_q", p.sbt_q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qhLGVag", p.sbt_qhLGVag)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_BnE>(sbt_BnE &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_91U", p.sbt_91U)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PfiDw", p.sbt_PfiDw)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_TVO19gt", p.sbt_TVO19gt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_q", p.sbt_q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qhLGVag", p.sbt_qhLGVag)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

