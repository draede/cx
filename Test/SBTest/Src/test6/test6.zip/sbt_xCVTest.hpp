
#pragma once


#include "sbt_xCV.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_oX6waTest.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_xCV &p)
{
	p.sbt_0qpn_4g = 0.899327;
	p.sbt_Otn.push_back(3754278822);
	p.sbt_Otn.push_back(1929883228);
	p.sbt_Otn.push_back(82682225);
	p.sbt_Otn.push_back(2208640709);
	p.sbt_Otn.push_back(3441862575);
	p.sbt_Otn.push_back(1210413343);
	p.sbt_Otn.push_back(4006315886);
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	p.sbt_fdG5FBcH8 = 44;
	TestInit(p.sbt_t);
}

static inline void RandInit(sbt_xCV &p)
{
	p.sbt_0qpn_4g = CX::Util::RndGen::Get().GetDouble();
	p.sbt_Otn.push_back(CX::Util::RndGen::Get().GetUInt32());
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_X564v.push_back(k);
	}
	p.sbt_fdG5FBcH8 = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_t);
}

}//namespace SB

}//namespace CX

