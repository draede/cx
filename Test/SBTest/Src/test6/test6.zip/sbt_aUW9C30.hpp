
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_HBYCFckMOOiNb.hpp"
#include "sbt_3ECVYxB8g3FKbQhx7sy.hpp"
#include "sbt_xCV.hpp"
#include "sbt_k.hpp"


class sbt_aUW9C30
{
public:

	CX::Int16 sbt_8;
	CX::SB::Map<sbt_HBYCFckMOOiNb, sbt_3ECVYxB8g3FKbQhx7sy>::Type sbt_F;
	CX::SB::Vector<CX::Double>::Type sbt_J;
	CX::SB::Vector<sbt_xCV>::Type sbt_ZxiXDd9gS;
	CX::SB::Map<CX::WString, CX::Int64>::Type sbt_aBfsRUe;
	CX::SB::Map<CX::Int32, CX::UInt64>::Type sbt_eLnYOiUwR;
	CX::WString sbt_h9Abea3;
	CX::SB::Map<CX::Int32, CX::Float>::Type sbt_hQP;
	CX::SB::Vector<sbt_k>::Type sbt_oHTQuQQ;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_aUW9C30 &p)
{
	DefInit(p.sbt_8);
	DefInit(p.sbt_F);
	DefInit(p.sbt_J);
	DefInit(p.sbt_ZxiXDd9gS);
	DefInit(p.sbt_aBfsRUe);
	DefInit(p.sbt_eLnYOiUwR);
	DefInit(p.sbt_h9Abea3);
	DefInit(p.sbt_hQP);
	DefInit(p.sbt_oHTQuQQ);
}

template <> static inline int Compare<sbt_aUW9C30>(const sbt_aUW9C30 &a, const sbt_aUW9C30 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8, b.sbt_8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F, b.sbt_F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_J, b.sbt_J)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ZxiXDd9gS, b.sbt_ZxiXDd9gS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aBfsRUe, b.sbt_aBfsRUe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_eLnYOiUwR, b.sbt_eLnYOiUwR)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_h9Abea3, b.sbt_h9Abea3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_hQP, b.sbt_hQP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_oHTQuQQ, b.sbt_oHTQuQQ)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_aUW9C30>(const sbt_aUW9C30 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8, pHasher);
	Hash(p.sbt_F, pHasher);
	Hash(p.sbt_J, pHasher);
	Hash(p.sbt_ZxiXDd9gS, pHasher);
	Hash(p.sbt_aBfsRUe, pHasher);
	Hash(p.sbt_eLnYOiUwR, pHasher);
	Hash(p.sbt_h9Abea3, pHasher);
	Hash(p.sbt_hQP, pHasher);
	Hash(p.sbt_oHTQuQQ, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_aUW9C30>(sbt_aUW9C30 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_J", p.sbt_J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ZxiXDd9gS", p.sbt_ZxiXDd9gS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aBfsRUe", p.sbt_aBfsRUe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_eLnYOiUwR", p.sbt_eLnYOiUwR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_h9Abea3", p.sbt_h9Abea3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_hQP", p.sbt_hQP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_oHTQuQQ", p.sbt_oHTQuQQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_aUW9C30>(sbt_aUW9C30 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_J", p.sbt_J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ZxiXDd9gS", p.sbt_ZxiXDd9gS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aBfsRUe", p.sbt_aBfsRUe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_eLnYOiUwR", p.sbt_eLnYOiUwR)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_h9Abea3", p.sbt_h9Abea3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_hQP", p.sbt_hQP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_oHTQuQQ", p.sbt_oHTQuQQ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

