
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxF.hpp"
#include "sbt_8bqhE.hpp"


class sbt_BqQpOQzSt4u
{
public:

	CX::SB::Map<sbt_aGqmCqmCkLer6NUtTxF, sbt_8bqhE>::Type sbt_1E_;
	CX::Int8 sbt_X81AA;
	CX::UInt64 sbt_h;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_BqQpOQzSt4u &p)
{
	DefInit(p.sbt_1E_);
	DefInit(p.sbt_X81AA);
	DefInit(p.sbt_h);
}

template <> static inline int Compare<sbt_BqQpOQzSt4u>(const sbt_BqQpOQzSt4u &a, const sbt_BqQpOQzSt4u &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1E_, b.sbt_1E_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X81AA, b.sbt_X81AA)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_h, b.sbt_h)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_BqQpOQzSt4u>(const sbt_BqQpOQzSt4u &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1E_, pHasher);
	Hash(p.sbt_X81AA, pHasher);
	Hash(p.sbt_h, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_BqQpOQzSt4u>(sbt_BqQpOQzSt4u p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1E_", p.sbt_1E_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X81AA", p.sbt_X81AA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_BqQpOQzSt4u>(sbt_BqQpOQzSt4u &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1E_", p.sbt_1E_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X81AA", p.sbt_X81AA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_h", p.sbt_h)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

