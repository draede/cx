
#pragma once


#include "sbt_A.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_A &p)
{
	TestInit(p.sbt_U);
}

static inline void RandInit(sbt_A &p)
{
	RandInit(p.sbt_U);
}

}//namespace SB

}//namespace CX

