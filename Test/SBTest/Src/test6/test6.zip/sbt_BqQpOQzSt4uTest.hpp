
#pragma once


#include "sbt_BqQpOQzSt4u.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxFTest.hpp"
#include "sbt_8bqhETest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_BqQpOQzSt4u &p)
{
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	p.sbt_X81AA = -93;
	p.sbt_h = 2896911766962505248;
}

static inline void RandInit(sbt_BqQpOQzSt4u &p)
{
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		RandInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		RandInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	{
		sbt_aGqmCqmCkLer6NUtTxF k;
		sbt_8bqhE v;

		RandInit(k);
		TestInit(v);
		p.sbt_1E_[k] = v;
	}
	p.sbt_X81AA = CX::Util::RndGen::Get().GetInt8();
	p.sbt_h = CX::Util::RndGen::Get().GetUInt64();
}

}//namespace SB

}//namespace CX

