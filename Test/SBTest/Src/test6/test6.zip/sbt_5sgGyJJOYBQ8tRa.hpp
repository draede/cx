
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0Se0hGnpT5kld.hpp"


class sbt_5sgGyJJOYBQ8tRa
{
public:

	sbt_0Se0hGnpT5kld sbt_pUV;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_5sgGyJJOYBQ8tRa &p)
{
	DefInit(p.sbt_pUV);
}

template <> static inline int Compare<sbt_5sgGyJJOYBQ8tRa>(const sbt_5sgGyJJOYBQ8tRa &a, const sbt_5sgGyJJOYBQ8tRa &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_pUV, b.sbt_pUV)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_5sgGyJJOYBQ8tRa>(const sbt_5sgGyJJOYBQ8tRa &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_pUV, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_5sgGyJJOYBQ8tRa>(sbt_5sgGyJJOYBQ8tRa p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pUV", p.sbt_pUV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_5sgGyJJOYBQ8tRa>(sbt_5sgGyJJOYBQ8tRa &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (1 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 1 members");
	}
	if ((status = pDataReader->ReadMember("sbt_pUV", p.sbt_pUV)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

