
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_O143bvo.hpp"
#include "sbt_8bqhE.hpp"


class sbt_FwDSmFyQ8yGqWNv19
{
public:

	CX::SB::Vector<CX::UInt16>::Type sbt_8Gs6Yo1;
	CX::UInt32 sbt_EvURu7Kfk;
	CX::Double sbt_ExpDmJI;
	CX::Int64 sbt_JShLBd7FA;
	sbt_O143bvo sbt_bL0VGkkDt;
	CX::WString sbt_bV5jl;
	CX::SB::Vector<sbt_8bqhE>::Type sbt_q3n;
	CX::SB::Map<CX::UInt32, CX::UInt16>::Type sbt_qF0;
	sbt_O143bvo sbt_uDC9aU6xn;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_FwDSmFyQ8yGqWNv19 &p)
{
	DefInit(p.sbt_8Gs6Yo1);
	DefInit(p.sbt_EvURu7Kfk);
	DefInit(p.sbt_ExpDmJI);
	DefInit(p.sbt_JShLBd7FA);
	DefInit(p.sbt_bL0VGkkDt);
	DefInit(p.sbt_bV5jl);
	DefInit(p.sbt_q3n);
	DefInit(p.sbt_qF0);
	DefInit(p.sbt_uDC9aU6xn);
}

template <> static inline int Compare<sbt_FwDSmFyQ8yGqWNv19>(const sbt_FwDSmFyQ8yGqWNv19 &a, const sbt_FwDSmFyQ8yGqWNv19 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8Gs6Yo1, b.sbt_8Gs6Yo1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EvURu7Kfk, b.sbt_EvURu7Kfk)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ExpDmJI, b.sbt_ExpDmJI)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_JShLBd7FA, b.sbt_JShLBd7FA)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bL0VGkkDt, b.sbt_bL0VGkkDt)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bV5jl, b.sbt_bV5jl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_q3n, b.sbt_q3n)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qF0, b.sbt_qF0)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_uDC9aU6xn, b.sbt_uDC9aU6xn)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_FwDSmFyQ8yGqWNv19>(const sbt_FwDSmFyQ8yGqWNv19 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8Gs6Yo1, pHasher);
	Hash(p.sbt_EvURu7Kfk, pHasher);
	Hash(p.sbt_ExpDmJI, pHasher);
	Hash(p.sbt_JShLBd7FA, pHasher);
	Hash(p.sbt_bL0VGkkDt, pHasher);
	Hash(p.sbt_bV5jl, pHasher);
	Hash(p.sbt_q3n, pHasher);
	Hash(p.sbt_qF0, pHasher);
	Hash(p.sbt_uDC9aU6xn, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_FwDSmFyQ8yGqWNv19>(sbt_FwDSmFyQ8yGqWNv19 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8Gs6Yo1", p.sbt_8Gs6Yo1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EvURu7Kfk", p.sbt_EvURu7Kfk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ExpDmJI", p.sbt_ExpDmJI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_JShLBd7FA", p.sbt_JShLBd7FA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bL0VGkkDt", p.sbt_bL0VGkkDt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bV5jl", p.sbt_bV5jl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_q3n", p.sbt_q3n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qF0", p.sbt_qF0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_uDC9aU6xn", p.sbt_uDC9aU6xn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_FwDSmFyQ8yGqWNv19>(sbt_FwDSmFyQ8yGqWNv19 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8Gs6Yo1", p.sbt_8Gs6Yo1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EvURu7Kfk", p.sbt_EvURu7Kfk)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ExpDmJI", p.sbt_ExpDmJI)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_JShLBd7FA", p.sbt_JShLBd7FA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bL0VGkkDt", p.sbt_bL0VGkkDt)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bV5jl", p.sbt_bV5jl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_q3n", p.sbt_q3n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qF0", p.sbt_qF0)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_uDC9aU6xn", p.sbt_uDC9aU6xn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

