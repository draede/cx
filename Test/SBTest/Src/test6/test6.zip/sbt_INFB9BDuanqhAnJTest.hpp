
#pragma once


#include "sbt_INFB9BDuanqhAnJ.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_5sgGyJJOYBQ8tRaTest.hpp"
#include "sbt_0Se0hGnpT5kldTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_INFB9BDuanqhAnJ &p)
{
	p.sbt_4xf = 31209;
	p.sbt_B = L"7SMiIY_;7=;e{g[7!+?kqI=E";
	p.sbt_G.push_back(-17361);
	p.sbt_G.push_back(28232);
	p.sbt_G.push_back(4645);
	TestInit(p.sbt_JcaJPQg6o);
	TestInit(p.sbt_q8aft);
}

static inline void RandInit(sbt_INFB9BDuanqhAnJ &p)
{
	p.sbt_4xf = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_B = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_G.push_back(CX::Util::RndGen::Get().GetInt16());
	RandInit(p.sbt_JcaJPQg6o);
	RandInit(p.sbt_q8aft);
}

}//namespace SB

}//namespace CX

