
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_4IFneIqIn.hpp"
#include "sbt_3YcOGtzqwTtSwgm3E.hpp"
#include "sbt_HRAmxsN.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"


class sbt_HBYCFckMOOiNb
{
public:

	CX::Float sbt_2IwgK;
	CX::SB::Vector<CX::Float>::Type sbt_5fK;
	CX::SB::Map<sbt_4IFneIqIn, sbt_3YcOGtzqwTtSwgm3E>::Type sbt_F_zwz0Q;
	sbt_HRAmxsN sbt_KID;
	CX::UInt64 sbt_RqN4K;
	CX::UInt16 sbt_UCbE7R6n5;
	sbt_225XhmpEekJ7un9iL sbt_cvtykut;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_HBYCFckMOOiNb &p)
{
	DefInit(p.sbt_2IwgK);
	DefInit(p.sbt_5fK);
	DefInit(p.sbt_F_zwz0Q);
	DefInit(p.sbt_KID);
	DefInit(p.sbt_RqN4K);
	DefInit(p.sbt_UCbE7R6n5);
	DefInit(p.sbt_cvtykut);
}

template <> static inline int Compare<sbt_HBYCFckMOOiNb>(const sbt_HBYCFckMOOiNb &a, const sbt_HBYCFckMOOiNb &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_2IwgK, b.sbt_2IwgK)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5fK, b.sbt_5fK)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F_zwz0Q, b.sbt_F_zwz0Q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KID, b.sbt_KID)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_RqN4K, b.sbt_RqN4K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UCbE7R6n5, b.sbt_UCbE7R6n5)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_cvtykut, b.sbt_cvtykut)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_HBYCFckMOOiNb>(const sbt_HBYCFckMOOiNb &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_2IwgK, pHasher);
	Hash(p.sbt_5fK, pHasher);
	Hash(p.sbt_F_zwz0Q, pHasher);
	Hash(p.sbt_KID, pHasher);
	Hash(p.sbt_RqN4K, pHasher);
	Hash(p.sbt_UCbE7R6n5, pHasher);
	Hash(p.sbt_cvtykut, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_HBYCFckMOOiNb>(sbt_HBYCFckMOOiNb p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_2IwgK", p.sbt_2IwgK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5fK", p.sbt_5fK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F_zwz0Q", p.sbt_F_zwz0Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KID", p.sbt_KID)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_RqN4K", p.sbt_RqN4K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UCbE7R6n5", p.sbt_UCbE7R6n5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_cvtykut", p.sbt_cvtykut)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_HBYCFckMOOiNb>(sbt_HBYCFckMOOiNb &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_2IwgK", p.sbt_2IwgK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5fK", p.sbt_5fK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F_zwz0Q", p.sbt_F_zwz0Q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KID", p.sbt_KID)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_RqN4K", p.sbt_RqN4K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UCbE7R6n5", p.sbt_UCbE7R6n5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_cvtykut", p.sbt_cvtykut)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

