
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_O143bvo.hpp"
#include "sbt_3YcOGtzqwTtSwgm3E.hpp"


class sbt_OBb
{
public:

	CX::SB::Map<CX::WString, CX::Int64>::Type sbt_QZYNODo3E;
	sbt_O143bvo sbt_SDsQx3u;
	sbt_3YcOGtzqwTtSwgm3E sbt_q;
	CX::Double sbt_xMCIh;
	CX::Int16 sbt_y891W;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_OBb &p)
{
	DefInit(p.sbt_QZYNODo3E);
	DefInit(p.sbt_SDsQx3u);
	DefInit(p.sbt_q);
	DefInit(p.sbt_xMCIh);
	DefInit(p.sbt_y891W);
}

template <> static inline int Compare<sbt_OBb>(const sbt_OBb &a, const sbt_OBb &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_QZYNODo3E, b.sbt_QZYNODo3E)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SDsQx3u, b.sbt_SDsQx3u)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_q, b.sbt_q)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_xMCIh, b.sbt_xMCIh)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_y891W, b.sbt_y891W)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_OBb>(const sbt_OBb &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_QZYNODo3E, pHasher);
	Hash(p.sbt_SDsQx3u, pHasher);
	Hash(p.sbt_q, pHasher);
	Hash(p.sbt_xMCIh, pHasher);
	Hash(p.sbt_y891W, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_OBb>(sbt_OBb p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_QZYNODo3E", p.sbt_QZYNODo3E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SDsQx3u", p.sbt_SDsQx3u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_q", p.sbt_q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_xMCIh", p.sbt_xMCIh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_y891W", p.sbt_y891W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_OBb>(sbt_OBb &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_QZYNODo3E", p.sbt_QZYNODo3E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SDsQx3u", p.sbt_SDsQx3u)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_q", p.sbt_q)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_xMCIh", p.sbt_xMCIh)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_y891W", p.sbt_y891W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

