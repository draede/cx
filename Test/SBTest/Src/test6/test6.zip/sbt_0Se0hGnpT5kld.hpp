
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_O143bvo.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"


class sbt_0Se0hGnpT5kld
{
public:

	CX::SB::Vector<sbt_O143bvo>::Type sbt_8;
	CX::UInt64 sbt_WbLYl8K;
	CX::Int32 sbt_gJM;
	CX::UInt8 sbt_qCGaRul;
	sbt_225XhmpEekJ7un9iL sbt_x;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_0Se0hGnpT5kld &p)
{
	DefInit(p.sbt_8);
	DefInit(p.sbt_WbLYl8K);
	DefInit(p.sbt_gJM);
	DefInit(p.sbt_qCGaRul);
	DefInit(p.sbt_x);
}

template <> static inline int Compare<sbt_0Se0hGnpT5kld>(const sbt_0Se0hGnpT5kld &a, const sbt_0Se0hGnpT5kld &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8, b.sbt_8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_WbLYl8K, b.sbt_WbLYl8K)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_gJM, b.sbt_gJM)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qCGaRul, b.sbt_qCGaRul)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_x, b.sbt_x)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_0Se0hGnpT5kld>(const sbt_0Se0hGnpT5kld &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8, pHasher);
	Hash(p.sbt_WbLYl8K, pHasher);
	Hash(p.sbt_gJM, pHasher);
	Hash(p.sbt_qCGaRul, pHasher);
	Hash(p.sbt_x, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_0Se0hGnpT5kld>(sbt_0Se0hGnpT5kld p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_WbLYl8K", p.sbt_WbLYl8K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_gJM", p.sbt_gJM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qCGaRul", p.sbt_qCGaRul)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_x", p.sbt_x)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_0Se0hGnpT5kld>(sbt_0Se0hGnpT5kld &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8", p.sbt_8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_WbLYl8K", p.sbt_WbLYl8K)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_gJM", p.sbt_gJM)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qCGaRul", p.sbt_qCGaRul)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_x", p.sbt_x)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

