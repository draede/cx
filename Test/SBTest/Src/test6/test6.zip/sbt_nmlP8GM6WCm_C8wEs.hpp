
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_Nq7.hpp"
#include "sbt_8bqhE.hpp"
#include "sbt_FwDSmFyQ8yGqWNv19.hpp"


class sbt_nmlP8GM6WCm_C8wEs
{
public:

	CX::SB::Vector<CX::UInt32>::Type sbt_KgrFfh1jC;
	CX::SB::Map<sbt_Nq7, sbt_8bqhE>::Type sbt_UeLir;
	CX::Int8 sbt__WT;
	CX::Int16 sbt_r;
	sbt_FwDSmFyQ8yGqWNv19 sbt_rgi;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_nmlP8GM6WCm_C8wEs &p)
{
	DefInit(p.sbt_KgrFfh1jC);
	DefInit(p.sbt_UeLir);
	DefInit(p.sbt__WT);
	DefInit(p.sbt_r);
	DefInit(p.sbt_rgi);
}

template <> static inline int Compare<sbt_nmlP8GM6WCm_C8wEs>(const sbt_nmlP8GM6WCm_C8wEs &a, const sbt_nmlP8GM6WCm_C8wEs &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_KgrFfh1jC, b.sbt_KgrFfh1jC)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_UeLir, b.sbt_UeLir)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__WT, b.sbt__WT)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_r, b.sbt_r)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_rgi, b.sbt_rgi)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_nmlP8GM6WCm_C8wEs>(const sbt_nmlP8GM6WCm_C8wEs &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_KgrFfh1jC, pHasher);
	Hash(p.sbt_UeLir, pHasher);
	Hash(p.sbt__WT, pHasher);
	Hash(p.sbt_r, pHasher);
	Hash(p.sbt_rgi, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_nmlP8GM6WCm_C8wEs>(sbt_nmlP8GM6WCm_C8wEs p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KgrFfh1jC", p.sbt_KgrFfh1jC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_UeLir", p.sbt_UeLir)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__WT", p.sbt__WT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_rgi", p.sbt_rgi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_nmlP8GM6WCm_C8wEs>(sbt_nmlP8GM6WCm_C8wEs &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_KgrFfh1jC", p.sbt_KgrFfh1jC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_UeLir", p.sbt_UeLir)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__WT", p.sbt__WT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_r", p.sbt_r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_rgi", p.sbt_rgi)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

