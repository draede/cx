
#pragma once


#include "sbt_6.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6BxTest.hpp"
#include "sbt_kTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_6 &p)
{
	p.sbt_Q_WzUgeAk = 65288;
	p.sbt_d = true;
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
}

static inline void RandInit(sbt_6 &p)
{
	p.sbt_Q_WzUgeAk = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_d = CX::Util::RndGen::Get().GetBool();
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
	{
		sbt_4zanj_ga3ZYRmUoH6Bx k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_gKnZr[k] = v;
	}
}

}//namespace SB

}//namespace CX

