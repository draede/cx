
#pragma once


#include "sbt_oX6wa.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_oX6wa &p)
{
	p.sbt_1ZC = 13767784116014695332;
	TestInit(p.sbt_PihYUi4jH);
	p.sbt_S = 0.369745f;
}

static inline void RandInit(sbt_oX6wa &p)
{
	p.sbt_1ZC = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_PihYUi4jH);
	p.sbt_S = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

