
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_8bqhE.hpp"
#include "sbt_gvj_DWPqkRZ0XCFOndC.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_xCV.hpp"
#include "sbt_HRAmxsN.hpp"


class sbt_1fR8HdhjYoWVvpv__xT
{
public:

	CX::UInt32 sbt_F7Vs5w_;
	CX::Int16 sbt_KKtMe;
	sbt_8bqhE sbt_Nnz;
	CX::SB::Map<sbt_gvj_DWPqkRZ0XCFOndC, sbt_225XhmpEekJ7un9iL>::Type sbt_RL6;
	CX::Int16 sbt_f;
	CX::SB::Map<sbt_xCV, sbt_HRAmxsN>::Type sbt_qyhPpMKT_;
	CX::SB::Map<CX::Float, CX::Float>::Type sbt_tPUI9VY;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_1fR8HdhjYoWVvpv__xT &p)
{
	DefInit(p.sbt_F7Vs5w_);
	DefInit(p.sbt_KKtMe);
	DefInit(p.sbt_Nnz);
	DefInit(p.sbt_RL6);
	DefInit(p.sbt_f);
	DefInit(p.sbt_qyhPpMKT_);
	DefInit(p.sbt_tPUI9VY);
}

template <> static inline int Compare<sbt_1fR8HdhjYoWVvpv__xT>(const sbt_1fR8HdhjYoWVvpv__xT &a, const sbt_1fR8HdhjYoWVvpv__xT &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_F7Vs5w_, b.sbt_F7Vs5w_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_KKtMe, b.sbt_KKtMe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Nnz, b.sbt_Nnz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_RL6, b.sbt_RL6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_f, b.sbt_f)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qyhPpMKT_, b.sbt_qyhPpMKT_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tPUI9VY, b.sbt_tPUI9VY)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_1fR8HdhjYoWVvpv__xT>(const sbt_1fR8HdhjYoWVvpv__xT &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_F7Vs5w_, pHasher);
	Hash(p.sbt_KKtMe, pHasher);
	Hash(p.sbt_Nnz, pHasher);
	Hash(p.sbt_RL6, pHasher);
	Hash(p.sbt_f, pHasher);
	Hash(p.sbt_qyhPpMKT_, pHasher);
	Hash(p.sbt_tPUI9VY, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_1fR8HdhjYoWVvpv__xT>(sbt_1fR8HdhjYoWVvpv__xT p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F7Vs5w_", p.sbt_F7Vs5w_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_KKtMe", p.sbt_KKtMe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Nnz", p.sbt_Nnz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_RL6", p.sbt_RL6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_f", p.sbt_f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qyhPpMKT_", p.sbt_qyhPpMKT_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tPUI9VY", p.sbt_tPUI9VY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_1fR8HdhjYoWVvpv__xT>(sbt_1fR8HdhjYoWVvpv__xT &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_F7Vs5w_", p.sbt_F7Vs5w_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_KKtMe", p.sbt_KKtMe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Nnz", p.sbt_Nnz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_RL6", p.sbt_RL6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_f", p.sbt_f)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qyhPpMKT_", p.sbt_qyhPpMKT_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tPUI9VY", p.sbt_tPUI9VY)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

