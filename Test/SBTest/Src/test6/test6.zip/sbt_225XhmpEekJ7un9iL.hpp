
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_4IFneIqIn.hpp"


class sbt_225XhmpEekJ7un9iL
{
public:

	sbt_4IFneIqIn sbt_Qv9JtfQQS;
	CX::UInt64 sbt_VQD_J;
	CX::Int64 sbt__FLcHyA;
	CX::String sbt_bPx;
	sbt_4IFneIqIn sbt_e;
	CX::Bool sbt_k6j;
	CX::UInt8 sbt_knS7C98tZ;
	CX::UInt32 sbt_tne;
	sbt_4IFneIqIn sbt_uAK;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_225XhmpEekJ7un9iL &p)
{
	DefInit(p.sbt_Qv9JtfQQS);
	DefInit(p.sbt_VQD_J);
	DefInit(p.sbt__FLcHyA);
	DefInit(p.sbt_bPx);
	DefInit(p.sbt_e);
	DefInit(p.sbt_k6j);
	DefInit(p.sbt_knS7C98tZ);
	DefInit(p.sbt_tne);
	DefInit(p.sbt_uAK);
}

template <> static inline int Compare<sbt_225XhmpEekJ7un9iL>(const sbt_225XhmpEekJ7un9iL &a, const sbt_225XhmpEekJ7un9iL &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_Qv9JtfQQS, b.sbt_Qv9JtfQQS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VQD_J, b.sbt_VQD_J)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__FLcHyA, b.sbt__FLcHyA)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_bPx, b.sbt_bPx)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_e, b.sbt_e)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_k6j, b.sbt_k6j)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_knS7C98tZ, b.sbt_knS7C98tZ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tne, b.sbt_tne)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_uAK, b.sbt_uAK)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_225XhmpEekJ7un9iL>(const sbt_225XhmpEekJ7un9iL &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_Qv9JtfQQS, pHasher);
	Hash(p.sbt_VQD_J, pHasher);
	Hash(p.sbt__FLcHyA, pHasher);
	Hash(p.sbt_bPx, pHasher);
	Hash(p.sbt_e, pHasher);
	Hash(p.sbt_k6j, pHasher);
	Hash(p.sbt_knS7C98tZ, pHasher);
	Hash(p.sbt_tne, pHasher);
	Hash(p.sbt_uAK, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_225XhmpEekJ7un9iL>(sbt_225XhmpEekJ7un9iL p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Qv9JtfQQS", p.sbt_Qv9JtfQQS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VQD_J", p.sbt_VQD_J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__FLcHyA", p.sbt__FLcHyA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_bPx", p.sbt_bPx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_e", p.sbt_e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_k6j", p.sbt_k6j)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_knS7C98tZ", p.sbt_knS7C98tZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tne", p.sbt_tne)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_uAK", p.sbt_uAK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_225XhmpEekJ7un9iL>(sbt_225XhmpEekJ7un9iL &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_Qv9JtfQQS", p.sbt_Qv9JtfQQS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VQD_J", p.sbt_VQD_J)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__FLcHyA", p.sbt__FLcHyA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_bPx", p.sbt_bPx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_e", p.sbt_e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_k6j", p.sbt_k6j)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_knS7C98tZ", p.sbt_knS7C98tZ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tne", p.sbt_tne)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_uAK", p.sbt_uAK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

