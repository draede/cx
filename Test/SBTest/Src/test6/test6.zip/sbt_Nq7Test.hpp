
#pragma once


#include "sbt_Nq7.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ATest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_kTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Nq7 &p)
{
	p.sbt_4 = 111;
	p.sbt_5LmGS = 1676080846343825070;
	TestInit(p.sbt_BQ2oj);
	p.sbt_F2YSnCkaz = 1830;
	p.sbt_LPl = 15629883094604632166;
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		TestInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	TestInit(p.sbt_iuEuUvE6i);
}

static inline void RandInit(sbt_Nq7 &p)
{
	p.sbt_4 = CX::Util::RndGen::Get().GetInt8();
	p.sbt_5LmGS = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_BQ2oj);
	p.sbt_F2YSnCkaz = CX::Util::RndGen::Get().GetInt16();
	p.sbt_LPl = CX::Util::RndGen::Get().GetUInt64();
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	{
		sbt_225XhmpEekJ7un9iL k;
		sbt_k v;

		RandInit(k);
		TestInit(v);
		p.sbt_Nk_Lxcb[k] = v;
	}
	RandInit(p.sbt_iuEuUvE6i);
}

}//namespace SB

}//namespace CX

