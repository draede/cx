
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_p.hpp"
#include "sbt_sJS.hpp"
#include "sbt_aUW9C30.hpp"


class sbt_bWrsHU86L8REX
{
public:

	CX::SB::Vector<sbt_p>::Type sbt_1a3z5G1D3;
	CX::UInt16 sbt_27N;
	CX::Int16 sbt_CYPaN3vdj;
	CX::UInt16 sbt_CeFjW;
	CX::Float sbt_SIdFZ1sp2;
	sbt_sJS sbt_Ub7RG;
	CX::SB::Vector<sbt_aUW9C30>::Type sbt__eA2r;
	CX::UInt64 sbt_j;
	CX::String sbt_wo_sg;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_bWrsHU86L8REX &p)
{
	DefInit(p.sbt_1a3z5G1D3);
	DefInit(p.sbt_27N);
	DefInit(p.sbt_CYPaN3vdj);
	DefInit(p.sbt_CeFjW);
	DefInit(p.sbt_SIdFZ1sp2);
	DefInit(p.sbt_Ub7RG);
	DefInit(p.sbt__eA2r);
	DefInit(p.sbt_j);
	DefInit(p.sbt_wo_sg);
}

template <> static inline int Compare<sbt_bWrsHU86L8REX>(const sbt_bWrsHU86L8REX &a, const sbt_bWrsHU86L8REX &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1a3z5G1D3, b.sbt_1a3z5G1D3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_27N, b.sbt_27N)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_CYPaN3vdj, b.sbt_CYPaN3vdj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_CeFjW, b.sbt_CeFjW)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SIdFZ1sp2, b.sbt_SIdFZ1sp2)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Ub7RG, b.sbt_Ub7RG)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__eA2r, b.sbt__eA2r)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_j, b.sbt_j)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_wo_sg, b.sbt_wo_sg)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_bWrsHU86L8REX>(const sbt_bWrsHU86L8REX &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1a3z5G1D3, pHasher);
	Hash(p.sbt_27N, pHasher);
	Hash(p.sbt_CYPaN3vdj, pHasher);
	Hash(p.sbt_CeFjW, pHasher);
	Hash(p.sbt_SIdFZ1sp2, pHasher);
	Hash(p.sbt_Ub7RG, pHasher);
	Hash(p.sbt__eA2r, pHasher);
	Hash(p.sbt_j, pHasher);
	Hash(p.sbt_wo_sg, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_bWrsHU86L8REX>(sbt_bWrsHU86L8REX p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1a3z5G1D3", p.sbt_1a3z5G1D3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_27N", p.sbt_27N)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_CYPaN3vdj", p.sbt_CYPaN3vdj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_CeFjW", p.sbt_CeFjW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SIdFZ1sp2", p.sbt_SIdFZ1sp2)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Ub7RG", p.sbt_Ub7RG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__eA2r", p.sbt__eA2r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_j", p.sbt_j)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_wo_sg", p.sbt_wo_sg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_bWrsHU86L8REX>(sbt_bWrsHU86L8REX &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1a3z5G1D3", p.sbt_1a3z5G1D3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_27N", p.sbt_27N)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_CYPaN3vdj", p.sbt_CYPaN3vdj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_CeFjW", p.sbt_CeFjW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SIdFZ1sp2", p.sbt_SIdFZ1sp2)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Ub7RG", p.sbt_Ub7RG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__eA2r", p.sbt__eA2r)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_j", p.sbt_j)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_wo_sg", p.sbt_wo_sg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

