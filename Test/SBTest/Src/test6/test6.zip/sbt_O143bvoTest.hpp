
#pragma once


#include "sbt_O143bvo.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_O143bvo &p)
{
	p.sbt_DGMQt[L"W}9+cMEy9eQ#37yQA?c"] = -11;
	TestInit(p.sbt_KFZI5);
	p.sbt_Xkj = 240;
	p.sbt__rsAycCA9 = L"k[sYwm9sc3/";
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_ghYNwFNIV.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_ghYNwFNIV.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_ghYNwFNIV.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_ghYNwFNIV.push_back(k);
	}
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_ghYNwFNIV.push_back(k);
	}
}

static inline void RandInit(sbt_O143bvo &p)
{
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	p.sbt_DGMQt[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_KFZI5);
	p.sbt_Xkj = CX::Util::RndGen::Get().GetUInt8();
	p.sbt__rsAycCA9 = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_225XhmpEekJ7un9iL k;

		TestInit(k);
		p.sbt_ghYNwFNIV.push_back(k);
	}
}

}//namespace SB

}//namespace CX

