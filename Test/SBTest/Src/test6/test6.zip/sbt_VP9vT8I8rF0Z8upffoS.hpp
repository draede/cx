
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_xCV.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6Bx.hpp"
#include "sbt_0Se0hGnpT5kld.hpp"


class sbt_VP9vT8I8rF0Z8upffoS
{
public:

	CX::Double sbt_4s4kak8;
	CX::Int8 sbt_98t;
	sbt_xCV sbt_PSc7fXWJe;
	sbt_4zanj_ga3ZYRmUoH6Bx sbt_W4lY7;
	CX::UInt64 sbt__sjF8yJ;
	sbt_0Se0hGnpT5kld sbt_mHC;
	CX::SB::Map<CX::String, CX::Int32>::Type sbt_zbNlLq1L3;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_VP9vT8I8rF0Z8upffoS &p)
{
	DefInit(p.sbt_4s4kak8);
	DefInit(p.sbt_98t);
	DefInit(p.sbt_PSc7fXWJe);
	DefInit(p.sbt_W4lY7);
	DefInit(p.sbt__sjF8yJ);
	DefInit(p.sbt_mHC);
	DefInit(p.sbt_zbNlLq1L3);
}

template <> static inline int Compare<sbt_VP9vT8I8rF0Z8upffoS>(const sbt_VP9vT8I8rF0Z8upffoS &a, const sbt_VP9vT8I8rF0Z8upffoS &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4s4kak8, b.sbt_4s4kak8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_98t, b.sbt_98t)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_PSc7fXWJe, b.sbt_PSc7fXWJe)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_W4lY7, b.sbt_W4lY7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt__sjF8yJ, b.sbt__sjF8yJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_mHC, b.sbt_mHC)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zbNlLq1L3, b.sbt_zbNlLq1L3)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_VP9vT8I8rF0Z8upffoS>(const sbt_VP9vT8I8rF0Z8upffoS &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4s4kak8, pHasher);
	Hash(p.sbt_98t, pHasher);
	Hash(p.sbt_PSc7fXWJe, pHasher);
	Hash(p.sbt_W4lY7, pHasher);
	Hash(p.sbt__sjF8yJ, pHasher);
	Hash(p.sbt_mHC, pHasher);
	Hash(p.sbt_zbNlLq1L3, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_VP9vT8I8rF0Z8upffoS>(sbt_VP9vT8I8rF0Z8upffoS p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4s4kak8", p.sbt_4s4kak8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_98t", p.sbt_98t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_PSc7fXWJe", p.sbt_PSc7fXWJe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_W4lY7", p.sbt_W4lY7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt__sjF8yJ", p.sbt__sjF8yJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_mHC", p.sbt_mHC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zbNlLq1L3", p.sbt_zbNlLq1L3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_VP9vT8I8rF0Z8upffoS>(sbt_VP9vT8I8rF0Z8upffoS &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4s4kak8", p.sbt_4s4kak8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_98t", p.sbt_98t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_PSc7fXWJe", p.sbt_PSc7fXWJe)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_W4lY7", p.sbt_W4lY7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt__sjF8yJ", p.sbt__sjF8yJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_mHC", p.sbt_mHC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zbNlLq1L3", p.sbt_zbNlLq1L3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

