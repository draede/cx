
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"


class sbt_3YcOGtzqwTtSwgm3E
{
public:

	CX::SB::Map<CX::Bool, CX::Int8>::Type sbt_IPOvb2pj9;
	CX::SB::Map<sbt_225XhmpEekJ7un9iL, sbt_225XhmpEekJ7un9iL>::Type sbt_NIW8rz4;
	CX::WString sbt_VeX0aWrjE;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_3YcOGtzqwTtSwgm3E &p)
{
	DefInit(p.sbt_IPOvb2pj9);
	DefInit(p.sbt_NIW8rz4);
	DefInit(p.sbt_VeX0aWrjE);
}

template <> static inline int Compare<sbt_3YcOGtzqwTtSwgm3E>(const sbt_3YcOGtzqwTtSwgm3E &a, const sbt_3YcOGtzqwTtSwgm3E &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_IPOvb2pj9, b.sbt_IPOvb2pj9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_NIW8rz4, b.sbt_NIW8rz4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_VeX0aWrjE, b.sbt_VeX0aWrjE)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_3YcOGtzqwTtSwgm3E>(const sbt_3YcOGtzqwTtSwgm3E &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_IPOvb2pj9, pHasher);
	Hash(p.sbt_NIW8rz4, pHasher);
	Hash(p.sbt_VeX0aWrjE, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_3YcOGtzqwTtSwgm3E>(sbt_3YcOGtzqwTtSwgm3E p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_IPOvb2pj9", p.sbt_IPOvb2pj9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_NIW8rz4", p.sbt_NIW8rz4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_VeX0aWrjE", p.sbt_VeX0aWrjE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_3YcOGtzqwTtSwgm3E>(sbt_3YcOGtzqwTtSwgm3E &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (3 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 3 members");
	}
	if ((status = pDataReader->ReadMember("sbt_IPOvb2pj9", p.sbt_IPOvb2pj9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_NIW8rz4", p.sbt_NIW8rz4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_VeX0aWrjE", p.sbt_VeX0aWrjE)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

