
#pragma once


#include "sbt_bWrsHU86L8REX.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_pTest.hpp"
#include "sbt_sJSTest.hpp"
#include "sbt_aUW9C30Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_bWrsHU86L8REX &p)
{
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	p.sbt_27N = 55116;
	p.sbt_CYPaN3vdj = -11347;
	p.sbt_CeFjW = 15481;
	p.sbt_SIdFZ1sp2 = 0.328884f;
	TestInit(p.sbt_Ub7RG);
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	p.sbt_j = 15670127685723477114;
	p.sbt_wo_sg = "c{;5-7YokuK!+YW+S_#[AI#Sg";
}

static inline void RandInit(sbt_bWrsHU86L8REX &p)
{
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	{
		sbt_p k;

		TestInit(k);
		p.sbt_1a3z5G1D3.push_back(k);
	}
	p.sbt_27N = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_CYPaN3vdj = CX::Util::RndGen::Get().GetInt16();
	p.sbt_CeFjW = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_SIdFZ1sp2 = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_Ub7RG);
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	{
		sbt_aUW9C30 k;

		TestInit(k);
		p.sbt__eA2r.push_back(k);
	}
	p.sbt_j = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_wo_sg = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
}

}//namespace SB

}//namespace CX

