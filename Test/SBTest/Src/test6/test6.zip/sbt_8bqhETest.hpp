
#pragma once


#include "sbt_8bqhE.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_kTest.hpp"
#include "sbt_Nq7Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_8bqhE &p)
{
	TestInit(p.sbt_BGc);
	p.sbt_QHTEQXX = 3409355461;
	p.sbt_fJyZlSgTZ = -3394198264012746332;
	p.sbt_is3 = 0.191725f;
	TestInit(p.sbt_j8C);
}

static inline void RandInit(sbt_8bqhE &p)
{
	RandInit(p.sbt_BGc);
	p.sbt_QHTEQXX = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_fJyZlSgTZ = CX::Util::RndGen::Get().GetInt64();
	p.sbt_is3 = CX::Util::RndGen::Get().GetFloat();
	RandInit(p.sbt_j8C);
}

}//namespace SB

}//namespace CX

