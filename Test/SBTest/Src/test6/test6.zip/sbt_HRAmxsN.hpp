
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_3YcOGtzqwTtSwgm3E.hpp"
#include "sbt_oX6wa.hpp"


class sbt_HRAmxsN
{
public:

	CX::SB::Vector<CX::WString>::Type sbt_2koZFA1;
	CX::SB::Vector<sbt_225XhmpEekJ7un9iL>::Type sbt_Z0AZFbc03;
	sbt_3YcOGtzqwTtSwgm3E sbt_aA9MU7CKH;
	CX::Int32 sbt_fMw30;
	CX::UInt64 sbt_m1hYlkab6;
	CX::UInt16 sbt_nfnxZyfYH;
	CX::Double sbt_pPX;
	sbt_oX6wa sbt_tcS;
	CX::String sbt_ydsIv7i;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_HRAmxsN &p)
{
	DefInit(p.sbt_2koZFA1);
	DefInit(p.sbt_Z0AZFbc03);
	DefInit(p.sbt_aA9MU7CKH);
	DefInit(p.sbt_fMw30);
	DefInit(p.sbt_m1hYlkab6);
	DefInit(p.sbt_nfnxZyfYH);
	DefInit(p.sbt_pPX);
	DefInit(p.sbt_tcS);
	DefInit(p.sbt_ydsIv7i);
}

template <> static inline int Compare<sbt_HRAmxsN>(const sbt_HRAmxsN &a, const sbt_HRAmxsN &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_2koZFA1, b.sbt_2koZFA1)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Z0AZFbc03, b.sbt_Z0AZFbc03)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_aA9MU7CKH, b.sbt_aA9MU7CKH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fMw30, b.sbt_fMw30)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_m1hYlkab6, b.sbt_m1hYlkab6)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nfnxZyfYH, b.sbt_nfnxZyfYH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pPX, b.sbt_pPX)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_tcS, b.sbt_tcS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ydsIv7i, b.sbt_ydsIv7i)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_HRAmxsN>(const sbt_HRAmxsN &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_2koZFA1, pHasher);
	Hash(p.sbt_Z0AZFbc03, pHasher);
	Hash(p.sbt_aA9MU7CKH, pHasher);
	Hash(p.sbt_fMw30, pHasher);
	Hash(p.sbt_m1hYlkab6, pHasher);
	Hash(p.sbt_nfnxZyfYH, pHasher);
	Hash(p.sbt_pPX, pHasher);
	Hash(p.sbt_tcS, pHasher);
	Hash(p.sbt_ydsIv7i, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_HRAmxsN>(sbt_HRAmxsN p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_2koZFA1", p.sbt_2koZFA1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Z0AZFbc03", p.sbt_Z0AZFbc03)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_aA9MU7CKH", p.sbt_aA9MU7CKH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fMw30", p.sbt_fMw30)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_m1hYlkab6", p.sbt_m1hYlkab6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nfnxZyfYH", p.sbt_nfnxZyfYH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pPX", p.sbt_pPX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_tcS", p.sbt_tcS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ydsIv7i", p.sbt_ydsIv7i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_HRAmxsN>(sbt_HRAmxsN &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_2koZFA1", p.sbt_2koZFA1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Z0AZFbc03", p.sbt_Z0AZFbc03)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_aA9MU7CKH", p.sbt_aA9MU7CKH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fMw30", p.sbt_fMw30)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_m1hYlkab6", p.sbt_m1hYlkab6)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nfnxZyfYH", p.sbt_nfnxZyfYH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pPX", p.sbt_pPX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_tcS", p.sbt_tcS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ydsIv7i", p.sbt_ydsIv7i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

