
#pragma once


#include "sbt_k.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_oX6waTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_k &p)
{
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
}

static inline void RandInit(sbt_k &p)
{
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
	{
		sbt_oX6wa k;

		TestInit(k);
		p.sbt_4.push_back(k);
	}
}

}//namespace SB

}//namespace CX

