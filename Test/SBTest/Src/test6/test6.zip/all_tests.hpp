
#pragma once


#include "CX/SB/Tester.hpp"
#include "CX/Print.hpp"
#include "sbt_0Se0hGnpT5kldTest.hpp"
#include "sbt_1fR8HdhjYoWVvpv__xTTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_2xfl8PxYqAX3eTest.hpp"
#include "sbt_3ECVYxB8g3FKbQhx7syTest.hpp"
#include "sbt_3YcOGtzqwTtSwgm3ETest.hpp"
#include "sbt_4IFneIqInTest.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6BxTest.hpp"
#include "sbt_5sgGyJJOYBQ8tRaTest.hpp"
#include "sbt_6Test.hpp"
#include "sbt_8bqhETest.hpp"
#include "sbt_ATest.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxFTest.hpp"
#include "sbt_aUW9C30Test.hpp"
#include "sbt_BnETest.hpp"
#include "sbt_BqQpOQzSt4uTest.hpp"
#include "sbt_bWrsHU86L8REXTest.hpp"
#include "sbt_C7P8zUDllnpTest.hpp"
#include "sbt_ClDKuCoEL3ciMTest.hpp"
#include "sbt_ETest.hpp"
#include "sbt_ekP_c1STest.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"
#include "sbt_FwDSmFyQ8yGqWNv19Test.hpp"
#include "sbt_g7mB9sN8RPXTest.hpp"
#include "sbt_gCnAZ4Srk0wKwMRpkTest.hpp"
#include "sbt_gNiZ3WOkV1jeetbhLzJTest.hpp"
#include "sbt_gvj_DWPqkRZ0XCFOndCTest.hpp"
#include "sbt_HBYCFckMOOiNbTest.hpp"
#include "sbt_HRAmxsNTest.hpp"
#include "sbt_iBQiryWTest.hpp"
#include "sbt_INFB9BDuanqhAnJTest.hpp"
#include "sbt_iS77qTest.hpp"
#include "sbt_kTest.hpp"
#include "sbt_Lu55mymTest.hpp"
#include "sbt_Lv6Cc5HdYTest.hpp"
#include "sbt_nmlP8GM6WCm_C8wEsTest.hpp"
#include "sbt_Nq7Test.hpp"
#include "sbt_O143bvoTest.hpp"
#include "sbt_OBbTest.hpp"
#include "sbt_oX6waTest.hpp"
#include "sbt_pTest.hpp"
#include "sbt_p0PAXTest.hpp"
#include "sbt_qCP3a4QA8VGTest.hpp"
#include "sbt_sJSTest.hpp"
#include "sbt_uE_IyAxSbkvGbDlAeTest.hpp"
#include "sbt_VP9vT8I8rF0Z8upffoSTest.hpp"
#include "sbt_xCVTest.hpp"
#include "sbt_y4nqlCNALJ9Test.hpp"
#include "sbt_ZLIQ7iEI8Test.hpp"
#include "sbt_ZTIUWTest.hpp"


void Run_Tests()
{
	CX::SB::StatsData trd;
	CX::SB::StatsData twd;
	CX::Size cAll = 0;
	CX::Size cOK = 0;
	CX::Status status;

	trd.Reset();
	twd.Reset();
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_0Se0hGnpT5kld>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_0Se0hGnpT5kld failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_1fR8HdhjYoWVvpv__xT>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_1fR8HdhjYoWVvpv__xT failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_225XhmpEekJ7un9iL>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_225XhmpEekJ7un9iL failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_2xfl8PxYqAX3e>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_2xfl8PxYqAX3e failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_3ECVYxB8g3FKbQhx7sy>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_3ECVYxB8g3FKbQhx7sy failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_3YcOGtzqwTtSwgm3E>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_3YcOGtzqwTtSwgm3E failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_4IFneIqIn>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_4IFneIqIn failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_4zanj_ga3ZYRmUoH6Bx>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_4zanj_ga3ZYRmUoH6Bx failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_5sgGyJJOYBQ8tRa>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_5sgGyJJOYBQ8tRa failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_6>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_6 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_8bqhE>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_8bqhE failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_A>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_A failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_aGqmCqmCkLer6NUtTxF>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_aGqmCqmCkLer6NUtTxF failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_aUW9C30>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_aUW9C30 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_BnE>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_BnE failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_BqQpOQzSt4u>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_BqQpOQzSt4u failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_bWrsHU86L8REX>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_bWrsHU86L8REX failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_C7P8zUDllnp>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_C7P8zUDllnp failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_ClDKuCoEL3ciM>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_ClDKuCoEL3ciM failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_E>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_E failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_ekP_c1S>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_ekP_c1S failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_FPkFvDvdxSroSAyqQ>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_FPkFvDvdxSroSAyqQ failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_FwDSmFyQ8yGqWNv19>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_FwDSmFyQ8yGqWNv19 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_g7mB9sN8RPX>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_g7mB9sN8RPX failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_gCnAZ4Srk0wKwMRpk>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_gCnAZ4Srk0wKwMRpk failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_gNiZ3WOkV1jeetbhLzJ>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_gNiZ3WOkV1jeetbhLzJ failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_gvj_DWPqkRZ0XCFOndC>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_gvj_DWPqkRZ0XCFOndC failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_HBYCFckMOOiNb>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_HBYCFckMOOiNb failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_HRAmxsN>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_HRAmxsN failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_iBQiryW>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_iBQiryW failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_INFB9BDuanqhAnJ>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_INFB9BDuanqhAnJ failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_iS77q>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_iS77q failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_k>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_k failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Lu55mym>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Lu55mym failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Lv6Cc5HdY>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Lv6Cc5HdY failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_nmlP8GM6WCm_C8wEs>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_nmlP8GM6WCm_C8wEs failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_Nq7>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_Nq7 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_O143bvo>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_O143bvo failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_OBb>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_OBb failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_oX6wa>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_oX6wa failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_p>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_p failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_p0PAX>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_p0PAX failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_qCP3a4QA8VG>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_qCP3a4QA8VG failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_sJS>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_sJS failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_uE_IyAxSbkvGbDlAe>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_uE_IyAxSbkvGbDlAe failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_VP9vT8I8rF0Z8upffoS>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_VP9vT8I8rF0Z8upffoS failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_xCV>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_xCV failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_y4nqlCNALJ9>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_y4nqlCNALJ9 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_ZLIQ7iEI8>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_ZLIQ7iEI8 failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	{
		CX::SB::StatsData rd;
		CX::SB::StatsData wd;

		if ((status = CX::SB::TestSerialize<sbt_ZTIUW>(rd, wd)).IsNOK())
		{
			cAll++;
		CX::Print(stdout, "sbt_ZTIUW failed with error code {1} and error msg '{2}'", status.GetCode(), status.GetMsg());
		}
		else
		{
			cAll++;
			cOK++;
		}
		trd.Add(rd);
		twd.Add(wd);
	}
	CX::Print(stdout, "All tests : {1}\n", cAll);
	CX::Print(stdout, "OK tests  : {1}\n", cOK);
	CX::Print(stdout, "===== READ STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", trd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", trd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", trd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", trd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", trd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", trd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", trd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", trd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", trd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", trd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", trd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", trd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", trd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", trd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", trd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", trd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", trd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", trd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", trd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {:.3} MB\n", trd.m_cbTotalSize / 1048576.0);
	CX::Print(stdout, "===== WRITE STATS =========================================\n");
	CX::Print(stdout, "   Members: {1}\n", twd.m_cMembers);
	CX::Print(stdout, "   Items: {1}\n", twd.m_cItems);
	CX::Print(stdout, "   Objects: {1}\n", twd.m_cObjects);
	CX::Print(stdout, "   Arrays: {1}\n", twd.m_cArrays);
	CX::Print(stdout, "   Bools: {1}\n", twd.m_cBools);
	CX::Print(stdout, "   Int8s: {1}\n", twd.m_cInt8s);
	CX::Print(stdout, "   UInt8s: {1}\n", twd.m_cUInt8s);
	CX::Print(stdout, "   Int16s: {1}\n", twd.m_cInt16s);
	CX::Print(stdout, "   UInt16s: {1}\n", twd.m_cUInt16s);
	CX::Print(stdout, "   Int32s: {1}\n", twd.m_cInt32s);
	CX::Print(stdout, "   UInt32s: {1}\n", twd.m_cUInt32s);
	CX::Print(stdout, "   Int64s: {1}\n", twd.m_cInt64s);
	CX::Print(stdout, "   UInt64s: {1}\n", twd.m_cUInt64s);
	CX::Print(stdout, "   Floats: {1}\n", twd.m_cFloats);
	CX::Print(stdout, "   Doubles: {1}\n", twd.m_cDoubles);
	CX::Print(stdout, "   Strings: {1}\n", twd.m_cStrings);
	CX::Print(stdout, "   WStrings: {1}\n", twd.m_cWStrings);
	CX::Print(stdout, "   AllValues: {1}\n", twd.m_cAllValues);
	CX::Print(stdout, "   DataSize: {1:.3} MB\n", twd.m_cbDataSize / 1048576.0);
	CX::Print(stdout, "   TotalSize: {1:.3} MB\n", twd.m_cbTotalSize / 1048576.0);
}
