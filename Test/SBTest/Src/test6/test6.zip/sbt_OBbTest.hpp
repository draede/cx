
#pragma once


#include "sbt_OBb.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_O143bvoTest.hpp"
#include "sbt_3YcOGtzqwTtSwgm3ETest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_OBb &p)
{
	p.sbt_QZYNODo3E[L"AIWoqm#mW3"] = -3845522793514886214;
	p.sbt_QZYNODo3E[L""] = -4481070868338476938;
	p.sbt_QZYNODo3E[L"!koSGIOmq)Ia_9OE3ac[-W"] = -7983083704127187980;
	p.sbt_QZYNODo3E[L"U{"] = -4756439727440240176;
	p.sbt_QZYNODo3E[L"O)1='EcGeU-{CgE_1Q3)s"] = -5818864074467414660;
	p.sbt_QZYNODo3E[L"am}[EgkMcw!oM{K1{[Wy7GUw"] = 114188911435834198;
	p.sbt_QZYNODo3E[L"K/_kkQK#s#MOmI7_}-[K#=)"] = -3353403759408395828;
	p.sbt_QZYNODo3E[L"msM/EGcIo3aC?SgwI-UWE'1'c9"] = -4503757627175883106;
	p.sbt_QZYNODo3E[L"euY;';aCM?M3#aMKyS}7''K3u+G9"] = 1191949877421959532;
	TestInit(p.sbt_SDsQx3u);
	TestInit(p.sbt_q);
	p.sbt_xMCIh = 0.824760;
	p.sbt_y891W = -7814;
}

static inline void RandInit(sbt_OBb &p)
{
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	p.sbt_QZYNODo3E[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_SDsQx3u);
	RandInit(p.sbt_q);
	p.sbt_xMCIh = CX::Util::RndGen::Get().GetDouble();
	p.sbt_y891W = CX::Util::RndGen::Get().GetInt16();
}

}//namespace SB

}//namespace CX

