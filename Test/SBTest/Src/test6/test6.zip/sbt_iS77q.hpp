
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_0Se0hGnpT5kld.hpp"
#include "sbt_iBQiryW.hpp"
#include "sbt_gNiZ3WOkV1jeetbhLzJ.hpp"


class sbt_iS77q
{
public:

	sbt_0Se0hGnpT5kld sbt_5co58Eo;
	CX::WString sbt_X96kc;
	CX::SB::Map<CX::Int8, CX::Int16>::Type sbt_d;
	CX::UInt16 sbt_euQuEdOtv;
	CX::UInt8 sbt_hv_;
	CX::SB::Vector<sbt_iBQiryW>::Type sbt_nzX;
	CX::Int8 sbt_qQ5aJ;
	CX::WString sbt_ryWnB3X;
	sbt_gNiZ3WOkV1jeetbhLzJ sbt_w;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_iS77q &p)
{
	DefInit(p.sbt_5co58Eo);
	DefInit(p.sbt_X96kc);
	DefInit(p.sbt_d);
	DefInit(p.sbt_euQuEdOtv);
	DefInit(p.sbt_hv_);
	DefInit(p.sbt_nzX);
	DefInit(p.sbt_qQ5aJ);
	DefInit(p.sbt_ryWnB3X);
	DefInit(p.sbt_w);
}

template <> static inline int Compare<sbt_iS77q>(const sbt_iS77q &a, const sbt_iS77q &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_5co58Eo, b.sbt_5co58Eo)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X96kc, b.sbt_X96kc)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_d, b.sbt_d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_euQuEdOtv, b.sbt_euQuEdOtv)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_hv_, b.sbt_hv_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nzX, b.sbt_nzX)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qQ5aJ, b.sbt_qQ5aJ)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_ryWnB3X, b.sbt_ryWnB3X)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_w, b.sbt_w)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_iS77q>(const sbt_iS77q &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_5co58Eo, pHasher);
	Hash(p.sbt_X96kc, pHasher);
	Hash(p.sbt_d, pHasher);
	Hash(p.sbt_euQuEdOtv, pHasher);
	Hash(p.sbt_hv_, pHasher);
	Hash(p.sbt_nzX, pHasher);
	Hash(p.sbt_qQ5aJ, pHasher);
	Hash(p.sbt_ryWnB3X, pHasher);
	Hash(p.sbt_w, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_iS77q>(sbt_iS77q p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5co58Eo", p.sbt_5co58Eo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X96kc", p.sbt_X96kc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_euQuEdOtv", p.sbt_euQuEdOtv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_hv_", p.sbt_hv_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nzX", p.sbt_nzX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qQ5aJ", p.sbt_qQ5aJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_ryWnB3X", p.sbt_ryWnB3X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_w", p.sbt_w)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_iS77q>(sbt_iS77q &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_5co58Eo", p.sbt_5co58Eo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X96kc", p.sbt_X96kc)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_euQuEdOtv", p.sbt_euQuEdOtv)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_hv_", p.sbt_hv_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nzX", p.sbt_nzX)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qQ5aJ", p.sbt_qQ5aJ)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_ryWnB3X", p.sbt_ryWnB3X)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_w", p.sbt_w)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

