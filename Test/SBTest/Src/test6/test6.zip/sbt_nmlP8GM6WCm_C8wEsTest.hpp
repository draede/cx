
#pragma once


#include "sbt_nmlP8GM6WCm_C8wEs.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_Nq7Test.hpp"
#include "sbt_8bqhETest.hpp"
#include "sbt_FwDSmFyQ8yGqWNv19Test.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_nmlP8GM6WCm_C8wEs &p)
{
	p.sbt_KgrFfh1jC.push_back(1972175133);
	p.sbt_KgrFfh1jC.push_back(2353536129);
	p.sbt_KgrFfh1jC.push_back(440631796);
	p.sbt_KgrFfh1jC.push_back(2514551832);
	p.sbt_KgrFfh1jC.push_back(2695354605);
	{
		sbt_Nq7 k;
		sbt_8bqhE v;

		TestInit(k);
		TestInit(v);
		p.sbt_UeLir[k] = v;
	}
	p.sbt__WT = -67;
	p.sbt_r = 8831;
	TestInit(p.sbt_rgi);
}

static inline void RandInit(sbt_nmlP8GM6WCm_C8wEs &p)
{
	p.sbt_KgrFfh1jC.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_KgrFfh1jC.push_back(CX::Util::RndGen::Get().GetUInt32());
	p.sbt_KgrFfh1jC.push_back(CX::Util::RndGen::Get().GetUInt32());
	{
		sbt_Nq7 k;
		sbt_8bqhE v;

		RandInit(k);
		TestInit(v);
		p.sbt_UeLir[k] = v;
	}
	p.sbt__WT = CX::Util::RndGen::Get().GetInt8();
	p.sbt_r = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_rgi);
}

}//namespace SB

}//namespace CX

