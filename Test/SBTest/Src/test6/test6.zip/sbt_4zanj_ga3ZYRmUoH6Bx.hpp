
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"
#include "sbt_aGqmCqmCkLer6NUtTxF.hpp"
#include "sbt_O143bvo.hpp"


class sbt_4zanj_ga3ZYRmUoH6Bx
{
public:

	CX::UInt64 sbt_3WN8Es8bd;
	sbt_FPkFvDvdxSroSAyqQ sbt_4;
	CX::SB::Map<CX::Double, CX::Int16>::Type sbt_Aii1EpxwH;
	CX::Double sbt_BBiE7;
	CX::Int16 sbt_O6Lbu;
	sbt_aGqmCqmCkLer6NUtTxF sbt_YHFMP;
	CX::UInt64 sbt_d;
	sbt_O143bvo sbt_dP_NokC;
	CX::SB::Vector<CX::Int16>::Type sbt_urK;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_4zanj_ga3ZYRmUoH6Bx &p)
{
	DefInit(p.sbt_3WN8Es8bd);
	DefInit(p.sbt_4);
	DefInit(p.sbt_Aii1EpxwH);
	DefInit(p.sbt_BBiE7);
	DefInit(p.sbt_O6Lbu);
	DefInit(p.sbt_YHFMP);
	DefInit(p.sbt_d);
	DefInit(p.sbt_dP_NokC);
	DefInit(p.sbt_urK);
}

template <> static inline int Compare<sbt_4zanj_ga3ZYRmUoH6Bx>(const sbt_4zanj_ga3ZYRmUoH6Bx &a, const sbt_4zanj_ga3ZYRmUoH6Bx &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3WN8Es8bd, b.sbt_3WN8Es8bd)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_4, b.sbt_4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Aii1EpxwH, b.sbt_Aii1EpxwH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_BBiE7, b.sbt_BBiE7)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_O6Lbu, b.sbt_O6Lbu)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_YHFMP, b.sbt_YHFMP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_d, b.sbt_d)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_dP_NokC, b.sbt_dP_NokC)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_urK, b.sbt_urK)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_4zanj_ga3ZYRmUoH6Bx>(const sbt_4zanj_ga3ZYRmUoH6Bx &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3WN8Es8bd, pHasher);
	Hash(p.sbt_4, pHasher);
	Hash(p.sbt_Aii1EpxwH, pHasher);
	Hash(p.sbt_BBiE7, pHasher);
	Hash(p.sbt_O6Lbu, pHasher);
	Hash(p.sbt_YHFMP, pHasher);
	Hash(p.sbt_d, pHasher);
	Hash(p.sbt_dP_NokC, pHasher);
	Hash(p.sbt_urK, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_4zanj_ga3ZYRmUoH6Bx>(sbt_4zanj_ga3ZYRmUoH6Bx p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3WN8Es8bd", p.sbt_3WN8Es8bd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Aii1EpxwH", p.sbt_Aii1EpxwH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BBiE7", p.sbt_BBiE7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_O6Lbu", p.sbt_O6Lbu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YHFMP", p.sbt_YHFMP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_dP_NokC", p.sbt_dP_NokC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_urK", p.sbt_urK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_4zanj_ga3ZYRmUoH6Bx>(sbt_4zanj_ga3ZYRmUoH6Bx &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3WN8Es8bd", p.sbt_3WN8Es8bd)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Aii1EpxwH", p.sbt_Aii1EpxwH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_BBiE7", p.sbt_BBiE7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_O6Lbu", p.sbt_O6Lbu)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_YHFMP", p.sbt_YHFMP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_d", p.sbt_d)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_dP_NokC", p.sbt_dP_NokC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_urK", p.sbt_urK)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

