
#pragma once


#include "sbt_uE_IyAxSbkvGbDlAe.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_4IFneIqInTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_uE_IyAxSbkvGbDlAe &p)
{
	TestInit(p.sbt_6v7FD8srk);
	TestInit(p.sbt_BcKZkboSz);
	p.sbt_LAnBXCF[-8258951753362789666] = 1665987689;
	p.sbt_LAnBXCF[5896763566561925838] = 3706882791;
	p.sbt_LAnBXCF[-2576295368229168896] = 2289573099;
	p.sbt_LAnBXCF[-6961677475967769170] = 3310737064;
	p.sbt_LAnBXCF[-1247566228831136740] = 1746891710;
	p.sbt_LAnBXCF[-3775035572262718842] = 2171048945;
	p.sbt_LAnBXCF[3357332362150055872] = 1830458496;
	p.sbt_MjI[L"wcI[e5'+i%=ks]C%_=["] = 0.394118f;
	p.sbt_MjI[L"=cM9kgy13Y!'"] = 0.658143f;
	p.sbt_MjI[L"yWiKcsA"] = 0.012568f;
	p.sbt_MjI[L"M];"] = 0.501503f;
	p.sbt_MjI[L"-OeM-oOS3+a{"] = 0.998121f;
	p.sbt_TL2rW = "%";
	p.sbt_X = 1086251149;
	p.sbt_h = 11099;
	p.sbt_okdOIk0ls = false;
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		TestInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		TestInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		TestInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
}

static inline void RandInit(sbt_uE_IyAxSbkvGbDlAe &p)
{
	RandInit(p.sbt_6v7FD8srk);
	RandInit(p.sbt_BcKZkboSz);
	p.sbt_LAnBXCF[CX::Util::RndGen::Get().GetInt64()] = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_MjI[Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_TL2rW = Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_X = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_h = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_okdOIk0ls = CX::Util::RndGen::Get().GetBool();
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
	{
		sbt_4IFneIqIn k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_sSNle[k] = v;
	}
}

}//namespace SB

}//namespace CX

