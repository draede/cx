
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_O143bvo.hpp"


class sbt_E
{
public:

	sbt_O143bvo sbt_3MufHsg;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_E &p)
{
	DefInit(p.sbt_3MufHsg);
}

template <> static inline int Compare<sbt_E>(const sbt_E &a, const sbt_E &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_3MufHsg, b.sbt_3MufHsg)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_E>(const sbt_E &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_3MufHsg, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_E>(sbt_E p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(1)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3MufHsg", p.sbt_3MufHsg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_E>(sbt_E &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (1 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 1 members");
	}
	if ((status = pDataReader->ReadMember("sbt_3MufHsg", p.sbt_3MufHsg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

