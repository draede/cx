
#pragma once


#include "sbt_0Se0hGnpT5kld.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_O143bvoTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_0Se0hGnpT5kld &p)
{
	{
		sbt_O143bvo k;

		TestInit(k);
		p.sbt_8.push_back(k);
	}
	p.sbt_WbLYl8K = 11279303751766403576;
	p.sbt_gJM = -1057877214;
	p.sbt_qCGaRul = 149;
	TestInit(p.sbt_x);
}

static inline void RandInit(sbt_0Se0hGnpT5kld &p)
{
	{
		sbt_O143bvo k;

		TestInit(k);
		p.sbt_8.push_back(k);
	}
	{
		sbt_O143bvo k;

		TestInit(k);
		p.sbt_8.push_back(k);
	}
	{
		sbt_O143bvo k;

		TestInit(k);
		p.sbt_8.push_back(k);
	}
	{
		sbt_O143bvo k;

		TestInit(k);
		p.sbt_8.push_back(k);
	}
	{
		sbt_O143bvo k;

		TestInit(k);
		p.sbt_8.push_back(k);
	}
	p.sbt_WbLYl8K = CX::Util::RndGen::Get().GetUInt64();
	p.sbt_gJM = CX::Util::RndGen::Get().GetInt32();
	p.sbt_qCGaRul = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_x);
}

}//namespace SB

}//namespace CX

