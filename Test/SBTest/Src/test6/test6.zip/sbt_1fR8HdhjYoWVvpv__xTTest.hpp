
#pragma once


#include "sbt_1fR8HdhjYoWVvpv__xT.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_8bqhETest.hpp"
#include "sbt_gvj_DWPqkRZ0XCFOndCTest.hpp"
#include "sbt_225XhmpEekJ7un9iLTest.hpp"
#include "sbt_xCVTest.hpp"
#include "sbt_HRAmxsNTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_1fR8HdhjYoWVvpv__xT &p)
{
	p.sbt_F7Vs5w_ = 1212479125;
	p.sbt_KKtMe = -17516;
	TestInit(p.sbt_Nnz);
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		TestInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	p.sbt_f = 30068;
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		TestInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		TestInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		TestInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		TestInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		TestInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	p.sbt_tPUI9VY[0.933204f] = 0.658755f;
	p.sbt_tPUI9VY[0.259542f] = 0.010563f;
	p.sbt_tPUI9VY[0.802484f] = 0.348831f;
}

static inline void RandInit(sbt_1fR8HdhjYoWVvpv__xT &p)
{
	p.sbt_F7Vs5w_ = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_KKtMe = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_Nnz);
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	{
		sbt_gvj_DWPqkRZ0XCFOndC k;
		sbt_225XhmpEekJ7un9iL v;

		RandInit(k);
		TestInit(v);
		p.sbt_RL6[k] = v;
	}
	p.sbt_f = CX::Util::RndGen::Get().GetInt16();
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		RandInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		RandInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	{
		sbt_xCV k;
		sbt_HRAmxsN v;

		RandInit(k);
		TestInit(v);
		p.sbt_qyhPpMKT_[k] = v;
	}
	p.sbt_tPUI9VY[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_tPUI9VY[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_tPUI9VY[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_tPUI9VY[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetFloat();
	p.sbt_tPUI9VY[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetFloat();
}

}//namespace SB

}//namespace CX

