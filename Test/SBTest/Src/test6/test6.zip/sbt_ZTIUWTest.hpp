
#pragma once


#include "sbt_ZTIUW.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_5sgGyJJOYBQ8tRaTest.hpp"
#include "sbt_qCP3a4QA8VGTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_ZTIUW &p)
{
	{
		sbt_5sgGyJJOYBQ8tRa k;

		TestInit(k);
		p.sbt_NSrARGSXS.push_back(k);
	}
	{
		sbt_5sgGyJJOYBQ8tRa k;

		TestInit(k);
		p.sbt_NSrARGSXS.push_back(k);
	}
	{
		sbt_5sgGyJJOYBQ8tRa k;

		TestInit(k);
		p.sbt_NSrARGSXS.push_back(k);
	}
	{
		sbt_5sgGyJJOYBQ8tRa k;

		TestInit(k);
		p.sbt_NSrARGSXS.push_back(k);
	}
	{
		sbt_5sgGyJJOYBQ8tRa k;

		TestInit(k);
		p.sbt_NSrARGSXS.push_back(k);
	}
	p.sbt_ToZvB = 3340961009;
	p.sbt_UHzZDZD1F = -4645;
	p.sbt_YXO3K.push_back(false);
	p.sbt_YXO3K.push_back(false);
	p.sbt_YXO3K.push_back(true);
	p.sbt_YXO3K.push_back(true);
	p.sbt_YXO3K.push_back(false);
	p.sbt_aocxr = 80;
	TestInit(p.sbt_kTJ);
	TestInit(p.sbt_zQ7);
}

static inline void RandInit(sbt_ZTIUW &p)
{
	{
		sbt_5sgGyJJOYBQ8tRa k;

		TestInit(k);
		p.sbt_NSrARGSXS.push_back(k);
	}
	p.sbt_ToZvB = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_UHzZDZD1F = CX::Util::RndGen::Get().GetInt16();
	p.sbt_YXO3K.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_YXO3K.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_YXO3K.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_YXO3K.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_YXO3K.push_back(CX::Util::RndGen::Get().GetBool());
	p.sbt_aocxr = CX::Util::RndGen::Get().GetUInt8();
	RandInit(p.sbt_kTJ);
	RandInit(p.sbt_zQ7);
}

}//namespace SB

}//namespace CX

