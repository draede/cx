
#pragma once


#include "sbt_g7mB9sN8RPX.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_kTest.hpp"
#include "sbt_1fR8HdhjYoWVvpv__xTTest.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_g7mB9sN8RPX &p)
{
	TestInit(p.sbt_1_cRU);
	p.sbt_5Q21W.push_back(232);
	p.sbt_5Q21W.push_back(213);
	p.sbt_5Q21W.push_back(97);
	p.sbt_5Q21W.push_back(211);
	p.sbt_5Q21W.push_back(159);
	p.sbt_5Q21W.push_back(2);
	p.sbt_5Q21W.push_back(244);
	p.sbt_5y9 = 0.958017f;
	p.sbt_8QnJ_Wm = L"a']')S-+QkIQqGm?wE#a)7!k-GK";
	p.sbt_WQSPio3 = 55940;
	p.sbt_fmSDyaF["G}o!]E"] = -1546271645;
	p.sbt_fmSDyaF["I/?SW1Y{5ku5+A%KKS;S9A"] = 731518061;
	p.sbt_fmSDyaF["1;E}?+eUu/aSCO-uyqQ+]a%/#"] = 1863832664;
	p.sbt_fmSDyaF["s%g#oi#OQq'IW-%"] = 1450537154;
	p.sbt_fmSDyaF["ygaAOg1"] = -408339197;
	p.sbt_fmSDyaF["[3=c?a!K=IGa_WIcyS=yMM#wAY'"] = 61371837;
	p.sbt_fmSDyaF["U?OEui[CYW#G{"] = -151370604;
	p.sbt_kDWQgiRpg = 2555019362902781204;
	TestInit(p.sbt_nvWnYgq);
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
}

static inline void RandInit(sbt_g7mB9sN8RPX &p)
{
	RandInit(p.sbt_1_cRU);
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5Q21W.push_back(CX::Util::RndGen::Get().GetUInt8());
	p.sbt_5y9 = CX::Util::RndGen::Get().GetFloat();
	p.sbt_8QnJ_Wm = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	p.sbt_WQSPio3 = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_fmSDyaF[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_kDWQgiRpg = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_nvWnYgq);
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
	{
		sbt_FPkFvDvdxSroSAyqQ k;

		TestInit(k);
		p.sbt_zfbU03TW4.push_back(k);
	}
}

}//namespace SB

}//namespace CX

