
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_A.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_k.hpp"


class sbt_Nq7
{
public:

	CX::Int8 sbt_4;
	CX::Int64 sbt_5LmGS;
	sbt_A sbt_BQ2oj;
	CX::Int16 sbt_F2YSnCkaz;
	CX::UInt64 sbt_LPl;
	CX::SB::Map<sbt_225XhmpEekJ7un9iL, sbt_k>::Type sbt_Nk_Lxcb;
	sbt_A sbt_iuEuUvE6i;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Nq7 &p)
{
	DefInit(p.sbt_4);
	DefInit(p.sbt_5LmGS);
	DefInit(p.sbt_BQ2oj);
	DefInit(p.sbt_F2YSnCkaz);
	DefInit(p.sbt_LPl);
	DefInit(p.sbt_Nk_Lxcb);
	DefInit(p.sbt_iuEuUvE6i);
}

template <> static inline int Compare<sbt_Nq7>(const sbt_Nq7 &a, const sbt_Nq7 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_4, b.sbt_4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5LmGS, b.sbt_5LmGS)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_BQ2oj, b.sbt_BQ2oj)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F2YSnCkaz, b.sbt_F2YSnCkaz)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LPl, b.sbt_LPl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Nk_Lxcb, b.sbt_Nk_Lxcb)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_iuEuUvE6i, b.sbt_iuEuUvE6i)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Nq7>(const sbt_Nq7 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_4, pHasher);
	Hash(p.sbt_5LmGS, pHasher);
	Hash(p.sbt_BQ2oj, pHasher);
	Hash(p.sbt_F2YSnCkaz, pHasher);
	Hash(p.sbt_LPl, pHasher);
	Hash(p.sbt_Nk_Lxcb, pHasher);
	Hash(p.sbt_iuEuUvE6i, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Nq7>(sbt_Nq7 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(7)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5LmGS", p.sbt_5LmGS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_BQ2oj", p.sbt_BQ2oj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F2YSnCkaz", p.sbt_F2YSnCkaz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LPl", p.sbt_LPl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Nk_Lxcb", p.sbt_Nk_Lxcb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_iuEuUvE6i", p.sbt_iuEuUvE6i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Nq7>(sbt_Nq7 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (7 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 7 members");
	}
	if ((status = pDataReader->ReadMember("sbt_4", p.sbt_4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5LmGS", p.sbt_5LmGS)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_BQ2oj", p.sbt_BQ2oj)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F2YSnCkaz", p.sbt_F2YSnCkaz)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LPl", p.sbt_LPl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Nk_Lxcb", p.sbt_Nk_Lxcb)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_iuEuUvE6i", p.sbt_iuEuUvE6i)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

