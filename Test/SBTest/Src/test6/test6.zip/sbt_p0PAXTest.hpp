
#pragma once


#include "sbt_p0PAX.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_ATest.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"
#include "sbt_kTest.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6BxTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_p0PAX &p)
{
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		TestInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	p.sbt_Rg4eUHi[0.132254f] = true;
	p.sbt_Rg4eUHi[0.998796f] = true;
	p.sbt_Rg4eUHi[0.973010f] = true;
	p.sbt_Zg9 = 935943395958263366;
	TestInit(p.sbt_aHlisy3cv);
	p.sbt_f = -1149780771;
	p.sbt_o9BwH.push_back(17467);
	p.sbt_o9BwH.push_back(-23180);
	p.sbt_o9BwH.push_back(18877);
	p.sbt_o9BwH.push_back(26500);
	p.sbt_o9BwH.push_back(-17104);
	TestInit(p.sbt_p);
}

static inline void RandInit(sbt_p0PAX &p)
{
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	{
		sbt_A k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_I3yBTvc[k] = v;
	}
	p.sbt_Rg4eUHi[CX::Util::RndGen::Get().GetFloat()] = CX::Util::RndGen::Get().GetBool();
	p.sbt_Zg9 = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_aHlisy3cv);
	p.sbt_f = CX::Util::RndGen::Get().GetInt32();
	p.sbt_o9BwH.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_o9BwH.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_o9BwH.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_o9BwH.push_back(CX::Util::RndGen::Get().GetInt16());
	p.sbt_o9BwH.push_back(CX::Util::RndGen::Get().GetInt16());
	RandInit(p.sbt_p);
}

}//namespace SB

}//namespace CX

