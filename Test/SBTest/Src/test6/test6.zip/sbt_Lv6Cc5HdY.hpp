
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_ZTIUW.hpp"
#include "sbt_A.hpp"
#include "sbt_Lu55mym.hpp"


class sbt_Lv6Cc5HdY
{
public:

	CX::Int8 sbt_8Wtbx;
	sbt_ZTIUW sbt_9_T0BvqEC;
	CX::Double sbt_F;
	CX::SB::Vector<CX::String>::Type sbt_F8e9Fy4;
	sbt_A sbt_LXl;
	CX::UInt8 sbt_SVW6e;
	CX::SB::Vector<sbt_Lu55mym>::Type sbt_Sk1Kx2Cce;
	CX::UInt32 sbt_fJCRr_nOW;
	CX::Int32 sbt_scWE48n;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_Lv6Cc5HdY &p)
{
	DefInit(p.sbt_8Wtbx);
	DefInit(p.sbt_9_T0BvqEC);
	DefInit(p.sbt_F);
	DefInit(p.sbt_F8e9Fy4);
	DefInit(p.sbt_LXl);
	DefInit(p.sbt_SVW6e);
	DefInit(p.sbt_Sk1Kx2Cce);
	DefInit(p.sbt_fJCRr_nOW);
	DefInit(p.sbt_scWE48n);
}

template <> static inline int Compare<sbt_Lv6Cc5HdY>(const sbt_Lv6Cc5HdY &a, const sbt_Lv6Cc5HdY &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_8Wtbx, b.sbt_8Wtbx)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_9_T0BvqEC, b.sbt_9_T0BvqEC)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F, b.sbt_F)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_F8e9Fy4, b.sbt_F8e9Fy4)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_LXl, b.sbt_LXl)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_SVW6e, b.sbt_SVW6e)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Sk1Kx2Cce, b.sbt_Sk1Kx2Cce)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fJCRr_nOW, b.sbt_fJCRr_nOW)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_scWE48n, b.sbt_scWE48n)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_Lv6Cc5HdY>(const sbt_Lv6Cc5HdY &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_8Wtbx, pHasher);
	Hash(p.sbt_9_T0BvqEC, pHasher);
	Hash(p.sbt_F, pHasher);
	Hash(p.sbt_F8e9Fy4, pHasher);
	Hash(p.sbt_LXl, pHasher);
	Hash(p.sbt_SVW6e, pHasher);
	Hash(p.sbt_Sk1Kx2Cce, pHasher);
	Hash(p.sbt_fJCRr_nOW, pHasher);
	Hash(p.sbt_scWE48n, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_Lv6Cc5HdY>(sbt_Lv6Cc5HdY p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8Wtbx", p.sbt_8Wtbx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_9_T0BvqEC", p.sbt_9_T0BvqEC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_F8e9Fy4", p.sbt_F8e9Fy4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_LXl", p.sbt_LXl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_SVW6e", p.sbt_SVW6e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Sk1Kx2Cce", p.sbt_Sk1Kx2Cce)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fJCRr_nOW", p.sbt_fJCRr_nOW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_scWE48n", p.sbt_scWE48n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_Lv6Cc5HdY>(sbt_Lv6Cc5HdY &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_8Wtbx", p.sbt_8Wtbx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_9_T0BvqEC", p.sbt_9_T0BvqEC)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F", p.sbt_F)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_F8e9Fy4", p.sbt_F8e9Fy4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_LXl", p.sbt_LXl)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_SVW6e", p.sbt_SVW6e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Sk1Kx2Cce", p.sbt_Sk1Kx2Cce)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fJCRr_nOW", p.sbt_fJCRr_nOW)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_scWE48n", p.sbt_scWE48n)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

