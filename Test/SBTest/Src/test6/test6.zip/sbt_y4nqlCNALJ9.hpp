
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_225XhmpEekJ7un9iL.hpp"
#include "sbt_qCP3a4QA8VG.hpp"
#include "sbt_HBYCFckMOOiNb.hpp"


class sbt_y4nqlCNALJ9
{
public:

	CX::SB::Map<CX::Int32, CX::UInt8>::Type sbt_6pl1G;
	CX::UInt32 sbt_7e15rbH;
	CX::SB::Map<sbt_225XhmpEekJ7un9iL, sbt_225XhmpEekJ7un9iL>::Type sbt_DfOMWFD;
	CX::Bool sbt_GJTK4iBSG;
	CX::SB::Vector<sbt_qCP3a4QA8VG>::Type sbt_M;
	CX::SB::Map<CX::UInt16, CX::UInt64>::Type sbt_QI5mITANA;
	CX::UInt32 sbt_Z8a;
	CX::Float sbt_sVCCP;
	sbt_HBYCFckMOOiNb sbt_vNqRt3E;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_y4nqlCNALJ9 &p)
{
	DefInit(p.sbt_6pl1G);
	DefInit(p.sbt_7e15rbH);
	DefInit(p.sbt_DfOMWFD);
	DefInit(p.sbt_GJTK4iBSG);
	DefInit(p.sbt_M);
	DefInit(p.sbt_QI5mITANA);
	DefInit(p.sbt_Z8a);
	DefInit(p.sbt_sVCCP);
	DefInit(p.sbt_vNqRt3E);
}

template <> static inline int Compare<sbt_y4nqlCNALJ9>(const sbt_y4nqlCNALJ9 &a, const sbt_y4nqlCNALJ9 &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_6pl1G, b.sbt_6pl1G)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_7e15rbH, b.sbt_7e15rbH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_DfOMWFD, b.sbt_DfOMWFD)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_GJTK4iBSG, b.sbt_GJTK4iBSG)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_M, b.sbt_M)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_QI5mITANA, b.sbt_QI5mITANA)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Z8a, b.sbt_Z8a)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_sVCCP, b.sbt_sVCCP)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_vNqRt3E, b.sbt_vNqRt3E)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_y4nqlCNALJ9>(const sbt_y4nqlCNALJ9 &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_6pl1G, pHasher);
	Hash(p.sbt_7e15rbH, pHasher);
	Hash(p.sbt_DfOMWFD, pHasher);
	Hash(p.sbt_GJTK4iBSG, pHasher);
	Hash(p.sbt_M, pHasher);
	Hash(p.sbt_QI5mITANA, pHasher);
	Hash(p.sbt_Z8a, pHasher);
	Hash(p.sbt_sVCCP, pHasher);
	Hash(p.sbt_vNqRt3E, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_y4nqlCNALJ9>(sbt_y4nqlCNALJ9 p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_6pl1G", p.sbt_6pl1G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_7e15rbH", p.sbt_7e15rbH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_DfOMWFD", p.sbt_DfOMWFD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_GJTK4iBSG", p.sbt_GJTK4iBSG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_M", p.sbt_M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_QI5mITANA", p.sbt_QI5mITANA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Z8a", p.sbt_Z8a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_sVCCP", p.sbt_sVCCP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_vNqRt3E", p.sbt_vNqRt3E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_y4nqlCNALJ9>(sbt_y4nqlCNALJ9 &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_6pl1G", p.sbt_6pl1G)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_7e15rbH", p.sbt_7e15rbH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_DfOMWFD", p.sbt_DfOMWFD)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_GJTK4iBSG", p.sbt_GJTK4iBSG)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_M", p.sbt_M)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_QI5mITANA", p.sbt_QI5mITANA)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Z8a", p.sbt_Z8a)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_sVCCP", p.sbt_sVCCP)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_vNqRt3E", p.sbt_vNqRt3E)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

