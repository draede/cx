
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_oX6wa.hpp"
#include "sbt_HBYCFckMOOiNb.hpp"


class sbt_xCV
{
public:

	CX::Double sbt_0qpn_4g;
	CX::SB::Vector<CX::UInt32>::Type sbt_Otn;
	CX::SB::Vector<sbt_oX6wa>::Type sbt_X564v;
	CX::UInt8 sbt_fdG5FBcH8;
	sbt_HBYCFckMOOiNb sbt_t;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_xCV &p)
{
	DefInit(p.sbt_0qpn_4g);
	DefInit(p.sbt_Otn);
	DefInit(p.sbt_X564v);
	DefInit(p.sbt_fdG5FBcH8);
	DefInit(p.sbt_t);
}

template <> static inline int Compare<sbt_xCV>(const sbt_xCV &a, const sbt_xCV &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_0qpn_4g, b.sbt_0qpn_4g)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Otn, b.sbt_Otn)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_X564v, b.sbt_X564v)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fdG5FBcH8, b.sbt_fdG5FBcH8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_t, b.sbt_t)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_xCV>(const sbt_xCV &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_0qpn_4g, pHasher);
	Hash(p.sbt_Otn, pHasher);
	Hash(p.sbt_X564v, pHasher);
	Hash(p.sbt_fdG5FBcH8, pHasher);
	Hash(p.sbt_t, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_xCV>(sbt_xCV p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_0qpn_4g", p.sbt_0qpn_4g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Otn", p.sbt_Otn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_X564v", p.sbt_X564v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fdG5FBcH8", p.sbt_fdG5FBcH8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_t", p.sbt_t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_xCV>(sbt_xCV &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_0qpn_4g", p.sbt_0qpn_4g)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Otn", p.sbt_Otn)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_X564v", p.sbt_X564v)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fdG5FBcH8", p.sbt_fdG5FBcH8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_t", p.sbt_t)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

