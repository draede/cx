
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_k.hpp"
#include "sbt_1fR8HdhjYoWVvpv__xT.hpp"
#include "sbt_FPkFvDvdxSroSAyqQ.hpp"


class sbt_g7mB9sN8RPX
{
public:

	sbt_k sbt_1_cRU;
	CX::SB::Vector<CX::UInt8>::Type sbt_5Q21W;
	CX::Float sbt_5y9;
	CX::WString sbt_8QnJ_Wm;
	CX::UInt16 sbt_WQSPio3;
	CX::SB::Map<CX::String, CX::Int32>::Type sbt_fmSDyaF;
	CX::UInt64 sbt_kDWQgiRpg;
	sbt_1fR8HdhjYoWVvpv__xT sbt_nvWnYgq;
	CX::SB::Vector<sbt_FPkFvDvdxSroSAyqQ>::Type sbt_zfbU03TW4;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_g7mB9sN8RPX &p)
{
	DefInit(p.sbt_1_cRU);
	DefInit(p.sbt_5Q21W);
	DefInit(p.sbt_5y9);
	DefInit(p.sbt_8QnJ_Wm);
	DefInit(p.sbt_WQSPio3);
	DefInit(p.sbt_fmSDyaF);
	DefInit(p.sbt_kDWQgiRpg);
	DefInit(p.sbt_nvWnYgq);
	DefInit(p.sbt_zfbU03TW4);
}

template <> static inline int Compare<sbt_g7mB9sN8RPX>(const sbt_g7mB9sN8RPX &a, const sbt_g7mB9sN8RPX &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_1_cRU, b.sbt_1_cRU)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5Q21W, b.sbt_5Q21W)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_5y9, b.sbt_5y9)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_8QnJ_Wm, b.sbt_8QnJ_Wm)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_WQSPio3, b.sbt_WQSPio3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_fmSDyaF, b.sbt_fmSDyaF)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_kDWQgiRpg, b.sbt_kDWQgiRpg)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_nvWnYgq, b.sbt_nvWnYgq)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zfbU03TW4, b.sbt_zfbU03TW4)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_g7mB9sN8RPX>(const sbt_g7mB9sN8RPX &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_1_cRU, pHasher);
	Hash(p.sbt_5Q21W, pHasher);
	Hash(p.sbt_5y9, pHasher);
	Hash(p.sbt_8QnJ_Wm, pHasher);
	Hash(p.sbt_WQSPio3, pHasher);
	Hash(p.sbt_fmSDyaF, pHasher);
	Hash(p.sbt_kDWQgiRpg, pHasher);
	Hash(p.sbt_nvWnYgq, pHasher);
	Hash(p.sbt_zfbU03TW4, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_g7mB9sN8RPX>(sbt_g7mB9sN8RPX p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_1_cRU", p.sbt_1_cRU)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5Q21W", p.sbt_5Q21W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_5y9", p.sbt_5y9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_8QnJ_Wm", p.sbt_8QnJ_Wm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_WQSPio3", p.sbt_WQSPio3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_fmSDyaF", p.sbt_fmSDyaF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_kDWQgiRpg", p.sbt_kDWQgiRpg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_nvWnYgq", p.sbt_nvWnYgq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zfbU03TW4", p.sbt_zfbU03TW4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_g7mB9sN8RPX>(sbt_g7mB9sN8RPX &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_1_cRU", p.sbt_1_cRU)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5Q21W", p.sbt_5Q21W)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_5y9", p.sbt_5y9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_8QnJ_Wm", p.sbt_8QnJ_Wm)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_WQSPio3", p.sbt_WQSPio3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_fmSDyaF", p.sbt_fmSDyaF)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_kDWQgiRpg", p.sbt_kDWQgiRpg)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_nvWnYgq", p.sbt_nvWnYgq)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zfbU03TW4", p.sbt_zfbU03TW4)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

