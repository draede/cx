
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_Nq7.hpp"
#include "sbt_qCP3a4QA8VG.hpp"


class sbt_gNiZ3WOkV1jeetbhLzJ
{
public:

	CX::UInt8 sbt_YKpPH4sfH;
	sbt_Nq7 sbt_c;
	CX::Float sbt_pbERo;
	CX::Int32 sbt_xjlGvkS55;
	CX::SB::Vector<sbt_qCP3a4QA8VG>::Type sbt_zxmExO5G_;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_gNiZ3WOkV1jeetbhLzJ &p)
{
	DefInit(p.sbt_YKpPH4sfH);
	DefInit(p.sbt_c);
	DefInit(p.sbt_pbERo);
	DefInit(p.sbt_xjlGvkS55);
	DefInit(p.sbt_zxmExO5G_);
}

template <> static inline int Compare<sbt_gNiZ3WOkV1jeetbhLzJ>(const sbt_gNiZ3WOkV1jeetbhLzJ &a, const sbt_gNiZ3WOkV1jeetbhLzJ &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_YKpPH4sfH, b.sbt_YKpPH4sfH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_c, b.sbt_c)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_pbERo, b.sbt_pbERo)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_xjlGvkS55, b.sbt_xjlGvkS55)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_zxmExO5G_, b.sbt_zxmExO5G_)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_gNiZ3WOkV1jeetbhLzJ>(const sbt_gNiZ3WOkV1jeetbhLzJ &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_YKpPH4sfH, pHasher);
	Hash(p.sbt_c, pHasher);
	Hash(p.sbt_pbERo, pHasher);
	Hash(p.sbt_xjlGvkS55, pHasher);
	Hash(p.sbt_zxmExO5G_, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_gNiZ3WOkV1jeetbhLzJ>(sbt_gNiZ3WOkV1jeetbhLzJ p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(5)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_YKpPH4sfH", p.sbt_YKpPH4sfH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_c", p.sbt_c)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_pbERo", p.sbt_pbERo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_xjlGvkS55", p.sbt_xjlGvkS55)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_zxmExO5G_", p.sbt_zxmExO5G_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_gNiZ3WOkV1jeetbhLzJ>(sbt_gNiZ3WOkV1jeetbhLzJ &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (5 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 5 members");
	}
	if ((status = pDataReader->ReadMember("sbt_YKpPH4sfH", p.sbt_YKpPH4sfH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_c", p.sbt_c)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_pbERo", p.sbt_pbERo)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_xjlGvkS55", p.sbt_xjlGvkS55)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_zxmExO5G_", p.sbt_zxmExO5G_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

