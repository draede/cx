
#pragma once


#include "CX/SB/Types.hpp"
#include "CX/SB/Comparators.hpp"
#include "CX/SB/Hashers.hpp"
#include "CX/SB/DefIniters.hpp"
#include "CX/SB/Readers.hpp"
#include "CX/SB/Writers.hpp"
#include "sbt_A.hpp"
#include "sbt_8bqhE.hpp"
#include "sbt_y4nqlCNALJ9.hpp"


class sbt_ekP_c1S
{
public:

	CX::SB::Vector<CX::Float>::Type sbt_2FADxlpyH;
	CX::Float sbt_3;
	CX::Int8 sbt_EWx;
	sbt_A sbt_Ex5p_;
	sbt_8bqhE sbt_FJ3do;
	CX::SB::Map<CX::Bool, CX::Double>::Type sbt_O;
	CX::UInt16 sbt_e;
	sbt_y4nqlCNALJ9 sbt_qa7m8;
	CX::Int16 sbt_xOGM15crT;

};


namespace CX
{

namespace SB
{

static inline void DefInit(sbt_ekP_c1S &p)
{
	DefInit(p.sbt_2FADxlpyH);
	DefInit(p.sbt_3);
	DefInit(p.sbt_EWx);
	DefInit(p.sbt_Ex5p_);
	DefInit(p.sbt_FJ3do);
	DefInit(p.sbt_O);
	DefInit(p.sbt_e);
	DefInit(p.sbt_qa7m8);
	DefInit(p.sbt_xOGM15crT);
}

template <> static inline int Compare<sbt_ekP_c1S>(const sbt_ekP_c1S &a, const sbt_ekP_c1S &b)
{
	int nCmp;

	if (0 != (nCmp = Compare(a.sbt_2FADxlpyH, b.sbt_2FADxlpyH)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_3, b.sbt_3)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_EWx, b.sbt_EWx)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_Ex5p_, b.sbt_Ex5p_)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_FJ3do, b.sbt_FJ3do)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_O, b.sbt_O)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_e, b.sbt_e)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_qa7m8, b.sbt_qa7m8)))
	{
		return nCmp;
	}
	if (0 != (nCmp = Compare(a.sbt_xOGM15crT, b.sbt_xOGM15crT)))
	{
		return nCmp;
	}

	return 0;
}

template <> static inline Size Hash<sbt_ekP_c1S>(const sbt_ekP_c1S &p, HasherHelper *pHasher)
{
	HasherHelper hh;

	if (NULL == pHasher)
	{
		hh.Init();
		pHasher = &hh;
	}
	Hash(p.sbt_2FADxlpyH, pHasher);
	Hash(p.sbt_3, pHasher);
	Hash(p.sbt_EWx, pHasher);
	Hash(p.sbt_Ex5p_, pHasher);
	Hash(p.sbt_FJ3do, pHasher);
	Hash(p.sbt_O, pHasher);
	Hash(p.sbt_e, pHasher);
	Hash(p.sbt_qa7m8, pHasher);
	Hash(p.sbt_xOGM15crT, pHasher);
	if (&hh == pHasher)
	{
		return hh.Done();
	}
	else
	{
		return 0;
	}

	return true;
}

template <> static inline Status Write<sbt_ekP_c1S>(sbt_ekP_c1S p, IDataWriter *pDataWriter)
{
	Status status;

	if ((status = pDataWriter->BeginObject(9)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_2FADxlpyH", p.sbt_2FADxlpyH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_3", p.sbt_3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_EWx", p.sbt_EWx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_Ex5p_", p.sbt_Ex5p_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_FJ3do", p.sbt_FJ3do)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_O", p.sbt_O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_e", p.sbt_e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_qa7m8", p.sbt_qa7m8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->WriteMember("sbt_xOGM15crT", p.sbt_xOGM15crT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataWriter->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

template <> static inline Status Read<sbt_ekP_c1S>(sbt_ekP_c1S &p, IDataReader *pDataReader)
{
	Size   cCount;
	Status status;

	DefInit(p);
	if ((status = pDataReader->BeginObject(&cCount)).IsNOK())
	{
		return status;
	}
	if (9 != cCount)
	{
		return Status(Status_InvalidArg, "Expected 9 members");
	}
	if ((status = pDataReader->ReadMember("sbt_2FADxlpyH", p.sbt_2FADxlpyH)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_3", p.sbt_3)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_EWx", p.sbt_EWx)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_Ex5p_", p.sbt_Ex5p_)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_FJ3do", p.sbt_FJ3do)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_O", p.sbt_O)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_e", p.sbt_e)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_qa7m8", p.sbt_qa7m8)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->ReadMember("sbt_xOGM15crT", p.sbt_xOGM15crT)).IsNOK())
	{
		return status;
	}
	if ((status = pDataReader->EndObject()).IsNOK())
	{
		return status;
	}

	return Status();
}

}//namespace SB

}//namespace CX

