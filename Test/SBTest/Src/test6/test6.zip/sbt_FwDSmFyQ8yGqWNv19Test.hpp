
#pragma once


#include "sbt_FwDSmFyQ8yGqWNv19.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_O143bvoTest.hpp"
#include "sbt_8bqhETest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_FwDSmFyQ8yGqWNv19 &p)
{
	p.sbt_8Gs6Yo1.push_back(45133);
	p.sbt_EvURu7Kfk = 46184315;
	p.sbt_ExpDmJI = 0.163676;
	p.sbt_JShLBd7FA = 1653902921673106452;
	TestInit(p.sbt_bL0VGkkDt);
	p.sbt_bV5jl = L"EMCe)o}%)[=qMm13O%{UQq%A?!E{";
	{
		sbt_8bqhE k;

		TestInit(k);
		p.sbt_q3n.push_back(k);
	}
	{
		sbt_8bqhE k;

		TestInit(k);
		p.sbt_q3n.push_back(k);
	}
	{
		sbt_8bqhE k;

		TestInit(k);
		p.sbt_q3n.push_back(k);
	}
	{
		sbt_8bqhE k;

		TestInit(k);
		p.sbt_q3n.push_back(k);
	}
	{
		sbt_8bqhE k;

		TestInit(k);
		p.sbt_q3n.push_back(k);
	}
	p.sbt_qF0[3384894589] = 57176;
	p.sbt_qF0[268679255] = 15389;
	p.sbt_qF0[304841200] = 25613;
	TestInit(p.sbt_uDC9aU6xn);
}

static inline void RandInit(sbt_FwDSmFyQ8yGqWNv19 &p)
{
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_8Gs6Yo1.push_back(CX::Util::RndGen::Get().GetUInt16());
	p.sbt_EvURu7Kfk = CX::Util::RndGen::Get().GetUInt32();
	p.sbt_ExpDmJI = CX::Util::RndGen::Get().GetDouble();
	p.sbt_JShLBd7FA = CX::Util::RndGen::Get().GetInt64();
	RandInit(p.sbt_bL0VGkkDt);
	p.sbt_bV5jl = Util::RndGen::Get().GetWString(0, 30, L"!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~");
	{
		sbt_8bqhE k;

		TestInit(k);
		p.sbt_q3n.push_back(k);
	}
	p.sbt_qF0[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_qF0[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetUInt16();
	p.sbt_qF0[CX::Util::RndGen::Get().GetUInt32()] = CX::Util::RndGen::Get().GetUInt16();
	RandInit(p.sbt_uDC9aU6xn);
}

}//namespace SB

}//namespace CX

