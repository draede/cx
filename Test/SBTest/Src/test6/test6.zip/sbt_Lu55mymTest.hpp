
#pragma once


#include "sbt_Lu55mym.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_8bqhETest.hpp"
#include "sbt_FPkFvDvdxSroSAyqQTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_Lu55mym &p)
{
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		TestInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
}

static inline void RandInit(sbt_Lu55mym &p)
{
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
	{
		sbt_8bqhE k;
		sbt_FPkFvDvdxSroSAyqQ v;

		RandInit(k);
		TestInit(v);
		p.sbt_PLiQFNi[k] = v;
	}
}

}//namespace SB

}//namespace CX

