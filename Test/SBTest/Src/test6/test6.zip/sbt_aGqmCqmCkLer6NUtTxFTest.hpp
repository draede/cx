
#pragma once


#include "sbt_aGqmCqmCkLer6NUtTxF.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_3YcOGtzqwTtSwgm3ETest.hpp"
#include "sbt_4IFneIqInTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_aGqmCqmCkLer6NUtTxF &p)
{
	p.sbt_6.push_back(0.246779f);
	p.sbt_6.push_back(0.604613f);
	p.sbt_6.push_back(0.258806f);
	p.sbt_6.push_back(0.304247f);
	p.sbt_6.push_back(0.572483f);
	p.sbt_6.push_back(0.866994f);
	p.sbt_6.push_back(0.738693f);
	p.sbt_6.push_back(0.922525f);
	p.sbt_6.push_back(0.886403f);
	p.sbt_Wtl = 30669;
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		TestInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		TestInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		TestInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
}

static inline void RandInit(sbt_aGqmCqmCkLer6NUtTxF &p)
{
	p.sbt_6.push_back(CX::Util::RndGen::Get().GetFloat());
	p.sbt_Wtl = CX::Util::RndGen::Get().GetInt16();
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
	{
		sbt_3YcOGtzqwTtSwgm3E k;
		sbt_4IFneIqIn v;

		RandInit(k);
		TestInit(v);
		p.sbt_r[k] = v;
	}
}

}//namespace SB

}//namespace CX

