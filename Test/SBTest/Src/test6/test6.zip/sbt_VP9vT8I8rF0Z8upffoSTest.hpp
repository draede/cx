
#pragma once


#include "sbt_VP9vT8I8rF0Z8upffoS.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_xCVTest.hpp"
#include "sbt_4zanj_ga3ZYRmUoH6BxTest.hpp"
#include "sbt_0Se0hGnpT5kldTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_VP9vT8I8rF0Z8upffoS &p)
{
	p.sbt_4s4kak8 = 0.397109;
	p.sbt_98t = 20;
	TestInit(p.sbt_PSc7fXWJe);
	TestInit(p.sbt_W4lY7);
	p.sbt__sjF8yJ = 6504082130106768338;
	TestInit(p.sbt_mHC);
	p.sbt_zbNlLq1L3["'U#+Os35y7u}y}[!W"] = 1907930672;
}

static inline void RandInit(sbt_VP9vT8I8rF0Z8upffoS &p)
{
	p.sbt_4s4kak8 = CX::Util::RndGen::Get().GetDouble();
	p.sbt_98t = CX::Util::RndGen::Get().GetInt8();
	RandInit(p.sbt_PSc7fXWJe);
	RandInit(p.sbt_W4lY7);
	p.sbt__sjF8yJ = CX::Util::RndGen::Get().GetUInt64();
	RandInit(p.sbt_mHC);
	p.sbt_zbNlLq1L3[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_zbNlLq1L3[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_zbNlLq1L3[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_zbNlLq1L3[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
	p.sbt_zbNlLq1L3[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

