
#pragma once


#include "sbt_gCnAZ4Srk0wKwMRpk.hpp"
#include "CX/Util/RndGen.hpp"
#include "sbt_5sgGyJJOYBQ8tRaTest.hpp"
#include "sbt_nmlP8GM6WCm_C8wEsTest.hpp"
#include "sbt_iS77qTest.hpp"


namespace CX
{

namespace SB
{

static inline void TestInit(sbt_gCnAZ4Srk0wKwMRpk &p)
{
	p.sbt_0N_98EIdV = 0.002276;
	TestInit(p.sbt_0tjN68F);
	p.sbt_6oR1d = 0.847352;
	TestInit(p.sbt_StI4C42);
	p.sbt_VBlyGMGJK["#A]K{/CIm-#o-G"] = 16508;
	p.sbt_VBlyGMGJK["CU=Io%CayE"] = 11239;
	p.sbt_VBlyGMGJK["!iom?=?w3ii"] = -31911;
	p.sbt_VBlyGMGJK[";SqEY"] = 18503;
	p.sbt_VBlyGMGJK[";eE"] = -26037;
	p.sbt_VBlyGMGJK["EAcI'{!1Koe/ag''q%3kY9;yA;Qe-"] = 10807;
	p.sbt_VBlyGMGJK["eCACIu13"] = 921;
	p.sbt_VBlyGMGJK["u%1}"] = 22575;
	p.sbt_VBlyGMGJK["/1{"] = -11637;
	TestInit(p.sbt_YM0);
	p.sbt__Iljn8h = 116;
	p.sbt_kXyzElSdM = 0.711316;
	p.sbt_tuT = 189715296;
}

static inline void RandInit(sbt_gCnAZ4Srk0wKwMRpk &p)
{
	p.sbt_0N_98EIdV = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_0tjN68F);
	p.sbt_6oR1d = CX::Util::RndGen::Get().GetDouble();
	RandInit(p.sbt_StI4C42);
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	p.sbt_VBlyGMGJK[Util::RndGen::Get().GetString(0, 30, "!#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~")] = CX::Util::RndGen::Get().GetInt16();
	RandInit(p.sbt_YM0);
	p.sbt__Iljn8h = CX::Util::RndGen::Get().GetUInt8();
	p.sbt_kXyzElSdM = CX::Util::RndGen::Get().GetDouble();
	p.sbt_tuT = CX::Util::RndGen::Get().GetInt32();
}

}//namespace SB

}//namespace CX

