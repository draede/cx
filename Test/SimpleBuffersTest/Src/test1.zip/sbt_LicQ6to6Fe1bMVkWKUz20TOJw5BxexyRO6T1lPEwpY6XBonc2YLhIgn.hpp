
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_GtcIUaYWCt5kAsi2u.hpp"


class sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh;
	CX::Double sbt_ZNP10qBz8QRRJIBR7IgnA;
	CX::Int8 sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR;
	CX::IO::SimpleBuffers::UInt64Array sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X;
	CX::UInt16 sbt_xKCsYF8E334;
	CX::IO::SimpleBuffers::Int8Array sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5;
	CX::IO::SimpleBuffers::FloatArray sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt;
	CX::Bool sbt_HAB1M7mdygM32Kxl4wKnTolWUCN;
	CX::Int16 sbt__9LmWsvD20fx85ejp;
	CX::UInt64 sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy;
	CX::Int32 sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy;
	CX::IO::SimpleBuffers::WStringArray sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn;
	CX::Float sbt_ZI5_2CuPW44;
	CX::IO::SimpleBuffers::FloatArray sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe;
	CX::IO::SimpleBuffers::UInt64Array sbt_d;
	CX::String sbt_6nStjyqr9k9KhMCfsfu6PGK8P;
	CX::Int64 sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe;
	sbt_GtcIUaYWCt5kAsi2uArray sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj;

	virtual void Reset()
	{
		sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh = 0;
		sbt_ZNP10qBz8QRRJIBR7IgnA = 0.0;
		sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR = 0;
		sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.clear();
		sbt_xKCsYF8E334 = 0;
		sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.clear();
		sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.clear();
		sbt_HAB1M7mdygM32Kxl4wKnTolWUCN = false;
		sbt__9LmWsvD20fx85ejp = 0;
		sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy = 0;
		sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy = 0;
		sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.clear();
		sbt_ZI5_2CuPW44 = 0.0f;
		sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.clear();
		sbt_d.clear();
		sbt_6nStjyqr9k9KhMCfsfu6PGK8P.clear();
		sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe = 0;
		sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh = -85;
		sbt_ZNP10qBz8QRRJIBR7IgnA = 0.676989;
		sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR = -30;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.push_back(17897751521795709572);
		}
		sbt_xKCsYF8E334 = 1975;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.push_back(-93);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.push_back(0.598817f);
		}
		sbt_HAB1M7mdygM32Kxl4wKnTolWUCN = true;
		sbt__9LmWsvD20fx85ejp = -79;
		sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy = 11586228411173470844;
		sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy = -304992956;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.push_back(L"wl'hVR/xgcM9vf+,6}-:h|I`_WlSS$5gw(rVFskI^^@jzq");
		}
		sbt_ZI5_2CuPW44 = 0.045071f;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.push_back(0.234387f);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_d.push_back(16620901382616486490);
		}
		sbt_6nStjyqr9k9KhMCfsfu6PGK8P = "1f`sd0\"q=SU*~3O1%G.Bet:&iy.\"#MmpC`x_+~}*}~s{{.nd(:Zs%hw+l+5#";
		sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe = 2038368294466425284;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_GtcIUaYWCt5kAsi2u v;

			v.SetupWithSomeValues();
			sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn *pObject = dynamic_cast<const sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh != pObject->sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh)
		{
			return false;
		}
		if (sbt_ZNP10qBz8QRRJIBR7IgnA != pObject->sbt_ZNP10qBz8QRRJIBR7IgnA)
		{
			return false;
		}
		if (sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR != pObject->sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR)
		{
			return false;
		}
		if (sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.size() != pObject->sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.size(); i++)
		{
			if (sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X[i] != pObject->sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X[i])
			{
				return false;
			}
		}
		if (sbt_xKCsYF8E334 != pObject->sbt_xKCsYF8E334)
		{
			return false;
		}
		if (sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.size() != pObject->sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.size(); i++)
		{
			if (sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5[i] != pObject->sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5[i])
			{
				return false;
			}
		}
		if (sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.size() != pObject->sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.size(); i++)
		{
			if (sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt[i] != pObject->sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt[i])
			{
				return false;
			}
		}
		if (sbt_HAB1M7mdygM32Kxl4wKnTolWUCN != pObject->sbt_HAB1M7mdygM32Kxl4wKnTolWUCN)
		{
			return false;
		}
		if (sbt__9LmWsvD20fx85ejp != pObject->sbt__9LmWsvD20fx85ejp)
		{
			return false;
		}
		if (sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy != pObject->sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy)
		{
			return false;
		}
		if (sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy != pObject->sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy)
		{
			return false;
		}
		if (sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.size() != pObject->sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn[i].c_str(), pObject->sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ZI5_2CuPW44 != pObject->sbt_ZI5_2CuPW44)
		{
			return false;
		}
		if (sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.size() != pObject->sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.size(); i++)
		{
			if (sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe[i] != pObject->sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe[i])
			{
				return false;
			}
		}
		if (sbt_d.size() != pObject->sbt_d.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d.size(); i++)
		{
			if (sbt_d[i] != pObject->sbt_d[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_6nStjyqr9k9KhMCfsfu6PGK8P.c_str(), pObject->sbt_6nStjyqr9k9KhMCfsfu6PGK8P.c_str()))
		{
			return false;
		}
		if (sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe != pObject->sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe)
		{
			return false;
		}
		if (sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.size() != pObject->sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.size(); i++)
		{
			if (!sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj[i].Compare(&pObject->sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_ZNP10qBz8QRRJIBR7IgnA", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ZNP10qBz8QRRJIBR7IgnA = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xKCsYF8E334", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xKCsYF8E334 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_HAB1M7mdygM32Kxl4wKnTolWUCN", &sbt_HAB1M7mdygM32Kxl4wKnTolWUCN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__9LmWsvD20fx85ejp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__9LmWsvD20fx85ejp = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_ZI5_2CuPW44", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ZI5_2CuPW44 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_d")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_6nStjyqr9k9KhMCfsfu6PGK8P", &sbt_6nStjyqr9k9KhMCfsfu6PGK8P)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_GtcIUaYWCt5kAsi2u tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh", (CX::Int64)sbt_UEnaD6Hyv7kLEEfnLtOWloMjC4n2K5m88IUesxNnebBTh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ZNP10qBz8QRRJIBR7IgnA", (CX::Double)sbt_ZNP10qBz8QRRJIBR7IgnA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR", (CX::Int64)sbt_AzNBqAc8DYedcJwVwviE8vKYF60fYkBVRzRpnNOWR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.begin(); iter != sbt_TblApFYaMhwQ3xKH3LrDdAXAx0Ar_SL8X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xKCsYF8E334", (CX::Int64)sbt_xKCsYF8E334)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.begin(); iter != sbt_Gx5r3G4RVfgZyI4PpkM2aGycjQCvt8TX384FeDsX9XNqGtEAIHBD48dAqDhhLS5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.begin(); iter != sbt_FjUJ4Ar0kuLNCgwFJy5IZsHSmEUWLu5Bt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_HAB1M7mdygM32Kxl4wKnTolWUCN", sbt_HAB1M7mdygM32Kxl4wKnTolWUCN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__9LmWsvD20fx85ejp", (CX::Int64)sbt__9LmWsvD20fx85ejp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy", (CX::Int64)sbt_LYbMSdlecfIgX5wcMrij8Oli_I_NVJT2WpluLusyo4lnMe8amsy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy", (CX::Int64)sbt_8pl5JCZFDf7B2xrEHyS8pfbXi8In7U5drwmQPRMLfGf0fjsNWXy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.begin(); iter != sbt_UUpfmvXNgdhUYS0o0Ks5HppsCtBJiiQKCQZJBNfWKHuBeljbn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ZI5_2CuPW44", (CX::Double)sbt_ZI5_2CuPW44)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.begin(); iter != sbt_iStbDvf5xrufpsU3Xr2cIhBBLakxmd6vr62PU4wGXaBOlCdswDe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_d.begin(); iter != sbt_d.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_6nStjyqr9k9KhMCfsfu6PGK8P", sbt_6nStjyqr9k9KhMCfsfu6PGK8P.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe", (CX::Int64)sbt_WwqEquDO9woMNMj45kqlA6NhuSgBCJO_Cq6abKxQe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj")).IsNOK())
		{
			return status;
		}
		for (sbt_GtcIUaYWCt5kAsi2uArray::const_iterator iter = sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.begin(); iter != sbt_XeGCtqJKt2CPGnk0Nnt6of4fdqiAiTRyi3NmEsj.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn>::Type sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgnArray;

