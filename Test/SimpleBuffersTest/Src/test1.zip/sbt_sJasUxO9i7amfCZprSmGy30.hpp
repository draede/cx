
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_sJasUxO9i7amfCZprSmGy30 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS;
	CX::IO::SimpleBuffers::UInt64Array sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y;
	CX::Int64 sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc;
	CX::UInt32 sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR;
	CX::IO::SimpleBuffers::Int8Array sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP;
	CX::UInt64 sbt_9SRLC;
	CX::IO::SimpleBuffers::Int8Array sbt_2BBEdlVral8JQQN1U5Y;
	CX::IO::SimpleBuffers::UInt8Array sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO;
	CX::IO::SimpleBuffers::Int16Array sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO;
	CX::IO::SimpleBuffers::Int32Array sbt_L22RS6fgc0mzs5J;
	CX::Int32 sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm;
	CX::IO::SimpleBuffers::UInt8Array sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT;
	CX::IO::SimpleBuffers::UInt8Array sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k;
	CX::IO::SimpleBuffers::Int8Array sbt_xxOkoRy65QUhYCn0F;
	CX::Bool sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p;
	CX::IO::SimpleBuffers::Int8Array sbt_7JT2gfS;
	CX::UInt64 sbt_ZbMk9vgICUoE34_XVGgaX;
	CX::UInt64 sbt_lZxBpkhcieuWU46jbDOpp9o3a;
	CX::IO::SimpleBuffers::UInt8Array sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd;
	CX::UInt64 sbt_4ZVuK;
	CX::Int16 sbt_5VE;
	CX::IO::SimpleBuffers::UInt32Array sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe;
	CX::IO::SimpleBuffers::UInt8Array sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R;
	CX::IO::SimpleBuffers::Int16Array sbt_p0f_Al_hWAGww9D4X;
	CX::Bool sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr;
	CX::IO::SimpleBuffers::BoolArray sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN;
	CX::UInt16 sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt;

	virtual void Reset()
	{
		sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS = false;
		sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.clear();
		sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc = 0;
		sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR = 0;
		sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.clear();
		sbt_9SRLC = 0;
		sbt_2BBEdlVral8JQQN1U5Y.clear();
		sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.clear();
		sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.clear();
		sbt_L22RS6fgc0mzs5J.clear();
		sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm = 0;
		sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.clear();
		sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.clear();
		sbt_xxOkoRy65QUhYCn0F.clear();
		sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p = false;
		sbt_7JT2gfS.clear();
		sbt_ZbMk9vgICUoE34_XVGgaX = 0;
		sbt_lZxBpkhcieuWU46jbDOpp9o3a = 0;
		sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.clear();
		sbt_4ZVuK = 0;
		sbt_5VE = 0;
		sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.clear();
		sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.clear();
		sbt_p0f_Al_hWAGww9D4X.clear();
		sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr = false;
		sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.clear();
		sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS = true;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.push_back(15796538933638494498);
		}
		sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc = 6305217109947654770;
		sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR = 3833991735;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.push_back(113);
		}
		sbt_9SRLC = 694908977166369212;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_2BBEdlVral8JQQN1U5Y.push_back(-82);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.push_back(45);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.push_back(-25373);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_L22RS6fgc0mzs5J.push_back(-1318772499);
		}
		sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm = -91214067;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.push_back(69);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.push_back(254);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_xxOkoRy65QUhYCn0F.push_back(-85);
		}
		sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p = false;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_7JT2gfS.push_back(14);
		}
		sbt_ZbMk9vgICUoE34_XVGgaX = 9193879481456625826;
		sbt_lZxBpkhcieuWU46jbDOpp9o3a = 18067244319582221626;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.push_back(241);
		}
		sbt_4ZVuK = 8923795254533958260;
		sbt_5VE = 16809;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.push_back(3959710211);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.push_back(229);
		}
		sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr = true;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.push_back(false);
		}
		sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt = 1178;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_sJasUxO9i7amfCZprSmGy30 *pObject = dynamic_cast<const sbt_sJasUxO9i7amfCZprSmGy30 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS != pObject->sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS)
		{
			return false;
		}
		if (sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.size() != pObject->sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.size(); i++)
		{
			if (sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y[i] != pObject->sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y[i])
			{
				return false;
			}
		}
		if (sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc != pObject->sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc)
		{
			return false;
		}
		if (sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR != pObject->sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR)
		{
			return false;
		}
		if (sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.size() != pObject->sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.size(); i++)
		{
			if (sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP[i] != pObject->sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP[i])
			{
				return false;
			}
		}
		if (sbt_9SRLC != pObject->sbt_9SRLC)
		{
			return false;
		}
		if (sbt_2BBEdlVral8JQQN1U5Y.size() != pObject->sbt_2BBEdlVral8JQQN1U5Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2BBEdlVral8JQQN1U5Y.size(); i++)
		{
			if (sbt_2BBEdlVral8JQQN1U5Y[i] != pObject->sbt_2BBEdlVral8JQQN1U5Y[i])
			{
				return false;
			}
		}
		if (sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.size() != pObject->sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.size(); i++)
		{
			if (sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO[i] != pObject->sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO[i])
			{
				return false;
			}
		}
		if (sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.size() != pObject->sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.size(); i++)
		{
			if (sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO[i] != pObject->sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO[i])
			{
				return false;
			}
		}
		if (sbt_L22RS6fgc0mzs5J.size() != pObject->sbt_L22RS6fgc0mzs5J.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L22RS6fgc0mzs5J.size(); i++)
		{
			if (sbt_L22RS6fgc0mzs5J[i] != pObject->sbt_L22RS6fgc0mzs5J[i])
			{
				return false;
			}
		}
		if (sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm != pObject->sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm)
		{
			return false;
		}
		if (sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.size() != pObject->sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.size(); i++)
		{
			if (sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT[i] != pObject->sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT[i])
			{
				return false;
			}
		}
		if (sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.size() != pObject->sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.size(); i++)
		{
			if (sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k[i] != pObject->sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k[i])
			{
				return false;
			}
		}
		if (sbt_xxOkoRy65QUhYCn0F.size() != pObject->sbt_xxOkoRy65QUhYCn0F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xxOkoRy65QUhYCn0F.size(); i++)
		{
			if (sbt_xxOkoRy65QUhYCn0F[i] != pObject->sbt_xxOkoRy65QUhYCn0F[i])
			{
				return false;
			}
		}
		if (sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p != pObject->sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p)
		{
			return false;
		}
		if (sbt_7JT2gfS.size() != pObject->sbt_7JT2gfS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7JT2gfS.size(); i++)
		{
			if (sbt_7JT2gfS[i] != pObject->sbt_7JT2gfS[i])
			{
				return false;
			}
		}
		if (sbt_ZbMk9vgICUoE34_XVGgaX != pObject->sbt_ZbMk9vgICUoE34_XVGgaX)
		{
			return false;
		}
		if (sbt_lZxBpkhcieuWU46jbDOpp9o3a != pObject->sbt_lZxBpkhcieuWU46jbDOpp9o3a)
		{
			return false;
		}
		if (sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.size() != pObject->sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.size(); i++)
		{
			if (sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd[i] != pObject->sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd[i])
			{
				return false;
			}
		}
		if (sbt_4ZVuK != pObject->sbt_4ZVuK)
		{
			return false;
		}
		if (sbt_5VE != pObject->sbt_5VE)
		{
			return false;
		}
		if (sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.size() != pObject->sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.size(); i++)
		{
			if (sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe[i] != pObject->sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe[i])
			{
				return false;
			}
		}
		if (sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.size() != pObject->sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.size(); i++)
		{
			if (sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R[i] != pObject->sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R[i])
			{
				return false;
			}
		}
		if (sbt_p0f_Al_hWAGww9D4X.size() != pObject->sbt_p0f_Al_hWAGww9D4X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p0f_Al_hWAGww9D4X.size(); i++)
		{
			if (sbt_p0f_Al_hWAGww9D4X[i] != pObject->sbt_p0f_Al_hWAGww9D4X[i])
			{
				return false;
			}
		}
		if (sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr != pObject->sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr)
		{
			return false;
		}
		if (sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.size() != pObject->sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.size(); i++)
		{
			if (sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN[i] != pObject->sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN[i])
			{
				return false;
			}
		}
		if (sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt != pObject->sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS", &sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9SRLC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9SRLC = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2BBEdlVral8JQQN1U5Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2BBEdlVral8JQQN1U5Y.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L22RS6fgc0mzs5J")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L22RS6fgc0mzs5J.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xxOkoRy65QUhYCn0F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xxOkoRy65QUhYCn0F.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p", &sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7JT2gfS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7JT2gfS.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZbMk9vgICUoE34_XVGgaX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZbMk9vgICUoE34_XVGgaX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lZxBpkhcieuWU46jbDOpp9o3a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lZxBpkhcieuWU46jbDOpp9o3a = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4ZVuK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4ZVuK = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5VE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5VE = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_p0f_Al_hWAGww9D4X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p0f_Al_hWAGww9D4X.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr", &sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS", sbt_W6ywrrKIm1ZOzZbQOBxqT0CZ0axhHHa9pnPT4MgKE2_nkZiPS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.begin(); iter != sbt_ZwXFFOPzYPipr7ZEhh2acNNly7AnH6XUjzxfcLykZ1Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc", (CX::Int64)sbt_pzCbqoE9En_7GKm6_eF4M_DoO1dyrAlYHWEt0akkc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR", (CX::Int64)sbt_jCZ3oUaEXjFv94svu_gAEJEoP7jU576aHOR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.begin(); iter != sbt_DX_DJrDvbo_s3cSwm_dgEMn5oKB72mGlBUs867YguNnBP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9SRLC", (CX::Int64)sbt_9SRLC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2BBEdlVral8JQQN1U5Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_2BBEdlVral8JQQN1U5Y.begin(); iter != sbt_2BBEdlVral8JQQN1U5Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.begin(); iter != sbt_ZjlkEZ9mVyoPkZjVrJJztu1GO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.begin(); iter != sbt_BEUN3JyAotjcFoMTG9rIX7zf4o4pgPXXg1JgH_0p0w7E_TAEPI7nLbTTPFO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L22RS6fgc0mzs5J")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_L22RS6fgc0mzs5J.begin(); iter != sbt_L22RS6fgc0mzs5J.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm", (CX::Int64)sbt_nAhPMhAF_9M51UjnIyRPaa1IfYvNH9cozimb_dTNbuHh8Xm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.begin(); iter != sbt_giPAqDUrbEP6hiWkkaXbltcLkUAUd0NY12Rbq3dzn73lDC2SeYpR8hJ4gvijNJT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.begin(); iter != sbt_nX4qcSAspjNJy0jaFefbsu1MPiIkSEGHs7g4k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xxOkoRy65QUhYCn0F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_xxOkoRy65QUhYCn0F.begin(); iter != sbt_xxOkoRy65QUhYCn0F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p", sbt_qXhTJ575DYLfD1UF3K_rS_4qGbbvrjh1soqxl7WdGVSOD_qTnhyf64p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7JT2gfS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_7JT2gfS.begin(); iter != sbt_7JT2gfS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZbMk9vgICUoE34_XVGgaX", (CX::Int64)sbt_ZbMk9vgICUoE34_XVGgaX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lZxBpkhcieuWU46jbDOpp9o3a", (CX::Int64)sbt_lZxBpkhcieuWU46jbDOpp9o3a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.begin(); iter != sbt_iK76t7kKfEXs4szW1Fw7jJuEHp6GO13Chzd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4ZVuK", (CX::Int64)sbt_4ZVuK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5VE", (CX::Int64)sbt_5VE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.begin(); iter != sbt_30gxHhL88QrPJ9M8LUjOXxC9Hi6rbZe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.begin(); iter != sbt_F4XsZgVhkUEcNQ5ZNVq5sco68OJvaFUKVm6WAQR37jsusxHnrKdE_3R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p0f_Al_hWAGww9D4X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_p0f_Al_hWAGww9D4X.begin(); iter != sbt_p0f_Al_hWAGww9D4X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr", sbt_Qdz30jPE2duhXSjJEUPOhHODUcUrHNNAYFLM5X1rGlqPNIr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.begin(); iter != sbt_0bhiOhTsCyO9tSG97js7MVpKZxAVUkFKNl1c9MDrN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt", (CX::Int64)sbt_NRFOyTI7iDmssDQfdTmX4mw8t5moYNnk0yYjPE582xPWR5RvdOmMt)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_sJasUxO9i7amfCZprSmGy30>::Type sbt_sJasUxO9i7amfCZprSmGy30Array;

