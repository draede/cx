
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2.hpp"


class sbt_l7KvLKCNYC5 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_6H7j5xaRiGp;
	CX::UInt8 sbt_T;
	CX::WString sbt_d_AdvODmpSN4e2fgxq8;
	CX::IO::SimpleBuffers::Int8Array sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39;
	CX::UInt64 sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC;
	CX::IO::SimpleBuffers::Int8Array sbt_zKRznscDNxvKT;
	CX::Bool sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75;
	CX::IO::SimpleBuffers::UInt64Array sbt_cXnca;
	CX::IO::SimpleBuffers::FloatArray sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT;
	CX::UInt16 sbt_7;
	sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2Array sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy;

	virtual void Reset()
	{
		sbt_6H7j5xaRiGp = 0;
		sbt_T = 0;
		sbt_d_AdvODmpSN4e2fgxq8.clear();
		sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.clear();
		sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC = 0;
		sbt_zKRznscDNxvKT.clear();
		sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75 = false;
		sbt_cXnca.clear();
		sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.clear();
		sbt_7 = 0;
		sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_6H7j5xaRiGp = -744154372;
		sbt_T = 47;
		sbt_d_AdvODmpSN4e2fgxq8 = L"%9o[36k4pOXM{}.gF<cAb_1*\"A<{#PqB>3|QWU,[)Hqj6~F}E,^7AIK";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.push_back(83);
		}
		sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC = 394336483168034338;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_zKRznscDNxvKT.push_back(80);
		}
		sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75 = false;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_cXnca.push_back(8480210690351084108);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.push_back(0.322064f);
		}
		sbt_7 = 4641;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 v;

			v.SetupWithSomeValues();
			sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_l7KvLKCNYC5 *pObject = dynamic_cast<const sbt_l7KvLKCNYC5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_6H7j5xaRiGp != pObject->sbt_6H7j5xaRiGp)
		{
			return false;
		}
		if (sbt_T != pObject->sbt_T)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_d_AdvODmpSN4e2fgxq8.c_str(), pObject->sbt_d_AdvODmpSN4e2fgxq8.c_str()))
		{
			return false;
		}
		if (sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.size() != pObject->sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.size(); i++)
		{
			if (sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39[i] != pObject->sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39[i])
			{
				return false;
			}
		}
		if (sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC != pObject->sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC)
		{
			return false;
		}
		if (sbt_zKRznscDNxvKT.size() != pObject->sbt_zKRznscDNxvKT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zKRznscDNxvKT.size(); i++)
		{
			if (sbt_zKRznscDNxvKT[i] != pObject->sbt_zKRznscDNxvKT[i])
			{
				return false;
			}
		}
		if (sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75 != pObject->sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75)
		{
			return false;
		}
		if (sbt_cXnca.size() != pObject->sbt_cXnca.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cXnca.size(); i++)
		{
			if (sbt_cXnca[i] != pObject->sbt_cXnca[i])
			{
				return false;
			}
		}
		if (sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.size() != pObject->sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.size(); i++)
		{
			if (sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT[i] != pObject->sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT[i])
			{
				return false;
			}
		}
		if (sbt_7 != pObject->sbt_7)
		{
			return false;
		}
		if (sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.size() != pObject->sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.size(); i++)
		{
			if (!sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy[i].Compare(&pObject->sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_6H7j5xaRiGp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6H7j5xaRiGp = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_d_AdvODmpSN4e2fgxq8", &sbt_d_AdvODmpSN4e2fgxq8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zKRznscDNxvKT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zKRznscDNxvKT.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75", &sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cXnca")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cXnca.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_6H7j5xaRiGp", (CX::Int64)sbt_6H7j5xaRiGp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T", (CX::Int64)sbt_T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_d_AdvODmpSN4e2fgxq8", sbt_d_AdvODmpSN4e2fgxq8.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.begin(); iter != sbt_n8B_LU8FmIOS_PzuyugSMUaVKsA_2P_RY27fm6PfdKQ3N7zwQw42i39.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC", (CX::Int64)sbt_rdjdM3PIDOHiS49HWLyBb1qgcD9JC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zKRznscDNxvKT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_zKRznscDNxvKT.begin(); iter != sbt_zKRznscDNxvKT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75", sbt_T9lRAEnZBZR08JbrxOq8SezTMd4EQ8U75)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cXnca")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_cXnca.begin(); iter != sbt_cXnca.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.begin(); iter != sbt_JUktKaSmtKHCU65gjVnRo8Rac8ggg_TFT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7", (CX::Int64)sbt_7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy")).IsNOK())
		{
			return status;
		}
		for (sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2Array::const_iterator iter = sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.begin(); iter != sbt_L7agFIY5E74MlM787xoCMX5xV67Xrsffy.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_l7KvLKCNYC5>::Type sbt_l7KvLKCNYC5Array;

