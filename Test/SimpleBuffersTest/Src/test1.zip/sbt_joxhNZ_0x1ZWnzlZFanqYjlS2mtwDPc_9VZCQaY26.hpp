
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V.hpp"


class sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_FWxEZPa;
	CX::IO::SimpleBuffers::DoubleArray sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG;
	CX::Double sbt_UfMV6;
	CX::IO::SimpleBuffers::UInt16Array sbt_0;
	CX::UInt32 sbt_oNi3zIAh51syIJthRQs;
	CX::IO::SimpleBuffers::UInt16Array sbt_5ol7lAs_dBf8Kcf_ZcI9VFD;
	CX::IO::SimpleBuffers::UInt64Array sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY;
	CX::Int32 sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV;
	CX::IO::SimpleBuffers::UInt16Array sbt_vkwNbbbETfu;
	CX::IO::SimpleBuffers::Int64Array sbt_kszeI1WdRUySgHncMWxXB4m;
	CX::UInt8 sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ;
	CX::IO::SimpleBuffers::UInt64Array sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml;
	CX::Int8 sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm;
	CX::IO::SimpleBuffers::FloatArray sbt_xK9WIV8FFTJuk14bC;
	CX::Bool sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA;
	CX::WString sbt_m8FrFf9uJMwXiCY6ww_zmFixE;
	CX::Int16 sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk;
	CX::Int16 sbt_5;
	CX::IO::SimpleBuffers::DoubleArray sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s;
	sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D;

	virtual void Reset()
	{
		sbt_FWxEZPa.clear();
		sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.clear();
		sbt_UfMV6 = 0.0;
		sbt_0.clear();
		sbt_oNi3zIAh51syIJthRQs = 0;
		sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.clear();
		sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.clear();
		sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV = 0;
		sbt_vkwNbbbETfu.clear();
		sbt_kszeI1WdRUySgHncMWxXB4m.clear();
		sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ = 0;
		sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.clear();
		sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm = 0;
		sbt_xK9WIV8FFTJuk14bC.clear();
		sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA = false;
		sbt_m8FrFf9uJMwXiCY6ww_zmFixE.clear();
		sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk = 0;
		sbt_5 = 0;
		sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.clear();
		sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_FWxEZPa = "_.d4_iq(Xciqx3R'?z)<-=EtLf^k7tiqQ7oZ\\^@nu1?3c=kfru\\jo-{+Z1Q";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.push_back(0.477393);
		}
		sbt_UfMV6 = 0.119136;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_0.push_back(12589);
		}
		sbt_oNi3zIAh51syIJthRQs = 1506462132;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.push_back(65255);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.push_back(11852041608673509658);
		}
		sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV = 581707414;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_vkwNbbbETfu.push_back(33302);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_kszeI1WdRUySgHncMWxXB4m.push_back(5786263051660394288);
		}
		sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ = 246;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.push_back(12865653303530628308);
		}
		sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm = -77;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_xK9WIV8FFTJuk14bC.push_back(0.545114f);
		}
		sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA = true;
		sbt_m8FrFf9uJMwXiCY6ww_zmFixE = L"Vrt{g_yQw=2w!";
		sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk = 255;
		sbt_5 = -1234;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.push_back(0.532986);
		}
		sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26 *pObject = dynamic_cast<const sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_FWxEZPa.c_str(), pObject->sbt_FWxEZPa.c_str()))
		{
			return false;
		}
		if (sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.size() != pObject->sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.size(); i++)
		{
			if (sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG[i] != pObject->sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG[i])
			{
				return false;
			}
		}
		if (sbt_UfMV6 != pObject->sbt_UfMV6)
		{
			return false;
		}
		if (sbt_0.size() != pObject->sbt_0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0.size(); i++)
		{
			if (sbt_0[i] != pObject->sbt_0[i])
			{
				return false;
			}
		}
		if (sbt_oNi3zIAh51syIJthRQs != pObject->sbt_oNi3zIAh51syIJthRQs)
		{
			return false;
		}
		if (sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.size() != pObject->sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.size(); i++)
		{
			if (sbt_5ol7lAs_dBf8Kcf_ZcI9VFD[i] != pObject->sbt_5ol7lAs_dBf8Kcf_ZcI9VFD[i])
			{
				return false;
			}
		}
		if (sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.size() != pObject->sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.size(); i++)
		{
			if (sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY[i] != pObject->sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY[i])
			{
				return false;
			}
		}
		if (sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV != pObject->sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV)
		{
			return false;
		}
		if (sbt_vkwNbbbETfu.size() != pObject->sbt_vkwNbbbETfu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vkwNbbbETfu.size(); i++)
		{
			if (sbt_vkwNbbbETfu[i] != pObject->sbt_vkwNbbbETfu[i])
			{
				return false;
			}
		}
		if (sbt_kszeI1WdRUySgHncMWxXB4m.size() != pObject->sbt_kszeI1WdRUySgHncMWxXB4m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kszeI1WdRUySgHncMWxXB4m.size(); i++)
		{
			if (sbt_kszeI1WdRUySgHncMWxXB4m[i] != pObject->sbt_kszeI1WdRUySgHncMWxXB4m[i])
			{
				return false;
			}
		}
		if (sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ != pObject->sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ)
		{
			return false;
		}
		if (sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.size() != pObject->sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.size(); i++)
		{
			if (sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml[i] != pObject->sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml[i])
			{
				return false;
			}
		}
		if (sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm != pObject->sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm)
		{
			return false;
		}
		if (sbt_xK9WIV8FFTJuk14bC.size() != pObject->sbt_xK9WIV8FFTJuk14bC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xK9WIV8FFTJuk14bC.size(); i++)
		{
			if (sbt_xK9WIV8FFTJuk14bC[i] != pObject->sbt_xK9WIV8FFTJuk14bC[i])
			{
				return false;
			}
		}
		if (sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA != pObject->sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_m8FrFf9uJMwXiCY6ww_zmFixE.c_str(), pObject->sbt_m8FrFf9uJMwXiCY6ww_zmFixE.c_str()))
		{
			return false;
		}
		if (sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk != pObject->sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk)
		{
			return false;
		}
		if (sbt_5 != pObject->sbt_5)
		{
			return false;
		}
		if (sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.size() != pObject->sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.size(); i++)
		{
			if (sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s[i] != pObject->sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s[i])
			{
				return false;
			}
		}
		if (!sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D.Compare(&pObject->sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_FWxEZPa", &sbt_FWxEZPa)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_UfMV6", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_UfMV6 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oNi3zIAh51syIJthRQs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oNi3zIAh51syIJthRQs = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5ol7lAs_dBf8Kcf_ZcI9VFD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vkwNbbbETfu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vkwNbbbETfu.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kszeI1WdRUySgHncMWxXB4m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kszeI1WdRUySgHncMWxXB4m.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xK9WIV8FFTJuk14bC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xK9WIV8FFTJuk14bC.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA", &sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_m8FrFf9uJMwXiCY6ww_zmFixE", &sbt_m8FrFf9uJMwXiCY6ww_zmFixE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_FWxEZPa", sbt_FWxEZPa.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.begin(); iter != sbt_uSVix1eywWlulqtw2qrlsFIBwFYZ_YPxERgvHTNBC52WIt1kgonBTzwWBpG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_UfMV6", (CX::Double)sbt_UfMV6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_0.begin(); iter != sbt_0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oNi3zIAh51syIJthRQs", (CX::Int64)sbt_oNi3zIAh51syIJthRQs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5ol7lAs_dBf8Kcf_ZcI9VFD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.begin(); iter != sbt_5ol7lAs_dBf8Kcf_ZcI9VFD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.begin(); iter != sbt__97P8RZ7mWVnFCmTF64nUpnPiDr0OVY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV", (CX::Int64)sbt_DR_rpJ92FG35QkykWLZ_oG08zj8sFOwUn6LFFAAUSqNzDSEwj91K9yDZg9oUV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vkwNbbbETfu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_vkwNbbbETfu.begin(); iter != sbt_vkwNbbbETfu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kszeI1WdRUySgHncMWxXB4m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_kszeI1WdRUySgHncMWxXB4m.begin(); iter != sbt_kszeI1WdRUySgHncMWxXB4m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ", (CX::Int64)sbt_OwFkUXpwT8tWkSVMCzJT7dMWqydn_TyTaFxlkgdNBNSnATHfzYJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.begin(); iter != sbt_riZ94lgL6DM6wlluU5aJG2yziVzhKJmml.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm", (CX::Int64)sbt_wYbxFIPXXIXKrF5ADf3FkqiqnIC_RiqlMtFoOSuJvQrwh7bTsQMRPmYspZNQm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xK9WIV8FFTJuk14bC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_xK9WIV8FFTJuk14bC.begin(); iter != sbt_xK9WIV8FFTJuk14bC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA", sbt__dvK901bk4a5esKaGdlcyqDuKXLTjG2bUXRfYnNg4hk2JoiY_E50I8CVA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_m8FrFf9uJMwXiCY6ww_zmFixE", sbt_m8FrFf9uJMwXiCY6ww_zmFixE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk", (CX::Int64)sbt_vWGxfHPSRPfXxGa5OvJRhuHaMjkNpjk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5", (CX::Int64)sbt_5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.begin(); iter != sbt_sW2E6Fb3HAyPfl3nx2uIADI8_NJmcgwIMoQaB_C660KfP4s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_yu5mlHyGDX_m6MQck3oJV1jGdipKzHOa24D.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26>::Type sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26Array;

