
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_B_DiPRSc3DU.hpp"


class sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo;
	CX::IO::SimpleBuffers::Int16Array sbt_sm7F3MyXm9KkrwsFi;
	CX::Int32 sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC;
	CX::UInt32 sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5;
	CX::Bool sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul;
	CX::IO::SimpleBuffers::UInt8Array sbt_lanRImxaehr;
	CX::IO::SimpleBuffers::Int8Array sbt_TTRQskD4sLb2qB7XJfR;
	CX::Float sbt_bvLQjXiYrHw;
	CX::IO::SimpleBuffers::Int64Array sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9;
	CX::Int32 sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp;
	CX::UInt16 sbt_LXGnKGtd7etGNoktlTu6I;
	CX::IO::SimpleBuffers::UInt64Array sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01;
	CX::Int8 sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY;
	CX::Int16 sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ;
	CX::IO::SimpleBuffers::FloatArray sbt_7yywRGMpnamQ_qcR4Z3F4;
	CX::Int64 sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K;
	CX::Double sbt_fTfmrpOLF1yI3I6;
	CX::IO::SimpleBuffers::UInt32Array sbt_3Jk_0;
	CX::IO::SimpleBuffers::StringArray sbt_fZ4;
	sbt_B_DiPRSc3DUArray sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw;

	virtual void Reset()
	{
		sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.clear();
		sbt_sm7F3MyXm9KkrwsFi.clear();
		sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC = 0;
		sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5 = 0;
		sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul = false;
		sbt_lanRImxaehr.clear();
		sbt_TTRQskD4sLb2qB7XJfR.clear();
		sbt_bvLQjXiYrHw = 0.0f;
		sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.clear();
		sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp = 0;
		sbt_LXGnKGtd7etGNoktlTu6I = 0;
		sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.clear();
		sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY = 0;
		sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ = 0;
		sbt_7yywRGMpnamQ_qcR4Z3F4.clear();
		sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K = 0;
		sbt_fTfmrpOLF1yI3I6 = 0.0;
		sbt_3Jk_0.clear();
		sbt_fZ4.clear();
		sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.push_back(L"7=21Sc$B$yjEe>");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_sm7F3MyXm9KkrwsFi.push_back(-31908);
		}
		sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC = 467399319;
		sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5 = 1754861591;
		sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul = true;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_lanRImxaehr.push_back(105);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_TTRQskD4sLb2qB7XJfR.push_back(64);
		}
		sbt_bvLQjXiYrHw = 0.138332f;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.push_back(6603143053694759846);
		}
		sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp = 778948464;
		sbt_LXGnKGtd7etGNoktlTu6I = 47753;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.push_back(4071456798084285852);
		}
		sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY = 67;
		sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ = 3594;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_7yywRGMpnamQ_qcR4Z3F4.push_back(0.264908f);
		}
		sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K = -5195696041941648456;
		sbt_fTfmrpOLF1yI3I6 = 0.260885;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_3Jk_0.push_back(3983925117);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_fZ4.push_back("q`{7^ED3h;B|hqAg!lN%S|=@/M;^8I|W:k]CM3aF8OkxE@wd$/>W`=eE");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_B_DiPRSc3DU v;

			v.SetupWithSomeValues();
			sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO *pObject = dynamic_cast<const sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.size() != pObject->sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo[i].c_str(), pObject->sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_sm7F3MyXm9KkrwsFi.size() != pObject->sbt_sm7F3MyXm9KkrwsFi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sm7F3MyXm9KkrwsFi.size(); i++)
		{
			if (sbt_sm7F3MyXm9KkrwsFi[i] != pObject->sbt_sm7F3MyXm9KkrwsFi[i])
			{
				return false;
			}
		}
		if (sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC != pObject->sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC)
		{
			return false;
		}
		if (sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5 != pObject->sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5)
		{
			return false;
		}
		if (sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul != pObject->sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul)
		{
			return false;
		}
		if (sbt_lanRImxaehr.size() != pObject->sbt_lanRImxaehr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lanRImxaehr.size(); i++)
		{
			if (sbt_lanRImxaehr[i] != pObject->sbt_lanRImxaehr[i])
			{
				return false;
			}
		}
		if (sbt_TTRQskD4sLb2qB7XJfR.size() != pObject->sbt_TTRQskD4sLb2qB7XJfR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TTRQskD4sLb2qB7XJfR.size(); i++)
		{
			if (sbt_TTRQskD4sLb2qB7XJfR[i] != pObject->sbt_TTRQskD4sLb2qB7XJfR[i])
			{
				return false;
			}
		}
		if (sbt_bvLQjXiYrHw != pObject->sbt_bvLQjXiYrHw)
		{
			return false;
		}
		if (sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.size() != pObject->sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.size(); i++)
		{
			if (sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9[i] != pObject->sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9[i])
			{
				return false;
			}
		}
		if (sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp != pObject->sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp)
		{
			return false;
		}
		if (sbt_LXGnKGtd7etGNoktlTu6I != pObject->sbt_LXGnKGtd7etGNoktlTu6I)
		{
			return false;
		}
		if (sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.size() != pObject->sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.size(); i++)
		{
			if (sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01[i] != pObject->sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01[i])
			{
				return false;
			}
		}
		if (sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY != pObject->sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY)
		{
			return false;
		}
		if (sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ != pObject->sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ)
		{
			return false;
		}
		if (sbt_7yywRGMpnamQ_qcR4Z3F4.size() != pObject->sbt_7yywRGMpnamQ_qcR4Z3F4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7yywRGMpnamQ_qcR4Z3F4.size(); i++)
		{
			if (sbt_7yywRGMpnamQ_qcR4Z3F4[i] != pObject->sbt_7yywRGMpnamQ_qcR4Z3F4[i])
			{
				return false;
			}
		}
		if (sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K != pObject->sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K)
		{
			return false;
		}
		if (sbt_fTfmrpOLF1yI3I6 != pObject->sbt_fTfmrpOLF1yI3I6)
		{
			return false;
		}
		if (sbt_3Jk_0.size() != pObject->sbt_3Jk_0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3Jk_0.size(); i++)
		{
			if (sbt_3Jk_0[i] != pObject->sbt_3Jk_0[i])
			{
				return false;
			}
		}
		if (sbt_fZ4.size() != pObject->sbt_fZ4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fZ4.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fZ4[i].c_str(), pObject->sbt_fZ4[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.size() != pObject->sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.size(); i++)
		{
			if (!sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw[i].Compare(&pObject->sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sm7F3MyXm9KkrwsFi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sm7F3MyXm9KkrwsFi.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul", &sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lanRImxaehr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lanRImxaehr.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TTRQskD4sLb2qB7XJfR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TTRQskD4sLb2qB7XJfR.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_bvLQjXiYrHw", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_bvLQjXiYrHw = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LXGnKGtd7etGNoktlTu6I", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LXGnKGtd7etGNoktlTu6I = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7yywRGMpnamQ_qcR4Z3F4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7yywRGMpnamQ_qcR4Z3F4.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_fTfmrpOLF1yI3I6", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fTfmrpOLF1yI3I6 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_3Jk_0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3Jk_0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fZ4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fZ4.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_B_DiPRSc3DU tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.begin(); iter != sbt_ixr_cxEuJSmnxoIGPBwM_SSBzhCNo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sm7F3MyXm9KkrwsFi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_sm7F3MyXm9KkrwsFi.begin(); iter != sbt_sm7F3MyXm9KkrwsFi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC", (CX::Int64)sbt_wFyanyCtmDAWroaGRh9w3VmDEE4X4kPlaR1iKG1qft1zMjrhBoYPzHVpC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5", (CX::Int64)sbt_lMiBmBdqtUi0AJaoW1EV2Qz0jRK3T5lMOklaKZtJ8gODYwqMZ472_q8fn3wdPG5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul", sbt_d6zNELKxYED08r7D1YrSVAYHjDJcZ04TWt5lCo_k8M2e0RFL2CV7JwQcBaQul)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lanRImxaehr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_lanRImxaehr.begin(); iter != sbt_lanRImxaehr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TTRQskD4sLb2qB7XJfR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_TTRQskD4sLb2qB7XJfR.begin(); iter != sbt_TTRQskD4sLb2qB7XJfR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_bvLQjXiYrHw", (CX::Double)sbt_bvLQjXiYrHw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.begin(); iter != sbt_djHNKAZnAUynR6tRrK9sq4okRMTrgAGD9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp", (CX::Int64)sbt_rPFcsHrxsWSmucmUpQQKFSJdeAYGmDJQldQlKoXGCgTUp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LXGnKGtd7etGNoktlTu6I", (CX::Int64)sbt_LXGnKGtd7etGNoktlTu6I)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.begin(); iter != sbt_BFfVYgzPi__Qv0VXVMnyjGY82MY01.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY", (CX::Int64)sbt_wxHtFPRbR57MyIFRbOs2FuxSWHY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ", (CX::Int64)sbt_zVpSRFvNReQIZx7asbQofzV4CengYSyNtUmTJsbBQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7yywRGMpnamQ_qcR4Z3F4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_7yywRGMpnamQ_qcR4Z3F4.begin(); iter != sbt_7yywRGMpnamQ_qcR4Z3F4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K", (CX::Int64)sbt_qrspmY1bHVM_ZsJNj0VmjI4n8PTxk8l8cUHUlno9K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fTfmrpOLF1yI3I6", (CX::Double)sbt_fTfmrpOLF1yI3I6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3Jk_0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_3Jk_0.begin(); iter != sbt_3Jk_0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fZ4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fZ4.begin(); iter != sbt_fZ4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw")).IsNOK())
		{
			return status;
		}
		for (sbt_B_DiPRSc3DUArray::const_iterator iter = sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.begin(); iter != sbt_xvKVMChsS2jZb9u66YHFtyIXW0nHf4Gg63g6qKvCwUw.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO>::Type sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvOArray;

