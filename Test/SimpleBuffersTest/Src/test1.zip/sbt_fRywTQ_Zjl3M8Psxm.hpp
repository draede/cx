
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_chS2XwPcNdHG4.hpp"


class sbt_fRywTQ_Zjl3M8Psxm : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg;
	CX::IO::SimpleBuffers::DoubleArray sbt_hliwL;
	CX::UInt16 sbt_zVv89Bg;
	CX::Int64 sbt_r_TjR;
	CX::IO::SimpleBuffers::UInt64Array sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI;
	CX::Float sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z;
	CX::IO::SimpleBuffers::Int32Array sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y;
	CX::Int64 sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4;
	CX::IO::SimpleBuffers::UInt8Array sbt_LeA5TMXEZWh9CJY;
	CX::UInt32 sbt_KuaIdVy0DOR3xAiLN;
	CX::IO::SimpleBuffers::UInt8Array sbt_Q0B_uMU_DSOAD;
	CX::IO::SimpleBuffers::Int8Array sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU;
	CX::Bool sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g;
	CX::IO::SimpleBuffers::FloatArray sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0;
	CX::String sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H;
	CX::Int64 sbt_YSupYHWOXBssR;
	CX::IO::SimpleBuffers::Int64Array sbt_pEJ0YPDuJYAFVKRexMUS_ER;
	CX::String sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz;
	CX::IO::SimpleBuffers::UInt32Array sbt_6oFYrznFkvD5RaEAl;
	CX::Float sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc;
	CX::IO::SimpleBuffers::UInt64Array sbt_DG7QQmFaMCX;
	CX::Int16 sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC;
	CX::Int16 sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI;
	CX::Int8 sbt_u3Vg6ZOyWHw4HF_;
	CX::IO::SimpleBuffers::UInt64Array sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q;
	CX::Int16 sbt__4o9zXX7Ywpkk1ByiAD0OhK;
	sbt_chS2XwPcNdHG4 sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs;

	virtual void Reset()
	{
		sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.clear();
		sbt_hliwL.clear();
		sbt_zVv89Bg = 0;
		sbt_r_TjR = 0;
		sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.clear();
		sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z = 0.0f;
		sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.clear();
		sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4 = 0;
		sbt_LeA5TMXEZWh9CJY.clear();
		sbt_KuaIdVy0DOR3xAiLN = 0;
		sbt_Q0B_uMU_DSOAD.clear();
		sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.clear();
		sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g = false;
		sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.clear();
		sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H.clear();
		sbt_YSupYHWOXBssR = 0;
		sbt_pEJ0YPDuJYAFVKRexMUS_ER.clear();
		sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz.clear();
		sbt_6oFYrznFkvD5RaEAl.clear();
		sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc = 0.0f;
		sbt_DG7QQmFaMCX.clear();
		sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC = 0;
		sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI = 0;
		sbt_u3Vg6ZOyWHw4HF_ = 0;
		sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.clear();
		sbt__4o9zXX7Ywpkk1ByiAD0OhK = 0;
		sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.push_back(58);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_hliwL.push_back(0.677681);
		}
		sbt_zVv89Bg = 60186;
		sbt_r_TjR = 400420110748403806;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.push_back(9856192577774455984);
		}
		sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z = 0.700036f;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.push_back(-1217302526);
		}
		sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4 = -4225604140826026176;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LeA5TMXEZWh9CJY.push_back(234);
		}
		sbt_KuaIdVy0DOR3xAiLN = 4178769790;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Q0B_uMU_DSOAD.push_back(84);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.push_back(-68);
		}
		sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.push_back(0.745048f);
		}
		sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H = "3gDN;xK;z?8$YJNb6^_eF'?}/(@}bK+Era\\IIG[;7\\`3!@N/^bQSkkbx]uByqg!";
		sbt_YSupYHWOXBssR = -6291477469742505742;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_pEJ0YPDuJYAFVKRexMUS_ER.push_back(-5322647278405325942);
		}
		sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz = "[}";
		sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc = 0.289796f;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_DG7QQmFaMCX.push_back(3867743016365456814);
		}
		sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC = -21141;
		sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI = -32256;
		sbt_u3Vg6ZOyWHw4HF_ = 102;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.push_back(14979960330394977536);
		}
		sbt__4o9zXX7Ywpkk1ByiAD0OhK = 13355;
		sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_fRywTQ_Zjl3M8Psxm *pObject = dynamic_cast<const sbt_fRywTQ_Zjl3M8Psxm *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.size() != pObject->sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.size(); i++)
		{
			if (sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg[i] != pObject->sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg[i])
			{
				return false;
			}
		}
		if (sbt_hliwL.size() != pObject->sbt_hliwL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hliwL.size(); i++)
		{
			if (sbt_hliwL[i] != pObject->sbt_hliwL[i])
			{
				return false;
			}
		}
		if (sbt_zVv89Bg != pObject->sbt_zVv89Bg)
		{
			return false;
		}
		if (sbt_r_TjR != pObject->sbt_r_TjR)
		{
			return false;
		}
		if (sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.size() != pObject->sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.size(); i++)
		{
			if (sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI[i] != pObject->sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI[i])
			{
				return false;
			}
		}
		if (sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z != pObject->sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z)
		{
			return false;
		}
		if (sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.size() != pObject->sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.size(); i++)
		{
			if (sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y[i] != pObject->sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y[i])
			{
				return false;
			}
		}
		if (sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4 != pObject->sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4)
		{
			return false;
		}
		if (sbt_LeA5TMXEZWh9CJY.size() != pObject->sbt_LeA5TMXEZWh9CJY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LeA5TMXEZWh9CJY.size(); i++)
		{
			if (sbt_LeA5TMXEZWh9CJY[i] != pObject->sbt_LeA5TMXEZWh9CJY[i])
			{
				return false;
			}
		}
		if (sbt_KuaIdVy0DOR3xAiLN != pObject->sbt_KuaIdVy0DOR3xAiLN)
		{
			return false;
		}
		if (sbt_Q0B_uMU_DSOAD.size() != pObject->sbt_Q0B_uMU_DSOAD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q0B_uMU_DSOAD.size(); i++)
		{
			if (sbt_Q0B_uMU_DSOAD[i] != pObject->sbt_Q0B_uMU_DSOAD[i])
			{
				return false;
			}
		}
		if (sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.size() != pObject->sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.size(); i++)
		{
			if (sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU[i] != pObject->sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU[i])
			{
				return false;
			}
		}
		if (sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g != pObject->sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g)
		{
			return false;
		}
		if (sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.size() != pObject->sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.size(); i++)
		{
			if (sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0[i] != pObject->sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H.c_str(), pObject->sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H.c_str()))
		{
			return false;
		}
		if (sbt_YSupYHWOXBssR != pObject->sbt_YSupYHWOXBssR)
		{
			return false;
		}
		if (sbt_pEJ0YPDuJYAFVKRexMUS_ER.size() != pObject->sbt_pEJ0YPDuJYAFVKRexMUS_ER.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pEJ0YPDuJYAFVKRexMUS_ER.size(); i++)
		{
			if (sbt_pEJ0YPDuJYAFVKRexMUS_ER[i] != pObject->sbt_pEJ0YPDuJYAFVKRexMUS_ER[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz.c_str(), pObject->sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz.c_str()))
		{
			return false;
		}
		if (sbt_6oFYrznFkvD5RaEAl.size() != pObject->sbt_6oFYrznFkvD5RaEAl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6oFYrznFkvD5RaEAl.size(); i++)
		{
			if (sbt_6oFYrznFkvD5RaEAl[i] != pObject->sbt_6oFYrznFkvD5RaEAl[i])
			{
				return false;
			}
		}
		if (sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc != pObject->sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc)
		{
			return false;
		}
		if (sbt_DG7QQmFaMCX.size() != pObject->sbt_DG7QQmFaMCX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DG7QQmFaMCX.size(); i++)
		{
			if (sbt_DG7QQmFaMCX[i] != pObject->sbt_DG7QQmFaMCX[i])
			{
				return false;
			}
		}
		if (sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC != pObject->sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC)
		{
			return false;
		}
		if (sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI != pObject->sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI)
		{
			return false;
		}
		if (sbt_u3Vg6ZOyWHw4HF_ != pObject->sbt_u3Vg6ZOyWHw4HF_)
		{
			return false;
		}
		if (sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.size() != pObject->sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.size(); i++)
		{
			if (sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q[i] != pObject->sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q[i])
			{
				return false;
			}
		}
		if (sbt__4o9zXX7Ywpkk1ByiAD0OhK != pObject->sbt__4o9zXX7Ywpkk1ByiAD0OhK)
		{
			return false;
		}
		if (!sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs.Compare(&pObject->sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hliwL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hliwL.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zVv89Bg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zVv89Bg = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_r_TjR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r_TjR = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LeA5TMXEZWh9CJY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LeA5TMXEZWh9CJY.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KuaIdVy0DOR3xAiLN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KuaIdVy0DOR3xAiLN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Q0B_uMU_DSOAD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q0B_uMU_DSOAD.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g", &sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H", &sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YSupYHWOXBssR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YSupYHWOXBssR = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pEJ0YPDuJYAFVKRexMUS_ER")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pEJ0YPDuJYAFVKRexMUS_ER.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz", &sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6oFYrznFkvD5RaEAl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6oFYrznFkvD5RaEAl.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_DG7QQmFaMCX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DG7QQmFaMCX.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_u3Vg6ZOyWHw4HF_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u3Vg6ZOyWHw4HF_ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__4o9zXX7Ywpkk1ByiAD0OhK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__4o9zXX7Ywpkk1ByiAD0OhK = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.begin(); iter != sbt_ln870NwMpNGWmTlNp20gS7FScrrYqOBAeJV_GqGrA3XANIZKxYZNzpg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hliwL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_hliwL.begin(); iter != sbt_hliwL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zVv89Bg", (CX::Int64)sbt_zVv89Bg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_r_TjR", (CX::Int64)sbt_r_TjR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.begin(); iter != sbt_awyrPYyqpsbz5EQDxQpooGncX05Ihhw3dWhEFhmWeyD4jWRBxrI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z", (CX::Double)sbt_dVwNZuigVavxNNfwaf8mWn54jYCb7xTCxpZmV6Gmp6VbSvO4LRa91XIFT9j2z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.begin(); iter != sbt_ndX0LRREPt_CX0IouJUuiXBhRWEYwgWRj4KR4dFa9bmtpt_ODKAV33BT50y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4", (CX::Int64)sbt_tzm1NnRoXeXjfx8ljWfPGuSRJJFZFSRfxqgAFF4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LeA5TMXEZWh9CJY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_LeA5TMXEZWh9CJY.begin(); iter != sbt_LeA5TMXEZWh9CJY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KuaIdVy0DOR3xAiLN", (CX::Int64)sbt_KuaIdVy0DOR3xAiLN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q0B_uMU_DSOAD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Q0B_uMU_DSOAD.begin(); iter != sbt_Q0B_uMU_DSOAD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.begin(); iter != sbt_CrQRM07jHM0kTNcukNZLqi8Wu657FtcJ7Grd7YhCvyoFU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g", sbt_8Tbky7UmtzEtm5gTsVMHp6Y_1gsqtN4PVgcWdhC6M707k_g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.begin(); iter != sbt_9IkIzc2cqaagLEQTiQfU2xXYWtGSMiZEnBBjspWA6hwf0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H", sbt_UkTeshjra1hp54jBSKYx9wHMzOqJYSMgARdXQkmUT6MCQU39H.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YSupYHWOXBssR", (CX::Int64)sbt_YSupYHWOXBssR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pEJ0YPDuJYAFVKRexMUS_ER")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_pEJ0YPDuJYAFVKRexMUS_ER.begin(); iter != sbt_pEJ0YPDuJYAFVKRexMUS_ER.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz", sbt_erx4z_pKy_dJZzIg_v1bocwGMi0VHqZxrDed2LVz8uLkGhZorReeJsA6vWz.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6oFYrznFkvD5RaEAl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_6oFYrznFkvD5RaEAl.begin(); iter != sbt_6oFYrznFkvD5RaEAl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc", (CX::Double)sbt_yoo3CDcxVkOFvzX3KsAwSkpvBY151O_N6HLGBezT0a6gc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DG7QQmFaMCX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_DG7QQmFaMCX.begin(); iter != sbt_DG7QQmFaMCX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC", (CX::Int64)sbt_YaWBw2C1f1Pw4FmPFNRSh77DFncxlZC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI", (CX::Int64)sbt_UKdDjSt2KZBosoLW1BWHqJY5ZLZwLtTFYz5JjguS_Ak8TLhcdNM8QnFmCwI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u3Vg6ZOyWHw4HF_", (CX::Int64)sbt_u3Vg6ZOyWHw4HF_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.begin(); iter != sbt_hWk0rJoUtBBjuJ8JdAyEIXNNYJ8Uu47YrvgkVSGWBR2Z3fuH5OKk40Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__4o9zXX7Ywpkk1ByiAD0OhK", (CX::Int64)sbt__4o9zXX7Ywpkk1ByiAD0OhK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_6yLSpID8PuwlJC6Gu3u9OxxBsnv3NZnwORMT9OD63mGJcS9iON8b1Rs.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_fRywTQ_Zjl3M8Psxm>::Type sbt_fRywTQ_Zjl3M8PsxmArray;

