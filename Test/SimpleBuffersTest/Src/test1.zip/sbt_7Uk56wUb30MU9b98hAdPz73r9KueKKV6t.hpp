
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_EhCciUPnsENSHQGekyQ;
	CX::UInt64 sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh;
	CX::Int32 sbt_vHolmf3mjTgtswKQRkGzF;
	CX::UInt16 sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2;
	CX::UInt32 sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH;

	virtual void Reset()
	{
		sbt_EhCciUPnsENSHQGekyQ.clear();
		sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh = 0;
		sbt_vHolmf3mjTgtswKQRkGzF = 0;
		sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2 = 0;
		sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh = 3562997515432832812;
		sbt_vHolmf3mjTgtswKQRkGzF = -1442673819;
		sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2 = 3524;
		sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH = 955451065;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t *pObject = dynamic_cast<const sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_EhCciUPnsENSHQGekyQ.size() != pObject->sbt_EhCciUPnsENSHQGekyQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EhCciUPnsENSHQGekyQ.size(); i++)
		{
			if (sbt_EhCciUPnsENSHQGekyQ[i] != pObject->sbt_EhCciUPnsENSHQGekyQ[i])
			{
				return false;
			}
		}
		if (sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh != pObject->sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh)
		{
			return false;
		}
		if (sbt_vHolmf3mjTgtswKQRkGzF != pObject->sbt_vHolmf3mjTgtswKQRkGzF)
		{
			return false;
		}
		if (sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2 != pObject->sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2)
		{
			return false;
		}
		if (sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH != pObject->sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_EhCciUPnsENSHQGekyQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EhCciUPnsENSHQGekyQ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_vHolmf3mjTgtswKQRkGzF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vHolmf3mjTgtswKQRkGzF = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_EhCciUPnsENSHQGekyQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_EhCciUPnsENSHQGekyQ.begin(); iter != sbt_EhCciUPnsENSHQGekyQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh", (CX::Int64)sbt_e9bSjsB584svmRz_GKugqRZDgAuyEBTme_IGk9RDpVbrh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vHolmf3mjTgtswKQRkGzF", (CX::Int64)sbt_vHolmf3mjTgtswKQRkGzF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2", (CX::Int64)sbt_SXSMstfjv690d14kKiCjAaeNN8KaYLZMwIdeqKCP2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH", (CX::Int64)sbt_qdLOWCiYGri0LZhFocxBTaeLAeoMSmjmz6pTSAzw2w_jF66hWRH)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t>::Type sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6tArray;

