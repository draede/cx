
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA;
	CX::UInt32 sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu;
	CX::IO::SimpleBuffers::UInt64Array sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD;
	CX::IO::SimpleBuffers::Int16Array sbt_tuibSsJhLyVUUcEU5;
	CX::IO::SimpleBuffers::UInt64Array sbt_h3KB_f8;
	CX::UInt16 sbt_6zf8Wgdrg6w;
	CX::UInt64 sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj;
	CX::Int8 sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp;
	CX::Int16 sbt_rLMe5_yWeQUFW;
	CX::UInt32 sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa;

	virtual void Reset()
	{
		sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA = 0;
		sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu = 0;
		sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.clear();
		sbt_tuibSsJhLyVUUcEU5.clear();
		sbt_h3KB_f8.clear();
		sbt_6zf8Wgdrg6w = 0;
		sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj = 0;
		sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp = 0;
		sbt_rLMe5_yWeQUFW = 0;
		sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA = 12650;
		sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu = 3171514560;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.push_back(1379089723436900868);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_tuibSsJhLyVUUcEU5.push_back(-3781);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_h3KB_f8.push_back(13869193631056563136);
		}
		sbt_6zf8Wgdrg6w = 38411;
		sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj = 995765721028951060;
		sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp = 5;
		sbt_rLMe5_yWeQUFW = -25397;
		sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa = 2496141138;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA *pObject = dynamic_cast<const sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA != pObject->sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA)
		{
			return false;
		}
		if (sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu != pObject->sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu)
		{
			return false;
		}
		if (sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.size() != pObject->sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.size(); i++)
		{
			if (sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD[i] != pObject->sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD[i])
			{
				return false;
			}
		}
		if (sbt_tuibSsJhLyVUUcEU5.size() != pObject->sbt_tuibSsJhLyVUUcEU5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tuibSsJhLyVUUcEU5.size(); i++)
		{
			if (sbt_tuibSsJhLyVUUcEU5[i] != pObject->sbt_tuibSsJhLyVUUcEU5[i])
			{
				return false;
			}
		}
		if (sbt_h3KB_f8.size() != pObject->sbt_h3KB_f8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h3KB_f8.size(); i++)
		{
			if (sbt_h3KB_f8[i] != pObject->sbt_h3KB_f8[i])
			{
				return false;
			}
		}
		if (sbt_6zf8Wgdrg6w != pObject->sbt_6zf8Wgdrg6w)
		{
			return false;
		}
		if (sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj != pObject->sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj)
		{
			return false;
		}
		if (sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp != pObject->sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp)
		{
			return false;
		}
		if (sbt_rLMe5_yWeQUFW != pObject->sbt_rLMe5_yWeQUFW)
		{
			return false;
		}
		if (sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa != pObject->sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tuibSsJhLyVUUcEU5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tuibSsJhLyVUUcEU5.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h3KB_f8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h3KB_f8.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6zf8Wgdrg6w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6zf8Wgdrg6w = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rLMe5_yWeQUFW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rLMe5_yWeQUFW = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA", (CX::Int64)sbt_ADmiOt4AmggGGAW3b8iVsLTAvpzeHAJTPhuDj5M8pwLLBfy_vGCaA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu", (CX::Int64)sbt_euzx8QDmyvDl_ZQACz2ghBMV4rSICWgbOQJOz7gSYcK5HpkaRPcFvfu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.begin(); iter != sbt_C6XWcXuBaJj5venlGM7GSOmAwPMFxB_U7KBgjS0qQZiOiOBZmbD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tuibSsJhLyVUUcEU5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_tuibSsJhLyVUUcEU5.begin(); iter != sbt_tuibSsJhLyVUUcEU5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h3KB_f8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_h3KB_f8.begin(); iter != sbt_h3KB_f8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6zf8Wgdrg6w", (CX::Int64)sbt_6zf8Wgdrg6w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj", (CX::Int64)sbt_PUVjOuPD1kJnJMkPhRHwAYIZsd9gcJ4ds1zRllOYgmj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp", (CX::Int64)sbt_LGdhKy3oarjbtqMu3GFh7Oa0QmTajH5oRmebp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rLMe5_yWeQUFW", (CX::Int64)sbt_rLMe5_yWeQUFW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa", (CX::Int64)sbt_NA0HoqCvdSUJbpZQHHJUfK7WLgbTx_OEIMnewyXPXC2q5YmyJ2BWrgMCa)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA>::Type sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WAArray;

