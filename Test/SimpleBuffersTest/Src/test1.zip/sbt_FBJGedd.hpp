
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_VNUKx.hpp"


class sbt_FBJGedd : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_pG78ZnXc4Svg0T9NTR327Mayy;
	sbt_VNUKx sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX;

	virtual void Reset()
	{
		sbt_pG78ZnXc4Svg0T9NTR327Mayy.clear();
		sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_pG78ZnXc4Svg0T9NTR327Mayy.push_back("CW`jUo*jpsVXR)A0+Q[P@>j[mcrU6$y`js0)gsvlv'ZZM,2?R5]xJ,kb7-_ev");
		}
		sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_FBJGedd *pObject = dynamic_cast<const sbt_FBJGedd *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_pG78ZnXc4Svg0T9NTR327Mayy.size() != pObject->sbt_pG78ZnXc4Svg0T9NTR327Mayy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pG78ZnXc4Svg0T9NTR327Mayy.size(); i++)
		{
			if (0 != cx_strcmp(sbt_pG78ZnXc4Svg0T9NTR327Mayy[i].c_str(), pObject->sbt_pG78ZnXc4Svg0T9NTR327Mayy[i].c_str()))
			{
				return false;
			}
		}
		if (!sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX.Compare(&pObject->sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_pG78ZnXc4Svg0T9NTR327Mayy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pG78ZnXc4Svg0T9NTR327Mayy.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_pG78ZnXc4Svg0T9NTR327Mayy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_pG78ZnXc4Svg0T9NTR327Mayy.begin(); iter != sbt_pG78ZnXc4Svg0T9NTR327Mayy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_9xZXs1fTirSBCzH2PRsuFU9RQoX.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_FBJGedd>::Type sbt_FBJGeddArray;

