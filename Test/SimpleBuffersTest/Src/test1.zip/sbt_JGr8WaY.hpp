
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_JGr8WaY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn;
	CX::Int16 sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq;
	CX::UInt64 sbt_6z0eXcU2vGa;
	CX::UInt16 sbt_f_iFUOLdet5lW;
	CX::UInt64 sbt_23tMG;
	CX::IO::SimpleBuffers::UInt64Array sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M;
	CX::IO::SimpleBuffers::Int32Array sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_;
	CX::String sbt_lNEJAIdP2nGJJTzQJ;
	CX::IO::SimpleBuffers::UInt8Array sbt_lJWxQ_cqsRBNVrkFM25;
	CX::Int64 sbt_qFnOut8eUpJlaxuFFFg;
	CX::String sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX;
	CX::String sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ;
	CX::UInt64 sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a;
	CX::IO::SimpleBuffers::BoolArray sbt_l4LbHexZYx6WrUOf0KiPnQ1;
	CX::Int8 sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO;
	CX::IO::SimpleBuffers::UInt8Array sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH;
	CX::IO::SimpleBuffers::Int16Array sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF;
	CX::Int64 sbt_jI9yzdcknaX;
	CX::IO::SimpleBuffers::BoolArray sbt_cMnx5WkBH39P0H8uA6Rg4;
	CX::IO::SimpleBuffers::UInt16Array sbt_S6KQamGF0;
	CX::IO::SimpleBuffers::UInt32Array sbt_QIw32ryQ0pCTI;
	CX::Bool sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy;
	CX::UInt64 sbt__vVvr2qfMgrKj6id68B;
	CX::IO::SimpleBuffers::UInt8Array sbt_KCzaRHSDJSYT4Pptg;

	virtual void Reset()
	{
		sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.clear();
		sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq = 0;
		sbt_6z0eXcU2vGa = 0;
		sbt_f_iFUOLdet5lW = 0;
		sbt_23tMG = 0;
		sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.clear();
		sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.clear();
		sbt_lNEJAIdP2nGJJTzQJ.clear();
		sbt_lJWxQ_cqsRBNVrkFM25.clear();
		sbt_qFnOut8eUpJlaxuFFFg = 0;
		sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX.clear();
		sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ.clear();
		sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a = 0;
		sbt_l4LbHexZYx6WrUOf0KiPnQ1.clear();
		sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO = 0;
		sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.clear();
		sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.clear();
		sbt_jI9yzdcknaX = 0;
		sbt_cMnx5WkBH39P0H8uA6Rg4.clear();
		sbt_S6KQamGF0.clear();
		sbt_QIw32ryQ0pCTI.clear();
		sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy = false;
		sbt__vVvr2qfMgrKj6id68B = 0;
		sbt_KCzaRHSDJSYT4Pptg.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.push_back(true);
		}
		sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq = 26035;
		sbt_6z0eXcU2vGa = 13554103426398322474;
		sbt_f_iFUOLdet5lW = 601;
		sbt_23tMG = 16064056242297908656;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.push_back(3914227452681335232);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.push_back(-2113549989);
		}
		sbt_lNEJAIdP2nGJJTzQJ = "q0\\^d!g!,a-aOg9UT'@bl#_";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_lJWxQ_cqsRBNVrkFM25.push_back(25);
		}
		sbt_qFnOut8eUpJlaxuFFFg = -6362367295945992818;
		sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX = "Z9y&_`:CB";
		sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ = "(]8z>/;s'gsgOo*^>$Fy6k";
		sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a = 1483507277185265074;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_l4LbHexZYx6WrUOf0KiPnQ1.push_back(true);
		}
		sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO = -96;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.push_back(60);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.push_back(6318);
		}
		sbt_jI9yzdcknaX = 7526719076721784818;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_cMnx5WkBH39P0H8uA6Rg4.push_back(false);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_S6KQamGF0.push_back(52630);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_QIw32ryQ0pCTI.push_back(737201200);
		}
		sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy = true;
		sbt__vVvr2qfMgrKj6id68B = 4686323429543413036;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_KCzaRHSDJSYT4Pptg.push_back(207);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_JGr8WaY *pObject = dynamic_cast<const sbt_JGr8WaY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.size() != pObject->sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.size(); i++)
		{
			if (sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn[i] != pObject->sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn[i])
			{
				return false;
			}
		}
		if (sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq != pObject->sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq)
		{
			return false;
		}
		if (sbt_6z0eXcU2vGa != pObject->sbt_6z0eXcU2vGa)
		{
			return false;
		}
		if (sbt_f_iFUOLdet5lW != pObject->sbt_f_iFUOLdet5lW)
		{
			return false;
		}
		if (sbt_23tMG != pObject->sbt_23tMG)
		{
			return false;
		}
		if (sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.size() != pObject->sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.size(); i++)
		{
			if (sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M[i] != pObject->sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M[i])
			{
				return false;
			}
		}
		if (sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.size() != pObject->sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.size(); i++)
		{
			if (sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_[i] != pObject->sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_lNEJAIdP2nGJJTzQJ.c_str(), pObject->sbt_lNEJAIdP2nGJJTzQJ.c_str()))
		{
			return false;
		}
		if (sbt_lJWxQ_cqsRBNVrkFM25.size() != pObject->sbt_lJWxQ_cqsRBNVrkFM25.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lJWxQ_cqsRBNVrkFM25.size(); i++)
		{
			if (sbt_lJWxQ_cqsRBNVrkFM25[i] != pObject->sbt_lJWxQ_cqsRBNVrkFM25[i])
			{
				return false;
			}
		}
		if (sbt_qFnOut8eUpJlaxuFFFg != pObject->sbt_qFnOut8eUpJlaxuFFFg)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX.c_str(), pObject->sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ.c_str(), pObject->sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ.c_str()))
		{
			return false;
		}
		if (sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a != pObject->sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a)
		{
			return false;
		}
		if (sbt_l4LbHexZYx6WrUOf0KiPnQ1.size() != pObject->sbt_l4LbHexZYx6WrUOf0KiPnQ1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l4LbHexZYx6WrUOf0KiPnQ1.size(); i++)
		{
			if (sbt_l4LbHexZYx6WrUOf0KiPnQ1[i] != pObject->sbt_l4LbHexZYx6WrUOf0KiPnQ1[i])
			{
				return false;
			}
		}
		if (sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO != pObject->sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO)
		{
			return false;
		}
		if (sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.size() != pObject->sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.size(); i++)
		{
			if (sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH[i] != pObject->sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH[i])
			{
				return false;
			}
		}
		if (sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.size() != pObject->sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.size(); i++)
		{
			if (sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF[i] != pObject->sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF[i])
			{
				return false;
			}
		}
		if (sbt_jI9yzdcknaX != pObject->sbt_jI9yzdcknaX)
		{
			return false;
		}
		if (sbt_cMnx5WkBH39P0H8uA6Rg4.size() != pObject->sbt_cMnx5WkBH39P0H8uA6Rg4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cMnx5WkBH39P0H8uA6Rg4.size(); i++)
		{
			if (sbt_cMnx5WkBH39P0H8uA6Rg4[i] != pObject->sbt_cMnx5WkBH39P0H8uA6Rg4[i])
			{
				return false;
			}
		}
		if (sbt_S6KQamGF0.size() != pObject->sbt_S6KQamGF0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S6KQamGF0.size(); i++)
		{
			if (sbt_S6KQamGF0[i] != pObject->sbt_S6KQamGF0[i])
			{
				return false;
			}
		}
		if (sbt_QIw32ryQ0pCTI.size() != pObject->sbt_QIw32ryQ0pCTI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QIw32ryQ0pCTI.size(); i++)
		{
			if (sbt_QIw32ryQ0pCTI[i] != pObject->sbt_QIw32ryQ0pCTI[i])
			{
				return false;
			}
		}
		if (sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy != pObject->sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy)
		{
			return false;
		}
		if (sbt__vVvr2qfMgrKj6id68B != pObject->sbt__vVvr2qfMgrKj6id68B)
		{
			return false;
		}
		if (sbt_KCzaRHSDJSYT4Pptg.size() != pObject->sbt_KCzaRHSDJSYT4Pptg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KCzaRHSDJSYT4Pptg.size(); i++)
		{
			if (sbt_KCzaRHSDJSYT4Pptg[i] != pObject->sbt_KCzaRHSDJSYT4Pptg[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_6z0eXcU2vGa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6z0eXcU2vGa = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_f_iFUOLdet5lW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_f_iFUOLdet5lW = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_23tMG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_23tMG = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_lNEJAIdP2nGJJTzQJ", &sbt_lNEJAIdP2nGJJTzQJ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lJWxQ_cqsRBNVrkFM25")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lJWxQ_cqsRBNVrkFM25.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qFnOut8eUpJlaxuFFFg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qFnOut8eUpJlaxuFFFg = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX", &sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ", &sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_l4LbHexZYx6WrUOf0KiPnQ1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l4LbHexZYx6WrUOf0KiPnQ1.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jI9yzdcknaX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jI9yzdcknaX = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cMnx5WkBH39P0H8uA6Rg4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cMnx5WkBH39P0H8uA6Rg4.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S6KQamGF0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S6KQamGF0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QIw32ryQ0pCTI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QIw32ryQ0pCTI.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy", &sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__vVvr2qfMgrKj6id68B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__vVvr2qfMgrKj6id68B = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KCzaRHSDJSYT4Pptg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KCzaRHSDJSYT4Pptg.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.begin(); iter != sbt_DfkUvap_KGfSAcpWVbvHab0dXqaXIW6Zo4FVfcOqMstZbT4i5T_Yn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq", (CX::Int64)sbt_QJxNwPgIjLNcw8ugLTLr69MFBHNu9LHY0hCrbsf5qMT41WqcrhqLHTpIq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6z0eXcU2vGa", (CX::Int64)sbt_6z0eXcU2vGa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_f_iFUOLdet5lW", (CX::Int64)sbt_f_iFUOLdet5lW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_23tMG", (CX::Int64)sbt_23tMG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.begin(); iter != sbt_yn16INqcr9ZeCXfmt4fvOws9L1oLYWyfWNzRUk7pAyhx4wAg58M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.begin(); iter != sbt_sMXYqy83RPiwKnecVbd9sYuJi3OObWY0RtfgCZwEyR5Kde0ZFj_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_lNEJAIdP2nGJJTzQJ", sbt_lNEJAIdP2nGJJTzQJ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lJWxQ_cqsRBNVrkFM25")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_lJWxQ_cqsRBNVrkFM25.begin(); iter != sbt_lJWxQ_cqsRBNVrkFM25.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qFnOut8eUpJlaxuFFFg", (CX::Int64)sbt_qFnOut8eUpJlaxuFFFg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX", sbt_bTNNVJvNhHgujEzRXzF8AZIab3Y_qOZ0QJX.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ", sbt_H1Lmrez7DUOJldlxIh6KdGGWZl4wV5Yb_eEVzRI4UyjZX08KQAoIySiLDwvZ1PJ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a", (CX::Int64)sbt_zf0x7lhqmPCchcNMSFEG3jXMXLNuNfWtD_Y4ZoP1A8L7FB94a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l4LbHexZYx6WrUOf0KiPnQ1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_l4LbHexZYx6WrUOf0KiPnQ1.begin(); iter != sbt_l4LbHexZYx6WrUOf0KiPnQ1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO", (CX::Int64)sbt_UzajzGh6WcGc50sZAaxivWxyP0ed0ePysL0d_YMXqbD2NytkpTO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.begin(); iter != sbt_7dLS23MuoHQkVaefv0Eu3ILr5yoo7frzwT0VT5R7cEFv__sOH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.begin(); iter != sbt_VYP1z_W3JSfQvdEowhJidanx3RlJmgenUx0znqq64SeZ2OAoa3cVvBFRJnF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jI9yzdcknaX", (CX::Int64)sbt_jI9yzdcknaX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cMnx5WkBH39P0H8uA6Rg4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_cMnx5WkBH39P0H8uA6Rg4.begin(); iter != sbt_cMnx5WkBH39P0H8uA6Rg4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S6KQamGF0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_S6KQamGF0.begin(); iter != sbt_S6KQamGF0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QIw32ryQ0pCTI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QIw32ryQ0pCTI.begin(); iter != sbt_QIw32ryQ0pCTI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy", sbt_3pzkdhlL0fo8h6Sn6YsxUTXZ7_iKAwEhhr2uy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__vVvr2qfMgrKj6id68B", (CX::Int64)sbt__vVvr2qfMgrKj6id68B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KCzaRHSDJSYT4Pptg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_KCzaRHSDJSYT4Pptg.begin(); iter != sbt_KCzaRHSDJSYT4Pptg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_JGr8WaY>::Type sbt_JGr8WaYArray;

