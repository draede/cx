
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_JNQMeDiFBg8c0 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_sEgxUREubAw;
	CX::UInt64 sbt_zoWd7drCh6rz6;
	CX::IO::SimpleBuffers::Int16Array sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL;
	CX::Int64 sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4;
	CX::UInt16 sbt_8757SrA;
	CX::Int8 sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT;
	CX::String sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR;
	CX::IO::SimpleBuffers::UInt32Array sbt_jPOL1;
	CX::UInt64 sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3;
	CX::Int64 sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo;
	CX::UInt8 sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf;
	CX::IO::SimpleBuffers::Int32Array sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM;
	CX::IO::SimpleBuffers::UInt64Array sbt_W;
	CX::Bool sbt_Njuwkrwh3g2QYpEdAkT;
	CX::Int16 sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV;
	CX::Int8 sbt_L2vNuYHVTf5yqFc4BAqSQAWha;
	CX::IO::SimpleBuffers::UInt64Array sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH;
	CX::IO::SimpleBuffers::Int32Array sbt_h2B4Q8QaOWbyaJp4y1YNYDJ;
	CX::IO::SimpleBuffers::Int32Array sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO;
	CX::UInt8 sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu;
	CX::IO::SimpleBuffers::Int64Array sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO;
	CX::IO::SimpleBuffers::Int8Array sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI;
	CX::UInt32 sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq;
	CX::UInt64 sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR;
	CX::Bool sbt_0M1C1A8mh;
	CX::IO::SimpleBuffers::Int32Array sbt_4YQ;
	CX::IO::SimpleBuffers::UInt64Array sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM;
	CX::IO::SimpleBuffers::BoolArray sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L;
	CX::IO::SimpleBuffers::UInt64Array sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl;

	virtual void Reset()
	{
		sbt_sEgxUREubAw.clear();
		sbt_zoWd7drCh6rz6 = 0;
		sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.clear();
		sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4 = 0;
		sbt_8757SrA = 0;
		sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT = 0;
		sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR.clear();
		sbt_jPOL1.clear();
		sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3 = 0;
		sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo = 0;
		sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf = 0;
		sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.clear();
		sbt_W.clear();
		sbt_Njuwkrwh3g2QYpEdAkT = false;
		sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV = 0;
		sbt_L2vNuYHVTf5yqFc4BAqSQAWha = 0;
		sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.clear();
		sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.clear();
		sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.clear();
		sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu = 0;
		sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.clear();
		sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.clear();
		sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq = 0;
		sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR = 0;
		sbt_0M1C1A8mh = false;
		sbt_4YQ.clear();
		sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.clear();
		sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.clear();
		sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_sEgxUREubAw.push_back(5874);
		}
		sbt_zoWd7drCh6rz6 = 8006510776618276226;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.push_back(32434);
		}
		sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4 = -4971593195418337130;
		sbt_8757SrA = 12539;
		sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT = -88;
		sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR = "chP]b.Nla5o0";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_jPOL1.push_back(1378362568);
		}
		sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3 = 12070491240456412664;
		sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo = -1517596470331247452;
		sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf = 107;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.push_back(649816174);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_W.push_back(17530409226889390778);
		}
		sbt_Njuwkrwh3g2QYpEdAkT = false;
		sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV = 12647;
		sbt_L2vNuYHVTf5yqFc4BAqSQAWha = 29;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.push_back(-1842170731);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.push_back(2001801657);
		}
		sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu = 167;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.push_back(-4713307527790686242);
		}
		sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq = 215988445;
		sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR = 6767923628264119992;
		sbt_0M1C1A8mh = false;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_4YQ.push_back(-1933183758);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.push_back(15971561730247589810);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.push_back(true);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.push_back(4674259916829115828);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_JNQMeDiFBg8c0 *pObject = dynamic_cast<const sbt_JNQMeDiFBg8c0 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_sEgxUREubAw.size() != pObject->sbt_sEgxUREubAw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sEgxUREubAw.size(); i++)
		{
			if (sbt_sEgxUREubAw[i] != pObject->sbt_sEgxUREubAw[i])
			{
				return false;
			}
		}
		if (sbt_zoWd7drCh6rz6 != pObject->sbt_zoWd7drCh6rz6)
		{
			return false;
		}
		if (sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.size() != pObject->sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.size(); i++)
		{
			if (sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL[i] != pObject->sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL[i])
			{
				return false;
			}
		}
		if (sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4 != pObject->sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4)
		{
			return false;
		}
		if (sbt_8757SrA != pObject->sbt_8757SrA)
		{
			return false;
		}
		if (sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT != pObject->sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR.c_str(), pObject->sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR.c_str()))
		{
			return false;
		}
		if (sbt_jPOL1.size() != pObject->sbt_jPOL1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jPOL1.size(); i++)
		{
			if (sbt_jPOL1[i] != pObject->sbt_jPOL1[i])
			{
				return false;
			}
		}
		if (sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3 != pObject->sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3)
		{
			return false;
		}
		if (sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo != pObject->sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo)
		{
			return false;
		}
		if (sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf != pObject->sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf)
		{
			return false;
		}
		if (sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.size() != pObject->sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.size(); i++)
		{
			if (sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM[i] != pObject->sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM[i])
			{
				return false;
			}
		}
		if (sbt_W.size() != pObject->sbt_W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W.size(); i++)
		{
			if (sbt_W[i] != pObject->sbt_W[i])
			{
				return false;
			}
		}
		if (sbt_Njuwkrwh3g2QYpEdAkT != pObject->sbt_Njuwkrwh3g2QYpEdAkT)
		{
			return false;
		}
		if (sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV != pObject->sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV)
		{
			return false;
		}
		if (sbt_L2vNuYHVTf5yqFc4BAqSQAWha != pObject->sbt_L2vNuYHVTf5yqFc4BAqSQAWha)
		{
			return false;
		}
		if (sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.size() != pObject->sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.size(); i++)
		{
			if (sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH[i] != pObject->sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH[i])
			{
				return false;
			}
		}
		if (sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.size() != pObject->sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.size(); i++)
		{
			if (sbt_h2B4Q8QaOWbyaJp4y1YNYDJ[i] != pObject->sbt_h2B4Q8QaOWbyaJp4y1YNYDJ[i])
			{
				return false;
			}
		}
		if (sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.size() != pObject->sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.size(); i++)
		{
			if (sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO[i] != pObject->sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO[i])
			{
				return false;
			}
		}
		if (sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu != pObject->sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu)
		{
			return false;
		}
		if (sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.size() != pObject->sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.size(); i++)
		{
			if (sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO[i] != pObject->sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO[i])
			{
				return false;
			}
		}
		if (sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.size() != pObject->sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.size(); i++)
		{
			if (sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI[i] != pObject->sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI[i])
			{
				return false;
			}
		}
		if (sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq != pObject->sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq)
		{
			return false;
		}
		if (sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR != pObject->sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR)
		{
			return false;
		}
		if (sbt_0M1C1A8mh != pObject->sbt_0M1C1A8mh)
		{
			return false;
		}
		if (sbt_4YQ.size() != pObject->sbt_4YQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4YQ.size(); i++)
		{
			if (sbt_4YQ[i] != pObject->sbt_4YQ[i])
			{
				return false;
			}
		}
		if (sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.size() != pObject->sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.size(); i++)
		{
			if (sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM[i] != pObject->sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM[i])
			{
				return false;
			}
		}
		if (sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.size() != pObject->sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.size(); i++)
		{
			if (sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L[i] != pObject->sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L[i])
			{
				return false;
			}
		}
		if (sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.size() != pObject->sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.size(); i++)
		{
			if (sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl[i] != pObject->sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_sEgxUREubAw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sEgxUREubAw.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zoWd7drCh6rz6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zoWd7drCh6rz6 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8757SrA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8757SrA = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR", &sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jPOL1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jPOL1.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Njuwkrwh3g2QYpEdAkT", &sbt_Njuwkrwh3g2QYpEdAkT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_L2vNuYHVTf5yqFc4BAqSQAWha", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_L2vNuYHVTf5yqFc4BAqSQAWha = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h2B4Q8QaOWbyaJp4y1YNYDJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_0M1C1A8mh", &sbt_0M1C1A8mh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4YQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4YQ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_sEgxUREubAw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_sEgxUREubAw.begin(); iter != sbt_sEgxUREubAw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zoWd7drCh6rz6", (CX::Int64)sbt_zoWd7drCh6rz6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.begin(); iter != sbt_KTk99aFBhsvxzjCJBWnQvXrfHguWbfUsZIWXH8TYsMz9YfpOukL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4", (CX::Int64)sbt_w4JibXCA1YUiO4P85tsIuSW_grSw31ySofpzfstM4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8757SrA", (CX::Int64)sbt_8757SrA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT", (CX::Int64)sbt_AdlpoeJFT5b8oSfRVxJfDO_EDvcYBUecT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR", sbt_ZdRThTshg3tQkpu6K8kP090WH8OvR.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jPOL1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_jPOL1.begin(); iter != sbt_jPOL1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3", (CX::Int64)sbt_lLNgBIyVrQbQxBYiwXYPqtXmHXA6RcZ7d_nK3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo", (CX::Int64)sbt_TBf2WXW5p_EWRNIIieK_STIAqNTKo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf", (CX::Int64)sbt_MEqxxqZ6ndHuPSsCM6Aqkx91iJcW6UR7hm6wf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.begin(); iter != sbt_5H1av5D_0MBer_41i3qPIQDKJtulE8RO3DJQtYOFD_lYnqKE11dyGwjZPzLIUQM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_W.begin(); iter != sbt_W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Njuwkrwh3g2QYpEdAkT", sbt_Njuwkrwh3g2QYpEdAkT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV", (CX::Int64)sbt_9XxNkWoCe4qjorPRNB1Ubbpm9skmR5_H53HNoZb7tWXRtZV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_L2vNuYHVTf5yqFc4BAqSQAWha", (CX::Int64)sbt_L2vNuYHVTf5yqFc4BAqSQAWha)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.begin(); iter != sbt_rF1EYBPtkAfCG0E_ceDimOXnY5DeqUaXmid6XLs_RwTuH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h2B4Q8QaOWbyaJp4y1YNYDJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.begin(); iter != sbt_h2B4Q8QaOWbyaJp4y1YNYDJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.begin(); iter != sbt_Oh6RaWSaSDyIBt_AdT0eJWA8Hb8zXsRs0fQgJBCClXO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu", (CX::Int64)sbt_UaYnFOIp6Atl5wWH59ZZNnsLpK6RZZnS1hCx5rOA08zM9anxEXFAvPauu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.begin(); iter != sbt_gVA8qPCGLMH0LDuXtFFMCIGNoyf6jqowgq2iwpku6Xu9AWiC9YDE0D8mO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.begin(); iter != sbt_DwIC67swtIgvu_oTRtqisuxeuvzr0MyfpJ2osSxvI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq", (CX::Int64)sbt_2Kl3C6YeqX0KCyHPPmhS0hyA7EZBGLwbT1ehq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR", (CX::Int64)sbt_qaiGwWB8M7M0JYocVznmo6In21lyfKNxR4SDH9pN8v5OeOeACVZD_IR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_0M1C1A8mh", sbt_0M1C1A8mh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4YQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_4YQ.begin(); iter != sbt_4YQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.begin(); iter != sbt_oEf0knHgmBDQIbYmaX8hLZJVKcmYD62qphuV8Az2m3zRbkSU0JM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.begin(); iter != sbt_yIhPfijCoxnB5XZFFtOS7hWC6oxzV5L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.begin(); iter != sbt_98BYA8NR1DleF4LUKXC_LWqJ3BF4_brou9_mcpVLbVy3rOl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_JNQMeDiFBg8c0>::Type sbt_JNQMeDiFBg8c0Array;

