
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_sAccXmCocRm4NkkyuxK419Ipt.hpp"


class sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj;
	CX::Bool sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69;
	CX::IO::SimpleBuffers::UInt16Array sbt_Mx6qZ;
	CX::Double sbt_IsqFVlYP53TSy0M;
	CX::IO::SimpleBuffers::UInt64Array sbt_XYgmdaex1;
	CX::IO::SimpleBuffers::BoolArray sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe;
	CX::IO::SimpleBuffers::FloatArray sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL;
	CX::IO::SimpleBuffers::Int32Array sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK;
	CX::String sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof;
	CX::IO::SimpleBuffers::UInt8Array sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu;
	CX::IO::SimpleBuffers::Int16Array sbt_CbVnrFn5ukDZqG6V74Q;
	CX::Bool sbt_NJDUYtSMN;
	CX::IO::SimpleBuffers::UInt64Array sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ;
	CX::IO::SimpleBuffers::WStringArray sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi;
	CX::Int16 sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV;
	CX::IO::SimpleBuffers::UInt8Array sbt_9vkU0gs;
	CX::Bool sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do;
	CX::String sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N;
	CX::IO::SimpleBuffers::Int64Array sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO;
	CX::Double sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX;
	CX::UInt16 sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL;
	CX::Int16 sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw;
	CX::UInt32 sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3;
	CX::Bool sbt_dx95BSQl6t6iq1g;
	CX::Int64 sbt_6uf04ip_8YYyyMAG7;
	CX::IO::SimpleBuffers::FloatArray sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps;
	sbt_sAccXmCocRm4NkkyuxK419Ipt sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS;

	virtual void Reset()
	{
		sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.clear();
		sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69 = false;
		sbt_Mx6qZ.clear();
		sbt_IsqFVlYP53TSy0M = 0.0;
		sbt_XYgmdaex1.clear();
		sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.clear();
		sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.clear();
		sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.clear();
		sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof.clear();
		sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.clear();
		sbt_CbVnrFn5ukDZqG6V74Q.clear();
		sbt_NJDUYtSMN = false;
		sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.clear();
		sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.clear();
		sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV = 0;
		sbt_9vkU0gs.clear();
		sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do = false;
		sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N.clear();
		sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.clear();
		sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX = 0.0;
		sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL = 0;
		sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw = 0;
		sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3 = 0;
		sbt_dx95BSQl6t6iq1g = false;
		sbt_6uf04ip_8YYyyMAG7 = 0;
		sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.clear();
		sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.push_back(-786854624);
		}
		sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69 = false;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Mx6qZ.push_back(18889);
		}
		sbt_IsqFVlYP53TSy0M = 0.780458;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_XYgmdaex1.push_back(7150354354093532248);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.push_back(true);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.push_back(-874793215);
		}
		sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof = "CS=/W_;*>1zz\"";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.push_back(237);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_CbVnrFn5ukDZqG6V74Q.push_back(16056);
		}
		sbt_NJDUYtSMN = false;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.push_back(17990639289781661286);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.push_back(L"S/lz\\F]<Rf!ob9|YhV14[S|X?0gUW]:");
		}
		sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV = 10739;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_9vkU0gs.push_back(251);
		}
		sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do = true;
		sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N = "x`2tFMxy8\\D{F=&";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.push_back(-8003916326630541620);
		}
		sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX = 0.872224;
		sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL = 11724;
		sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw = 6427;
		sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3 = 1232764915;
		sbt_dx95BSQl6t6iq1g = false;
		sbt_6uf04ip_8YYyyMAG7 = -3376465795316865230;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.push_back(0.799580f);
		}
		sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_ *pObject = dynamic_cast<const sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.size() != pObject->sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.size(); i++)
		{
			if (sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj[i] != pObject->sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj[i])
			{
				return false;
			}
		}
		if (sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69 != pObject->sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69)
		{
			return false;
		}
		if (sbt_Mx6qZ.size() != pObject->sbt_Mx6qZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Mx6qZ.size(); i++)
		{
			if (sbt_Mx6qZ[i] != pObject->sbt_Mx6qZ[i])
			{
				return false;
			}
		}
		if (sbt_IsqFVlYP53TSy0M != pObject->sbt_IsqFVlYP53TSy0M)
		{
			return false;
		}
		if (sbt_XYgmdaex1.size() != pObject->sbt_XYgmdaex1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XYgmdaex1.size(); i++)
		{
			if (sbt_XYgmdaex1[i] != pObject->sbt_XYgmdaex1[i])
			{
				return false;
			}
		}
		if (sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.size() != pObject->sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.size(); i++)
		{
			if (sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe[i] != pObject->sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe[i])
			{
				return false;
			}
		}
		if (sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.size() != pObject->sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.size(); i++)
		{
			if (sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL[i] != pObject->sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL[i])
			{
				return false;
			}
		}
		if (sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.size() != pObject->sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.size(); i++)
		{
			if (sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK[i] != pObject->sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof.c_str(), pObject->sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof.c_str()))
		{
			return false;
		}
		if (sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.size() != pObject->sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.size(); i++)
		{
			if (sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu[i] != pObject->sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu[i])
			{
				return false;
			}
		}
		if (sbt_CbVnrFn5ukDZqG6V74Q.size() != pObject->sbt_CbVnrFn5ukDZqG6V74Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CbVnrFn5ukDZqG6V74Q.size(); i++)
		{
			if (sbt_CbVnrFn5ukDZqG6V74Q[i] != pObject->sbt_CbVnrFn5ukDZqG6V74Q[i])
			{
				return false;
			}
		}
		if (sbt_NJDUYtSMN != pObject->sbt_NJDUYtSMN)
		{
			return false;
		}
		if (sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.size() != pObject->sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.size(); i++)
		{
			if (sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ[i] != pObject->sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ[i])
			{
				return false;
			}
		}
		if (sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.size() != pObject->sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi[i].c_str(), pObject->sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV != pObject->sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV)
		{
			return false;
		}
		if (sbt_9vkU0gs.size() != pObject->sbt_9vkU0gs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9vkU0gs.size(); i++)
		{
			if (sbt_9vkU0gs[i] != pObject->sbt_9vkU0gs[i])
			{
				return false;
			}
		}
		if (sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do != pObject->sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N.c_str(), pObject->sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N.c_str()))
		{
			return false;
		}
		if (sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.size() != pObject->sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.size(); i++)
		{
			if (sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO[i] != pObject->sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO[i])
			{
				return false;
			}
		}
		if (sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX != pObject->sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX)
		{
			return false;
		}
		if (sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL != pObject->sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL)
		{
			return false;
		}
		if (sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw != pObject->sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw)
		{
			return false;
		}
		if (sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3 != pObject->sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3)
		{
			return false;
		}
		if (sbt_dx95BSQl6t6iq1g != pObject->sbt_dx95BSQl6t6iq1g)
		{
			return false;
		}
		if (sbt_6uf04ip_8YYyyMAG7 != pObject->sbt_6uf04ip_8YYyyMAG7)
		{
			return false;
		}
		if (sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.size() != pObject->sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.size(); i++)
		{
			if (sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps[i] != pObject->sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps[i])
			{
				return false;
			}
		}
		if (!sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS.Compare(&pObject->sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69", &sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Mx6qZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Mx6qZ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_IsqFVlYP53TSy0M", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_IsqFVlYP53TSy0M = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_XYgmdaex1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XYgmdaex1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof", &sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CbVnrFn5ukDZqG6V74Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CbVnrFn5ukDZqG6V74Q.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_NJDUYtSMN", &sbt_NJDUYtSMN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9vkU0gs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9vkU0gs.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do", &sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N", &sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_dx95BSQl6t6iq1g", &sbt_dx95BSQl6t6iq1g)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6uf04ip_8YYyyMAG7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6uf04ip_8YYyyMAG7 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.begin(); iter != sbt_OJBjaKRTIGdzIbKi7wVL9dVvTIFZ9LQXzlJueyhtmF2Uj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69", sbt_jn1AyyqAgT62p61SiTqnR19BRODiyezbyU2uO0HBQ90qMyTpHdBpV69)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Mx6qZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Mx6qZ.begin(); iter != sbt_Mx6qZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_IsqFVlYP53TSy0M", (CX::Double)sbt_IsqFVlYP53TSy0M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XYgmdaex1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_XYgmdaex1.begin(); iter != sbt_XYgmdaex1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.begin(); iter != sbt_f1uRie0sTyvcAPsyRdGaErYbg01OgMJhQ1jsKetaSN_WzSDKyFthuu22fDsNe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.begin(); iter != sbt_MD22xwM61HYz2xhhjzeMt5OpAuTWwrTedvxmZaL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.begin(); iter != sbt_WHpWtUqulHZjHi2mtAIhbOydnits6MVXIgcHqIrnGe4ZNMpPfK8H6N2jFiK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof", sbt_TFKJqftaRBAgGnfT_BzGq8Mzp956C4b3WKOQhrJof.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.begin(); iter != sbt_PA5gM_ZZ49TFRkXtI8nle6QOdvp9sDQNRG8Dzo4nevhlv_Pqu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CbVnrFn5ukDZqG6V74Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_CbVnrFn5ukDZqG6V74Q.begin(); iter != sbt_CbVnrFn5ukDZqG6V74Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_NJDUYtSMN", sbt_NJDUYtSMN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.begin(); iter != sbt_MXUGMcsLq063WOBvinO6ZzY1HeZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.begin(); iter != sbt_IeGxuP1Uky3whevEAncrj_Dk8qoMqH43NGLBIWOpa1UJoCxUi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV", (CX::Int64)sbt_9TvScf1bMs8gHp3tkx0jQjBK4N4Jjd8vtFV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9vkU0gs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_9vkU0gs.begin(); iter != sbt_9vkU0gs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do", sbt_BeKY6hmn3j8JQ2KZuiIIP7ug3Do)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N", sbt_nwX8YCNZNcR_GCFsV9rgSDjO98NELKczrKNTtyfrLl1CQeKjZ2N.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.begin(); iter != sbt_gCzjRVKmvzmKppZso4U3B_w33BDE_V51x8Na2DBWEZBTkpZ8NQbuobIfO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX", (CX::Double)sbt_HObOwLSYaK_dQspdxbX_777o4KqsZV8Abe2hZn783wX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL", (CX::Int64)sbt_UmW3bOEBvxIsTnyh8X4Q07VPkrZesDnlmyQhQjfuL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw", (CX::Int64)sbt_iX4hv6DKp2UynSU1VBLfOcVVXqXu6ELVMZmW_Hw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3", (CX::Int64)sbt_IHM83uU428aanxvhZeLiHzeU4hLbdI9T6ovKVb3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_dx95BSQl6t6iq1g", sbt_dx95BSQl6t6iq1g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6uf04ip_8YYyyMAG7", (CX::Int64)sbt_6uf04ip_8YYyyMAG7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.begin(); iter != sbt_wWXvk4d15OrKB7E0GH3PqS3NgDg8RrVe_fQB5mS6827EdmiizVhzUIUcaps.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_6mD5mt1XCWnDl0IqbYSPHVUfzGapXJMNdBinAdI1Ry6f45cSlJWvLq7h91pbS.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_>::Type sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_Array;

