
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D;
	CX::Bool sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O;
	CX::UInt64 sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG;
	CX::IO::SimpleBuffers::UInt64Array sbt_GK8;
	CX::Int32 sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc;
	CX::IO::SimpleBuffers::Int16Array sbt_TVDChtxjL77;
	CX::IO::SimpleBuffers::UInt32Array sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK;
	CX::Int8 sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1;
	CX::IO::SimpleBuffers::Int8Array sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb;
	CX::IO::SimpleBuffers::StringArray sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI;
	CX::IO::SimpleBuffers::UInt8Array sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv;
	CX::IO::SimpleBuffers::UInt64Array sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7;
	CX::IO::SimpleBuffers::UInt32Array sbt_dvPV3Vf8F4F;

	virtual void Reset()
	{
		sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D.clear();
		sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O = false;
		sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG = 0;
		sbt_GK8.clear();
		sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc = 0;
		sbt_TVDChtxjL77.clear();
		sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.clear();
		sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1 = 0;
		sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.clear();
		sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.clear();
		sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.clear();
		sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.clear();
		sbt_dvPV3Vf8F4F.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D = "Q=%";
		sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O = false;
		sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG = 3348645257728923860;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_GK8.push_back(15441329334347674910);
		}
		sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc = -1383917874;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_TVDChtxjL77.push_back(-10558);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.push_back(2177001221);
		}
		sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1 = 11;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.push_back(-35);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.push_back("Z;]/Itm{[Kp5=,5x/$R>7I0H1'5hwY3lAs|JSBEM(ABW=<+:uL'7H._");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.push_back(18);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.push_back(12015171362513338392);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM *pObject = dynamic_cast<const sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D.c_str(), pObject->sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D.c_str()))
		{
			return false;
		}
		if (sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O != pObject->sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O)
		{
			return false;
		}
		if (sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG != pObject->sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG)
		{
			return false;
		}
		if (sbt_GK8.size() != pObject->sbt_GK8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GK8.size(); i++)
		{
			if (sbt_GK8[i] != pObject->sbt_GK8[i])
			{
				return false;
			}
		}
		if (sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc != pObject->sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc)
		{
			return false;
		}
		if (sbt_TVDChtxjL77.size() != pObject->sbt_TVDChtxjL77.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TVDChtxjL77.size(); i++)
		{
			if (sbt_TVDChtxjL77[i] != pObject->sbt_TVDChtxjL77[i])
			{
				return false;
			}
		}
		if (sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.size() != pObject->sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.size(); i++)
		{
			if (sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK[i] != pObject->sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK[i])
			{
				return false;
			}
		}
		if (sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1 != pObject->sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1)
		{
			return false;
		}
		if (sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.size() != pObject->sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.size(); i++)
		{
			if (sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb[i] != pObject->sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb[i])
			{
				return false;
			}
		}
		if (sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.size() != pObject->sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI[i].c_str(), pObject->sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.size() != pObject->sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.size(); i++)
		{
			if (sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv[i] != pObject->sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv[i])
			{
				return false;
			}
		}
		if (sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.size() != pObject->sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.size(); i++)
		{
			if (sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7[i] != pObject->sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7[i])
			{
				return false;
			}
		}
		if (sbt_dvPV3Vf8F4F.size() != pObject->sbt_dvPV3Vf8F4F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dvPV3Vf8F4F.size(); i++)
		{
			if (sbt_dvPV3Vf8F4F[i] != pObject->sbt_dvPV3Vf8F4F[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D", &sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O", &sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GK8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GK8.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TVDChtxjL77")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TVDChtxjL77.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dvPV3Vf8F4F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dvPV3Vf8F4F.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D", sbt_4WkDtyOLV54OGR04iGAxjo5M3k19D.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O", sbt_1fwYtw2sCrUCjNqw28YC6LJH_rryMgd3Qr2uhKvotrCpv7O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG", (CX::Int64)sbt_ImfcBszCIsoNOMjy0urLnPRB8JnxO4JmxsG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GK8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_GK8.begin(); iter != sbt_GK8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc", (CX::Int64)sbt_ArJouxX_KjAko3zkpvoXUNZrRW37gJ2nc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TVDChtxjL77")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_TVDChtxjL77.begin(); iter != sbt_TVDChtxjL77.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.begin(); iter != sbt_5aXAobTRVhPYWIQphOuN2hNTMsYYTMHZmfQWK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1", (CX::Int64)sbt_aqYxlCY2ruyr_RDZkvgDTgMuDA1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.begin(); iter != sbt_TtgNjSOKgUP0yHFsrfhDap4sdKFXjmTu7dKnYeS8TouuqEPTSbxmb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.begin(); iter != sbt_LpT91LPVBi09olekR8UIwhD09GCBiAhw_U7neshIbm0YGYFmKaxqqTtfFCMjJJI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.begin(); iter != sbt_q8RIf9wXGVlqPctqS7hPNnLm4cv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.begin(); iter != sbt_AezlyWCQ20ndY7Burfjb70hcxKEz9E7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dvPV3Vf8F4F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_dvPV3Vf8F4F.begin(); iter != sbt_dvPV3Vf8F4F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM>::Type sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCMArray;

