
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm.hpp"


class sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W;
	CX::Int64 sbt_J0iJh87aOFslWSzRH8F1IlNYn;
	CX::Float sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9;
	CX::IO::SimpleBuffers::Int64Array sbt_6y_zVnJwwsrpl;
	CX::IO::SimpleBuffers::UInt32Array sbt_PgwdUHjJpp4jP;
	CX::IO::SimpleBuffers::DoubleArray sbt_5wggc;
	CX::IO::SimpleBuffers::FloatArray sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1;
	CX::IO::SimpleBuffers::Int8Array sbt_98OFKP0L5iMRAyD6jqNENYE;
	CX::Double sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ;
	CX::UInt8 sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf;
	CX::WString sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh;
	CX::Bool sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV;
	CX::IO::SimpleBuffers::Int64Array sbt_Fb8Da7AKCChBYrbwe;
	CX::IO::SimpleBuffers::FloatArray sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2;
	CX::Int16 sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ;
	CX::IO::SimpleBuffers::Int16Array sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W;
	CX::WString sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E;
	CX::IO::SimpleBuffers::DoubleArray sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1;
	CX::Int32 sbt_wGslUHS_oMiFyoyob;
	CX::IO::SimpleBuffers::Int16Array sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz;
	CX::IO::SimpleBuffers::BoolArray sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE;
	CX::IO::SimpleBuffers::DoubleArray sbt_3yoBQiKRY_CDovQ8xrA;
	CX::Int16 sbt_qvTSovawPad4bbske;
	CX::IO::SimpleBuffers::UInt16Array sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED;
	CX::IO::SimpleBuffers::Int64Array sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4;
	CX::IO::SimpleBuffers::Int32Array sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg;
	CX::IO::SimpleBuffers::Int32Array sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ;
	CX::Double sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk;
	CX::IO::SimpleBuffers::Int32Array sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_;
	sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCmArray sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z;

	virtual void Reset()
	{
		sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W = 0;
		sbt_J0iJh87aOFslWSzRH8F1IlNYn = 0;
		sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9 = 0.0f;
		sbt_6y_zVnJwwsrpl.clear();
		sbt_PgwdUHjJpp4jP.clear();
		sbt_5wggc.clear();
		sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.clear();
		sbt_98OFKP0L5iMRAyD6jqNENYE.clear();
		sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ = 0.0;
		sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf = 0;
		sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh.clear();
		sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV = false;
		sbt_Fb8Da7AKCChBYrbwe.clear();
		sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.clear();
		sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ = 0;
		sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.clear();
		sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E.clear();
		sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.clear();
		sbt_wGslUHS_oMiFyoyob = 0;
		sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.clear();
		sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.clear();
		sbt_3yoBQiKRY_CDovQ8xrA.clear();
		sbt_qvTSovawPad4bbske = 0;
		sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.clear();
		sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.clear();
		sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.clear();
		sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.clear();
		sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk = 0.0;
		sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.clear();
		sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W = -4319002286250837904;
		sbt_J0iJh87aOFslWSzRH8F1IlNYn = -8013827887002114010;
		sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9 = 0.196839f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_6y_zVnJwwsrpl.push_back(5277501462899528702);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_PgwdUHjJpp4jP.push_back(2895800981);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_5wggc.push_back(0.552199);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.push_back(0.124984f);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_98OFKP0L5iMRAyD6jqNENYE.push_back(87);
		}
		sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ = 0.019678;
		sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf = 12;
		sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh = L"Hv.>9i&o0qCaTk*kc80<9m&CW6q_n6EqePo!SH";
		sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Fb8Da7AKCChBYrbwe.push_back(8758554850361490560);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.push_back(0.331157f);
		}
		sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ = 397;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.push_back(-25453);
		}
		sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E = L"r|_)-xpK}qHKhr<u:ykl@UR`l+L2=\"3,8XPfNr,BsUe)K)i6[MyUeJucCD%q";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.push_back(0.370088);
		}
		sbt_wGslUHS_oMiFyoyob = -1558095447;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.push_back(26182);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.push_back(true);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_3yoBQiKRY_CDovQ8xrA.push_back(0.135166);
		}
		sbt_qvTSovawPad4bbske = -10319;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.push_back(25741);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.push_back(-6122069201950699866);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.push_back(-2085508312);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.push_back(-1451948755);
		}
		sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk = 0.338793;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.push_back(1080338875);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm v;

			v.SetupWithSomeValues();
			sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf *pObject = dynamic_cast<const sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W != pObject->sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W)
		{
			return false;
		}
		if (sbt_J0iJh87aOFslWSzRH8F1IlNYn != pObject->sbt_J0iJh87aOFslWSzRH8F1IlNYn)
		{
			return false;
		}
		if (sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9 != pObject->sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9)
		{
			return false;
		}
		if (sbt_6y_zVnJwwsrpl.size() != pObject->sbt_6y_zVnJwwsrpl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6y_zVnJwwsrpl.size(); i++)
		{
			if (sbt_6y_zVnJwwsrpl[i] != pObject->sbt_6y_zVnJwwsrpl[i])
			{
				return false;
			}
		}
		if (sbt_PgwdUHjJpp4jP.size() != pObject->sbt_PgwdUHjJpp4jP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PgwdUHjJpp4jP.size(); i++)
		{
			if (sbt_PgwdUHjJpp4jP[i] != pObject->sbt_PgwdUHjJpp4jP[i])
			{
				return false;
			}
		}
		if (sbt_5wggc.size() != pObject->sbt_5wggc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5wggc.size(); i++)
		{
			if (sbt_5wggc[i] != pObject->sbt_5wggc[i])
			{
				return false;
			}
		}
		if (sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.size() != pObject->sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.size(); i++)
		{
			if (sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1[i] != pObject->sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1[i])
			{
				return false;
			}
		}
		if (sbt_98OFKP0L5iMRAyD6jqNENYE.size() != pObject->sbt_98OFKP0L5iMRAyD6jqNENYE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_98OFKP0L5iMRAyD6jqNENYE.size(); i++)
		{
			if (sbt_98OFKP0L5iMRAyD6jqNENYE[i] != pObject->sbt_98OFKP0L5iMRAyD6jqNENYE[i])
			{
				return false;
			}
		}
		if (sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ != pObject->sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ)
		{
			return false;
		}
		if (sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf != pObject->sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh.c_str(), pObject->sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh.c_str()))
		{
			return false;
		}
		if (sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV != pObject->sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV)
		{
			return false;
		}
		if (sbt_Fb8Da7AKCChBYrbwe.size() != pObject->sbt_Fb8Da7AKCChBYrbwe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fb8Da7AKCChBYrbwe.size(); i++)
		{
			if (sbt_Fb8Da7AKCChBYrbwe[i] != pObject->sbt_Fb8Da7AKCChBYrbwe[i])
			{
				return false;
			}
		}
		if (sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.size() != pObject->sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.size(); i++)
		{
			if (sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2[i] != pObject->sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2[i])
			{
				return false;
			}
		}
		if (sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ != pObject->sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ)
		{
			return false;
		}
		if (sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.size() != pObject->sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.size(); i++)
		{
			if (sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W[i] != pObject->sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E.c_str(), pObject->sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E.c_str()))
		{
			return false;
		}
		if (sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.size() != pObject->sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.size(); i++)
		{
			if (sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1[i] != pObject->sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1[i])
			{
				return false;
			}
		}
		if (sbt_wGslUHS_oMiFyoyob != pObject->sbt_wGslUHS_oMiFyoyob)
		{
			return false;
		}
		if (sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.size() != pObject->sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.size(); i++)
		{
			if (sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz[i] != pObject->sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz[i])
			{
				return false;
			}
		}
		if (sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.size() != pObject->sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.size(); i++)
		{
			if (sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE[i] != pObject->sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE[i])
			{
				return false;
			}
		}
		if (sbt_3yoBQiKRY_CDovQ8xrA.size() != pObject->sbt_3yoBQiKRY_CDovQ8xrA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3yoBQiKRY_CDovQ8xrA.size(); i++)
		{
			if (sbt_3yoBQiKRY_CDovQ8xrA[i] != pObject->sbt_3yoBQiKRY_CDovQ8xrA[i])
			{
				return false;
			}
		}
		if (sbt_qvTSovawPad4bbske != pObject->sbt_qvTSovawPad4bbske)
		{
			return false;
		}
		if (sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.size() != pObject->sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.size(); i++)
		{
			if (sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED[i] != pObject->sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED[i])
			{
				return false;
			}
		}
		if (sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.size() != pObject->sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.size(); i++)
		{
			if (sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4[i] != pObject->sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4[i])
			{
				return false;
			}
		}
		if (sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.size() != pObject->sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.size(); i++)
		{
			if (sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg[i] != pObject->sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg[i])
			{
				return false;
			}
		}
		if (sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.size() != pObject->sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.size(); i++)
		{
			if (sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ[i] != pObject->sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ[i])
			{
				return false;
			}
		}
		if (sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk != pObject->sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk)
		{
			return false;
		}
		if (sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.size() != pObject->sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.size(); i++)
		{
			if (sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_[i] != pObject->sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_[i])
			{
				return false;
			}
		}
		if (sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.size() != pObject->sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.size(); i++)
		{
			if (!sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z[i].Compare(&pObject->sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_J0iJh87aOFslWSzRH8F1IlNYn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J0iJh87aOFslWSzRH8F1IlNYn = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_6y_zVnJwwsrpl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6y_zVnJwwsrpl.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PgwdUHjJpp4jP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PgwdUHjJpp4jP.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5wggc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5wggc.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_98OFKP0L5iMRAyD6jqNENYE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_98OFKP0L5iMRAyD6jqNENYE.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh", &sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV", &sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Fb8Da7AKCChBYrbwe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fb8Da7AKCChBYrbwe.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E", &sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wGslUHS_oMiFyoyob", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wGslUHS_oMiFyoyob = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3yoBQiKRY_CDovQ8xrA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3yoBQiKRY_CDovQ8xrA.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qvTSovawPad4bbske", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qvTSovawPad4bbske = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W", (CX::Int64)sbt_gcsqcqLXh68l_b_9NfCc9HZgwcFjwlcZCRwzzCcO60IakDJyye6PjswGsPhNh7W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J0iJh87aOFslWSzRH8F1IlNYn", (CX::Int64)sbt_J0iJh87aOFslWSzRH8F1IlNYn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9", (CX::Double)sbt_JhemsdlUbicNQkCmugD11I5ADUCwlqCYfNskN8p4Zx9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6y_zVnJwwsrpl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_6y_zVnJwwsrpl.begin(); iter != sbt_6y_zVnJwwsrpl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PgwdUHjJpp4jP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_PgwdUHjJpp4jP.begin(); iter != sbt_PgwdUHjJpp4jP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5wggc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_5wggc.begin(); iter != sbt_5wggc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.begin(); iter != sbt_tmZj2OwaxEp_hytxEVFaPaw5EBm6VMCuAcECUTLDyiRbiY6YMJ3m1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_98OFKP0L5iMRAyD6jqNENYE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_98OFKP0L5iMRAyD6jqNENYE.begin(); iter != sbt_98OFKP0L5iMRAyD6jqNENYE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ", (CX::Double)sbt_P5SC81Ldt5iMrbM8NJXV2J7SDaQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf", (CX::Int64)sbt_Vx95xPaCMWGYQ4N4KQSIClXmPFjB7gvEZJnv59LrJKZr7JIxl3WIgEKC8bitmIf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh", sbt_oObb2fjCbEN0MXetEaVCvY10h1anmbfiluttbx5MS3eELwXyqx7NjfDe4XGSh.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV", sbt_lSjt73JbtHPk30THUCiuGSA7FXWIenj6Mp8zWbV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fb8Da7AKCChBYrbwe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Fb8Da7AKCChBYrbwe.begin(); iter != sbt_Fb8Da7AKCChBYrbwe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.begin(); iter != sbt_8xRmO_8SbCZ31Y3me4QaaUEi6HxyZP2QKe2WM_bxuRYyRTq8X8mKBK3v2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ", (CX::Int64)sbt_YE6WKS2QLimntvqWa0Qw5ms3DnqEaOUStDo4hsCqMb9zrY4ZaMFinNGWJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.begin(); iter != sbt_WzlNxURHseyfuk2PJWCZLRtJZYPy14BYmUySGvWzOmFnAdpXd8xK6xxxKkVcR5W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E", sbt_4Uht4sN8lk_SAiml3L1XcFltovhghIxfopJcu1qDI0ecnt62E.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.begin(); iter != sbt_y4s3cGeazGxg1OlhYzQCAOT8NThsZFJvZTLDme1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wGslUHS_oMiFyoyob", (CX::Int64)sbt_wGslUHS_oMiFyoyob)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.begin(); iter != sbt_UJunzpasWKxoA_49NBMQ3zF3fik72dl_bK59fZQs2Fz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.begin(); iter != sbt_aB6zdsG9U_sGxr8xwXACIcAa2zKj8a4wJdloGHZJWruVE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3yoBQiKRY_CDovQ8xrA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_3yoBQiKRY_CDovQ8xrA.begin(); iter != sbt_3yoBQiKRY_CDovQ8xrA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qvTSovawPad4bbske", (CX::Int64)sbt_qvTSovawPad4bbske)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.begin(); iter != sbt_vDRXCwtc31S2euqTVW4cbJYvbDjQqkTqigkrSH7FSCxQ5sBgpHQHmjLED.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.begin(); iter != sbt_iEvYNsHlBHWo0AjxRcrzeCsPwbFL55SJt3otM6SpWgaa3OQXbW5jmfuM4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.begin(); iter != sbt_J7ZYaCU53ud9SIna6qcY8dK725l14oEVAf6Ivw0cGFV51FSiio2YnkjRg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.begin(); iter != sbt_FbdwvUeaOJ3AKelHqrcpoaOWroSlel3QFI1xTjOv0tWoQ_qJnkBoZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk", (CX::Double)sbt_A9aTkLZztjICjSuPObF9tJcIhNIcWZZQVd6RmucA2QlyRvL7jeKsk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.begin(); iter != sbt_Iaw5zqRZM18ankR_isEtGgzpzO5lI8p70MeVpO0IB8cHJS_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z")).IsNOK())
		{
			return status;
		}
		for (sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCmArray::const_iterator iter = sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.begin(); iter != sbt__vHjchteGY82F4Rr3V3JOcBR8QHSTdxllGalXM1MN2FJKnZfXN4Ff6ntFQnvk3Z.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf>::Type sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVfArray;

