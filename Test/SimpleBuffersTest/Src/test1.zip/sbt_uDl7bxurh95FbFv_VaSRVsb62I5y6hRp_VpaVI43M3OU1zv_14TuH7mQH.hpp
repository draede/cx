
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb;
	CX::IO::SimpleBuffers::UInt64Array sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk;
	CX::IO::SimpleBuffers::UInt64Array sbt_1FOEZTvR5fPasMtUaCQVBMq;
	CX::IO::SimpleBuffers::Int64Array sbt_mdmroDovqWZq_0kfqQcI3Ds4K;
	CX::IO::SimpleBuffers::StringArray sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu;
	CX::UInt64 sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY;
	CX::UInt8 sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem;
	CX::IO::SimpleBuffers::UInt64Array sbt_5e29zFscbWO;

	virtual void Reset()
	{
		sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb = 0;
		sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.clear();
		sbt_1FOEZTvR5fPasMtUaCQVBMq.clear();
		sbt_mdmroDovqWZq_0kfqQcI3Ds4K.clear();
		sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.clear();
		sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY = 0;
		sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem = 0;
		sbt_5e29zFscbWO.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb = 113;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.push_back(9760589139827813266);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_1FOEZTvR5fPasMtUaCQVBMq.push_back(5128449246716372890);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_mdmroDovqWZq_0kfqQcI3Ds4K.push_back(5780667024473706684);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.push_back("X6+|~x=wD\"SAn,-8QGAY$xd0t_<qCeTMT~'2UQOH");
		}
		sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY = 8656635366317115278;
		sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem = 152;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_5e29zFscbWO.push_back(8365131215550723094);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH *pObject = dynamic_cast<const sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb != pObject->sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb)
		{
			return false;
		}
		if (sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.size() != pObject->sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.size(); i++)
		{
			if (sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk[i] != pObject->sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk[i])
			{
				return false;
			}
		}
		if (sbt_1FOEZTvR5fPasMtUaCQVBMq.size() != pObject->sbt_1FOEZTvR5fPasMtUaCQVBMq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1FOEZTvR5fPasMtUaCQVBMq.size(); i++)
		{
			if (sbt_1FOEZTvR5fPasMtUaCQVBMq[i] != pObject->sbt_1FOEZTvR5fPasMtUaCQVBMq[i])
			{
				return false;
			}
		}
		if (sbt_mdmroDovqWZq_0kfqQcI3Ds4K.size() != pObject->sbt_mdmroDovqWZq_0kfqQcI3Ds4K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mdmroDovqWZq_0kfqQcI3Ds4K.size(); i++)
		{
			if (sbt_mdmroDovqWZq_0kfqQcI3Ds4K[i] != pObject->sbt_mdmroDovqWZq_0kfqQcI3Ds4K[i])
			{
				return false;
			}
		}
		if (sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.size() != pObject->sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.size(); i++)
		{
			if (0 != cx_strcmp(sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu[i].c_str(), pObject->sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY != pObject->sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY)
		{
			return false;
		}
		if (sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem != pObject->sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem)
		{
			return false;
		}
		if (sbt_5e29zFscbWO.size() != pObject->sbt_5e29zFscbWO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5e29zFscbWO.size(); i++)
		{
			if (sbt_5e29zFscbWO[i] != pObject->sbt_5e29zFscbWO[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1FOEZTvR5fPasMtUaCQVBMq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1FOEZTvR5fPasMtUaCQVBMq.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mdmroDovqWZq_0kfqQcI3Ds4K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mdmroDovqWZq_0kfqQcI3Ds4K.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5e29zFscbWO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5e29zFscbWO.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb", (CX::Int64)sbt_CQb99SMY3LTuQSnvEeknr_PlbvdmlhwdKGxv9Cb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.begin(); iter != sbt_VrUh5fdbCOgAcxVPTMeKATPtnmSP3Tw6fUl57whZCcBbajIBbAnkUXx2T3Euk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1FOEZTvR5fPasMtUaCQVBMq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_1FOEZTvR5fPasMtUaCQVBMq.begin(); iter != sbt_1FOEZTvR5fPasMtUaCQVBMq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mdmroDovqWZq_0kfqQcI3Ds4K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_mdmroDovqWZq_0kfqQcI3Ds4K.begin(); iter != sbt_mdmroDovqWZq_0kfqQcI3Ds4K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.begin(); iter != sbt_KYrt6HTRgMM1rA2JiTYbHyhyewgRu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY", (CX::Int64)sbt_DHAbHAWShOOuF2UTpoyzNq9hU36U_2bYKiSy0qWSm3QUgSvpAQfxY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem", (CX::Int64)sbt_DMNIacHfbTyLTm9CqxnCVQFGuippSem)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5e29zFscbWO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5e29zFscbWO.begin(); iter != sbt_5e29zFscbWO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH>::Type sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQHArray;

