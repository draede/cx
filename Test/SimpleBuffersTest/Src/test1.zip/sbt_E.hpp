
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_QAL.hpp"


class sbt_E : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_0eVzJkn6tIaQ5X2oJSK_q;
	CX::IO::SimpleBuffers::StringArray sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap;
	CX::IO::SimpleBuffers::BoolArray sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu;
	CX::IO::SimpleBuffers::BoolArray sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi;
	CX::IO::SimpleBuffers::WStringArray sbt_I;
	CX::String sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN;
	CX::Bool sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD;
	CX::Int16 sbt__mwQ9x1e7;
	CX::IO::SimpleBuffers::UInt16Array sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP;
	CX::String sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA;
	CX::IO::SimpleBuffers::UInt32Array sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV;
	CX::Float sbt_fdLbsuLpw;
	CX::IO::SimpleBuffers::Int32Array sbt_0NAS6;
	CX::IO::SimpleBuffers::UInt8Array sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0;
	CX::String sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm;
	CX::IO::SimpleBuffers::UInt64Array sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK;
	CX::Bool sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q;
	CX::IO::SimpleBuffers::UInt32Array sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0;
	CX::IO::SimpleBuffers::BoolArray sbt_R98LtbQl6Qhtr;
	CX::IO::SimpleBuffers::Int16Array sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL;
	CX::IO::SimpleBuffers::UInt8Array sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl;
	CX::IO::SimpleBuffers::DoubleArray sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU;
	CX::Int16 sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh;
	CX::IO::SimpleBuffers::Int16Array sbt_SFMMuI8UfXq9fJW25gxvonudI;
	sbt_QALArray sbt_YuhQZ;

	virtual void Reset()
	{
		sbt_0eVzJkn6tIaQ5X2oJSK_q = 0;
		sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.clear();
		sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.clear();
		sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.clear();
		sbt_I.clear();
		sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN.clear();
		sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD = false;
		sbt__mwQ9x1e7 = 0;
		sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.clear();
		sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA.clear();
		sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.clear();
		sbt_fdLbsuLpw = 0.0f;
		sbt_0NAS6.clear();
		sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.clear();
		sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm.clear();
		sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.clear();
		sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q = false;
		sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.clear();
		sbt_R98LtbQl6Qhtr.clear();
		sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.clear();
		sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.clear();
		sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.clear();
		sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh = 0;
		sbt_SFMMuI8UfXq9fJW25gxvonudI.clear();
		sbt_YuhQZ.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_0eVzJkn6tIaQ5X2oJSK_q = -5899;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.push_back("\":}s{\"2I_");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.push_back(true);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.push_back(false);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_I.push_back(L"atl$OUQl,BwV@d`rX_4v)'mI{8c[<s^dB4Fdy1x\\V@}e(WXf:T_r}");
		}
		sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN = "BQgJkPR02\\ehp5POZ_pz@dS${mmZsb61/HBLQY]";
		sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD = true;
		sbt__mwQ9x1e7 = 13887;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.push_back(53580);
		}
		sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA = "";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.push_back(3170057204);
		}
		sbt_fdLbsuLpw = 0.016941f;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.push_back(223);
		}
		sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm = "vy84IO`d=pp2SNfa:&bGaIE[#^/e3@+_6L{k@`I0Sg\"Q.M[.5Kwa(?)";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.push_back(16901189167431541918);
		}
		sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.push_back(905541512);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_R98LtbQl6Qhtr.push_back(false);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.push_back(-4292);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.push_back(0.952998);
		}
		sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh = -26648;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_SFMMuI8UfXq9fJW25gxvonudI.push_back(-17152);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_QAL v;

			v.SetupWithSomeValues();
			sbt_YuhQZ.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_E *pObject = dynamic_cast<const sbt_E *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_0eVzJkn6tIaQ5X2oJSK_q != pObject->sbt_0eVzJkn6tIaQ5X2oJSK_q)
		{
			return false;
		}
		if (sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.size() != pObject->sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.size(); i++)
		{
			if (0 != cx_strcmp(sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap[i].c_str(), pObject->sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.size() != pObject->sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.size(); i++)
		{
			if (sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu[i] != pObject->sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu[i])
			{
				return false;
			}
		}
		if (sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.size() != pObject->sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.size(); i++)
		{
			if (sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi[i] != pObject->sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi[i])
			{
				return false;
			}
		}
		if (sbt_I.size() != pObject->sbt_I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_I[i].c_str(), pObject->sbt_I[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN.c_str(), pObject->sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN.c_str()))
		{
			return false;
		}
		if (sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD != pObject->sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD)
		{
			return false;
		}
		if (sbt__mwQ9x1e7 != pObject->sbt__mwQ9x1e7)
		{
			return false;
		}
		if (sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.size() != pObject->sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.size(); i++)
		{
			if (sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP[i] != pObject->sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA.c_str(), pObject->sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA.c_str()))
		{
			return false;
		}
		if (sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.size() != pObject->sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.size(); i++)
		{
			if (sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV[i] != pObject->sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV[i])
			{
				return false;
			}
		}
		if (sbt_fdLbsuLpw != pObject->sbt_fdLbsuLpw)
		{
			return false;
		}
		if (sbt_0NAS6.size() != pObject->sbt_0NAS6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0NAS6.size(); i++)
		{
			if (sbt_0NAS6[i] != pObject->sbt_0NAS6[i])
			{
				return false;
			}
		}
		if (sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.size() != pObject->sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.size(); i++)
		{
			if (sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0[i] != pObject->sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm.c_str(), pObject->sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm.c_str()))
		{
			return false;
		}
		if (sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.size() != pObject->sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.size(); i++)
		{
			if (sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK[i] != pObject->sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK[i])
			{
				return false;
			}
		}
		if (sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q != pObject->sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q)
		{
			return false;
		}
		if (sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.size() != pObject->sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.size(); i++)
		{
			if (sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0[i] != pObject->sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0[i])
			{
				return false;
			}
		}
		if (sbt_R98LtbQl6Qhtr.size() != pObject->sbt_R98LtbQl6Qhtr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R98LtbQl6Qhtr.size(); i++)
		{
			if (sbt_R98LtbQl6Qhtr[i] != pObject->sbt_R98LtbQl6Qhtr[i])
			{
				return false;
			}
		}
		if (sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.size() != pObject->sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.size(); i++)
		{
			if (sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL[i] != pObject->sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL[i])
			{
				return false;
			}
		}
		if (sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.size() != pObject->sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.size(); i++)
		{
			if (sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl[i] != pObject->sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl[i])
			{
				return false;
			}
		}
		if (sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.size() != pObject->sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.size(); i++)
		{
			if (sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU[i] != pObject->sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU[i])
			{
				return false;
			}
		}
		if (sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh != pObject->sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh)
		{
			return false;
		}
		if (sbt_SFMMuI8UfXq9fJW25gxvonudI.size() != pObject->sbt_SFMMuI8UfXq9fJW25gxvonudI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SFMMuI8UfXq9fJW25gxvonudI.size(); i++)
		{
			if (sbt_SFMMuI8UfXq9fJW25gxvonudI[i] != pObject->sbt_SFMMuI8UfXq9fJW25gxvonudI[i])
			{
				return false;
			}
		}
		if (sbt_YuhQZ.size() != pObject->sbt_YuhQZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YuhQZ.size(); i++)
		{
			if (!sbt_YuhQZ[i].Compare(&pObject->sbt_YuhQZ[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_0eVzJkn6tIaQ5X2oJSK_q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0eVzJkn6tIaQ5X2oJSK_q = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN", &sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD", &sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__mwQ9x1e7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__mwQ9x1e7 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA", &sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_fdLbsuLpw", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fdLbsuLpw = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_0NAS6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0NAS6.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm", &sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q", &sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R98LtbQl6Qhtr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R98LtbQl6Qhtr.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SFMMuI8UfXq9fJW25gxvonudI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SFMMuI8UfXq9fJW25gxvonudI.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YuhQZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_QAL tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_YuhQZ.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_0eVzJkn6tIaQ5X2oJSK_q", (CX::Int64)sbt_0eVzJkn6tIaQ5X2oJSK_q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.begin(); iter != sbt_MjCb6etwPSqPZ_Ob7eg6n3VJ5z0F0AuE_maH81fP9L5p85s2Xc0Fnap.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.begin(); iter != sbt_os7boozF07G9iKRxOi5xMWz17y_ySKu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.begin(); iter != sbt_iqyRloTMxnpbbh1JD_dOaVLLf7lsRi1gaw5lvJLMi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_I.begin(); iter != sbt_I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN", sbt_AXtcTln9UY400tPWimEIhZ7wvYVgAzmgN.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD", sbt_aF59PW6eonhBtxQyNqDkXNR2tgJItgeAsUJciIJKIvS9PpD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__mwQ9x1e7", (CX::Int64)sbt__mwQ9x1e7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.begin(); iter != sbt_8BupLDiTtXznETUnUfRMb_kGMvPOw3m9uiNUmTP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA", sbt_Hoa61VFQiLsKWBM0vEcK8_AOMbcNlILqLE_catD8xkA.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.begin(); iter != sbt_E6vW25MAdJJ1X7m6OZXTKoSNY10CCrTrDM0fHjV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fdLbsuLpw", (CX::Double)sbt_fdLbsuLpw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0NAS6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_0NAS6.begin(); iter != sbt_0NAS6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.begin(); iter != sbt_XH2NUy2XkRzJFhNMO_BrvWAzNumxtWSajtKMj_ENAHm13A0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm", sbt_1RcpFxczpoVJytljDFXWB05Zd3ev8apvFocGEJ1h8zj3XhHM7Xm.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.begin(); iter != sbt_4nds5cibKdJtHFaWaGY1loOI3dLrHgpcK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q", sbt_fwsGdfThlZ1QPxuE9LD1lmGlg_Z7Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.begin(); iter != sbt_veP0XQwwQzVcWQlSRai5n8LE4nVJYh0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R98LtbQl6Qhtr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_R98LtbQl6Qhtr.begin(); iter != sbt_R98LtbQl6Qhtr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.begin(); iter != sbt_nDZLX_oWP_Bt4l3V6gQFwoqjDqoPmjbfRCZZujW7SF3zSW_TJSL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.begin(); iter != sbt_oP43vOP_bSIPkICRFP2KA8eaOOzcXlGvHWc5Rfl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.begin(); iter != sbt_mXUn12gAQjMiMfrdTr3mX6FCe0X5qxtyRZ0WbxU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh", (CX::Int64)sbt_J2_yZQe73YajTzHq0KOP9HkoVIxSerimrEEYJuh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SFMMuI8UfXq9fJW25gxvonudI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_SFMMuI8UfXq9fJW25gxvonudI.begin(); iter != sbt_SFMMuI8UfXq9fJW25gxvonudI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YuhQZ")).IsNOK())
		{
			return status;
		}
		for (sbt_QALArray::const_iterator iter = sbt_YuhQZ.begin(); iter != sbt_YuhQZ.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_E>::Type sbt_EArray;

