
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_LbdMY;
	CX::IO::SimpleBuffers::UInt64Array sbt_UkoJ37NXSvWN0SOBtdrrDMS;
	CX::IO::SimpleBuffers::Int64Array sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi;
	CX::IO::SimpleBuffers::Int64Array sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL;
	CX::IO::SimpleBuffers::Int16Array sbt_sjDVALMoU11qa0jmDl4;
	CX::UInt64 sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j;
	CX::UInt64 sbt_1VAibbx77DNK8UUUvlAk1vzvz;
	CX::IO::SimpleBuffers::UInt64Array sbt_Bmqx5VN5M;
	CX::String sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X;
	CX::Int32 sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6;
	CX::UInt32 sbt_kFmbxJNjAcro6fi1bna6kARNAuJ;
	CX::IO::SimpleBuffers::UInt64Array sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ;
	CX::IO::SimpleBuffers::BoolArray sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1;
	CX::Bool sbt_UCVCZnWsdbkmRauH_;
	CX::IO::SimpleBuffers::Int64Array sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1;
	CX::IO::SimpleBuffers::UInt16Array sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z;
	CX::IO::SimpleBuffers::BoolArray sbt_P7p6R;
	CX::IO::SimpleBuffers::Int64Array sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3;
	CX::UInt32 sbt_rvFAv42DMRYnDAqZ5j0bA;
	CX::Bool sbt_8sS;

	virtual void Reset()
	{
		sbt_LbdMY = 0;
		sbt_UkoJ37NXSvWN0SOBtdrrDMS.clear();
		sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.clear();
		sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.clear();
		sbt_sjDVALMoU11qa0jmDl4.clear();
		sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j = 0;
		sbt_1VAibbx77DNK8UUUvlAk1vzvz = 0;
		sbt_Bmqx5VN5M.clear();
		sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X.clear();
		sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6 = 0;
		sbt_kFmbxJNjAcro6fi1bna6kARNAuJ = 0;
		sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.clear();
		sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.clear();
		sbt_UCVCZnWsdbkmRauH_ = false;
		sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.clear();
		sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.clear();
		sbt_P7p6R.clear();
		sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.clear();
		sbt_rvFAv42DMRYnDAqZ5j0bA = 0;
		sbt_8sS = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_LbdMY = 114;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_UkoJ37NXSvWN0SOBtdrrDMS.push_back(2612916691294874296);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.push_back(-8866706836107203462);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.push_back(3700496507114514422);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_sjDVALMoU11qa0jmDl4.push_back(16274);
		}
		sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j = 8169905840106289246;
		sbt_1VAibbx77DNK8UUUvlAk1vzvz = 4105455267836748532;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Bmqx5VN5M.push_back(10002353757278047062);
		}
		sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X = "`?_'GBYj2q>@gsi|yl8V<VQ)?|\\#^I,iQ99OX0BI`b!mnamFE~5[T";
		sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6 = 1391443406;
		sbt_kFmbxJNjAcro6fi1bna6kARNAuJ = 3238278235;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.push_back(16799260233545515610);
		}
		sbt_UCVCZnWsdbkmRauH_ = false;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.push_back(-5217287609833329380);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.push_back(25144);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_P7p6R.push_back(true);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.push_back(5513818702590726990);
		}
		sbt_rvFAv42DMRYnDAqZ5j0bA = 2370441752;
		sbt_8sS = true;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9 *pObject = dynamic_cast<const sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_LbdMY != pObject->sbt_LbdMY)
		{
			return false;
		}
		if (sbt_UkoJ37NXSvWN0SOBtdrrDMS.size() != pObject->sbt_UkoJ37NXSvWN0SOBtdrrDMS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UkoJ37NXSvWN0SOBtdrrDMS.size(); i++)
		{
			if (sbt_UkoJ37NXSvWN0SOBtdrrDMS[i] != pObject->sbt_UkoJ37NXSvWN0SOBtdrrDMS[i])
			{
				return false;
			}
		}
		if (sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.size() != pObject->sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.size(); i++)
		{
			if (sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi[i] != pObject->sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi[i])
			{
				return false;
			}
		}
		if (sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.size() != pObject->sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.size(); i++)
		{
			if (sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL[i] != pObject->sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL[i])
			{
				return false;
			}
		}
		if (sbt_sjDVALMoU11qa0jmDl4.size() != pObject->sbt_sjDVALMoU11qa0jmDl4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sjDVALMoU11qa0jmDl4.size(); i++)
		{
			if (sbt_sjDVALMoU11qa0jmDl4[i] != pObject->sbt_sjDVALMoU11qa0jmDl4[i])
			{
				return false;
			}
		}
		if (sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j != pObject->sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j)
		{
			return false;
		}
		if (sbt_1VAibbx77DNK8UUUvlAk1vzvz != pObject->sbt_1VAibbx77DNK8UUUvlAk1vzvz)
		{
			return false;
		}
		if (sbt_Bmqx5VN5M.size() != pObject->sbt_Bmqx5VN5M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Bmqx5VN5M.size(); i++)
		{
			if (sbt_Bmqx5VN5M[i] != pObject->sbt_Bmqx5VN5M[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X.c_str(), pObject->sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X.c_str()))
		{
			return false;
		}
		if (sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6 != pObject->sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6)
		{
			return false;
		}
		if (sbt_kFmbxJNjAcro6fi1bna6kARNAuJ != pObject->sbt_kFmbxJNjAcro6fi1bna6kARNAuJ)
		{
			return false;
		}
		if (sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.size() != pObject->sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.size(); i++)
		{
			if (sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ[i] != pObject->sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ[i])
			{
				return false;
			}
		}
		if (sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.size() != pObject->sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.size(); i++)
		{
			if (sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1[i] != pObject->sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1[i])
			{
				return false;
			}
		}
		if (sbt_UCVCZnWsdbkmRauH_ != pObject->sbt_UCVCZnWsdbkmRauH_)
		{
			return false;
		}
		if (sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.size() != pObject->sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.size(); i++)
		{
			if (sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1[i] != pObject->sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1[i])
			{
				return false;
			}
		}
		if (sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.size() != pObject->sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.size(); i++)
		{
			if (sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z[i] != pObject->sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z[i])
			{
				return false;
			}
		}
		if (sbt_P7p6R.size() != pObject->sbt_P7p6R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P7p6R.size(); i++)
		{
			if (sbt_P7p6R[i] != pObject->sbt_P7p6R[i])
			{
				return false;
			}
		}
		if (sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.size() != pObject->sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.size(); i++)
		{
			if (sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3[i] != pObject->sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3[i])
			{
				return false;
			}
		}
		if (sbt_rvFAv42DMRYnDAqZ5j0bA != pObject->sbt_rvFAv42DMRYnDAqZ5j0bA)
		{
			return false;
		}
		if (sbt_8sS != pObject->sbt_8sS)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_LbdMY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LbdMY = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UkoJ37NXSvWN0SOBtdrrDMS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UkoJ37NXSvWN0SOBtdrrDMS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sjDVALMoU11qa0jmDl4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sjDVALMoU11qa0jmDl4.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1VAibbx77DNK8UUUvlAk1vzvz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1VAibbx77DNK8UUUvlAk1vzvz = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Bmqx5VN5M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Bmqx5VN5M.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X", &sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kFmbxJNjAcro6fi1bna6kARNAuJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kFmbxJNjAcro6fi1bna6kARNAuJ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_UCVCZnWsdbkmRauH_", &sbt_UCVCZnWsdbkmRauH_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P7p6R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P7p6R.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rvFAv42DMRYnDAqZ5j0bA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rvFAv42DMRYnDAqZ5j0bA = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_8sS", &sbt_8sS)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_LbdMY", (CX::Int64)sbt_LbdMY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UkoJ37NXSvWN0SOBtdrrDMS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_UkoJ37NXSvWN0SOBtdrrDMS.begin(); iter != sbt_UkoJ37NXSvWN0SOBtdrrDMS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.begin(); iter != sbt_enh9L4V1ifxD_PVxtdmi3OERoXM0nnmgqM7FXQHpcUvbCb_qi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.begin(); iter != sbt_lE6motVa5K4ROf5NQCMiFC86AUBsOL4SgPsveVBziGL10dIBM3uO8VchL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sjDVALMoU11qa0jmDl4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_sjDVALMoU11qa0jmDl4.begin(); iter != sbt_sjDVALMoU11qa0jmDl4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j", (CX::Int64)sbt_aAUnci6XKHo3nOmMFZUTVWHdva0HLQLzrrcgPu39ZqgICRwUICzG9K67j)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1VAibbx77DNK8UUUvlAk1vzvz", (CX::Int64)sbt_1VAibbx77DNK8UUUvlAk1vzvz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Bmqx5VN5M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Bmqx5VN5M.begin(); iter != sbt_Bmqx5VN5M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X", sbt_3AC6MiEcWY1kx5lZ1L4442NiXCCdn38S67ezp50rccFBfSaJjOp8X.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6", (CX::Int64)sbt_ZC5tmthdasEQLZktaxY2A3OEOFLFJK4WLVQWtvPKFv3QXCp5wc7FwwQmi1otlN6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kFmbxJNjAcro6fi1bna6kARNAuJ", (CX::Int64)sbt_kFmbxJNjAcro6fi1bna6kARNAuJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.begin(); iter != sbt_Jw8jQAz8BsvuXo_0kpPYNqfne2axmANIQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.begin(); iter != sbt_1CEgmVGMBJAQkFT835PdvkGyIQt81JkMOlaGTww7ER1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_UCVCZnWsdbkmRauH_", sbt_UCVCZnWsdbkmRauH_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.begin(); iter != sbt_LccCCOT2ouWbRtQ1_9R1pA99Zy1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.begin(); iter != sbt_W1d20STWY9IrxaGtwbzy7OHka_SJFI88oJDEzaNWrKxSlOR9Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P7p6R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_P7p6R.begin(); iter != sbt_P7p6R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.begin(); iter != sbt_OHiLVqvzsO5Ae2ZBKs01KLOrlTgLOj6kPxttblxkd7mtsIrYjunL_86rGs3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rvFAv42DMRYnDAqZ5j0bA", (CX::Int64)sbt_rvFAv42DMRYnDAqZ5j0bA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_8sS", sbt_8sS)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9>::Type sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9Array;

