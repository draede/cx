
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3;
	CX::IO::SimpleBuffers::UInt64Array sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG;
	CX::UInt64 sbt__;
	CX::Bool sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2;
	CX::Int64 sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG;
	CX::IO::SimpleBuffers::Int8Array sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl;
	CX::UInt32 sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p;
	CX::IO::SimpleBuffers::UInt16Array sbt_Gtxg_klDu;
	CX::UInt32 sbt_t;
	CX::UInt64 sbt_wEKFmSzTtvQ1ZbFus5rnncY;
	CX::IO::SimpleBuffers::Int8Array sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw;
	CX::IO::SimpleBuffers::BoolArray sbt_vmfdkSR_SSWlWH7;
	CX::String sbt_fme3D;
	CX::IO::SimpleBuffers::UInt8Array sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ;
	CX::Int64 sbt_A3y4LTA;
	CX::Bool sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0;
	CX::IO::SimpleBuffers::Int32Array sbt_3lLDmQtbEnZ;
	CX::IO::SimpleBuffers::UInt8Array sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R;
	CX::IO::SimpleBuffers::UInt64Array sbt_GNps3kHL0WAho;
	CX::String sbt_3;

	virtual void Reset()
	{
		sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3 = 0;
		sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.clear();
		sbt__ = 0;
		sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2 = false;
		sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG = 0;
		sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.clear();
		sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p = 0;
		sbt_Gtxg_klDu.clear();
		sbt_t = 0;
		sbt_wEKFmSzTtvQ1ZbFus5rnncY = 0;
		sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.clear();
		sbt_vmfdkSR_SSWlWH7.clear();
		sbt_fme3D.clear();
		sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.clear();
		sbt_A3y4LTA = 0;
		sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0 = false;
		sbt_3lLDmQtbEnZ.clear();
		sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.clear();
		sbt_GNps3kHL0WAho.clear();
		sbt_3.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3 = 6656494748745665288;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.push_back(17346330899549303474);
		}
		sbt__ = 12152516339209772218;
		sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2 = false;
		sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG = 1113471733736558582;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.push_back(-13);
		}
		sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p = 3538330516;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Gtxg_klDu.push_back(60745);
		}
		sbt_t = 2861337515;
		sbt_wEKFmSzTtvQ1ZbFus5rnncY = 15951474793056132272;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.push_back(-125);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_vmfdkSR_SSWlWH7.push_back(false);
		}
		sbt_fme3D = "_o`~Xl1_N$X\\%";
		sbt_A3y4LTA = -2026630609814360408;
		sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0 = true;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_3lLDmQtbEnZ.push_back(-443269442);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.push_back(40);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_GNps3kHL0WAho.push_back(4916276690803214288);
		}
		sbt_3 = "^3v-DWq_lL6IbS+_b6@>ST4WH.Wa:l>'S?";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC *pObject = dynamic_cast<const sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3 != pObject->sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3)
		{
			return false;
		}
		if (sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.size() != pObject->sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.size(); i++)
		{
			if (sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG[i] != pObject->sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG[i])
			{
				return false;
			}
		}
		if (sbt__ != pObject->sbt__)
		{
			return false;
		}
		if (sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2 != pObject->sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2)
		{
			return false;
		}
		if (sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG != pObject->sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG)
		{
			return false;
		}
		if (sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.size() != pObject->sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.size(); i++)
		{
			if (sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl[i] != pObject->sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl[i])
			{
				return false;
			}
		}
		if (sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p != pObject->sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p)
		{
			return false;
		}
		if (sbt_Gtxg_klDu.size() != pObject->sbt_Gtxg_klDu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Gtxg_klDu.size(); i++)
		{
			if (sbt_Gtxg_klDu[i] != pObject->sbt_Gtxg_klDu[i])
			{
				return false;
			}
		}
		if (sbt_t != pObject->sbt_t)
		{
			return false;
		}
		if (sbt_wEKFmSzTtvQ1ZbFus5rnncY != pObject->sbt_wEKFmSzTtvQ1ZbFus5rnncY)
		{
			return false;
		}
		if (sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.size() != pObject->sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.size(); i++)
		{
			if (sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw[i] != pObject->sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw[i])
			{
				return false;
			}
		}
		if (sbt_vmfdkSR_SSWlWH7.size() != pObject->sbt_vmfdkSR_SSWlWH7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vmfdkSR_SSWlWH7.size(); i++)
		{
			if (sbt_vmfdkSR_SSWlWH7[i] != pObject->sbt_vmfdkSR_SSWlWH7[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_fme3D.c_str(), pObject->sbt_fme3D.c_str()))
		{
			return false;
		}
		if (sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.size() != pObject->sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.size(); i++)
		{
			if (sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ[i] != pObject->sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ[i])
			{
				return false;
			}
		}
		if (sbt_A3y4LTA != pObject->sbt_A3y4LTA)
		{
			return false;
		}
		if (sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0 != pObject->sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0)
		{
			return false;
		}
		if (sbt_3lLDmQtbEnZ.size() != pObject->sbt_3lLDmQtbEnZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3lLDmQtbEnZ.size(); i++)
		{
			if (sbt_3lLDmQtbEnZ[i] != pObject->sbt_3lLDmQtbEnZ[i])
			{
				return false;
			}
		}
		if (sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.size() != pObject->sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.size(); i++)
		{
			if (sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R[i] != pObject->sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R[i])
			{
				return false;
			}
		}
		if (sbt_GNps3kHL0WAho.size() != pObject->sbt_GNps3kHL0WAho.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GNps3kHL0WAho.size(); i++)
		{
			if (sbt_GNps3kHL0WAho[i] != pObject->sbt_GNps3kHL0WAho[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_3.c_str(), pObject->sbt_3.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2", &sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Gtxg_klDu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Gtxg_klDu.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wEKFmSzTtvQ1ZbFus5rnncY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wEKFmSzTtvQ1ZbFus5rnncY = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vmfdkSR_SSWlWH7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vmfdkSR_SSWlWH7.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_fme3D", &sbt_fme3D)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A3y4LTA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A3y4LTA = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0", &sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3lLDmQtbEnZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3lLDmQtbEnZ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GNps3kHL0WAho")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GNps3kHL0WAho.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_3", &sbt_3)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3", (CX::Int64)sbt_TEB6KsiOYC2nPkA6lSWX4AnNjZgMrMa_J5t705RTGxWK7Gzl4nqE3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.begin(); iter != sbt_CftMAFImW0IyzPGqGF22xRQfs_0uPpIkGnM6HfKyvAhHG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__", (CX::Int64)sbt__)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2", sbt_cpqjeko29ULN6K4iHXow1xls7zLub80_dKDbpF2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG", (CX::Int64)sbt_NPPVuPhjbspUOzzyXe6KteHeO28__oHwV4FCSHKNtWWn2NSsG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.begin(); iter != sbt_PnbDavTTQY7TNglno54zD2Eh4j90Ek4qtYUtwqX5Qwapl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p", (CX::Int64)sbt_5kxI3qYNCenJFtXs0buXufSYVmLIBxS2epGbyrDPMUBV92kAZ5SVZJYFhef1p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Gtxg_klDu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Gtxg_klDu.begin(); iter != sbt_Gtxg_klDu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t", (CX::Int64)sbt_t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wEKFmSzTtvQ1ZbFus5rnncY", (CX::Int64)sbt_wEKFmSzTtvQ1ZbFus5rnncY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.begin(); iter != sbt_4GVN0ciqCy2zvBipMJ8079KV1zEYjx6hjYz9CwhQUZNoPP6en6MMHlw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vmfdkSR_SSWlWH7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_vmfdkSR_SSWlWH7.begin(); iter != sbt_vmfdkSR_SSWlWH7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_fme3D", sbt_fme3D.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.begin(); iter != sbt__nrS8LbPTMeLuXIibPFoD81zjPS9ItWHxGErEvZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A3y4LTA", (CX::Int64)sbt_A3y4LTA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0", sbt_SUW2sdQec1H8bgbUiz_7Ro5Wqn0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3lLDmQtbEnZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_3lLDmQtbEnZ.begin(); iter != sbt_3lLDmQtbEnZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.begin(); iter != sbt_uipFUSIcBeJ5TKbHZKbznfqJHA1M6qO0R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GNps3kHL0WAho")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_GNps3kHL0WAho.begin(); iter != sbt_GNps3kHL0WAho.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_3", sbt_3.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC>::Type sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNCArray;

