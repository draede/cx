
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_ay3sSPIe8H7XoNbLaPobJRRSrBfJTjI1N6pKnK7dMrQPJfhJb0_aF1KdD.hpp"


class sbt_zhJORZFLhQEym0l : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::DoubleArray sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs;
	CX::IO::SimpleBuffers::UInt8Array sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5;
	CX::UInt32 sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6;
	CX::UInt8 sbt_2CKuhCNP3;
	CX::IO::SimpleBuffers::Int64Array sbt_HYOvpKKevrDeK52Nbxtop;
	CX::IO::SimpleBuffers::Int64Array sbt_FBVQWhIGwbW3Xw2Hk05Gr;
	CX::IO::SimpleBuffers::Int8Array sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa;
	CX::IO::SimpleBuffers::UInt32Array sbt_00LnmIeNwE3gXyz0F;
	CX::IO::SimpleBuffers::Int32Array sbt_NF6Csz1my;
	CX::IO::SimpleBuffers::Int16Array sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz;
	CX::Int8 sbt_yCNQjj9Fm3js1CRTRdb2aDb68;
	CX::Int64 sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M;
	CX::IO::SimpleBuffers::BoolArray sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1;
	CX::IO::SimpleBuffers::StringArray sbt_bwwnKq49xR9ORlTNuYYzn;
	CX::IO::SimpleBuffers::Int8Array sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk;
	CX::IO::SimpleBuffers::BoolArray sbt_5Pb_fog34;
	CX::IO::SimpleBuffers::StringArray sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx;
	CX::IO::SimpleBuffers::FloatArray sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz;
	sbt_ay3sSPIe8H7XoNbLaPobJRRSrBfJTjI1N6pKnK7dMrQPJfhJb0_aF1KdD sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV;

	virtual void Reset()
	{
		sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.clear();
		sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.clear();
		sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6 = 0;
		sbt_2CKuhCNP3 = 0;
		sbt_HYOvpKKevrDeK52Nbxtop.clear();
		sbt_FBVQWhIGwbW3Xw2Hk05Gr.clear();
		sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.clear();
		sbt_00LnmIeNwE3gXyz0F.clear();
		sbt_NF6Csz1my.clear();
		sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.clear();
		sbt_yCNQjj9Fm3js1CRTRdb2aDb68 = 0;
		sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M = 0;
		sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.clear();
		sbt_bwwnKq49xR9ORlTNuYYzn.clear();
		sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.clear();
		sbt_5Pb_fog34.clear();
		sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.clear();
		sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.clear();
		sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.push_back(59);
		}
		sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6 = 4279651561;
		sbt_2CKuhCNP3 = 244;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_HYOvpKKevrDeK52Nbxtop.push_back(-1530789655817933120);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.push_back(108);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_00LnmIeNwE3gXyz0F.push_back(688649508);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_NF6Csz1my.push_back(-1799115867);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.push_back(19001);
		}
		sbt_yCNQjj9Fm3js1CRTRdb2aDb68 = -74;
		sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M = 889046446680654088;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.push_back(false);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_bwwnKq49xR9ORlTNuYYzn.push_back("6M}lHPol{w\"9d7sq.,%[DK");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.push_back(67);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_5Pb_fog34.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.push_back(")S_?zO3H8py0jF~1J'Zd");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.push_back(0.871562f);
		}
		sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zhJORZFLhQEym0l *pObject = dynamic_cast<const sbt_zhJORZFLhQEym0l *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.size() != pObject->sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.size(); i++)
		{
			if (sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs[i] != pObject->sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs[i])
			{
				return false;
			}
		}
		if (sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.size() != pObject->sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.size(); i++)
		{
			if (sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5[i] != pObject->sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5[i])
			{
				return false;
			}
		}
		if (sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6 != pObject->sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6)
		{
			return false;
		}
		if (sbt_2CKuhCNP3 != pObject->sbt_2CKuhCNP3)
		{
			return false;
		}
		if (sbt_HYOvpKKevrDeK52Nbxtop.size() != pObject->sbt_HYOvpKKevrDeK52Nbxtop.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HYOvpKKevrDeK52Nbxtop.size(); i++)
		{
			if (sbt_HYOvpKKevrDeK52Nbxtop[i] != pObject->sbt_HYOvpKKevrDeK52Nbxtop[i])
			{
				return false;
			}
		}
		if (sbt_FBVQWhIGwbW3Xw2Hk05Gr.size() != pObject->sbt_FBVQWhIGwbW3Xw2Hk05Gr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FBVQWhIGwbW3Xw2Hk05Gr.size(); i++)
		{
			if (sbt_FBVQWhIGwbW3Xw2Hk05Gr[i] != pObject->sbt_FBVQWhIGwbW3Xw2Hk05Gr[i])
			{
				return false;
			}
		}
		if (sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.size() != pObject->sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.size(); i++)
		{
			if (sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa[i] != pObject->sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa[i])
			{
				return false;
			}
		}
		if (sbt_00LnmIeNwE3gXyz0F.size() != pObject->sbt_00LnmIeNwE3gXyz0F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_00LnmIeNwE3gXyz0F.size(); i++)
		{
			if (sbt_00LnmIeNwE3gXyz0F[i] != pObject->sbt_00LnmIeNwE3gXyz0F[i])
			{
				return false;
			}
		}
		if (sbt_NF6Csz1my.size() != pObject->sbt_NF6Csz1my.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NF6Csz1my.size(); i++)
		{
			if (sbt_NF6Csz1my[i] != pObject->sbt_NF6Csz1my[i])
			{
				return false;
			}
		}
		if (sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.size() != pObject->sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.size(); i++)
		{
			if (sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz[i] != pObject->sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz[i])
			{
				return false;
			}
		}
		if (sbt_yCNQjj9Fm3js1CRTRdb2aDb68 != pObject->sbt_yCNQjj9Fm3js1CRTRdb2aDb68)
		{
			return false;
		}
		if (sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M != pObject->sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M)
		{
			return false;
		}
		if (sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.size() != pObject->sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.size(); i++)
		{
			if (sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1[i] != pObject->sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1[i])
			{
				return false;
			}
		}
		if (sbt_bwwnKq49xR9ORlTNuYYzn.size() != pObject->sbt_bwwnKq49xR9ORlTNuYYzn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bwwnKq49xR9ORlTNuYYzn.size(); i++)
		{
			if (0 != cx_strcmp(sbt_bwwnKq49xR9ORlTNuYYzn[i].c_str(), pObject->sbt_bwwnKq49xR9ORlTNuYYzn[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.size() != pObject->sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.size(); i++)
		{
			if (sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk[i] != pObject->sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk[i])
			{
				return false;
			}
		}
		if (sbt_5Pb_fog34.size() != pObject->sbt_5Pb_fog34.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5Pb_fog34.size(); i++)
		{
			if (sbt_5Pb_fog34[i] != pObject->sbt_5Pb_fog34[i])
			{
				return false;
			}
		}
		if (sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.size() != pObject->sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx[i].c_str(), pObject->sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.size() != pObject->sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.size(); i++)
		{
			if (sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz[i] != pObject->sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz[i])
			{
				return false;
			}
		}
		if (!sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV.Compare(&pObject->sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2CKuhCNP3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2CKuhCNP3 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HYOvpKKevrDeK52Nbxtop")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HYOvpKKevrDeK52Nbxtop.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FBVQWhIGwbW3Xw2Hk05Gr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FBVQWhIGwbW3Xw2Hk05Gr.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_00LnmIeNwE3gXyz0F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_00LnmIeNwE3gXyz0F.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NF6Csz1my")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NF6Csz1my.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yCNQjj9Fm3js1CRTRdb2aDb68", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yCNQjj9Fm3js1CRTRdb2aDb68 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bwwnKq49xR9ORlTNuYYzn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bwwnKq49xR9ORlTNuYYzn.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5Pb_fog34")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5Pb_fog34.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.begin(); iter != sbt_HA6iT95lxJUNC99hMO8YeXGJdOb3dvtFachnhY7TC9KjqJlOpBs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.begin(); iter != sbt_Uazxj7LBXnia9b2ljwmAorDlSU8IyvSSKErj5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6", (CX::Int64)sbt_d9j2vD4l_tpt3irVLN0BWkp_fsFS2YOaQYECX6bv0x2QkaABWvRHGl5vFM6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2CKuhCNP3", (CX::Int64)sbt_2CKuhCNP3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HYOvpKKevrDeK52Nbxtop")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_HYOvpKKevrDeK52Nbxtop.begin(); iter != sbt_HYOvpKKevrDeK52Nbxtop.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FBVQWhIGwbW3Xw2Hk05Gr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_FBVQWhIGwbW3Xw2Hk05Gr.begin(); iter != sbt_FBVQWhIGwbW3Xw2Hk05Gr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.begin(); iter != sbt_zzDmujZuCOuh1k3y0zPHlz1ZEYdfKV05t0hc1BQFa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_00LnmIeNwE3gXyz0F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_00LnmIeNwE3gXyz0F.begin(); iter != sbt_00LnmIeNwE3gXyz0F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NF6Csz1my")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_NF6Csz1my.begin(); iter != sbt_NF6Csz1my.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.begin(); iter != sbt_rPJjsw6MVOYqlCMIVpPrlJGochKYRL7Q9SSGnAhK_BMgAchkznz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yCNQjj9Fm3js1CRTRdb2aDb68", (CX::Int64)sbt_yCNQjj9Fm3js1CRTRdb2aDb68)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M", (CX::Int64)sbt_fW8gHMbw3331nxvIuIY8jYgsHuhYW6ihdXz0M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.begin(); iter != sbt_Yzv8zwRIzozphnugO7ukTAjTE2HL9NvafqMsW2BJ1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bwwnKq49xR9ORlTNuYYzn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_bwwnKq49xR9ORlTNuYYzn.begin(); iter != sbt_bwwnKq49xR9ORlTNuYYzn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.begin(); iter != sbt_RfmeAyCpvGlz4KBKu5CWukO1qOIFk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5Pb_fog34")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_5Pb_fog34.begin(); iter != sbt_5Pb_fog34.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.begin(); iter != sbt_ApScsEviVj9Gz1Q3JkY8AYBEuM2m37SrPwIrpjJqSvyDEl95IQx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.begin(); iter != sbt_gAoiYIyMs64oR0gYhfPY6CVQBcz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_c0go8CDco1HumricBtP_HdR50_lQ7USUxt3dpl4gV.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zhJORZFLhQEym0l>::Type sbt_zhJORZFLhQEym0lArray;

