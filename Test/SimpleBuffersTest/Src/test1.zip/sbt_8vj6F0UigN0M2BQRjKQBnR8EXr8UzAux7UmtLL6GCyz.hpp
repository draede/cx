
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_qxwtYrkYd29dl.hpp"


class sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_wX0iiAL0NFkIXa_m_yQG2;
	CX::IO::SimpleBuffers::UInt64Array sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h;
	CX::IO::SimpleBuffers::UInt32Array sbt_e9hJy8GXbZqtFYm;
	CX::Bool sbt_m8a0LI8;
	CX::IO::SimpleBuffers::UInt16Array sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI;
	CX::UInt16 sbt_1yQN5b1kudK7zgW5H;
	CX::Int16 sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx;
	CX::Float sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc;
	CX::Int16 sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM;
	CX::Int32 sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ;
	CX::IO::SimpleBuffers::Int32Array sbt_s81Fq9O8V;
	CX::WString sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C;
	CX::UInt16 sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F;
	sbt_qxwtYrkYd29dl sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg;

	virtual void Reset()
	{
		sbt_wX0iiAL0NFkIXa_m_yQG2 = 0.0f;
		sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.clear();
		sbt_e9hJy8GXbZqtFYm.clear();
		sbt_m8a0LI8 = false;
		sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.clear();
		sbt_1yQN5b1kudK7zgW5H = 0;
		sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx = 0;
		sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc = 0.0f;
		sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM = 0;
		sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ = 0;
		sbt_s81Fq9O8V.clear();
		sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C.clear();
		sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F = 0;
		sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_wX0iiAL0NFkIXa_m_yQG2 = 0.008285f;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.push_back(3176167607382107774);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_e9hJy8GXbZqtFYm.push_back(3501039763);
		}
		sbt_m8a0LI8 = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.push_back(37932);
		}
		sbt_1yQN5b1kudK7zgW5H = 5065;
		sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx = -21291;
		sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc = 0.272746f;
		sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM = 25442;
		sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ = -1690093210;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_s81Fq9O8V.push_back(-1031814783);
		}
		sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C = L"9$N+N$Lewu4TCdnVM?xj7";
		sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F = 7412;
		sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz *pObject = dynamic_cast<const sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wX0iiAL0NFkIXa_m_yQG2 != pObject->sbt_wX0iiAL0NFkIXa_m_yQG2)
		{
			return false;
		}
		if (sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.size() != pObject->sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.size(); i++)
		{
			if (sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h[i] != pObject->sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h[i])
			{
				return false;
			}
		}
		if (sbt_e9hJy8GXbZqtFYm.size() != pObject->sbt_e9hJy8GXbZqtFYm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_e9hJy8GXbZqtFYm.size(); i++)
		{
			if (sbt_e9hJy8GXbZqtFYm[i] != pObject->sbt_e9hJy8GXbZqtFYm[i])
			{
				return false;
			}
		}
		if (sbt_m8a0LI8 != pObject->sbt_m8a0LI8)
		{
			return false;
		}
		if (sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.size() != pObject->sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.size(); i++)
		{
			if (sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI[i] != pObject->sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI[i])
			{
				return false;
			}
		}
		if (sbt_1yQN5b1kudK7zgW5H != pObject->sbt_1yQN5b1kudK7zgW5H)
		{
			return false;
		}
		if (sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx != pObject->sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx)
		{
			return false;
		}
		if (sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc != pObject->sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc)
		{
			return false;
		}
		if (sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM != pObject->sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM)
		{
			return false;
		}
		if (sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ != pObject->sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ)
		{
			return false;
		}
		if (sbt_s81Fq9O8V.size() != pObject->sbt_s81Fq9O8V.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s81Fq9O8V.size(); i++)
		{
			if (sbt_s81Fq9O8V[i] != pObject->sbt_s81Fq9O8V[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C.c_str(), pObject->sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C.c_str()))
		{
			return false;
		}
		if (sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F != pObject->sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F)
		{
			return false;
		}
		if (!sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg.Compare(&pObject->sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_wX0iiAL0NFkIXa_m_yQG2", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_wX0iiAL0NFkIXa_m_yQG2 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_e9hJy8GXbZqtFYm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_e9hJy8GXbZqtFYm.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_m8a0LI8", &sbt_m8a0LI8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1yQN5b1kudK7zgW5H", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1yQN5b1kudK7zgW5H = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_s81Fq9O8V")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s81Fq9O8V.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C", &sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_wX0iiAL0NFkIXa_m_yQG2", (CX::Double)sbt_wX0iiAL0NFkIXa_m_yQG2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.begin(); iter != sbt_5EyozqvnfrSWXd9fYWfeYcZghinA_o2oYkKA5or64Y1g9NFKw0dF5wf_h.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_e9hJy8GXbZqtFYm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_e9hJy8GXbZqtFYm.begin(); iter != sbt_e9hJy8GXbZqtFYm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_m8a0LI8", sbt_m8a0LI8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.begin(); iter != sbt_l0YotBiQgE0aAGtMI_WImWjtGdETRBk2SxJ5GaJH4KTjRc5lUWI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1yQN5b1kudK7zgW5H", (CX::Int64)sbt_1yQN5b1kudK7zgW5H)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx", (CX::Int64)sbt_lxUraq0aqF24ou8z9lBA7UfG_buEvcx4Twx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc", (CX::Double)sbt_fUDn3lhbCV7XiA30CDoWjoFgjWSjXHc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM", (CX::Int64)sbt_4WpSUVyhRiqvTX_mvoVTO1aYOPROr8moY8XWbGM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ", (CX::Int64)sbt_KQPBDSm0d8PtFUvJNIkwFjZqYRZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s81Fq9O8V")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_s81Fq9O8V.begin(); iter != sbt_s81Fq9O8V.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C", sbt_GVUeFPWD0W0c50ybXCyNrzWqv8ut3M5lk0JaJPYSPjwoIAq_C.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F", (CX::Int64)sbt_XhL8ZC4VjBP7fa1qE1bLGc0pRGXAb_F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_bPROpe__5ZFrN3M0wXOh_h79v3fq8q3QhlrUr3Gcg.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz>::Type sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyzArray;

