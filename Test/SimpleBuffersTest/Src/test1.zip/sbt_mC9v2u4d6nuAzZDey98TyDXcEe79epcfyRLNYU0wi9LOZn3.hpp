
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP;
	CX::Bool sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5;
	CX::IO::SimpleBuffers::UInt32Array sbt_h05HeQvqKBdOkC5B4;
	CX::Int64 sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_;
	CX::IO::SimpleBuffers::Int32Array sbt_ponmA238or5dJJaN6tskQoSvqCd;
	CX::UInt64 sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk;
	CX::IO::SimpleBuffers::UInt32Array sbt_J1z4Q_Q;
	CX::UInt64 sbt_A_5djA_JH4tnCTrr1or;
	CX::UInt64 sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St;
	CX::IO::SimpleBuffers::UInt32Array sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I;
	CX::UInt64 sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9;
	CX::IO::SimpleBuffers::UInt16Array sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF;
	CX::Int32 sbt_Pb7qi3E;
	CX::IO::SimpleBuffers::UInt32Array sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE;
	CX::Int64 sbt_77bxh;
	CX::UInt64 sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C;
	CX::IO::SimpleBuffers::Int8Array sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y;
	CX::UInt32 sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH;
	CX::UInt32 sbt_yp2t7OrKGzsVUW7DVdNSEr4;
	CX::IO::SimpleBuffers::Int8Array sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X;
	CX::Int8 sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT;
	CX::IO::SimpleBuffers::Int16Array sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR;
	CX::IO::SimpleBuffers::BoolArray sbt_UFaxsBcqsA8tcsArdA795yR;

	virtual void Reset()
	{
		sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.clear();
		sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5 = false;
		sbt_h05HeQvqKBdOkC5B4.clear();
		sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_ = 0;
		sbt_ponmA238or5dJJaN6tskQoSvqCd.clear();
		sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk = 0;
		sbt_J1z4Q_Q.clear();
		sbt_A_5djA_JH4tnCTrr1or = 0;
		sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St = 0;
		sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.clear();
		sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9 = 0;
		sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.clear();
		sbt_Pb7qi3E = 0;
		sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.clear();
		sbt_77bxh = 0;
		sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C = 0;
		sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.clear();
		sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH = 0;
		sbt_yp2t7OrKGzsVUW7DVdNSEr4 = 0;
		sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.clear();
		sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT = 0;
		sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.clear();
		sbt_UFaxsBcqsA8tcsArdA795yR.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.push_back(71);
		}
		sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5 = false;
		sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_ = -6206397519699640610;
		sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk = 11836349360666451924;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_J1z4Q_Q.push_back(3998196769);
		}
		sbt_A_5djA_JH4tnCTrr1or = 2777403993836197830;
		sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St = 483594780712987590;
		sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9 = 8527447771496618470;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.push_back(59628);
		}
		sbt_Pb7qi3E = 971231383;
		sbt_77bxh = -713401041324395732;
		sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C = 12950282350331340762;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.push_back(-116);
		}
		sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH = 55807689;
		sbt_yp2t7OrKGzsVUW7DVdNSEr4 = 4110006874;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.push_back(48);
		}
		sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT = 49;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_UFaxsBcqsA8tcsArdA795yR.push_back(true);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3 *pObject = dynamic_cast<const sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.size() != pObject->sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.size(); i++)
		{
			if (sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP[i] != pObject->sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP[i])
			{
				return false;
			}
		}
		if (sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5 != pObject->sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5)
		{
			return false;
		}
		if (sbt_h05HeQvqKBdOkC5B4.size() != pObject->sbt_h05HeQvqKBdOkC5B4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h05HeQvqKBdOkC5B4.size(); i++)
		{
			if (sbt_h05HeQvqKBdOkC5B4[i] != pObject->sbt_h05HeQvqKBdOkC5B4[i])
			{
				return false;
			}
		}
		if (sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_ != pObject->sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_)
		{
			return false;
		}
		if (sbt_ponmA238or5dJJaN6tskQoSvqCd.size() != pObject->sbt_ponmA238or5dJJaN6tskQoSvqCd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ponmA238or5dJJaN6tskQoSvqCd.size(); i++)
		{
			if (sbt_ponmA238or5dJJaN6tskQoSvqCd[i] != pObject->sbt_ponmA238or5dJJaN6tskQoSvqCd[i])
			{
				return false;
			}
		}
		if (sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk != pObject->sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk)
		{
			return false;
		}
		if (sbt_J1z4Q_Q.size() != pObject->sbt_J1z4Q_Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J1z4Q_Q.size(); i++)
		{
			if (sbt_J1z4Q_Q[i] != pObject->sbt_J1z4Q_Q[i])
			{
				return false;
			}
		}
		if (sbt_A_5djA_JH4tnCTrr1or != pObject->sbt_A_5djA_JH4tnCTrr1or)
		{
			return false;
		}
		if (sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St != pObject->sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St)
		{
			return false;
		}
		if (sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.size() != pObject->sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.size(); i++)
		{
			if (sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I[i] != pObject->sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I[i])
			{
				return false;
			}
		}
		if (sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9 != pObject->sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9)
		{
			return false;
		}
		if (sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.size() != pObject->sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.size(); i++)
		{
			if (sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF[i] != pObject->sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF[i])
			{
				return false;
			}
		}
		if (sbt_Pb7qi3E != pObject->sbt_Pb7qi3E)
		{
			return false;
		}
		if (sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.size() != pObject->sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.size(); i++)
		{
			if (sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE[i] != pObject->sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE[i])
			{
				return false;
			}
		}
		if (sbt_77bxh != pObject->sbt_77bxh)
		{
			return false;
		}
		if (sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C != pObject->sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C)
		{
			return false;
		}
		if (sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.size() != pObject->sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.size(); i++)
		{
			if (sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y[i] != pObject->sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y[i])
			{
				return false;
			}
		}
		if (sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH != pObject->sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH)
		{
			return false;
		}
		if (sbt_yp2t7OrKGzsVUW7DVdNSEr4 != pObject->sbt_yp2t7OrKGzsVUW7DVdNSEr4)
		{
			return false;
		}
		if (sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.size() != pObject->sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.size(); i++)
		{
			if (sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X[i] != pObject->sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X[i])
			{
				return false;
			}
		}
		if (sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT != pObject->sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT)
		{
			return false;
		}
		if (sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.size() != pObject->sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.size(); i++)
		{
			if (sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR[i] != pObject->sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR[i])
			{
				return false;
			}
		}
		if (sbt_UFaxsBcqsA8tcsArdA795yR.size() != pObject->sbt_UFaxsBcqsA8tcsArdA795yR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UFaxsBcqsA8tcsArdA795yR.size(); i++)
		{
			if (sbt_UFaxsBcqsA8tcsArdA795yR[i] != pObject->sbt_UFaxsBcqsA8tcsArdA795yR[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5", &sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h05HeQvqKBdOkC5B4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h05HeQvqKBdOkC5B4.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ponmA238or5dJJaN6tskQoSvqCd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ponmA238or5dJJaN6tskQoSvqCd.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_J1z4Q_Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J1z4Q_Q.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A_5djA_JH4tnCTrr1or", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A_5djA_JH4tnCTrr1or = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Pb7qi3E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Pb7qi3E = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_77bxh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_77bxh = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_yp2t7OrKGzsVUW7DVdNSEr4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yp2t7OrKGzsVUW7DVdNSEr4 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UFaxsBcqsA8tcsArdA795yR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UFaxsBcqsA8tcsArdA795yR.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.begin(); iter != sbt_jppYUXfuEffih3WYr6PUaRzRe7L7uiGLvn6Q0JEyfh2otQ3pgCgxO4riP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5", sbt_pZ2g9moXbYwj5VaI5nQ0aCwrmdYZSpxeGDdFBraXI7KIc0pZdK8Sq_beEwvY5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h05HeQvqKBdOkC5B4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_h05HeQvqKBdOkC5B4.begin(); iter != sbt_h05HeQvqKBdOkC5B4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_", (CX::Int64)sbt_Oj9apNWWG2wrgJsBZHpfWjvXaAUz3M8zbwvMRxz4_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ponmA238or5dJJaN6tskQoSvqCd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ponmA238or5dJJaN6tskQoSvqCd.begin(); iter != sbt_ponmA238or5dJJaN6tskQoSvqCd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk", (CX::Int64)sbt_hCsMJ6yZwfN_wAIKBYSQokTAAroQt6ejBkozPggPSY3XyEk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J1z4Q_Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_J1z4Q_Q.begin(); iter != sbt_J1z4Q_Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A_5djA_JH4tnCTrr1or", (CX::Int64)sbt_A_5djA_JH4tnCTrr1or)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St", (CX::Int64)sbt_9eSOUNAJjPtLusI_v84_D6Xopfrq0dzZyqfPQiwE12tsg_NVzcWC5gYsfKfA7St)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.begin(); iter != sbt_1TkuZGrd9oG8PzinYnBYmb_G88C7UQNZtLq9p7b4kVxHzI0CfTybAO02I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9", (CX::Int64)sbt_ifDF4Uc3zRunl_bMiI_Us9Ds_X6yPCsiD2fhO9ht9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.begin(); iter != sbt_t8hQyY5ubjNqEC7WJfdPz5aR_3iDUmfk8VF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Pb7qi3E", (CX::Int64)sbt_Pb7qi3E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.begin(); iter != sbt_dte5uX2WDYmkmsj9KI8ABm5C61knfQVf1ZdmkqaZE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_77bxh", (CX::Int64)sbt_77bxh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C", (CX::Int64)sbt_SIaaEnnMWobLDN9mArbSEabVtKs2WONB7w6SL3d1C)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.begin(); iter != sbt_gbe1fCmPa1s0SH4HRy3F1j3BESvXyWGckpBc8RV5nipZ4tChc0Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH", (CX::Int64)sbt_YZeNNJ1lsLz9QYP0Sx5RvW9kR6Z2t4YOH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yp2t7OrKGzsVUW7DVdNSEr4", (CX::Int64)sbt_yp2t7OrKGzsVUW7DVdNSEr4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.begin(); iter != sbt_fBGgq8Xgs2ZS4CoeXW5ZI6mLznKBLhZDyfe8X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT", (CX::Int64)sbt_m5vT7tMewUGw7x4fFy776wybfpwPLvOTT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.begin(); iter != sbt_3G1xzjgt3YuVMKrx8yRTanzX8KR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UFaxsBcqsA8tcsArdA795yR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_UFaxsBcqsA8tcsArdA795yR.begin(); iter != sbt_UFaxsBcqsA8tcsArdA795yR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3>::Type sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3Array;

