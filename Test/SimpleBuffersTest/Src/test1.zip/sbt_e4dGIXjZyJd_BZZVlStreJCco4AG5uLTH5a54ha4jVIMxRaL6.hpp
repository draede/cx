
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_OfTs8AqcrGZXthD.hpp"


class sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj;
	CX::Bool sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax;
	CX::Double sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV;
	CX::IO::SimpleBuffers::UInt16Array sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj;
	CX::IO::SimpleBuffers::StringArray sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH;
	CX::IO::SimpleBuffers::UInt16Array sbt_5ADOCPK5T;
	CX::Int8 sbt_dCD;
	CX::Double sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW;
	CX::UInt32 sbt_vrb7vucuzhpPyEk;
	CX::IO::SimpleBuffers::Int8Array sbt_zHt_P__AUt2c1wISxbGdySwXB;
	CX::IO::SimpleBuffers::Int32Array sbt_L54zFVwAyXUEnrSW9nbfNnD;
	CX::Float sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v;
	sbt_OfTs8AqcrGZXthDArray sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5;

	virtual void Reset()
	{
		sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.clear();
		sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax = false;
		sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV = 0.0;
		sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.clear();
		sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.clear();
		sbt_5ADOCPK5T.clear();
		sbt_dCD = 0;
		sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW = 0.0;
		sbt_vrb7vucuzhpPyEk = 0;
		sbt_zHt_P__AUt2c1wISxbGdySwXB.clear();
		sbt_L54zFVwAyXUEnrSW9nbfNnD.clear();
		sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v = 0.0f;
		sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.push_back(-75);
		}
		sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax = false;
		sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV = 0.318842;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.push_back(32715);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.push_back("[AqV#&>\\h;|:0ZZR");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_5ADOCPK5T.push_back(34703);
		}
		sbt_dCD = 120;
		sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW = 0.109657;
		sbt_vrb7vucuzhpPyEk = 4282067034;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_zHt_P__AUt2c1wISxbGdySwXB.push_back(78);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_L54zFVwAyXUEnrSW9nbfNnD.push_back(-962044033);
		}
		sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v = 0.116009f;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_OfTs8AqcrGZXthD v;

			v.SetupWithSomeValues();
			sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6 *pObject = dynamic_cast<const sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.size() != pObject->sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.size(); i++)
		{
			if (sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj[i] != pObject->sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj[i])
			{
				return false;
			}
		}
		if (sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax != pObject->sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax)
		{
			return false;
		}
		if (sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV != pObject->sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV)
		{
			return false;
		}
		if (sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.size() != pObject->sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.size(); i++)
		{
			if (sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj[i] != pObject->sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj[i])
			{
				return false;
			}
		}
		if (sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.size() != pObject->sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.size(); i++)
		{
			if (0 != cx_strcmp(sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH[i].c_str(), pObject->sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_5ADOCPK5T.size() != pObject->sbt_5ADOCPK5T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5ADOCPK5T.size(); i++)
		{
			if (sbt_5ADOCPK5T[i] != pObject->sbt_5ADOCPK5T[i])
			{
				return false;
			}
		}
		if (sbt_dCD != pObject->sbt_dCD)
		{
			return false;
		}
		if (sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW != pObject->sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW)
		{
			return false;
		}
		if (sbt_vrb7vucuzhpPyEk != pObject->sbt_vrb7vucuzhpPyEk)
		{
			return false;
		}
		if (sbt_zHt_P__AUt2c1wISxbGdySwXB.size() != pObject->sbt_zHt_P__AUt2c1wISxbGdySwXB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zHt_P__AUt2c1wISxbGdySwXB.size(); i++)
		{
			if (sbt_zHt_P__AUt2c1wISxbGdySwXB[i] != pObject->sbt_zHt_P__AUt2c1wISxbGdySwXB[i])
			{
				return false;
			}
		}
		if (sbt_L54zFVwAyXUEnrSW9nbfNnD.size() != pObject->sbt_L54zFVwAyXUEnrSW9nbfNnD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L54zFVwAyXUEnrSW9nbfNnD.size(); i++)
		{
			if (sbt_L54zFVwAyXUEnrSW9nbfNnD[i] != pObject->sbt_L54zFVwAyXUEnrSW9nbfNnD[i])
			{
				return false;
			}
		}
		if (sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v != pObject->sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v)
		{
			return false;
		}
		if (sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.size() != pObject->sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.size(); i++)
		{
			if (!sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5[i].Compare(&pObject->sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax", &sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5ADOCPK5T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5ADOCPK5T.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dCD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dCD = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_vrb7vucuzhpPyEk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vrb7vucuzhpPyEk = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zHt_P__AUt2c1wISxbGdySwXB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zHt_P__AUt2c1wISxbGdySwXB.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L54zFVwAyXUEnrSW9nbfNnD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L54zFVwAyXUEnrSW9nbfNnD.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_OfTs8AqcrGZXthD tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.begin(); iter != sbt_MPkGhS8AJ5xhXPj1KvZyfLqgVlebu2rtSltkH0yw5hrXjmahq_1IQATjj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax", sbt_UNxwjtTjGJ_1tLwuhGvuAy7QafB7_gSllfjWF4Gax)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV", (CX::Double)sbt_wxtHZ7ijkoNpiRd5_kmaAXcbRgyMmer157udV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.begin(); iter != sbt_ciav16B0Eke0acN_b2KPxtKxUMcQCB8By2xqqYtYfHgavI6JYP_fj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.begin(); iter != sbt_KTH183Nez0_HN2AvXiQd6mCptr6NH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5ADOCPK5T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_5ADOCPK5T.begin(); iter != sbt_5ADOCPK5T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dCD", (CX::Int64)sbt_dCD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW", (CX::Double)sbt_gsJtn2QCPVzQdRHGaR8TyJDkyDlOe5xcnV8L8kKRfp58fCW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vrb7vucuzhpPyEk", (CX::Int64)sbt_vrb7vucuzhpPyEk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zHt_P__AUt2c1wISxbGdySwXB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_zHt_P__AUt2c1wISxbGdySwXB.begin(); iter != sbt_zHt_P__AUt2c1wISxbGdySwXB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L54zFVwAyXUEnrSW9nbfNnD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_L54zFVwAyXUEnrSW9nbfNnD.begin(); iter != sbt_L54zFVwAyXUEnrSW9nbfNnD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v", (CX::Double)sbt_74o1jH1ymudFCjA_DEDRyIJ5MBk2v)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5")).IsNOK())
		{
			return status;
		}
		for (sbt_OfTs8AqcrGZXthDArray::const_iterator iter = sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.begin(); iter != sbt_rrFtsFuM4YHgxrb66NZUfW6e4eXyCq5.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6>::Type sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6Array;

