
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_6La1NvPRjxJcnkV : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY;
	CX::UInt32 sbt_ZQNJ1ED;
	CX::UInt32 sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49;
	CX::IO::SimpleBuffers::Int32Array sbt_U4OQ8Rl;
	CX::String sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh;
	CX::String sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS;
	CX::Bool sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp;
	CX::IO::SimpleBuffers::Int64Array sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB;
	CX::IO::SimpleBuffers::BoolArray sbt_90r;
	CX::IO::SimpleBuffers::BoolArray sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr;
	CX::Int8 sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt;
	CX::UInt32 sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr;
	CX::IO::SimpleBuffers::Int64Array sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv;
	CX::IO::SimpleBuffers::UInt32Array sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6;
	CX::Bool sbt_ukyUiRsPar5ey;
	CX::UInt64 sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO;
	CX::IO::SimpleBuffers::UInt32Array sbt_p;
	CX::IO::SimpleBuffers::UInt32Array sbt_nL8P0yuQ1oJiv;
	CX::UInt8 sbt_xktq0cQ0IBHGaeJs414pjMv;

	virtual void Reset()
	{
		sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.clear();
		sbt_ZQNJ1ED = 0;
		sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49 = 0;
		sbt_U4OQ8Rl.clear();
		sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh.clear();
		sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS.clear();
		sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp = false;
		sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.clear();
		sbt_90r.clear();
		sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.clear();
		sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt = 0;
		sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr = 0;
		sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.clear();
		sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.clear();
		sbt_ukyUiRsPar5ey = false;
		sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO = 0;
		sbt_p.clear();
		sbt_nL8P0yuQ1oJiv.clear();
		sbt_xktq0cQ0IBHGaeJs414pjMv = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.push_back("^*?aHh");
		}
		sbt_ZQNJ1ED = 2704236748;
		sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49 = 1634179938;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_U4OQ8Rl.push_back(-195085379);
		}
		sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh = "J>?i";
		sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS = "B_Aq_6:e&ym-I.O=~)Od$dO#{wDD.TMiVO}OGj!CoWrAauBk#\"EEHI\":,i.q'";
		sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp = false;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.push_back(-7312035317662449010);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_90r.push_back(true);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.push_back(true);
		}
		sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt = 81;
		sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr = 3088914903;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.push_back(-2624494201310696256);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.push_back(3881834012);
		}
		sbt_ukyUiRsPar5ey = false;
		sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO = 13764523678124263236;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_nL8P0yuQ1oJiv.push_back(254229217);
		}
		sbt_xktq0cQ0IBHGaeJs414pjMv = 54;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6La1NvPRjxJcnkV *pObject = dynamic_cast<const sbt_6La1NvPRjxJcnkV *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.size() != pObject->sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.size(); i++)
		{
			if (0 != cx_strcmp(sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY[i].c_str(), pObject->sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ZQNJ1ED != pObject->sbt_ZQNJ1ED)
		{
			return false;
		}
		if (sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49 != pObject->sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49)
		{
			return false;
		}
		if (sbt_U4OQ8Rl.size() != pObject->sbt_U4OQ8Rl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U4OQ8Rl.size(); i++)
		{
			if (sbt_U4OQ8Rl[i] != pObject->sbt_U4OQ8Rl[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh.c_str(), pObject->sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS.c_str(), pObject->sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS.c_str()))
		{
			return false;
		}
		if (sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp != pObject->sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp)
		{
			return false;
		}
		if (sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.size() != pObject->sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.size(); i++)
		{
			if (sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB[i] != pObject->sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB[i])
			{
				return false;
			}
		}
		if (sbt_90r.size() != pObject->sbt_90r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_90r.size(); i++)
		{
			if (sbt_90r[i] != pObject->sbt_90r[i])
			{
				return false;
			}
		}
		if (sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.size() != pObject->sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.size(); i++)
		{
			if (sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr[i] != pObject->sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr[i])
			{
				return false;
			}
		}
		if (sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt != pObject->sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt)
		{
			return false;
		}
		if (sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr != pObject->sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr)
		{
			return false;
		}
		if (sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.size() != pObject->sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.size(); i++)
		{
			if (sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv[i] != pObject->sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv[i])
			{
				return false;
			}
		}
		if (sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.size() != pObject->sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.size(); i++)
		{
			if (sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6[i] != pObject->sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6[i])
			{
				return false;
			}
		}
		if (sbt_ukyUiRsPar5ey != pObject->sbt_ukyUiRsPar5ey)
		{
			return false;
		}
		if (sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO != pObject->sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO)
		{
			return false;
		}
		if (sbt_p.size() != pObject->sbt_p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p.size(); i++)
		{
			if (sbt_p[i] != pObject->sbt_p[i])
			{
				return false;
			}
		}
		if (sbt_nL8P0yuQ1oJiv.size() != pObject->sbt_nL8P0yuQ1oJiv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nL8P0yuQ1oJiv.size(); i++)
		{
			if (sbt_nL8P0yuQ1oJiv[i] != pObject->sbt_nL8P0yuQ1oJiv[i])
			{
				return false;
			}
		}
		if (sbt_xktq0cQ0IBHGaeJs414pjMv != pObject->sbt_xktq0cQ0IBHGaeJs414pjMv)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZQNJ1ED", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZQNJ1ED = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_U4OQ8Rl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U4OQ8Rl.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh", &sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS", &sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp", &sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_90r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_90r.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_ukyUiRsPar5ey", &sbt_ukyUiRsPar5ey)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nL8P0yuQ1oJiv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nL8P0yuQ1oJiv.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xktq0cQ0IBHGaeJs414pjMv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xktq0cQ0IBHGaeJs414pjMv = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.begin(); iter != sbt_yc28LA3ZWPBMYHgVFKunmHoPWHg6i2xgOvagznCsY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZQNJ1ED", (CX::Int64)sbt_ZQNJ1ED)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49", (CX::Int64)sbt_s7SPABEWMdUL4ozFH8CROHProQa5ljF26FLfBLJnoBuSgSfYN4qJi49)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U4OQ8Rl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_U4OQ8Rl.begin(); iter != sbt_U4OQ8Rl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh", sbt_fKw5S1V3oHX7PC6NGLEhbcJRL9ZofcWQpHbLNwP8YmG9KHh.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS", sbt_wyM8pRoxgcPpnZwr2A0R8gXX_ruODBS.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp", sbt_2Wij8A3lpN6fQUPdg5VXvTwhqeBJvSDmK7y6Iwa3bj_necNMyrp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.begin(); iter != sbt_1dTYBtdXQek8r7vSQgnYxCc3MH6DBsi9F5i_S8dHXjB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_90r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_90r.begin(); iter != sbt_90r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.begin(); iter != sbt_VGgAXwVY8j1iCOHOt69tyK4QTKr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt", (CX::Int64)sbt_QTMaOmePBvSp5UsOtM7QGL__XvnuWCrco7y_PWbLVZ4A9_LLyzOIt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr", (CX::Int64)sbt_ZcN46cI6crG0iHofg4TOcliQuRmhyZbhwwgzr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.begin(); iter != sbt_fZ_oVOnvgZCbJ3KyMQB0hAe_eAWJwMv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.begin(); iter != sbt_1JHwe34kfiQMEWea84310cHE8DG1iTLK6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ukyUiRsPar5ey", sbt_ukyUiRsPar5ey)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO", (CX::Int64)sbt_SqYXDhfsh2lCmsIDj_2p4I5zp90q56ZRQCtQO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_p.begin(); iter != sbt_p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nL8P0yuQ1oJiv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_nL8P0yuQ1oJiv.begin(); iter != sbt_nL8P0yuQ1oJiv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xktq0cQ0IBHGaeJs414pjMv", (CX::Int64)sbt_xktq0cQ0IBHGaeJs414pjMv)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6La1NvPRjxJcnkV>::Type sbt_6La1NvPRjxJcnkVArray;

