
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH.hpp"


class sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_2_Y;
	CX::Int16 sbt_C7IUw01ZE;
	CX::Int32 sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c;
	sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW;

	virtual void Reset()
	{
		sbt_2_Y.clear();
		sbt_C7IUw01ZE = 0;
		sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c = 0;
		sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_2_Y = L"h*>,8>hXl4eNqMToV,4FwBX}B^q}Q`F-m:MT]vzL'6PXH^#U$K71";
		sbt_C7IUw01ZE = 18996;
		sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c = 1856733515;
		sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_ *pObject = dynamic_cast<const sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_2_Y.c_str(), pObject->sbt_2_Y.c_str()))
		{
			return false;
		}
		if (sbt_C7IUw01ZE != pObject->sbt_C7IUw01ZE)
		{
			return false;
		}
		if (sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c != pObject->sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c)
		{
			return false;
		}
		if (!sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW.Compare(&pObject->sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_2_Y", &sbt_2_Y)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_C7IUw01ZE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_C7IUw01ZE = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_2_Y", sbt_2_Y.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_C7IUw01ZE", (CX::Int64)sbt_C7IUw01ZE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c", (CX::Int64)sbt_c5XN3sRdPRwWhExsRB1FJ4PaoleoJobCU7c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_vk0EtJ_DANZpak4H_YnTt_D2g6wiJRHsHzBl4q4frJmSmA68SK8IGzG7MeofW.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_>::Type sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_Array;

