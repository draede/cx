
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_r8yh3;
	CX::IO::SimpleBuffers::UInt16Array sbt_xnnZDMCKcu9T2;
	CX::UInt32 sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo;
	CX::UInt16 sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu;
	CX::IO::SimpleBuffers::UInt8Array sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7;

	virtual void Reset()
	{
		sbt_r8yh3.clear();
		sbt_xnnZDMCKcu9T2.clear();
		sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo = 0;
		sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu = 0;
		sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_r8yh3 = "'Y.@m<'``\"|T=H`?.h\\sUS]#&DX`Pe>SovJo8c(jt=s)C:?2;7";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_xnnZDMCKcu9T2.push_back(35397);
		}
		sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo = 1878332835;
		sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu = 26740;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.push_back(254);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD *pObject = dynamic_cast<const sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_r8yh3.c_str(), pObject->sbt_r8yh3.c_str()))
		{
			return false;
		}
		if (sbt_xnnZDMCKcu9T2.size() != pObject->sbt_xnnZDMCKcu9T2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xnnZDMCKcu9T2.size(); i++)
		{
			if (sbt_xnnZDMCKcu9T2[i] != pObject->sbt_xnnZDMCKcu9T2[i])
			{
				return false;
			}
		}
		if (sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo != pObject->sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo)
		{
			return false;
		}
		if (sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu != pObject->sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu)
		{
			return false;
		}
		if (sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.size() != pObject->sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.size(); i++)
		{
			if (sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7[i] != pObject->sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_r8yh3", &sbt_r8yh3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xnnZDMCKcu9T2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xnnZDMCKcu9T2.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_r8yh3", sbt_r8yh3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xnnZDMCKcu9T2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_xnnZDMCKcu9T2.begin(); iter != sbt_xnnZDMCKcu9T2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo", (CX::Int64)sbt_7hlXaA7DWVey3wPNe60NyeT1EGBZ71kM0FuXpw9P4fLanbo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu", (CX::Int64)sbt_HnW7bCNFlzXGkUgDX_pkREbBsUKGwWKnDuiYXD3GYEyWs2hyl_URWveN5QT0rGu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.begin(); iter != sbt_U3eKJ7Wb6tvgDino5PeFA9kNpfUA7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD>::Type sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcDArray;

