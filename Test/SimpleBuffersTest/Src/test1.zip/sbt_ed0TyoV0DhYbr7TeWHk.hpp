
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_ed0TyoV0DhYbr7TeWHk : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU;

	virtual void Reset()
	{
		sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU = 6921026604264122746;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ed0TyoV0DhYbr7TeWHk *pObject = dynamic_cast<const sbt_ed0TyoV0DhYbr7TeWHk *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU != pObject->sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU", (CX::Int64)sbt_60ukyi8XJ6Akzsu8Auj3OTkq40RCOzTktFdwSJT3IRxd5yRwNsU)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ed0TyoV0DhYbr7TeWHk>::Type sbt_ed0TyoV0DhYbr7TeWHkArray;

