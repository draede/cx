
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF;
	CX::Int64 sbt_0;
	CX::Bool sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF;
	CX::UInt32 sbt_ji2VXXu;
	CX::IO::SimpleBuffers::BoolArray sbt_wa8tP;
	CX::IO::SimpleBuffers::UInt8Array sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn;
	CX::Int8 sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY;
	CX::Int8 sbt_AZm3ItSHk60ZT;
	CX::UInt32 sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK;
	CX::UInt16 sbt_R;

	virtual void Reset()
	{
		sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.clear();
		sbt_0 = 0;
		sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF = false;
		sbt_ji2VXXu = 0;
		sbt_wa8tP.clear();
		sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.clear();
		sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY = 0;
		sbt_AZm3ItSHk60ZT = 0;
		sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK = 0;
		sbt_R = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.push_back(4212559831);
		}
		sbt_0 = 8247058584255366540;
		sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF = true;
		sbt_ji2VXXu = 1109341631;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_wa8tP.push_back(false);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.push_back(22);
		}
		sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY = 7;
		sbt_AZm3ItSHk60ZT = 1;
		sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK = 1897681491;
		sbt_R = 45165;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10 *pObject = dynamic_cast<const sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.size() != pObject->sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.size(); i++)
		{
			if (sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF[i] != pObject->sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF[i])
			{
				return false;
			}
		}
		if (sbt_0 != pObject->sbt_0)
		{
			return false;
		}
		if (sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF != pObject->sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF)
		{
			return false;
		}
		if (sbt_ji2VXXu != pObject->sbt_ji2VXXu)
		{
			return false;
		}
		if (sbt_wa8tP.size() != pObject->sbt_wa8tP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wa8tP.size(); i++)
		{
			if (sbt_wa8tP[i] != pObject->sbt_wa8tP[i])
			{
				return false;
			}
		}
		if (sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.size() != pObject->sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.size(); i++)
		{
			if (sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn[i] != pObject->sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn[i])
			{
				return false;
			}
		}
		if (sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY != pObject->sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY)
		{
			return false;
		}
		if (sbt_AZm3ItSHk60ZT != pObject->sbt_AZm3ItSHk60ZT)
		{
			return false;
		}
		if (sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK != pObject->sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK)
		{
			return false;
		}
		if (sbt_R != pObject->sbt_R)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF", &sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ji2VXXu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ji2VXXu = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wa8tP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wa8tP.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AZm3ItSHk60ZT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AZm3ItSHk60ZT = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_R", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_R = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.begin(); iter != sbt_4GIsAleSEw1oVwc9s9G1uvP6dj17cJ6PlYg8DoZdP7WJmrSNF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0", (CX::Int64)sbt_0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF", sbt_gi7XowH5LLqhX3wirgjkkknb3WVenPf1f83h_trmLMsLYqBhL43FF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ji2VXXu", (CX::Int64)sbt_ji2VXXu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wa8tP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_wa8tP.begin(); iter != sbt_wa8tP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.begin(); iter != sbt_mxdGNg_1q3KFblz7hB5NF6shvZXUpPGajk0REYnNwFphEKSW61rr7HERJ6EKIJn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY", (CX::Int64)sbt_tnfA3vOtSmFdx_o4O7DuaKTXWhyzpCUW8Wpe9_FiY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AZm3ItSHk60ZT", (CX::Int64)sbt_AZm3ItSHk60ZT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK", (CX::Int64)sbt_AfiRXkca8OhR082GUXbsxuSEHOFHmwwO20kK0wIqa3eDZyRSSsK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_R", (CX::Int64)sbt_R)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10>::Type sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10Array;

