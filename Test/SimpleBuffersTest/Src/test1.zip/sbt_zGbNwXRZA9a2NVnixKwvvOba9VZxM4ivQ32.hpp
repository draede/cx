
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_D2lgRi655HoJQnFlCbXM6T3AtbE.hpp"


class sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_PRUkhiFPJJdb_;
	CX::Int64 sbt_br8ifDK7j;
	CX::Int32 sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea;
	CX::IO::SimpleBuffers::Int16Array sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g;
	CX::IO::SimpleBuffers::Int32Array sbt_uh8qMAb;
	CX::WString sbt_Wly62G4gu9NQq3RHfYypQQ0;
	CX::IO::SimpleBuffers::Int16Array sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY;
	CX::IO::SimpleBuffers::UInt8Array sbt_GormzMvQ3TAmHWkIGDt;
	CX::IO::SimpleBuffers::BoolArray sbt_rbPqKmoaUOT;
	CX::Int16 sbt_NFy4zR4yV3tCN7m2lq5;
	CX::IO::SimpleBuffers::Int8Array sbt_RbCqlsTossUPgTW;
	CX::UInt64 sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC;
	CX::IO::SimpleBuffers::UInt64Array sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ;
	CX::IO::SimpleBuffers::UInt16Array sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl;
	CX::IO::SimpleBuffers::UInt8Array sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b;
	CX::UInt8 sbt_7pKWEUhVMm6klMQ6p;
	CX::Double sbt__BDJZ3dwSjz0VTNeSAqq5Cc;
	CX::String sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO;
	CX::Int64 sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7;
	CX::Float sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ;
	CX::IO::SimpleBuffers::BoolArray sbt_uJj3uszSCqXz4I_BeeUoM;
	CX::IO::SimpleBuffers::UInt8Array sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg;
	sbt_D2lgRi655HoJQnFlCbXM6T3AtbEArray sbt_bRHjkEhi0FyzK2s;

	virtual void Reset()
	{
		sbt_PRUkhiFPJJdb_.clear();
		sbt_br8ifDK7j = 0;
		sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea = 0;
		sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.clear();
		sbt_uh8qMAb.clear();
		sbt_Wly62G4gu9NQq3RHfYypQQ0.clear();
		sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.clear();
		sbt_GormzMvQ3TAmHWkIGDt.clear();
		sbt_rbPqKmoaUOT.clear();
		sbt_NFy4zR4yV3tCN7m2lq5 = 0;
		sbt_RbCqlsTossUPgTW.clear();
		sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC = 0;
		sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.clear();
		sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.clear();
		sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.clear();
		sbt_7pKWEUhVMm6klMQ6p = 0;
		sbt__BDJZ3dwSjz0VTNeSAqq5Cc = 0.0;
		sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO.clear();
		sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7 = 0;
		sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ = 0.0f;
		sbt_uJj3uszSCqXz4I_BeeUoM.clear();
		sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.clear();
		sbt_bRHjkEhi0FyzK2s.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_PRUkhiFPJJdb_.push_back(L"~,0nt98[uO_i7rTU&Q;v'8rI%rli7[v\\K");
		}
		sbt_br8ifDK7j = -4377364745746395116;
		sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea = -1756421723;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.push_back(-8310);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_uh8qMAb.push_back(1505012189);
		}
		sbt_Wly62G4gu9NQq3RHfYypQQ0 = L"b,xZ+;os7`xYu7=EDahBVcV@(*nJ";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.push_back(3440);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_rbPqKmoaUOT.push_back(false);
		}
		sbt_NFy4zR4yV3tCN7m2lq5 = -8958;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_RbCqlsTossUPgTW.push_back(-42);
		}
		sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC = 2204202836505439416;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.push_back(17401196057439151324);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.push_back(8941);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.push_back(188);
		}
		sbt_7pKWEUhVMm6klMQ6p = 203;
		sbt__BDJZ3dwSjz0VTNeSAqq5Cc = 0.416776;
		sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO = ";>QI|O4m6sg=8<Vg08sO1#m\"yUUaw%'tfGRp\"}GN't|nRgU[*)\"'lR[]S0|l@:>@";
		sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7 = 8614775311935922998;
		sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ = 0.335552f;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_uJj3uszSCqXz4I_BeeUoM.push_back(false);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.push_back(153);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_D2lgRi655HoJQnFlCbXM6T3AtbE v;

			v.SetupWithSomeValues();
			sbt_bRHjkEhi0FyzK2s.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32 *pObject = dynamic_cast<const sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_PRUkhiFPJJdb_.size() != pObject->sbt_PRUkhiFPJJdb_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PRUkhiFPJJdb_.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_PRUkhiFPJJdb_[i].c_str(), pObject->sbt_PRUkhiFPJJdb_[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_br8ifDK7j != pObject->sbt_br8ifDK7j)
		{
			return false;
		}
		if (sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea != pObject->sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea)
		{
			return false;
		}
		if (sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.size() != pObject->sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.size(); i++)
		{
			if (sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g[i] != pObject->sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g[i])
			{
				return false;
			}
		}
		if (sbt_uh8qMAb.size() != pObject->sbt_uh8qMAb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uh8qMAb.size(); i++)
		{
			if (sbt_uh8qMAb[i] != pObject->sbt_uh8qMAb[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_Wly62G4gu9NQq3RHfYypQQ0.c_str(), pObject->sbt_Wly62G4gu9NQq3RHfYypQQ0.c_str()))
		{
			return false;
		}
		if (sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.size() != pObject->sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.size(); i++)
		{
			if (sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY[i] != pObject->sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY[i])
			{
				return false;
			}
		}
		if (sbt_GormzMvQ3TAmHWkIGDt.size() != pObject->sbt_GormzMvQ3TAmHWkIGDt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GormzMvQ3TAmHWkIGDt.size(); i++)
		{
			if (sbt_GormzMvQ3TAmHWkIGDt[i] != pObject->sbt_GormzMvQ3TAmHWkIGDt[i])
			{
				return false;
			}
		}
		if (sbt_rbPqKmoaUOT.size() != pObject->sbt_rbPqKmoaUOT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rbPqKmoaUOT.size(); i++)
		{
			if (sbt_rbPqKmoaUOT[i] != pObject->sbt_rbPqKmoaUOT[i])
			{
				return false;
			}
		}
		if (sbt_NFy4zR4yV3tCN7m2lq5 != pObject->sbt_NFy4zR4yV3tCN7m2lq5)
		{
			return false;
		}
		if (sbt_RbCqlsTossUPgTW.size() != pObject->sbt_RbCqlsTossUPgTW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RbCqlsTossUPgTW.size(); i++)
		{
			if (sbt_RbCqlsTossUPgTW[i] != pObject->sbt_RbCqlsTossUPgTW[i])
			{
				return false;
			}
		}
		if (sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC != pObject->sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC)
		{
			return false;
		}
		if (sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.size() != pObject->sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.size(); i++)
		{
			if (sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ[i] != pObject->sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ[i])
			{
				return false;
			}
		}
		if (sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.size() != pObject->sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.size(); i++)
		{
			if (sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl[i] != pObject->sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl[i])
			{
				return false;
			}
		}
		if (sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.size() != pObject->sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.size(); i++)
		{
			if (sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b[i] != pObject->sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b[i])
			{
				return false;
			}
		}
		if (sbt_7pKWEUhVMm6klMQ6p != pObject->sbt_7pKWEUhVMm6klMQ6p)
		{
			return false;
		}
		if (sbt__BDJZ3dwSjz0VTNeSAqq5Cc != pObject->sbt__BDJZ3dwSjz0VTNeSAqq5Cc)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO.c_str(), pObject->sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO.c_str()))
		{
			return false;
		}
		if (sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7 != pObject->sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7)
		{
			return false;
		}
		if (sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ != pObject->sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ)
		{
			return false;
		}
		if (sbt_uJj3uszSCqXz4I_BeeUoM.size() != pObject->sbt_uJj3uszSCqXz4I_BeeUoM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uJj3uszSCqXz4I_BeeUoM.size(); i++)
		{
			if (sbt_uJj3uszSCqXz4I_BeeUoM[i] != pObject->sbt_uJj3uszSCqXz4I_BeeUoM[i])
			{
				return false;
			}
		}
		if (sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.size() != pObject->sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.size(); i++)
		{
			if (sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg[i] != pObject->sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg[i])
			{
				return false;
			}
		}
		if (sbt_bRHjkEhi0FyzK2s.size() != pObject->sbt_bRHjkEhi0FyzK2s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bRHjkEhi0FyzK2s.size(); i++)
		{
			if (!sbt_bRHjkEhi0FyzK2s[i].Compare(&pObject->sbt_bRHjkEhi0FyzK2s[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_PRUkhiFPJJdb_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PRUkhiFPJJdb_.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_br8ifDK7j", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_br8ifDK7j = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uh8qMAb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uh8qMAb.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_Wly62G4gu9NQq3RHfYypQQ0", &sbt_Wly62G4gu9NQq3RHfYypQQ0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GormzMvQ3TAmHWkIGDt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GormzMvQ3TAmHWkIGDt.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rbPqKmoaUOT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rbPqKmoaUOT.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NFy4zR4yV3tCN7m2lq5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NFy4zR4yV3tCN7m2lq5 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RbCqlsTossUPgTW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RbCqlsTossUPgTW.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7pKWEUhVMm6klMQ6p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7pKWEUhVMm6klMQ6p = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectReal("sbt__BDJZ3dwSjz0VTNeSAqq5Cc", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__BDJZ3dwSjz0VTNeSAqq5Cc = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectString("sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO", &sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_uJj3uszSCqXz4I_BeeUoM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uJj3uszSCqXz4I_BeeUoM.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bRHjkEhi0FyzK2s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_D2lgRi655HoJQnFlCbXM6T3AtbE tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_bRHjkEhi0FyzK2s.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_PRUkhiFPJJdb_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_PRUkhiFPJJdb_.begin(); iter != sbt_PRUkhiFPJJdb_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_br8ifDK7j", (CX::Int64)sbt_br8ifDK7j)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea", (CX::Int64)sbt_7zGr1UWD_RURi1Uy_8S6EhPAIj7Ea)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.begin(); iter != sbt_oGMArJIZslaKh_LaTIsL9WJF2K0dfNkAfkKvCP3EfiQjfdcx51g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uh8qMAb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_uh8qMAb.begin(); iter != sbt_uh8qMAb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_Wly62G4gu9NQq3RHfYypQQ0", sbt_Wly62G4gu9NQq3RHfYypQQ0.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.begin(); iter != sbt_RmNQb0UbLK1rHC4jE4nXv2OrwB2dlWiNHRVIYIhocqx_oD1SY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GormzMvQ3TAmHWkIGDt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_GormzMvQ3TAmHWkIGDt.begin(); iter != sbt_GormzMvQ3TAmHWkIGDt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rbPqKmoaUOT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_rbPqKmoaUOT.begin(); iter != sbt_rbPqKmoaUOT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NFy4zR4yV3tCN7m2lq5", (CX::Int64)sbt_NFy4zR4yV3tCN7m2lq5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RbCqlsTossUPgTW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_RbCqlsTossUPgTW.begin(); iter != sbt_RbCqlsTossUPgTW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC", (CX::Int64)sbt_KUvVSEG3VIYrqeUYl8O9_koi0Sd10PUkC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.begin(); iter != sbt_jW1mTpLGD_kXqA2rAjXx6c8dbXf0wGTtt9bSTrOLXcsX4ZT9CFCFYoJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.begin(); iter != sbt_EXK3GTXaUAlKrqMMq12c0n2dgis7d9n2g9ZDML5fWLImsdkB0HF4Xc_Ets6GIRl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.begin(); iter != sbt_5pRjTipFuuh27a4YFN2EFD_DWDWDfSE3b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7pKWEUhVMm6klMQ6p", (CX::Int64)sbt_7pKWEUhVMm6klMQ6p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__BDJZ3dwSjz0VTNeSAqq5Cc", (CX::Double)sbt__BDJZ3dwSjz0VTNeSAqq5Cc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO", sbt_AMZdhlWuFym16vhtKVVk9v7rf0CLiUpVrAtPlec8HLsjJqO.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7", (CX::Int64)sbt_p6kVytpkyF8Cos98ZbVdg8Nx31qEqbFdOuOlQuGU4gS_INnzHrvw7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ", (CX::Double)sbt_2I_7Ojkzg5m6n6GJYR7FesC5FYIiAJV7h5JI__1u93N64L1se7lgJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uJj3uszSCqXz4I_BeeUoM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_uJj3uszSCqXz4I_BeeUoM.begin(); iter != sbt_uJj3uszSCqXz4I_BeeUoM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.begin(); iter != sbt_mYQ5Qw6NSJz27HRSLQUsaM2Azllgu43tg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bRHjkEhi0FyzK2s")).IsNOK())
		{
			return status;
		}
		for (sbt_D2lgRi655HoJQnFlCbXM6T3AtbEArray::const_iterator iter = sbt_bRHjkEhi0FyzK2s.begin(); iter != sbt_bRHjkEhi0FyzK2s.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32>::Type sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32Array;

