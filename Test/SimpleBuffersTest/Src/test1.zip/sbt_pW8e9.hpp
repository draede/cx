
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR.hpp"


class sbt_pW8e9 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h;
	CX::IO::SimpleBuffers::Int64Array sbt_lZjYwt_PKqleKQYxqMw;
	CX::Int32 sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs;
	CX::Int32 sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK;
	CX::Float sbt_OWqGfSNvhzuIlVr;
	CX::IO::SimpleBuffers::Int8Array sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ;
	CX::IO::SimpleBuffers::Int16Array sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5;
	CX::IO::SimpleBuffers::Int32Array sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG;
	CX::IO::SimpleBuffers::Int8Array sbt_XoZLj;
	CX::Bool sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA;
	CX::Bool sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H;
	CX::Bool sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8;
	CX::Float sbt_97wMBfGq4NWk7;
	CX::WString sbt_2eHVKwkrf20;
	CX::IO::SimpleBuffers::UInt16Array sbt_guO0_3Ah5vL;
	CX::Int8 sbt_N30Dvfccr;
	CX::IO::SimpleBuffers::FloatArray sbt_ZGstx;
	CX::Int64 sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An;
	CX::IO::SimpleBuffers::UInt16Array sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo;
	CX::String sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa;
	CX::IO::SimpleBuffers::Int8Array sbt_7_cHi13ePWiwH2j;
	sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR sbt_mR5Qy;

	virtual void Reset()
	{
		sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h = 0.0;
		sbt_lZjYwt_PKqleKQYxqMw.clear();
		sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs = 0;
		sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK = 0;
		sbt_OWqGfSNvhzuIlVr = 0.0f;
		sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.clear();
		sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.clear();
		sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.clear();
		sbt_XoZLj.clear();
		sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA = false;
		sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H = false;
		sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8 = false;
		sbt_97wMBfGq4NWk7 = 0.0f;
		sbt_2eHVKwkrf20.clear();
		sbt_guO0_3Ah5vL.clear();
		sbt_N30Dvfccr = 0;
		sbt_ZGstx.clear();
		sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An = 0;
		sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.clear();
		sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa.clear();
		sbt_7_cHi13ePWiwH2j.clear();
		sbt_mR5Qy.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h = 0.030132;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_lZjYwt_PKqleKQYxqMw.push_back(6088823525661216784);
		}
		sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs = 345061958;
		sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK = -1116074224;
		sbt_OWqGfSNvhzuIlVr = 0.578451f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.push_back(-35);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.push_back(-31159);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_XoZLj.push_back(44);
		}
		sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA = false;
		sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H = true;
		sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8 = false;
		sbt_97wMBfGq4NWk7 = 0.035069f;
		sbt_2eHVKwkrf20 = L"$wlJme.lj8ZK+#)L0%}B^&$cpja'7#g#m0`tDgefbG/ehsLwRuk[LrrnS#*4cP|)";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_guO0_3Ah5vL.push_back(4);
		}
		sbt_N30Dvfccr = 91;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_ZGstx.push_back(0.554440f);
		}
		sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An = -5460854809592013594;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.push_back(14229);
		}
		sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa = "`|F:pT%m~wl8q3d^t";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_7_cHi13ePWiwH2j.push_back(0);
		}
		sbt_mR5Qy.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_pW8e9 *pObject = dynamic_cast<const sbt_pW8e9 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h != pObject->sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h)
		{
			return false;
		}
		if (sbt_lZjYwt_PKqleKQYxqMw.size() != pObject->sbt_lZjYwt_PKqleKQYxqMw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lZjYwt_PKqleKQYxqMw.size(); i++)
		{
			if (sbt_lZjYwt_PKqleKQYxqMw[i] != pObject->sbt_lZjYwt_PKqleKQYxqMw[i])
			{
				return false;
			}
		}
		if (sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs != pObject->sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs)
		{
			return false;
		}
		if (sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK != pObject->sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK)
		{
			return false;
		}
		if (sbt_OWqGfSNvhzuIlVr != pObject->sbt_OWqGfSNvhzuIlVr)
		{
			return false;
		}
		if (sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.size() != pObject->sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.size(); i++)
		{
			if (sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ[i] != pObject->sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ[i])
			{
				return false;
			}
		}
		if (sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.size() != pObject->sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.size(); i++)
		{
			if (sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5[i] != pObject->sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5[i])
			{
				return false;
			}
		}
		if (sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.size() != pObject->sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.size(); i++)
		{
			if (sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG[i] != pObject->sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG[i])
			{
				return false;
			}
		}
		if (sbt_XoZLj.size() != pObject->sbt_XoZLj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XoZLj.size(); i++)
		{
			if (sbt_XoZLj[i] != pObject->sbt_XoZLj[i])
			{
				return false;
			}
		}
		if (sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA != pObject->sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA)
		{
			return false;
		}
		if (sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H != pObject->sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H)
		{
			return false;
		}
		if (sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8 != pObject->sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8)
		{
			return false;
		}
		if (sbt_97wMBfGq4NWk7 != pObject->sbt_97wMBfGq4NWk7)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_2eHVKwkrf20.c_str(), pObject->sbt_2eHVKwkrf20.c_str()))
		{
			return false;
		}
		if (sbt_guO0_3Ah5vL.size() != pObject->sbt_guO0_3Ah5vL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_guO0_3Ah5vL.size(); i++)
		{
			if (sbt_guO0_3Ah5vL[i] != pObject->sbt_guO0_3Ah5vL[i])
			{
				return false;
			}
		}
		if (sbt_N30Dvfccr != pObject->sbt_N30Dvfccr)
		{
			return false;
		}
		if (sbt_ZGstx.size() != pObject->sbt_ZGstx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZGstx.size(); i++)
		{
			if (sbt_ZGstx[i] != pObject->sbt_ZGstx[i])
			{
				return false;
			}
		}
		if (sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An != pObject->sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An)
		{
			return false;
		}
		if (sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.size() != pObject->sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.size(); i++)
		{
			if (sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo[i] != pObject->sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa.c_str(), pObject->sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa.c_str()))
		{
			return false;
		}
		if (sbt_7_cHi13ePWiwH2j.size() != pObject->sbt_7_cHi13ePWiwH2j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7_cHi13ePWiwH2j.size(); i++)
		{
			if (sbt_7_cHi13ePWiwH2j[i] != pObject->sbt_7_cHi13ePWiwH2j[i])
			{
				return false;
			}
		}
		if (!sbt_mR5Qy.Compare(&pObject->sbt_mR5Qy))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_lZjYwt_PKqleKQYxqMw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lZjYwt_PKqleKQYxqMw.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_OWqGfSNvhzuIlVr", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_OWqGfSNvhzuIlVr = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XoZLj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XoZLj.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA", &sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H", &sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8", &sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_97wMBfGq4NWk7", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_97wMBfGq4NWk7 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_2eHVKwkrf20", &sbt_2eHVKwkrf20)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_guO0_3Ah5vL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_guO0_3Ah5vL.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_N30Dvfccr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N30Dvfccr = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZGstx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZGstx.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa", &sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7_cHi13ePWiwH2j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7_cHi13ePWiwH2j.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_mR5Qy")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_mR5Qy.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h", (CX::Double)sbt_N54fhdbMYOJp6MhItbNpPzeuIhPSneLSA6h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lZjYwt_PKqleKQYxqMw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_lZjYwt_PKqleKQYxqMw.begin(); iter != sbt_lZjYwt_PKqleKQYxqMw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs", (CX::Int64)sbt_iv7U0p09hP8QFwArJaqHzuve8PKauFfWbzt18_m7HQhh2G3K8fPsxcRSMPav3hs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK", (CX::Int64)sbt_Bmc3zdMQ__cKE4o5E7WO2t15V7wpZ6I78wHewNaOCie3x7QnIZVS33pZOLFirbK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_OWqGfSNvhzuIlVr", (CX::Double)sbt_OWqGfSNvhzuIlVr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.begin(); iter != sbt_4VjCa5NsXBuL2peBwtYG_aiUriQtGQ8lh_yvmYOvBiweXvZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.begin(); iter != sbt_TekTfV14sARAIDJsN0jJhdGInr_2PHQNbuX3w0VvxGvin12OnJklDT5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.begin(); iter != sbt_KAKAdAM_o1f_BcuG2GtONMjB2X5RB6TayuvRzaVh16WG8XQ5OpuWG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XoZLj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_XoZLj.begin(); iter != sbt_XoZLj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA", sbt_krAE5EDrWjMNrTYPlJrFPd9fnLeujAQw5xDAuhA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H", sbt_XOCk_ctvGsqaIvNVElWEJiDOLS6fCQ_UMUBNeHP9Hoo6H)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8", sbt_SassoHSC1msnNR6PWryaIbf5rxBoq505sqkZuvEgBW2bPlE_YLLg8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_97wMBfGq4NWk7", (CX::Double)sbt_97wMBfGq4NWk7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_2eHVKwkrf20", sbt_2eHVKwkrf20.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_guO0_3Ah5vL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_guO0_3Ah5vL.begin(); iter != sbt_guO0_3Ah5vL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N30Dvfccr", (CX::Int64)sbt_N30Dvfccr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZGstx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_ZGstx.begin(); iter != sbt_ZGstx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An", (CX::Int64)sbt_UfrkJ7DSz1JnnNHVrX7ohIQLOkMecsYKVYnQ3RSnBSWpUr1An)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.begin(); iter != sbt_ctpG7OzIF63foSJYqALRL2ZkPUwDLcSM5Lausxm7nyVIo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa", sbt_YQ62z8sbWpOUL6axR0OJeWtB7B57hNHIFFa.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7_cHi13ePWiwH2j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_7_cHi13ePWiwH2j.begin(); iter != sbt_7_cHi13ePWiwH2j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_mR5Qy")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_mR5Qy.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_pW8e9>::Type sbt_pW8e9Array;

