
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o.hpp"


class sbt_5hVHTBsND_PpC_8rJzrElet : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc;
	CX::IO::SimpleBuffers::BoolArray sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5;
	CX::IO::SimpleBuffers::UInt16Array sbt_nMZPN4dGhuubLF_;
	CX::UInt32 sbt_OWppAPdbFpzxl4SdCaRP5;
	CX::Int8 sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8;
	CX::UInt8 sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o;
	CX::IO::SimpleBuffers::Int64Array sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f;
	CX::UInt32 sbt_BO6rm;
	CX::IO::SimpleBuffers::UInt16Array sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e;
	CX::IO::SimpleBuffers::FloatArray sbt_vYTKKIbjS7Gun;
	CX::IO::SimpleBuffers::WStringArray sbt_eKGlQHEm1gFqEYPgkmhYIJBzW;
	CX::IO::SimpleBuffers::Int32Array sbt_DoE3M40DQXPMyfE;
	CX::IO::SimpleBuffers::UInt32Array sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324;
	CX::IO::SimpleBuffers::StringArray sbt_rRrcW;
	CX::Int32 sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL;
	sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8oArray sbt_4DJ0F10x_cqv57A;

	virtual void Reset()
	{
		sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc = 0.0;
		sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.clear();
		sbt_nMZPN4dGhuubLF_.clear();
		sbt_OWppAPdbFpzxl4SdCaRP5 = 0;
		sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8 = 0;
		sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o = 0;
		sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.clear();
		sbt_BO6rm = 0;
		sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.clear();
		sbt_vYTKKIbjS7Gun.clear();
		sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.clear();
		sbt_DoE3M40DQXPMyfE.clear();
		sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.clear();
		sbt_rRrcW.clear();
		sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL = 0;
		sbt_4DJ0F10x_cqv57A.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc = 0.924887;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.push_back(true);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_nMZPN4dGhuubLF_.push_back(21563);
		}
		sbt_OWppAPdbFpzxl4SdCaRP5 = 487273377;
		sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8 = 84;
		sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o = 52;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.push_back(4320309547330924854);
		}
		sbt_BO6rm = 2589367895;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.push_back(26037);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_vYTKKIbjS7Gun.push_back(0.483934f);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.push_back(L"MTPI7VmXu!#J6|&y5b%c>23N`");
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_DoE3M40DQXPMyfE.push_back(69271948);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.push_back(2257917531);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_rRrcW.push_back("QF#_-r");
		}
		sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL = 838786981;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o v;

			v.SetupWithSomeValues();
			sbt_4DJ0F10x_cqv57A.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_5hVHTBsND_PpC_8rJzrElet *pObject = dynamic_cast<const sbt_5hVHTBsND_PpC_8rJzrElet *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc != pObject->sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc)
		{
			return false;
		}
		if (sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.size() != pObject->sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.size(); i++)
		{
			if (sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5[i] != pObject->sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5[i])
			{
				return false;
			}
		}
		if (sbt_nMZPN4dGhuubLF_.size() != pObject->sbt_nMZPN4dGhuubLF_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nMZPN4dGhuubLF_.size(); i++)
		{
			if (sbt_nMZPN4dGhuubLF_[i] != pObject->sbt_nMZPN4dGhuubLF_[i])
			{
				return false;
			}
		}
		if (sbt_OWppAPdbFpzxl4SdCaRP5 != pObject->sbt_OWppAPdbFpzxl4SdCaRP5)
		{
			return false;
		}
		if (sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8 != pObject->sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8)
		{
			return false;
		}
		if (sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o != pObject->sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o)
		{
			return false;
		}
		if (sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.size() != pObject->sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.size(); i++)
		{
			if (sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f[i] != pObject->sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f[i])
			{
				return false;
			}
		}
		if (sbt_BO6rm != pObject->sbt_BO6rm)
		{
			return false;
		}
		if (sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.size() != pObject->sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.size(); i++)
		{
			if (sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e[i] != pObject->sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e[i])
			{
				return false;
			}
		}
		if (sbt_vYTKKIbjS7Gun.size() != pObject->sbt_vYTKKIbjS7Gun.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vYTKKIbjS7Gun.size(); i++)
		{
			if (sbt_vYTKKIbjS7Gun[i] != pObject->sbt_vYTKKIbjS7Gun[i])
			{
				return false;
			}
		}
		if (sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.size() != pObject->sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_eKGlQHEm1gFqEYPgkmhYIJBzW[i].c_str(), pObject->sbt_eKGlQHEm1gFqEYPgkmhYIJBzW[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_DoE3M40DQXPMyfE.size() != pObject->sbt_DoE3M40DQXPMyfE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DoE3M40DQXPMyfE.size(); i++)
		{
			if (sbt_DoE3M40DQXPMyfE[i] != pObject->sbt_DoE3M40DQXPMyfE[i])
			{
				return false;
			}
		}
		if (sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.size() != pObject->sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.size(); i++)
		{
			if (sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324[i] != pObject->sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324[i])
			{
				return false;
			}
		}
		if (sbt_rRrcW.size() != pObject->sbt_rRrcW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rRrcW.size(); i++)
		{
			if (0 != cx_strcmp(sbt_rRrcW[i].c_str(), pObject->sbt_rRrcW[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL != pObject->sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL)
		{
			return false;
		}
		if (sbt_4DJ0F10x_cqv57A.size() != pObject->sbt_4DJ0F10x_cqv57A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4DJ0F10x_cqv57A.size(); i++)
		{
			if (!sbt_4DJ0F10x_cqv57A[i].Compare(&pObject->sbt_4DJ0F10x_cqv57A[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nMZPN4dGhuubLF_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nMZPN4dGhuubLF_.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OWppAPdbFpzxl4SdCaRP5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OWppAPdbFpzxl4SdCaRP5 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BO6rm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BO6rm = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vYTKKIbjS7Gun")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vYTKKIbjS7Gun.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eKGlQHEm1gFqEYPgkmhYIJBzW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DoE3M40DQXPMyfE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DoE3M40DQXPMyfE.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rRrcW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rRrcW.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4DJ0F10x_cqv57A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_4DJ0F10x_cqv57A.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc", (CX::Double)sbt_fZeQtZ92KjbcfQTjCoVxjbOAHqxIbEPOezpb3mN0kE_KctjZQavVc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.begin(); iter != sbt_mdnmEI5jlE8YEJQGQGm6WhcO24GeTsDv5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nMZPN4dGhuubLF_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_nMZPN4dGhuubLF_.begin(); iter != sbt_nMZPN4dGhuubLF_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OWppAPdbFpzxl4SdCaRP5", (CX::Int64)sbt_OWppAPdbFpzxl4SdCaRP5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8", (CX::Int64)sbt_Wzzj5bhtejcCuCOFATIHAKbtfFhKjZnbcU8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o", (CX::Int64)sbt_lMz4w5s1KGNndfZIFjHewqfZfcGBfN52xHBZssi8Ta08GHInsQKTYu33o)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.begin(); iter != sbt_Ontw8AdwG1gwDHDcMqJpXIpoD94QF_LmljJ54U96f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BO6rm", (CX::Int64)sbt_BO6rm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.begin(); iter != sbt_SQwh09kqtuB8JJ4jwmU6X_d6ddIZzieSQ0e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vYTKKIbjS7Gun")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_vYTKKIbjS7Gun.begin(); iter != sbt_vYTKKIbjS7Gun.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eKGlQHEm1gFqEYPgkmhYIJBzW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.begin(); iter != sbt_eKGlQHEm1gFqEYPgkmhYIJBzW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DoE3M40DQXPMyfE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_DoE3M40DQXPMyfE.begin(); iter != sbt_DoE3M40DQXPMyfE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.begin(); iter != sbt_5JxBzw9ah6g36wMicE2weYtv47aGeDUMVJeR5G0SV32H8bfF324.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rRrcW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_rRrcW.begin(); iter != sbt_rRrcW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL", (CX::Int64)sbt_EhtUf_AelgKe2mMm52YAsc9Lx9694sHxrr_HOAdcrPCWL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4DJ0F10x_cqv57A")).IsNOK())
		{
			return status;
		}
		for (sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8oArray::const_iterator iter = sbt_4DJ0F10x_cqv57A.begin(); iter != sbt_4DJ0F10x_cqv57A.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_5hVHTBsND_PpC_8rJzrElet>::Type sbt_5hVHTBsND_PpC_8rJzrEletArray;

