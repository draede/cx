
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_0Mk8Rck1rfINzZy.hpp"


class sbt_USEHjC3o8yvTt8_CGExNNTI : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0;
	CX::Int64 sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX;
	CX::IO::SimpleBuffers::UInt32Array sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD;
	CX::Int32 sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y;
	sbt_0Mk8Rck1rfINzZy sbt_WALarebVwVIsYATJj2qo8SIPf;

	virtual void Reset()
	{
		sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.clear();
		sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX = 0;
		sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.clear();
		sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y = 0;
		sbt_WALarebVwVIsYATJj2qo8SIPf.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX = -4778254415196758762;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.push_back(4161538943);
		}
		sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y = 1174617048;
		sbt_WALarebVwVIsYATJj2qo8SIPf.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_USEHjC3o8yvTt8_CGExNNTI *pObject = dynamic_cast<const sbt_USEHjC3o8yvTt8_CGExNNTI *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.size() != pObject->sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.size(); i++)
		{
			if (sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0[i] != pObject->sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0[i])
			{
				return false;
			}
		}
		if (sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX != pObject->sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX)
		{
			return false;
		}
		if (sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.size() != pObject->sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.size(); i++)
		{
			if (sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD[i] != pObject->sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD[i])
			{
				return false;
			}
		}
		if (sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y != pObject->sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y)
		{
			return false;
		}
		if (!sbt_WALarebVwVIsYATJj2qo8SIPf.Compare(&pObject->sbt_WALarebVwVIsYATJj2qo8SIPf))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_WALarebVwVIsYATJj2qo8SIPf")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_WALarebVwVIsYATJj2qo8SIPf.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.begin(); iter != sbt_2MFBIRwmbuqWJS11jjFDhQZ7sZ1GCywAf8d50FHnIh5fVY0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX", (CX::Int64)sbt_HN_PF0ajc2jEXvmZUX4C8UDZRrtoNrOAWND9mePiX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.begin(); iter != sbt_IWBDYCbHo4gl0oMvUXzz2VZv6FkSbDRkcKPo1McLptLtb2mMgfD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y", (CX::Int64)sbt_PBopMpnh07d9GRz2lqDbolBIuCx2xMcg6MtsskspHbdyp7nOs9n9y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_WALarebVwVIsYATJj2qo8SIPf")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_WALarebVwVIsYATJj2qo8SIPf.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_USEHjC3o8yvTt8_CGExNNTI>::Type sbt_USEHjC3o8yvTt8_CGExNNTIArray;

