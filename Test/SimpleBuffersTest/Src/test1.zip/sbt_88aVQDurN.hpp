
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp.hpp"


class sbt_88aVQDurN : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_CkipfR5U_bFid3fDDQHCD1n;
	CX::IO::SimpleBuffers::BoolArray sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y;
	CX::IO::SimpleBuffers::BoolArray sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG;
	CX::IO::SimpleBuffers::UInt16Array sbt_Lku6IP4p183;
	CX::WString sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO;
	CX::IO::SimpleBuffers::Int8Array sbt_8WZCd;
	CX::IO::SimpleBuffers::UInt64Array sbt_ZmiVK_sbZ_W2M;
	CX::IO::SimpleBuffers::UInt8Array sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9;
	CX::UInt8 sbt_CclaTzFJhSspc;
	CX::IO::SimpleBuffers::Int16Array sbt_JtX;
	CX::Bool sbt_guqaLQ0E8Wj92;
	CX::IO::SimpleBuffers::UInt64Array sbt_JBX;
	CX::IO::SimpleBuffers::DoubleArray sbt_sTHW8KZt0;
	CX::UInt64 sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s;
	CX::IO::SimpleBuffers::Int8Array sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN;
	CX::Float sbt_VxdQI_yOPfMAnOyf9hi6vM6bO;
	CX::UInt32 sbt_W5gAXTR3SBPOfbLMPWx;
	CX::IO::SimpleBuffers::UInt32Array sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj;
	CX::String sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e;
	CX::IO::SimpleBuffers::Int64Array sbt_0G3EnPYb8jptNqk;
	CX::IO::SimpleBuffers::UInt16Array sbt_lHs3Qs0mUYyF6ElywqiSf7LX6;
	CX::IO::SimpleBuffers::Int8Array sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq;
	CX::UInt64 sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7;
	CX::IO::SimpleBuffers::UInt16Array sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut;
	CX::IO::SimpleBuffers::UInt16Array sbt_rfxY7iCRbyxW_1khAOymV;
	sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe;

	virtual void Reset()
	{
		sbt_CkipfR5U_bFid3fDDQHCD1n = 0.0;
		sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.clear();
		sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.clear();
		sbt_Lku6IP4p183.clear();
		sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO.clear();
		sbt_8WZCd.clear();
		sbt_ZmiVK_sbZ_W2M.clear();
		sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.clear();
		sbt_CclaTzFJhSspc = 0;
		sbt_JtX.clear();
		sbt_guqaLQ0E8Wj92 = false;
		sbt_JBX.clear();
		sbt_sTHW8KZt0.clear();
		sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s = 0;
		sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.clear();
		sbt_VxdQI_yOPfMAnOyf9hi6vM6bO = 0.0f;
		sbt_W5gAXTR3SBPOfbLMPWx = 0;
		sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.clear();
		sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e.clear();
		sbt_0G3EnPYb8jptNqk.clear();
		sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.clear();
		sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.clear();
		sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7 = 0;
		sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.clear();
		sbt_rfxY7iCRbyxW_1khAOymV.clear();
		sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_CkipfR5U_bFid3fDDQHCD1n = 0.299168;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.push_back(false);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.push_back(false);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Lku6IP4p183.push_back(6870);
		}
		sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO = L"lHQrT=X$lZF2=V]cMTfHO,iR:1pa-45u]}";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_8WZCd.push_back(-60);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ZmiVK_sbZ_W2M.push_back(9187025775905231684);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.push_back(240);
		}
		sbt_CclaTzFJhSspc = 38;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_JtX.push_back(-15299);
		}
		sbt_guqaLQ0E8Wj92 = false;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_JBX.push_back(7494751746522626506);
		}
		sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s = 9173742875162981594;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.push_back(-10);
		}
		sbt_VxdQI_yOPfMAnOyf9hi6vM6bO = 0.478252f;
		sbt_W5gAXTR3SBPOfbLMPWx = 2905248849;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.push_back(3109417158);
		}
		sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e = ")T";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_0G3EnPYb8jptNqk.push_back(-8049198697691208328);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.push_back(56634);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.push_back(-5);
		}
		sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7 = 10715359013826510506;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.push_back(7290);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_rfxY7iCRbyxW_1khAOymV.push_back(15950);
		}
		sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_88aVQDurN *pObject = dynamic_cast<const sbt_88aVQDurN *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_CkipfR5U_bFid3fDDQHCD1n != pObject->sbt_CkipfR5U_bFid3fDDQHCD1n)
		{
			return false;
		}
		if (sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.size() != pObject->sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.size(); i++)
		{
			if (sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y[i] != pObject->sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y[i])
			{
				return false;
			}
		}
		if (sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.size() != pObject->sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.size(); i++)
		{
			if (sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG[i] != pObject->sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG[i])
			{
				return false;
			}
		}
		if (sbt_Lku6IP4p183.size() != pObject->sbt_Lku6IP4p183.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Lku6IP4p183.size(); i++)
		{
			if (sbt_Lku6IP4p183[i] != pObject->sbt_Lku6IP4p183[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO.c_str(), pObject->sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO.c_str()))
		{
			return false;
		}
		if (sbt_8WZCd.size() != pObject->sbt_8WZCd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8WZCd.size(); i++)
		{
			if (sbt_8WZCd[i] != pObject->sbt_8WZCd[i])
			{
				return false;
			}
		}
		if (sbt_ZmiVK_sbZ_W2M.size() != pObject->sbt_ZmiVK_sbZ_W2M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZmiVK_sbZ_W2M.size(); i++)
		{
			if (sbt_ZmiVK_sbZ_W2M[i] != pObject->sbt_ZmiVK_sbZ_W2M[i])
			{
				return false;
			}
		}
		if (sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.size() != pObject->sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.size(); i++)
		{
			if (sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9[i] != pObject->sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9[i])
			{
				return false;
			}
		}
		if (sbt_CclaTzFJhSspc != pObject->sbt_CclaTzFJhSspc)
		{
			return false;
		}
		if (sbt_JtX.size() != pObject->sbt_JtX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JtX.size(); i++)
		{
			if (sbt_JtX[i] != pObject->sbt_JtX[i])
			{
				return false;
			}
		}
		if (sbt_guqaLQ0E8Wj92 != pObject->sbt_guqaLQ0E8Wj92)
		{
			return false;
		}
		if (sbt_JBX.size() != pObject->sbt_JBX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JBX.size(); i++)
		{
			if (sbt_JBX[i] != pObject->sbt_JBX[i])
			{
				return false;
			}
		}
		if (sbt_sTHW8KZt0.size() != pObject->sbt_sTHW8KZt0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sTHW8KZt0.size(); i++)
		{
			if (sbt_sTHW8KZt0[i] != pObject->sbt_sTHW8KZt0[i])
			{
				return false;
			}
		}
		if (sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s != pObject->sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s)
		{
			return false;
		}
		if (sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.size() != pObject->sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.size(); i++)
		{
			if (sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN[i] != pObject->sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN[i])
			{
				return false;
			}
		}
		if (sbt_VxdQI_yOPfMAnOyf9hi6vM6bO != pObject->sbt_VxdQI_yOPfMAnOyf9hi6vM6bO)
		{
			return false;
		}
		if (sbt_W5gAXTR3SBPOfbLMPWx != pObject->sbt_W5gAXTR3SBPOfbLMPWx)
		{
			return false;
		}
		if (sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.size() != pObject->sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.size(); i++)
		{
			if (sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj[i] != pObject->sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e.c_str(), pObject->sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e.c_str()))
		{
			return false;
		}
		if (sbt_0G3EnPYb8jptNqk.size() != pObject->sbt_0G3EnPYb8jptNqk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0G3EnPYb8jptNqk.size(); i++)
		{
			if (sbt_0G3EnPYb8jptNqk[i] != pObject->sbt_0G3EnPYb8jptNqk[i])
			{
				return false;
			}
		}
		if (sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.size() != pObject->sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.size(); i++)
		{
			if (sbt_lHs3Qs0mUYyF6ElywqiSf7LX6[i] != pObject->sbt_lHs3Qs0mUYyF6ElywqiSf7LX6[i])
			{
				return false;
			}
		}
		if (sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.size() != pObject->sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.size(); i++)
		{
			if (sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq[i] != pObject->sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq[i])
			{
				return false;
			}
		}
		if (sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7 != pObject->sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7)
		{
			return false;
		}
		if (sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.size() != pObject->sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.size(); i++)
		{
			if (sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut[i] != pObject->sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut[i])
			{
				return false;
			}
		}
		if (sbt_rfxY7iCRbyxW_1khAOymV.size() != pObject->sbt_rfxY7iCRbyxW_1khAOymV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rfxY7iCRbyxW_1khAOymV.size(); i++)
		{
			if (sbt_rfxY7iCRbyxW_1khAOymV[i] != pObject->sbt_rfxY7iCRbyxW_1khAOymV[i])
			{
				return false;
			}
		}
		if (!sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe.Compare(&pObject->sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_CkipfR5U_bFid3fDDQHCD1n", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_CkipfR5U_bFid3fDDQHCD1n = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Lku6IP4p183")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Lku6IP4p183.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO", &sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8WZCd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8WZCd.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZmiVK_sbZ_W2M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZmiVK_sbZ_W2M.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CclaTzFJhSspc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CclaTzFJhSspc = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JtX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JtX.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_guqaLQ0E8Wj92", &sbt_guqaLQ0E8Wj92)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JBX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JBX.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sTHW8KZt0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sTHW8KZt0.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_VxdQI_yOPfMAnOyf9hi6vM6bO", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_VxdQI_yOPfMAnOyf9hi6vM6bO = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_W5gAXTR3SBPOfbLMPWx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_W5gAXTR3SBPOfbLMPWx = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e", &sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0G3EnPYb8jptNqk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0G3EnPYb8jptNqk.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lHs3Qs0mUYyF6ElywqiSf7LX6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rfxY7iCRbyxW_1khAOymV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rfxY7iCRbyxW_1khAOymV.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_CkipfR5U_bFid3fDDQHCD1n", (CX::Double)sbt_CkipfR5U_bFid3fDDQHCD1n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.begin(); iter != sbt_nm0rXZVimXum9yhpTWubWkqqWRX8y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.begin(); iter != sbt_0Zt6bqMCxjNpEQu9qxBrS4w6bFiV_vioNIKxQ5CBlP2J0HGNK9WJZVkdG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Lku6IP4p183")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Lku6IP4p183.begin(); iter != sbt_Lku6IP4p183.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO", sbt_kt0dxtVcPNAkKa7BbkrPMqYWCsyWJgnF4ClL8lO.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8WZCd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_8WZCd.begin(); iter != sbt_8WZCd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZmiVK_sbZ_W2M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ZmiVK_sbZ_W2M.begin(); iter != sbt_ZmiVK_sbZ_W2M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.begin(); iter != sbt_88bBu9mgWdh89wSHMyVET24R0aB5fr92MehQpL9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CclaTzFJhSspc", (CX::Int64)sbt_CclaTzFJhSspc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JtX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_JtX.begin(); iter != sbt_JtX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_guqaLQ0E8Wj92", sbt_guqaLQ0E8Wj92)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JBX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_JBX.begin(); iter != sbt_JBX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sTHW8KZt0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_sTHW8KZt0.begin(); iter != sbt_sTHW8KZt0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s", (CX::Int64)sbt_F0FRAqQsMNexcEL2rUG5z0ise7T4iQPrnA7nb0s)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.begin(); iter != sbt_cIt_77tagAcXJVEoh5lKFUqLgtqYkhxPJighzA2ZjLWTeJToN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_VxdQI_yOPfMAnOyf9hi6vM6bO", (CX::Double)sbt_VxdQI_yOPfMAnOyf9hi6vM6bO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_W5gAXTR3SBPOfbLMPWx", (CX::Int64)sbt_W5gAXTR3SBPOfbLMPWx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.begin(); iter != sbt_TcIDJgQ_z3FgpRQ68nuhi4OVJQPjSoAU61UlVtbv4FNKeB74qOW4ZFj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e", sbt_oEof9e_8w5dhalCF5uKwxvTjscc5e.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0G3EnPYb8jptNqk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_0G3EnPYb8jptNqk.begin(); iter != sbt_0G3EnPYb8jptNqk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lHs3Qs0mUYyF6ElywqiSf7LX6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.begin(); iter != sbt_lHs3Qs0mUYyF6ElywqiSf7LX6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.begin(); iter != sbt_BueLuqBAuM1MMjh1bwAMgnDaj4fTar_fkcbN5bEMv3wh3z6xiyq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7", (CX::Int64)sbt_BGz3y8kRqRC7CzEHm3vzwWnedlyBKADbdM7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.begin(); iter != sbt__F4IPlRR9cqZvKO4mJbUNGhq0ut.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rfxY7iCRbyxW_1khAOymV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_rfxY7iCRbyxW_1khAOymV.begin(); iter != sbt_rfxY7iCRbyxW_1khAOymV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_UGrDWK7dAs7aU_l7XRD2CEawsBOqZIvmmzIzfH69N0wG8YmZOl5ic_MAeHe.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_88aVQDurN>::Type sbt_88aVQDurNArray;

