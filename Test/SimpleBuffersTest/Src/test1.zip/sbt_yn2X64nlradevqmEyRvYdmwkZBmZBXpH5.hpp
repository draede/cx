
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_mpw5B;
	CX::UInt16 sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv;
	CX::String sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv;
	CX::UInt8 sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8;
	CX::IO::SimpleBuffers::Int32Array sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt;
	CX::IO::SimpleBuffers::UInt8Array sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2;
	CX::Int64 sbt_kvY8WS9KH;
	CX::UInt64 sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T;
	CX::UInt32 sbt_Aj5KaGO1NKHNGVS;
	CX::IO::SimpleBuffers::UInt32Array sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_;
	CX::IO::SimpleBuffers::StringArray sbt_xvEIHkNN8i2vHMMQsbrv01f;
	CX::UInt64 sbt_PTJUzoHZydY_3nAmE68I44ZhU;
	CX::UInt64 sbt_b6jbHhT1FmxXn7JbjWjNWAele;
	CX::IO::SimpleBuffers::UInt16Array sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp;
	CX::UInt32 sbt_Av51KPdHKCzZ0;
	CX::UInt64 sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7;
	CX::Int8 sbt_aIS;
	CX::Bool sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197;
	CX::IO::SimpleBuffers::Int32Array sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e;
	CX::UInt64 sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh;
	CX::IO::SimpleBuffers::Int64Array sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm;
	CX::UInt32 sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN;
	CX::UInt16 sbt_i7cqi2_;
	CX::IO::SimpleBuffers::Int16Array sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm;
	CX::Bool sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd;
	CX::IO::SimpleBuffers::UInt64Array sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X;
	CX::String sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L;
	CX::UInt16 sbt_I1KZMEOmgllwVf9CAa9N8M2V9;
	CX::IO::SimpleBuffers::UInt16Array sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6;

	virtual void Reset()
	{
		sbt_mpw5B = 0;
		sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv = 0;
		sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv.clear();
		sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8 = 0;
		sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.clear();
		sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.clear();
		sbt_kvY8WS9KH = 0;
		sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T = 0;
		sbt_Aj5KaGO1NKHNGVS = 0;
		sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.clear();
		sbt_xvEIHkNN8i2vHMMQsbrv01f.clear();
		sbt_PTJUzoHZydY_3nAmE68I44ZhU = 0;
		sbt_b6jbHhT1FmxXn7JbjWjNWAele = 0;
		sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.clear();
		sbt_Av51KPdHKCzZ0 = 0;
		sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7 = 0;
		sbt_aIS = 0;
		sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197 = false;
		sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.clear();
		sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh = 0;
		sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.clear();
		sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN = 0;
		sbt_i7cqi2_ = 0;
		sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.clear();
		sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd = false;
		sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.clear();
		sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L.clear();
		sbt_I1KZMEOmgllwVf9CAa9N8M2V9 = 0;
		sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_mpw5B = 20619;
		sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv = 46100;
		sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv = "?6A/QCkEV:HI4y85yrI]";
		sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8 = 239;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.push_back(363753185);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.push_back(205);
		}
		sbt_kvY8WS9KH = 6246940032564211920;
		sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T = 6605946284207445508;
		sbt_Aj5KaGO1NKHNGVS = 2836573529;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.push_back(2475696827);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_xvEIHkNN8i2vHMMQsbrv01f.push_back("IY(g\\r-[<0lM^R7w1,9}J|oZe)in_4l#`Rt8q_|");
		}
		sbt_PTJUzoHZydY_3nAmE68I44ZhU = 14383275880309848276;
		sbt_b6jbHhT1FmxXn7JbjWjNWAele = 17663623196155719454;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.push_back(48608);
		}
		sbt_Av51KPdHKCzZ0 = 2429203147;
		sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7 = 7355900392165302000;
		sbt_aIS = 84;
		sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197 = false;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.push_back(1850178628);
		}
		sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh = 14201466857541784636;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.push_back(-5577721403616596702);
		}
		sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN = 696710509;
		sbt_i7cqi2_ = 1215;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.push_back(-24984);
		}
		sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd = true;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.push_back(1156901406434387942);
		}
		sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L = "fxRc?N|Sd`+]LDi.T9vQ7~h=;SleB^Y0is#vkAs=|3E'{8-mNJa\\C%X*zmd6*,";
		sbt_I1KZMEOmgllwVf9CAa9N8M2V9 = 15306;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.push_back(42429);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5 *pObject = dynamic_cast<const sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_mpw5B != pObject->sbt_mpw5B)
		{
			return false;
		}
		if (sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv != pObject->sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv.c_str(), pObject->sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv.c_str()))
		{
			return false;
		}
		if (sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8 != pObject->sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8)
		{
			return false;
		}
		if (sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.size() != pObject->sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.size(); i++)
		{
			if (sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt[i] != pObject->sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt[i])
			{
				return false;
			}
		}
		if (sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.size() != pObject->sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.size(); i++)
		{
			if (sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2[i] != pObject->sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2[i])
			{
				return false;
			}
		}
		if (sbt_kvY8WS9KH != pObject->sbt_kvY8WS9KH)
		{
			return false;
		}
		if (sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T != pObject->sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T)
		{
			return false;
		}
		if (sbt_Aj5KaGO1NKHNGVS != pObject->sbt_Aj5KaGO1NKHNGVS)
		{
			return false;
		}
		if (sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.size() != pObject->sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.size(); i++)
		{
			if (sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_[i] != pObject->sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_[i])
			{
				return false;
			}
		}
		if (sbt_xvEIHkNN8i2vHMMQsbrv01f.size() != pObject->sbt_xvEIHkNN8i2vHMMQsbrv01f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xvEIHkNN8i2vHMMQsbrv01f.size(); i++)
		{
			if (0 != cx_strcmp(sbt_xvEIHkNN8i2vHMMQsbrv01f[i].c_str(), pObject->sbt_xvEIHkNN8i2vHMMQsbrv01f[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_PTJUzoHZydY_3nAmE68I44ZhU != pObject->sbt_PTJUzoHZydY_3nAmE68I44ZhU)
		{
			return false;
		}
		if (sbt_b6jbHhT1FmxXn7JbjWjNWAele != pObject->sbt_b6jbHhT1FmxXn7JbjWjNWAele)
		{
			return false;
		}
		if (sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.size() != pObject->sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.size(); i++)
		{
			if (sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp[i] != pObject->sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp[i])
			{
				return false;
			}
		}
		if (sbt_Av51KPdHKCzZ0 != pObject->sbt_Av51KPdHKCzZ0)
		{
			return false;
		}
		if (sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7 != pObject->sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7)
		{
			return false;
		}
		if (sbt_aIS != pObject->sbt_aIS)
		{
			return false;
		}
		if (sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197 != pObject->sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197)
		{
			return false;
		}
		if (sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.size() != pObject->sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.size(); i++)
		{
			if (sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e[i] != pObject->sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e[i])
			{
				return false;
			}
		}
		if (sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh != pObject->sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh)
		{
			return false;
		}
		if (sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.size() != pObject->sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.size(); i++)
		{
			if (sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm[i] != pObject->sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm[i])
			{
				return false;
			}
		}
		if (sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN != pObject->sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN)
		{
			return false;
		}
		if (sbt_i7cqi2_ != pObject->sbt_i7cqi2_)
		{
			return false;
		}
		if (sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.size() != pObject->sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.size(); i++)
		{
			if (sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm[i] != pObject->sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm[i])
			{
				return false;
			}
		}
		if (sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd != pObject->sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd)
		{
			return false;
		}
		if (sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.size() != pObject->sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.size(); i++)
		{
			if (sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X[i] != pObject->sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L.c_str(), pObject->sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L.c_str()))
		{
			return false;
		}
		if (sbt_I1KZMEOmgllwVf9CAa9N8M2V9 != pObject->sbt_I1KZMEOmgllwVf9CAa9N8M2V9)
		{
			return false;
		}
		if (sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.size() != pObject->sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.size(); i++)
		{
			if (sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6[i] != pObject->sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_mpw5B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mpw5B = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv", &sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kvY8WS9KH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kvY8WS9KH = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Aj5KaGO1NKHNGVS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Aj5KaGO1NKHNGVS = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xvEIHkNN8i2vHMMQsbrv01f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xvEIHkNN8i2vHMMQsbrv01f.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PTJUzoHZydY_3nAmE68I44ZhU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PTJUzoHZydY_3nAmE68I44ZhU = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_b6jbHhT1FmxXn7JbjWjNWAele", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b6jbHhT1FmxXn7JbjWjNWAele = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Av51KPdHKCzZ0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Av51KPdHKCzZ0 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_aIS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aIS = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197", &sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_i7cqi2_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_i7cqi2_ = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd", &sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L", &sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_I1KZMEOmgllwVf9CAa9N8M2V9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I1KZMEOmgllwVf9CAa9N8M2V9 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_mpw5B", (CX::Int64)sbt_mpw5B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv", (CX::Int64)sbt_YVjNTVMgZYp0ydAsuYo5Rqif_h0ziDRplVYrhekoq4yotPMEfrv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv", sbt_JQJKMPRFoeMbMQCy0vmFxUm1KRZ1x8bZeHTV3gBcgj3hv.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8", (CX::Int64)sbt_9BGc_eDqBWOXCID1J9Cmn66lGIWMi9Nw2lWZUweZaVjN21kvpeXgnoMkWWP8yH8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.begin(); iter != sbt_cFUeyNdUd68IJybIpq7rgw63O0aJt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.begin(); iter != sbt_dEVsBZ8kttd4cCMs3uXSmJOxDT2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kvY8WS9KH", (CX::Int64)sbt_kvY8WS9KH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T", (CX::Int64)sbt_pF3kr1qdCPH2dBS7NcjK25JcL_RCIkuZDOxZh0nZBcroHGTuxBbBV6T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Aj5KaGO1NKHNGVS", (CX::Int64)sbt_Aj5KaGO1NKHNGVS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.begin(); iter != sbt_w1q1P68Daa3lYr2hfgZfxiEolFdtiLAsG0yyPgz2nDZefPFN_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xvEIHkNN8i2vHMMQsbrv01f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_xvEIHkNN8i2vHMMQsbrv01f.begin(); iter != sbt_xvEIHkNN8i2vHMMQsbrv01f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PTJUzoHZydY_3nAmE68I44ZhU", (CX::Int64)sbt_PTJUzoHZydY_3nAmE68I44ZhU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b6jbHhT1FmxXn7JbjWjNWAele", (CX::Int64)sbt_b6jbHhT1FmxXn7JbjWjNWAele)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.begin(); iter != sbt_NiFPDiGUzk7877SWkoJA4v6h9AMqRbsa7qjr4PlNED2ubIoSL3GXVFLBavg2lOp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Av51KPdHKCzZ0", (CX::Int64)sbt_Av51KPdHKCzZ0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7", (CX::Int64)sbt_rkk3zfUjXq7C0DspohCMSfYKBXhiWm7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aIS", (CX::Int64)sbt_aIS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197", sbt_iXl28_XLO4lwBEkMQd2aSCho8trqU8UrP_avUGxKR2YlfnYFzI0pVfDEPm6P197)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.begin(); iter != sbt_xHABidSeR6SRPInGpITsWCPvD4cUTbR8e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh", (CX::Int64)sbt_AzaHVR4bGUXD0voIm9DG9Ja_eCaYnCWrnuaedAZkuwSTPmh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.begin(); iter != sbt_qlB_0s8v47hym0mZtCKQFa5_m9R8C68F7CH7QuHuBr3jrEslPdY2a0Snm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN", (CX::Int64)sbt_eMFRKTafwAouaKvkGB6VXg9_PPf0zY8gOxWKKlfYnw2vrGXTy9V9CFRw8GN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_i7cqi2_", (CX::Int64)sbt_i7cqi2_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.begin(); iter != sbt_zG8Ur0cf4L0p0lVawaXvbKMtRQFkxoIaoatHhTnaV1Acm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd", sbt_IFTuiimJvNaezCMQ_Qd24TFVBd89jXvTrO1YWarTAawOQmBL9QHZQdd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.begin(); iter != sbt_Kv7gmisqIopLL66RyJ9oyBRHwyPXtFnAO7h57BR_ouGOBRDVhMO2btPlCb2ax3X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L", sbt_G_nfJEjW7li7ZjpRa1H21ZlDNMYnmQtujhkJ8lLRnvoT6ZDuhOpw9_L.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_I1KZMEOmgllwVf9CAa9N8M2V9", (CX::Int64)sbt_I1KZMEOmgllwVf9CAa9N8M2V9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.begin(); iter != sbt_yehw4_AmGvhStrqJ9XQFvs28XDG7o6fxfIkf0_6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5>::Type sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5Array;

