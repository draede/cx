
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_QAL : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB;

	virtual void Reset()
	{
		sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB = -2519;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_QAL *pObject = dynamic_cast<const sbt_QAL *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB != pObject->sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB = (CX::Int16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB", (CX::Int64)sbt_GAnTbOYvLy8sgeik6xG3wuarKzZK0CjgB)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_QAL>::Type sbt_QALArray;

