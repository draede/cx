
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_6mSKrq1ZBtodU8N : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_LSsaWuy;
	CX::UInt8 sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu;
	CX::IO::SimpleBuffers::UInt16Array sbt_iUtlG5jCD;
	CX::IO::SimpleBuffers::UInt64Array sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId;
	CX::IO::SimpleBuffers::UInt8Array sbt_AFhfsDE;
	CX::IO::SimpleBuffers::UInt8Array sbt_woDk6agauuf2BA_UG;
	CX::IO::SimpleBuffers::StringArray sbt_FrfhSkkWNEFSm3w_4;
	CX::IO::SimpleBuffers::UInt32Array sbt_j229BE9;
	CX::UInt16 sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA;
	CX::IO::SimpleBuffers::UInt64Array sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb;
	CX::Bool sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y;
	CX::Int64 sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW;
	CX::Int32 sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw;
	CX::Int16 sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO;
	CX::IO::SimpleBuffers::BoolArray sbt_Fy2y6k5carhsu8R7BXn0uU3r3;
	CX::UInt32 sbt_gQTvCPfMZRZ1fvtxzDXsaJq;
	CX::IO::SimpleBuffers::UInt16Array sbt_4lKf77yCcxNhH0B412Lsd;
	CX::IO::SimpleBuffers::Int8Array sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek;
	CX::Bool sbt_15hmlZzSkYqKgLlFMmBcBo4Z_;
	CX::UInt64 sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf;
	CX::UInt64 sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS;
	CX::Int16 sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw;
	CX::Int64 sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643;
	CX::IO::SimpleBuffers::Int8Array sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5;
	CX::IO::SimpleBuffers::UInt32Array sbt_n0aKoOoOV;
	CX::UInt8 sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y;

	virtual void Reset()
	{
		sbt_LSsaWuy = 0;
		sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu = 0;
		sbt_iUtlG5jCD.clear();
		sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.clear();
		sbt_AFhfsDE.clear();
		sbt_woDk6agauuf2BA_UG.clear();
		sbt_FrfhSkkWNEFSm3w_4.clear();
		sbt_j229BE9.clear();
		sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA = 0;
		sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.clear();
		sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y = false;
		sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW = 0;
		sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw = 0;
		sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO = 0;
		sbt_Fy2y6k5carhsu8R7BXn0uU3r3.clear();
		sbt_gQTvCPfMZRZ1fvtxzDXsaJq = 0;
		sbt_4lKf77yCcxNhH0B412Lsd.clear();
		sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.clear();
		sbt_15hmlZzSkYqKgLlFMmBcBo4Z_ = false;
		sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf = 0;
		sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS = 0;
		sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw = 0;
		sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643 = 0;
		sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.clear();
		sbt_n0aKoOoOV.clear();
		sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_LSsaWuy = 70;
		sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu = 73;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_iUtlG5jCD.push_back(29013);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.push_back(14044188873844309862);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_AFhfsDE.push_back(254);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_woDk6agauuf2BA_UG.push_back(147);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_FrfhSkkWNEFSm3w_4.push_back("@v|\\K5b_U@,nAl{6aZl&W2qGdceCoEN8|d}[f.?Cp_Ha`sU%^z[(y^(");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_j229BE9.push_back(1112002499);
		}
		sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA = 46590;
		sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y = true;
		sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW = 2870353382513344562;
		sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw = -1884561316;
		sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO = -11562;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Fy2y6k5carhsu8R7BXn0uU3r3.push_back(false);
		}
		sbt_gQTvCPfMZRZ1fvtxzDXsaJq = 2578916057;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4lKf77yCcxNhH0B412Lsd.push_back(9836);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.push_back(56);
		}
		sbt_15hmlZzSkYqKgLlFMmBcBo4Z_ = false;
		sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf = 8988475075081693516;
		sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS = 15319473265233705302;
		sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw = -22625;
		sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643 = 506087876390133310;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.push_back(-14);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_n0aKoOoOV.push_back(2980778695);
		}
		sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y = 54;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6mSKrq1ZBtodU8N *pObject = dynamic_cast<const sbt_6mSKrq1ZBtodU8N *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_LSsaWuy != pObject->sbt_LSsaWuy)
		{
			return false;
		}
		if (sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu != pObject->sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu)
		{
			return false;
		}
		if (sbt_iUtlG5jCD.size() != pObject->sbt_iUtlG5jCD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iUtlG5jCD.size(); i++)
		{
			if (sbt_iUtlG5jCD[i] != pObject->sbt_iUtlG5jCD[i])
			{
				return false;
			}
		}
		if (sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.size() != pObject->sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.size(); i++)
		{
			if (sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId[i] != pObject->sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId[i])
			{
				return false;
			}
		}
		if (sbt_AFhfsDE.size() != pObject->sbt_AFhfsDE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AFhfsDE.size(); i++)
		{
			if (sbt_AFhfsDE[i] != pObject->sbt_AFhfsDE[i])
			{
				return false;
			}
		}
		if (sbt_woDk6agauuf2BA_UG.size() != pObject->sbt_woDk6agauuf2BA_UG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_woDk6agauuf2BA_UG.size(); i++)
		{
			if (sbt_woDk6agauuf2BA_UG[i] != pObject->sbt_woDk6agauuf2BA_UG[i])
			{
				return false;
			}
		}
		if (sbt_FrfhSkkWNEFSm3w_4.size() != pObject->sbt_FrfhSkkWNEFSm3w_4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FrfhSkkWNEFSm3w_4.size(); i++)
		{
			if (0 != cx_strcmp(sbt_FrfhSkkWNEFSm3w_4[i].c_str(), pObject->sbt_FrfhSkkWNEFSm3w_4[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_j229BE9.size() != pObject->sbt_j229BE9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j229BE9.size(); i++)
		{
			if (sbt_j229BE9[i] != pObject->sbt_j229BE9[i])
			{
				return false;
			}
		}
		if (sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA != pObject->sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA)
		{
			return false;
		}
		if (sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.size() != pObject->sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.size(); i++)
		{
			if (sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb[i] != pObject->sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb[i])
			{
				return false;
			}
		}
		if (sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y != pObject->sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y)
		{
			return false;
		}
		if (sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW != pObject->sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW)
		{
			return false;
		}
		if (sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw != pObject->sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw)
		{
			return false;
		}
		if (sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO != pObject->sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO)
		{
			return false;
		}
		if (sbt_Fy2y6k5carhsu8R7BXn0uU3r3.size() != pObject->sbt_Fy2y6k5carhsu8R7BXn0uU3r3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fy2y6k5carhsu8R7BXn0uU3r3.size(); i++)
		{
			if (sbt_Fy2y6k5carhsu8R7BXn0uU3r3[i] != pObject->sbt_Fy2y6k5carhsu8R7BXn0uU3r3[i])
			{
				return false;
			}
		}
		if (sbt_gQTvCPfMZRZ1fvtxzDXsaJq != pObject->sbt_gQTvCPfMZRZ1fvtxzDXsaJq)
		{
			return false;
		}
		if (sbt_4lKf77yCcxNhH0B412Lsd.size() != pObject->sbt_4lKf77yCcxNhH0B412Lsd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4lKf77yCcxNhH0B412Lsd.size(); i++)
		{
			if (sbt_4lKf77yCcxNhH0B412Lsd[i] != pObject->sbt_4lKf77yCcxNhH0B412Lsd[i])
			{
				return false;
			}
		}
		if (sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.size() != pObject->sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.size(); i++)
		{
			if (sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek[i] != pObject->sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek[i])
			{
				return false;
			}
		}
		if (sbt_15hmlZzSkYqKgLlFMmBcBo4Z_ != pObject->sbt_15hmlZzSkYqKgLlFMmBcBo4Z_)
		{
			return false;
		}
		if (sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf != pObject->sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf)
		{
			return false;
		}
		if (sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS != pObject->sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS)
		{
			return false;
		}
		if (sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw != pObject->sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw)
		{
			return false;
		}
		if (sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643 != pObject->sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643)
		{
			return false;
		}
		if (sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.size() != pObject->sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.size(); i++)
		{
			if (sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5[i] != pObject->sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5[i])
			{
				return false;
			}
		}
		if (sbt_n0aKoOoOV.size() != pObject->sbt_n0aKoOoOV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n0aKoOoOV.size(); i++)
		{
			if (sbt_n0aKoOoOV[i] != pObject->sbt_n0aKoOoOV[i])
			{
				return false;
			}
		}
		if (sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y != pObject->sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_LSsaWuy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LSsaWuy = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iUtlG5jCD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iUtlG5jCD.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AFhfsDE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AFhfsDE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_woDk6agauuf2BA_UG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_woDk6agauuf2BA_UG.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FrfhSkkWNEFSm3w_4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FrfhSkkWNEFSm3w_4.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j229BE9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j229BE9.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y", &sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Fy2y6k5carhsu8R7BXn0uU3r3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fy2y6k5carhsu8R7BXn0uU3r3.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gQTvCPfMZRZ1fvtxzDXsaJq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gQTvCPfMZRZ1fvtxzDXsaJq = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4lKf77yCcxNhH0B412Lsd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4lKf77yCcxNhH0B412Lsd.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_15hmlZzSkYqKgLlFMmBcBo4Z_", &sbt_15hmlZzSkYqKgLlFMmBcBo4Z_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n0aKoOoOV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n0aKoOoOV.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_LSsaWuy", (CX::Int64)sbt_LSsaWuy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu", (CX::Int64)sbt_G9Pd5A94rorgYLe79wTTj4plz06Y9d_rcaEA21IGu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iUtlG5jCD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_iUtlG5jCD.begin(); iter != sbt_iUtlG5jCD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.begin(); iter != sbt_6bULtZnFjr1QahaYNP9txySg8LNjJJFh7aF4eId.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AFhfsDE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_AFhfsDE.begin(); iter != sbt_AFhfsDE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_woDk6agauuf2BA_UG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_woDk6agauuf2BA_UG.begin(); iter != sbt_woDk6agauuf2BA_UG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FrfhSkkWNEFSm3w_4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_FrfhSkkWNEFSm3w_4.begin(); iter != sbt_FrfhSkkWNEFSm3w_4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j229BE9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_j229BE9.begin(); iter != sbt_j229BE9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA", (CX::Int64)sbt_JAKzk16lvtxsHCQzWYtxEJXS1XtEi_wcGvdfSzAPZJt4aJA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.begin(); iter != sbt_faH2D3Erz9O6glQbagnXW0OmtIORA5rBzm_pA4XCxfRXjq7Kb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y", sbt_VUdS9SgUD46CONpBt43LyL4V7SoSjyWU1Kn8RY3q1GR0xp8yh1Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW", (CX::Int64)sbt_tD4OQmaMsvz892sC3XFeu_KM1T5jQFPCvKW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw", (CX::Int64)sbt_J3bNIh2YQmcl8ug2v0L90_QKSd20WHw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO", (CX::Int64)sbt_afjtXtIB1vnkxWtIocghcjx80HPMLkOMYgJaDCGYdg7vBnI0aFO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fy2y6k5carhsu8R7BXn0uU3r3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Fy2y6k5carhsu8R7BXn0uU3r3.begin(); iter != sbt_Fy2y6k5carhsu8R7BXn0uU3r3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gQTvCPfMZRZ1fvtxzDXsaJq", (CX::Int64)sbt_gQTvCPfMZRZ1fvtxzDXsaJq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4lKf77yCcxNhH0B412Lsd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_4lKf77yCcxNhH0B412Lsd.begin(); iter != sbt_4lKf77yCcxNhH0B412Lsd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.begin(); iter != sbt_ojE4VmDfG8p6KdNcmZWUrk_B6lZq_qDd_hvqQYnWMf6bpek.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_15hmlZzSkYqKgLlFMmBcBo4Z_", sbt_15hmlZzSkYqKgLlFMmBcBo4Z_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf", (CX::Int64)sbt_KL1Jo6_vrqBHDfvLY5Hi8_toj5R8Px_9T7oJ8S1QowPo8_V1Lt_KH2OF2ARilmf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS", (CX::Int64)sbt_kLFSOkJlbJBQ_25uIWph0JTrV_4fHbxGNlS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw", (CX::Int64)sbt_W0YtaOq3xGuppglMouDrSfnU3ksr6Bp2Fy0dEgKqSArYGIzoxD47g9wuw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643", (CX::Int64)sbt_nIB6qJc4TuhNOfgggj7FhIYAh1Yk1zg2643)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.begin(); iter != sbt_Nxz0aVHwVOQy4M6GtSH2BRv9ndJstggDHa8JpT7UW5O8LadOkRhs5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n0aKoOoOV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_n0aKoOoOV.begin(); iter != sbt_n0aKoOoOV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y", (CX::Int64)sbt_WgyDAP8kvL36ggcylBqoIqG1I1DOTafcvlto0iwZev3JpZlDVMbgG1Y)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6mSKrq1ZBtodU8N>::Type sbt_6mSKrq1ZBtodU8NArray;

