
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw.hpp"


class sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_7nbu7JZigjmaiPllZMB7k;
	CX::UInt64 sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt;
	CX::String sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd;
	sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw sbt_UfKa0Ziae7v8S0s9N;

	virtual void Reset()
	{
		sbt_7nbu7JZigjmaiPllZMB7k = 0;
		sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt = 0;
		sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd.clear();
		sbt_UfKa0Ziae7v8S0s9N.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_7nbu7JZigjmaiPllZMB7k = 51;
		sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt = 7991790574154933632;
		sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd = "Em!g";
		sbt_UfKa0Ziae7v8S0s9N.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa *pObject = dynamic_cast<const sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_7nbu7JZigjmaiPllZMB7k != pObject->sbt_7nbu7JZigjmaiPllZMB7k)
		{
			return false;
		}
		if (sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt != pObject->sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd.c_str(), pObject->sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd.c_str()))
		{
			return false;
		}
		if (!sbt_UfKa0Ziae7v8S0s9N.Compare(&pObject->sbt_UfKa0Ziae7v8S0s9N))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_7nbu7JZigjmaiPllZMB7k", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7nbu7JZigjmaiPllZMB7k = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd", &sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_UfKa0Ziae7v8S0s9N")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_UfKa0Ziae7v8S0s9N.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_7nbu7JZigjmaiPllZMB7k", (CX::Int64)sbt_7nbu7JZigjmaiPllZMB7k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt", (CX::Int64)sbt_lgHe35S6obuFfWFflsChq8BVDwL1yuiDncPN6ugNt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd", sbt_87KhwWYt4j9D35HjC0EyCB2be_TaJFBpd.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_UfKa0Ziae7v8S0s9N")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_UfKa0Ziae7v8S0s9N.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa>::Type sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUaArray;

