
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_o : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_nJ7lPkM6Wsv0AFIT7SK;
	CX::UInt8 sbt_7fG;
	CX::UInt32 sbt_gZMkF0Jg83L;
	CX::IO::SimpleBuffers::UInt64Array sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn;
	CX::Int16 sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC;
	CX::IO::SimpleBuffers::Int32Array sbt_mK6cKrOcyPw7_98;
	CX::IO::SimpleBuffers::Int64Array sbt_lxdx98KUSb4yu;
	CX::UInt64 sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw;
	CX::Int64 sbt_5tXVCugfbQet1t7M_koXCtf8rfp;
	CX::UInt32 sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ;
	CX::IO::SimpleBuffers::UInt32Array sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4;
	CX::IO::SimpleBuffers::Int16Array sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86;
	CX::String sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB;
	CX::IO::SimpleBuffers::Int16Array sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX;
	CX::IO::SimpleBuffers::Int16Array sbt_ZliJZglwNFaS4Al;
	CX::IO::SimpleBuffers::StringArray sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI;
	CX::UInt32 sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf;
	CX::IO::SimpleBuffers::UInt32Array sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF;
	CX::UInt8 sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD;
	CX::IO::SimpleBuffers::UInt32Array sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT;
	CX::IO::SimpleBuffers::Int16Array sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo;
	CX::String sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R;
	CX::IO::SimpleBuffers::Int64Array sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY;
	CX::UInt64 sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg;
	CX::Int64 sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL;
	CX::IO::SimpleBuffers::UInt32Array sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb;
	CX::UInt32 sbt_CgJ7HRBfFleEq8BhNHT;
	CX::IO::SimpleBuffers::UInt64Array sbt_B;
	CX::IO::SimpleBuffers::UInt32Array sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02;

	virtual void Reset()
	{
		sbt_nJ7lPkM6Wsv0AFIT7SK = 0;
		sbt_7fG = 0;
		sbt_gZMkF0Jg83L = 0;
		sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.clear();
		sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC = 0;
		sbt_mK6cKrOcyPw7_98.clear();
		sbt_lxdx98KUSb4yu.clear();
		sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw = 0;
		sbt_5tXVCugfbQet1t7M_koXCtf8rfp = 0;
		sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ = 0;
		sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.clear();
		sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.clear();
		sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB.clear();
		sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.clear();
		sbt_ZliJZglwNFaS4Al.clear();
		sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.clear();
		sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf = 0;
		sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.clear();
		sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD = 0;
		sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.clear();
		sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.clear();
		sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R.clear();
		sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.clear();
		sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg = 0;
		sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL = 0;
		sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.clear();
		sbt_CgJ7HRBfFleEq8BhNHT = 0;
		sbt_B.clear();
		sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_nJ7lPkM6Wsv0AFIT7SK = 5731008889199137556;
		sbt_7fG = 213;
		sbt_gZMkF0Jg83L = 4037342801;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.push_back(14803529968947521972);
		}
		sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC = 22230;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_mK6cKrOcyPw7_98.push_back(503047784);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lxdx98KUSb4yu.push_back(-7964913239564005504);
		}
		sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw = 11863744051837861460;
		sbt_5tXVCugfbQet1t7M_koXCtf8rfp = 2651285886747169670;
		sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ = 2693516335;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.push_back(293720011);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.push_back(-32087);
		}
		sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB = "ga!9.t|;pZ4}_P?HR[8Kvdo,RuUTBUW4bu\"X[?mSi@{Y\"3hz<oX]up'Hb|";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.push_back(25846);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ZliJZglwNFaS4Al.push_back(25684);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.push_back("_8Gkwdl(v)zy4:@J");
		}
		sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf = 2793427616;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.push_back(4179618343);
		}
		sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD = 145;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.push_back(4288079054);
		}
		sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R = "^1-BAY5Q%|2=C[8)52.3yb^ulk3e7zc@HL>\"~yJ5-";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.push_back(-8416568672258211702);
		}
		sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg = 15216604609225958034;
		sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL = -1725132656775437670;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.push_back(3448882058);
		}
		sbt_CgJ7HRBfFleEq8BhNHT = 1121726305;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_B.push_back(6270033598510958478);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.push_back(1833699837);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_o *pObject = dynamic_cast<const sbt_o *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_nJ7lPkM6Wsv0AFIT7SK != pObject->sbt_nJ7lPkM6Wsv0AFIT7SK)
		{
			return false;
		}
		if (sbt_7fG != pObject->sbt_7fG)
		{
			return false;
		}
		if (sbt_gZMkF0Jg83L != pObject->sbt_gZMkF0Jg83L)
		{
			return false;
		}
		if (sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.size() != pObject->sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.size(); i++)
		{
			if (sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn[i] != pObject->sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn[i])
			{
				return false;
			}
		}
		if (sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC != pObject->sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC)
		{
			return false;
		}
		if (sbt_mK6cKrOcyPw7_98.size() != pObject->sbt_mK6cKrOcyPw7_98.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mK6cKrOcyPw7_98.size(); i++)
		{
			if (sbt_mK6cKrOcyPw7_98[i] != pObject->sbt_mK6cKrOcyPw7_98[i])
			{
				return false;
			}
		}
		if (sbt_lxdx98KUSb4yu.size() != pObject->sbt_lxdx98KUSb4yu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lxdx98KUSb4yu.size(); i++)
		{
			if (sbt_lxdx98KUSb4yu[i] != pObject->sbt_lxdx98KUSb4yu[i])
			{
				return false;
			}
		}
		if (sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw != pObject->sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw)
		{
			return false;
		}
		if (sbt_5tXVCugfbQet1t7M_koXCtf8rfp != pObject->sbt_5tXVCugfbQet1t7M_koXCtf8rfp)
		{
			return false;
		}
		if (sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ != pObject->sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ)
		{
			return false;
		}
		if (sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.size() != pObject->sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.size(); i++)
		{
			if (sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4[i] != pObject->sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4[i])
			{
				return false;
			}
		}
		if (sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.size() != pObject->sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.size(); i++)
		{
			if (sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86[i] != pObject->sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB.c_str(), pObject->sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB.c_str()))
		{
			return false;
		}
		if (sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.size() != pObject->sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.size(); i++)
		{
			if (sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX[i] != pObject->sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX[i])
			{
				return false;
			}
		}
		if (sbt_ZliJZglwNFaS4Al.size() != pObject->sbt_ZliJZglwNFaS4Al.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZliJZglwNFaS4Al.size(); i++)
		{
			if (sbt_ZliJZglwNFaS4Al[i] != pObject->sbt_ZliJZglwNFaS4Al[i])
			{
				return false;
			}
		}
		if (sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.size() != pObject->sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI[i].c_str(), pObject->sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf != pObject->sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf)
		{
			return false;
		}
		if (sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.size() != pObject->sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.size(); i++)
		{
			if (sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF[i] != pObject->sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF[i])
			{
				return false;
			}
		}
		if (sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD != pObject->sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD)
		{
			return false;
		}
		if (sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.size() != pObject->sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.size(); i++)
		{
			if (sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT[i] != pObject->sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT[i])
			{
				return false;
			}
		}
		if (sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.size() != pObject->sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.size(); i++)
		{
			if (sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo[i] != pObject->sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R.c_str(), pObject->sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R.c_str()))
		{
			return false;
		}
		if (sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.size() != pObject->sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.size(); i++)
		{
			if (sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY[i] != pObject->sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY[i])
			{
				return false;
			}
		}
		if (sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg != pObject->sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg)
		{
			return false;
		}
		if (sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL != pObject->sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL)
		{
			return false;
		}
		if (sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.size() != pObject->sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.size(); i++)
		{
			if (sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb[i] != pObject->sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb[i])
			{
				return false;
			}
		}
		if (sbt_CgJ7HRBfFleEq8BhNHT != pObject->sbt_CgJ7HRBfFleEq8BhNHT)
		{
			return false;
		}
		if (sbt_B.size() != pObject->sbt_B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B.size(); i++)
		{
			if (sbt_B[i] != pObject->sbt_B[i])
			{
				return false;
			}
		}
		if (sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.size() != pObject->sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.size(); i++)
		{
			if (sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02[i] != pObject->sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_nJ7lPkM6Wsv0AFIT7SK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nJ7lPkM6Wsv0AFIT7SK = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7fG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7fG = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gZMkF0Jg83L", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gZMkF0Jg83L = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mK6cKrOcyPw7_98")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mK6cKrOcyPw7_98.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lxdx98KUSb4yu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lxdx98KUSb4yu.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5tXVCugfbQet1t7M_koXCtf8rfp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5tXVCugfbQet1t7M_koXCtf8rfp = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB", &sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZliJZglwNFaS4Al")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZliJZglwNFaS4Al.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R", &sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CgJ7HRBfFleEq8BhNHT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CgJ7HRBfFleEq8BhNHT = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_nJ7lPkM6Wsv0AFIT7SK", (CX::Int64)sbt_nJ7lPkM6Wsv0AFIT7SK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7fG", (CX::Int64)sbt_7fG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gZMkF0Jg83L", (CX::Int64)sbt_gZMkF0Jg83L)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.begin(); iter != sbt__gi69SWhu5PWg7ruD8854bysqndRBYhE4YOXtUCyKUn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC", (CX::Int64)sbt_hnYIxX9oHL6VnD1EcAHVC4GXmwD6ON2PC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mK6cKrOcyPw7_98")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_mK6cKrOcyPw7_98.begin(); iter != sbt_mK6cKrOcyPw7_98.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lxdx98KUSb4yu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_lxdx98KUSb4yu.begin(); iter != sbt_lxdx98KUSb4yu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw", (CX::Int64)sbt_tKdhZJID_53LVqZuCbluwJ_tTo7AaTQQ84OTCMVimfBpVcuuUZgMw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5tXVCugfbQet1t7M_koXCtf8rfp", (CX::Int64)sbt_5tXVCugfbQet1t7M_koXCtf8rfp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ", (CX::Int64)sbt_u7bTEc0MDFUqIT0wPPZhzChrArIWJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.begin(); iter != sbt_Wau5hN3h7dfkSdqLtwfEaVSLXbEacQHy2_vM4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.begin(); iter != sbt_VhnhdrjnkiL8yAzOoVg1pEIPgLsGHXe5iuPbnqf70j5ifrOUgeio99O86.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB", sbt_UhB9aSfzoCYu3zID4xyksHYgU1Wwo4PpONV4BlVaZ22MB.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.begin(); iter != sbt_jf4601LX9WYUj1ufSq8ip3Ja693B4zFCQcndTSvlkwTIlboCW9vYRlCAX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZliJZglwNFaS4Al")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ZliJZglwNFaS4Al.begin(); iter != sbt_ZliJZglwNFaS4Al.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.begin(); iter != sbt_zVDvtHlJ6j7cqCavYffGN7LnN5k80uJSI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf", (CX::Int64)sbt_FxfWYx5wFv1JCagBTe03lzL9PFCsFDnbk1UM9FFG0kzZcjJTIvZ8MXorwTmZQYf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.begin(); iter != sbt_N8CYjNsskye7HoEn0iNp98a8Rn34K88vUJWjR3dbhKTBi8_0tU_KFvtsBd5kimF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD", (CX::Int64)sbt__etdhjlAzR7NU9g8Poz2Jr90aw4zCCqkZHOvcFbA8UD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.begin(); iter != sbt_oD3pYuh9kiC33zKtsz3ypvHmpwXxNempttoJFYkI9WV_bfT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.begin(); iter != sbt_BtVDRX1BUDTdm1xN_KEwUvBBabxjGdqv_wWMdmeMo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R", sbt_eOSOesGT3XlMJllZ9mg9AXkRjinp7nhR3_R.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.begin(); iter != sbt_qCy2tHbN3vicMJi1iskw05zfSSkua4b4XTY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg", (CX::Int64)sbt_ylh5hJZVOqdGA7p6IJUtssZLZ93a5yCHQnREjg14Ycg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL", (CX::Int64)sbt_PhIULnQ4MiVS6bW87Rb0G67gv0AJ7Cs4boaKIQemwB6XAPzsHm3bXD6TnzL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.begin(); iter != sbt_A9lDg6yFhbs83P2IzMIubIPvwaysKd6NfRb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CgJ7HRBfFleEq8BhNHT", (CX::Int64)sbt_CgJ7HRBfFleEq8BhNHT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_B.begin(); iter != sbt_B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.begin(); iter != sbt_d5H6ZZjyOPME61jF1pBJPK9dpW_51ogS6U7hXExgpFb02.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_o>::Type sbt_oArray;

