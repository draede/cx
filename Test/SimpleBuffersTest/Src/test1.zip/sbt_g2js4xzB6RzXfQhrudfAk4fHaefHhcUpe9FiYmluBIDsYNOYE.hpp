
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3;
	CX::Int16 sbt_Dutzur7wpXO6vNJD1;
	CX::Bool sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq;
	CX::Int32 sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97;
	CX::Int64 sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz;
	CX::IO::SimpleBuffers::UInt32Array sbt_iLXNSfYkb0cFWS_fk;
	CX::UInt32 sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7;
	CX::Int16 sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu;
	CX::String sbt_Fh9M3SPKL3ZWogz;

	virtual void Reset()
	{
		sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3 = 0;
		sbt_Dutzur7wpXO6vNJD1 = 0;
		sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq = false;
		sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97 = 0;
		sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz = 0;
		sbt_iLXNSfYkb0cFWS_fk.clear();
		sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7 = 0;
		sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu = 0;
		sbt_Fh9M3SPKL3ZWogz.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3 = -1693685053788248316;
		sbt_Dutzur7wpXO6vNJD1 = 2796;
		sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq = false;
		sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97 = 543127103;
		sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz = -5480586723960840544;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_iLXNSfYkb0cFWS_fk.push_back(2706678136);
		}
		sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7 = 1467617762;
		sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu = 9465;
		sbt_Fh9M3SPKL3ZWogz = "z<z?xjs=zD7m6(>\"#?qlo";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE *pObject = dynamic_cast<const sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3 != pObject->sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3)
		{
			return false;
		}
		if (sbt_Dutzur7wpXO6vNJD1 != pObject->sbt_Dutzur7wpXO6vNJD1)
		{
			return false;
		}
		if (sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq != pObject->sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq)
		{
			return false;
		}
		if (sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97 != pObject->sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97)
		{
			return false;
		}
		if (sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz != pObject->sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz)
		{
			return false;
		}
		if (sbt_iLXNSfYkb0cFWS_fk.size() != pObject->sbt_iLXNSfYkb0cFWS_fk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iLXNSfYkb0cFWS_fk.size(); i++)
		{
			if (sbt_iLXNSfYkb0cFWS_fk[i] != pObject->sbt_iLXNSfYkb0cFWS_fk[i])
			{
				return false;
			}
		}
		if (sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7 != pObject->sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7)
		{
			return false;
		}
		if (sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu != pObject->sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Fh9M3SPKL3ZWogz.c_str(), pObject->sbt_Fh9M3SPKL3ZWogz.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Dutzur7wpXO6vNJD1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Dutzur7wpXO6vNJD1 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq", &sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iLXNSfYkb0cFWS_fk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iLXNSfYkb0cFWS_fk.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_Fh9M3SPKL3ZWogz", &sbt_Fh9M3SPKL3ZWogz)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3", (CX::Int64)sbt_c7Q0aPkJPYQ2rNNmQc2Q3z3JHI3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Dutzur7wpXO6vNJD1", (CX::Int64)sbt_Dutzur7wpXO6vNJD1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq", sbt_JXWoIXSDWrI0Vqa7KuvjWPyTHkBF43ZsD_AQ5Hq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97", (CX::Int64)sbt_H5sICYzBEYPfcJEUdOQi8OWUpzz4eYASms5UuRtzR97)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz", (CX::Int64)sbt_0ZQPsX2zJIsv80xn1KfkjigrMzfTZOFcuQdUnUvOKxjCLOz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iLXNSfYkb0cFWS_fk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_iLXNSfYkb0cFWS_fk.begin(); iter != sbt_iLXNSfYkb0cFWS_fk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7", (CX::Int64)sbt_9K8zyAiTXxWFmhh2muO4ClZn6k7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu", (CX::Int64)sbt_t097NoZGI_sbbnpsc6y01gYYl_JtuwdfIvcTu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Fh9M3SPKL3ZWogz", sbt_Fh9M3SPKL3ZWogz.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE>::Type sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYEArray;

