
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_AjpZVa2qtd2oY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc;
	CX::IO::SimpleBuffers::UInt32Array sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et;
	CX::IO::SimpleBuffers::Int32Array sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm;
	CX::Int64 sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS;
	CX::IO::SimpleBuffers::UInt32Array sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba;
	CX::UInt32 sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z;
	CX::IO::SimpleBuffers::UInt16Array sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv;
	CX::UInt32 sbt_EnRJPpTOOyWnviWcwHaA_kf;
	CX::IO::SimpleBuffers::UInt64Array sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y;
	CX::IO::SimpleBuffers::Int64Array sbt_hMywflAOxljkCgZ5H;
	CX::IO::SimpleBuffers::UInt32Array sbt_QRwiboXun;
	CX::Bool sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a;
	CX::IO::SimpleBuffers::UInt32Array sbt_yNUALnbyuxD2INFZxh5hS;
	CX::IO::SimpleBuffers::BoolArray sbt_eaUMNS4gUsXB8sR4BmEGE;
	CX::UInt64 sbt_yXvuAZragoqjljMxuqtK5;
	CX::IO::SimpleBuffers::BoolArray sbt_m2WEG8qyiwJOLfk1Z0hr3FT;
	CX::IO::SimpleBuffers::Int8Array sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY;
	CX::Int16 sbt_ujCBclSk8mSI6FUzH_tyImuLQK5;
	CX::String sbt_KIzh8CDqZ;
	CX::IO::SimpleBuffers::Int8Array sbt_XrCkF0uWxpsT0jo;
	CX::IO::SimpleBuffers::StringArray sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm;
	CX::IO::SimpleBuffers::StringArray sbt_Rw7R42xGsc8vsFWOUpstBCrnc;
	CX::IO::SimpleBuffers::Int64Array sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2;
	CX::IO::SimpleBuffers::Int8Array sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G;
	CX::IO::SimpleBuffers::Int8Array sbt_s;

	virtual void Reset()
	{
		sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.clear();
		sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.clear();
		sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.clear();
		sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS = 0;
		sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.clear();
		sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z = 0;
		sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.clear();
		sbt_EnRJPpTOOyWnviWcwHaA_kf = 0;
		sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.clear();
		sbt_hMywflAOxljkCgZ5H.clear();
		sbt_QRwiboXun.clear();
		sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a = false;
		sbt_yNUALnbyuxD2INFZxh5hS.clear();
		sbt_eaUMNS4gUsXB8sR4BmEGE.clear();
		sbt_yXvuAZragoqjljMxuqtK5 = 0;
		sbt_m2WEG8qyiwJOLfk1Z0hr3FT.clear();
		sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.clear();
		sbt_ujCBclSk8mSI6FUzH_tyImuLQK5 = 0;
		sbt_KIzh8CDqZ.clear();
		sbt_XrCkF0uWxpsT0jo.clear();
		sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.clear();
		sbt_Rw7R42xGsc8vsFWOUpstBCrnc.clear();
		sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.clear();
		sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.clear();
		sbt_s.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.push_back(-88);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.push_back(1985506429);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.push_back(-94570265);
		}
		sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS = -2358671228082641316;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.push_back(709120444);
		}
		sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z = 2761642546;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.push_back(56780);
		}
		sbt_EnRJPpTOOyWnviWcwHaA_kf = 1904638432;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.push_back(2372071261190380362);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_QRwiboXun.push_back(630235497);
		}
		sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a = false;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_yNUALnbyuxD2INFZxh5hS.push_back(1342448583);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_eaUMNS4gUsXB8sR4BmEGE.push_back(true);
		}
		sbt_yXvuAZragoqjljMxuqtK5 = 11261978171998414678;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_m2WEG8qyiwJOLfk1Z0hr3FT.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.push_back(-77);
		}
		sbt_ujCBclSk8mSI6FUzH_tyImuLQK5 = 12593;
		sbt_KIzh8CDqZ = "2]8/xLQ|Z";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_XrCkF0uWxpsT0jo.push_back(-123);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.push_back("hy9X?@\\;0+w)Sq3k!@2|UGHa");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Rw7R42xGsc8vsFWOUpstBCrnc.push_back("cPN.-+RU`_o'`kYY*zJ!\\,|\"FiU<}7{(-!s%FE@8`&EOTlj]xGw");
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.push_back(3001190514281150150);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.push_back(-99);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_s.push_back(43);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_AjpZVa2qtd2oY *pObject = dynamic_cast<const sbt_AjpZVa2qtd2oY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.size() != pObject->sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.size(); i++)
		{
			if (sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc[i] != pObject->sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc[i])
			{
				return false;
			}
		}
		if (sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.size() != pObject->sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.size(); i++)
		{
			if (sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et[i] != pObject->sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et[i])
			{
				return false;
			}
		}
		if (sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.size() != pObject->sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.size(); i++)
		{
			if (sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm[i] != pObject->sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm[i])
			{
				return false;
			}
		}
		if (sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS != pObject->sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS)
		{
			return false;
		}
		if (sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.size() != pObject->sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.size(); i++)
		{
			if (sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba[i] != pObject->sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba[i])
			{
				return false;
			}
		}
		if (sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z != pObject->sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z)
		{
			return false;
		}
		if (sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.size() != pObject->sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.size(); i++)
		{
			if (sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv[i] != pObject->sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv[i])
			{
				return false;
			}
		}
		if (sbt_EnRJPpTOOyWnviWcwHaA_kf != pObject->sbt_EnRJPpTOOyWnviWcwHaA_kf)
		{
			return false;
		}
		if (sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.size() != pObject->sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.size(); i++)
		{
			if (sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y[i] != pObject->sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y[i])
			{
				return false;
			}
		}
		if (sbt_hMywflAOxljkCgZ5H.size() != pObject->sbt_hMywflAOxljkCgZ5H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hMywflAOxljkCgZ5H.size(); i++)
		{
			if (sbt_hMywflAOxljkCgZ5H[i] != pObject->sbt_hMywflAOxljkCgZ5H[i])
			{
				return false;
			}
		}
		if (sbt_QRwiboXun.size() != pObject->sbt_QRwiboXun.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QRwiboXun.size(); i++)
		{
			if (sbt_QRwiboXun[i] != pObject->sbt_QRwiboXun[i])
			{
				return false;
			}
		}
		if (sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a != pObject->sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a)
		{
			return false;
		}
		if (sbt_yNUALnbyuxD2INFZxh5hS.size() != pObject->sbt_yNUALnbyuxD2INFZxh5hS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yNUALnbyuxD2INFZxh5hS.size(); i++)
		{
			if (sbt_yNUALnbyuxD2INFZxh5hS[i] != pObject->sbt_yNUALnbyuxD2INFZxh5hS[i])
			{
				return false;
			}
		}
		if (sbt_eaUMNS4gUsXB8sR4BmEGE.size() != pObject->sbt_eaUMNS4gUsXB8sR4BmEGE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eaUMNS4gUsXB8sR4BmEGE.size(); i++)
		{
			if (sbt_eaUMNS4gUsXB8sR4BmEGE[i] != pObject->sbt_eaUMNS4gUsXB8sR4BmEGE[i])
			{
				return false;
			}
		}
		if (sbt_yXvuAZragoqjljMxuqtK5 != pObject->sbt_yXvuAZragoqjljMxuqtK5)
		{
			return false;
		}
		if (sbt_m2WEG8qyiwJOLfk1Z0hr3FT.size() != pObject->sbt_m2WEG8qyiwJOLfk1Z0hr3FT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m2WEG8qyiwJOLfk1Z0hr3FT.size(); i++)
		{
			if (sbt_m2WEG8qyiwJOLfk1Z0hr3FT[i] != pObject->sbt_m2WEG8qyiwJOLfk1Z0hr3FT[i])
			{
				return false;
			}
		}
		if (sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.size() != pObject->sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.size(); i++)
		{
			if (sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY[i] != pObject->sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY[i])
			{
				return false;
			}
		}
		if (sbt_ujCBclSk8mSI6FUzH_tyImuLQK5 != pObject->sbt_ujCBclSk8mSI6FUzH_tyImuLQK5)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_KIzh8CDqZ.c_str(), pObject->sbt_KIzh8CDqZ.c_str()))
		{
			return false;
		}
		if (sbt_XrCkF0uWxpsT0jo.size() != pObject->sbt_XrCkF0uWxpsT0jo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XrCkF0uWxpsT0jo.size(); i++)
		{
			if (sbt_XrCkF0uWxpsT0jo[i] != pObject->sbt_XrCkF0uWxpsT0jo[i])
			{
				return false;
			}
		}
		if (sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.size() != pObject->sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.size(); i++)
		{
			if (0 != cx_strcmp(sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm[i].c_str(), pObject->sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Rw7R42xGsc8vsFWOUpstBCrnc.size() != pObject->sbt_Rw7R42xGsc8vsFWOUpstBCrnc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Rw7R42xGsc8vsFWOUpstBCrnc.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Rw7R42xGsc8vsFWOUpstBCrnc[i].c_str(), pObject->sbt_Rw7R42xGsc8vsFWOUpstBCrnc[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.size() != pObject->sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.size(); i++)
		{
			if (sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2[i] != pObject->sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2[i])
			{
				return false;
			}
		}
		if (sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.size() != pObject->sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.size(); i++)
		{
			if (sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G[i] != pObject->sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G[i])
			{
				return false;
			}
		}
		if (sbt_s.size() != pObject->sbt_s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s.size(); i++)
		{
			if (sbt_s[i] != pObject->sbt_s[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EnRJPpTOOyWnviWcwHaA_kf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EnRJPpTOOyWnviWcwHaA_kf = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hMywflAOxljkCgZ5H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hMywflAOxljkCgZ5H.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QRwiboXun")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QRwiboXun.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a", &sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yNUALnbyuxD2INFZxh5hS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yNUALnbyuxD2INFZxh5hS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eaUMNS4gUsXB8sR4BmEGE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eaUMNS4gUsXB8sR4BmEGE.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yXvuAZragoqjljMxuqtK5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yXvuAZragoqjljMxuqtK5 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_m2WEG8qyiwJOLfk1Z0hr3FT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m2WEG8qyiwJOLfk1Z0hr3FT.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ujCBclSk8mSI6FUzH_tyImuLQK5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ujCBclSk8mSI6FUzH_tyImuLQK5 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_KIzh8CDqZ", &sbt_KIzh8CDqZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XrCkF0uWxpsT0jo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XrCkF0uWxpsT0jo.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Rw7R42xGsc8vsFWOUpstBCrnc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Rw7R42xGsc8vsFWOUpstBCrnc.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.begin(); iter != sbt_M7Sa7n0W5l3MlAcAn3H4zFWM4tbbgIhh5MxY5lFo9IodV9qxWX4cSNc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.begin(); iter != sbt_Z8XllWhLerIz1Fuozn0pm2I1RJpsGqtRahH08uratNeXZrAPwyqF6J4et.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.begin(); iter != sbt_hTYgZACqmWfztuns0ebTgUvFwv46_Tm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS", (CX::Int64)sbt_PVxWnwjD6ZJT8rKsA57TH9dSArBWimFuGzS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.begin(); iter != sbt_iHff8YVtCSlJAakl1S8bOWT9GfxeNdH89zA2f4nFGiABolkRTeUKQq6X9Ba.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z", (CX::Int64)sbt_vvTbC6yv3Z_x2dVO48gYHHclSVotynU44XrCSuzuX5SdXQMpX6z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.begin(); iter != sbt_CVHF0aR0sTCdCyMBySnQjKP2dtftgrRSu8fNJDs32gaPIqChDFdlx2n7RFLqv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EnRJPpTOOyWnviWcwHaA_kf", (CX::Int64)sbt_EnRJPpTOOyWnviWcwHaA_kf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.begin(); iter != sbt_wRHVvjqJwwj3cNj4ZGsFwGC1Nio8Ysh7Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hMywflAOxljkCgZ5H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_hMywflAOxljkCgZ5H.begin(); iter != sbt_hMywflAOxljkCgZ5H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QRwiboXun")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QRwiboXun.begin(); iter != sbt_QRwiboXun.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a", sbt_BU99UZpj98IdoXXhMVJHeVP2c6dA2nM1V106_ICEM_a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yNUALnbyuxD2INFZxh5hS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_yNUALnbyuxD2INFZxh5hS.begin(); iter != sbt_yNUALnbyuxD2INFZxh5hS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eaUMNS4gUsXB8sR4BmEGE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_eaUMNS4gUsXB8sR4BmEGE.begin(); iter != sbt_eaUMNS4gUsXB8sR4BmEGE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yXvuAZragoqjljMxuqtK5", (CX::Int64)sbt_yXvuAZragoqjljMxuqtK5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_m2WEG8qyiwJOLfk1Z0hr3FT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_m2WEG8qyiwJOLfk1Z0hr3FT.begin(); iter != sbt_m2WEG8qyiwJOLfk1Z0hr3FT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.begin(); iter != sbt_fDe29drGq4zomyxTvhAWOkC0uDgtMv9tKik8GNwlltY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ujCBclSk8mSI6FUzH_tyImuLQK5", (CX::Int64)sbt_ujCBclSk8mSI6FUzH_tyImuLQK5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_KIzh8CDqZ", sbt_KIzh8CDqZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XrCkF0uWxpsT0jo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_XrCkF0uWxpsT0jo.begin(); iter != sbt_XrCkF0uWxpsT0jo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.begin(); iter != sbt_yvR1AIjZ7qABQt2hnThLLeE0NaJK__rRm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Rw7R42xGsc8vsFWOUpstBCrnc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Rw7R42xGsc8vsFWOUpstBCrnc.begin(); iter != sbt_Rw7R42xGsc8vsFWOUpstBCrnc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.begin(); iter != sbt_NgHVNRDxKKA6Q14raETN4wAgBQiHQ53YvSnFBEE7_gJz3Zdvy8wh2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.begin(); iter != sbt_sEi_3Qba9hf7y8_1LNQHLDhFKVpK06vUEN2AkayQQUVYKCyZVsj7G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_s.begin(); iter != sbt_s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_AjpZVa2qtd2oY>::Type sbt_AjpZVa2qtd2oYArray;

