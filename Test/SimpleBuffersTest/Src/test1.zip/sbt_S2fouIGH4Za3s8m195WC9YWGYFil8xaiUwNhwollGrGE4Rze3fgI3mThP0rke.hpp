
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jVSCkaD5dp1.hpp"


class sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_r8F395k77aAqMDm;
	CX::IO::SimpleBuffers::UInt16Array sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV;
	CX::IO::SimpleBuffers::DoubleArray sbt_0;
	sbt_jVSCkaD5dp1 sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa;

	virtual void Reset()
	{
		sbt_r8F395k77aAqMDm.clear();
		sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.clear();
		sbt_0.clear();
		sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_r8F395k77aAqMDm.push_back(17838921978401279964);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.push_back(65392);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_0.push_back(0.391823);
		}
		sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke *pObject = dynamic_cast<const sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_r8F395k77aAqMDm.size() != pObject->sbt_r8F395k77aAqMDm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r8F395k77aAqMDm.size(); i++)
		{
			if (sbt_r8F395k77aAqMDm[i] != pObject->sbt_r8F395k77aAqMDm[i])
			{
				return false;
			}
		}
		if (sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.size() != pObject->sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.size(); i++)
		{
			if (sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV[i] != pObject->sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV[i])
			{
				return false;
			}
		}
		if (sbt_0.size() != pObject->sbt_0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0.size(); i++)
		{
			if (sbt_0[i] != pObject->sbt_0[i])
			{
				return false;
			}
		}
		if (!sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa.Compare(&pObject->sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_r8F395k77aAqMDm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r8F395k77aAqMDm.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_r8F395k77aAqMDm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_r8F395k77aAqMDm.begin(); iter != sbt_r8F395k77aAqMDm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.begin(); iter != sbt_1zgS30jAu_QEmF1FxDKEVwGhMwXSqSV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_0.begin(); iter != sbt_0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_qwlbbOd3OtruXQjHfW3cLAfDzwf30pOOkAWMa.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke>::Type sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rkeArray;

