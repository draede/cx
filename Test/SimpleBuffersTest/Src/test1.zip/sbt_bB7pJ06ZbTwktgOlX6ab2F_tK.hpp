
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV.hpp"


class sbt_bB7pJ06ZbTwktgOlX6ab2F_tK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77;
	CX::UInt16 sbt_HsFtuVj;
	sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV sbt_3OBTF;

	virtual void Reset()
	{
		sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77 = 0.0f;
		sbt_HsFtuVj = 0;
		sbt_3OBTF.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77 = 0.483697f;
		sbt_HsFtuVj = 65449;
		sbt_3OBTF.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_bB7pJ06ZbTwktgOlX6ab2F_tK *pObject = dynamic_cast<const sbt_bB7pJ06ZbTwktgOlX6ab2F_tK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77 != pObject->sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77)
		{
			return false;
		}
		if (sbt_HsFtuVj != pObject->sbt_HsFtuVj)
		{
			return false;
		}
		if (!sbt_3OBTF.Compare(&pObject->sbt_3OBTF))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_HsFtuVj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HsFtuVj = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_3OBTF")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_3OBTF.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77", (CX::Double)sbt_TLRtbHzyFp48zE4i6qxI7EaObY5_vJS77)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HsFtuVj", (CX::Int64)sbt_HsFtuVj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_3OBTF")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_3OBTF.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_bB7pJ06ZbTwktgOlX6ab2F_tK>::Type sbt_bB7pJ06ZbTwktgOlX6ab2F_tKArray;

