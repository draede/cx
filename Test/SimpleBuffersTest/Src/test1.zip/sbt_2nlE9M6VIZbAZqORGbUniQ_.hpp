
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX.hpp"


class sbt_2nlE9M6VIZbAZqORGbUniQ_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_Vgn;
	CX::IO::SimpleBuffers::Int64Array sbt_HOC;
	CX::IO::SimpleBuffers::UInt16Array sbt_uRhKjKxu2rliqtDr6ZWkOjnj6;
	CX::IO::SimpleBuffers::UInt8Array sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs;
	CX::IO::SimpleBuffers::Int16Array sbt_9j9viRkHLucNOVz;
	CX::Double sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC;
	CX::UInt16 sbt_jt65yY6VH1rxB;
	CX::WString sbt_E6zONK6qj7a;
	CX::Float sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ;
	CX::UInt8 sbt_M2A_3UjRs7TQsQ8oXYp;
	CX::IO::SimpleBuffers::StringArray sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D;
	CX::IO::SimpleBuffers::BoolArray sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn;
	CX::IO::SimpleBuffers::Int32Array sbt_EZsy40q;
	CX::IO::SimpleBuffers::Int8Array sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP;
	CX::UInt64 sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg;
	CX::WString sbt_fgTqNC36q;
	CX::IO::SimpleBuffers::UInt8Array sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv;
	CX::IO::SimpleBuffers::DoubleArray sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0;
	CX::Int8 sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO;
	CX::Int32 sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2;
	CX::Int8 sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX;
	sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilXArray sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA;

	virtual void Reset()
	{
		sbt_Vgn.clear();
		sbt_HOC.clear();
		sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.clear();
		sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.clear();
		sbt_9j9viRkHLucNOVz.clear();
		sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC = 0.0;
		sbt_jt65yY6VH1rxB = 0;
		sbt_E6zONK6qj7a.clear();
		sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ = 0.0f;
		sbt_M2A_3UjRs7TQsQ8oXYp = 0;
		sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.clear();
		sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.clear();
		sbt_EZsy40q.clear();
		sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.clear();
		sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg = 0;
		sbt_fgTqNC36q.clear();
		sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.clear();
		sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.clear();
		sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO = 0;
		sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2 = 0;
		sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX = 0;
		sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Vgn = "TUYqWEBL";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_HOC.push_back(-6511777913059847284);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.push_back(51787);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.push_back(70);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_9j9viRkHLucNOVz.push_back(-16748);
		}
		sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC = 0.161695;
		sbt_jt65yY6VH1rxB = 214;
		sbt_E6zONK6qj7a = L"d_3jM^6ac0'fi,k,CRWHHYQZ8?(=yZ";
		sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ = 0.009770f;
		sbt_M2A_3UjRs7TQsQ8oXYp = 166;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.push_back("+{'jwFu?'$%pbd~Rh2");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.push_back(false);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_EZsy40q.push_back(-1679198364);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.push_back(41);
		}
		sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg = 17091937563936526220;
		sbt_fgTqNC36q = L"z(4-l]nclSA$HRFRltt:zot\\<1SlPH#`}p/r;'";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.push_back(32);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.push_back(0.189702);
		}
		sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO = -70;
		sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2 = -2014342470;
		sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX = 37;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX v;

			v.SetupWithSomeValues();
			sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2nlE9M6VIZbAZqORGbUniQ_ *pObject = dynamic_cast<const sbt_2nlE9M6VIZbAZqORGbUniQ_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Vgn.c_str(), pObject->sbt_Vgn.c_str()))
		{
			return false;
		}
		if (sbt_HOC.size() != pObject->sbt_HOC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HOC.size(); i++)
		{
			if (sbt_HOC[i] != pObject->sbt_HOC[i])
			{
				return false;
			}
		}
		if (sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.size() != pObject->sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.size(); i++)
		{
			if (sbt_uRhKjKxu2rliqtDr6ZWkOjnj6[i] != pObject->sbt_uRhKjKxu2rliqtDr6ZWkOjnj6[i])
			{
				return false;
			}
		}
		if (sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.size() != pObject->sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.size(); i++)
		{
			if (sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs[i] != pObject->sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs[i])
			{
				return false;
			}
		}
		if (sbt_9j9viRkHLucNOVz.size() != pObject->sbt_9j9viRkHLucNOVz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9j9viRkHLucNOVz.size(); i++)
		{
			if (sbt_9j9viRkHLucNOVz[i] != pObject->sbt_9j9viRkHLucNOVz[i])
			{
				return false;
			}
		}
		if (sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC != pObject->sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC)
		{
			return false;
		}
		if (sbt_jt65yY6VH1rxB != pObject->sbt_jt65yY6VH1rxB)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_E6zONK6qj7a.c_str(), pObject->sbt_E6zONK6qj7a.c_str()))
		{
			return false;
		}
		if (sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ != pObject->sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ)
		{
			return false;
		}
		if (sbt_M2A_3UjRs7TQsQ8oXYp != pObject->sbt_M2A_3UjRs7TQsQ8oXYp)
		{
			return false;
		}
		if (sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.size() != pObject->sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D[i].c_str(), pObject->sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.size() != pObject->sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.size(); i++)
		{
			if (sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn[i] != pObject->sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn[i])
			{
				return false;
			}
		}
		if (sbt_EZsy40q.size() != pObject->sbt_EZsy40q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EZsy40q.size(); i++)
		{
			if (sbt_EZsy40q[i] != pObject->sbt_EZsy40q[i])
			{
				return false;
			}
		}
		if (sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.size() != pObject->sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.size(); i++)
		{
			if (sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP[i] != pObject->sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP[i])
			{
				return false;
			}
		}
		if (sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg != pObject->sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_fgTqNC36q.c_str(), pObject->sbt_fgTqNC36q.c_str()))
		{
			return false;
		}
		if (sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.size() != pObject->sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.size(); i++)
		{
			if (sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv[i] != pObject->sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv[i])
			{
				return false;
			}
		}
		if (sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.size() != pObject->sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.size(); i++)
		{
			if (sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0[i] != pObject->sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0[i])
			{
				return false;
			}
		}
		if (sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO != pObject->sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO)
		{
			return false;
		}
		if (sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2 != pObject->sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2)
		{
			return false;
		}
		if (sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX != pObject->sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX)
		{
			return false;
		}
		if (sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.size() != pObject->sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.size(); i++)
		{
			if (!sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA[i].Compare(&pObject->sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_Vgn", &sbt_Vgn)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HOC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HOC.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uRhKjKxu2rliqtDr6ZWkOjnj6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9j9viRkHLucNOVz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9j9viRkHLucNOVz.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_jt65yY6VH1rxB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jt65yY6VH1rxB = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_E6zONK6qj7a", &sbt_E6zONK6qj7a)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_M2A_3UjRs7TQsQ8oXYp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M2A_3UjRs7TQsQ8oXYp = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EZsy40q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EZsy40q.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_fgTqNC36q", &sbt_fgTqNC36q)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_Vgn", sbt_Vgn.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HOC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_HOC.begin(); iter != sbt_HOC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uRhKjKxu2rliqtDr6ZWkOjnj6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.begin(); iter != sbt_uRhKjKxu2rliqtDr6ZWkOjnj6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.begin(); iter != sbt_MT4ojyF2uPH9MfPZsuvqrx_MvmDqRtj8zknaycMr3DHxAmNJs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9j9viRkHLucNOVz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_9j9viRkHLucNOVz.begin(); iter != sbt_9j9viRkHLucNOVz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC", (CX::Double)sbt_gLtqMPkuFUQDdczqG_p4iQXH9DuIhcDEYrnqaq98iCyNDoC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jt65yY6VH1rxB", (CX::Int64)sbt_jt65yY6VH1rxB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_E6zONK6qj7a", sbt_E6zONK6qj7a.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ", (CX::Double)sbt_XXas4AnBzfHYPFXKkCrPh_OstltMTTvknCQLSLOdhMHFOjNsQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M2A_3UjRs7TQsQ8oXYp", (CX::Int64)sbt_M2A_3UjRs7TQsQ8oXYp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.begin(); iter != sbt_Sdpzum3SOVkrQxtIsy1FLUIb1Fa8D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.begin(); iter != sbt_fc6_9SDiPOrCkoXGq70SJiYy_mKFBIUfgq5SaAn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EZsy40q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_EZsy40q.begin(); iter != sbt_EZsy40q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.begin(); iter != sbt_GHcRAhnjpedxH6QHldphSvFugYn6N8GoP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg", (CX::Int64)sbt_cRbOPRhd62tUn955B0whuDoZXwgVzzpfHaGYg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_fgTqNC36q", sbt_fgTqNC36q.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.begin(); iter != sbt_RImdz0KOVK5bBHs32utMgv2jiLdaqxgMybsf2gqz_mg6ha5PDmv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.begin(); iter != sbt_7dM3JVeiVG7Fkn8UBvV_46Wbmkg7MMJwOpIzNqj_OfbodEce0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO", (CX::Int64)sbt_nA3id49QJWPGbRZTw_S7avKpIomLCXO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2", (CX::Int64)sbt_7uS8k3g8CfSxxf3oYcqtR7E2zL2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX", (CX::Int64)sbt_G97Iqxb7IisjDYaMEXsGBdhbWpM2BOrCvkM5F5jnX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA")).IsNOK())
		{
			return status;
		}
		for (sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilXArray::const_iterator iter = sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.begin(); iter != sbt_G0sIYuSDtOpu3olvBnRoCXuOK_Xgm5wAq464vGT0hTWMfjdL92MIJBA.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2nlE9M6VIZbAZqORGbUniQ_>::Type sbt_2nlE9M6VIZbAZqORGbUniQ_Array;

