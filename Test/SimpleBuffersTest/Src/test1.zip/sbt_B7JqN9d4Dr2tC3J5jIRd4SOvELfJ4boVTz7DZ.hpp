
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd;
	CX::Int16 sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik;
	CX::IO::SimpleBuffers::Int8Array sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4;
	CX::IO::SimpleBuffers::UInt32Array sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko;
	CX::IO::SimpleBuffers::UInt16Array sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5;

	virtual void Reset()
	{
		sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd = false;
		sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik = 0;
		sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.clear();
		sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.clear();
		sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd = false;
		sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik = -24734;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.push_back(78);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.push_back(2173036506);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.push_back(58949);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ *pObject = dynamic_cast<const sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd != pObject->sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd)
		{
			return false;
		}
		if (sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik != pObject->sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik)
		{
			return false;
		}
		if (sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.size() != pObject->sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.size(); i++)
		{
			if (sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4[i] != pObject->sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4[i])
			{
				return false;
			}
		}
		if (sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.size() != pObject->sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.size(); i++)
		{
			if (sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko[i] != pObject->sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko[i])
			{
				return false;
			}
		}
		if (sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.size() != pObject->sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.size(); i++)
		{
			if (sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5[i] != pObject->sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd", &sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd", sbt_SecnNU6tY8HZmYaaLAKbkbQvEMMCTIbVd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik", (CX::Int64)sbt_DC9e_oB6vEktmub5XibGdPCdP6RFzy5fHHYAXB2Lr23M18pbbxt76ik)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.begin(); iter != sbt_KOVh8JnDR02Gteu0RQrkBsT8f4I2UddquuVG4v_k4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.begin(); iter != sbt_sXSGTXQgdgujD4Q4oVSI87_kr2VCfaKRoko.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.begin(); iter != sbt_O9dilhitaN5cF2bTXhSjVT2v3xOgZ4cXzNZOkX5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ>::Type sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZArray;

