
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_3cmksv9geLsONvo.hpp"


class sbt_Fxu3FQkTl3BJionNv6S : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu;
	CX::IO::SimpleBuffers::WStringArray sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO;
	CX::UInt8 sbt_1a72qOGu16O;
	CX::IO::SimpleBuffers::Int16Array sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU;
	CX::UInt64 sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2;
	CX::IO::SimpleBuffers::Int8Array sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6;
	CX::UInt16 sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu;
	CX::WString sbt_zW1mXbSsaxmU5d5jDHo;
	CX::IO::SimpleBuffers::UInt64Array sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE;
	CX::UInt64 sbt_mK5EhqdUD_4HPKcsVF8;
	CX::Int32 sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z;
	CX::IO::SimpleBuffers::UInt16Array sbt_roZPn9_3cjR0QcfhLDhYybHccpe;
	CX::UInt16 sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7;
	CX::IO::SimpleBuffers::Int8Array sbt_iaTg1UOLidX1aqq3kqC9v;
	CX::Bool sbt_MH2o4J1i5ErrMEFti;
	CX::IO::SimpleBuffers::Int8Array sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B;
	CX::IO::SimpleBuffers::Int8Array sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_;
	CX::UInt8 sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw;
	CX::Int32 sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF;
	CX::Int32 sbt_8;
	CX::IO::SimpleBuffers::Int8Array sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b;
	CX::IO::SimpleBuffers::Int16Array sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38;
	sbt_3cmksv9geLsONvoArray sbt_uBy;

	virtual void Reset()
	{
		sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.clear();
		sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.clear();
		sbt_1a72qOGu16O = 0;
		sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.clear();
		sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2 = 0;
		sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.clear();
		sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu = 0;
		sbt_zW1mXbSsaxmU5d5jDHo.clear();
		sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.clear();
		sbt_mK5EhqdUD_4HPKcsVF8 = 0;
		sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z = 0;
		sbt_roZPn9_3cjR0QcfhLDhYybHccpe.clear();
		sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7 = 0;
		sbt_iaTg1UOLidX1aqq3kqC9v.clear();
		sbt_MH2o4J1i5ErrMEFti = false;
		sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.clear();
		sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.clear();
		sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw = 0;
		sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF = 0;
		sbt_8 = 0;
		sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.clear();
		sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.clear();
		sbt_uBy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.push_back(")X)@G};\"r~g-a.j[2-w2=hm3aXQi0^!#4:[}LZE0Z56>B3:[9N`");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.push_back(L"74k2;");
		}
		sbt_1a72qOGu16O = 248;
		sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2 = 17965277150526017348;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.push_back(-75);
		}
		sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu = 38139;
		sbt_zW1mXbSsaxmU5d5jDHo = L"2>{!h";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.push_back(10111272455586342796);
		}
		sbt_mK5EhqdUD_4HPKcsVF8 = 13490326334253196906;
		sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z = -1554281944;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_roZPn9_3cjR0QcfhLDhYybHccpe.push_back(31475);
		}
		sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7 = 59174;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_iaTg1UOLidX1aqq3kqC9v.push_back(-101);
		}
		sbt_MH2o4J1i5ErrMEFti = false;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.push_back(-106);
		}
		sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw = 88;
		sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF = 161732775;
		sbt_8 = -1353971270;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.push_back(45);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.push_back(-12698);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_3cmksv9geLsONvo v;

			v.SetupWithSomeValues();
			sbt_uBy.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Fxu3FQkTl3BJionNv6S *pObject = dynamic_cast<const sbt_Fxu3FQkTl3BJionNv6S *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.size() != pObject->sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.size(); i++)
		{
			if (0 != cx_strcmp(sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu[i].c_str(), pObject->sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.size() != pObject->sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO[i].c_str(), pObject->sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_1a72qOGu16O != pObject->sbt_1a72qOGu16O)
		{
			return false;
		}
		if (sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.size() != pObject->sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.size(); i++)
		{
			if (sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU[i] != pObject->sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU[i])
			{
				return false;
			}
		}
		if (sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2 != pObject->sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2)
		{
			return false;
		}
		if (sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.size() != pObject->sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.size(); i++)
		{
			if (sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6[i] != pObject->sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6[i])
			{
				return false;
			}
		}
		if (sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu != pObject->sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_zW1mXbSsaxmU5d5jDHo.c_str(), pObject->sbt_zW1mXbSsaxmU5d5jDHo.c_str()))
		{
			return false;
		}
		if (sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.size() != pObject->sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.size(); i++)
		{
			if (sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE[i] != pObject->sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE[i])
			{
				return false;
			}
		}
		if (sbt_mK5EhqdUD_4HPKcsVF8 != pObject->sbt_mK5EhqdUD_4HPKcsVF8)
		{
			return false;
		}
		if (sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z != pObject->sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z)
		{
			return false;
		}
		if (sbt_roZPn9_3cjR0QcfhLDhYybHccpe.size() != pObject->sbt_roZPn9_3cjR0QcfhLDhYybHccpe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_roZPn9_3cjR0QcfhLDhYybHccpe.size(); i++)
		{
			if (sbt_roZPn9_3cjR0QcfhLDhYybHccpe[i] != pObject->sbt_roZPn9_3cjR0QcfhLDhYybHccpe[i])
			{
				return false;
			}
		}
		if (sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7 != pObject->sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7)
		{
			return false;
		}
		if (sbt_iaTg1UOLidX1aqq3kqC9v.size() != pObject->sbt_iaTg1UOLidX1aqq3kqC9v.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iaTg1UOLidX1aqq3kqC9v.size(); i++)
		{
			if (sbt_iaTg1UOLidX1aqq3kqC9v[i] != pObject->sbt_iaTg1UOLidX1aqq3kqC9v[i])
			{
				return false;
			}
		}
		if (sbt_MH2o4J1i5ErrMEFti != pObject->sbt_MH2o4J1i5ErrMEFti)
		{
			return false;
		}
		if (sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.size() != pObject->sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.size(); i++)
		{
			if (sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B[i] != pObject->sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B[i])
			{
				return false;
			}
		}
		if (sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.size() != pObject->sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.size(); i++)
		{
			if (sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_[i] != pObject->sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_[i])
			{
				return false;
			}
		}
		if (sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw != pObject->sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw)
		{
			return false;
		}
		if (sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF != pObject->sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF)
		{
			return false;
		}
		if (sbt_8 != pObject->sbt_8)
		{
			return false;
		}
		if (sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.size() != pObject->sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.size(); i++)
		{
			if (sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b[i] != pObject->sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b[i])
			{
				return false;
			}
		}
		if (sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.size() != pObject->sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.size(); i++)
		{
			if (sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38[i] != pObject->sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38[i])
			{
				return false;
			}
		}
		if (sbt_uBy.size() != pObject->sbt_uBy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uBy.size(); i++)
		{
			if (!sbt_uBy[i].Compare(&pObject->sbt_uBy[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1a72qOGu16O", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1a72qOGu16O = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_zW1mXbSsaxmU5d5jDHo", &sbt_zW1mXbSsaxmU5d5jDHo)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mK5EhqdUD_4HPKcsVF8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mK5EhqdUD_4HPKcsVF8 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_roZPn9_3cjR0QcfhLDhYybHccpe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_roZPn9_3cjR0QcfhLDhYybHccpe.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iaTg1UOLidX1aqq3kqC9v")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iaTg1UOLidX1aqq3kqC9v.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_MH2o4J1i5ErrMEFti", &sbt_MH2o4J1i5ErrMEFti)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uBy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_3cmksv9geLsONvo tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_uBy.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.begin(); iter != sbt_wzCtXPLtLIjLjeBrUjEqYvLSdwu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.begin(); iter != sbt_Hr9oMocJVH3aNi42lc0MVU97QGIfGYbQRYhiylxmoXDKObDMeHIfeIlPCX4VUXO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1a72qOGu16O", (CX::Int64)sbt_1a72qOGu16O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.begin(); iter != sbt_c1QypBxIR8RDy9oIfEvPc8cYWoTeNSsJAsrN5wTnzYxwi6zK1IvLpEU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2", (CX::Int64)sbt_2Y2lYu5wKZJEm3igBWAMnj8aEfBHdLuySoVBK05U7cfbpGgK2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.begin(); iter != sbt_5RLgif1NvcDqZsu4lLeWG4Ci3E6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu", (CX::Int64)sbt_wqMIG4wDKlyThMMOja2oVv3q0kZB69jCNcpoX66FZhxk5eiLNyu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_zW1mXbSsaxmU5d5jDHo", sbt_zW1mXbSsaxmU5d5jDHo.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.begin(); iter != sbt_vO2yC_wNqKtFx7Ogu9OwsIDHGnZCTY15Z71XzlaTleZk2gEWgB1wZvE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mK5EhqdUD_4HPKcsVF8", (CX::Int64)sbt_mK5EhqdUD_4HPKcsVF8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z", (CX::Int64)sbt_ltM4vkrUAkwyiUoISHlXbYCoofdel79aBpnUY18rE3Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_roZPn9_3cjR0QcfhLDhYybHccpe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_roZPn9_3cjR0QcfhLDhYybHccpe.begin(); iter != sbt_roZPn9_3cjR0QcfhLDhYybHccpe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7", (CX::Int64)sbt_0xgNMxOHfToxHWeTIluKa3H4gmPwIXlG5CVkhXxNuOUajmJY7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iaTg1UOLidX1aqq3kqC9v")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_iaTg1UOLidX1aqq3kqC9v.begin(); iter != sbt_iaTg1UOLidX1aqq3kqC9v.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_MH2o4J1i5ErrMEFti", sbt_MH2o4J1i5ErrMEFti)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.begin(); iter != sbt_VmIp3g4REGfqPz7ANF_JxqvY2jTqZRu9OIk3HIlrs4voav1GU7B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.begin(); iter != sbt_Q7QVMio7KfombgMZ3RT_FNMvwm_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw", (CX::Int64)sbt_CZyawWpGiwkyCGReSxfIx3DQEbiv_qqspUX3_Lejw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF", (CX::Int64)sbt__Ca58vJa8XSOmBzRufkqzflGNLnYIYf_LgDWwxcE3IzqnkI8aneQi3llxf1jF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8", (CX::Int64)sbt_8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.begin(); iter != sbt_oh6hse5ioeyaHjcYEvZIqNdgCsC8b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.begin(); iter != sbt_4pCiWgt1_wcnWvQV9tpoO192ikAGNKZ9Rdu5y38.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uBy")).IsNOK())
		{
			return status;
		}
		for (sbt_3cmksv9geLsONvoArray::const_iterator iter = sbt_uBy.begin(); iter != sbt_uBy.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Fxu3FQkTl3BJionNv6S>::Type sbt_Fxu3FQkTl3BJionNv6SArray;

