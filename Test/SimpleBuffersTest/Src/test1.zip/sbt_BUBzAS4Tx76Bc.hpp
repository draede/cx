
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_x6tWbffuGKf.hpp"


class sbt_BUBzAS4Tx76Bc : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_Y;
	CX::IO::SimpleBuffers::UInt32Array sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN;
	CX::IO::SimpleBuffers::UInt32Array sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7;
	CX::WString sbt_E4QvrfqEDQwfu;
	CX::Int32 sbt_lCzIV9CDbc_;
	CX::IO::SimpleBuffers::BoolArray sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8;
	CX::IO::SimpleBuffers::WStringArray sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU;
	CX::IO::SimpleBuffers::Int16Array sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid;
	CX::Int8 sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77;
	CX::IO::SimpleBuffers::WStringArray sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF;
	CX::UInt8 sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl;
	CX::IO::SimpleBuffers::Int16Array sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS;
	CX::IO::SimpleBuffers::UInt8Array sbt_Xfs8x_XmnXYVZRl;
	CX::Float sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO;
	CX::UInt32 sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g;
	CX::IO::SimpleBuffers::UInt16Array sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN;
	CX::UInt32 sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu;
	CX::Int32 sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97;
	CX::Int16 sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4;
	sbt_x6tWbffuGKfArray sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC;

	virtual void Reset()
	{
		sbt_Y.clear();
		sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.clear();
		sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.clear();
		sbt_E4QvrfqEDQwfu.clear();
		sbt_lCzIV9CDbc_ = 0;
		sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.clear();
		sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.clear();
		sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.clear();
		sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77 = 0;
		sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.clear();
		sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl = 0;
		sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.clear();
		sbt_Xfs8x_XmnXYVZRl.clear();
		sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO = 0.0f;
		sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g = 0;
		sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.clear();
		sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu = 0;
		sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97 = 0;
		sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4 = 0;
		sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Y.push_back(0.474181f);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.push_back(3031326735);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.push_back(4128774913);
		}
		sbt_E4QvrfqEDQwfu = L"9:<\"7/W/Z%R@4e;2<ByL-Lf5p8@,DsQn@X}";
		sbt_lCzIV9CDbc_ = 791383940;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.push_back(true);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.push_back(L"g%QfV9tS=C^aG33)^W0xa1Ka\"J-vlN,mYPlF6NvChS!X>8O?YvOGi_W");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.push_back(7115);
		}
		sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77 = 79;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.push_back(L"n>m.a.'/FOr|xxtWtIRE;aK54AioWF{zS,S!<1m;+$UcaaH)7N{,I%nVe0z@cI/");
		}
		sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl = 129;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.push_back(31512);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Xfs8x_XmnXYVZRl.push_back(94);
		}
		sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO = 0.094577f;
		sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g = 2782317888;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.push_back(48464);
		}
		sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu = 3262486924;
		sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97 = 1577513929;
		sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4 = -9529;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_x6tWbffuGKf v;

			v.SetupWithSomeValues();
			sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_BUBzAS4Tx76Bc *pObject = dynamic_cast<const sbt_BUBzAS4Tx76Bc *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Y.size() != pObject->sbt_Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y.size(); i++)
		{
			if (sbt_Y[i] != pObject->sbt_Y[i])
			{
				return false;
			}
		}
		if (sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.size() != pObject->sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.size(); i++)
		{
			if (sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN[i] != pObject->sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN[i])
			{
				return false;
			}
		}
		if (sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.size() != pObject->sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.size(); i++)
		{
			if (sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7[i] != pObject->sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_E4QvrfqEDQwfu.c_str(), pObject->sbt_E4QvrfqEDQwfu.c_str()))
		{
			return false;
		}
		if (sbt_lCzIV9CDbc_ != pObject->sbt_lCzIV9CDbc_)
		{
			return false;
		}
		if (sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.size() != pObject->sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.size(); i++)
		{
			if (sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8[i] != pObject->sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8[i])
			{
				return false;
			}
		}
		if (sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.size() != pObject->sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU[i].c_str(), pObject->sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.size() != pObject->sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.size(); i++)
		{
			if (sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid[i] != pObject->sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid[i])
			{
				return false;
			}
		}
		if (sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77 != pObject->sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77)
		{
			return false;
		}
		if (sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.size() != pObject->sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF[i].c_str(), pObject->sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl != pObject->sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl)
		{
			return false;
		}
		if (sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.size() != pObject->sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.size(); i++)
		{
			if (sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS[i] != pObject->sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS[i])
			{
				return false;
			}
		}
		if (sbt_Xfs8x_XmnXYVZRl.size() != pObject->sbt_Xfs8x_XmnXYVZRl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Xfs8x_XmnXYVZRl.size(); i++)
		{
			if (sbt_Xfs8x_XmnXYVZRl[i] != pObject->sbt_Xfs8x_XmnXYVZRl[i])
			{
				return false;
			}
		}
		if (sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO != pObject->sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO)
		{
			return false;
		}
		if (sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g != pObject->sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g)
		{
			return false;
		}
		if (sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.size() != pObject->sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.size(); i++)
		{
			if (sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN[i] != pObject->sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN[i])
			{
				return false;
			}
		}
		if (sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu != pObject->sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu)
		{
			return false;
		}
		if (sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97 != pObject->sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97)
		{
			return false;
		}
		if (sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4 != pObject->sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4)
		{
			return false;
		}
		if (sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.size() != pObject->sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.size(); i++)
		{
			if (!sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC[i].Compare(&pObject->sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_E4QvrfqEDQwfu", &sbt_E4QvrfqEDQwfu)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lCzIV9CDbc_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lCzIV9CDbc_ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Xfs8x_XmnXYVZRl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Xfs8x_XmnXYVZRl.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_x6tWbffuGKf tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Y.begin(); iter != sbt_Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.begin(); iter != sbt_5W0ZbxPwpWgdLug17e_Dc2Lyxe3MrpQzhhSNN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.begin(); iter != sbt_wZ8Bw_h0igyC668XSqOyQoREGhYU7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_E4QvrfqEDQwfu", sbt_E4QvrfqEDQwfu.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lCzIV9CDbc_", (CX::Int64)sbt_lCzIV9CDbc_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.begin(); iter != sbt_4ZTreO0mbhhq_0nxdF91JZuhhh8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.begin(); iter != sbt_kUgu1yQ7zGjhC1mEMYIxrt0SoePgCmD4lwfbvSU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.begin(); iter != sbt_71_Rha06fwQ4mcv642A0ue600t8tpBSKDscLiid.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77", (CX::Int64)sbt_OpLInoRJSSwnPBvr5GBBljopaqBxVXAweVsJ6IAQwCbM_jQ77)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.begin(); iter != sbt_hvlGzIKmut3rn3aL8stmSQLEAOgKxyXe2zkX1B8t2RP8YVRYUdndt1FRerF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl", (CX::Int64)sbt_lTjy1EG9dUdsH1gdc7QKL8PBGB1kh1Jh6zxUI61Rxt6_xsZX_QAygjiF00UZl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.begin(); iter != sbt_dpHGu6OzyX3_HuftuGlVsKQCN7xW60sCOlbIkyOAFIPj0JYBcVxeh6eyqThPaUS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Xfs8x_XmnXYVZRl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Xfs8x_XmnXYVZRl.begin(); iter != sbt_Xfs8x_XmnXYVZRl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO", (CX::Double)sbt_J0SQSO1D0D7NQQhiT5QombXmyPR_vxwcQ8zVO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g", (CX::Int64)sbt_WWgYFiZTy1tJ3ll1hjQPk9XtNHLhrevY81Uw6HJbASdMSWL6g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.begin(); iter != sbt_Hj2FpfSUTSdIoFID4znwnH3DPiginxjrN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu", (CX::Int64)sbt__0FM_7TTEO01IQx5N9lTmRUDHwA4uBQT4kJsseu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97", (CX::Int64)sbt__cDGxFBRWLhf6m1Kl1QmbyH9P97)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4", (CX::Int64)sbt_DDC1RYwY3VBSX3jkT3NzRwMEEe0BKkV9OS4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC")).IsNOK())
		{
			return status;
		}
		for (sbt_x6tWbffuGKfArray::const_iterator iter = sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.begin(); iter != sbt_hjhGYwXaZJsHletY7r1mFjh82KNlipI7OiOV254fC.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_BUBzAS4Tx76Bc>::Type sbt_BUBzAS4Tx76BcArray;

