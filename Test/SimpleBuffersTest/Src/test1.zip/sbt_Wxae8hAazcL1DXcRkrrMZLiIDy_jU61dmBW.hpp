
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH;
	CX::IO::SimpleBuffers::UInt16Array sbt_QjSAtSoViOAav18Lp;
	CX::UInt64 sbt_S1tZdVt;
	CX::Int16 sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX;
	CX::UInt32 sbt_5iU;
	CX::Int8 sbt_nas78oDrJAb;
	CX::Int16 sbt_rc1IwCzGyTn1NqQKTM96BzghkVF;
	CX::Int32 sbt_ZWe;
	CX::Int64 sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI;
	CX::IO::SimpleBuffers::UInt64Array sbt_P;
	CX::IO::SimpleBuffers::UInt16Array sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk;
	CX::Bool sbt_wT3DIEuZBdgaLOvmbUc;
	CX::IO::SimpleBuffers::UInt64Array sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD;
	CX::IO::SimpleBuffers::Int8Array sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl;
	CX::IO::SimpleBuffers::UInt8Array sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd;
	CX::UInt64 sbt_Bhf;
	CX::UInt8 sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C;
	CX::UInt8 sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n;
	CX::String sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9;
	CX::UInt32 sbt_rsSh2_1Y4dZzjezbLDfbt;

	virtual void Reset()
	{
		sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH = 0;
		sbt_QjSAtSoViOAav18Lp.clear();
		sbt_S1tZdVt = 0;
		sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX = 0;
		sbt_5iU = 0;
		sbt_nas78oDrJAb = 0;
		sbt_rc1IwCzGyTn1NqQKTM96BzghkVF = 0;
		sbt_ZWe = 0;
		sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI = 0;
		sbt_P.clear();
		sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.clear();
		sbt_wT3DIEuZBdgaLOvmbUc = false;
		sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.clear();
		sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.clear();
		sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.clear();
		sbt_Bhf = 0;
		sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C = 0;
		sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n = 0;
		sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9.clear();
		sbt_rsSh2_1Y4dZzjezbLDfbt = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH = -20721;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_QjSAtSoViOAav18Lp.push_back(21067);
		}
		sbt_S1tZdVt = 1456524013674898550;
		sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX = 6458;
		sbt_5iU = 4116419739;
		sbt_nas78oDrJAb = 79;
		sbt_rc1IwCzGyTn1NqQKTM96BzghkVF = 3504;
		sbt_ZWe = 1391907286;
		sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI = -380554479515133226;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_P.push_back(489369075372875346);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.push_back(6146);
		}
		sbt_wT3DIEuZBdgaLOvmbUc = true;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.push_back(5942651845952969410);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.push_back(92);
		}
		sbt_Bhf = 18190311435133362314;
		sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C = 149;
		sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n = 37;
		sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9 = "*0@ENr*IBQA$z`dKf]3E=PAxQ+,K5sHvDaE')c";
		sbt_rsSh2_1Y4dZzjezbLDfbt = 426685213;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW *pObject = dynamic_cast<const sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH != pObject->sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH)
		{
			return false;
		}
		if (sbt_QjSAtSoViOAav18Lp.size() != pObject->sbt_QjSAtSoViOAav18Lp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QjSAtSoViOAav18Lp.size(); i++)
		{
			if (sbt_QjSAtSoViOAav18Lp[i] != pObject->sbt_QjSAtSoViOAav18Lp[i])
			{
				return false;
			}
		}
		if (sbt_S1tZdVt != pObject->sbt_S1tZdVt)
		{
			return false;
		}
		if (sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX != pObject->sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX)
		{
			return false;
		}
		if (sbt_5iU != pObject->sbt_5iU)
		{
			return false;
		}
		if (sbt_nas78oDrJAb != pObject->sbt_nas78oDrJAb)
		{
			return false;
		}
		if (sbt_rc1IwCzGyTn1NqQKTM96BzghkVF != pObject->sbt_rc1IwCzGyTn1NqQKTM96BzghkVF)
		{
			return false;
		}
		if (sbt_ZWe != pObject->sbt_ZWe)
		{
			return false;
		}
		if (sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI != pObject->sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI)
		{
			return false;
		}
		if (sbt_P.size() != pObject->sbt_P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P.size(); i++)
		{
			if (sbt_P[i] != pObject->sbt_P[i])
			{
				return false;
			}
		}
		if (sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.size() != pObject->sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.size(); i++)
		{
			if (sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk[i] != pObject->sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk[i])
			{
				return false;
			}
		}
		if (sbt_wT3DIEuZBdgaLOvmbUc != pObject->sbt_wT3DIEuZBdgaLOvmbUc)
		{
			return false;
		}
		if (sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.size() != pObject->sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.size(); i++)
		{
			if (sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD[i] != pObject->sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD[i])
			{
				return false;
			}
		}
		if (sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.size() != pObject->sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.size(); i++)
		{
			if (sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl[i] != pObject->sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl[i])
			{
				return false;
			}
		}
		if (sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.size() != pObject->sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.size(); i++)
		{
			if (sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd[i] != pObject->sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd[i])
			{
				return false;
			}
		}
		if (sbt_Bhf != pObject->sbt_Bhf)
		{
			return false;
		}
		if (sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C != pObject->sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C)
		{
			return false;
		}
		if (sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n != pObject->sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9.c_str(), pObject->sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9.c_str()))
		{
			return false;
		}
		if (sbt_rsSh2_1Y4dZzjezbLDfbt != pObject->sbt_rsSh2_1Y4dZzjezbLDfbt)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_QjSAtSoViOAav18Lp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QjSAtSoViOAav18Lp.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_S1tZdVt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S1tZdVt = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5iU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5iU = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nas78oDrJAb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nas78oDrJAb = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rc1IwCzGyTn1NqQKTM96BzghkVF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rc1IwCzGyTn1NqQKTM96BzghkVF = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZWe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZWe = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_wT3DIEuZBdgaLOvmbUc", &sbt_wT3DIEuZBdgaLOvmbUc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Bhf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Bhf = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectString("sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9", &sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rsSh2_1Y4dZzjezbLDfbt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rsSh2_1Y4dZzjezbLDfbt = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH", (CX::Int64)sbt_tLtvjZ2pdigSM24jYLSxqAGZsRIbTSX06ulC0RQWqJK8rQoZ5mYtyI0WrCYuH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QjSAtSoViOAav18Lp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_QjSAtSoViOAav18Lp.begin(); iter != sbt_QjSAtSoViOAav18Lp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S1tZdVt", (CX::Int64)sbt_S1tZdVt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX", (CX::Int64)sbt_7w2xMS2blmPtW6rqB_KLWo8gnizI2emZSAhyEiHbX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5iU", (CX::Int64)sbt_5iU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nas78oDrJAb", (CX::Int64)sbt_nas78oDrJAb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rc1IwCzGyTn1NqQKTM96BzghkVF", (CX::Int64)sbt_rc1IwCzGyTn1NqQKTM96BzghkVF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZWe", (CX::Int64)sbt_ZWe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI", (CX::Int64)sbt_X0Sbewbw8qjUOPEeGMwnTN6yKeI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_P.begin(); iter != sbt_P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.begin(); iter != sbt_Mp72mRhSQc3uq4kG3yxHWRlSUYgWcltFqwB6agU3kU_Mk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_wT3DIEuZBdgaLOvmbUc", sbt_wT3DIEuZBdgaLOvmbUc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.begin(); iter != sbt_PasvBg3A5iMavU9vGGfoXoQrOOChH3mC8wJZq6PcPKScQUHDem_GfcD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.begin(); iter != sbt_52eZylqjIseyU83525RGITfRlChMpVZwN3Nle9lQCiOZJUHU0wl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.begin(); iter != sbt_OjBrtJaPLZxU5Mwlab3QG6eP5C16q_iGHukvP32S1nUBK4lqRkPO2iKHN9ULd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Bhf", (CX::Int64)sbt_Bhf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C", (CX::Int64)sbt_rKItOLgiqHaeOFLQsxE5QJ2WhQurxlVviX33C)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n", (CX::Int64)sbt_dhRqdGPPzTn6weWstUZqhr1NqjZXCTCIOUBy7EnYXw20MFC9RxxdJYTiQwOMT9n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9", sbt_esfdIrXzu0FBx82XDOdgompGdzOFbA0GFkrVLaXG25vU9.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rsSh2_1Y4dZzjezbLDfbt", (CX::Int64)sbt_rsSh2_1Y4dZzjezbLDfbt)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW>::Type sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBWArray;

