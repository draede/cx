
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_cYxfyXlT2u5kIewZ3To16AL61 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy;
	CX::Int16 sbt_LzzZRRc82BZyjznRN6e;
	CX::UInt32 sbt_q_J76tBHhdN;
	CX::IO::SimpleBuffers::UInt32Array sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP;
	CX::UInt64 sbt_a6v_m;
	CX::IO::SimpleBuffers::StringArray sbt_bzkLmgmEVGb7xcARMd668;
	CX::IO::SimpleBuffers::Int8Array sbt_v1DDxvTs10j;
	CX::IO::SimpleBuffers::UInt16Array sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8;
	CX::UInt64 sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl;
	CX::IO::SimpleBuffers::Int32Array sbt_PpWiwOVaz7wllQH22M0;
	CX::IO::SimpleBuffers::BoolArray sbt__;
	CX::IO::SimpleBuffers::UInt32Array sbt_o;
	CX::UInt32 sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh;
	CX::UInt8 sbt_UwuCis2MfHasZIHw7Ass3;
	CX::IO::SimpleBuffers::UInt32Array sbt_OKEvGzB4Zz2;
	CX::IO::SimpleBuffers::Int32Array sbt_0PLXo5Xarh6sqRYNK;
	CX::IO::SimpleBuffers::Int64Array sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs;
	CX::Int64 sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p;
	CX::UInt64 sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg;
	CX::IO::SimpleBuffers::Int32Array sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw;
	CX::IO::SimpleBuffers::UInt8Array sbt_HOlg2C9mE1uj2ZEUOswagwWXR;
	CX::IO::SimpleBuffers::StringArray sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx;
	CX::IO::SimpleBuffers::StringArray sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5;

	virtual void Reset()
	{
		sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.clear();
		sbt_LzzZRRc82BZyjznRN6e = 0;
		sbt_q_J76tBHhdN = 0;
		sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.clear();
		sbt_a6v_m = 0;
		sbt_bzkLmgmEVGb7xcARMd668.clear();
		sbt_v1DDxvTs10j.clear();
		sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.clear();
		sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl = 0;
		sbt_PpWiwOVaz7wllQH22M0.clear();
		sbt__.clear();
		sbt_o.clear();
		sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh = 0;
		sbt_UwuCis2MfHasZIHw7Ass3 = 0;
		sbt_OKEvGzB4Zz2.clear();
		sbt_0PLXo5Xarh6sqRYNK.clear();
		sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.clear();
		sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p = 0;
		sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg = 0;
		sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.clear();
		sbt_HOlg2C9mE1uj2ZEUOswagwWXR.clear();
		sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.clear();
		sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.push_back(-7297);
		}
		sbt_LzzZRRc82BZyjznRN6e = -24935;
		sbt_q_J76tBHhdN = 3939830423;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.push_back(1630038390);
		}
		sbt_a6v_m = 3046110340686990864;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_bzkLmgmEVGb7xcARMd668.push_back("'TNJ/HfytM!8jQ!%,zYR!+jP&#I96TrJv#9'#tS4");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_v1DDxvTs10j.push_back(-39);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.push_back(23368);
		}
		sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl = 12962715538618525816;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_PpWiwOVaz7wllQH22M0.push_back(1444757337);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt__.push_back(false);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_o.push_back(2893370876);
		}
		sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh = 3882909359;
		sbt_UwuCis2MfHasZIHw7Ass3 = 249;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_OKEvGzB4Zz2.push_back(4060620023);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_0PLXo5Xarh6sqRYNK.push_back(-642307757);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.push_back(-5946295592122309836);
		}
		sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p = 6351772166315709174;
		sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg = 5328900864497351140;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.push_back(1829928516);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_HOlg2C9mE1uj2ZEUOswagwWXR.push_back(209);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.push_back("jNWgS8=aI`wXF!V4#:2!&,HYd]$FJ9YHOxUm\\vU|^#<_-y@6XQ,4JKv6;\\/\"P4Gj");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.push_back("rDo!Y=f,%AJ8Kj48U@jAFo;4KN1cQ}I`\"OppQ7N|J0VR[@KL*)\"sl/(bWJApL");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_cYxfyXlT2u5kIewZ3To16AL61 *pObject = dynamic_cast<const sbt_cYxfyXlT2u5kIewZ3To16AL61 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.size() != pObject->sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.size(); i++)
		{
			if (sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy[i] != pObject->sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy[i])
			{
				return false;
			}
		}
		if (sbt_LzzZRRc82BZyjznRN6e != pObject->sbt_LzzZRRc82BZyjznRN6e)
		{
			return false;
		}
		if (sbt_q_J76tBHhdN != pObject->sbt_q_J76tBHhdN)
		{
			return false;
		}
		if (sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.size() != pObject->sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.size(); i++)
		{
			if (sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP[i] != pObject->sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP[i])
			{
				return false;
			}
		}
		if (sbt_a6v_m != pObject->sbt_a6v_m)
		{
			return false;
		}
		if (sbt_bzkLmgmEVGb7xcARMd668.size() != pObject->sbt_bzkLmgmEVGb7xcARMd668.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bzkLmgmEVGb7xcARMd668.size(); i++)
		{
			if (0 != cx_strcmp(sbt_bzkLmgmEVGb7xcARMd668[i].c_str(), pObject->sbt_bzkLmgmEVGb7xcARMd668[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_v1DDxvTs10j.size() != pObject->sbt_v1DDxvTs10j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v1DDxvTs10j.size(); i++)
		{
			if (sbt_v1DDxvTs10j[i] != pObject->sbt_v1DDxvTs10j[i])
			{
				return false;
			}
		}
		if (sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.size() != pObject->sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.size(); i++)
		{
			if (sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8[i] != pObject->sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8[i])
			{
				return false;
			}
		}
		if (sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl != pObject->sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl)
		{
			return false;
		}
		if (sbt_PpWiwOVaz7wllQH22M0.size() != pObject->sbt_PpWiwOVaz7wllQH22M0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PpWiwOVaz7wllQH22M0.size(); i++)
		{
			if (sbt_PpWiwOVaz7wllQH22M0[i] != pObject->sbt_PpWiwOVaz7wllQH22M0[i])
			{
				return false;
			}
		}
		if (sbt__.size() != pObject->sbt__.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__.size(); i++)
		{
			if (sbt__[i] != pObject->sbt__[i])
			{
				return false;
			}
		}
		if (sbt_o.size() != pObject->sbt_o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o.size(); i++)
		{
			if (sbt_o[i] != pObject->sbt_o[i])
			{
				return false;
			}
		}
		if (sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh != pObject->sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh)
		{
			return false;
		}
		if (sbt_UwuCis2MfHasZIHw7Ass3 != pObject->sbt_UwuCis2MfHasZIHw7Ass3)
		{
			return false;
		}
		if (sbt_OKEvGzB4Zz2.size() != pObject->sbt_OKEvGzB4Zz2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OKEvGzB4Zz2.size(); i++)
		{
			if (sbt_OKEvGzB4Zz2[i] != pObject->sbt_OKEvGzB4Zz2[i])
			{
				return false;
			}
		}
		if (sbt_0PLXo5Xarh6sqRYNK.size() != pObject->sbt_0PLXo5Xarh6sqRYNK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0PLXo5Xarh6sqRYNK.size(); i++)
		{
			if (sbt_0PLXo5Xarh6sqRYNK[i] != pObject->sbt_0PLXo5Xarh6sqRYNK[i])
			{
				return false;
			}
		}
		if (sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.size() != pObject->sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.size(); i++)
		{
			if (sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs[i] != pObject->sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs[i])
			{
				return false;
			}
		}
		if (sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p != pObject->sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p)
		{
			return false;
		}
		if (sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg != pObject->sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg)
		{
			return false;
		}
		if (sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.size() != pObject->sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.size(); i++)
		{
			if (sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw[i] != pObject->sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw[i])
			{
				return false;
			}
		}
		if (sbt_HOlg2C9mE1uj2ZEUOswagwWXR.size() != pObject->sbt_HOlg2C9mE1uj2ZEUOswagwWXR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HOlg2C9mE1uj2ZEUOswagwWXR.size(); i++)
		{
			if (sbt_HOlg2C9mE1uj2ZEUOswagwWXR[i] != pObject->sbt_HOlg2C9mE1uj2ZEUOswagwWXR[i])
			{
				return false;
			}
		}
		if (sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.size() != pObject->sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.size(); i++)
		{
			if (0 != cx_strcmp(sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx[i].c_str(), pObject->sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.size() != pObject->sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.size(); i++)
		{
			if (0 != cx_strcmp(sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5[i].c_str(), pObject->sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LzzZRRc82BZyjznRN6e", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LzzZRRc82BZyjznRN6e = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_q_J76tBHhdN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_q_J76tBHhdN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_a6v_m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a6v_m = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bzkLmgmEVGb7xcARMd668")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bzkLmgmEVGb7xcARMd668.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_v1DDxvTs10j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_v1DDxvTs10j.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PpWiwOVaz7wllQH22M0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PpWiwOVaz7wllQH22M0.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UwuCis2MfHasZIHw7Ass3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UwuCis2MfHasZIHw7Ass3 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OKEvGzB4Zz2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OKEvGzB4Zz2.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0PLXo5Xarh6sqRYNK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0PLXo5Xarh6sqRYNK.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HOlg2C9mE1uj2ZEUOswagwWXR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HOlg2C9mE1uj2ZEUOswagwWXR.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.begin(); iter != sbt_HeKZ5dOn7OcFSgmIhroaeuk4XkCvEzSTveLTJJYVoZy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LzzZRRc82BZyjznRN6e", (CX::Int64)sbt_LzzZRRc82BZyjznRN6e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_q_J76tBHhdN", (CX::Int64)sbt_q_J76tBHhdN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.begin(); iter != sbt_I5jB02QzEV5UNnt5WK9nm4iYOypVP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_a6v_m", (CX::Int64)sbt_a6v_m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bzkLmgmEVGb7xcARMd668")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_bzkLmgmEVGb7xcARMd668.begin(); iter != sbt_bzkLmgmEVGb7xcARMd668.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_v1DDxvTs10j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_v1DDxvTs10j.begin(); iter != sbt_v1DDxvTs10j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.begin(); iter != sbt_NngzacoWaUVr4SgWcXDy8TSZfl_FVGO20L8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl", (CX::Int64)sbt_ozbkhiL3KnjEIBhCHV41rK4izWbRiE5bl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PpWiwOVaz7wllQH22M0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_PpWiwOVaz7wllQH22M0.begin(); iter != sbt_PpWiwOVaz7wllQH22M0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt__.begin(); iter != sbt__.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_o.begin(); iter != sbt_o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh", (CX::Int64)sbt_VQ3ixZ61xJ0sDaowkVtExVsgwyHUngmDCf60iwh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UwuCis2MfHasZIHw7Ass3", (CX::Int64)sbt_UwuCis2MfHasZIHw7Ass3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OKEvGzB4Zz2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_OKEvGzB4Zz2.begin(); iter != sbt_OKEvGzB4Zz2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0PLXo5Xarh6sqRYNK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_0PLXo5Xarh6sqRYNK.begin(); iter != sbt_0PLXo5Xarh6sqRYNK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.begin(); iter != sbt_1xWP5b9JtBIMNE6cvqAP7NgblJYZcJuGZgs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p", (CX::Int64)sbt_I2X2B_7d1Zo6Tpqdm9ry9slPcehMSA4APEOXow1ud7p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg", (CX::Int64)sbt_dPrQyE5fXMTbtKxzTvmIypWSmfjpg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.begin(); iter != sbt_bI3xjs08TgPGXBwrsNW3O5DMKUXfwOHPXmqo3c5uZ0cItYNBCb7sw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HOlg2C9mE1uj2ZEUOswagwWXR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_HOlg2C9mE1uj2ZEUOswagwWXR.begin(); iter != sbt_HOlg2C9mE1uj2ZEUOswagwWXR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.begin(); iter != sbt_UndgiRSaCzBw12Nfj_IXj1LqJJRO9NNVD97BU9UamjqFyKctiRMIBzO61MmjqXx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.begin(); iter != sbt_D3Qq6PsrfO8ElEncArnEVSds7CO8XwPGx06NMSx1a1T1_nfMTC5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_cYxfyXlT2u5kIewZ3To16AL61>::Type sbt_cYxfyXlT2u5kIewZ3To16AL61Array;

