
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_oGQc9MTwA.hpp"


class sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu;
	CX::UInt64 sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq;
	CX::IO::SimpleBuffers::BoolArray sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K;
	CX::UInt16 sbt_PRl9XZDpd;
	sbt_oGQc9MTwAArray sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya;

	virtual void Reset()
	{
		sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu.clear();
		sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq = 0;
		sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.clear();
		sbt_PRl9XZDpd = 0;
		sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu = "HJj0~k|!cj+u+Dc1orTyMTZbA@xYtZb?6";
		sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq = 18058551262741126192;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.push_back(false);
		}
		sbt_PRl9XZDpd = 56679;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_oGQc9MTwA v;

			v.SetupWithSomeValues();
			sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ *pObject = dynamic_cast<const sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu.c_str(), pObject->sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu.c_str()))
		{
			return false;
		}
		if (sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq != pObject->sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq)
		{
			return false;
		}
		if (sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.size() != pObject->sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.size(); i++)
		{
			if (sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K[i] != pObject->sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K[i])
			{
				return false;
			}
		}
		if (sbt_PRl9XZDpd != pObject->sbt_PRl9XZDpd)
		{
			return false;
		}
		if (sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.size() != pObject->sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.size(); i++)
		{
			if (!sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya[i].Compare(&pObject->sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu", &sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PRl9XZDpd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PRl9XZDpd = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_oGQc9MTwA tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu", sbt_wrSyo77vtJYFPPkmUkBOyhrnhtRNmBkQoNkBAIvDdjv3hM888dgRDFnFw1OFTGu.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq", (CX::Int64)sbt_3Fc7B3cNWoV9nY5Vc4XRmM3o4XBxjT1DRL_RrRq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.begin(); iter != sbt_jEK3RciHUSeOzFiO1NHiCvojQ86fS6K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PRl9XZDpd", (CX::Int64)sbt_PRl9XZDpd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya")).IsNOK())
		{
			return status;
		}
		for (sbt_oGQc9MTwAArray::const_iterator iter = sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.begin(); iter != sbt_EgKaD4BPxhfjMabTi2tYSI6DlqzKmffHvbpya.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ>::Type sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZArray;

