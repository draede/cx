
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs;
	CX::UInt32 sbt_1_ZsG3FJnGB54XQeuKojjXr;
	CX::String sbt_4vFtDk2nSivXp;
	CX::IO::SimpleBuffers::UInt32Array sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72;
	CX::IO::SimpleBuffers::UInt16Array sbt_gHQ;
	CX::IO::SimpleBuffers::UInt32Array sbt_1UwL5ptDJG0PKSkZpzbiu3Q;
	CX::IO::SimpleBuffers::StringArray sbt_0BjRicltK;
	CX::Int32 sbt_ht9ew4VUl77wik_;
	CX::IO::SimpleBuffers::BoolArray sbt_D_3wwdTxezNh7hjOJpT;

	virtual void Reset()
	{
		sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs = 0;
		sbt_1_ZsG3FJnGB54XQeuKojjXr = 0;
		sbt_4vFtDk2nSivXp.clear();
		sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.clear();
		sbt_gHQ.clear();
		sbt_1UwL5ptDJG0PKSkZpzbiu3Q.clear();
		sbt_0BjRicltK.clear();
		sbt_ht9ew4VUl77wik_ = 0;
		sbt_D_3wwdTxezNh7hjOJpT.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs = 53218;
		sbt_1_ZsG3FJnGB54XQeuKojjXr = 2801560332;
		sbt_4vFtDk2nSivXp = "EZX%x2j{]bU|z{kV|-.^u&l>YJbPL7'yAXoA]|/I~B5'm(v";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.push_back(2952317719);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_gHQ.push_back(914);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_1UwL5ptDJG0PKSkZpzbiu3Q.push_back(1295479462);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_0BjRicltK.push_back("+;pg\\OKSh~-WU)ZX<+:Y;LQtFmSJ~_aRNNswn7yq");
		}
		sbt_ht9ew4VUl77wik_ = -437916038;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw *pObject = dynamic_cast<const sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs != pObject->sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs)
		{
			return false;
		}
		if (sbt_1_ZsG3FJnGB54XQeuKojjXr != pObject->sbt_1_ZsG3FJnGB54XQeuKojjXr)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_4vFtDk2nSivXp.c_str(), pObject->sbt_4vFtDk2nSivXp.c_str()))
		{
			return false;
		}
		if (sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.size() != pObject->sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.size(); i++)
		{
			if (sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72[i] != pObject->sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72[i])
			{
				return false;
			}
		}
		if (sbt_gHQ.size() != pObject->sbt_gHQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gHQ.size(); i++)
		{
			if (sbt_gHQ[i] != pObject->sbt_gHQ[i])
			{
				return false;
			}
		}
		if (sbt_1UwL5ptDJG0PKSkZpzbiu3Q.size() != pObject->sbt_1UwL5ptDJG0PKSkZpzbiu3Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1UwL5ptDJG0PKSkZpzbiu3Q.size(); i++)
		{
			if (sbt_1UwL5ptDJG0PKSkZpzbiu3Q[i] != pObject->sbt_1UwL5ptDJG0PKSkZpzbiu3Q[i])
			{
				return false;
			}
		}
		if (sbt_0BjRicltK.size() != pObject->sbt_0BjRicltK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0BjRicltK.size(); i++)
		{
			if (0 != cx_strcmp(sbt_0BjRicltK[i].c_str(), pObject->sbt_0BjRicltK[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ht9ew4VUl77wik_ != pObject->sbt_ht9ew4VUl77wik_)
		{
			return false;
		}
		if (sbt_D_3wwdTxezNh7hjOJpT.size() != pObject->sbt_D_3wwdTxezNh7hjOJpT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D_3wwdTxezNh7hjOJpT.size(); i++)
		{
			if (sbt_D_3wwdTxezNh7hjOJpT[i] != pObject->sbt_D_3wwdTxezNh7hjOJpT[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1_ZsG3FJnGB54XQeuKojjXr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1_ZsG3FJnGB54XQeuKojjXr = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_4vFtDk2nSivXp", &sbt_4vFtDk2nSivXp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gHQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gHQ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1UwL5ptDJG0PKSkZpzbiu3Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1UwL5ptDJG0PKSkZpzbiu3Q.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0BjRicltK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0BjRicltK.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ht9ew4VUl77wik_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ht9ew4VUl77wik_ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_D_3wwdTxezNh7hjOJpT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D_3wwdTxezNh7hjOJpT.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs", (CX::Int64)sbt_9A64FrBYbUJi9D88aYjAhmX7Krgf5VvHUBzJYwYIOd0gUcJpVb4hrV0Kydkcs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1_ZsG3FJnGB54XQeuKojjXr", (CX::Int64)sbt_1_ZsG3FJnGB54XQeuKojjXr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_4vFtDk2nSivXp", sbt_4vFtDk2nSivXp.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.begin(); iter != sbt_XK54sTVWzofutPAY7YxlE0q2b2jqFkgNP9WZPT8neSo72.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gHQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_gHQ.begin(); iter != sbt_gHQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1UwL5ptDJG0PKSkZpzbiu3Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1UwL5ptDJG0PKSkZpzbiu3Q.begin(); iter != sbt_1UwL5ptDJG0PKSkZpzbiu3Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0BjRicltK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_0BjRicltK.begin(); iter != sbt_0BjRicltK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ht9ew4VUl77wik_", (CX::Int64)sbt_ht9ew4VUl77wik_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D_3wwdTxezNh7hjOJpT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_D_3wwdTxezNh7hjOJpT.begin(); iter != sbt_D_3wwdTxezNh7hjOJpT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw>::Type sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9TwArray;

