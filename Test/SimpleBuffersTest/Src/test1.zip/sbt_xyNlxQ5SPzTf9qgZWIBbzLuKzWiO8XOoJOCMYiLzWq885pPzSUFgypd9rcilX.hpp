
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H.hpp"


class sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe;
	CX::Int16 sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC;
	CX::IO::SimpleBuffers::Int32Array sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS;
	CX::IO::SimpleBuffers::UInt64Array sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS;
	CX::Double sbt_QoXqis1sSw_;
	CX::Int16 sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL;
	CX::Bool sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch;
	CX::WString sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE;
	CX::Int16 sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA;
	CX::IO::SimpleBuffers::UInt64Array sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH;
	CX::IO::SimpleBuffers::UInt8Array sbt_sewnQWdXfD7TdibtS;
	CX::Double sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2;
	CX::IO::SimpleBuffers::StringArray sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr;
	CX::String sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ;
	CX::IO::SimpleBuffers::Int16Array sbt_bBWRyB7RtTmyGQP9V2QGKvLOp;
	sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_HArray sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470;

	virtual void Reset()
	{
		sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.clear();
		sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC = 0;
		sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.clear();
		sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.clear();
		sbt_QoXqis1sSw_ = 0.0;
		sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL = 0;
		sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch = false;
		sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE.clear();
		sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA = 0;
		sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.clear();
		sbt_sewnQWdXfD7TdibtS.clear();
		sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2 = 0.0;
		sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.clear();
		sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ.clear();
		sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.clear();
		sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.push_back(true);
		}
		sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC = 8236;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.push_back(157122876);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.push_back(12323317820832090400);
		}
		sbt_QoXqis1sSw_ = 0.867587;
		sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL = 27086;
		sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch = false;
		sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE = L"'Gv$$LUVpZ-|0sBh5\\Bi}Km\"T>iN#rXt?E=DRz>.@[B4t`{A\\S_c";
		sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA = -23167;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.push_back(298923662463589782);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_sewnQWdXfD7TdibtS.push_back(12);
		}
		sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2 = 0.679689;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.push_back("a>Pm0iQ+Y.js-.SWI:liud");
		}
		sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ = "a7sn4%\\2\\2OHLL{as[YbcWlITd8~6wC21:IX8t8*GDje3usTd@t/i!CL5%HfXq:";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.push_back(29203);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H v;

			v.SetupWithSomeValues();
			sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX *pObject = dynamic_cast<const sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.size() != pObject->sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.size(); i++)
		{
			if (sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe[i] != pObject->sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe[i])
			{
				return false;
			}
		}
		if (sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC != pObject->sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC)
		{
			return false;
		}
		if (sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.size() != pObject->sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.size(); i++)
		{
			if (sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS[i] != pObject->sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS[i])
			{
				return false;
			}
		}
		if (sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.size() != pObject->sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.size(); i++)
		{
			if (sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS[i] != pObject->sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS[i])
			{
				return false;
			}
		}
		if (sbt_QoXqis1sSw_ != pObject->sbt_QoXqis1sSw_)
		{
			return false;
		}
		if (sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL != pObject->sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL)
		{
			return false;
		}
		if (sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch != pObject->sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE.c_str(), pObject->sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE.c_str()))
		{
			return false;
		}
		if (sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA != pObject->sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA)
		{
			return false;
		}
		if (sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.size() != pObject->sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.size(); i++)
		{
			if (sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH[i] != pObject->sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH[i])
			{
				return false;
			}
		}
		if (sbt_sewnQWdXfD7TdibtS.size() != pObject->sbt_sewnQWdXfD7TdibtS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sewnQWdXfD7TdibtS.size(); i++)
		{
			if (sbt_sewnQWdXfD7TdibtS[i] != pObject->sbt_sewnQWdXfD7TdibtS[i])
			{
				return false;
			}
		}
		if (sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2 != pObject->sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2)
		{
			return false;
		}
		if (sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.size() != pObject->sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.size(); i++)
		{
			if (0 != cx_strcmp(sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr[i].c_str(), pObject->sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ.c_str(), pObject->sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ.c_str()))
		{
			return false;
		}
		if (sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.size() != pObject->sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.size(); i++)
		{
			if (sbt_bBWRyB7RtTmyGQP9V2QGKvLOp[i] != pObject->sbt_bBWRyB7RtTmyGQP9V2QGKvLOp[i])
			{
				return false;
			}
		}
		if (sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.size() != pObject->sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.size(); i++)
		{
			if (!sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470[i].Compare(&pObject->sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_QoXqis1sSw_", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_QoXqis1sSw_ = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch", &sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE", &sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sewnQWdXfD7TdibtS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sewnQWdXfD7TdibtS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ", &sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bBWRyB7RtTmyGQP9V2QGKvLOp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.begin(); iter != sbt_Th9fTPh3hiDW1UYHfY040wFvLEhcGt3do4hby9bsicljKjW1H_FYxMVIe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC", (CX::Int64)sbt_T1kMuUibGTAaAvEnJ1Ydekc4gk4ipdkObL4CgzC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.begin(); iter != sbt_eLk42Wlm4WwD6BGRxOrmlgEFbu2Fg1v6uVn21D8JlNNaO_grPe4a5HOq7uXAS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.begin(); iter != sbt_SrDv4Yqsb9tat_4mXWMu16u9p2Z3FjAfr7UaLJITqX0LKDWrAhS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_QoXqis1sSw_", (CX::Double)sbt_QoXqis1sSw_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL", (CX::Int64)sbt_CD2S83UXl5fXU140GLiQc7AaJ3viUPnln3x3QnVNvgljEFciHnK8GQBKL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch", sbt_KEWBH645s2NZAlXygALF4aNMOZHC0X2xcrd25Lq__IS8Zzjch)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE", sbt_raOpqPyQfTGN3BDobB82qWgjIJuyxuQPhUE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA", (CX::Int64)sbt_VnC9KPRtE__rEY21BmyMF5Ikg7vKtKC_hTCBgmyZJwVCJTbrA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.begin(); iter != sbt_HyVAAKVypKGUy9LwO6ZBO_V1_aH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sewnQWdXfD7TdibtS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_sewnQWdXfD7TdibtS.begin(); iter != sbt_sewnQWdXfD7TdibtS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2", (CX::Double)sbt_9vswPD8MmPMUE7lzi1i9fQBQF8s0xw2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.begin(); iter != sbt_M8lgaOwYcm_jncF5y8r8seLwZRlm9Mr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ", sbt_iV5Wk8gzHijixO4v4VgP_7pWNjCkbpFGNzZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bBWRyB7RtTmyGQP9V2QGKvLOp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.begin(); iter != sbt_bBWRyB7RtTmyGQP9V2QGKvLOp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470")).IsNOK())
		{
			return status;
		}
		for (sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_HArray::const_iterator iter = sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.begin(); iter != sbt_L0dcw2NzWTGcZCADY_hS0itTjeT5N9YHtGRDF2i5t1470.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX>::Type sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilXArray;

