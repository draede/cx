
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_t99ZE67Cx;
	CX::Int16 sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx;
	CX::Int64 sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY;
	CX::IO::SimpleBuffers::UInt64Array sbt_TcQ;

	virtual void Reset()
	{
		sbt_t99ZE67Cx = 0;
		sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx = 0;
		sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY = 0;
		sbt_TcQ.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_t99ZE67Cx = 1795607157;
		sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx = 14386;
		sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY = 8664490399524267648;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox *pObject = dynamic_cast<const sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_t99ZE67Cx != pObject->sbt_t99ZE67Cx)
		{
			return false;
		}
		if (sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx != pObject->sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx)
		{
			return false;
		}
		if (sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY != pObject->sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY)
		{
			return false;
		}
		if (sbt_TcQ.size() != pObject->sbt_TcQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TcQ.size(); i++)
		{
			if (sbt_TcQ[i] != pObject->sbt_TcQ[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_t99ZE67Cx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t99ZE67Cx = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TcQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TcQ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_t99ZE67Cx", (CX::Int64)sbt_t99ZE67Cx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx", (CX::Int64)sbt_WIIuE_O38C0Fh0KAHOStkpAEM3t1MwOaQ5kd4Z0LKLXghlxkeTwwFYmhvIuYljx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY", (CX::Int64)sbt_ZH9falZpesU49xxh18hrz6l6NwNNCRY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TcQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_TcQ.begin(); iter != sbt_TcQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox>::Type sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuoxArray;

