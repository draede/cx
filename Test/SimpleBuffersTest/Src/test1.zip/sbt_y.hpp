
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_y : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY;
	CX::IO::SimpleBuffers::Int8Array sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20;

	virtual void Reset()
	{
		sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.clear();
		sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.push_back(176);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.push_back(59);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_y *pObject = dynamic_cast<const sbt_y *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.size() != pObject->sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.size(); i++)
		{
			if (sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY[i] != pObject->sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY[i])
			{
				return false;
			}
		}
		if (sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.size() != pObject->sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.size(); i++)
		{
			if (sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20[i] != pObject->sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.begin(); iter != sbt_cr1FNlt7zYCdPbsat8lCQdQlTpwi8UxEsPw46VNBY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.begin(); iter != sbt_TqqhfIIJq9emuBQTm3ZQLeqd3t3uTb62FHeoDFVfToZR6Yk7ELNz_20.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_y>::Type sbt_yArray;

