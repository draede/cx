
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_tCa9Hj0t6hLbmvzztOVk5bPU2 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7;
	CX::UInt32 sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy;
	CX::IO::SimpleBuffers::StringArray sbt_NlUrI3laxul0uNVLg;
	CX::String sbt_IW1Iu_5Br4N;
	CX::IO::SimpleBuffers::UInt32Array sbt_4;
	CX::IO::SimpleBuffers::Int8Array sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp;
	CX::UInt64 sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg;
	CX::Bool sbt_GV8ThMO;
	CX::IO::SimpleBuffers::Int8Array sbt_MGnC7d9tpxLIaJX7febAr;

	virtual void Reset()
	{
		sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.clear();
		sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy = 0;
		sbt_NlUrI3laxul0uNVLg.clear();
		sbt_IW1Iu_5Br4N.clear();
		sbt_4.clear();
		sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.clear();
		sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg = 0;
		sbt_GV8ThMO = false;
		sbt_MGnC7d9tpxLIaJX7febAr.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.push_back(6433);
		}
		sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy = 3895400509;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_NlUrI3laxul0uNVLg.push_back("DV2K;Dv:yG\\ex``MfNrym:}");
		}
		sbt_IW1Iu_5Br4N = "A;QN),Q4U|%8*u=PwTr<2HD~E:'8-&X9GH]dR07Qtg8gZ<=\"hJ!";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_4.push_back(3162095317);
		}
		sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg = 6393425651167822840;
		sbt_GV8ThMO = true;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_MGnC7d9tpxLIaJX7febAr.push_back(16);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_tCa9Hj0t6hLbmvzztOVk5bPU2 *pObject = dynamic_cast<const sbt_tCa9Hj0t6hLbmvzztOVk5bPU2 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.size() != pObject->sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.size(); i++)
		{
			if (sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7[i] != pObject->sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7[i])
			{
				return false;
			}
		}
		if (sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy != pObject->sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy)
		{
			return false;
		}
		if (sbt_NlUrI3laxul0uNVLg.size() != pObject->sbt_NlUrI3laxul0uNVLg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NlUrI3laxul0uNVLg.size(); i++)
		{
			if (0 != cx_strcmp(sbt_NlUrI3laxul0uNVLg[i].c_str(), pObject->sbt_NlUrI3laxul0uNVLg[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_IW1Iu_5Br4N.c_str(), pObject->sbt_IW1Iu_5Br4N.c_str()))
		{
			return false;
		}
		if (sbt_4.size() != pObject->sbt_4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4.size(); i++)
		{
			if (sbt_4[i] != pObject->sbt_4[i])
			{
				return false;
			}
		}
		if (sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.size() != pObject->sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.size(); i++)
		{
			if (sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp[i] != pObject->sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp[i])
			{
				return false;
			}
		}
		if (sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg != pObject->sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg)
		{
			return false;
		}
		if (sbt_GV8ThMO != pObject->sbt_GV8ThMO)
		{
			return false;
		}
		if (sbt_MGnC7d9tpxLIaJX7febAr.size() != pObject->sbt_MGnC7d9tpxLIaJX7febAr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MGnC7d9tpxLIaJX7febAr.size(); i++)
		{
			if (sbt_MGnC7d9tpxLIaJX7febAr[i] != pObject->sbt_MGnC7d9tpxLIaJX7febAr[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NlUrI3laxul0uNVLg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NlUrI3laxul0uNVLg.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_IW1Iu_5Br4N", &sbt_IW1Iu_5Br4N)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_GV8ThMO", &sbt_GV8ThMO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MGnC7d9tpxLIaJX7febAr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MGnC7d9tpxLIaJX7febAr.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.begin(); iter != sbt_9OruBOlwheLPEzLvph1Em0KM_NSjLvhb7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy", (CX::Int64)sbt_ez8p6vTCTsqxuM65QFjYjz_uUJcId84qw6NxeOmf4vy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NlUrI3laxul0uNVLg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_NlUrI3laxul0uNVLg.begin(); iter != sbt_NlUrI3laxul0uNVLg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_IW1Iu_5Br4N", sbt_IW1Iu_5Br4N.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_4.begin(); iter != sbt_4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.begin(); iter != sbt_n3ivF7y6Yp3uLmJQMsi7DzyzpDpN1iHU4Syg48M9gMq4W27YyIshOS25Nd4Kp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg", (CX::Int64)sbt_yNyww0SkidbmChevB3ymei8pUyEB0Lzl7CF2EKg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GV8ThMO", sbt_GV8ThMO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MGnC7d9tpxLIaJX7febAr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_MGnC7d9tpxLIaJX7febAr.begin(); iter != sbt_MGnC7d9tpxLIaJX7febAr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_tCa9Hj0t6hLbmvzztOVk5bPU2>::Type sbt_tCa9Hj0t6hLbmvzztOVk5bPU2Array;

