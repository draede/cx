
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW.hpp"


class sbt_kA8FyEwnZJJ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN;
	CX::UInt16 sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J;
	CX::IO::SimpleBuffers::UInt64Array sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_;
	CX::UInt8 sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R;
	CX::IO::SimpleBuffers::DoubleArray sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3;
	CX::IO::SimpleBuffers::WStringArray sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH;
	sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4;

	virtual void Reset()
	{
		sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN = 0.0f;
		sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J = 0;
		sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.clear();
		sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R = 0;
		sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.clear();
		sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.clear();
		sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN = 0.406934f;
		sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J = 12096;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.push_back(1092249696714942372);
		}
		sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R = 205;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.push_back(0.019789);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.push_back(L"B:8V@wWKB@x\"U,Z'yw|-@\"}2S?1+i&GX/bmr6kp3ipu&5E3otQ");
		}
		sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_kA8FyEwnZJJ *pObject = dynamic_cast<const sbt_kA8FyEwnZJJ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN != pObject->sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN)
		{
			return false;
		}
		if (sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J != pObject->sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J)
		{
			return false;
		}
		if (sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.size() != pObject->sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.size(); i++)
		{
			if (sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_[i] != pObject->sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_[i])
			{
				return false;
			}
		}
		if (sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R != pObject->sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R)
		{
			return false;
		}
		if (sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.size() != pObject->sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.size(); i++)
		{
			if (sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3[i] != pObject->sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3[i])
			{
				return false;
			}
		}
		if (sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.size() != pObject->sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH[i].c_str(), pObject->sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH[i].c_str()))
			{
				return false;
			}
		}
		if (!sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4.Compare(&pObject->sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN", (CX::Double)sbt_owmo06I9CGk55qAzm9L3Iye1G45VCQIwHdil0frFN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J", (CX::Int64)sbt_EZrbuYwwmqvI6GEn9qZlo9LGvz45cYdAV_J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.begin(); iter != sbt_wJCd0OlDkRfo8NG3e59Kkx8NxsAAzw5SkoS8aU0deszX6b075gQlXL_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R", (CX::Int64)sbt_wtDoSOvOUJ5Yrw70eK1hK1e_R)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.begin(); iter != sbt_igZytdLB1Btxmjv7cZRJfEVynEcIOcZq3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.begin(); iter != sbt_YK5hWF2dFr9vf1XRxY2CrCStjbjDC0ExisG105hIOsPtMENSH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_HgkSt0bTDQKJOY6VOjtbc8SImWmPJvPYvFnyzULSU5Exigaoek4.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_kA8FyEwnZJJ>::Type sbt_kA8FyEwnZJJArray;

