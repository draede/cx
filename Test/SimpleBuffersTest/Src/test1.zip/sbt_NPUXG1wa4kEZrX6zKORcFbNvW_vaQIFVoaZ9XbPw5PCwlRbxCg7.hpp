
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_0Mk8Rck1rfINzZy.hpp"


class sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK;
	CX::IO::SimpleBuffers::Int8Array sbt_JLbRrWsuifwnwiEyWTl8OzToo;
	CX::Bool sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY;
	CX::Int8 sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr;
	CX::IO::SimpleBuffers::UInt32Array sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7;
	CX::IO::SimpleBuffers::StringArray sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA;
	CX::IO::SimpleBuffers::UInt8Array sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1;
	CX::Float sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT;
	CX::String sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB;
	CX::IO::SimpleBuffers::UInt8Array sbt_14lWcycRZzv8OFAnW;
	CX::UInt32 sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel;
	CX::Int8 sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ;
	CX::IO::SimpleBuffers::BoolArray sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe;
	CX::IO::SimpleBuffers::WStringArray sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb;
	CX::UInt16 sbt_v84HCv42JvEqN3f;
	CX::IO::SimpleBuffers::UInt16Array sbt_5t0kmZgM_ic9v03gl66e58T9_;
	CX::UInt16 sbt_Bds;
	CX::IO::SimpleBuffers::Int16Array sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW;
	CX::IO::SimpleBuffers::UInt32Array sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6;
	CX::IO::SimpleBuffers::FloatArray sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk;
	CX::WString sbt_Wpa0R9OH0;
	CX::IO::SimpleBuffers::DoubleArray sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9;
	sbt_0Mk8Rck1rfINzZyArray sbt_j;

	virtual void Reset()
	{
		sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.clear();
		sbt_JLbRrWsuifwnwiEyWTl8OzToo.clear();
		sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY = false;
		sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr = 0;
		sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.clear();
		sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.clear();
		sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.clear();
		sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT = 0.0f;
		sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB.clear();
		sbt_14lWcycRZzv8OFAnW.clear();
		sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel = 0;
		sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ = 0;
		sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.clear();
		sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.clear();
		sbt_v84HCv42JvEqN3f = 0;
		sbt_5t0kmZgM_ic9v03gl66e58T9_.clear();
		sbt_Bds = 0;
		sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.clear();
		sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.clear();
		sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.clear();
		sbt_Wpa0R9OH0.clear();
		sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.clear();
		sbt_j.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.push_back(3693039133383658468);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_JLbRrWsuifwnwiEyWTl8OzToo.push_back(-31);
		}
		sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY = true;
		sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr = -33;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.push_back(1676903877);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.push_back("DG6xKkdURy([pCJ*7=g~,?!TAK5$X3g~Y(aU}ziguX+>yeqBfDy\\GYdVj;4p)1");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.push_back(203);
		}
		sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT = 0.111070f;
		sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB = "!mu_k2/EqM{+";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_14lWcycRZzv8OFAnW.push_back(221);
		}
		sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel = 1136610068;
		sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ = 46;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.push_back(false);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.push_back(L"x}N\\N9{?np&N");
		}
		sbt_v84HCv42JvEqN3f = 36189;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_5t0kmZgM_ic9v03gl66e58T9_.push_back(13559);
		}
		sbt_Bds = 41190;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.push_back(-31757);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.push_back(653517065);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.push_back(0.785344f);
		}
		sbt_Wpa0R9OH0 = L"lx!\"Uhu~Ew^5Aa}PK";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.push_back(0.896375);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_0Mk8Rck1rfINzZy v;

			v.SetupWithSomeValues();
			sbt_j.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7 *pObject = dynamic_cast<const sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.size() != pObject->sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.size(); i++)
		{
			if (sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK[i] != pObject->sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK[i])
			{
				return false;
			}
		}
		if (sbt_JLbRrWsuifwnwiEyWTl8OzToo.size() != pObject->sbt_JLbRrWsuifwnwiEyWTl8OzToo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JLbRrWsuifwnwiEyWTl8OzToo.size(); i++)
		{
			if (sbt_JLbRrWsuifwnwiEyWTl8OzToo[i] != pObject->sbt_JLbRrWsuifwnwiEyWTl8OzToo[i])
			{
				return false;
			}
		}
		if (sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY != pObject->sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY)
		{
			return false;
		}
		if (sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr != pObject->sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr)
		{
			return false;
		}
		if (sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.size() != pObject->sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.size(); i++)
		{
			if (sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7[i] != pObject->sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7[i])
			{
				return false;
			}
		}
		if (sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.size() != pObject->sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.size(); i++)
		{
			if (0 != cx_strcmp(sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA[i].c_str(), pObject->sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.size() != pObject->sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.size(); i++)
		{
			if (sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1[i] != pObject->sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1[i])
			{
				return false;
			}
		}
		if (sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT != pObject->sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB.c_str(), pObject->sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB.c_str()))
		{
			return false;
		}
		if (sbt_14lWcycRZzv8OFAnW.size() != pObject->sbt_14lWcycRZzv8OFAnW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_14lWcycRZzv8OFAnW.size(); i++)
		{
			if (sbt_14lWcycRZzv8OFAnW[i] != pObject->sbt_14lWcycRZzv8OFAnW[i])
			{
				return false;
			}
		}
		if (sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel != pObject->sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel)
		{
			return false;
		}
		if (sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ != pObject->sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ)
		{
			return false;
		}
		if (sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.size() != pObject->sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.size(); i++)
		{
			if (sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe[i] != pObject->sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe[i])
			{
				return false;
			}
		}
		if (sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.size() != pObject->sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb[i].c_str(), pObject->sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_v84HCv42JvEqN3f != pObject->sbt_v84HCv42JvEqN3f)
		{
			return false;
		}
		if (sbt_5t0kmZgM_ic9v03gl66e58T9_.size() != pObject->sbt_5t0kmZgM_ic9v03gl66e58T9_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5t0kmZgM_ic9v03gl66e58T9_.size(); i++)
		{
			if (sbt_5t0kmZgM_ic9v03gl66e58T9_[i] != pObject->sbt_5t0kmZgM_ic9v03gl66e58T9_[i])
			{
				return false;
			}
		}
		if (sbt_Bds != pObject->sbt_Bds)
		{
			return false;
		}
		if (sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.size() != pObject->sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.size(); i++)
		{
			if (sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW[i] != pObject->sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW[i])
			{
				return false;
			}
		}
		if (sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.size() != pObject->sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.size(); i++)
		{
			if (sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6[i] != pObject->sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6[i])
			{
				return false;
			}
		}
		if (sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.size() != pObject->sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.size(); i++)
		{
			if (sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk[i] != pObject->sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_Wpa0R9OH0.c_str(), pObject->sbt_Wpa0R9OH0.c_str()))
		{
			return false;
		}
		if (sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.size() != pObject->sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.size(); i++)
		{
			if (sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9[i] != pObject->sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9[i])
			{
				return false;
			}
		}
		if (sbt_j.size() != pObject->sbt_j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j.size(); i++)
		{
			if (!sbt_j[i].Compare(&pObject->sbt_j[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JLbRrWsuifwnwiEyWTl8OzToo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JLbRrWsuifwnwiEyWTl8OzToo.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY", &sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectString("sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB", &sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_14lWcycRZzv8OFAnW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_14lWcycRZzv8OFAnW.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_v84HCv42JvEqN3f", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v84HCv42JvEqN3f = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5t0kmZgM_ic9v03gl66e58T9_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5t0kmZgM_ic9v03gl66e58T9_.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Bds", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Bds = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_Wpa0R9OH0", &sbt_Wpa0R9OH0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_0Mk8Rck1rfINzZy tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_j.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.begin(); iter != sbt_v0fgtgax9luOAc2HIbyTQBCdFsYC5q9rlyl_LTNcz7_EBRK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JLbRrWsuifwnwiEyWTl8OzToo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_JLbRrWsuifwnwiEyWTl8OzToo.begin(); iter != sbt_JLbRrWsuifwnwiEyWTl8OzToo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY", sbt_Mrl1KPGqmWuVN18EtxkChxx5EyEgcla8HZoKwt3WEFGRIFBkAkh0LcnBrpss8TY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr", (CX::Int64)sbt_NlFjTeURps7vwnMfB5NT4rFq_dRWH9iOETrbBRr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.begin(); iter != sbt_paOgN_xpHcLIULBf8Hs4o92Z9m7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.begin(); iter != sbt_OFCRGYWMxGMOrzRAmg9c3hx0yOpSoddKIWFD7EgMhTLrKUA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.begin(); iter != sbt_5jbMBlYUqKYjtDzRXLztJl_3n3icbXNiVj7sljrX1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT", (CX::Double)sbt_K2X5r228nQUuc3q91pEF1hfRbuVsufrmXt9UL9j928clx8e93HT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB", sbt_KBgYfXLm7aI27BsfIQElgyPrbdmxthJNI5FfeX0a0c0cdOsjaaB.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_14lWcycRZzv8OFAnW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_14lWcycRZzv8OFAnW.begin(); iter != sbt_14lWcycRZzv8OFAnW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel", (CX::Int64)sbt_6OBn02osHvgKHNv9lYjIDfku9xrM8A9BKnGwgEHKzAb5f2TD43fgcYgsTel)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ", (CX::Int64)sbt_vfY47cTJ7TRdZ010S5bejYNWeVXlL0pMjsUVD6yES2SzNpZIQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.begin(); iter != sbt_BUhwBr92uopyJfn2uAMzAFRu0vHjrecHtVdrRpVxe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.begin(); iter != sbt_Moy4FAU5FonGkN0zo4eecwQP58NFBCrJancWqfIax2R6hn3caZ4XeLyo1H8AHXb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v84HCv42JvEqN3f", (CX::Int64)sbt_v84HCv42JvEqN3f)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5t0kmZgM_ic9v03gl66e58T9_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_5t0kmZgM_ic9v03gl66e58T9_.begin(); iter != sbt_5t0kmZgM_ic9v03gl66e58T9_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Bds", (CX::Int64)sbt_Bds)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.begin(); iter != sbt_QmZ0HFFKgxoroK8aOIkEx0rHEyW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.begin(); iter != sbt_8oA63k6IrcSqPidybITCaY3VMvns5l0vIbJu6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.begin(); iter != sbt_daexz1al6DUneZswTRNk7eLuj7G_NP48amTw6xoOjk_C7qnpk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_Wpa0R9OH0", sbt_Wpa0R9OH0.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.begin(); iter != sbt_Pt4Nds2nyoykE8sbHeQd14HpRHTYTNpqQCdo9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (sbt_0Mk8Rck1rfINzZyArray::const_iterator iter = sbt_j.begin(); iter != sbt_j.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7>::Type sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7Array;

