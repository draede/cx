
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR;
	CX::Int8 sbt_SNHDnayIX;
	CX::Int8 sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF;
	CX::IO::SimpleBuffers::UInt64Array sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd;
	CX::UInt64 sbt_0xT8lqM;
	CX::IO::SimpleBuffers::UInt32Array sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM;
	CX::IO::SimpleBuffers::Int32Array sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB;
	CX::IO::SimpleBuffers::UInt32Array sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr;
	CX::IO::SimpleBuffers::UInt64Array sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB;
	CX::Bool sbt_4bhI6XTblcWAN;

	virtual void Reset()
	{
		sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.clear();
		sbt_SNHDnayIX = 0;
		sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF = 0;
		sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.clear();
		sbt_0xT8lqM = 0;
		sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.clear();
		sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.clear();
		sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.clear();
		sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.clear();
		sbt_4bhI6XTblcWAN = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.push_back("6Th(0sT6:\"_9f1B!M^Y%_n#5^PUA<OV");
		}
		sbt_SNHDnayIX = -83;
		sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF = -83;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.push_back(7367987134997889880);
		}
		sbt_0xT8lqM = 6676858532574818412;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.push_back(58497111);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.push_back(-1156282878);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.push_back(4188385374);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.push_back(9236030003212409120);
		}
		sbt_4bhI6XTblcWAN = false;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM *pObject = dynamic_cast<const sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.size() != pObject->sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.size(); i++)
		{
			if (0 != cx_strcmp(sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR[i].c_str(), pObject->sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_SNHDnayIX != pObject->sbt_SNHDnayIX)
		{
			return false;
		}
		if (sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF != pObject->sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF)
		{
			return false;
		}
		if (sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.size() != pObject->sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.size(); i++)
		{
			if (sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd[i] != pObject->sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd[i])
			{
				return false;
			}
		}
		if (sbt_0xT8lqM != pObject->sbt_0xT8lqM)
		{
			return false;
		}
		if (sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.size() != pObject->sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.size(); i++)
		{
			if (sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM[i] != pObject->sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM[i])
			{
				return false;
			}
		}
		if (sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.size() != pObject->sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.size(); i++)
		{
			if (sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB[i] != pObject->sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB[i])
			{
				return false;
			}
		}
		if (sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.size() != pObject->sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.size(); i++)
		{
			if (sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr[i] != pObject->sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr[i])
			{
				return false;
			}
		}
		if (sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.size() != pObject->sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.size(); i++)
		{
			if (sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB[i] != pObject->sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB[i])
			{
				return false;
			}
		}
		if (sbt_4bhI6XTblcWAN != pObject->sbt_4bhI6XTblcWAN)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SNHDnayIX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SNHDnayIX = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0xT8lqM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0xT8lqM = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_4bhI6XTblcWAN", &sbt_4bhI6XTblcWAN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.begin(); iter != sbt_8WdyxWHBQPwvsIwoaSaxaZytAX_xZ2vBiyr0kKINJtgR94IcvQhvR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SNHDnayIX", (CX::Int64)sbt_SNHDnayIX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF", (CX::Int64)sbt_HOFcm66tBPO2dJ1LNZGXAJ3k21x75JfYF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.begin(); iter != sbt_wA9m2_D33T5LDQf8Hc44S1MUMI4Ar4UxssBS0jUDVThp7zl0HxRSd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0xT8lqM", (CX::Int64)sbt_0xT8lqM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.begin(); iter != sbt_Zu0kiUHNQPsxWR0VagDzPLCLM8i4EjVO2n1gM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.begin(); iter != sbt_6AHqN78pNvhRw9RkkU_x2hR4Q5jPa5NpUsCbVyLaEF3KB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.begin(); iter != sbt_bE3yHx6j1l8pDjeq52ZCnucT9PRDrXldJBNDGhuslcZUr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.begin(); iter != sbt__1dVykXSXqhEib0KSVavBItxvuwISUbY7hTnPyLj4jctB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_4bhI6XTblcWAN", sbt_4bhI6XTblcWAN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM>::Type sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIMArray;

