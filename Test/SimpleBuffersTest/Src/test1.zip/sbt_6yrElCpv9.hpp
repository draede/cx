
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_FBJGedd.hpp"


class sbt_6yrElCpv9 : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_FBJGedd sbt_TMgGOiui9Uf2_BZODvXD3;

	virtual void Reset()
	{
		sbt_TMgGOiui9Uf2_BZODvXD3.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TMgGOiui9Uf2_BZODvXD3.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6yrElCpv9 *pObject = dynamic_cast<const sbt_6yrElCpv9 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (!sbt_TMgGOiui9Uf2_BZODvXD3.Compare(&pObject->sbt_TMgGOiui9Uf2_BZODvXD3))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectObject("sbt_TMgGOiui9Uf2_BZODvXD3")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TMgGOiui9Uf2_BZODvXD3.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectObject("sbt_TMgGOiui9Uf2_BZODvXD3")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TMgGOiui9Uf2_BZODvXD3.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6yrElCpv9>::Type sbt_6yrElCpv9Array;

