
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_4uITTZHRL : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk;
	CX::IO::SimpleBuffers::StringArray sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj;
	CX::UInt32 sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH;
	CX::String sbt_2QE;
	CX::IO::SimpleBuffers::UInt64Array sbt_AgINnT7un2eRwLsEmyx;
	CX::IO::SimpleBuffers::BoolArray sbt_KTO;
	CX::UInt8 sbt_1ed;
	CX::IO::SimpleBuffers::BoolArray sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL;
	CX::IO::SimpleBuffers::UInt64Array sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7;
	CX::IO::SimpleBuffers::UInt8Array sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C;
	CX::UInt64 sbt_BkhipNymZFSmcoz;
	CX::IO::SimpleBuffers::StringArray sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U;
	CX::Int64 sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt;
	CX::Bool sbt_muypVqejrUgpnAooco7lRND47dI;
	CX::UInt8 sbt_YDcwHEkOex9AAhpKU;
	CX::IO::SimpleBuffers::UInt8Array sbt_f67pgBg;
	CX::IO::SimpleBuffers::Int16Array sbt_hkRKkUTWb4Af14T;
	CX::UInt64 sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ;
	CX::IO::SimpleBuffers::Int64Array sbt_rL2Y6CZm9ndtGPtQWqrpLhv;
	CX::IO::SimpleBuffers::UInt32Array sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS;
	CX::UInt32 sbt_qYlKiE4;
	CX::IO::SimpleBuffers::Int8Array sbt_vNR1c_sYUFzg77E;
	CX::UInt16 sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC;
	CX::String sbt_hMVlqijMO5oxs4drJWn;
	CX::Int64 sbt_OFzIq;
	CX::Bool sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1;
	CX::IO::SimpleBuffers::Int64Array sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS;

	virtual void Reset()
	{
		sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.clear();
		sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.clear();
		sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH = 0;
		sbt_2QE.clear();
		sbt_AgINnT7un2eRwLsEmyx.clear();
		sbt_KTO.clear();
		sbt_1ed = 0;
		sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.clear();
		sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.clear();
		sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.clear();
		sbt_BkhipNymZFSmcoz = 0;
		sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.clear();
		sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt = 0;
		sbt_muypVqejrUgpnAooco7lRND47dI = false;
		sbt_YDcwHEkOex9AAhpKU = 0;
		sbt_f67pgBg.clear();
		sbt_hkRKkUTWb4Af14T.clear();
		sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ = 0;
		sbt_rL2Y6CZm9ndtGPtQWqrpLhv.clear();
		sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.clear();
		sbt_qYlKiE4 = 0;
		sbt_vNR1c_sYUFzg77E.clear();
		sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC = 0;
		sbt_hMVlqijMO5oxs4drJWn.clear();
		sbt_OFzIq = 0;
		sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1 = false;
		sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.push_back(2000028298);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.push_back("U([L1rk:)R_5WMV$PV+M#5vNhATWVan]zGs9BHot-#|5xLQkT`.xni!");
		}
		sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH = 1287989517;
		sbt_2QE = "y&==Sp?SuCdp=%I{";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_AgINnT7un2eRwLsEmyx.push_back(52336062556394658);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_KTO.push_back(false);
		}
		sbt_1ed = 165;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.push_back(false);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.push_back(12431600577413603266);
		}
		sbt_BkhipNymZFSmcoz = 7656638417128485684;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.push_back("vWdWk:dLKfu|$u#hirI^j\"zxc6$GU+L.h~b|$U.%[!oJf[A#RRP");
		}
		sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt = 8658058033657812556;
		sbt_muypVqejrUgpnAooco7lRND47dI = false;
		sbt_YDcwHEkOex9AAhpKU = 150;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_f67pgBg.push_back(60);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_hkRKkUTWb4Af14T.push_back(13206);
		}
		sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ = 7252799445010424052;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_rL2Y6CZm9ndtGPtQWqrpLhv.push_back(-4949396019884662204);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.push_back(565370155);
		}
		sbt_qYlKiE4 = 1878006909;
		sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC = 2192;
		sbt_hMVlqijMO5oxs4drJWn = "=(dXXz+8UzYrHsii+a";
		sbt_OFzIq = -4962177472323702858;
		sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1 = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.push_back(-2237324569132078716);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4uITTZHRL *pObject = dynamic_cast<const sbt_4uITTZHRL *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.size() != pObject->sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.size(); i++)
		{
			if (sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk[i] != pObject->sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk[i])
			{
				return false;
			}
		}
		if (sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.size() != pObject->sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.size(); i++)
		{
			if (0 != cx_strcmp(sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj[i].c_str(), pObject->sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH != pObject->sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_2QE.c_str(), pObject->sbt_2QE.c_str()))
		{
			return false;
		}
		if (sbt_AgINnT7un2eRwLsEmyx.size() != pObject->sbt_AgINnT7un2eRwLsEmyx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AgINnT7un2eRwLsEmyx.size(); i++)
		{
			if (sbt_AgINnT7un2eRwLsEmyx[i] != pObject->sbt_AgINnT7un2eRwLsEmyx[i])
			{
				return false;
			}
		}
		if (sbt_KTO.size() != pObject->sbt_KTO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KTO.size(); i++)
		{
			if (sbt_KTO[i] != pObject->sbt_KTO[i])
			{
				return false;
			}
		}
		if (sbt_1ed != pObject->sbt_1ed)
		{
			return false;
		}
		if (sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.size() != pObject->sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.size(); i++)
		{
			if (sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL[i] != pObject->sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL[i])
			{
				return false;
			}
		}
		if (sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.size() != pObject->sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.size(); i++)
		{
			if (sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7[i] != pObject->sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7[i])
			{
				return false;
			}
		}
		if (sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.size() != pObject->sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.size(); i++)
		{
			if (sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C[i] != pObject->sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C[i])
			{
				return false;
			}
		}
		if (sbt_BkhipNymZFSmcoz != pObject->sbt_BkhipNymZFSmcoz)
		{
			return false;
		}
		if (sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.size() != pObject->sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.size(); i++)
		{
			if (0 != cx_strcmp(sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U[i].c_str(), pObject->sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt != pObject->sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt)
		{
			return false;
		}
		if (sbt_muypVqejrUgpnAooco7lRND47dI != pObject->sbt_muypVqejrUgpnAooco7lRND47dI)
		{
			return false;
		}
		if (sbt_YDcwHEkOex9AAhpKU != pObject->sbt_YDcwHEkOex9AAhpKU)
		{
			return false;
		}
		if (sbt_f67pgBg.size() != pObject->sbt_f67pgBg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f67pgBg.size(); i++)
		{
			if (sbt_f67pgBg[i] != pObject->sbt_f67pgBg[i])
			{
				return false;
			}
		}
		if (sbt_hkRKkUTWb4Af14T.size() != pObject->sbt_hkRKkUTWb4Af14T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hkRKkUTWb4Af14T.size(); i++)
		{
			if (sbt_hkRKkUTWb4Af14T[i] != pObject->sbt_hkRKkUTWb4Af14T[i])
			{
				return false;
			}
		}
		if (sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ != pObject->sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ)
		{
			return false;
		}
		if (sbt_rL2Y6CZm9ndtGPtQWqrpLhv.size() != pObject->sbt_rL2Y6CZm9ndtGPtQWqrpLhv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rL2Y6CZm9ndtGPtQWqrpLhv.size(); i++)
		{
			if (sbt_rL2Y6CZm9ndtGPtQWqrpLhv[i] != pObject->sbt_rL2Y6CZm9ndtGPtQWqrpLhv[i])
			{
				return false;
			}
		}
		if (sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.size() != pObject->sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.size(); i++)
		{
			if (sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS[i] != pObject->sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS[i])
			{
				return false;
			}
		}
		if (sbt_qYlKiE4 != pObject->sbt_qYlKiE4)
		{
			return false;
		}
		if (sbt_vNR1c_sYUFzg77E.size() != pObject->sbt_vNR1c_sYUFzg77E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vNR1c_sYUFzg77E.size(); i++)
		{
			if (sbt_vNR1c_sYUFzg77E[i] != pObject->sbt_vNR1c_sYUFzg77E[i])
			{
				return false;
			}
		}
		if (sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC != pObject->sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_hMVlqijMO5oxs4drJWn.c_str(), pObject->sbt_hMVlqijMO5oxs4drJWn.c_str()))
		{
			return false;
		}
		if (sbt_OFzIq != pObject->sbt_OFzIq)
		{
			return false;
		}
		if (sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1 != pObject->sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1)
		{
			return false;
		}
		if (sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.size() != pObject->sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.size(); i++)
		{
			if (sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS[i] != pObject->sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_2QE", &sbt_2QE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AgINnT7un2eRwLsEmyx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AgINnT7un2eRwLsEmyx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KTO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KTO.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1ed", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1ed = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BkhipNymZFSmcoz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BkhipNymZFSmcoz = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_muypVqejrUgpnAooco7lRND47dI", &sbt_muypVqejrUgpnAooco7lRND47dI)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YDcwHEkOex9AAhpKU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YDcwHEkOex9AAhpKU = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_f67pgBg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f67pgBg.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hkRKkUTWb4Af14T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hkRKkUTWb4Af14T.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rL2Y6CZm9ndtGPtQWqrpLhv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rL2Y6CZm9ndtGPtQWqrpLhv.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qYlKiE4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qYlKiE4 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vNR1c_sYUFzg77E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vNR1c_sYUFzg77E.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_hMVlqijMO5oxs4drJWn", &sbt_hMVlqijMO5oxs4drJWn)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OFzIq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OFzIq = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1", &sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.begin(); iter != sbt_nkh8mNKeEwQBXjN_rQbg0b1kBJujk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.begin(); iter != sbt_eSQH4HOpL3w52j4nur_hC4EFNh8DvgRphZc6jbkKRAWtiGOhiuuskSgLHqRaj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH", (CX::Int64)sbt_mzJ29Yf7e_QTRFbtgh6EoSJNBc4htY1QvtwY5MF0FK1NBt_ttLmy0aXmOxkXRHH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_2QE", sbt_2QE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AgINnT7un2eRwLsEmyx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_AgINnT7un2eRwLsEmyx.begin(); iter != sbt_AgINnT7un2eRwLsEmyx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KTO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_KTO.begin(); iter != sbt_KTO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1ed", (CX::Int64)sbt_1ed)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.begin(); iter != sbt_MVW83W3NkjTmPoIU3mFBtWYY7N9xQVEXL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.begin(); iter != sbt_jVRDkGNs1VV9Vn0xSA8dEeFAPsKucShgEZ_1bjHOYMg2vFOAxYTDQLkQ1oNTuy7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.begin(); iter != sbt_vnte_AGLtB2nBt8SNcm9ah4kXb6uV4MNW2Wsb3WfCrYt5hOUfQKmLRBtwDNOM5C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BkhipNymZFSmcoz", (CX::Int64)sbt_BkhipNymZFSmcoz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.begin(); iter != sbt_cEUqGRZKJHj03U1Nlno0dhExjC7a1DQrPB9J2LQf6GKprdYktq24W0U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt", (CX::Int64)sbt_f1_sVz_HN0Mj7UUXXoutB71CH2z4TIBMt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_muypVqejrUgpnAooco7lRND47dI", sbt_muypVqejrUgpnAooco7lRND47dI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YDcwHEkOex9AAhpKU", (CX::Int64)sbt_YDcwHEkOex9AAhpKU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f67pgBg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_f67pgBg.begin(); iter != sbt_f67pgBg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hkRKkUTWb4Af14T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_hkRKkUTWb4Af14T.begin(); iter != sbt_hkRKkUTWb4Af14T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ", (CX::Int64)sbt_cJaQlspOV8wRWXSBFOJrvQU_IolKPmQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rL2Y6CZm9ndtGPtQWqrpLhv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_rL2Y6CZm9ndtGPtQWqrpLhv.begin(); iter != sbt_rL2Y6CZm9ndtGPtQWqrpLhv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.begin(); iter != sbt_luz5_PZFl4fyiqInl_qUBkQMK6iys8iJ2KnkcpS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qYlKiE4", (CX::Int64)sbt_qYlKiE4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vNR1c_sYUFzg77E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_vNR1c_sYUFzg77E.begin(); iter != sbt_vNR1c_sYUFzg77E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC", (CX::Int64)sbt_tBx8leupBMM3RN54dlP0AZTls7NXGDytcZ6vqk9eA9PzoGeqnQzkfNC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_hMVlqijMO5oxs4drJWn", sbt_hMVlqijMO5oxs4drJWn.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OFzIq", (CX::Int64)sbt_OFzIq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1", sbt_2VOyWUQAKg1qaFg3IMo3JJ8bTf0r09f8QhQOw0rmlMJI1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.begin(); iter != sbt_a77fWYo_F9J86_XAuqxyV5HdsjcDSr6hC7Dog03UFOvpgIS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4uITTZHRL>::Type sbt_4uITTZHRLArray;

