
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID;
	CX::String sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk;
	CX::IO::SimpleBuffers::UInt32Array sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH;
	CX::UInt64 sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8;
	CX::Int8 sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC;
	CX::IO::SimpleBuffers::Int8Array sbt_9cjo1q030P2ZgrQcG;
	CX::UInt16 sbt_yjaLBa9zMeU4MI4SOLiQhpx;
	CX::UInt16 sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La;
	CX::IO::SimpleBuffers::Int8Array sbt_pfxljpoUPeASopnPMp5;

	virtual void Reset()
	{
		sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID = 0;
		sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk.clear();
		sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.clear();
		sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8 = 0;
		sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC = 0;
		sbt_9cjo1q030P2ZgrQcG.clear();
		sbt_yjaLBa9zMeU4MI4SOLiQhpx = 0;
		sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La = 0;
		sbt_pfxljpoUPeASopnPMp5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID = 11159;
		sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk = "_;Yjpma$A7\\";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.push_back(1202425803);
		}
		sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8 = 1368903125581371722;
		sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC = -25;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_9cjo1q030P2ZgrQcG.push_back(-32);
		}
		sbt_yjaLBa9zMeU4MI4SOLiQhpx = 48620;
		sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La = 25287;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_pfxljpoUPeASopnPMp5.push_back(-92);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq *pObject = dynamic_cast<const sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID != pObject->sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk.c_str(), pObject->sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk.c_str()))
		{
			return false;
		}
		if (sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.size() != pObject->sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.size(); i++)
		{
			if (sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH[i] != pObject->sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH[i])
			{
				return false;
			}
		}
		if (sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8 != pObject->sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8)
		{
			return false;
		}
		if (sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC != pObject->sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC)
		{
			return false;
		}
		if (sbt_9cjo1q030P2ZgrQcG.size() != pObject->sbt_9cjo1q030P2ZgrQcG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9cjo1q030P2ZgrQcG.size(); i++)
		{
			if (sbt_9cjo1q030P2ZgrQcG[i] != pObject->sbt_9cjo1q030P2ZgrQcG[i])
			{
				return false;
			}
		}
		if (sbt_yjaLBa9zMeU4MI4SOLiQhpx != pObject->sbt_yjaLBa9zMeU4MI4SOLiQhpx)
		{
			return false;
		}
		if (sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La != pObject->sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La)
		{
			return false;
		}
		if (sbt_pfxljpoUPeASopnPMp5.size() != pObject->sbt_pfxljpoUPeASopnPMp5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pfxljpoUPeASopnPMp5.size(); i++)
		{
			if (sbt_pfxljpoUPeASopnPMp5[i] != pObject->sbt_pfxljpoUPeASopnPMp5[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk", &sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9cjo1q030P2ZgrQcG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9cjo1q030P2ZgrQcG.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yjaLBa9zMeU4MI4SOLiQhpx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yjaLBa9zMeU4MI4SOLiQhpx = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pfxljpoUPeASopnPMp5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pfxljpoUPeASopnPMp5.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID", (CX::Int64)sbt_e7KNqkSuaHMHeT9hjKVIk4pz2GY8RV70zJ65Wjr7G1G6Ow_XcpmID)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk", sbt_cGDpQ4RZbBonDUaWR6oCbfVY8uQRk.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.begin(); iter != sbt_H_AjitdhQpefnGuMGejTz2QqH0hUUSbQB9bxbcH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8", (CX::Int64)sbt_ysPF_ZwWabwE25qrBHaHhx4m0lC5bOCfzfBtlchoAWw9fzViXNHTWDF_drkK8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC", (CX::Int64)sbt_xwf9fJvYAwieDeDiRl8edHv5G1PQDJEGyiULiyvCDM_beJblbX1c7IBkybzyC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9cjo1q030P2ZgrQcG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_9cjo1q030P2ZgrQcG.begin(); iter != sbt_9cjo1q030P2ZgrQcG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yjaLBa9zMeU4MI4SOLiQhpx", (CX::Int64)sbt_yjaLBa9zMeU4MI4SOLiQhpx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La", (CX::Int64)sbt_ZeblAWuA2scXBC7XeiwTe9f4w7ry3wEjpAsv9srBNWEwOZWb1La)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pfxljpoUPeASopnPMp5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_pfxljpoUPeASopnPMp5.begin(); iter != sbt_pfxljpoUPeASopnPMp5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq>::Type sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmqArray;

