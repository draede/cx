
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo.hpp"


class sbt_bJ6BPs7vVwBd7yjaT : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_PkegLHXrsoHpTObBK_w5WRl;
	CX::IO::SimpleBuffers::UInt16Array sbt_WhTudFprzG700QSLtK396y3GRie;
	CX::UInt32 sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g;
	CX::IO::SimpleBuffers::UInt64Array sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ;
	CX::Bool sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk;
	CX::IO::SimpleBuffers::Int8Array sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve;
	CX::UInt64 sbt_oyYmPb4eQlPXLuzo2J_T7;
	CX::UInt16 sbt_U_dhcXaX8BClMProuYUNYJu;
	sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw;

	virtual void Reset()
	{
		sbt_PkegLHXrsoHpTObBK_w5WRl.clear();
		sbt_WhTudFprzG700QSLtK396y3GRie.clear();
		sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g = 0;
		sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.clear();
		sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk = false;
		sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.clear();
		sbt_oyYmPb4eQlPXLuzo2J_T7 = 0;
		sbt_U_dhcXaX8BClMProuYUNYJu = 0;
		sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_PkegLHXrsoHpTObBK_w5WRl.push_back(72);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_WhTudFprzG700QSLtK396y3GRie.push_back(10706);
		}
		sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g = 3215101562;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.push_back(11520030619757688470);
		}
		sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk = true;
		sbt_oyYmPb4eQlPXLuzo2J_T7 = 12886670142200498738;
		sbt_U_dhcXaX8BClMProuYUNYJu = 22314;
		sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_bJ6BPs7vVwBd7yjaT *pObject = dynamic_cast<const sbt_bJ6BPs7vVwBd7yjaT *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_PkegLHXrsoHpTObBK_w5WRl.size() != pObject->sbt_PkegLHXrsoHpTObBK_w5WRl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PkegLHXrsoHpTObBK_w5WRl.size(); i++)
		{
			if (sbt_PkegLHXrsoHpTObBK_w5WRl[i] != pObject->sbt_PkegLHXrsoHpTObBK_w5WRl[i])
			{
				return false;
			}
		}
		if (sbt_WhTudFprzG700QSLtK396y3GRie.size() != pObject->sbt_WhTudFprzG700QSLtK396y3GRie.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WhTudFprzG700QSLtK396y3GRie.size(); i++)
		{
			if (sbt_WhTudFprzG700QSLtK396y3GRie[i] != pObject->sbt_WhTudFprzG700QSLtK396y3GRie[i])
			{
				return false;
			}
		}
		if (sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g != pObject->sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g)
		{
			return false;
		}
		if (sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.size() != pObject->sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.size(); i++)
		{
			if (sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ[i] != pObject->sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ[i])
			{
				return false;
			}
		}
		if (sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk != pObject->sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk)
		{
			return false;
		}
		if (sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.size() != pObject->sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.size(); i++)
		{
			if (sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve[i] != pObject->sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve[i])
			{
				return false;
			}
		}
		if (sbt_oyYmPb4eQlPXLuzo2J_T7 != pObject->sbt_oyYmPb4eQlPXLuzo2J_T7)
		{
			return false;
		}
		if (sbt_U_dhcXaX8BClMProuYUNYJu != pObject->sbt_U_dhcXaX8BClMProuYUNYJu)
		{
			return false;
		}
		if (!sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw.Compare(&pObject->sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_PkegLHXrsoHpTObBK_w5WRl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PkegLHXrsoHpTObBK_w5WRl.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WhTudFprzG700QSLtK396y3GRie")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WhTudFprzG700QSLtK396y3GRie.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk", &sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oyYmPb4eQlPXLuzo2J_T7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oyYmPb4eQlPXLuzo2J_T7 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_U_dhcXaX8BClMProuYUNYJu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_U_dhcXaX8BClMProuYUNYJu = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_PkegLHXrsoHpTObBK_w5WRl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_PkegLHXrsoHpTObBK_w5WRl.begin(); iter != sbt_PkegLHXrsoHpTObBK_w5WRl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WhTudFprzG700QSLtK396y3GRie")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_WhTudFprzG700QSLtK396y3GRie.begin(); iter != sbt_WhTudFprzG700QSLtK396y3GRie.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g", (CX::Int64)sbt_HnxhDJaxzJ0KTYIcoqvsLMZsrZtlArkKTLVKQ0oyfDrvDzcXocUBW8g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.begin(); iter != sbt_NofOE2bg4v3AY4ha_6IyQNgF22VZclsYjy2hoohurWikQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk", sbt_pKXNr7ymRqmOGYrXO4l3ZJOchRpkm1siO8tVJDk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.begin(); iter != sbt_x4YNum_p3LiJFMHVrElUEkjj8Ve.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oyYmPb4eQlPXLuzo2J_T7", (CX::Int64)sbt_oyYmPb4eQlPXLuzo2J_T7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_U_dhcXaX8BClMProuYUNYJu", (CX::Int64)sbt_U_dhcXaX8BClMProuYUNYJu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ttBsrv85svbPbw8Lu8YsN3319rr9hwyYNiw.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_bJ6BPs7vVwBd7yjaT>::Type sbt_bJ6BPs7vVwBd7yjaTArray;

