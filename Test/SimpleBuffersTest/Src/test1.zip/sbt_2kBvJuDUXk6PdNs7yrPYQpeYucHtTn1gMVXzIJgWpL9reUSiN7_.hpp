
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI.hpp"


class sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE;
	CX::UInt8 sbt_i1ial;
	CX::UInt64 sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV;
	CX::IO::SimpleBuffers::Int8Array sbt_qvMCaS6JCNmHLyDkBNb;
	CX::Int16 sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg;
	CX::IO::SimpleBuffers::StringArray sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj;
	CX::Int8 sbt_KaYCKiLUcweSzT2GN;
	CX::Double sbt_vpGWSJNvvTW_d;
	CX::Int64 sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0;
	CX::IO::SimpleBuffers::BoolArray sbt_CbL;
	CX::IO::SimpleBuffers::FloatArray sbt_OwV53K0TM;
	CX::IO::SimpleBuffers::UInt8Array sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ;
	CX::UInt64 sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O;
	CX::IO::SimpleBuffers::UInt16Array sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj;
	CX::UInt32 sbt_YcEImnLwt9qmC;
	CX::IO::SimpleBuffers::Int64Array sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw;
	CX::UInt64 sbt_Q1SaIAc8qm3hJbX_S;
	CX::Int32 sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo;
	CX::IO::SimpleBuffers::UInt64Array sbt_9XX3SRC8cl5c6;
	CX::WString sbt_9UQ4i8LXL;
	CX::IO::SimpleBuffers::StringArray sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH;
	sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goIArray sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX;

	virtual void Reset()
	{
		sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.clear();
		sbt_i1ial = 0;
		sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV = 0;
		sbt_qvMCaS6JCNmHLyDkBNb.clear();
		sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg = 0;
		sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.clear();
		sbt_KaYCKiLUcweSzT2GN = 0;
		sbt_vpGWSJNvvTW_d = 0.0;
		sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0 = 0;
		sbt_CbL.clear();
		sbt_OwV53K0TM.clear();
		sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.clear();
		sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O = 0;
		sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.clear();
		sbt_YcEImnLwt9qmC = 0;
		sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.clear();
		sbt_Q1SaIAc8qm3hJbX_S = 0;
		sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo = 0;
		sbt_9XX3SRC8cl5c6.clear();
		sbt_9UQ4i8LXL.clear();
		sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.clear();
		sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_i1ial = 101;
		sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV = 15332916741823987620;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_qvMCaS6JCNmHLyDkBNb.push_back(-93);
		}
		sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg = -25548;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.push_back("n?RpN5/@S8%y!v\"^y/{guAf34`s$7312o]2Ac6Alcr\\^qSo'DT&");
		}
		sbt_KaYCKiLUcweSzT2GN = 123;
		sbt_vpGWSJNvvTW_d = 0.070015;
		sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0 = 255860455323395690;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_CbL.push_back(false);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_OwV53K0TM.push_back(0.946164f);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.push_back(185);
		}
		sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O = 3771519006764712222;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.push_back(57894);
		}
		sbt_YcEImnLwt9qmC = 3092382348;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.push_back(-5453918787996344454);
		}
		sbt_Q1SaIAc8qm3hJbX_S = 17999655123076819258;
		sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo = -1078388772;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_9XX3SRC8cl5c6.push_back(14548134519460558120);
		}
		sbt_9UQ4i8LXL = L"J15,Ce(jy[)luc5PkbD1|9$1=7";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.push_back("AJVQ(R<jq+2P;X1-bI^`RULprMR^^d8'.+)sAtbKkYNJv.U-{v<c}_2Nw]MT]Sp");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI v;

			v.SetupWithSomeValues();
			sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_ *pObject = dynamic_cast<const sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.size() != pObject->sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.size(); i++)
		{
			if (sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE[i] != pObject->sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE[i])
			{
				return false;
			}
		}
		if (sbt_i1ial != pObject->sbt_i1ial)
		{
			return false;
		}
		if (sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV != pObject->sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV)
		{
			return false;
		}
		if (sbt_qvMCaS6JCNmHLyDkBNb.size() != pObject->sbt_qvMCaS6JCNmHLyDkBNb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qvMCaS6JCNmHLyDkBNb.size(); i++)
		{
			if (sbt_qvMCaS6JCNmHLyDkBNb[i] != pObject->sbt_qvMCaS6JCNmHLyDkBNb[i])
			{
				return false;
			}
		}
		if (sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg != pObject->sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg)
		{
			return false;
		}
		if (sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.size() != pObject->sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.size(); i++)
		{
			if (0 != cx_strcmp(sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj[i].c_str(), pObject->sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_KaYCKiLUcweSzT2GN != pObject->sbt_KaYCKiLUcweSzT2GN)
		{
			return false;
		}
		if (sbt_vpGWSJNvvTW_d != pObject->sbt_vpGWSJNvvTW_d)
		{
			return false;
		}
		if (sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0 != pObject->sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0)
		{
			return false;
		}
		if (sbt_CbL.size() != pObject->sbt_CbL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CbL.size(); i++)
		{
			if (sbt_CbL[i] != pObject->sbt_CbL[i])
			{
				return false;
			}
		}
		if (sbt_OwV53K0TM.size() != pObject->sbt_OwV53K0TM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OwV53K0TM.size(); i++)
		{
			if (sbt_OwV53K0TM[i] != pObject->sbt_OwV53K0TM[i])
			{
				return false;
			}
		}
		if (sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.size() != pObject->sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.size(); i++)
		{
			if (sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ[i] != pObject->sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ[i])
			{
				return false;
			}
		}
		if (sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O != pObject->sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O)
		{
			return false;
		}
		if (sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.size() != pObject->sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.size(); i++)
		{
			if (sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj[i] != pObject->sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj[i])
			{
				return false;
			}
		}
		if (sbt_YcEImnLwt9qmC != pObject->sbt_YcEImnLwt9qmC)
		{
			return false;
		}
		if (sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.size() != pObject->sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.size(); i++)
		{
			if (sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw[i] != pObject->sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw[i])
			{
				return false;
			}
		}
		if (sbt_Q1SaIAc8qm3hJbX_S != pObject->sbt_Q1SaIAc8qm3hJbX_S)
		{
			return false;
		}
		if (sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo != pObject->sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo)
		{
			return false;
		}
		if (sbt_9XX3SRC8cl5c6.size() != pObject->sbt_9XX3SRC8cl5c6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9XX3SRC8cl5c6.size(); i++)
		{
			if (sbt_9XX3SRC8cl5c6[i] != pObject->sbt_9XX3SRC8cl5c6[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_9UQ4i8LXL.c_str(), pObject->sbt_9UQ4i8LXL.c_str()))
		{
			return false;
		}
		if (sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.size() != pObject->sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.size(); i++)
		{
			if (0 != cx_strcmp(sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH[i].c_str(), pObject->sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.size() != pObject->sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.size(); i++)
		{
			if (!sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX[i].Compare(&pObject->sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_i1ial", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_i1ial = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qvMCaS6JCNmHLyDkBNb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qvMCaS6JCNmHLyDkBNb.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KaYCKiLUcweSzT2GN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KaYCKiLUcweSzT2GN = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_vpGWSJNvvTW_d", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_vpGWSJNvvTW_d = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CbL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CbL.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OwV53K0TM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OwV53K0TM.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YcEImnLwt9qmC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YcEImnLwt9qmC = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Q1SaIAc8qm3hJbX_S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Q1SaIAc8qm3hJbX_S = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9XX3SRC8cl5c6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9XX3SRC8cl5c6.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_9UQ4i8LXL", &sbt_9UQ4i8LXL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.begin(); iter != sbt_xriFIDt17jw0v8vOs_gRR6TDkPi3sXjBE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_i1ial", (CX::Int64)sbt_i1ial)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV", (CX::Int64)sbt_nJlh3gUCv6DQNloFI3tsB7p5B9mEa5Otu1m2v__3aMuTR7LPV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qvMCaS6JCNmHLyDkBNb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_qvMCaS6JCNmHLyDkBNb.begin(); iter != sbt_qvMCaS6JCNmHLyDkBNb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg", (CX::Int64)sbt_Sbzo27aLuT__wFL60kCEpzkman_YKuGFbH06jvg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.begin(); iter != sbt_IPFA9P6WSWNRyJ0PY1H1PUNL99RdThj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KaYCKiLUcweSzT2GN", (CX::Int64)sbt_KaYCKiLUcweSzT2GN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_vpGWSJNvvTW_d", (CX::Double)sbt_vpGWSJNvvTW_d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0", (CX::Int64)sbt_8sX74h83nLmFVILsbqFOaB_FSzPo0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CbL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_CbL.begin(); iter != sbt_CbL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OwV53K0TM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_OwV53K0TM.begin(); iter != sbt_OwV53K0TM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.begin(); iter != sbt_qwfcnfFPyJlcEPZj4W_OhpwKsEG6YYFmQR9zMRQfyMWjCcNOSMV0xr6r1oSFQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O", (CX::Int64)sbt_FAKoZA5lX6PcNbvgTmpSZGcuIhpvyjHzuGMlwI2_LyeYzDarh88pF6O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.begin(); iter != sbt_yrDVvaJxRyA8lo3f2bMBUz3szdLJnrthx05e0MrKq8Z3v3gObg2mjIj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YcEImnLwt9qmC", (CX::Int64)sbt_YcEImnLwt9qmC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.begin(); iter != sbt_pZu659spt_OpnTfs9tcXXSsptIc5lOXp7MNqMvd_HAw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Q1SaIAc8qm3hJbX_S", (CX::Int64)sbt_Q1SaIAc8qm3hJbX_S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo", (CX::Int64)sbt_mRDjUD8KTzk4pK80HJ_TMeUn7nOMpvjfo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9XX3SRC8cl5c6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_9XX3SRC8cl5c6.begin(); iter != sbt_9XX3SRC8cl5c6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_9UQ4i8LXL", sbt_9UQ4i8LXL.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.begin(); iter != sbt_U5kEUnhaBfmKy1lE_WGR5FOPXCc3hVH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX")).IsNOK())
		{
			return status;
		}
		for (sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goIArray::const_iterator iter = sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.begin(); iter != sbt_CPNkK6vFzYxZz0VXiGc_tCtdbTf8HkcxgL4oX.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_>::Type sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_Array;

