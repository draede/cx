
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY;
	CX::Int8 sbt_vU2SMMBVBVb5804kC;
	CX::IO::SimpleBuffers::Int64Array sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr;
	CX::IO::SimpleBuffers::UInt64Array sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT;

	virtual void Reset()
	{
		sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY.clear();
		sbt_vU2SMMBVBVb5804kC = 0;
		sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.clear();
		sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY = "1jm]Zr}x:N@97K0c>[z?>&=Z6isZl@\\'Hvac-'OSnkj]t@>3I&92H[R<A+";
		sbt_vU2SMMBVBVb5804kC = -119;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.push_back(-290424673608459726);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.push_back(4826998315679648830);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw *pObject = dynamic_cast<const sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY.c_str(), pObject->sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY.c_str()))
		{
			return false;
		}
		if (sbt_vU2SMMBVBVb5804kC != pObject->sbt_vU2SMMBVBVb5804kC)
		{
			return false;
		}
		if (sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.size() != pObject->sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.size(); i++)
		{
			if (sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr[i] != pObject->sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr[i])
			{
				return false;
			}
		}
		if (sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.size() != pObject->sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.size(); i++)
		{
			if (sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT[i] != pObject->sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY", &sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vU2SMMBVBVb5804kC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vU2SMMBVBVb5804kC = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY", sbt_dtm3SvBTmicvdGpKuqEf_IEeh2PuoW_bwMXpmvaWNwiAcLY.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vU2SMMBVBVb5804kC", (CX::Int64)sbt_vU2SMMBVBVb5804kC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.begin(); iter != sbt_gSVMhZ5Ngn1Kr0KI03dWB0hfzDLfM2L2rk06_YFlnH8z53QcJHr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.begin(); iter != sbt_t3rHNS4ioqWjgdqHdjEjzwmolCCsH6t7PVvhmFaWcyLqT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw>::Type sbt_ooaz5jN7Um93iqbDqfmHrhbRFnwArray;

