
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g;
	CX::IO::SimpleBuffers::UInt16Array sbt_eNVvgLMz9_fi0;

	virtual void Reset()
	{
		sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.clear();
		sbt_eNVvgLMz9_fi0.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.push_back(39396);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_eNVvgLMz9_fi0.push_back(590);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ *pObject = dynamic_cast<const sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.size() != pObject->sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.size(); i++)
		{
			if (sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g[i] != pObject->sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g[i])
			{
				return false;
			}
		}
		if (sbt_eNVvgLMz9_fi0.size() != pObject->sbt_eNVvgLMz9_fi0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eNVvgLMz9_fi0.size(); i++)
		{
			if (sbt_eNVvgLMz9_fi0[i] != pObject->sbt_eNVvgLMz9_fi0[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eNVvgLMz9_fi0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eNVvgLMz9_fi0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.begin(); iter != sbt_eydKAlyCEoYDCSICw5CZmmwcEcTZFKe7F7Mhf3g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eNVvgLMz9_fi0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_eNVvgLMz9_fi0.begin(); iter != sbt_eNVvgLMz9_fi0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ>::Type sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQArray;

