
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_v8y : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_zlZqPtfUeEtQG0R8PVQlS;

	virtual void Reset()
	{
		sbt_zlZqPtfUeEtQG0R8PVQlS = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_zlZqPtfUeEtQG0R8PVQlS = 2116293190;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_v8y *pObject = dynamic_cast<const sbt_v8y *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_zlZqPtfUeEtQG0R8PVQlS != pObject->sbt_zlZqPtfUeEtQG0R8PVQlS)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_zlZqPtfUeEtQG0R8PVQlS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zlZqPtfUeEtQG0R8PVQlS = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_zlZqPtfUeEtQG0R8PVQlS", (CX::Int64)sbt_zlZqPtfUeEtQG0R8PVQlS)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_v8y>::Type sbt_v8yArray;

