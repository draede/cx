
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld.hpp"


class sbt_g8dOw6ykyiVJImhB8zO : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP;
	CX::UInt8 sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW;
	CX::IO::SimpleBuffers::UInt64Array sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU;
	CX::String sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST;
	CX::Bool sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4;
	CX::IO::SimpleBuffers::UInt64Array sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH;
	CX::UInt32 sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99;
	CX::IO::SimpleBuffers::UInt16Array sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6;
	CX::Bool sbt_UPlvN1Q51Y3zIy6A4ZDJczD;
	sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld sbt_Vn3Aqeo_6mWHbts9GIf;

	virtual void Reset()
	{
		sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP = 0.0;
		sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW = 0;
		sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.clear();
		sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST.clear();
		sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4 = false;
		sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.clear();
		sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99 = 0;
		sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.clear();
		sbt_UPlvN1Q51Y3zIy6A4ZDJczD = false;
		sbt_Vn3Aqeo_6mWHbts9GIf.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP = 0.551359;
		sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW = 140;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.push_back(16485548801698599602);
		}
		sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST = "N*";
		sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4 = true;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.push_back(6695537237513939530);
		}
		sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99 = 901341435;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.push_back(15839);
		}
		sbt_UPlvN1Q51Y3zIy6A4ZDJczD = true;
		sbt_Vn3Aqeo_6mWHbts9GIf.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_g8dOw6ykyiVJImhB8zO *pObject = dynamic_cast<const sbt_g8dOw6ykyiVJImhB8zO *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP != pObject->sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP)
		{
			return false;
		}
		if (sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW != pObject->sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW)
		{
			return false;
		}
		if (sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.size() != pObject->sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.size(); i++)
		{
			if (sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU[i] != pObject->sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST.c_str(), pObject->sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST.c_str()))
		{
			return false;
		}
		if (sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4 != pObject->sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4)
		{
			return false;
		}
		if (sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.size() != pObject->sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.size(); i++)
		{
			if (sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH[i] != pObject->sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH[i])
			{
				return false;
			}
		}
		if (sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99 != pObject->sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99)
		{
			return false;
		}
		if (sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.size() != pObject->sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.size(); i++)
		{
			if (sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6[i] != pObject->sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6[i])
			{
				return false;
			}
		}
		if (sbt_UPlvN1Q51Y3zIy6A4ZDJczD != pObject->sbt_UPlvN1Q51Y3zIy6A4ZDJczD)
		{
			return false;
		}
		if (!sbt_Vn3Aqeo_6mWHbts9GIf.Compare(&pObject->sbt_Vn3Aqeo_6mWHbts9GIf))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST", &sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4", &sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_UPlvN1Q51Y3zIy6A4ZDJczD", &sbt_UPlvN1Q51Y3zIy6A4ZDJczD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_Vn3Aqeo_6mWHbts9GIf")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Vn3Aqeo_6mWHbts9GIf.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP", (CX::Double)sbt_XqqAQwogvXPeuXLd9UJUPN2Ukyt2pxSJp6GHV7tK_8xrPPFwP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW", (CX::Int64)sbt_EQsVK4n5J9jjkB8b4Cu7_F9gY4HS4aW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.begin(); iter != sbt_nrrUDpt7mtKr16tHhmDcHQSL9GuzYP3PMZUF3gbDPRU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST", sbt_5Qqxq2dwqQJpmMvba7nqBVm8CL404IpzWJ5ygMOby50t4T_ST.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4", sbt_ZWr1PLMoeWRKd3VjssJG5mJYjyc1oYOSi_Lm6qpEtExkfy4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.begin(); iter != sbt_JK_kNfgh6tqRWk79GMHWTqdZHfihmOARNdhCGTdaH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99", (CX::Int64)sbt_5psxRhjmr1G6PIgYn3V_14y9nIQKjERQPXoz_gbB9vGx4gMA7Sa1LJR99)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.begin(); iter != sbt_k2B1EhnOl5EnTPkt3FV2p_3RP1J3Lw6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_UPlvN1Q51Y3zIy6A4ZDJczD", sbt_UPlvN1Q51Y3zIy6A4ZDJczD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_Vn3Aqeo_6mWHbts9GIf")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Vn3Aqeo_6mWHbts9GIf.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_g8dOw6ykyiVJImhB8zO>::Type sbt_g8dOw6ykyiVJImhB8zOArray;

