
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_FW5GTG6t9V_XSet7gY5.hpp"


class sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_Zc6jRDg;
	CX::IO::SimpleBuffers::DoubleArray sbt_KnA4jZWxLpLYocXiG9cxHOU;
	CX::Int16 sbt_wuEKJ7lM_sdC3MgZmJN9XBo;
	CX::IO::SimpleBuffers::FloatArray sbt_Ak4E6cx1TMZ;
	CX::IO::SimpleBuffers::UInt32Array sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL;
	CX::String sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1;
	CX::IO::SimpleBuffers::Int8Array sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK;
	CX::IO::SimpleBuffers::UInt8Array sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW;
	CX::String sbt_KcltpjkJ7raJGTVIxVyN__w;
	CX::IO::SimpleBuffers::DoubleArray sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o;
	CX::Int8 sbt__02K7;
	CX::Double sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2;
	CX::IO::SimpleBuffers::StringArray sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe;
	CX::Int32 sbt_mBSQk8hTnG8HPxI;
	CX::IO::SimpleBuffers::FloatArray sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8;
	CX::IO::SimpleBuffers::WStringArray sbt_CuDHAday7uuQk;
	CX::IO::SimpleBuffers::DoubleArray sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK;
	CX::Bool sbt_C68pPJwDPSOBW3oEgFk3ruq;
	CX::String sbt_Eh9DqkQ0G249eJ4;
	CX::Int32 sbt_NA1XYQWXZVfEX;
	CX::UInt32 sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg;
	CX::Double sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN;
	CX::IO::SimpleBuffers::DoubleArray sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH;
	sbt_FW5GTG6t9V_XSet7gY5Array sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy;

	virtual void Reset()
	{
		sbt_Zc6jRDg = 0.0f;
		sbt_KnA4jZWxLpLYocXiG9cxHOU.clear();
		sbt_wuEKJ7lM_sdC3MgZmJN9XBo = 0;
		sbt_Ak4E6cx1TMZ.clear();
		sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.clear();
		sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1.clear();
		sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.clear();
		sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.clear();
		sbt_KcltpjkJ7raJGTVIxVyN__w.clear();
		sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.clear();
		sbt__02K7 = 0;
		sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2 = 0.0;
		sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.clear();
		sbt_mBSQk8hTnG8HPxI = 0;
		sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.clear();
		sbt_CuDHAday7uuQk.clear();
		sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.clear();
		sbt_C68pPJwDPSOBW3oEgFk3ruq = false;
		sbt_Eh9DqkQ0G249eJ4.clear();
		sbt_NA1XYQWXZVfEX = 0;
		sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg = 0;
		sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN = 0.0;
		sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.clear();
		sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Zc6jRDg = 0.463567f;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_KnA4jZWxLpLYocXiG9cxHOU.push_back(0.574608);
		}
		sbt_wuEKJ7lM_sdC3MgZmJN9XBo = -2006;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Ak4E6cx1TMZ.push_back(0.014931f);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.push_back(384705210);
		}
		sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1 = "8r";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.push_back(57);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.push_back(29);
		}
		sbt_KcltpjkJ7raJGTVIxVyN__w = "lPTe1,c*p2/|=%v'8}r0ZC,'}=3+u}^5>:;~bQPHe]}kPtx+}";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.push_back(0.688014);
		}
		sbt__02K7 = -39;
		sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2 = 0.826322;
		sbt_mBSQk8hTnG8HPxI = 245385310;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.push_back(0.443446f);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_CuDHAday7uuQk.push_back(L".p2>\\?W%&iBSft");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.push_back(0.446644);
		}
		sbt_C68pPJwDPSOBW3oEgFk3ruq = false;
		sbt_Eh9DqkQ0G249eJ4 = "KK7RqbZB8o(yQ2-u{2:VH6uS\\A@Dl}7H.eQ{x(r56M9ASVw$LU\\?yD0=";
		sbt_NA1XYQWXZVfEX = -1551401526;
		sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg = 1121376112;
		sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN = 0.577611;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.push_back(0.478692);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_FW5GTG6t9V_XSet7gY5 v;

			v.SetupWithSomeValues();
			sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP *pObject = dynamic_cast<const sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Zc6jRDg != pObject->sbt_Zc6jRDg)
		{
			return false;
		}
		if (sbt_KnA4jZWxLpLYocXiG9cxHOU.size() != pObject->sbt_KnA4jZWxLpLYocXiG9cxHOU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KnA4jZWxLpLYocXiG9cxHOU.size(); i++)
		{
			if (sbt_KnA4jZWxLpLYocXiG9cxHOU[i] != pObject->sbt_KnA4jZWxLpLYocXiG9cxHOU[i])
			{
				return false;
			}
		}
		if (sbt_wuEKJ7lM_sdC3MgZmJN9XBo != pObject->sbt_wuEKJ7lM_sdC3MgZmJN9XBo)
		{
			return false;
		}
		if (sbt_Ak4E6cx1TMZ.size() != pObject->sbt_Ak4E6cx1TMZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ak4E6cx1TMZ.size(); i++)
		{
			if (sbt_Ak4E6cx1TMZ[i] != pObject->sbt_Ak4E6cx1TMZ[i])
			{
				return false;
			}
		}
		if (sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.size() != pObject->sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.size(); i++)
		{
			if (sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL[i] != pObject->sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1.c_str(), pObject->sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1.c_str()))
		{
			return false;
		}
		if (sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.size() != pObject->sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.size(); i++)
		{
			if (sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK[i] != pObject->sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK[i])
			{
				return false;
			}
		}
		if (sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.size() != pObject->sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.size(); i++)
		{
			if (sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW[i] != pObject->sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_KcltpjkJ7raJGTVIxVyN__w.c_str(), pObject->sbt_KcltpjkJ7raJGTVIxVyN__w.c_str()))
		{
			return false;
		}
		if (sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.size() != pObject->sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.size(); i++)
		{
			if (sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o[i] != pObject->sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o[i])
			{
				return false;
			}
		}
		if (sbt__02K7 != pObject->sbt__02K7)
		{
			return false;
		}
		if (sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2 != pObject->sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2)
		{
			return false;
		}
		if (sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.size() != pObject->sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.size(); i++)
		{
			if (0 != cx_strcmp(sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe[i].c_str(), pObject->sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_mBSQk8hTnG8HPxI != pObject->sbt_mBSQk8hTnG8HPxI)
		{
			return false;
		}
		if (sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.size() != pObject->sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.size(); i++)
		{
			if (sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8[i] != pObject->sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8[i])
			{
				return false;
			}
		}
		if (sbt_CuDHAday7uuQk.size() != pObject->sbt_CuDHAday7uuQk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CuDHAday7uuQk.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_CuDHAday7uuQk[i].c_str(), pObject->sbt_CuDHAday7uuQk[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.size() != pObject->sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.size(); i++)
		{
			if (sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK[i] != pObject->sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK[i])
			{
				return false;
			}
		}
		if (sbt_C68pPJwDPSOBW3oEgFk3ruq != pObject->sbt_C68pPJwDPSOBW3oEgFk3ruq)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Eh9DqkQ0G249eJ4.c_str(), pObject->sbt_Eh9DqkQ0G249eJ4.c_str()))
		{
			return false;
		}
		if (sbt_NA1XYQWXZVfEX != pObject->sbt_NA1XYQWXZVfEX)
		{
			return false;
		}
		if (sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg != pObject->sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg)
		{
			return false;
		}
		if (sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN != pObject->sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN)
		{
			return false;
		}
		if (sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.size() != pObject->sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.size(); i++)
		{
			if (sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH[i] != pObject->sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH[i])
			{
				return false;
			}
		}
		if (sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.size() != pObject->sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.size(); i++)
		{
			if (!sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy[i].Compare(&pObject->sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_Zc6jRDg", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Zc6jRDg = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_KnA4jZWxLpLYocXiG9cxHOU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KnA4jZWxLpLYocXiG9cxHOU.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wuEKJ7lM_sdC3MgZmJN9XBo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wuEKJ7lM_sdC3MgZmJN9XBo = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Ak4E6cx1TMZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ak4E6cx1TMZ.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1", &sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_KcltpjkJ7raJGTVIxVyN__w", &sbt_KcltpjkJ7raJGTVIxVyN__w)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__02K7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__02K7 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mBSQk8hTnG8HPxI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mBSQk8hTnG8HPxI = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CuDHAday7uuQk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CuDHAday7uuQk.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_C68pPJwDPSOBW3oEgFk3ruq", &sbt_C68pPJwDPSOBW3oEgFk3ruq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Eh9DqkQ0G249eJ4", &sbt_Eh9DqkQ0G249eJ4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NA1XYQWXZVfEX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NA1XYQWXZVfEX = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_FW5GTG6t9V_XSet7gY5 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_Zc6jRDg", (CX::Double)sbt_Zc6jRDg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KnA4jZWxLpLYocXiG9cxHOU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_KnA4jZWxLpLYocXiG9cxHOU.begin(); iter != sbt_KnA4jZWxLpLYocXiG9cxHOU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wuEKJ7lM_sdC3MgZmJN9XBo", (CX::Int64)sbt_wuEKJ7lM_sdC3MgZmJN9XBo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ak4E6cx1TMZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Ak4E6cx1TMZ.begin(); iter != sbt_Ak4E6cx1TMZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.begin(); iter != sbt_y8qV1ZJAKfEoKSU9qW9AZZq0BSRaxsqO4hqmL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1", sbt_uCGbPyXp9hsVtVpB_f0ZUDVU7kfzZYBkStRCYa32Uida6_NYKydwUIhjp_xYXa1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.begin(); iter != sbt_DRsV7RrA7bgnbDsJE89wJMUyt4gvaIqwK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.begin(); iter != sbt_18sVnz3OWTxajcCkca0MnyN_TfmGMjtBBEW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_KcltpjkJ7raJGTVIxVyN__w", sbt_KcltpjkJ7raJGTVIxVyN__w.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.begin(); iter != sbt_ovnPu39djJBLuuBo_8jYsYWIxll8aebQhvbf_m7QjYz66fg2o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__02K7", (CX::Int64)sbt__02K7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2", (CX::Double)sbt_ogSsPJP3rYyy0xBLEipyx6LRVIIQeyZviXmv1Rw71vporGku3F2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.begin(); iter != sbt_8oOcpw1URcpZO1tW9hkUPTy8VvbwxqUGEGkcggYi1WbJAjMUe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mBSQk8hTnG8HPxI", (CX::Int64)sbt_mBSQk8hTnG8HPxI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.begin(); iter != sbt_HfdBFxL59cxuYk5tsDysqQiJIWr5U6tiibV9PqAuwLadt50yVpnrkf8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CuDHAday7uuQk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_CuDHAday7uuQk.begin(); iter != sbt_CuDHAday7uuQk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.begin(); iter != sbt_RzqCSExCLBmksGM2P_QsfVAqyss8PmrGweWFpVf0NlhOxXpcCaK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_C68pPJwDPSOBW3oEgFk3ruq", sbt_C68pPJwDPSOBW3oEgFk3ruq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Eh9DqkQ0G249eJ4", sbt_Eh9DqkQ0G249eJ4.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NA1XYQWXZVfEX", (CX::Int64)sbt_NA1XYQWXZVfEX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg", (CX::Int64)sbt_jIuFepxS6xJVczl6YVT1BXFZfcbXY3ryg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN", (CX::Double)sbt_QVbBp1henYPQWXwbPXPvnDRS4Zzs1XN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.begin(); iter != sbt_8hBhvXCxmDOtpxpkj9KRsu_fll8HH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy")).IsNOK())
		{
			return status;
		}
		for (sbt_FW5GTG6t9V_XSet7gY5Array::const_iterator iter = sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.begin(); iter != sbt_dgq9HdTaX_obcgdkA5KWzmKFzk7EJAVyn7uv1K2KkO4RYULQ4YVP61FL8lo94Iy.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP>::Type sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxPArray;

