
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_jVSCkaD5dp1 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe;
	CX::Int16 sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM;
	CX::String sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV;
	CX::IO::SimpleBuffers::Int32Array sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi;
	CX::Bool sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4;
	CX::UInt16 sbt_ULcFnbWl_iq8VD65Gfg;
	CX::IO::SimpleBuffers::UInt64Array sbt_rJd;
	CX::IO::SimpleBuffers::Int64Array sbt__90K1DjPC51RKdmvKyr2qQnPB;
	CX::UInt16 sbt_SFQ_fD4i4isOQWSkDMxb__r;
	CX::UInt32 sbt_ioGeweqwOCZxU;
	CX::IO::SimpleBuffers::BoolArray sbt_qtYktRTZSfdMvg4qhBkSbKI5Y;
	CX::Bool sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN;

	virtual void Reset()
	{
		sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe = 0;
		sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM = 0;
		sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV.clear();
		sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.clear();
		sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4 = false;
		sbt_ULcFnbWl_iq8VD65Gfg = 0;
		sbt_rJd.clear();
		sbt__90K1DjPC51RKdmvKyr2qQnPB.clear();
		sbt_SFQ_fD4i4isOQWSkDMxb__r = 0;
		sbt_ioGeweqwOCZxU = 0;
		sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.clear();
		sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe = 10523657526023269190;
		sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM = -17575;
		sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV = "V";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.push_back(1853409239);
		}
		sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4 = true;
		sbt_ULcFnbWl_iq8VD65Gfg = 17857;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_rJd.push_back(7001803719420309494);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt__90K1DjPC51RKdmvKyr2qQnPB.push_back(8310171839757162472);
		}
		sbt_SFQ_fD4i4isOQWSkDMxb__r = 652;
		sbt_ioGeweqwOCZxU = 986663596;
		sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN = false;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_jVSCkaD5dp1 *pObject = dynamic_cast<const sbt_jVSCkaD5dp1 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe != pObject->sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe)
		{
			return false;
		}
		if (sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM != pObject->sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV.c_str(), pObject->sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV.c_str()))
		{
			return false;
		}
		if (sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.size() != pObject->sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.size(); i++)
		{
			if (sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi[i] != pObject->sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi[i])
			{
				return false;
			}
		}
		if (sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4 != pObject->sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4)
		{
			return false;
		}
		if (sbt_ULcFnbWl_iq8VD65Gfg != pObject->sbt_ULcFnbWl_iq8VD65Gfg)
		{
			return false;
		}
		if (sbt_rJd.size() != pObject->sbt_rJd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rJd.size(); i++)
		{
			if (sbt_rJd[i] != pObject->sbt_rJd[i])
			{
				return false;
			}
		}
		if (sbt__90K1DjPC51RKdmvKyr2qQnPB.size() != pObject->sbt__90K1DjPC51RKdmvKyr2qQnPB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__90K1DjPC51RKdmvKyr2qQnPB.size(); i++)
		{
			if (sbt__90K1DjPC51RKdmvKyr2qQnPB[i] != pObject->sbt__90K1DjPC51RKdmvKyr2qQnPB[i])
			{
				return false;
			}
		}
		if (sbt_SFQ_fD4i4isOQWSkDMxb__r != pObject->sbt_SFQ_fD4i4isOQWSkDMxb__r)
		{
			return false;
		}
		if (sbt_ioGeweqwOCZxU != pObject->sbt_ioGeweqwOCZxU)
		{
			return false;
		}
		if (sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.size() != pObject->sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.size(); i++)
		{
			if (sbt_qtYktRTZSfdMvg4qhBkSbKI5Y[i] != pObject->sbt_qtYktRTZSfdMvg4qhBkSbKI5Y[i])
			{
				return false;
			}
		}
		if (sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN != pObject->sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV", &sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4", &sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ULcFnbWl_iq8VD65Gfg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ULcFnbWl_iq8VD65Gfg = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rJd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rJd.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__90K1DjPC51RKdmvKyr2qQnPB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__90K1DjPC51RKdmvKyr2qQnPB.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SFQ_fD4i4isOQWSkDMxb__r", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SFQ_fD4i4isOQWSkDMxb__r = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ioGeweqwOCZxU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ioGeweqwOCZxU = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qtYktRTZSfdMvg4qhBkSbKI5Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN", &sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe", (CX::Int64)sbt_aoWwc9sNFUoH5WMpYZdY1Egdrfe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM", (CX::Int64)sbt_EEtbcQKQq6Sbh4XGsKQxUms3uotAeOT4XEA9N5gy64x_14k4B9Jy6NM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV", sbt_e2NAyF5gCA152IwHNsZaAxO472liXgmZiclmhX0yn05UV.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.begin(); iter != sbt_1UsPB50J5BWfe04VcaWhvVWDbvoCVTsGoAQYNGPG_aTzOgi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4", sbt_0wlT9GNLCa0up9nwibkfYE4HUe6ShFcOa6i46p5BvAv_7yZs491JCg4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ULcFnbWl_iq8VD65Gfg", (CX::Int64)sbt_ULcFnbWl_iq8VD65Gfg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rJd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_rJd.begin(); iter != sbt_rJd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__90K1DjPC51RKdmvKyr2qQnPB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt__90K1DjPC51RKdmvKyr2qQnPB.begin(); iter != sbt__90K1DjPC51RKdmvKyr2qQnPB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SFQ_fD4i4isOQWSkDMxb__r", (CX::Int64)sbt_SFQ_fD4i4isOQWSkDMxb__r)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ioGeweqwOCZxU", (CX::Int64)sbt_ioGeweqwOCZxU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qtYktRTZSfdMvg4qhBkSbKI5Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.begin(); iter != sbt_qtYktRTZSfdMvg4qhBkSbKI5Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN", sbt_SJSQGPMdyaa7RwPmtujK0siMHwMD56QWJRFxDIsrn3KkN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_jVSCkaD5dp1>::Type sbt_jVSCkaD5dp1Array;

