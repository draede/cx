
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jgDm6sWUw.hpp"


class sbt_gEFFmQ6 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL;
	sbt_jgDm6sWUwArray sbt_L6YDAWUNUvb4xhnVvm5;

	virtual void Reset()
	{
		sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL = 0;
		sbt_L6YDAWUNUvb4xhnVvm5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL = 11618265677781690854;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_jgDm6sWUw v;

			v.SetupWithSomeValues();
			sbt_L6YDAWUNUvb4xhnVvm5.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gEFFmQ6 *pObject = dynamic_cast<const sbt_gEFFmQ6 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL != pObject->sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL)
		{
			return false;
		}
		if (sbt_L6YDAWUNUvb4xhnVvm5.size() != pObject->sbt_L6YDAWUNUvb4xhnVvm5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L6YDAWUNUvb4xhnVvm5.size(); i++)
		{
			if (!sbt_L6YDAWUNUvb4xhnVvm5[i].Compare(&pObject->sbt_L6YDAWUNUvb4xhnVvm5[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_L6YDAWUNUvb4xhnVvm5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_jgDm6sWUw tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_L6YDAWUNUvb4xhnVvm5.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL", (CX::Int64)sbt_97CZEFc9cYWU84YszPMkRANY9cnb6ljruvy88uBKjhq_xoUHWoL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L6YDAWUNUvb4xhnVvm5")).IsNOK())
		{
			return status;
		}
		for (sbt_jgDm6sWUwArray::const_iterator iter = sbt_L6YDAWUNUvb4xhnVvm5.begin(); iter != sbt_L6YDAWUNUvb4xhnVvm5.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gEFFmQ6>::Type sbt_gEFFmQ6Array;

