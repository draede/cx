
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_HNAQoVIBEDIwlsBdK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T;
	CX::IO::SimpleBuffers::UInt64Array sbt_8WUvK;
	CX::IO::SimpleBuffers::UInt64Array sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs;
	CX::UInt32 sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n;
	CX::Int16 sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2;
	CX::IO::SimpleBuffers::Int16Array sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6;
	CX::IO::SimpleBuffers::StringArray sbt_QuzaAOu;
	CX::IO::SimpleBuffers::UInt16Array sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx;
	CX::UInt32 sbt_gY7FVyINxLNHccCoO;
	CX::IO::SimpleBuffers::StringArray sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh;
	CX::String sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw;
	CX::UInt32 sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B;
	CX::Int32 sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7;

	virtual void Reset()
	{
		sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.clear();
		sbt_8WUvK.clear();
		sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.clear();
		sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n = 0;
		sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2 = 0;
		sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.clear();
		sbt_QuzaAOu.clear();
		sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.clear();
		sbt_gY7FVyINxLNHccCoO = 0;
		sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.clear();
		sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw.clear();
		sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B = 0;
		sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.push_back(4873921018039851878);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_8WUvK.push_back(14507734208917284608);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.push_back(9513602682742041492);
		}
		sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n = 4152549182;
		sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2 = 14872;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.push_back(12404);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_QuzaAOu.push_back("fu3bjC|dA7/5epyzH\\FcTTd,P/c`AJho'dSQ|p`+$V^im_r6IU/6B");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.push_back(33588);
		}
		sbt_gY7FVyINxLNHccCoO = 2510766403;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.push_back("4RO#Cq5>oh7OaRx#Ao<7hZ$<sT)WQuh*6]=-\"n=P}~zORr");
		}
		sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw = "ikn}R:>~>njW!/)>{tHt#h>}uFAud7e[I*l;B+P=UtKWN";
		sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B = 485636819;
		sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7 = -648383269;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_HNAQoVIBEDIwlsBdK *pObject = dynamic_cast<const sbt_HNAQoVIBEDIwlsBdK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.size() != pObject->sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.size(); i++)
		{
			if (sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T[i] != pObject->sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T[i])
			{
				return false;
			}
		}
		if (sbt_8WUvK.size() != pObject->sbt_8WUvK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8WUvK.size(); i++)
		{
			if (sbt_8WUvK[i] != pObject->sbt_8WUvK[i])
			{
				return false;
			}
		}
		if (sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.size() != pObject->sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.size(); i++)
		{
			if (sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs[i] != pObject->sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs[i])
			{
				return false;
			}
		}
		if (sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n != pObject->sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n)
		{
			return false;
		}
		if (sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2 != pObject->sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2)
		{
			return false;
		}
		if (sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.size() != pObject->sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.size(); i++)
		{
			if (sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6[i] != pObject->sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6[i])
			{
				return false;
			}
		}
		if (sbt_QuzaAOu.size() != pObject->sbt_QuzaAOu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QuzaAOu.size(); i++)
		{
			if (0 != cx_strcmp(sbt_QuzaAOu[i].c_str(), pObject->sbt_QuzaAOu[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.size() != pObject->sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.size(); i++)
		{
			if (sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx[i] != pObject->sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx[i])
			{
				return false;
			}
		}
		if (sbt_gY7FVyINxLNHccCoO != pObject->sbt_gY7FVyINxLNHccCoO)
		{
			return false;
		}
		if (sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.size() != pObject->sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh[i].c_str(), pObject->sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw.c_str(), pObject->sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw.c_str()))
		{
			return false;
		}
		if (sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B != pObject->sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B)
		{
			return false;
		}
		if (sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7 != pObject->sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8WUvK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8WUvK.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QuzaAOu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QuzaAOu.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gY7FVyINxLNHccCoO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gY7FVyINxLNHccCoO = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw", &sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7 = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.begin(); iter != sbt_c0iEcXcrVKAyTMjb2ykNIEtoweun0VOBEPI46B9nWX13T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8WUvK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_8WUvK.begin(); iter != sbt_8WUvK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.begin(); iter != sbt_EqFPN6PJ2ya1Qipwp6a6fSv5Z8mkURwanyYOYww2wBs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n", (CX::Int64)sbt__nHCGYF6QZrl0QFLznQPkhcaB4jqbQ76n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2", (CX::Int64)sbt_UqWg7FsgYisbmRzUkTmMjOE9ywgVC5qDNr2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.begin(); iter != sbt_n1LV4otJeLqeml8vrwUUyhx5smBMY56n6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QuzaAOu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_QuzaAOu.begin(); iter != sbt_QuzaAOu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.begin(); iter != sbt_7COq6LeFtPOXzJHMdETLj3ICbdClazx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gY7FVyINxLNHccCoO", (CX::Int64)sbt_gY7FVyINxLNHccCoO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.begin(); iter != sbt_ksDO6AEzsfElcFcTM0zAX0LGxE8KHvWU93IAnYDEMgBu4wD7IBBddY5yxQh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw", sbt_Jz2Vrrg4dbtyFvp9zIHflrhUWj7jsq4EEKY2TZA17rrWRh2pzWGcw.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B", (CX::Int64)sbt__H4tvW1lvo9q0GCqtjPPX79nZFDaQwjlkg55B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7", (CX::Int64)sbt_Prj0JoFMqDIcZGypHjWAH5VzgXE9xF7)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_HNAQoVIBEDIwlsBdK>::Type sbt_HNAQoVIBEDIwlsBdKArray;

