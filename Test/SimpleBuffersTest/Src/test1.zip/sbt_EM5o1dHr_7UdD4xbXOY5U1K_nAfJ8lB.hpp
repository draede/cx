
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy.hpp"


class sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W;
	CX::IO::SimpleBuffers::UInt64Array sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR;
	CX::IO::SimpleBuffers::StringArray sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI;
	CX::IO::SimpleBuffers::UInt8Array sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY;
	CX::Int32 sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm;
	CX::IO::SimpleBuffers::UInt16Array sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk;
	CX::IO::SimpleBuffers::DoubleArray sbt_Y123_4aus46qVfB7xs87nsqWVkdYS;
	CX::WString sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB;
	CX::IO::SimpleBuffers::BoolArray sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl;
	CX::IO::SimpleBuffers::BoolArray sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa;
	CX::Bool sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq;
	CX::String sbt_OAApR9HQGEH;
	CX::UInt32 sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5;
	CX::IO::SimpleBuffers::UInt8Array sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt;
	CX::Int16 sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW;
	CX::UInt32 sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL;
	CX::Int32 sbt_8hcdODiPGxuuc88g3yn63ifja;
	CX::UInt32 sbt_K1pX_;
	sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG;

	virtual void Reset()
	{
		sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W = false;
		sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.clear();
		sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.clear();
		sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.clear();
		sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm = 0;
		sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.clear();
		sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.clear();
		sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB.clear();
		sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.clear();
		sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.clear();
		sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq = false;
		sbt_OAApR9HQGEH.clear();
		sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5 = 0;
		sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.clear();
		sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW = 0;
		sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL = 0;
		sbt_8hcdODiPGxuuc88g3yn63ifja = 0;
		sbt_K1pX_ = 0;
		sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W = false;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.push_back(4388583054351594512);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.push_back("dP{O>^iX5nPwO-=O!]52%i_P!UG'i'%3]K7#)~<)<MpPa");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.push_back(39);
		}
		sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm = 596803994;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.push_back(57075);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.push_back(0.990629);
		}
		sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB = L"vrv$6%`}tsI?.g&%8Vr0>-3,*eE\",'nI[tL'b:5etfk!hgc&WNnQk'6rLa3{G3v";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.push_back(false);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.push_back(true);
		}
		sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq = false;
		sbt_OAApR9HQGEH = "w~34pa5~TysZA'96TR:#N{H-G_j4Ib)TUI=aY";
		sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5 = 1098288604;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.push_back(57);
		}
		sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW = -1675;
		sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL = 1651463770;
		sbt_8hcdODiPGxuuc88g3yn63ifja = 247623996;
		sbt_K1pX_ = 3372414223;
		sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB *pObject = dynamic_cast<const sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W != pObject->sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W)
		{
			return false;
		}
		if (sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.size() != pObject->sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.size(); i++)
		{
			if (sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR[i] != pObject->sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR[i])
			{
				return false;
			}
		}
		if (sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.size() != pObject->sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI[i].c_str(), pObject->sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.size() != pObject->sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.size(); i++)
		{
			if (sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY[i] != pObject->sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY[i])
			{
				return false;
			}
		}
		if (sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm != pObject->sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm)
		{
			return false;
		}
		if (sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.size() != pObject->sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.size(); i++)
		{
			if (sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk[i] != pObject->sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk[i])
			{
				return false;
			}
		}
		if (sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.size() != pObject->sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.size(); i++)
		{
			if (sbt_Y123_4aus46qVfB7xs87nsqWVkdYS[i] != pObject->sbt_Y123_4aus46qVfB7xs87nsqWVkdYS[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB.c_str(), pObject->sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB.c_str()))
		{
			return false;
		}
		if (sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.size() != pObject->sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.size(); i++)
		{
			if (sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl[i] != pObject->sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl[i])
			{
				return false;
			}
		}
		if (sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.size() != pObject->sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.size(); i++)
		{
			if (sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa[i] != pObject->sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa[i])
			{
				return false;
			}
		}
		if (sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq != pObject->sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_OAApR9HQGEH.c_str(), pObject->sbt_OAApR9HQGEH.c_str()))
		{
			return false;
		}
		if (sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5 != pObject->sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5)
		{
			return false;
		}
		if (sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.size() != pObject->sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.size(); i++)
		{
			if (sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt[i] != pObject->sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt[i])
			{
				return false;
			}
		}
		if (sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW != pObject->sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW)
		{
			return false;
		}
		if (sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL != pObject->sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL)
		{
			return false;
		}
		if (sbt_8hcdODiPGxuuc88g3yn63ifja != pObject->sbt_8hcdODiPGxuuc88g3yn63ifja)
		{
			return false;
		}
		if (sbt_K1pX_ != pObject->sbt_K1pX_)
		{
			return false;
		}
		if (!sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG.Compare(&pObject->sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W", &sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Y123_4aus46qVfB7xs87nsqWVkdYS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB", &sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq", &sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_OAApR9HQGEH", &sbt_OAApR9HQGEH)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8hcdODiPGxuuc88g3yn63ifja", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8hcdODiPGxuuc88g3yn63ifja = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_K1pX_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_K1pX_ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W", sbt_oqeBzRo0LI4UAc3S1c8fYpqHKusdnKgqAycopA07W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.begin(); iter != sbt_JRUsSqKanBqBZX2j8K7aA0GCOoy_VJYriQLieNR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.begin(); iter != sbt_aVQjZ4_lhFDHon32jC1coHbHrW5ChWSYGtfAs5PsERAfQiKns5hkKUI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.begin(); iter != sbt_TjwKZx9dA5LNrOwt8Bj1ELv43jfI0JspGXxh0vY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm", (CX::Int64)sbt_AVEi2cYXtgIWkv9a7osNhE9hx2wB8aLFTnvzm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.begin(); iter != sbt_mHGrvNg0ZxQZnn5xHLrUgLshTHJNdXuqoPSau14kBPpvphDwk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y123_4aus46qVfB7xs87nsqWVkdYS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.begin(); iter != sbt_Y123_4aus46qVfB7xs87nsqWVkdYS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB", sbt_oZbLgTDOL4hpHpGF2aPBCCN73m379AB.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.begin(); iter != sbt_XxuHu7Z8spO_qA3aQYbdaF9BY01pRb2Cd8n4LHg2JLSIukl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.begin(); iter != sbt_kKcD6aNz4R4SFI8pEl06CKam_iowK_hBf6wkn9Vv7kb5zncoAdHVMKa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq", sbt_dJ8LjHnmkTrdkF8raTj94IYqCQ96obetNhRRtUYbT6zlRpZcq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_OAApR9HQGEH", sbt_OAApR9HQGEH.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5", (CX::Int64)sbt_j0O5QbNfUVpEhn_Rj8rHnr6kQnBdwqCgCTUivqDjzoByZmakUW7LtXorxNDSms5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.begin(); iter != sbt_xxTz6qBsB3lFCYLXRtQ4q2mQlPfAoVKBt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW", (CX::Int64)sbt_u1L81zm4wcaT4RVImvDmf5enaq_wkjcWRu6frEhA1kpqTXKaW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL", (CX::Int64)sbt_oGNQ7h9KPThhEFrTcLUzA8s7MpI0Z4t6qaKwNL6T6ynCiEYy7KL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8hcdODiPGxuuc88g3yn63ifja", (CX::Int64)sbt_8hcdODiPGxuuc88g3yn63ifja)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_K1pX_", (CX::Int64)sbt_K1pX_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_C6mHhk8KUNkVe8PqoSUL5srxs2rRX_z5KiH8SzFCGMToqN4wk86cG.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB>::Type sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lBArray;

