
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA.hpp"


class sbt_8Hp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1;
	CX::IO::SimpleBuffers::BoolArray sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp;
	CX::Bool sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX;
	CX::UInt16 sbt_0anxLAD;
	CX::UInt64 sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL;
	CX::Float sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC;
	CX::Double sbt_jBcFRiJ8f42ZW9gzh;
	CX::WString sbt_t35xled;
	CX::IO::SimpleBuffers::Int16Array sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd;
	CX::Bool sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs;
	CX::Float sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ;
	CX::Int16 sbt_eU17iXqd4IToGUxRrsz6NaN;
	CX::UInt16 sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH;
	CX::Int32 sbt_mq_Z3f2;
	CX::UInt16 sbt_EDvYXYr67RsOphD;
	CX::IO::SimpleBuffers::Int8Array sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ;
	CX::IO::SimpleBuffers::Int32Array sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB;
	sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA sbt_lhUr2hepB;

	virtual void Reset()
	{
		sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1 = 0;
		sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.clear();
		sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX = false;
		sbt_0anxLAD = 0;
		sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL = 0;
		sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC = 0.0f;
		sbt_jBcFRiJ8f42ZW9gzh = 0.0;
		sbt_t35xled.clear();
		sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.clear();
		sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs = false;
		sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ = 0.0f;
		sbt_eU17iXqd4IToGUxRrsz6NaN = 0;
		sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH = 0;
		sbt_mq_Z3f2 = 0;
		sbt_EDvYXYr67RsOphD = 0;
		sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.clear();
		sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.clear();
		sbt_lhUr2hepB.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1 = -169219427247065388;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.push_back(false);
		}
		sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX = true;
		sbt_0anxLAD = 15984;
		sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL = 14245021301337029680;
		sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC = 0.074191f;
		sbt_jBcFRiJ8f42ZW9gzh = 0.088403;
		sbt_t35xled = L"{>,~";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.push_back(7539);
		}
		sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs = false;
		sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ = 0.034473f;
		sbt_eU17iXqd4IToGUxRrsz6NaN = -5360;
		sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH = 56949;
		sbt_mq_Z3f2 = 1838227529;
		sbt_EDvYXYr67RsOphD = 64622;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.push_back(-23);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.push_back(-392717039);
		}
		sbt_lhUr2hepB.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8Hp *pObject = dynamic_cast<const sbt_8Hp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1 != pObject->sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1)
		{
			return false;
		}
		if (sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.size() != pObject->sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.size(); i++)
		{
			if (sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp[i] != pObject->sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp[i])
			{
				return false;
			}
		}
		if (sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX != pObject->sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX)
		{
			return false;
		}
		if (sbt_0anxLAD != pObject->sbt_0anxLAD)
		{
			return false;
		}
		if (sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL != pObject->sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL)
		{
			return false;
		}
		if (sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC != pObject->sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC)
		{
			return false;
		}
		if (sbt_jBcFRiJ8f42ZW9gzh != pObject->sbt_jBcFRiJ8f42ZW9gzh)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_t35xled.c_str(), pObject->sbt_t35xled.c_str()))
		{
			return false;
		}
		if (sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.size() != pObject->sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.size(); i++)
		{
			if (sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd[i] != pObject->sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd[i])
			{
				return false;
			}
		}
		if (sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs != pObject->sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs)
		{
			return false;
		}
		if (sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ != pObject->sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ)
		{
			return false;
		}
		if (sbt_eU17iXqd4IToGUxRrsz6NaN != pObject->sbt_eU17iXqd4IToGUxRrsz6NaN)
		{
			return false;
		}
		if (sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH != pObject->sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH)
		{
			return false;
		}
		if (sbt_mq_Z3f2 != pObject->sbt_mq_Z3f2)
		{
			return false;
		}
		if (sbt_EDvYXYr67RsOphD != pObject->sbt_EDvYXYr67RsOphD)
		{
			return false;
		}
		if (sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.size() != pObject->sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.size(); i++)
		{
			if (sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ[i] != pObject->sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ[i])
			{
				return false;
			}
		}
		if (sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.size() != pObject->sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.size(); i++)
		{
			if (sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB[i] != pObject->sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB[i])
			{
				return false;
			}
		}
		if (!sbt_lhUr2hepB.Compare(&pObject->sbt_lhUr2hepB))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX", &sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0anxLAD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0anxLAD = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_jBcFRiJ8f42ZW9gzh", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_jBcFRiJ8f42ZW9gzh = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_t35xled", &sbt_t35xled)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs", &sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_eU17iXqd4IToGUxRrsz6NaN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eU17iXqd4IToGUxRrsz6NaN = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mq_Z3f2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mq_Z3f2 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EDvYXYr67RsOphD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EDvYXYr67RsOphD = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_lhUr2hepB")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_lhUr2hepB.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1", (CX::Int64)sbt_kBeQU_bXZCLrWJN9vlBIV53rmdMwLYs09T1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.begin(); iter != sbt_LD0FZZXHFsQKOm7dEnOXb2_evBp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX", sbt_4QH1GLXJ9LdAc2MkTdYYrkgEd6AX6aX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0anxLAD", (CX::Int64)sbt_0anxLAD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL", (CX::Int64)sbt_WGnIr1R2eSksdZxYuHfiuuKcnlGcliURL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC", (CX::Double)sbt_2LX90Jlh4Kqm3MZNDhAyb1AvorhJ6vK8a0rTC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_jBcFRiJ8f42ZW9gzh", (CX::Double)sbt_jBcFRiJ8f42ZW9gzh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_t35xled", sbt_t35xled.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.begin(); iter != sbt_mg8FQ6wMT6FiqOIcnXXKKhDGd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs", sbt_vQOvXPiCuoRadi1xt8tGjtvbPV29v5Kb6WpxciMYdGeq4aFMPTRIoVN8EZs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ", (CX::Double)sbt_f13p1x7OyneuV5DYSr4cLVvlTzcDcmZW38khQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eU17iXqd4IToGUxRrsz6NaN", (CX::Int64)sbt_eU17iXqd4IToGUxRrsz6NaN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH", (CX::Int64)sbt_q7aBrIagJkUJBAuox_GY1VvbNwlmeMMBhGo7w39krMjH9uulH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mq_Z3f2", (CX::Int64)sbt_mq_Z3f2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EDvYXYr67RsOphD", (CX::Int64)sbt_EDvYXYr67RsOphD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.begin(); iter != sbt_AyO014ogV0FBBpMXrDTcZXIX9IQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.begin(); iter != sbt_GWBxZq9reWpCFM9_R2rqPKh8msa9kyDW21_4B46yB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_lhUr2hepB")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_lhUr2hepB.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8Hp>::Type sbt_8HpArray;

