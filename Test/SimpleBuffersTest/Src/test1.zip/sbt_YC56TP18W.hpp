
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6.hpp"


class sbt_YC56TP18W : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_4ASqWmWcTtpbUWS;
	CX::IO::SimpleBuffers::UInt32Array sbt_erb;
	CX::IO::SimpleBuffers::FloatArray sbt_Stnra6CKKRtab;
	CX::Int32 sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz;
	CX::UInt32 sbt_Dn7SXijKL;
	CX::Int64 sbt_DdVwg;
	CX::IO::SimpleBuffers::DoubleArray sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR;
	CX::UInt64 sbt_pxR;
	CX::Int16 sbt_dW9_Q;
	CX::IO::SimpleBuffers::DoubleArray sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060;
	CX::UInt8 sbt_iesRY43;
	CX::WString sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o;
	CX::IO::SimpleBuffers::Int64Array sbt_4oU2sJjiImHgUB2ZVclwi;
	CX::IO::SimpleBuffers::UInt16Array sbt_s7y8vA5y325lSam;
	CX::String sbt_M59dJUp15TSY8NjVncKqjjB;
	CX::String sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207;
	CX::Int8 sbt_S;
	CX::IO::SimpleBuffers::Int32Array sbt_j4Fmohx2JkA;
	CX::Float sbt_sUoUB4N;
	CX::Int16 sbt_AGJX6;
	CX::WString sbt_gUGKjlgio;
	CX::Int64 sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK;
	CX::IO::SimpleBuffers::Int64Array sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH;
	sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8;

	virtual void Reset()
	{
		sbt_4ASqWmWcTtpbUWS.clear();
		sbt_erb.clear();
		sbt_Stnra6CKKRtab.clear();
		sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz = 0;
		sbt_Dn7SXijKL = 0;
		sbt_DdVwg = 0;
		sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.clear();
		sbt_pxR = 0;
		sbt_dW9_Q = 0;
		sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.clear();
		sbt_iesRY43 = 0;
		sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o.clear();
		sbt_4oU2sJjiImHgUB2ZVclwi.clear();
		sbt_s7y8vA5y325lSam.clear();
		sbt_M59dJUp15TSY8NjVncKqjjB.clear();
		sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207.clear();
		sbt_S = 0;
		sbt_j4Fmohx2JkA.clear();
		sbt_sUoUB4N = 0.0f;
		sbt_AGJX6 = 0;
		sbt_gUGKjlgio.clear();
		sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK = 0;
		sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.clear();
		sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_4ASqWmWcTtpbUWS = "81S)'#m`Z)gmdv";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_erb.push_back(3465263103);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Stnra6CKKRtab.push_back(0.957378f);
		}
		sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz = 423855966;
		sbt_Dn7SXijKL = 63716644;
		sbt_DdVwg = -1021864604012726882;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.push_back(0.272494);
		}
		sbt_pxR = 4930243075281373098;
		sbt_dW9_Q = -3447;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.push_back(0.363621);
		}
		sbt_iesRY43 = 245;
		sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o = L"OQ*2Ie^F'zaXTeAZcX@@q35gxKI`}M<=;b(Ig";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_4oU2sJjiImHgUB2ZVclwi.push_back(-585092446590050828);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_s7y8vA5y325lSam.push_back(51372);
		}
		sbt_M59dJUp15TSY8NjVncKqjjB = "C)E%SXiCS5Jk3!";
		sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207 = "k|NXUOjlQPta5";
		sbt_S = 48;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_j4Fmohx2JkA.push_back(1913289290);
		}
		sbt_sUoUB4N = 0.329731f;
		sbt_AGJX6 = -23164;
		sbt_gUGKjlgio = L"h9?Z1'e(sF>*20Q_%kC`;W~[O=N@'Ups6Rv/n@`2.C\":blL(Q7MlK4Vw5?A";
		sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK = 4518715290880426900;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.push_back(-6627842460281132986);
		}
		sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_YC56TP18W *pObject = dynamic_cast<const sbt_YC56TP18W *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_4ASqWmWcTtpbUWS.c_str(), pObject->sbt_4ASqWmWcTtpbUWS.c_str()))
		{
			return false;
		}
		if (sbt_erb.size() != pObject->sbt_erb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_erb.size(); i++)
		{
			if (sbt_erb[i] != pObject->sbt_erb[i])
			{
				return false;
			}
		}
		if (sbt_Stnra6CKKRtab.size() != pObject->sbt_Stnra6CKKRtab.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Stnra6CKKRtab.size(); i++)
		{
			if (sbt_Stnra6CKKRtab[i] != pObject->sbt_Stnra6CKKRtab[i])
			{
				return false;
			}
		}
		if (sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz != pObject->sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz)
		{
			return false;
		}
		if (sbt_Dn7SXijKL != pObject->sbt_Dn7SXijKL)
		{
			return false;
		}
		if (sbt_DdVwg != pObject->sbt_DdVwg)
		{
			return false;
		}
		if (sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.size() != pObject->sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.size(); i++)
		{
			if (sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR[i] != pObject->sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR[i])
			{
				return false;
			}
		}
		if (sbt_pxR != pObject->sbt_pxR)
		{
			return false;
		}
		if (sbt_dW9_Q != pObject->sbt_dW9_Q)
		{
			return false;
		}
		if (sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.size() != pObject->sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.size(); i++)
		{
			if (sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060[i] != pObject->sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060[i])
			{
				return false;
			}
		}
		if (sbt_iesRY43 != pObject->sbt_iesRY43)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o.c_str(), pObject->sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o.c_str()))
		{
			return false;
		}
		if (sbt_4oU2sJjiImHgUB2ZVclwi.size() != pObject->sbt_4oU2sJjiImHgUB2ZVclwi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4oU2sJjiImHgUB2ZVclwi.size(); i++)
		{
			if (sbt_4oU2sJjiImHgUB2ZVclwi[i] != pObject->sbt_4oU2sJjiImHgUB2ZVclwi[i])
			{
				return false;
			}
		}
		if (sbt_s7y8vA5y325lSam.size() != pObject->sbt_s7y8vA5y325lSam.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s7y8vA5y325lSam.size(); i++)
		{
			if (sbt_s7y8vA5y325lSam[i] != pObject->sbt_s7y8vA5y325lSam[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_M59dJUp15TSY8NjVncKqjjB.c_str(), pObject->sbt_M59dJUp15TSY8NjVncKqjjB.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207.c_str(), pObject->sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207.c_str()))
		{
			return false;
		}
		if (sbt_S != pObject->sbt_S)
		{
			return false;
		}
		if (sbt_j4Fmohx2JkA.size() != pObject->sbt_j4Fmohx2JkA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j4Fmohx2JkA.size(); i++)
		{
			if (sbt_j4Fmohx2JkA[i] != pObject->sbt_j4Fmohx2JkA[i])
			{
				return false;
			}
		}
		if (sbt_sUoUB4N != pObject->sbt_sUoUB4N)
		{
			return false;
		}
		if (sbt_AGJX6 != pObject->sbt_AGJX6)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_gUGKjlgio.c_str(), pObject->sbt_gUGKjlgio.c_str()))
		{
			return false;
		}
		if (sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK != pObject->sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK)
		{
			return false;
		}
		if (sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.size() != pObject->sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.size(); i++)
		{
			if (sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH[i] != pObject->sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH[i])
			{
				return false;
			}
		}
		if (!sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8.Compare(&pObject->sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_4ASqWmWcTtpbUWS", &sbt_4ASqWmWcTtpbUWS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_erb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_erb.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Stnra6CKKRtab")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Stnra6CKKRtab.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Dn7SXijKL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Dn7SXijKL = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DdVwg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DdVwg = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pxR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pxR = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dW9_Q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dW9_Q = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iesRY43", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iesRY43 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o", &sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4oU2sJjiImHgUB2ZVclwi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4oU2sJjiImHgUB2ZVclwi.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s7y8vA5y325lSam")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s7y8vA5y325lSam.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_M59dJUp15TSY8NjVncKqjjB", &sbt_M59dJUp15TSY8NjVncKqjjB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207", &sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_j4Fmohx2JkA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j4Fmohx2JkA.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_sUoUB4N", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_sUoUB4N = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_AGJX6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AGJX6 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_gUGKjlgio", &sbt_gUGKjlgio)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_4ASqWmWcTtpbUWS", sbt_4ASqWmWcTtpbUWS.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_erb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_erb.begin(); iter != sbt_erb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Stnra6CKKRtab")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Stnra6CKKRtab.begin(); iter != sbt_Stnra6CKKRtab.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz", (CX::Int64)sbt_smKkFn0495_sBpmVbvABfuxq_QboSXANjbCzz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Dn7SXijKL", (CX::Int64)sbt_Dn7SXijKL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DdVwg", (CX::Int64)sbt_DdVwg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.begin(); iter != sbt_uKgmgbCbwHCachOFc8QXIcBVVzMmfMfCR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pxR", (CX::Int64)sbt_pxR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dW9_Q", (CX::Int64)sbt_dW9_Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.begin(); iter != sbt_36gtSRBrQ8MyeAQsleIpzMONN14g060.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iesRY43", (CX::Int64)sbt_iesRY43)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o", sbt_xkWuLrbcYCeO4i3o54pBTO56qvGENZnXyS4VUkORtFluPZ7Qz3o.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4oU2sJjiImHgUB2ZVclwi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_4oU2sJjiImHgUB2ZVclwi.begin(); iter != sbt_4oU2sJjiImHgUB2ZVclwi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s7y8vA5y325lSam")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_s7y8vA5y325lSam.begin(); iter != sbt_s7y8vA5y325lSam.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_M59dJUp15TSY8NjVncKqjjB", sbt_M59dJUp15TSY8NjVncKqjjB.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207", sbt_DdlAe9tQiQ5lC69nn7vmVRALNnex2pclmu4Wv0arLX207.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S", (CX::Int64)sbt_S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j4Fmohx2JkA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_j4Fmohx2JkA.begin(); iter != sbt_j4Fmohx2JkA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_sUoUB4N", (CX::Double)sbt_sUoUB4N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AGJX6", (CX::Int64)sbt_AGJX6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_gUGKjlgio", sbt_gUGKjlgio.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK", (CX::Int64)sbt_bMM2TliXvZyT0joH_Yh3ww0KO6AuM6IFJORjHVru4qK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.begin(); iter != sbt_0mS63iU4WhMnK5Gti91ti_BEIGUqm2793uN61iH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_fo8LzY5wJtehEJT1vganiHFuthbqJIGXS8EJtqolThmSogxB8.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_YC56TP18W>::Type sbt_YC56TP18WArray;

