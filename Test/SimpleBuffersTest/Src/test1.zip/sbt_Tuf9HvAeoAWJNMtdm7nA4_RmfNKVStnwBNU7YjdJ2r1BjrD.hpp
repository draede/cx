
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_z7V7j2R83fWj7sZN7YRoI.hpp"


class sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM;
	CX::IO::SimpleBuffers::UInt8Array sbt_hdvd6QtvyHa0bvDfl;
	CX::Float sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9;
	CX::IO::SimpleBuffers::BoolArray sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f;
	CX::Bool sbt_fK4KR;
	CX::UInt16 sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y;
	sbt_z7V7j2R83fWj7sZN7YRoI sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS;

	virtual void Reset()
	{
		sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.clear();
		sbt_hdvd6QtvyHa0bvDfl.clear();
		sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9 = 0.0f;
		sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.clear();
		sbt_fK4KR = false;
		sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y = 0;
		sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.push_back(-1119694536132046894);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_hdvd6QtvyHa0bvDfl.push_back(28);
		}
		sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9 = 0.827645f;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.push_back(false);
		}
		sbt_fK4KR = false;
		sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y = 44278;
		sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD *pObject = dynamic_cast<const sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.size() != pObject->sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.size(); i++)
		{
			if (sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM[i] != pObject->sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM[i])
			{
				return false;
			}
		}
		if (sbt_hdvd6QtvyHa0bvDfl.size() != pObject->sbt_hdvd6QtvyHa0bvDfl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hdvd6QtvyHa0bvDfl.size(); i++)
		{
			if (sbt_hdvd6QtvyHa0bvDfl[i] != pObject->sbt_hdvd6QtvyHa0bvDfl[i])
			{
				return false;
			}
		}
		if (sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9 != pObject->sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9)
		{
			return false;
		}
		if (sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.size() != pObject->sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.size(); i++)
		{
			if (sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f[i] != pObject->sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f[i])
			{
				return false;
			}
		}
		if (sbt_fK4KR != pObject->sbt_fK4KR)
		{
			return false;
		}
		if (sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y != pObject->sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y)
		{
			return false;
		}
		if (!sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS.Compare(&pObject->sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hdvd6QtvyHa0bvDfl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hdvd6QtvyHa0bvDfl.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_fK4KR", &sbt_fK4KR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.begin(); iter != sbt_nK2WmLmAGc5ueETcPiQ3bD15P2IbiOLUEalZM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hdvd6QtvyHa0bvDfl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_hdvd6QtvyHa0bvDfl.begin(); iter != sbt_hdvd6QtvyHa0bvDfl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9", (CX::Double)sbt_tkvNOrKJfmwyXhihC4_XUVC80C_1KZ4wqd7H8vdZyAYWpG9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.begin(); iter != sbt_PC7oPoySgyXvw4X9sTjXvSaTBkeWKqShmNp0o030f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_fK4KR", sbt_fK4KR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y", (CX::Int64)sbt_tQSR1r5TDyvkGhh3RnDZnnik9jGuIU3JiI7K5lC8cFKq_ptoknniZRPa72y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_KpW0FBXe0x80ZeiEC4Sm9PyI7UKf16grXNsyS.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD>::Type sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrDArray;

