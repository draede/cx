
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_hl6ou.hpp"


class sbt_jJLkD5_dC2e60AtetoWG4Vg : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_JjFjA;
	CX::IO::SimpleBuffers::StringArray sbt_7lwxGgLML;
	CX::IO::SimpleBuffers::UInt8Array sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx;
	CX::IO::SimpleBuffers::Int16Array sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV;
	CX::Int16 sbt_GYjP6;
	CX::IO::SimpleBuffers::Int64Array sbt_0sYKEQbw96JJtiI;
	CX::IO::SimpleBuffers::Int64Array sbt_YJ9QmR2IrWdYh41GLFlirbpREtz;
	CX::IO::SimpleBuffers::BoolArray sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt;
	CX::IO::SimpleBuffers::Int8Array sbt_71dgh0m369d1mE_V8xmyN;
	CX::IO::SimpleBuffers::UInt8Array sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn;
	CX::IO::SimpleBuffers::UInt16Array sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z;
	CX::Int64 sbt_henG7lPrq;
	CX::IO::SimpleBuffers::StringArray sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv;
	CX::UInt32 sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj;
	CX::Double sbt_MBmvrkUF6_1YqKkhdLuid7K;
	CX::IO::SimpleBuffers::FloatArray sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb;
	CX::IO::SimpleBuffers::UInt16Array sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7;
	CX::IO::SimpleBuffers::Int64Array sbt_I5gYXfXL3iBtV;
	CX::UInt16 sbt_sLu9tFoy1;
	CX::UInt64 sbt_SoEYw;
	CX::IO::SimpleBuffers::UInt32Array sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC;
	CX::IO::SimpleBuffers::Int8Array sbt_JMc7oHe7U02bVPemPdWhnb3UFZk;
	CX::IO::SimpleBuffers::DoubleArray sbt_hywpmvfcUYQRaAAU7;
	CX::IO::SimpleBuffers::UInt64Array sbt_V;
	CX::IO::SimpleBuffers::UInt64Array sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI;
	CX::UInt64 sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK;
	CX::UInt16 sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm;
	CX::Float sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw;
	sbt_hl6ou sbt_Cq7KNDs;

	virtual void Reset()
	{
		sbt_JjFjA.clear();
		sbt_7lwxGgLML.clear();
		sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.clear();
		sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.clear();
		sbt_GYjP6 = 0;
		sbt_0sYKEQbw96JJtiI.clear();
		sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.clear();
		sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.clear();
		sbt_71dgh0m369d1mE_V8xmyN.clear();
		sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.clear();
		sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.clear();
		sbt_henG7lPrq = 0;
		sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.clear();
		sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj = 0;
		sbt_MBmvrkUF6_1YqKkhdLuid7K = 0.0;
		sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.clear();
		sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.clear();
		sbt_I5gYXfXL3iBtV.clear();
		sbt_sLu9tFoy1 = 0;
		sbt_SoEYw = 0;
		sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.clear();
		sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.clear();
		sbt_hywpmvfcUYQRaAAU7.clear();
		sbt_V.clear();
		sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.clear();
		sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK = 0;
		sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm = 0;
		sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw = 0.0f;
		sbt_Cq7KNDs.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JjFjA.push_back(-19);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_7lwxGgLML.push_back("Sx@u`B+kJ=TW(x8?24=r");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.push_back(-23259);
		}
		sbt_GYjP6 = 7595;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_0sYKEQbw96JJtiI.push_back(2365712300129150490);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.push_back(3374093497339222944);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.push_back(true);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_71dgh0m369d1mE_V8xmyN.push_back(101);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.push_back(190);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.push_back(29922);
		}
		sbt_henG7lPrq = -7333782211061928282;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.push_back("WyvCa$g*&,");
		}
		sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj = 3697861528;
		sbt_MBmvrkUF6_1YqKkhdLuid7K = 0.807303;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.push_back(0.518768f);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.push_back(12096);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_I5gYXfXL3iBtV.push_back(9031857403080057972);
		}
		sbt_sLu9tFoy1 = 59011;
		sbt_SoEYw = 1159989772898165640;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.push_back(1002286280);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.push_back(-104);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_hywpmvfcUYQRaAAU7.push_back(0.110471);
		}
		sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK = 2475672738535504454;
		sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm = 35415;
		sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw = 0.940456f;
		sbt_Cq7KNDs.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_jJLkD5_dC2e60AtetoWG4Vg *pObject = dynamic_cast<const sbt_jJLkD5_dC2e60AtetoWG4Vg *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_JjFjA.size() != pObject->sbt_JjFjA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JjFjA.size(); i++)
		{
			if (sbt_JjFjA[i] != pObject->sbt_JjFjA[i])
			{
				return false;
			}
		}
		if (sbt_7lwxGgLML.size() != pObject->sbt_7lwxGgLML.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7lwxGgLML.size(); i++)
		{
			if (0 != cx_strcmp(sbt_7lwxGgLML[i].c_str(), pObject->sbt_7lwxGgLML[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.size() != pObject->sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.size(); i++)
		{
			if (sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx[i] != pObject->sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx[i])
			{
				return false;
			}
		}
		if (sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.size() != pObject->sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.size(); i++)
		{
			if (sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV[i] != pObject->sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV[i])
			{
				return false;
			}
		}
		if (sbt_GYjP6 != pObject->sbt_GYjP6)
		{
			return false;
		}
		if (sbt_0sYKEQbw96JJtiI.size() != pObject->sbt_0sYKEQbw96JJtiI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0sYKEQbw96JJtiI.size(); i++)
		{
			if (sbt_0sYKEQbw96JJtiI[i] != pObject->sbt_0sYKEQbw96JJtiI[i])
			{
				return false;
			}
		}
		if (sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.size() != pObject->sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.size(); i++)
		{
			if (sbt_YJ9QmR2IrWdYh41GLFlirbpREtz[i] != pObject->sbt_YJ9QmR2IrWdYh41GLFlirbpREtz[i])
			{
				return false;
			}
		}
		if (sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.size() != pObject->sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.size(); i++)
		{
			if (sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt[i] != pObject->sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt[i])
			{
				return false;
			}
		}
		if (sbt_71dgh0m369d1mE_V8xmyN.size() != pObject->sbt_71dgh0m369d1mE_V8xmyN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_71dgh0m369d1mE_V8xmyN.size(); i++)
		{
			if (sbt_71dgh0m369d1mE_V8xmyN[i] != pObject->sbt_71dgh0m369d1mE_V8xmyN[i])
			{
				return false;
			}
		}
		if (sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.size() != pObject->sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.size(); i++)
		{
			if (sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn[i] != pObject->sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn[i])
			{
				return false;
			}
		}
		if (sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.size() != pObject->sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.size(); i++)
		{
			if (sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z[i] != pObject->sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z[i])
			{
				return false;
			}
		}
		if (sbt_henG7lPrq != pObject->sbt_henG7lPrq)
		{
			return false;
		}
		if (sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.size() != pObject->sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.size(); i++)
		{
			if (0 != cx_strcmp(sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv[i].c_str(), pObject->sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj != pObject->sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj)
		{
			return false;
		}
		if (sbt_MBmvrkUF6_1YqKkhdLuid7K != pObject->sbt_MBmvrkUF6_1YqKkhdLuid7K)
		{
			return false;
		}
		if (sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.size() != pObject->sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.size(); i++)
		{
			if (sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb[i] != pObject->sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb[i])
			{
				return false;
			}
		}
		if (sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.size() != pObject->sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.size(); i++)
		{
			if (sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7[i] != pObject->sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7[i])
			{
				return false;
			}
		}
		if (sbt_I5gYXfXL3iBtV.size() != pObject->sbt_I5gYXfXL3iBtV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I5gYXfXL3iBtV.size(); i++)
		{
			if (sbt_I5gYXfXL3iBtV[i] != pObject->sbt_I5gYXfXL3iBtV[i])
			{
				return false;
			}
		}
		if (sbt_sLu9tFoy1 != pObject->sbt_sLu9tFoy1)
		{
			return false;
		}
		if (sbt_SoEYw != pObject->sbt_SoEYw)
		{
			return false;
		}
		if (sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.size() != pObject->sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.size(); i++)
		{
			if (sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC[i] != pObject->sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC[i])
			{
				return false;
			}
		}
		if (sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.size() != pObject->sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.size(); i++)
		{
			if (sbt_JMc7oHe7U02bVPemPdWhnb3UFZk[i] != pObject->sbt_JMc7oHe7U02bVPemPdWhnb3UFZk[i])
			{
				return false;
			}
		}
		if (sbt_hywpmvfcUYQRaAAU7.size() != pObject->sbt_hywpmvfcUYQRaAAU7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hywpmvfcUYQRaAAU7.size(); i++)
		{
			if (sbt_hywpmvfcUYQRaAAU7[i] != pObject->sbt_hywpmvfcUYQRaAAU7[i])
			{
				return false;
			}
		}
		if (sbt_V.size() != pObject->sbt_V.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_V.size(); i++)
		{
			if (sbt_V[i] != pObject->sbt_V[i])
			{
				return false;
			}
		}
		if (sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.size() != pObject->sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.size(); i++)
		{
			if (sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI[i] != pObject->sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI[i])
			{
				return false;
			}
		}
		if (sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK != pObject->sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK)
		{
			return false;
		}
		if (sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm != pObject->sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm)
		{
			return false;
		}
		if (sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw != pObject->sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw)
		{
			return false;
		}
		if (!sbt_Cq7KNDs.Compare(&pObject->sbt_Cq7KNDs))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_JjFjA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JjFjA.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7lwxGgLML")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7lwxGgLML.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GYjP6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GYjP6 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0sYKEQbw96JJtiI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0sYKEQbw96JJtiI.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YJ9QmR2IrWdYh41GLFlirbpREtz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_71dgh0m369d1mE_V8xmyN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_71dgh0m369d1mE_V8xmyN.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_henG7lPrq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_henG7lPrq = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_MBmvrkUF6_1YqKkhdLuid7K", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_MBmvrkUF6_1YqKkhdLuid7K = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I5gYXfXL3iBtV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I5gYXfXL3iBtV.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sLu9tFoy1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sLu9tFoy1 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SoEYw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SoEYw = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JMc7oHe7U02bVPemPdWhnb3UFZk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hywpmvfcUYQRaAAU7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hywpmvfcUYQRaAAU7.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_V")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_V.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectObject("sbt_Cq7KNDs")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Cq7KNDs.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_JjFjA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_JjFjA.begin(); iter != sbt_JjFjA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7lwxGgLML")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_7lwxGgLML.begin(); iter != sbt_7lwxGgLML.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.begin(); iter != sbt_J1gg_LlIhx8yTc76WHLyHZSRM0cYVfZW8sZNDvx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.begin(); iter != sbt_tqGZ_fQjysJ4Cw4HBwCiL3gRrhaBJFrKcNdc87qeb26BABXcV_9l4KkyV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GYjP6", (CX::Int64)sbt_GYjP6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0sYKEQbw96JJtiI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_0sYKEQbw96JJtiI.begin(); iter != sbt_0sYKEQbw96JJtiI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YJ9QmR2IrWdYh41GLFlirbpREtz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.begin(); iter != sbt_YJ9QmR2IrWdYh41GLFlirbpREtz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.begin(); iter != sbt_8WwWMNwvFXHWOJ_rTpkwMlD20Ai2U_ASSDPWXwxJuynHnUWzAw7lt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_71dgh0m369d1mE_V8xmyN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_71dgh0m369d1mE_V8xmyN.begin(); iter != sbt_71dgh0m369d1mE_V8xmyN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.begin(); iter != sbt_IJChWk6tnF8NHwxGBhGSxJHQ9aD93kIPn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.begin(); iter != sbt_neGTWji8JKqx6khQozIBital3cq1bVwPsK7HTYsFNyzE2qjebebuK5Q8o3z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_henG7lPrq", (CX::Int64)sbt_henG7lPrq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.begin(); iter != sbt_5t5Ja93CPDygnPsMCB0AjfAuWCX0HBKKgq0n1rhvudeTRXGo3gxMGWVXmCv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj", (CX::Int64)sbt_jbnTinadY3lLxSdpNuyQPF1Xxaj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_MBmvrkUF6_1YqKkhdLuid7K", (CX::Double)sbt_MBmvrkUF6_1YqKkhdLuid7K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.begin(); iter != sbt_A5fGoPktPXbuMK6QV9N16bHAsVvDb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.begin(); iter != sbt_mcNtiWtNdp88uuX_7_1r4e6ZclkA87Vz7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I5gYXfXL3iBtV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_I5gYXfXL3iBtV.begin(); iter != sbt_I5gYXfXL3iBtV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sLu9tFoy1", (CX::Int64)sbt_sLu9tFoy1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SoEYw", (CX::Int64)sbt_SoEYw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.begin(); iter != sbt_RKj9CWxkgygpG9dpf37AFKKEHTwBLIvyjSC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JMc7oHe7U02bVPemPdWhnb3UFZk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.begin(); iter != sbt_JMc7oHe7U02bVPemPdWhnb3UFZk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hywpmvfcUYQRaAAU7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_hywpmvfcUYQRaAAU7.begin(); iter != sbt_hywpmvfcUYQRaAAU7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_V")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_V.begin(); iter != sbt_V.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.begin(); iter != sbt_9th4cDCwX870OVyE_GGxpzhkKaxZct6f3txplZiivOkOcSI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK", (CX::Int64)sbt_CwbyBuffIlxDMQpTu3Qc7OcUgbMxY1f6Kks_cUrW6wAqK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm", (CX::Int64)sbt_9P4bXbJ6o5DjpHUo9v4VLRQMo8zmtGVkNeLxJdkSVjZR5lTqOElM7Sm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw", (CX::Double)sbt_dh2QqAPv9f2MFulyouF_cJn1zmWh0v_xptK5OasLjacLmOKHw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_Cq7KNDs")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Cq7KNDs.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_jJLkD5_dC2e60AtetoWG4Vg>::Type sbt_jJLkD5_dC2e60AtetoWG4VgArray;

