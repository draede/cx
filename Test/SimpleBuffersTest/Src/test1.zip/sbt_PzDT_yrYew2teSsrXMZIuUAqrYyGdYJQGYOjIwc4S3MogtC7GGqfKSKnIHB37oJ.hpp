
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_EwUR103N00K.hpp"


class sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O;
	CX::Bool sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk;
	CX::IO::SimpleBuffers::UInt8Array sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq;
	CX::IO::SimpleBuffers::UInt16Array sbt_4wRnvjoQ3CQmA2K;
	CX::String sbt_HzK2z_Z1JvS3jz6TmzY;
	CX::Bool sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA;
	sbt_EwUR103N00K sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F;

	virtual void Reset()
	{
		sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O = false;
		sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk = false;
		sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.clear();
		sbt_4wRnvjoQ3CQmA2K.clear();
		sbt_HzK2z_Z1JvS3jz6TmzY.clear();
		sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA = false;
		sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O = true;
		sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.push_back(32);
		}
		sbt_HzK2z_Z1JvS3jz6TmzY = "mNN0.";
		sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA = true;
		sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ *pObject = dynamic_cast<const sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O != pObject->sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O)
		{
			return false;
		}
		if (sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk != pObject->sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk)
		{
			return false;
		}
		if (sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.size() != pObject->sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.size(); i++)
		{
			if (sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq[i] != pObject->sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq[i])
			{
				return false;
			}
		}
		if (sbt_4wRnvjoQ3CQmA2K.size() != pObject->sbt_4wRnvjoQ3CQmA2K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4wRnvjoQ3CQmA2K.size(); i++)
		{
			if (sbt_4wRnvjoQ3CQmA2K[i] != pObject->sbt_4wRnvjoQ3CQmA2K[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_HzK2z_Z1JvS3jz6TmzY.c_str(), pObject->sbt_HzK2z_Z1JvS3jz6TmzY.c_str()))
		{
			return false;
		}
		if (sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA != pObject->sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA)
		{
			return false;
		}
		if (!sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F.Compare(&pObject->sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O", &sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk", &sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4wRnvjoQ3CQmA2K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4wRnvjoQ3CQmA2K.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_HzK2z_Z1JvS3jz6TmzY", &sbt_HzK2z_Z1JvS3jz6TmzY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA", &sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O", sbt_eMVQDcLMsK8SDIpPLbnDwt3_kCn3KPUg0FAWmp1Lk7O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk", sbt_7TCsuEhFMjdSl79dqYIBZTgYo7wCk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.begin(); iter != sbt_fnsLXjtegP9UmR0iCg85txetzprEhUzVq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4wRnvjoQ3CQmA2K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_4wRnvjoQ3CQmA2K.begin(); iter != sbt_4wRnvjoQ3CQmA2K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_HzK2z_Z1JvS3jz6TmzY", sbt_HzK2z_Z1JvS3jz6TmzY.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA", sbt_P_epQvkqzB5qNwu5EpFVNtr4TkLxOXbn7oF0UfA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_xqQQq4lSwoTbiJx5SDphQP7NO6F.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ>::Type sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJArray;

