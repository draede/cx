
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_EwUR103N00K : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_HYPDbEu8ewTTYvh0VEzOzZV;
	CX::Int32 sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC;
	CX::IO::SimpleBuffers::StringArray sbt_BAy;
	CX::UInt8 sbt_pBJ;
	CX::UInt64 sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex;
	CX::UInt64 sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ;
	CX::IO::SimpleBuffers::UInt32Array sbt_p;
	CX::String sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO;
	CX::UInt32 sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH;
	CX::UInt32 sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW;
	CX::UInt64 sbt_5ICHwdq3i_M9Zfm2m;

	virtual void Reset()
	{
		sbt_HYPDbEu8ewTTYvh0VEzOzZV.clear();
		sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC = 0;
		sbt_BAy.clear();
		sbt_pBJ = 0;
		sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex = 0;
		sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ = 0;
		sbt_p.clear();
		sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO.clear();
		sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH = 0;
		sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW = 0;
		sbt_5ICHwdq3i_M9Zfm2m = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_HYPDbEu8ewTTYvh0VEzOzZV.push_back(true);
		}
		sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC = -987129961;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_BAy.push_back("#bdlwPId^ZP0SSPrS4{1+_Fx6{YbZjnKRGAz'_=XyHk']$_?uCO>y\"{D\"T4gF>");
		}
		sbt_pBJ = 189;
		sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex = 2029133975815651592;
		sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ = 17503767453116274086;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_p.push_back(3054871976);
		}
		sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO = "7X3T";
		sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH = 3269692814;
		sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW = 1130699703;
		sbt_5ICHwdq3i_M9Zfm2m = 11486437669461736736;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_EwUR103N00K *pObject = dynamic_cast<const sbt_EwUR103N00K *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_HYPDbEu8ewTTYvh0VEzOzZV.size() != pObject->sbt_HYPDbEu8ewTTYvh0VEzOzZV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HYPDbEu8ewTTYvh0VEzOzZV.size(); i++)
		{
			if (sbt_HYPDbEu8ewTTYvh0VEzOzZV[i] != pObject->sbt_HYPDbEu8ewTTYvh0VEzOzZV[i])
			{
				return false;
			}
		}
		if (sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC != pObject->sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC)
		{
			return false;
		}
		if (sbt_BAy.size() != pObject->sbt_BAy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BAy.size(); i++)
		{
			if (0 != cx_strcmp(sbt_BAy[i].c_str(), pObject->sbt_BAy[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_pBJ != pObject->sbt_pBJ)
		{
			return false;
		}
		if (sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex != pObject->sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex)
		{
			return false;
		}
		if (sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ != pObject->sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ)
		{
			return false;
		}
		if (sbt_p.size() != pObject->sbt_p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p.size(); i++)
		{
			if (sbt_p[i] != pObject->sbt_p[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO.c_str(), pObject->sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO.c_str()))
		{
			return false;
		}
		if (sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH != pObject->sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH)
		{
			return false;
		}
		if (sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW != pObject->sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW)
		{
			return false;
		}
		if (sbt_5ICHwdq3i_M9Zfm2m != pObject->sbt_5ICHwdq3i_M9Zfm2m)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_HYPDbEu8ewTTYvh0VEzOzZV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HYPDbEu8ewTTYvh0VEzOzZV.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BAy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BAy.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pBJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pBJ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO", &sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5ICHwdq3i_M9Zfm2m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5ICHwdq3i_M9Zfm2m = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_HYPDbEu8ewTTYvh0VEzOzZV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_HYPDbEu8ewTTYvh0VEzOzZV.begin(); iter != sbt_HYPDbEu8ewTTYvh0VEzOzZV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC", (CX::Int64)sbt_AgPusVY4W3h3Oq0FC_fCwqo0BosPxWq39qNytAQkDzZa9jcOjGjbC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BAy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_BAy.begin(); iter != sbt_BAy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pBJ", (CX::Int64)sbt_pBJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex", (CX::Int64)sbt_ko2UDrmEm5_QbxC47AxyA94fdPeaZTz49DS1IM5rMVH0VrTpaCNcMex)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ", (CX::Int64)sbt_I8AXTrgt8tcj5yIl0Lrsh8LcbhQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_p.begin(); iter != sbt_p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO", sbt_pxcscf_caKDYPeeFLcIeJafdlKgOTXH4pICNq_8DAzrYPnWxxIDcoDeuzEO.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH", (CX::Int64)sbt_mgVte1Uapk5Yxc1asPIByypdMqCd1QI46EH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW", (CX::Int64)sbt_i_7Y2DUOCgSH0rbu5ANgg4w4p8dc4D6nW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5ICHwdq3i_M9Zfm2m", (CX::Int64)sbt_5ICHwdq3i_M9Zfm2m)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_EwUR103N00K>::Type sbt_EwUR103N00KArray;

