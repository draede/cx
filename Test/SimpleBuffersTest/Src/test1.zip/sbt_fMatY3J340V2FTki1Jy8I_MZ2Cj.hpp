
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke.hpp"


class sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX;
	CX::IO::SimpleBuffers::Int32Array sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M;
	CX::IO::SimpleBuffers::DoubleArray sbt_WusRllV6neo7Buhn1SFdcfA;
	CX::IO::SimpleBuffers::Int32Array sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung;
	CX::IO::SimpleBuffers::UInt8Array sbt_pXe07Ke3Ck5gtORow;
	CX::Float sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0;
	CX::IO::SimpleBuffers::Int8Array sbt_SoswMswPiDGHZrf00BBJOzOgzJx;
	CX::Bool sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO;
	CX::UInt32 sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_;
	CX::Int16 sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR;
	CX::UInt64 sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T;
	CX::UInt32 sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX;
	CX::IO::SimpleBuffers::UInt64Array sbt_a0jhqsHpDiZxA;
	CX::IO::SimpleBuffers::UInt32Array sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO;
	CX::IO::SimpleBuffers::Int8Array sbt_pvt2xaO7EIbX11UjGTwgOFj;
	CX::Double sbt_D9zmobExFsmo5_a;
	sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke sbt_pzv87A1Lf69QATQWKVLuJ;

	virtual void Reset()
	{
		sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.clear();
		sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.clear();
		sbt_WusRllV6neo7Buhn1SFdcfA.clear();
		sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.clear();
		sbt_pXe07Ke3Ck5gtORow.clear();
		sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0 = 0.0f;
		sbt_SoswMswPiDGHZrf00BBJOzOgzJx.clear();
		sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO = false;
		sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_ = 0;
		sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR = 0;
		sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T = 0;
		sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX = 0;
		sbt_a0jhqsHpDiZxA.clear();
		sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.clear();
		sbt_pvt2xaO7EIbX11UjGTwgOFj.clear();
		sbt_D9zmobExFsmo5_a = 0.0;
		sbt_pzv87A1Lf69QATQWKVLuJ.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.push_back(3782430420);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.push_back(-752012183);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_WusRllV6neo7Buhn1SFdcfA.push_back(0.450808);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.push_back(-437582465);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_pXe07Ke3Ck5gtORow.push_back(250);
		}
		sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0 = 0.477096f;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_SoswMswPiDGHZrf00BBJOzOgzJx.push_back(17);
		}
		sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO = false;
		sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_ = 3499101176;
		sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR = -6226;
		sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T = 16564527271390858382;
		sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX = 4141777189;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_a0jhqsHpDiZxA.push_back(13560896965619500406);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.push_back(2790124695);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_pvt2xaO7EIbX11UjGTwgOFj.push_back(58);
		}
		sbt_D9zmobExFsmo5_a = 0.887823;
		sbt_pzv87A1Lf69QATQWKVLuJ.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj *pObject = dynamic_cast<const sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.size() != pObject->sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.size(); i++)
		{
			if (sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX[i] != pObject->sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX[i])
			{
				return false;
			}
		}
		if (sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.size() != pObject->sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.size(); i++)
		{
			if (sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M[i] != pObject->sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M[i])
			{
				return false;
			}
		}
		if (sbt_WusRllV6neo7Buhn1SFdcfA.size() != pObject->sbt_WusRllV6neo7Buhn1SFdcfA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WusRllV6neo7Buhn1SFdcfA.size(); i++)
		{
			if (sbt_WusRllV6neo7Buhn1SFdcfA[i] != pObject->sbt_WusRllV6neo7Buhn1SFdcfA[i])
			{
				return false;
			}
		}
		if (sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.size() != pObject->sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.size(); i++)
		{
			if (sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung[i] != pObject->sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung[i])
			{
				return false;
			}
		}
		if (sbt_pXe07Ke3Ck5gtORow.size() != pObject->sbt_pXe07Ke3Ck5gtORow.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pXe07Ke3Ck5gtORow.size(); i++)
		{
			if (sbt_pXe07Ke3Ck5gtORow[i] != pObject->sbt_pXe07Ke3Ck5gtORow[i])
			{
				return false;
			}
		}
		if (sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0 != pObject->sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0)
		{
			return false;
		}
		if (sbt_SoswMswPiDGHZrf00BBJOzOgzJx.size() != pObject->sbt_SoswMswPiDGHZrf00BBJOzOgzJx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SoswMswPiDGHZrf00BBJOzOgzJx.size(); i++)
		{
			if (sbt_SoswMswPiDGHZrf00BBJOzOgzJx[i] != pObject->sbt_SoswMswPiDGHZrf00BBJOzOgzJx[i])
			{
				return false;
			}
		}
		if (sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO != pObject->sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO)
		{
			return false;
		}
		if (sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_ != pObject->sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_)
		{
			return false;
		}
		if (sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR != pObject->sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR)
		{
			return false;
		}
		if (sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T != pObject->sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T)
		{
			return false;
		}
		if (sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX != pObject->sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX)
		{
			return false;
		}
		if (sbt_a0jhqsHpDiZxA.size() != pObject->sbt_a0jhqsHpDiZxA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a0jhqsHpDiZxA.size(); i++)
		{
			if (sbt_a0jhqsHpDiZxA[i] != pObject->sbt_a0jhqsHpDiZxA[i])
			{
				return false;
			}
		}
		if (sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.size() != pObject->sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.size(); i++)
		{
			if (sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO[i] != pObject->sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO[i])
			{
				return false;
			}
		}
		if (sbt_pvt2xaO7EIbX11UjGTwgOFj.size() != pObject->sbt_pvt2xaO7EIbX11UjGTwgOFj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pvt2xaO7EIbX11UjGTwgOFj.size(); i++)
		{
			if (sbt_pvt2xaO7EIbX11UjGTwgOFj[i] != pObject->sbt_pvt2xaO7EIbX11UjGTwgOFj[i])
			{
				return false;
			}
		}
		if (sbt_D9zmobExFsmo5_a != pObject->sbt_D9zmobExFsmo5_a)
		{
			return false;
		}
		if (!sbt_pzv87A1Lf69QATQWKVLuJ.Compare(&pObject->sbt_pzv87A1Lf69QATQWKVLuJ))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WusRllV6neo7Buhn1SFdcfA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WusRllV6neo7Buhn1SFdcfA.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pXe07Ke3Ck5gtORow")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pXe07Ke3Ck5gtORow.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_SoswMswPiDGHZrf00BBJOzOgzJx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SoswMswPiDGHZrf00BBJOzOgzJx.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO", &sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_a0jhqsHpDiZxA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a0jhqsHpDiZxA.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pvt2xaO7EIbX11UjGTwgOFj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pvt2xaO7EIbX11UjGTwgOFj.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_D9zmobExFsmo5_a", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_D9zmobExFsmo5_a = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectObject("sbt_pzv87A1Lf69QATQWKVLuJ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_pzv87A1Lf69QATQWKVLuJ.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.begin(); iter != sbt_J681HsJYo4FEDgp89cdk47K0KP8UxatnX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.begin(); iter != sbt_2g8X9N7q67Jd9EZaEC4eLSd1txzyD3M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WusRllV6neo7Buhn1SFdcfA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_WusRllV6neo7Buhn1SFdcfA.begin(); iter != sbt_WusRllV6neo7Buhn1SFdcfA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.begin(); iter != sbt_ZKHZNdCRelmDPfjqtzTTVBXBXWM0kiswTzYG1RBGgZGWZYpu7vtsg4ung.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pXe07Ke3Ck5gtORow")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_pXe07Ke3Ck5gtORow.begin(); iter != sbt_pXe07Ke3Ck5gtORow.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0", (CX::Double)sbt_fhs7G39REoAwYgrlISCJmLqvLu6ns_XJ_SSH6AhkILtBvE0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SoswMswPiDGHZrf00BBJOzOgzJx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_SoswMswPiDGHZrf00BBJOzOgzJx.begin(); iter != sbt_SoswMswPiDGHZrf00BBJOzOgzJx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO", sbt_vrywolMWskvatef3psD5Mmf8k0cU8Z_O2sDx6POurrN3RrfqTd6oqDgN1sIiUuO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_", (CX::Int64)sbt_nZzWMst6Y60DmemQSMZqzTYtAmTxW66HVmb1Y0_yRSXKYbsd_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR", (CX::Int64)sbt_J3bwwSUnx5gDkE6bdS3RZyOm_zR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T", (CX::Int64)sbt_9S_TyAl2llXHNOC_byumV4yTrG_aSGP6sTjJ4NDu8LohgOD5T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX", (CX::Int64)sbt_f3gOj2jt9_HozzWTFCLAInOd1sFHJoEflNpLwuiABfbOAYX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a0jhqsHpDiZxA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_a0jhqsHpDiZxA.begin(); iter != sbt_a0jhqsHpDiZxA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.begin(); iter != sbt_DMEHyWZWN4RQnWwajS3a7WT0JkISUbv5XJJR8jhD6VJLVox9eQk8KNRbP1pvO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pvt2xaO7EIbX11UjGTwgOFj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_pvt2xaO7EIbX11UjGTwgOFj.begin(); iter != sbt_pvt2xaO7EIbX11UjGTwgOFj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_D9zmobExFsmo5_a", (CX::Double)sbt_D9zmobExFsmo5_a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_pzv87A1Lf69QATQWKVLuJ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_pzv87A1Lf69QATQWKVLuJ.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj>::Type sbt_fMatY3J340V2FTki1Jy8I_MZ2CjArray;

