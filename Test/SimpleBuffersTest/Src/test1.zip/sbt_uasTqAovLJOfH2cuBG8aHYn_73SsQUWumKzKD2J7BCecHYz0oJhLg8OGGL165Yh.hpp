
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B;
	CX::IO::SimpleBuffers::BoolArray sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0;
	CX::UInt64 sbt_r4T5awJMN9QT7Y3Xr;
	CX::UInt64 sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7;
	CX::UInt8 sbt_xdKPuLhqN;
	CX::IO::SimpleBuffers::Int32Array sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb;
	CX::Bool sbt_AfXEWGrl_MY9sNe;
	CX::IO::SimpleBuffers::BoolArray sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj;
	CX::IO::SimpleBuffers::Int8Array sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl;
	CX::IO::SimpleBuffers::Int16Array sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK;
	CX::IO::SimpleBuffers::UInt64Array sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2;
	CX::IO::SimpleBuffers::UInt32Array sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv;
	CX::UInt32 sbt_kwPqBQM;
	CX::IO::SimpleBuffers::UInt32Array sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK;
	CX::UInt64 sbt_AiVC1KW;
	CX::IO::SimpleBuffers::Int8Array sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3;
	CX::Bool sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP;
	CX::IO::SimpleBuffers::UInt64Array sbt__IiVS;
	CX::IO::SimpleBuffers::StringArray sbt_ZEiK3G68B;
	CX::String sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc;
	CX::IO::SimpleBuffers::Int32Array sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n;
	CX::Bool sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_;
	CX::IO::SimpleBuffers::UInt64Array sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW;
	CX::UInt64 sbt_jPpDk3vvulm3UjX;

	virtual void Reset()
	{
		sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.clear();
		sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.clear();
		sbt_r4T5awJMN9QT7Y3Xr = 0;
		sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7 = 0;
		sbt_xdKPuLhqN = 0;
		sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.clear();
		sbt_AfXEWGrl_MY9sNe = false;
		sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.clear();
		sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.clear();
		sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.clear();
		sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.clear();
		sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.clear();
		sbt_kwPqBQM = 0;
		sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.clear();
		sbt_AiVC1KW = 0;
		sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.clear();
		sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP = false;
		sbt__IiVS.clear();
		sbt_ZEiK3G68B.clear();
		sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc.clear();
		sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.clear();
		sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_ = false;
		sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.clear();
		sbt_jPpDk3vvulm3UjX = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.push_back(4085118367);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.push_back(true);
		}
		sbt_r4T5awJMN9QT7Y3Xr = 8239367783391385218;
		sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7 = 2660406158199644778;
		sbt_xdKPuLhqN = 87;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.push_back(-428062152);
		}
		sbt_AfXEWGrl_MY9sNe = false;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.push_back(false);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.push_back(-19);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.push_back(-5160);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.push_back(17522122692814219218);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.push_back(2208115467);
		}
		sbt_kwPqBQM = 3135813394;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.push_back(1436106570);
		}
		sbt_AiVC1KW = 15189843533664231922;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.push_back(-39);
		}
		sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP = false;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt__IiVS.push_back(12602399568750212028);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_ZEiK3G68B.push_back("kw.@EUfi^u[zbv).55=!AOp{pM.'?u@JT");
		}
		sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc = "Dut;nc!wS2YdY_M@K=ym#Li6=7|(n:K";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.push_back(19833015);
		}
		sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_ = false;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.push_back(1113861875799707402);
		}
		sbt_jPpDk3vvulm3UjX = 15212373120406525320;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh *pObject = dynamic_cast<const sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.size() != pObject->sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.size(); i++)
		{
			if (sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B[i] != pObject->sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B[i])
			{
				return false;
			}
		}
		if (sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.size() != pObject->sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.size(); i++)
		{
			if (sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0[i] != pObject->sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0[i])
			{
				return false;
			}
		}
		if (sbt_r4T5awJMN9QT7Y3Xr != pObject->sbt_r4T5awJMN9QT7Y3Xr)
		{
			return false;
		}
		if (sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7 != pObject->sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7)
		{
			return false;
		}
		if (sbt_xdKPuLhqN != pObject->sbt_xdKPuLhqN)
		{
			return false;
		}
		if (sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.size() != pObject->sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.size(); i++)
		{
			if (sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb[i] != pObject->sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb[i])
			{
				return false;
			}
		}
		if (sbt_AfXEWGrl_MY9sNe != pObject->sbt_AfXEWGrl_MY9sNe)
		{
			return false;
		}
		if (sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.size() != pObject->sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.size(); i++)
		{
			if (sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj[i] != pObject->sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj[i])
			{
				return false;
			}
		}
		if (sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.size() != pObject->sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.size(); i++)
		{
			if (sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl[i] != pObject->sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl[i])
			{
				return false;
			}
		}
		if (sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.size() != pObject->sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.size(); i++)
		{
			if (sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK[i] != pObject->sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK[i])
			{
				return false;
			}
		}
		if (sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.size() != pObject->sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.size(); i++)
		{
			if (sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2[i] != pObject->sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2[i])
			{
				return false;
			}
		}
		if (sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.size() != pObject->sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.size(); i++)
		{
			if (sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv[i] != pObject->sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv[i])
			{
				return false;
			}
		}
		if (sbt_kwPqBQM != pObject->sbt_kwPqBQM)
		{
			return false;
		}
		if (sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.size() != pObject->sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.size(); i++)
		{
			if (sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK[i] != pObject->sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK[i])
			{
				return false;
			}
		}
		if (sbt_AiVC1KW != pObject->sbt_AiVC1KW)
		{
			return false;
		}
		if (sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.size() != pObject->sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.size(); i++)
		{
			if (sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3[i] != pObject->sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3[i])
			{
				return false;
			}
		}
		if (sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP != pObject->sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP)
		{
			return false;
		}
		if (sbt__IiVS.size() != pObject->sbt__IiVS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__IiVS.size(); i++)
		{
			if (sbt__IiVS[i] != pObject->sbt__IiVS[i])
			{
				return false;
			}
		}
		if (sbt_ZEiK3G68B.size() != pObject->sbt_ZEiK3G68B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZEiK3G68B.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ZEiK3G68B[i].c_str(), pObject->sbt_ZEiK3G68B[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc.c_str(), pObject->sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc.c_str()))
		{
			return false;
		}
		if (sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.size() != pObject->sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.size(); i++)
		{
			if (sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n[i] != pObject->sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n[i])
			{
				return false;
			}
		}
		if (sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_ != pObject->sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_)
		{
			return false;
		}
		if (sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.size() != pObject->sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.size(); i++)
		{
			if (sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW[i] != pObject->sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW[i])
			{
				return false;
			}
		}
		if (sbt_jPpDk3vvulm3UjX != pObject->sbt_jPpDk3vvulm3UjX)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_r4T5awJMN9QT7Y3Xr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r4T5awJMN9QT7Y3Xr = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_xdKPuLhqN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xdKPuLhqN = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_AfXEWGrl_MY9sNe", &sbt_AfXEWGrl_MY9sNe)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kwPqBQM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kwPqBQM = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AiVC1KW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AiVC1KW = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP", &sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__IiVS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__IiVS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZEiK3G68B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZEiK3G68B.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc", &sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_", &sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jPpDk3vvulm3UjX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jPpDk3vvulm3UjX = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.begin(); iter != sbt_ObNJr3ffzEdmm9OnB8GD8laO80PPhbZHMwzO25B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.begin(); iter != sbt_I2zFsjsfMP17sBBMRJ0vIF36L_g8wx5BCe_qOj_N6ezcEYTtrm6V0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_r4T5awJMN9QT7Y3Xr", (CX::Int64)sbt_r4T5awJMN9QT7Y3Xr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7", (CX::Int64)sbt_NSwBkUtdO0iPKFVnGQt2W5G5JkCEgPWY7wSZtlM0m4Q9HZ_XQGQh3PfjuhHIlT7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xdKPuLhqN", (CX::Int64)sbt_xdKPuLhqN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.begin(); iter != sbt_fQitnA5iKufuMkFuqqZvaRnCYOsTb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_AfXEWGrl_MY9sNe", sbt_AfXEWGrl_MY9sNe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.begin(); iter != sbt_QFJYojni94Zz9vUucuqe5AMzfK63m33Cg1Exj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.begin(); iter != sbt_rc56MC2W4t3F4lgdoKnDCAs8vLIB3bGdbCtbgZ0ONvPJ7Cl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.begin(); iter != sbt_4X3BtsRsnipjzb1y20wpy5ODrp6mt2FWPUXMKDIWq_bS1jK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.begin(); iter != sbt_nPLcxNJgjfbVajMOKZfLR8i3oc9Uxn2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.begin(); iter != sbt_QwclXlnlLmus42HWbZBNVvd0A6zg0VEijd1F_8nrfC0kf7xyOTXCv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kwPqBQM", (CX::Int64)sbt_kwPqBQM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.begin(); iter != sbt_0aUVh5jthPTQoPxh5Irz2lODH1ZjMyEX9w2DuWwP39wMI7P0gyei1G2CHfK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AiVC1KW", (CX::Int64)sbt_AiVC1KW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.begin(); iter != sbt_qJqp3fxhna2OU9fKg9At7ZhbNWo5W64NuvG2azu6uWwhkAJ5C1GF_bOr3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP", sbt_35ZNn7lT_Mwp8FqRJTDD4tYcwVG8VzZdNSBnvJP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__IiVS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__IiVS.begin(); iter != sbt__IiVS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZEiK3G68B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ZEiK3G68B.begin(); iter != sbt_ZEiK3G68B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc", sbt_2kPI8w52cb37qM9G0OnqHSwBijO2jxXDIAsIvdut52MkcZD_NzvzAaF0GMc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.begin(); iter != sbt_DlMqGDQMqhfkeHmQTTD8Uwpc0McLVNt6n.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_", sbt__lz3ZzQYRUEv0hcwOQaIAv7DEL8jkLeANVNLX3SQVnrCyOG6vS_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.begin(); iter != sbt_jejNUkhVSwlmKiP42TMJfaFKOVrPjenWEgNeCjQcQYAACIrqW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jPpDk3vvulm3UjX", (CX::Int64)sbt_jPpDk3vvulm3UjX)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh>::Type sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165YhArray;

