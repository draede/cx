
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD.hpp"


class sbt_j110sfDS2NJVocY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE;
	CX::IO::SimpleBuffers::WStringArray sbt_nZKo789a3ieA6iNwuMD5RO68C;
	CX::IO::SimpleBuffers::UInt32Array sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX;
	CX::IO::SimpleBuffers::Int16Array sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV;
	CX::UInt8 sbt_Tdpnj;
	CX::IO::SimpleBuffers::Int16Array sbt_7EVltXcojrhp3mrUiRERdRXb_;
	CX::IO::SimpleBuffers::UInt32Array sbt__vt121kMP;
	CX::IO::SimpleBuffers::UInt8Array sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE;
	CX::IO::SimpleBuffers::UInt32Array sbt_b;
	CX::IO::SimpleBuffers::WStringArray sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl;
	CX::Int16 sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6;
	CX::IO::SimpleBuffers::Int64Array sbt_YfZReUKmf0M7cLa7v_FM0;
	CX::IO::SimpleBuffers::FloatArray sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj;
	CX::Int32 sbt_KKezKn2ndc62tEjg77edz;
	CX::IO::SimpleBuffers::DoubleArray sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5;
	CX::IO::SimpleBuffers::UInt64Array sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er;
	CX::Int16 sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ;
	CX::WString sbt_nEIlgaA3XJ3s5;
	CX::IO::SimpleBuffers::DoubleArray sbt_keGx_;
	CX::Int64 sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0;
	CX::UInt64 sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI;
	CX::String sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg;
	CX::UInt16 sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0;
	CX::String sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6;
	sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD sbt_PGiXGr8;

	virtual void Reset()
	{
		sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.clear();
		sbt_nZKo789a3ieA6iNwuMD5RO68C.clear();
		sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.clear();
		sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.clear();
		sbt_Tdpnj = 0;
		sbt_7EVltXcojrhp3mrUiRERdRXb_.clear();
		sbt__vt121kMP.clear();
		sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.clear();
		sbt_b.clear();
		sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.clear();
		sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6 = 0;
		sbt_YfZReUKmf0M7cLa7v_FM0.clear();
		sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.clear();
		sbt_KKezKn2ndc62tEjg77edz = 0;
		sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.clear();
		sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.clear();
		sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ = 0;
		sbt_nEIlgaA3XJ3s5.clear();
		sbt_keGx_.clear();
		sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0 = 0;
		sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI = 0;
		sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg.clear();
		sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0 = 0;
		sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6.clear();
		sbt_PGiXGr8.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.push_back(true);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_nZKo789a3ieA6iNwuMD5RO68C.push_back(L"<bT;`GlOR\\h5p<mB4O~lgni");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.push_back(529339541);
		}
		sbt_Tdpnj = 232;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_7EVltXcojrhp3mrUiRERdRXb_.push_back(21795);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.push_back(254);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_b.push_back(981718895);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.push_back(L"lg3mIJ9:\"v1S");
		}
		sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6 = -24357;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_YfZReUKmf0M7cLa7v_FM0.push_back(7636295538188561544);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.push_back(0.308448f);
		}
		sbt_KKezKn2ndc62tEjg77edz = 716418478;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.push_back(0.757367);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.push_back(6670617518158217870);
		}
		sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ = -5456;
		sbt_nEIlgaA3XJ3s5 = L"(Y*=`x2S\\v4RA9(5'{ktI6hIx?laXy";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_keGx_.push_back(0.369683);
		}
		sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0 = -3904442723105009434;
		sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI = 11526896588404780822;
		sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg = "Rt/UqJ03\"kA%:.+KlYE~3B";
		sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0 = 14065;
		sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6 = "8E+?YByNE_,%.g_fD~4^X%#%jIz]cDW@qi";
		sbt_PGiXGr8.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_j110sfDS2NJVocY *pObject = dynamic_cast<const sbt_j110sfDS2NJVocY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.size() != pObject->sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.size(); i++)
		{
			if (sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE[i] != pObject->sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE[i])
			{
				return false;
			}
		}
		if (sbt_nZKo789a3ieA6iNwuMD5RO68C.size() != pObject->sbt_nZKo789a3ieA6iNwuMD5RO68C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nZKo789a3ieA6iNwuMD5RO68C.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_nZKo789a3ieA6iNwuMD5RO68C[i].c_str(), pObject->sbt_nZKo789a3ieA6iNwuMD5RO68C[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.size() != pObject->sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.size(); i++)
		{
			if (sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX[i] != pObject->sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX[i])
			{
				return false;
			}
		}
		if (sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.size() != pObject->sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.size(); i++)
		{
			if (sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV[i] != pObject->sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV[i])
			{
				return false;
			}
		}
		if (sbt_Tdpnj != pObject->sbt_Tdpnj)
		{
			return false;
		}
		if (sbt_7EVltXcojrhp3mrUiRERdRXb_.size() != pObject->sbt_7EVltXcojrhp3mrUiRERdRXb_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7EVltXcojrhp3mrUiRERdRXb_.size(); i++)
		{
			if (sbt_7EVltXcojrhp3mrUiRERdRXb_[i] != pObject->sbt_7EVltXcojrhp3mrUiRERdRXb_[i])
			{
				return false;
			}
		}
		if (sbt__vt121kMP.size() != pObject->sbt__vt121kMP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__vt121kMP.size(); i++)
		{
			if (sbt__vt121kMP[i] != pObject->sbt__vt121kMP[i])
			{
				return false;
			}
		}
		if (sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.size() != pObject->sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.size(); i++)
		{
			if (sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE[i] != pObject->sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE[i])
			{
				return false;
			}
		}
		if (sbt_b.size() != pObject->sbt_b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b.size(); i++)
		{
			if (sbt_b[i] != pObject->sbt_b[i])
			{
				return false;
			}
		}
		if (sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.size() != pObject->sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl[i].c_str(), pObject->sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6 != pObject->sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6)
		{
			return false;
		}
		if (sbt_YfZReUKmf0M7cLa7v_FM0.size() != pObject->sbt_YfZReUKmf0M7cLa7v_FM0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YfZReUKmf0M7cLa7v_FM0.size(); i++)
		{
			if (sbt_YfZReUKmf0M7cLa7v_FM0[i] != pObject->sbt_YfZReUKmf0M7cLa7v_FM0[i])
			{
				return false;
			}
		}
		if (sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.size() != pObject->sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.size(); i++)
		{
			if (sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj[i] != pObject->sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj[i])
			{
				return false;
			}
		}
		if (sbt_KKezKn2ndc62tEjg77edz != pObject->sbt_KKezKn2ndc62tEjg77edz)
		{
			return false;
		}
		if (sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.size() != pObject->sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.size(); i++)
		{
			if (sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5[i] != pObject->sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5[i])
			{
				return false;
			}
		}
		if (sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.size() != pObject->sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.size(); i++)
		{
			if (sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er[i] != pObject->sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er[i])
			{
				return false;
			}
		}
		if (sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ != pObject->sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_nEIlgaA3XJ3s5.c_str(), pObject->sbt_nEIlgaA3XJ3s5.c_str()))
		{
			return false;
		}
		if (sbt_keGx_.size() != pObject->sbt_keGx_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_keGx_.size(); i++)
		{
			if (sbt_keGx_[i] != pObject->sbt_keGx_[i])
			{
				return false;
			}
		}
		if (sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0 != pObject->sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0)
		{
			return false;
		}
		if (sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI != pObject->sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg.c_str(), pObject->sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg.c_str()))
		{
			return false;
		}
		if (sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0 != pObject->sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6.c_str(), pObject->sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6.c_str()))
		{
			return false;
		}
		if (!sbt_PGiXGr8.Compare(&pObject->sbt_PGiXGr8))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nZKo789a3ieA6iNwuMD5RO68C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nZKo789a3ieA6iNwuMD5RO68C.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Tdpnj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Tdpnj = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7EVltXcojrhp3mrUiRERdRXb_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7EVltXcojrhp3mrUiRERdRXb_.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__vt121kMP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__vt121kMP.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YfZReUKmf0M7cLa7v_FM0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YfZReUKmf0M7cLa7v_FM0.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KKezKn2ndc62tEjg77edz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KKezKn2ndc62tEjg77edz = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_nEIlgaA3XJ3s5", &sbt_nEIlgaA3XJ3s5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_keGx_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_keGx_.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg", &sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6", &sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_PGiXGr8")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_PGiXGr8.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.begin(); iter != sbt_c4X29yYGUcISCpUd3iRiNAibFTyfZQx1ZLOtE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nZKo789a3ieA6iNwuMD5RO68C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_nZKo789a3ieA6iNwuMD5RO68C.begin(); iter != sbt_nZKo789a3ieA6iNwuMD5RO68C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.begin(); iter != sbt_jfsTVEQ8xHRB8oOXrpfdEUqjxp_nEXKNe8K8zsZYX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.begin(); iter != sbt_4mbqhgURm4uZFoWIwyBRQ4M0H47WX45TR_Mg6kgIV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Tdpnj", (CX::Int64)sbt_Tdpnj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7EVltXcojrhp3mrUiRERdRXb_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_7EVltXcojrhp3mrUiRERdRXb_.begin(); iter != sbt_7EVltXcojrhp3mrUiRERdRXb_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__vt121kMP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt__vt121kMP.begin(); iter != sbt__vt121kMP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.begin(); iter != sbt_aDq_ghVmX_K5gSZTqznk7PpVq8wghlzIE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_b.begin(); iter != sbt_b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.begin(); iter != sbt_WYpsCEo75JAdqsqIs_cVeO9x3gsznRbtCyjTjDCGhV6gs6Rfl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6", (CX::Int64)sbt_PjniOiq6ufIp3ReQHeHKhWcF7Nxt9B5X9bfHRT9_NmFg0uG_EyIpAsQR6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YfZReUKmf0M7cLa7v_FM0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_YfZReUKmf0M7cLa7v_FM0.begin(); iter != sbt_YfZReUKmf0M7cLa7v_FM0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.begin(); iter != sbt_2pyQxquWeZLSfktWY3TOkPnMOjvsrcLt22_vFnrGCHUWhJj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KKezKn2ndc62tEjg77edz", (CX::Int64)sbt_KKezKn2ndc62tEjg77edz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.begin(); iter != sbt_KSbXukuixg362ASz7ARVdMwDWGHvSg5KBN5PHB5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.begin(); iter != sbt_IRr9Dtxjbsli9z15kAwH09Jl2Er.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ", (CX::Int64)sbt_1gtIKIPH82V2YEUJG84Ra36SFQ2BusEUJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_nEIlgaA3XJ3s5", sbt_nEIlgaA3XJ3s5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_keGx_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_keGx_.begin(); iter != sbt_keGx_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0", (CX::Int64)sbt_hcF_VvDJrhn3hZkZb_hgvlfiCzwI6CJKCZ0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI", (CX::Int64)sbt_IGU8WB70HHxQU9YKc3vLPjBokwuGAkRGEAkwI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg", sbt_y6FiaIqJ86RlGx50C0dakeoc7wALFAyaUNVQTVk8kHPsCTiII4jsP45jg.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0", (CX::Int64)sbt_00xrK6SA5LUFtC14MmnWZEXHZWOmJJNFLQ5a_TsD0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6", sbt_HmS4pArAI2MNRbWykQrQGAeFH3PsN5201uR7M2s3GbNDcV2d6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_PGiXGr8")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_PGiXGr8.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_j110sfDS2NJVocY>::Type sbt_j110sfDS2NJVocYArray;

