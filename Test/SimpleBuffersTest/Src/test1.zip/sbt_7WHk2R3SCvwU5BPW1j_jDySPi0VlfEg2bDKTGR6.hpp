
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_9;
	CX::UInt64 sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC;

	virtual void Reset()
	{
		sbt_9 = 0;
		sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_9 = 25926;
		sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC = 8874512142985863524;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 *pObject = dynamic_cast<const sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9 != pObject->sbt_9)
		{
			return false;
		}
		if (sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC != pObject->sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_9", (CX::Int64)sbt_9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC", (CX::Int64)sbt_bDJqyBTVEJEJ7ecTCncRzN53StDXHtoV9fJKSKNukYAUnz0SV1Xdk9zqDZLtsVC)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6>::Type sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6Array;

