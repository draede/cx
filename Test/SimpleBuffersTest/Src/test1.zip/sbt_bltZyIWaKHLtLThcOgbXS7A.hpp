
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX.hpp"


class sbt_bltZyIWaKHLtLThcOgbXS7A : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_U7AOd;
	CX::IO::SimpleBuffers::UInt32Array sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG;
	CX::IO::SimpleBuffers::Int8Array sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh;
	CX::UInt8 sbt_ZzZhRYiILatUe7t;
	CX::IO::SimpleBuffers::UInt16Array sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp;
	CX::Int32 sbt_BW197iuUrIwDJU0gnVu0T;
	CX::IO::SimpleBuffers::Int64Array sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR;
	CX::WString sbt_IuJTkbYxkaukUd1IT9qSSL96a;
	CX::IO::SimpleBuffers::UInt64Array sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo;
	CX::IO::SimpleBuffers::UInt8Array sbt_pKy;
	CX::IO::SimpleBuffers::WStringArray sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg;
	CX::IO::SimpleBuffers::UInt32Array sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI;
	CX::WString sbt_S1HOukrzx91V3aFGsr6MC22bYLd;
	CX::IO::SimpleBuffers::UInt64Array sbt_js4BRkS;
	CX::IO::SimpleBuffers::Int8Array sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV;
	CX::IO::SimpleBuffers::UInt32Array sbt_XPrEA1jT3;
	CX::IO::SimpleBuffers::StringArray sbt_iQ30cQsrc12jP7BWWwH;
	sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK;

	virtual void Reset()
	{
		sbt_U7AOd = 0.0;
		sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.clear();
		sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.clear();
		sbt_ZzZhRYiILatUe7t = 0;
		sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.clear();
		sbt_BW197iuUrIwDJU0gnVu0T = 0;
		sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.clear();
		sbt_IuJTkbYxkaukUd1IT9qSSL96a.clear();
		sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.clear();
		sbt_pKy.clear();
		sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.clear();
		sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.clear();
		sbt_S1HOukrzx91V3aFGsr6MC22bYLd.clear();
		sbt_js4BRkS.clear();
		sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.clear();
		sbt_XPrEA1jT3.clear();
		sbt_iQ30cQsrc12jP7BWWwH.clear();
		sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_U7AOd = 0.973376;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.push_back(3111669353);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.push_back(-6);
		}
		sbt_ZzZhRYiILatUe7t = 49;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.push_back(40129);
		}
		sbt_BW197iuUrIwDJU0gnVu0T = 2128396769;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.push_back(3430741925774277978);
		}
		sbt_IuJTkbYxkaukUd1IT9qSSL96a = L".J\\JEdZ1gbxGog6`tH`u&EiR0,x,,2NmcDE";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.push_back(7867442492360535450);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_pKy.push_back(183);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.push_back(L"+uO@ksT8K^POhq~FVSXv;6S_$_gkvlIp\"*JS!+r4VUy')^7");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.push_back(3742375992);
		}
		sbt_S1HOukrzx91V3aFGsr6MC22bYLd = L"&Q\"'U?[J7+W/;mazV.xt%|v%-X8$-A(2`\"A>`W{V-QzPYN!N_";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_js4BRkS.push_back(15589416923064789762);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.push_back(0);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_XPrEA1jT3.push_back(2966027373);
		}
		sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_bltZyIWaKHLtLThcOgbXS7A *pObject = dynamic_cast<const sbt_bltZyIWaKHLtLThcOgbXS7A *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_U7AOd != pObject->sbt_U7AOd)
		{
			return false;
		}
		if (sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.size() != pObject->sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.size(); i++)
		{
			if (sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG[i] != pObject->sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG[i])
			{
				return false;
			}
		}
		if (sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.size() != pObject->sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.size(); i++)
		{
			if (sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh[i] != pObject->sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh[i])
			{
				return false;
			}
		}
		if (sbt_ZzZhRYiILatUe7t != pObject->sbt_ZzZhRYiILatUe7t)
		{
			return false;
		}
		if (sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.size() != pObject->sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.size(); i++)
		{
			if (sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp[i] != pObject->sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp[i])
			{
				return false;
			}
		}
		if (sbt_BW197iuUrIwDJU0gnVu0T != pObject->sbt_BW197iuUrIwDJU0gnVu0T)
		{
			return false;
		}
		if (sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.size() != pObject->sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.size(); i++)
		{
			if (sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR[i] != pObject->sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_IuJTkbYxkaukUd1IT9qSSL96a.c_str(), pObject->sbt_IuJTkbYxkaukUd1IT9qSSL96a.c_str()))
		{
			return false;
		}
		if (sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.size() != pObject->sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.size(); i++)
		{
			if (sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo[i] != pObject->sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo[i])
			{
				return false;
			}
		}
		if (sbt_pKy.size() != pObject->sbt_pKy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pKy.size(); i++)
		{
			if (sbt_pKy[i] != pObject->sbt_pKy[i])
			{
				return false;
			}
		}
		if (sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.size() != pObject->sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg[i].c_str(), pObject->sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.size() != pObject->sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.size(); i++)
		{
			if (sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI[i] != pObject->sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_S1HOukrzx91V3aFGsr6MC22bYLd.c_str(), pObject->sbt_S1HOukrzx91V3aFGsr6MC22bYLd.c_str()))
		{
			return false;
		}
		if (sbt_js4BRkS.size() != pObject->sbt_js4BRkS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_js4BRkS.size(); i++)
		{
			if (sbt_js4BRkS[i] != pObject->sbt_js4BRkS[i])
			{
				return false;
			}
		}
		if (sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.size() != pObject->sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.size(); i++)
		{
			if (sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV[i] != pObject->sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV[i])
			{
				return false;
			}
		}
		if (sbt_XPrEA1jT3.size() != pObject->sbt_XPrEA1jT3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XPrEA1jT3.size(); i++)
		{
			if (sbt_XPrEA1jT3[i] != pObject->sbt_XPrEA1jT3[i])
			{
				return false;
			}
		}
		if (sbt_iQ30cQsrc12jP7BWWwH.size() != pObject->sbt_iQ30cQsrc12jP7BWWwH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iQ30cQsrc12jP7BWWwH.size(); i++)
		{
			if (0 != cx_strcmp(sbt_iQ30cQsrc12jP7BWWwH[i].c_str(), pObject->sbt_iQ30cQsrc12jP7BWWwH[i].c_str()))
			{
				return false;
			}
		}
		if (!sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK.Compare(&pObject->sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_U7AOd", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_U7AOd = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZzZhRYiILatUe7t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZzZhRYiILatUe7t = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BW197iuUrIwDJU0gnVu0T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BW197iuUrIwDJU0gnVu0T = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_IuJTkbYxkaukUd1IT9qSSL96a", &sbt_IuJTkbYxkaukUd1IT9qSSL96a)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pKy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pKy.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_S1HOukrzx91V3aFGsr6MC22bYLd", &sbt_S1HOukrzx91V3aFGsr6MC22bYLd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_js4BRkS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_js4BRkS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XPrEA1jT3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XPrEA1jT3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_iQ30cQsrc12jP7BWWwH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iQ30cQsrc12jP7BWWwH.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_U7AOd", (CX::Double)sbt_U7AOd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.begin(); iter != sbt_DX3LAN5Sl92IDng2aqORMmI4ms02_byOVnNs3Qx40dlJRw1MaYLsKWG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.begin(); iter != sbt_fhSJrJ9cMIS7POaW3MFikEgLIEopZaZy9P5JHSTVh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZzZhRYiILatUe7t", (CX::Int64)sbt_ZzZhRYiILatUe7t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.begin(); iter != sbt_u7cPGwZo7bJDsJP0gzvO8WN6eCbGY9kEaNIJcW709Z8PVCBJuAJNyxrzp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BW197iuUrIwDJU0gnVu0T", (CX::Int64)sbt_BW197iuUrIwDJU0gnVu0T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.begin(); iter != sbt_mXtCc8n3VYY3_87sU2vp9Edz2PgXWhm7nHvO0_A2ACzgHgbmA5LtkqeT3tR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_IuJTkbYxkaukUd1IT9qSSL96a", sbt_IuJTkbYxkaukUd1IT9qSSL96a.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.begin(); iter != sbt_rZCEFjpYXP4irHD4faennE7Nm_Df1g4VKdT79UDQkTWJjppBo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pKy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_pKy.begin(); iter != sbt_pKy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.begin(); iter != sbt_Vh3LAIopab7PLVpnUeWSfGlQoacjb_OlwLQO81BtMKp5iwOl3f2OhXFeg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.begin(); iter != sbt_hAknWqlr2kDoAlznDQ4xaIwjMgKXyMtaZEIyECzcFkHl0ckz86_4QpCKI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_S1HOukrzx91V3aFGsr6MC22bYLd", sbt_S1HOukrzx91V3aFGsr6MC22bYLd.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_js4BRkS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_js4BRkS.begin(); iter != sbt_js4BRkS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.begin(); iter != sbt_oN311EDSXEfv5YlpzKBFELeMXvEmA5pHV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XPrEA1jT3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_XPrEA1jT3.begin(); iter != sbt_XPrEA1jT3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iQ30cQsrc12jP7BWWwH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_iQ30cQsrc12jP7BWWwH.begin(); iter != sbt_iQ30cQsrc12jP7BWWwH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_DAxM1iiWe6V1W2cVGLMM0o1Wk66w1IK.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_bltZyIWaKHLtLThcOgbXS7A>::Type sbt_bltZyIWaKHLtLThcOgbXS7AArray;

