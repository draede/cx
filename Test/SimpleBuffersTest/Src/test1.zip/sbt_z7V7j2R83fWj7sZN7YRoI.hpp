
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg.hpp"


class sbt_z7V7j2R83fWj7sZN7YRoI : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_cQ1mME4DTqNm0vhHD;
	CX::IO::SimpleBuffers::DoubleArray sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm;
	CX::WString sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9;
	CX::IO::SimpleBuffers::BoolArray sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_;
	CX::IO::SimpleBuffers::Int16Array sbt_6MbYRAIGAxbm763oJcI;
	CX::UInt32 sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s;
	sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMgArray sbt_6XHPCOBfsluqxcQVrhy9PJNeN;

	virtual void Reset()
	{
		sbt_cQ1mME4DTqNm0vhHD = 0;
		sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.clear();
		sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9.clear();
		sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.clear();
		sbt_6MbYRAIGAxbm763oJcI.clear();
		sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s = 0;
		sbt_6XHPCOBfsluqxcQVrhy9PJNeN.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_cQ1mME4DTqNm0vhHD = -13321;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.push_back(0.079169);
		}
		sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9 = L"eylo/,Nzicl(h>;!W##h_}A@DP]pix^)>Ht#~";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.push_back(false);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_6MbYRAIGAxbm763oJcI.push_back(29765);
		}
		sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s = 2895227039;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg v;

			v.SetupWithSomeValues();
			sbt_6XHPCOBfsluqxcQVrhy9PJNeN.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_z7V7j2R83fWj7sZN7YRoI *pObject = dynamic_cast<const sbt_z7V7j2R83fWj7sZN7YRoI *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_cQ1mME4DTqNm0vhHD != pObject->sbt_cQ1mME4DTqNm0vhHD)
		{
			return false;
		}
		if (sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.size() != pObject->sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.size(); i++)
		{
			if (sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm[i] != pObject->sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9.c_str(), pObject->sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9.c_str()))
		{
			return false;
		}
		if (sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.size() != pObject->sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.size(); i++)
		{
			if (sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_[i] != pObject->sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_[i])
			{
				return false;
			}
		}
		if (sbt_6MbYRAIGAxbm763oJcI.size() != pObject->sbt_6MbYRAIGAxbm763oJcI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6MbYRAIGAxbm763oJcI.size(); i++)
		{
			if (sbt_6MbYRAIGAxbm763oJcI[i] != pObject->sbt_6MbYRAIGAxbm763oJcI[i])
			{
				return false;
			}
		}
		if (sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s != pObject->sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s)
		{
			return false;
		}
		if (sbt_6XHPCOBfsluqxcQVrhy9PJNeN.size() != pObject->sbt_6XHPCOBfsluqxcQVrhy9PJNeN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6XHPCOBfsluqxcQVrhy9PJNeN.size(); i++)
		{
			if (!sbt_6XHPCOBfsluqxcQVrhy9PJNeN[i].Compare(&pObject->sbt_6XHPCOBfsluqxcQVrhy9PJNeN[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_cQ1mME4DTqNm0vhHD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cQ1mME4DTqNm0vhHD = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9", &sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6MbYRAIGAxbm763oJcI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6MbYRAIGAxbm763oJcI.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6XHPCOBfsluqxcQVrhy9PJNeN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_6XHPCOBfsluqxcQVrhy9PJNeN.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_cQ1mME4DTqNm0vhHD", (CX::Int64)sbt_cQ1mME4DTqNm0vhHD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.begin(); iter != sbt_pkyZnWWG4x7bDiFzprA7GLkLkM72Ag3g3p5hm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9", sbt_wrDI256QSoNR8bYHODcFgzee3QbuJk2n390PB7OThep_Fisuk4bR9.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.begin(); iter != sbt_xqLsuYAW7K0yMbaWXxLQ0RAyuScAWf6p7X2aAikIpqiGz3EpWys0dJ6wgnmx_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6MbYRAIGAxbm763oJcI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_6MbYRAIGAxbm763oJcI.begin(); iter != sbt_6MbYRAIGAxbm763oJcI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s", (CX::Int64)sbt_dQEI2nHReZi583Vkl0gDY5HQ9mpN0K6z4_JWvFZ1s)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6XHPCOBfsluqxcQVrhy9PJNeN")).IsNOK())
		{
			return status;
		}
		for (sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMgArray::const_iterator iter = sbt_6XHPCOBfsluqxcQVrhy9PJNeN.begin(); iter != sbt_6XHPCOBfsluqxcQVrhy9PJNeN.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_z7V7j2R83fWj7sZN7YRoI>::Type sbt_z7V7j2R83fWj7sZN7YRoIArray;

