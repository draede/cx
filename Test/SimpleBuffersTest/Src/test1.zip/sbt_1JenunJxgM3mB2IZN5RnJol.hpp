
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz.hpp"


class sbt_1JenunJxgM3mB2IZN5RnJol : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU;
	CX::IO::SimpleBuffers::StringArray sbt_Rik9UKsYdYHPu8j7tqSNQZy;
	CX::IO::SimpleBuffers::FloatArray sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K;
	CX::IO::SimpleBuffers::Int32Array sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9;
	sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWczArray sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH;

	virtual void Reset()
	{
		sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.clear();
		sbt_Rik9UKsYdYHPu8j7tqSNQZy.clear();
		sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.clear();
		sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.clear();
		sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.push_back(L"IH3[F6G2i4~9J=R8eAenX\\Ub5F^S8zb{Bb`tSv10ZNckN*!'Z");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Rik9UKsYdYHPu8j7tqSNQZy.push_back("?Z8A-psf`&3xLRjFdpKFpI~Q\"Wt,l");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.push_back(0.647377f);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.push_back(-148636995);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz v;

			v.SetupWithSomeValues();
			sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_1JenunJxgM3mB2IZN5RnJol *pObject = dynamic_cast<const sbt_1JenunJxgM3mB2IZN5RnJol *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.size() != pObject->sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU[i].c_str(), pObject->sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Rik9UKsYdYHPu8j7tqSNQZy.size() != pObject->sbt_Rik9UKsYdYHPu8j7tqSNQZy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Rik9UKsYdYHPu8j7tqSNQZy.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Rik9UKsYdYHPu8j7tqSNQZy[i].c_str(), pObject->sbt_Rik9UKsYdYHPu8j7tqSNQZy[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.size() != pObject->sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.size(); i++)
		{
			if (sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K[i] != pObject->sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K[i])
			{
				return false;
			}
		}
		if (sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.size() != pObject->sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.size(); i++)
		{
			if (sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9[i] != pObject->sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9[i])
			{
				return false;
			}
		}
		if (sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.size() != pObject->sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.size(); i++)
		{
			if (!sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH[i].Compare(&pObject->sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Rik9UKsYdYHPu8j7tqSNQZy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Rik9UKsYdYHPu8j7tqSNQZy.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.begin(); iter != sbt_9qvqYGqWqQxdLkxaoaXHKiTP75DgU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Rik9UKsYdYHPu8j7tqSNQZy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Rik9UKsYdYHPu8j7tqSNQZy.begin(); iter != sbt_Rik9UKsYdYHPu8j7tqSNQZy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.begin(); iter != sbt_ssLQVJ9KiMwVBQ_usCipXjAainKl26kpQtKoEePZ3sz2h6A4PSbKf8K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.begin(); iter != sbt_o616zM6SFfZSpE4NAq016c4dhSxrdvJi_ydX9_P0z1EqO_bKuS9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH")).IsNOK())
		{
			return status;
		}
		for (sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWczArray::const_iterator iter = sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.begin(); iter != sbt_OuvcLxGW9C9_7k_qRb5yuNTTSar3U1hae0M_WCmE3PIgXKlQ6uzYohH.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_1JenunJxgM3mB2IZN5RnJol>::Type sbt_1JenunJxgM3mB2IZN5RnJolArray;

