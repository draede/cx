
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_MB9ykZMXMVlFYrw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww;
	CX::IO::SimpleBuffers::UInt8Array sbt_rxs0Z;
	CX::String sbt_kN9r8;
	CX::Bool sbt_Yl2_AGtziTZF7KICCucGm;
	CX::UInt32 sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt;
	CX::IO::SimpleBuffers::Int16Array sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB;
	CX::IO::SimpleBuffers::UInt8Array sbt_a_zG9oJw4;
	CX::UInt8 sbt_TbeDJcznxguqHKkiqq4cp_tNE;
	CX::IO::SimpleBuffers::UInt32Array sbt_9MhKcKAt0GS9IWx3pmqFsXT_b;
	CX::IO::SimpleBuffers::UInt64Array sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF;
	CX::IO::SimpleBuffers::Int32Array sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr;
	CX::Int8 sbt_vyMPq8OpQ0GLtICW8Eq8COh2S;
	CX::IO::SimpleBuffers::UInt64Array sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8;
	CX::IO::SimpleBuffers::UInt32Array sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC;
	CX::Int8 sbt_iHAaa;
	CX::String sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc;
	CX::UInt64 sbt_bex_cG6jTTRsYZmr6cSom;
	CX::UInt32 sbt_Y44lIyOZL;
	CX::IO::SimpleBuffers::UInt32Array sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx;
	CX::IO::SimpleBuffers::UInt16Array sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL;
	CX::IO::SimpleBuffers::BoolArray sbt_E3Xx7juA6p5Z2iz0iWKSf;
	CX::IO::SimpleBuffers::Int32Array sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c;
	CX::UInt8 sbt__lCRJ92TJ;
	CX::IO::SimpleBuffers::Int8Array sbt_dgrdIWzYAyPqKqP;
	CX::Int32 sbt_e40bMMW7SieV6JvrIlMIIbP;
	CX::Bool sbt_GH7ModFH386BD9Oh6H8Tk;

	virtual void Reset()
	{
		sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.clear();
		sbt_rxs0Z.clear();
		sbt_kN9r8.clear();
		sbt_Yl2_AGtziTZF7KICCucGm = false;
		sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt = 0;
		sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.clear();
		sbt_a_zG9oJw4.clear();
		sbt_TbeDJcznxguqHKkiqq4cp_tNE = 0;
		sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.clear();
		sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.clear();
		sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.clear();
		sbt_vyMPq8OpQ0GLtICW8Eq8COh2S = 0;
		sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.clear();
		sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.clear();
		sbt_iHAaa = 0;
		sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc.clear();
		sbt_bex_cG6jTTRsYZmr6cSom = 0;
		sbt_Y44lIyOZL = 0;
		sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.clear();
		sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.clear();
		sbt_E3Xx7juA6p5Z2iz0iWKSf.clear();
		sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.clear();
		sbt__lCRJ92TJ = 0;
		sbt_dgrdIWzYAyPqKqP.clear();
		sbt_e40bMMW7SieV6JvrIlMIIbP = 0;
		sbt_GH7ModFH386BD9Oh6H8Tk = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.push_back(2720686774);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_rxs0Z.push_back(101);
		}
		sbt_kN9r8 = "Pbt2`s<;%f*IV0<1t|3:{BJUH?;>cw~>?.'0/^z}C!<v?zJLR]6J\\Qd1";
		sbt_Yl2_AGtziTZF7KICCucGm = false;
		sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt = 2043816663;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.push_back(16317);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_a_zG9oJw4.push_back(83);
		}
		sbt_TbeDJcznxguqHKkiqq4cp_tNE = 250;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.push_back(1018917432);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.push_back(10097478205803460600);
		}
		sbt_vyMPq8OpQ0GLtICW8Eq8COh2S = 10;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.push_back(1113513295413603966);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.push_back(2780750435);
		}
		sbt_iHAaa = 75;
		sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc = "[4;}nTEfYXuR*62F#XN^R|z/lrp*w;7{I),WiVK6HDfF5]*G(x)I#^iEFar5<(fL";
		sbt_bex_cG6jTTRsYZmr6cSom = 14578463874823262058;
		sbt_Y44lIyOZL = 453654347;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.push_back(1175216607);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.push_back(62090);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_E3Xx7juA6p5Z2iz0iWKSf.push_back(false);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.push_back(-18352986);
		}
		sbt__lCRJ92TJ = 184;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_dgrdIWzYAyPqKqP.push_back(-115);
		}
		sbt_e40bMMW7SieV6JvrIlMIIbP = -576344698;
		sbt_GH7ModFH386BD9Oh6H8Tk = false;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_MB9ykZMXMVlFYrw *pObject = dynamic_cast<const sbt_MB9ykZMXMVlFYrw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.size() != pObject->sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.size(); i++)
		{
			if (sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww[i] != pObject->sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww[i])
			{
				return false;
			}
		}
		if (sbt_rxs0Z.size() != pObject->sbt_rxs0Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rxs0Z.size(); i++)
		{
			if (sbt_rxs0Z[i] != pObject->sbt_rxs0Z[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_kN9r8.c_str(), pObject->sbt_kN9r8.c_str()))
		{
			return false;
		}
		if (sbt_Yl2_AGtziTZF7KICCucGm != pObject->sbt_Yl2_AGtziTZF7KICCucGm)
		{
			return false;
		}
		if (sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt != pObject->sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt)
		{
			return false;
		}
		if (sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.size() != pObject->sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.size(); i++)
		{
			if (sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB[i] != pObject->sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB[i])
			{
				return false;
			}
		}
		if (sbt_a_zG9oJw4.size() != pObject->sbt_a_zG9oJw4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a_zG9oJw4.size(); i++)
		{
			if (sbt_a_zG9oJw4[i] != pObject->sbt_a_zG9oJw4[i])
			{
				return false;
			}
		}
		if (sbt_TbeDJcznxguqHKkiqq4cp_tNE != pObject->sbt_TbeDJcznxguqHKkiqq4cp_tNE)
		{
			return false;
		}
		if (sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.size() != pObject->sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.size(); i++)
		{
			if (sbt_9MhKcKAt0GS9IWx3pmqFsXT_b[i] != pObject->sbt_9MhKcKAt0GS9IWx3pmqFsXT_b[i])
			{
				return false;
			}
		}
		if (sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.size() != pObject->sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.size(); i++)
		{
			if (sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF[i] != pObject->sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF[i])
			{
				return false;
			}
		}
		if (sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.size() != pObject->sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.size(); i++)
		{
			if (sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr[i] != pObject->sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr[i])
			{
				return false;
			}
		}
		if (sbt_vyMPq8OpQ0GLtICW8Eq8COh2S != pObject->sbt_vyMPq8OpQ0GLtICW8Eq8COh2S)
		{
			return false;
		}
		if (sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.size() != pObject->sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.size(); i++)
		{
			if (sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8[i] != pObject->sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8[i])
			{
				return false;
			}
		}
		if (sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.size() != pObject->sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.size(); i++)
		{
			if (sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC[i] != pObject->sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC[i])
			{
				return false;
			}
		}
		if (sbt_iHAaa != pObject->sbt_iHAaa)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc.c_str(), pObject->sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc.c_str()))
		{
			return false;
		}
		if (sbt_bex_cG6jTTRsYZmr6cSom != pObject->sbt_bex_cG6jTTRsYZmr6cSom)
		{
			return false;
		}
		if (sbt_Y44lIyOZL != pObject->sbt_Y44lIyOZL)
		{
			return false;
		}
		if (sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.size() != pObject->sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.size(); i++)
		{
			if (sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx[i] != pObject->sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx[i])
			{
				return false;
			}
		}
		if (sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.size() != pObject->sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.size(); i++)
		{
			if (sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL[i] != pObject->sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL[i])
			{
				return false;
			}
		}
		if (sbt_E3Xx7juA6p5Z2iz0iWKSf.size() != pObject->sbt_E3Xx7juA6p5Z2iz0iWKSf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E3Xx7juA6p5Z2iz0iWKSf.size(); i++)
		{
			if (sbt_E3Xx7juA6p5Z2iz0iWKSf[i] != pObject->sbt_E3Xx7juA6p5Z2iz0iWKSf[i])
			{
				return false;
			}
		}
		if (sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.size() != pObject->sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.size(); i++)
		{
			if (sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c[i] != pObject->sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c[i])
			{
				return false;
			}
		}
		if (sbt__lCRJ92TJ != pObject->sbt__lCRJ92TJ)
		{
			return false;
		}
		if (sbt_dgrdIWzYAyPqKqP.size() != pObject->sbt_dgrdIWzYAyPqKqP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dgrdIWzYAyPqKqP.size(); i++)
		{
			if (sbt_dgrdIWzYAyPqKqP[i] != pObject->sbt_dgrdIWzYAyPqKqP[i])
			{
				return false;
			}
		}
		if (sbt_e40bMMW7SieV6JvrIlMIIbP != pObject->sbt_e40bMMW7SieV6JvrIlMIIbP)
		{
			return false;
		}
		if (sbt_GH7ModFH386BD9Oh6H8Tk != pObject->sbt_GH7ModFH386BD9Oh6H8Tk)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rxs0Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rxs0Z.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_kN9r8", &sbt_kN9r8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Yl2_AGtziTZF7KICCucGm", &sbt_Yl2_AGtziTZF7KICCucGm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a_zG9oJw4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a_zG9oJw4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TbeDJcznxguqHKkiqq4cp_tNE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TbeDJcznxguqHKkiqq4cp_tNE = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9MhKcKAt0GS9IWx3pmqFsXT_b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vyMPq8OpQ0GLtICW8Eq8COh2S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vyMPq8OpQ0GLtICW8Eq8COh2S = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iHAaa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iHAaa = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc", &sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bex_cG6jTTRsYZmr6cSom", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bex_cG6jTTRsYZmr6cSom = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Y44lIyOZL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y44lIyOZL = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E3Xx7juA6p5Z2iz0iWKSf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E3Xx7juA6p5Z2iz0iWKSf.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__lCRJ92TJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__lCRJ92TJ = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dgrdIWzYAyPqKqP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dgrdIWzYAyPqKqP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_e40bMMW7SieV6JvrIlMIIbP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e40bMMW7SieV6JvrIlMIIbP = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_GH7ModFH386BD9Oh6H8Tk", &sbt_GH7ModFH386BD9Oh6H8Tk)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.begin(); iter != sbt_YD3cGgXIXiR5V4t9su8E27Xk75TD4Ww.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rxs0Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_rxs0Z.begin(); iter != sbt_rxs0Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_kN9r8", sbt_kN9r8.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Yl2_AGtziTZF7KICCucGm", sbt_Yl2_AGtziTZF7KICCucGm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt", (CX::Int64)sbt_jNKJQC44GuD1h1ZiJnMUfnxHljMEQ0xfrNvXt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.begin(); iter != sbt_kQqPrXw1AigCjptYZOYCEKazYw94na8gNJHFOVjsQnWvAPA3XXloB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a_zG9oJw4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_a_zG9oJw4.begin(); iter != sbt_a_zG9oJw4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TbeDJcznxguqHKkiqq4cp_tNE", (CX::Int64)sbt_TbeDJcznxguqHKkiqq4cp_tNE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9MhKcKAt0GS9IWx3pmqFsXT_b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.begin(); iter != sbt_9MhKcKAt0GS9IWx3pmqFsXT_b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.begin(); iter != sbt_yxlGjKfxvztzGveNyDumiZl0OcCxvohUF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.begin(); iter != sbt_OvF6773tffExLhprboZ2P6UuReEwxzOelS0FM2DNR7jzbKuuPL_hnLvHr348cFr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vyMPq8OpQ0GLtICW8Eq8COh2S", (CX::Int64)sbt_vyMPq8OpQ0GLtICW8Eq8COh2S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.begin(); iter != sbt_EgiG0ZTQGjPMe_w1BsIj8ApDBPETeCzp97vQH4wFHY8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.begin(); iter != sbt_L1FMlRx_89Sk_VpqbEw3d42hTS66w74RngRrw33x8hJXmLkLzIvL9T8cxDXGVDC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iHAaa", (CX::Int64)sbt_iHAaa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc", sbt_YcbrA5m_8lndxztacS93j0iQ9NyOQFM70iEg5JUZWPwlNWgOQ_PCagw0l0A8oKc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bex_cG6jTTRsYZmr6cSom", (CX::Int64)sbt_bex_cG6jTTRsYZmr6cSom)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y44lIyOZL", (CX::Int64)sbt_Y44lIyOZL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.begin(); iter != sbt_Rr7lHxOBgCRx2VrYLW6TaXAuyZpwKaKkx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.begin(); iter != sbt_VzBnjoDdA4sF0hAlQrFGt9PB0oL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E3Xx7juA6p5Z2iz0iWKSf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_E3Xx7juA6p5Z2iz0iWKSf.begin(); iter != sbt_E3Xx7juA6p5Z2iz0iWKSf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.begin(); iter != sbt_4_3dqfscym7C5GytNQWZffC_IA4WlLsYXkRfSAxxnY56F8c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__lCRJ92TJ", (CX::Int64)sbt__lCRJ92TJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dgrdIWzYAyPqKqP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_dgrdIWzYAyPqKqP.begin(); iter != sbt_dgrdIWzYAyPqKqP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_e40bMMW7SieV6JvrIlMIIbP", (CX::Int64)sbt_e40bMMW7SieV6JvrIlMIIbP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GH7ModFH386BD9Oh6H8Tk", sbt_GH7ModFH386BD9Oh6H8Tk)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_MB9ykZMXMVlFYrw>::Type sbt_MB9ykZMXMVlFYrwArray;

