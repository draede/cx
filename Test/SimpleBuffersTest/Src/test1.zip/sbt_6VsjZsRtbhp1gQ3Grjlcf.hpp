
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB.hpp"


class sbt_6VsjZsRtbhp1gQ3Grjlcf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_HEDTWFj9n12;
	CX::WString sbt_biGi1;
	CX::UInt32 sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN;
	CX::IO::SimpleBuffers::StringArray sbt_7xdjlO29tG08_dNYUOpFrtG;
	CX::Int64 sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp;
	CX::String sbt_GEreecEUjfiwF5NeSHEmocT;
	CX::Int32 sbt_pP9zJ;
	CX::IO::SimpleBuffers::FloatArray sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL;
	CX::IO::SimpleBuffers::StringArray sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R;
	CX::Int32 sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3;
	CX::Int64 sbt_qkGsISqMIRfefSvfq;
	CX::UInt64 sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN;
	CX::UInt64 sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7;
	CX::IO::SimpleBuffers::UInt64Array sbt_xKL;
	sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK;

	virtual void Reset()
	{
		sbt_HEDTWFj9n12.clear();
		sbt_biGi1.clear();
		sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN = 0;
		sbt_7xdjlO29tG08_dNYUOpFrtG.clear();
		sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp = 0;
		sbt_GEreecEUjfiwF5NeSHEmocT.clear();
		sbt_pP9zJ = 0;
		sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.clear();
		sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.clear();
		sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3 = 0;
		sbt_qkGsISqMIRfefSvfq = 0;
		sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN = 0;
		sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7 = 0;
		sbt_xKL.clear();
		sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_HEDTWFj9n12.push_back(L"/ze");
		}
		sbt_biGi1 = L"JXh<NHwBn|\\L~7RYN{W`-T\\:?JL[PB4ZFo";
		sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN = 1775892781;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_7xdjlO29tG08_dNYUOpFrtG.push_back("f+5QgSF30cb3sE;BECNVml8Vi6%giVm!V?L=lQ_=UO'a()A8cbXx!");
		}
		sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp = 2741803114496038640;
		sbt_GEreecEUjfiwF5NeSHEmocT = "HXNSdn/4';?lxPJOzz*<*'];.X0uS_~(UJOI\"pk63<#('S!C5{q*\\GNR1Zv/s";
		sbt_pP9zJ = -2108460294;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.push_back(0.903181f);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.push_back("C2<7BUa?C(n'|)4&cS-kHI^z:+J~A1PE%ra4UFy||Y#{>m4oPuz8@eLL8(8K");
		}
		sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3 = -1615801393;
		sbt_qkGsISqMIRfefSvfq = -1803445026772612552;
		sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN = 12892372277622108038;
		sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7 = 11033008592627410346;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_xKL.push_back(12310497898783606594);
		}
		sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6VsjZsRtbhp1gQ3Grjlcf *pObject = dynamic_cast<const sbt_6VsjZsRtbhp1gQ3Grjlcf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_HEDTWFj9n12.size() != pObject->sbt_HEDTWFj9n12.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HEDTWFj9n12.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_HEDTWFj9n12[i].c_str(), pObject->sbt_HEDTWFj9n12[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_biGi1.c_str(), pObject->sbt_biGi1.c_str()))
		{
			return false;
		}
		if (sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN != pObject->sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN)
		{
			return false;
		}
		if (sbt_7xdjlO29tG08_dNYUOpFrtG.size() != pObject->sbt_7xdjlO29tG08_dNYUOpFrtG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7xdjlO29tG08_dNYUOpFrtG.size(); i++)
		{
			if (0 != cx_strcmp(sbt_7xdjlO29tG08_dNYUOpFrtG[i].c_str(), pObject->sbt_7xdjlO29tG08_dNYUOpFrtG[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp != pObject->sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_GEreecEUjfiwF5NeSHEmocT.c_str(), pObject->sbt_GEreecEUjfiwF5NeSHEmocT.c_str()))
		{
			return false;
		}
		if (sbt_pP9zJ != pObject->sbt_pP9zJ)
		{
			return false;
		}
		if (sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.size() != pObject->sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.size(); i++)
		{
			if (sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL[i] != pObject->sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL[i])
			{
				return false;
			}
		}
		if (sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.size() != pObject->sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.size(); i++)
		{
			if (0 != cx_strcmp(sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R[i].c_str(), pObject->sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3 != pObject->sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3)
		{
			return false;
		}
		if (sbt_qkGsISqMIRfefSvfq != pObject->sbt_qkGsISqMIRfefSvfq)
		{
			return false;
		}
		if (sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN != pObject->sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN)
		{
			return false;
		}
		if (sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7 != pObject->sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7)
		{
			return false;
		}
		if (sbt_xKL.size() != pObject->sbt_xKL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xKL.size(); i++)
		{
			if (sbt_xKL[i] != pObject->sbt_xKL[i])
			{
				return false;
			}
		}
		if (!sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK.Compare(&pObject->sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_HEDTWFj9n12")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HEDTWFj9n12.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_biGi1", &sbt_biGi1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7xdjlO29tG08_dNYUOpFrtG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7xdjlO29tG08_dNYUOpFrtG.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_GEreecEUjfiwF5NeSHEmocT", &sbt_GEreecEUjfiwF5NeSHEmocT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pP9zJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pP9zJ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qkGsISqMIRfefSvfq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qkGsISqMIRfefSvfq = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xKL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xKL.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_HEDTWFj9n12")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_HEDTWFj9n12.begin(); iter != sbt_HEDTWFj9n12.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_biGi1", sbt_biGi1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN", (CX::Int64)sbt_HhorVL6OWAfbeH7Q_UuMPITtWqWEctO3UUNukdogpCPd2tk1TFN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7xdjlO29tG08_dNYUOpFrtG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_7xdjlO29tG08_dNYUOpFrtG.begin(); iter != sbt_7xdjlO29tG08_dNYUOpFrtG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp", (CX::Int64)sbt_3evGhuXnv_gJ38jKRC5KDcbR7hsUBOfPKIFKpneN4Pp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_GEreecEUjfiwF5NeSHEmocT", sbt_GEreecEUjfiwF5NeSHEmocT.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pP9zJ", (CX::Int64)sbt_pP9zJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.begin(); iter != sbt_U2B_tPZg4Fenn8NIGLPQyb5RAracYbL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.begin(); iter != sbt_qHOtUfGgqcxY90EbmIjH1YgwfS3u4NZbnvsI9WboZr7cPM2QBKbRyUkJChcRy5R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3", (CX::Int64)sbt_4L1Bs98opTYFE1Q6hhlZ0Cx_O6yJxq3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qkGsISqMIRfefSvfq", (CX::Int64)sbt_qkGsISqMIRfefSvfq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN", (CX::Int64)sbt_sQ5_N3oyMsYFw8MtHSNiDV43C9oLBlvrspNxXfKR9fN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7", (CX::Int64)sbt_8OTYD6rTzsGf2VHsr9CzUMKw9ABNTo4IbCNo7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xKL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_xKL.begin(); iter != sbt_xKL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iLCIzibXfaavS1y9iUxyy0thwVz7WgK.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6VsjZsRtbhp1gQ3Grjlcf>::Type sbt_6VsjZsRtbhp1gQ3GrjlcfArray;

