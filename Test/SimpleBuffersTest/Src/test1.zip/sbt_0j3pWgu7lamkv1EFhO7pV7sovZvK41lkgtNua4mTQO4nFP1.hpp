
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc;
	CX::IO::SimpleBuffers::UInt64Array sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg;
	CX::IO::SimpleBuffers::UInt32Array sbt_j_8;
	CX::Int16 sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi;
	CX::UInt8 sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF;
	CX::IO::SimpleBuffers::BoolArray sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d;
	CX::IO::SimpleBuffers::UInt64Array sbt_dtiZKbboTp60kc_tj5tXr;
	CX::UInt16 sbt_yEf;
	CX::Int64 sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9;
	CX::Int16 sbt_IhQ4y;
	CX::UInt32 sbt_JL6G63lK_SKPed4o4iy;
	CX::IO::SimpleBuffers::Int16Array sbt_PZIGUKwYytxM8vH46O0AI;
	CX::IO::SimpleBuffers::UInt16Array sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB;
	CX::IO::SimpleBuffers::Int64Array sbt_Y;
	CX::Bool sbt_M_gMKu1;
	CX::IO::SimpleBuffers::Int32Array sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC;
	CX::Bool sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6;
	CX::IO::SimpleBuffers::BoolArray sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4;
	CX::Bool sbt_FCAxeRI;
	CX::IO::SimpleBuffers::Int64Array sbt_lJcvY;
	CX::IO::SimpleBuffers::Int16Array sbt_4RzsHZl;
	CX::IO::SimpleBuffers::Int8Array sbt_K3_Ykb3sPwPfuANyZHEWo;
	CX::IO::SimpleBuffers::UInt64Array sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI;
	CX::String sbt_ZPBfn;

	virtual void Reset()
	{
		sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.clear();
		sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.clear();
		sbt_j_8.clear();
		sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi = 0;
		sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF = 0;
		sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.clear();
		sbt_dtiZKbboTp60kc_tj5tXr.clear();
		sbt_yEf = 0;
		sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9 = 0;
		sbt_IhQ4y = 0;
		sbt_JL6G63lK_SKPed4o4iy = 0;
		sbt_PZIGUKwYytxM8vH46O0AI.clear();
		sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.clear();
		sbt_Y.clear();
		sbt_M_gMKu1 = false;
		sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.clear();
		sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6 = false;
		sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.clear();
		sbt_FCAxeRI = false;
		sbt_lJcvY.clear();
		sbt_4RzsHZl.clear();
		sbt_K3_Ykb3sPwPfuANyZHEWo.clear();
		sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.clear();
		sbt_ZPBfn.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.push_back(2568347837);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.push_back(18115292588195528590);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_j_8.push_back(572618153);
		}
		sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi = -6623;
		sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF = 240;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.push_back(false);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_dtiZKbboTp60kc_tj5tXr.push_back(3676772656432908492);
		}
		sbt_yEf = 34621;
		sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9 = -7253142076322977100;
		sbt_IhQ4y = 12403;
		sbt_JL6G63lK_SKPed4o4iy = 421005457;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_PZIGUKwYytxM8vH46O0AI.push_back(11917);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.push_back(51424);
		}
		sbt_M_gMKu1 = false;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.push_back(-790276680);
		}
		sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6 = false;
		sbt_FCAxeRI = true;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_lJcvY.push_back(-6505757858200311932);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4RzsHZl.push_back(-4527);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_K3_Ykb3sPwPfuANyZHEWo.push_back(38);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.push_back(6138237451059396656);
		}
		sbt_ZPBfn = "QY";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1 *pObject = dynamic_cast<const sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.size() != pObject->sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.size(); i++)
		{
			if (sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc[i] != pObject->sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc[i])
			{
				return false;
			}
		}
		if (sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.size() != pObject->sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.size(); i++)
		{
			if (sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg[i] != pObject->sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg[i])
			{
				return false;
			}
		}
		if (sbt_j_8.size() != pObject->sbt_j_8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j_8.size(); i++)
		{
			if (sbt_j_8[i] != pObject->sbt_j_8[i])
			{
				return false;
			}
		}
		if (sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi != pObject->sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi)
		{
			return false;
		}
		if (sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF != pObject->sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF)
		{
			return false;
		}
		if (sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.size() != pObject->sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.size(); i++)
		{
			if (sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d[i] != pObject->sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d[i])
			{
				return false;
			}
		}
		if (sbt_dtiZKbboTp60kc_tj5tXr.size() != pObject->sbt_dtiZKbboTp60kc_tj5tXr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dtiZKbboTp60kc_tj5tXr.size(); i++)
		{
			if (sbt_dtiZKbboTp60kc_tj5tXr[i] != pObject->sbt_dtiZKbboTp60kc_tj5tXr[i])
			{
				return false;
			}
		}
		if (sbt_yEf != pObject->sbt_yEf)
		{
			return false;
		}
		if (sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9 != pObject->sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9)
		{
			return false;
		}
		if (sbt_IhQ4y != pObject->sbt_IhQ4y)
		{
			return false;
		}
		if (sbt_JL6G63lK_SKPed4o4iy != pObject->sbt_JL6G63lK_SKPed4o4iy)
		{
			return false;
		}
		if (sbt_PZIGUKwYytxM8vH46O0AI.size() != pObject->sbt_PZIGUKwYytxM8vH46O0AI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PZIGUKwYytxM8vH46O0AI.size(); i++)
		{
			if (sbt_PZIGUKwYytxM8vH46O0AI[i] != pObject->sbt_PZIGUKwYytxM8vH46O0AI[i])
			{
				return false;
			}
		}
		if (sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.size() != pObject->sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.size(); i++)
		{
			if (sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB[i] != pObject->sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB[i])
			{
				return false;
			}
		}
		if (sbt_Y.size() != pObject->sbt_Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y.size(); i++)
		{
			if (sbt_Y[i] != pObject->sbt_Y[i])
			{
				return false;
			}
		}
		if (sbt_M_gMKu1 != pObject->sbt_M_gMKu1)
		{
			return false;
		}
		if (sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.size() != pObject->sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.size(); i++)
		{
			if (sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC[i] != pObject->sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC[i])
			{
				return false;
			}
		}
		if (sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6 != pObject->sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6)
		{
			return false;
		}
		if (sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.size() != pObject->sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.size(); i++)
		{
			if (sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4[i] != pObject->sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4[i])
			{
				return false;
			}
		}
		if (sbt_FCAxeRI != pObject->sbt_FCAxeRI)
		{
			return false;
		}
		if (sbt_lJcvY.size() != pObject->sbt_lJcvY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lJcvY.size(); i++)
		{
			if (sbt_lJcvY[i] != pObject->sbt_lJcvY[i])
			{
				return false;
			}
		}
		if (sbt_4RzsHZl.size() != pObject->sbt_4RzsHZl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4RzsHZl.size(); i++)
		{
			if (sbt_4RzsHZl[i] != pObject->sbt_4RzsHZl[i])
			{
				return false;
			}
		}
		if (sbt_K3_Ykb3sPwPfuANyZHEWo.size() != pObject->sbt_K3_Ykb3sPwPfuANyZHEWo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_K3_Ykb3sPwPfuANyZHEWo.size(); i++)
		{
			if (sbt_K3_Ykb3sPwPfuANyZHEWo[i] != pObject->sbt_K3_Ykb3sPwPfuANyZHEWo[i])
			{
				return false;
			}
		}
		if (sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.size() != pObject->sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.size(); i++)
		{
			if (sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI[i] != pObject->sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_ZPBfn.c_str(), pObject->sbt_ZPBfn.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j_8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j_8.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dtiZKbboTp60kc_tj5tXr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dtiZKbboTp60kc_tj5tXr.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yEf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yEf = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IhQ4y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IhQ4y = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_JL6G63lK_SKPed4o4iy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JL6G63lK_SKPed4o4iy = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PZIGUKwYytxM8vH46O0AI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PZIGUKwYytxM8vH46O0AI.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_M_gMKu1", &sbt_M_gMKu1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6", &sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_FCAxeRI", &sbt_FCAxeRI)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lJcvY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lJcvY.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4RzsHZl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4RzsHZl.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_K3_Ykb3sPwPfuANyZHEWo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_K3_Ykb3sPwPfuANyZHEWo.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_ZPBfn", &sbt_ZPBfn)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.begin(); iter != sbt_XPndDg_Sqs2EgOwP4xmzxB4Pc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.begin(); iter != sbt_u2R8kYuWU3yqlGQ6GC7Bq1SMcp8Wg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j_8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_j_8.begin(); iter != sbt_j_8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi", (CX::Int64)sbt_DdsSHAsaQsmCT42vEPZdanPPFc66s0494PQVxe6FQ2tZkhahDGFMM1e1BYi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF", (CX::Int64)sbt_ahr8Ods6a6TKN9Eijr4DIwxq7ATr7_OH5HT036wRdHgzqyJiF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.begin(); iter != sbt_UM_bEPrpT8eiC_Pro1GmzhbOd4uqXCCwX9Fnx3d.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dtiZKbboTp60kc_tj5tXr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_dtiZKbboTp60kc_tj5tXr.begin(); iter != sbt_dtiZKbboTp60kc_tj5tXr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yEf", (CX::Int64)sbt_yEf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9", (CX::Int64)sbt_JPHN9etnWUPyU62iRUTjos22KHmLp6DKu_OZ5TFnZn1RU_2Nsp9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IhQ4y", (CX::Int64)sbt_IhQ4y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JL6G63lK_SKPed4o4iy", (CX::Int64)sbt_JL6G63lK_SKPed4o4iy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PZIGUKwYytxM8vH46O0AI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_PZIGUKwYytxM8vH46O0AI.begin(); iter != sbt_PZIGUKwYytxM8vH46O0AI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.begin(); iter != sbt_IpHiwPaqyRblbURz7iY7GvQukoyh6yDmJVTFyiB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Y.begin(); iter != sbt_Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_M_gMKu1", sbt_M_gMKu1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.begin(); iter != sbt_fEjPOROLk2wHTl4nP_7sKBnStHC75bpUAKUfrPC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6", sbt_KLaM8I5bzHFhcgrnfrgVW8iokdwzZVW6WwXM6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.begin(); iter != sbt_KzqqoHBZZ8JHpAQXQLZk7KQFaKBTLGVEmL9pXsQjANSUBY4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_FCAxeRI", sbt_FCAxeRI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lJcvY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_lJcvY.begin(); iter != sbt_lJcvY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4RzsHZl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_4RzsHZl.begin(); iter != sbt_4RzsHZl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_K3_Ykb3sPwPfuANyZHEWo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_K3_Ykb3sPwPfuANyZHEWo.begin(); iter != sbt_K3_Ykb3sPwPfuANyZHEWo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.begin(); iter != sbt_9WwiCMAdpQG35Yh11yMKOvvRlAEskUSsMTLv8Z2EGDiSzl5Jr2ePz1oWPLwuI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ZPBfn", sbt_ZPBfn.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1>::Type sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1Array;

