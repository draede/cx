
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC;
	CX::UInt32 sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy;
	CX::UInt32 sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx;
	CX::IO::SimpleBuffers::UInt64Array sbt_eIGK6zGr2rPIe3jBopD;
	CX::IO::SimpleBuffers::Int16Array sbt_EKTFRBKmo6F2trT_c8eX1E9jn;
	CX::Int64 sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3;
	CX::IO::SimpleBuffers::UInt8Array sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C;
	CX::UInt32 sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl;
	CX::Int16 sbt__K4Q2sqfEAwNejnz5;
	CX::IO::SimpleBuffers::UInt8Array sbt_rvQjMcemv;
	CX::IO::SimpleBuffers::Int8Array sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT;
	CX::IO::SimpleBuffers::UInt8Array sbt_bRL;
	CX::IO::SimpleBuffers::Int16Array sbt_Uorm4QT7oCnyzrcaEyC85K2W1;
	CX::UInt32 sbt_qHZaxzIEP;
	CX::IO::SimpleBuffers::UInt32Array sbt_31VnJtm4GEWKDgfpPzUTDy_;
	CX::IO::SimpleBuffers::UInt16Array sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE;
	CX::IO::SimpleBuffers::Int16Array sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca;
	CX::IO::SimpleBuffers::Int8Array sbt_L2T0zy_D0JcMmdiiAmRmowY;
	CX::IO::SimpleBuffers::Int8Array sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL;
	CX::Int32 sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP;
	CX::UInt64 sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq;
	CX::IO::SimpleBuffers::UInt32Array sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ;
	CX::Int64 sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d;
	CX::UInt32 sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb;
	CX::UInt32 sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk;

	virtual void Reset()
	{
		sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.clear();
		sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy = 0;
		sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx = 0;
		sbt_eIGK6zGr2rPIe3jBopD.clear();
		sbt_EKTFRBKmo6F2trT_c8eX1E9jn.clear();
		sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3 = 0;
		sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.clear();
		sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl = 0;
		sbt__K4Q2sqfEAwNejnz5 = 0;
		sbt_rvQjMcemv.clear();
		sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.clear();
		sbt_bRL.clear();
		sbt_Uorm4QT7oCnyzrcaEyC85K2W1.clear();
		sbt_qHZaxzIEP = 0;
		sbt_31VnJtm4GEWKDgfpPzUTDy_.clear();
		sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.clear();
		sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.clear();
		sbt_L2T0zy_D0JcMmdiiAmRmowY.clear();
		sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.clear();
		sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP = 0;
		sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq = 0;
		sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.clear();
		sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d = 0;
		sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb = 0;
		sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.push_back(false);
		}
		sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy = 2915549115;
		sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx = 3153649889;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_eIGK6zGr2rPIe3jBopD.push_back(1396484624377507654);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_EKTFRBKmo6F2trT_c8eX1E9jn.push_back(18318);
		}
		sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3 = -9037153330809953852;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.push_back(10);
		}
		sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl = 2254481775;
		sbt__K4Q2sqfEAwNejnz5 = -3406;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_rvQjMcemv.push_back(104);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.push_back(-108);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_bRL.push_back(145);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Uorm4QT7oCnyzrcaEyC85K2W1.push_back(18979);
		}
		sbt_qHZaxzIEP = 3001473482;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_31VnJtm4GEWKDgfpPzUTDy_.push_back(3073369916);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.push_back(30355);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_L2T0zy_D0JcMmdiiAmRmowY.push_back(-34);
		}
		sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP = -1088865629;
		sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq = 14769083906015699042;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.push_back(4135239986);
		}
		sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d = 2006210387146535012;
		sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb = 1494734407;
		sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk = 2881847478;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw *pObject = dynamic_cast<const sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.size() != pObject->sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.size(); i++)
		{
			if (sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC[i] != pObject->sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC[i])
			{
				return false;
			}
		}
		if (sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy != pObject->sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy)
		{
			return false;
		}
		if (sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx != pObject->sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx)
		{
			return false;
		}
		if (sbt_eIGK6zGr2rPIe3jBopD.size() != pObject->sbt_eIGK6zGr2rPIe3jBopD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eIGK6zGr2rPIe3jBopD.size(); i++)
		{
			if (sbt_eIGK6zGr2rPIe3jBopD[i] != pObject->sbt_eIGK6zGr2rPIe3jBopD[i])
			{
				return false;
			}
		}
		if (sbt_EKTFRBKmo6F2trT_c8eX1E9jn.size() != pObject->sbt_EKTFRBKmo6F2trT_c8eX1E9jn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EKTFRBKmo6F2trT_c8eX1E9jn.size(); i++)
		{
			if (sbt_EKTFRBKmo6F2trT_c8eX1E9jn[i] != pObject->sbt_EKTFRBKmo6F2trT_c8eX1E9jn[i])
			{
				return false;
			}
		}
		if (sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3 != pObject->sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3)
		{
			return false;
		}
		if (sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.size() != pObject->sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.size(); i++)
		{
			if (sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C[i] != pObject->sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C[i])
			{
				return false;
			}
		}
		if (sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl != pObject->sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl)
		{
			return false;
		}
		if (sbt__K4Q2sqfEAwNejnz5 != pObject->sbt__K4Q2sqfEAwNejnz5)
		{
			return false;
		}
		if (sbt_rvQjMcemv.size() != pObject->sbt_rvQjMcemv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rvQjMcemv.size(); i++)
		{
			if (sbt_rvQjMcemv[i] != pObject->sbt_rvQjMcemv[i])
			{
				return false;
			}
		}
		if (sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.size() != pObject->sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.size(); i++)
		{
			if (sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT[i] != pObject->sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT[i])
			{
				return false;
			}
		}
		if (sbt_bRL.size() != pObject->sbt_bRL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bRL.size(); i++)
		{
			if (sbt_bRL[i] != pObject->sbt_bRL[i])
			{
				return false;
			}
		}
		if (sbt_Uorm4QT7oCnyzrcaEyC85K2W1.size() != pObject->sbt_Uorm4QT7oCnyzrcaEyC85K2W1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Uorm4QT7oCnyzrcaEyC85K2W1.size(); i++)
		{
			if (sbt_Uorm4QT7oCnyzrcaEyC85K2W1[i] != pObject->sbt_Uorm4QT7oCnyzrcaEyC85K2W1[i])
			{
				return false;
			}
		}
		if (sbt_qHZaxzIEP != pObject->sbt_qHZaxzIEP)
		{
			return false;
		}
		if (sbt_31VnJtm4GEWKDgfpPzUTDy_.size() != pObject->sbt_31VnJtm4GEWKDgfpPzUTDy_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_31VnJtm4GEWKDgfpPzUTDy_.size(); i++)
		{
			if (sbt_31VnJtm4GEWKDgfpPzUTDy_[i] != pObject->sbt_31VnJtm4GEWKDgfpPzUTDy_[i])
			{
				return false;
			}
		}
		if (sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.size() != pObject->sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.size(); i++)
		{
			if (sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE[i] != pObject->sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE[i])
			{
				return false;
			}
		}
		if (sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.size() != pObject->sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.size(); i++)
		{
			if (sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca[i] != pObject->sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca[i])
			{
				return false;
			}
		}
		if (sbt_L2T0zy_D0JcMmdiiAmRmowY.size() != pObject->sbt_L2T0zy_D0JcMmdiiAmRmowY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L2T0zy_D0JcMmdiiAmRmowY.size(); i++)
		{
			if (sbt_L2T0zy_D0JcMmdiiAmRmowY[i] != pObject->sbt_L2T0zy_D0JcMmdiiAmRmowY[i])
			{
				return false;
			}
		}
		if (sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.size() != pObject->sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.size(); i++)
		{
			if (sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL[i] != pObject->sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL[i])
			{
				return false;
			}
		}
		if (sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP != pObject->sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP)
		{
			return false;
		}
		if (sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq != pObject->sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq)
		{
			return false;
		}
		if (sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.size() != pObject->sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.size(); i++)
		{
			if (sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ[i] != pObject->sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ[i])
			{
				return false;
			}
		}
		if (sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d != pObject->sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d)
		{
			return false;
		}
		if (sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb != pObject->sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb)
		{
			return false;
		}
		if (sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk != pObject->sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eIGK6zGr2rPIe3jBopD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eIGK6zGr2rPIe3jBopD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EKTFRBKmo6F2trT_c8eX1E9jn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EKTFRBKmo6F2trT_c8eX1E9jn.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt__K4Q2sqfEAwNejnz5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__K4Q2sqfEAwNejnz5 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rvQjMcemv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rvQjMcemv.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bRL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bRL.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Uorm4QT7oCnyzrcaEyC85K2W1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Uorm4QT7oCnyzrcaEyC85K2W1.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qHZaxzIEP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qHZaxzIEP = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_31VnJtm4GEWKDgfpPzUTDy_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_31VnJtm4GEWKDgfpPzUTDy_.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L2T0zy_D0JcMmdiiAmRmowY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L2T0zy_D0JcMmdiiAmRmowY.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.begin(); iter != sbt_qW4dh37Kfzxb_nQvt2xPRiaDdRzGbGuSZZSvaX2lXrrAC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy", (CX::Int64)sbt_ax5Rcj0ZrWldIEH6XZQvykJ8nuy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx", (CX::Int64)sbt_EXSMU5jYJYi36z77anYHGbPLi3Dslld33PJtlfx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eIGK6zGr2rPIe3jBopD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_eIGK6zGr2rPIe3jBopD.begin(); iter != sbt_eIGK6zGr2rPIe3jBopD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EKTFRBKmo6F2trT_c8eX1E9jn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_EKTFRBKmo6F2trT_c8eX1E9jn.begin(); iter != sbt_EKTFRBKmo6F2trT_c8eX1E9jn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3", (CX::Int64)sbt_jsoTAluOyrQPXQJeHHctYlVSlL31TJCtfeYY3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.begin(); iter != sbt_vfxBiropZLjW24RPkq_3uF0V7BaQyN34C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl", (CX::Int64)sbt_20EtTjftZLKq3N853q7ztt3saGEr58tGreDQGk1MkJYC8hFK7yFgK6wDOrmWl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__K4Q2sqfEAwNejnz5", (CX::Int64)sbt__K4Q2sqfEAwNejnz5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rvQjMcemv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_rvQjMcemv.begin(); iter != sbt_rvQjMcemv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.begin(); iter != sbt_AN_ubi_m1RKBemDfRbKoHrhJcYtpT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bRL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_bRL.begin(); iter != sbt_bRL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Uorm4QT7oCnyzrcaEyC85K2W1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Uorm4QT7oCnyzrcaEyC85K2W1.begin(); iter != sbt_Uorm4QT7oCnyzrcaEyC85K2W1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qHZaxzIEP", (CX::Int64)sbt_qHZaxzIEP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_31VnJtm4GEWKDgfpPzUTDy_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_31VnJtm4GEWKDgfpPzUTDy_.begin(); iter != sbt_31VnJtm4GEWKDgfpPzUTDy_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.begin(); iter != sbt_woPGqMdaK5enekmoKCoHBBlqxAmNDy3wZZ7Y86HS5crxm1IHxji_ug781TE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.begin(); iter != sbt_O6ghWSRvqjADfmMrHz5uNrg4jTPxTVUFxggZCh_DD6GzWrzIgzmKeV3Ca.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L2T0zy_D0JcMmdiiAmRmowY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_L2T0zy_D0JcMmdiiAmRmowY.begin(); iter != sbt_L2T0zy_D0JcMmdiiAmRmowY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.begin(); iter != sbt_jQ2P9cqOhuOOM8dshcowcX4r2m26FfPfuYTlbdt4QyFfj8T7I6dB9gQLL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP", (CX::Int64)sbt_18Ln3l2530bfNQ8O1BGUexRn7mLOenPfMzvFjfD5A8ccn6LyfmzJP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq", (CX::Int64)sbt_No1pr9EpDogTlMvjsz7tmU_qtTbOtl354pcviJQ5JQiREFTlORq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.begin(); iter != sbt_NX9heZ37Yihc6iQyeracP2RhWGYgGlBwQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d", (CX::Int64)sbt_gbKvAkOIgGJ93LE1B0VfVY2d2goEpJtVoFCeIl9mU_d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb", (CX::Int64)sbt_FK7kHnhyyWE8WN2oGMHzHdd3ZlT91Z8mShPadNvS8ed8He22y43ope9_aW1PZmb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk", (CX::Int64)sbt_Or9oEdcqRzw5hL9HOzOGEL6helhIv7eW3wFPahk)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw>::Type sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlwArray;

