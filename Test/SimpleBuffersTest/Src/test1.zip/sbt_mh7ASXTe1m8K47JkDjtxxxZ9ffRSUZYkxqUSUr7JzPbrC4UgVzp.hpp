
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_h81snrulZgMc1BBmsba;
	CX::UInt64 sbt_vup6Bm8Gi0iz2;
	CX::IO::SimpleBuffers::Int32Array sbt_2DgRbKOPp17o4Zic697pC;
	CX::IO::SimpleBuffers::BoolArray sbt_7Av;
	CX::Bool sbt_0wG8EH4jahuwDLt1rd3qKIx;
	CX::Int8 sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB;
	CX::Bool sbt_F;
	CX::IO::SimpleBuffers::UInt32Array sbt_JrbJgUuVmxiYgWc;
	CX::IO::SimpleBuffers::Int16Array sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF;
	CX::IO::SimpleBuffers::Int8Array sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW;
	CX::IO::SimpleBuffers::UInt32Array sbt_sy9s42_xwoRwMfJ9nboqPZAE4;
	CX::IO::SimpleBuffers::StringArray sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE;
	CX::Int32 sbt__Uz6wizPYXzyj6Mm6SVpk;
	CX::UInt64 sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv;
	CX::UInt64 sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk;
	CX::UInt32 sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a;

	virtual void Reset()
	{
		sbt_h81snrulZgMc1BBmsba.clear();
		sbt_vup6Bm8Gi0iz2 = 0;
		sbt_2DgRbKOPp17o4Zic697pC.clear();
		sbt_7Av.clear();
		sbt_0wG8EH4jahuwDLt1rd3qKIx = false;
		sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB = 0;
		sbt_F = false;
		sbt_JrbJgUuVmxiYgWc.clear();
		sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.clear();
		sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.clear();
		sbt_sy9s42_xwoRwMfJ9nboqPZAE4.clear();
		sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.clear();
		sbt__Uz6wizPYXzyj6Mm6SVpk = 0;
		sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv = 0;
		sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk = 0;
		sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_h81snrulZgMc1BBmsba.push_back(8096782326348381576);
		}
		sbt_vup6Bm8Gi0iz2 = 11792265091692970612;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_2DgRbKOPp17o4Zic697pC.push_back(-1205320021);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_7Av.push_back(true);
		}
		sbt_0wG8EH4jahuwDLt1rd3qKIx = true;
		sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB = -5;
		sbt_F = true;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_JrbJgUuVmxiYgWc.push_back(2026076095);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.push_back(-29702);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.push_back(-105);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_sy9s42_xwoRwMfJ9nboqPZAE4.push_back(3736975334);
		}
		sbt__Uz6wizPYXzyj6Mm6SVpk = 404797607;
		sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv = 2772102664975546370;
		sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk = 11383123453534381782;
		sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a = 1240194967;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp *pObject = dynamic_cast<const sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_h81snrulZgMc1BBmsba.size() != pObject->sbt_h81snrulZgMc1BBmsba.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h81snrulZgMc1BBmsba.size(); i++)
		{
			if (sbt_h81snrulZgMc1BBmsba[i] != pObject->sbt_h81snrulZgMc1BBmsba[i])
			{
				return false;
			}
		}
		if (sbt_vup6Bm8Gi0iz2 != pObject->sbt_vup6Bm8Gi0iz2)
		{
			return false;
		}
		if (sbt_2DgRbKOPp17o4Zic697pC.size() != pObject->sbt_2DgRbKOPp17o4Zic697pC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2DgRbKOPp17o4Zic697pC.size(); i++)
		{
			if (sbt_2DgRbKOPp17o4Zic697pC[i] != pObject->sbt_2DgRbKOPp17o4Zic697pC[i])
			{
				return false;
			}
		}
		if (sbt_7Av.size() != pObject->sbt_7Av.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7Av.size(); i++)
		{
			if (sbt_7Av[i] != pObject->sbt_7Av[i])
			{
				return false;
			}
		}
		if (sbt_0wG8EH4jahuwDLt1rd3qKIx != pObject->sbt_0wG8EH4jahuwDLt1rd3qKIx)
		{
			return false;
		}
		if (sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB != pObject->sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB)
		{
			return false;
		}
		if (sbt_F != pObject->sbt_F)
		{
			return false;
		}
		if (sbt_JrbJgUuVmxiYgWc.size() != pObject->sbt_JrbJgUuVmxiYgWc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JrbJgUuVmxiYgWc.size(); i++)
		{
			if (sbt_JrbJgUuVmxiYgWc[i] != pObject->sbt_JrbJgUuVmxiYgWc[i])
			{
				return false;
			}
		}
		if (sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.size() != pObject->sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.size(); i++)
		{
			if (sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF[i] != pObject->sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF[i])
			{
				return false;
			}
		}
		if (sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.size() != pObject->sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.size(); i++)
		{
			if (sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW[i] != pObject->sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW[i])
			{
				return false;
			}
		}
		if (sbt_sy9s42_xwoRwMfJ9nboqPZAE4.size() != pObject->sbt_sy9s42_xwoRwMfJ9nboqPZAE4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sy9s42_xwoRwMfJ9nboqPZAE4.size(); i++)
		{
			if (sbt_sy9s42_xwoRwMfJ9nboqPZAE4[i] != pObject->sbt_sy9s42_xwoRwMfJ9nboqPZAE4[i])
			{
				return false;
			}
		}
		if (sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.size() != pObject->sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.size(); i++)
		{
			if (0 != cx_strcmp(sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE[i].c_str(), pObject->sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE[i].c_str()))
			{
				return false;
			}
		}
		if (sbt__Uz6wizPYXzyj6Mm6SVpk != pObject->sbt__Uz6wizPYXzyj6Mm6SVpk)
		{
			return false;
		}
		if (sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv != pObject->sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv)
		{
			return false;
		}
		if (sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk != pObject->sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk)
		{
			return false;
		}
		if (sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a != pObject->sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_h81snrulZgMc1BBmsba")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h81snrulZgMc1BBmsba.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vup6Bm8Gi0iz2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vup6Bm8Gi0iz2 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2DgRbKOPp17o4Zic697pC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2DgRbKOPp17o4Zic697pC.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7Av")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7Av.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_0wG8EH4jahuwDLt1rd3qKIx", &sbt_0wG8EH4jahuwDLt1rd3qKIx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_F", &sbt_F)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JrbJgUuVmxiYgWc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JrbJgUuVmxiYgWc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sy9s42_xwoRwMfJ9nboqPZAE4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sy9s42_xwoRwMfJ9nboqPZAE4.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__Uz6wizPYXzyj6Mm6SVpk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__Uz6wizPYXzyj6Mm6SVpk = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_h81snrulZgMc1BBmsba")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_h81snrulZgMc1BBmsba.begin(); iter != sbt_h81snrulZgMc1BBmsba.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vup6Bm8Gi0iz2", (CX::Int64)sbt_vup6Bm8Gi0iz2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2DgRbKOPp17o4Zic697pC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_2DgRbKOPp17o4Zic697pC.begin(); iter != sbt_2DgRbKOPp17o4Zic697pC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7Av")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_7Av.begin(); iter != sbt_7Av.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_0wG8EH4jahuwDLt1rd3qKIx", sbt_0wG8EH4jahuwDLt1rd3qKIx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB", (CX::Int64)sbt_CPXtps7WF1X4WPlABRismPEGjR_pBJigUMPEobSd0mB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_F", sbt_F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JrbJgUuVmxiYgWc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_JrbJgUuVmxiYgWc.begin(); iter != sbt_JrbJgUuVmxiYgWc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.begin(); iter != sbt_H7130nKNCxRJBH8Lfh0JQ992CcVjVDWBX2R80dZfNMfPtVKSlyhx4JFpF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.begin(); iter != sbt_vGnShWLLtpLn9GogTOjFK2Ayy4Uitu_jRHWqqXg3yvt2JCW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sy9s42_xwoRwMfJ9nboqPZAE4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_sy9s42_xwoRwMfJ9nboqPZAE4.begin(); iter != sbt_sy9s42_xwoRwMfJ9nboqPZAE4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.begin(); iter != sbt_MaNDkOSOoR3XINBU1gTMRvrPInh8LDlDWe01iLT64MhMggNvkcNfE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__Uz6wizPYXzyj6Mm6SVpk", (CX::Int64)sbt__Uz6wizPYXzyj6Mm6SVpk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv", (CX::Int64)sbt_GpMvs5kTDMDgsoGcCyjV_9Cw1yv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk", (CX::Int64)sbt_S8Kzw8_1py5ro_0IchDSXLMQ26evcUTHnGcuKbnWlq7iCKqgmtYiGF3hqlKpiPk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a", (CX::Int64)sbt_XFi04fHmrhJpynh82Xtvawt8t8xc1G4AeImdhONeccMBNh82SziWfHUET_a)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp>::Type sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzpArray;

