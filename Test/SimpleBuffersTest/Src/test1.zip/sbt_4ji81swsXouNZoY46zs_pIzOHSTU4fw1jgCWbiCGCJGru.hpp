
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs;
	CX::Int32 sbt_Esb6oUj92gJNY0vu3;
	CX::IO::SimpleBuffers::BoolArray sbt_UfUV7mRwoBb;
	CX::Bool sbt_1RcOq;
	CX::IO::SimpleBuffers::BoolArray sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb;
	CX::UInt64 sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0;
	CX::IO::SimpleBuffers::StringArray sbt_nSSC483MYUzEC0Ool25jp1984;
	CX::Int64 sbt_g9uZ1GYBF0VklaNzo2f;
	CX::IO::SimpleBuffers::UInt32Array sbt_mU4YZzXanJsr2lCCamR1k;
	CX::UInt64 sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy;
	CX::UInt16 sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr;
	CX::IO::SimpleBuffers::UInt64Array sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R;
	CX::Bool sbt_WQa8Y;
	CX::UInt8 sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE;
	CX::IO::SimpleBuffers::UInt64Array sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm;
	CX::IO::SimpleBuffers::BoolArray sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx;
	CX::UInt32 sbt_UAAKTxzA5zNdL;
	CX::UInt32 sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO;
	CX::UInt32 sbt_y4FSrxtzpXt;
	CX::Int32 sbt_RkFDvdh;
	CX::IO::SimpleBuffers::BoolArray sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O;
	CX::Int16 sbt_7kQPW;
	CX::IO::SimpleBuffers::Int8Array sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW;
	CX::Int16 sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o;
	CX::String sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl;
	CX::IO::SimpleBuffers::BoolArray sbt_EWMYOtsRv9Gv3me;
	CX::Bool sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi;
	CX::UInt32 sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI;

	virtual void Reset()
	{
		sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.clear();
		sbt_Esb6oUj92gJNY0vu3 = 0;
		sbt_UfUV7mRwoBb.clear();
		sbt_1RcOq = false;
		sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.clear();
		sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0 = 0;
		sbt_nSSC483MYUzEC0Ool25jp1984.clear();
		sbt_g9uZ1GYBF0VklaNzo2f = 0;
		sbt_mU4YZzXanJsr2lCCamR1k.clear();
		sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy = 0;
		sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr = 0;
		sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.clear();
		sbt_WQa8Y = false;
		sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE = 0;
		sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.clear();
		sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.clear();
		sbt_UAAKTxzA5zNdL = 0;
		sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO = 0;
		sbt_y4FSrxtzpXt = 0;
		sbt_RkFDvdh = 0;
		sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.clear();
		sbt_7kQPW = 0;
		sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.clear();
		sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o = 0;
		sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl.clear();
		sbt_EWMYOtsRv9Gv3me.clear();
		sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi = false;
		sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.push_back(2866350906814707060);
		}
		sbt_Esb6oUj92gJNY0vu3 = -1479035656;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_UfUV7mRwoBb.push_back(true);
		}
		sbt_1RcOq = true;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.push_back(true);
		}
		sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0 = 10744945875710462806;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_nSSC483MYUzEC0Ool25jp1984.push_back("ETz(%)^u?#ij#M0cY?>qzUJh`>UQ'v5vXDooLtR:t;7'~<IX:m\\U-P|[aJ");
		}
		sbt_g9uZ1GYBF0VklaNzo2f = -2204228858117001936;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_mU4YZzXanJsr2lCCamR1k.push_back(4074672060);
		}
		sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy = 1602512827772717598;
		sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr = 45432;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.push_back(13933405568056724004);
		}
		sbt_WQa8Y = false;
		sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE = 130;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.push_back(207332343052677874);
		}
		sbt_UAAKTxzA5zNdL = 2294154417;
		sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO = 1497254682;
		sbt_y4FSrxtzpXt = 3988709401;
		sbt_RkFDvdh = -391089665;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.push_back(true);
		}
		sbt_7kQPW = 5029;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.push_back(9);
		}
		sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o = 18481;
		sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl = "p)N:\"4?)xCCF]qgJNW[A*X0dz>$k?";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_EWMYOtsRv9Gv3me.push_back(true);
		}
		sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi = true;
		sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI = 1060260549;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru *pObject = dynamic_cast<const sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.size() != pObject->sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.size(); i++)
		{
			if (sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs[i] != pObject->sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs[i])
			{
				return false;
			}
		}
		if (sbt_Esb6oUj92gJNY0vu3 != pObject->sbt_Esb6oUj92gJNY0vu3)
		{
			return false;
		}
		if (sbt_UfUV7mRwoBb.size() != pObject->sbt_UfUV7mRwoBb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UfUV7mRwoBb.size(); i++)
		{
			if (sbt_UfUV7mRwoBb[i] != pObject->sbt_UfUV7mRwoBb[i])
			{
				return false;
			}
		}
		if (sbt_1RcOq != pObject->sbt_1RcOq)
		{
			return false;
		}
		if (sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.size() != pObject->sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.size(); i++)
		{
			if (sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb[i] != pObject->sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb[i])
			{
				return false;
			}
		}
		if (sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0 != pObject->sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0)
		{
			return false;
		}
		if (sbt_nSSC483MYUzEC0Ool25jp1984.size() != pObject->sbt_nSSC483MYUzEC0Ool25jp1984.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nSSC483MYUzEC0Ool25jp1984.size(); i++)
		{
			if (0 != cx_strcmp(sbt_nSSC483MYUzEC0Ool25jp1984[i].c_str(), pObject->sbt_nSSC483MYUzEC0Ool25jp1984[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_g9uZ1GYBF0VklaNzo2f != pObject->sbt_g9uZ1GYBF0VklaNzo2f)
		{
			return false;
		}
		if (sbt_mU4YZzXanJsr2lCCamR1k.size() != pObject->sbt_mU4YZzXanJsr2lCCamR1k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mU4YZzXanJsr2lCCamR1k.size(); i++)
		{
			if (sbt_mU4YZzXanJsr2lCCamR1k[i] != pObject->sbt_mU4YZzXanJsr2lCCamR1k[i])
			{
				return false;
			}
		}
		if (sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy != pObject->sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy)
		{
			return false;
		}
		if (sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr != pObject->sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr)
		{
			return false;
		}
		if (sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.size() != pObject->sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.size(); i++)
		{
			if (sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R[i] != pObject->sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R[i])
			{
				return false;
			}
		}
		if (sbt_WQa8Y != pObject->sbt_WQa8Y)
		{
			return false;
		}
		if (sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE != pObject->sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE)
		{
			return false;
		}
		if (sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.size() != pObject->sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.size(); i++)
		{
			if (sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm[i] != pObject->sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm[i])
			{
				return false;
			}
		}
		if (sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.size() != pObject->sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.size(); i++)
		{
			if (sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx[i] != pObject->sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx[i])
			{
				return false;
			}
		}
		if (sbt_UAAKTxzA5zNdL != pObject->sbt_UAAKTxzA5zNdL)
		{
			return false;
		}
		if (sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO != pObject->sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO)
		{
			return false;
		}
		if (sbt_y4FSrxtzpXt != pObject->sbt_y4FSrxtzpXt)
		{
			return false;
		}
		if (sbt_RkFDvdh != pObject->sbt_RkFDvdh)
		{
			return false;
		}
		if (sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.size() != pObject->sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.size(); i++)
		{
			if (sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O[i] != pObject->sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O[i])
			{
				return false;
			}
		}
		if (sbt_7kQPW != pObject->sbt_7kQPW)
		{
			return false;
		}
		if (sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.size() != pObject->sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.size(); i++)
		{
			if (sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW[i] != pObject->sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW[i])
			{
				return false;
			}
		}
		if (sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o != pObject->sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl.c_str(), pObject->sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl.c_str()))
		{
			return false;
		}
		if (sbt_EWMYOtsRv9Gv3me.size() != pObject->sbt_EWMYOtsRv9Gv3me.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EWMYOtsRv9Gv3me.size(); i++)
		{
			if (sbt_EWMYOtsRv9Gv3me[i] != pObject->sbt_EWMYOtsRv9Gv3me[i])
			{
				return false;
			}
		}
		if (sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi != pObject->sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi)
		{
			return false;
		}
		if (sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI != pObject->sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Esb6oUj92gJNY0vu3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Esb6oUj92gJNY0vu3 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UfUV7mRwoBb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UfUV7mRwoBb.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_1RcOq", &sbt_1RcOq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_nSSC483MYUzEC0Ool25jp1984")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nSSC483MYUzEC0Ool25jp1984.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_g9uZ1GYBF0VklaNzo2f", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_g9uZ1GYBF0VklaNzo2f = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mU4YZzXanJsr2lCCamR1k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mU4YZzXanJsr2lCCamR1k.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_WQa8Y", &sbt_WQa8Y)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UAAKTxzA5zNdL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UAAKTxzA5zNdL = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_y4FSrxtzpXt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y4FSrxtzpXt = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RkFDvdh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RkFDvdh = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7kQPW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7kQPW = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl", &sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EWMYOtsRv9Gv3me")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EWMYOtsRv9Gv3me.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi", &sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.begin(); iter != sbt_dzXI7v0Zvj2DFjQAUvyziqa8BzKBs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Esb6oUj92gJNY0vu3", (CX::Int64)sbt_Esb6oUj92gJNY0vu3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UfUV7mRwoBb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_UfUV7mRwoBb.begin(); iter != sbt_UfUV7mRwoBb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_1RcOq", sbt_1RcOq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.begin(); iter != sbt_h6dScFBFc4z_xb9FOwgeKWL4oB_547S4CnUcAgknypiXACpnSg4uWzb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0", (CX::Int64)sbt_SCUTXvTEBRn0V5F9FuJzhA5vmXcwzWWeRN0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nSSC483MYUzEC0Ool25jp1984")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_nSSC483MYUzEC0Ool25jp1984.begin(); iter != sbt_nSSC483MYUzEC0Ool25jp1984.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_g9uZ1GYBF0VklaNzo2f", (CX::Int64)sbt_g9uZ1GYBF0VklaNzo2f)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mU4YZzXanJsr2lCCamR1k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_mU4YZzXanJsr2lCCamR1k.begin(); iter != sbt_mU4YZzXanJsr2lCCamR1k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy", (CX::Int64)sbt_HGm7TEOznsCHN_NYq5v6IOJyTkTAtTskdH0QVWy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr", (CX::Int64)sbt_a6ZCfz7PdTdhlb9Hm0xxZc6BbW2xCxCZYLUyWgIyxIlns0Z1Z671HSqZlAcQUkr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.begin(); iter != sbt_MRxHdYxK3ZwNUje8C_vX01AObUqHkMK2R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_WQa8Y", sbt_WQa8Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE", (CX::Int64)sbt_Oh_JCXf_VMTGqWQ3X4GNVhWEDLwWcq_sCclIE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.begin(); iter != sbt_B9LH13dOCrPLImYArx_7XnZqMrvc_2WU9nHpOSrXm18njA2IozmAaAVZm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.begin(); iter != sbt_7ghVYCF5aaV0XkBu6mBs2xO6xzjn42bd5DgKkFcGXyxv8Jx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UAAKTxzA5zNdL", (CX::Int64)sbt_UAAKTxzA5zNdL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO", (CX::Int64)sbt_acMDfUqTfRgRLcBrDaofZt8augwhFzioaDTFShshrftzahqtimO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y4FSrxtzpXt", (CX::Int64)sbt_y4FSrxtzpXt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RkFDvdh", (CX::Int64)sbt_RkFDvdh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.begin(); iter != sbt_WZqoYQ_k3Rn2V5ZvGFkmzH90O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7kQPW", (CX::Int64)sbt_7kQPW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.begin(); iter != sbt_oNkfKyYjVsIknrzg_O_uJaZzaiLkKqtLmq46jpVg9jdGHa5hL80aKSXtW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o", (CX::Int64)sbt_IGoYkDiyhUB5Ul5mrfrDXcTwq0g3SsNWcoCHlSfcX4w93sy5o)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl", sbt_SqPxWOJ2DPpKT8DAMcqTk5X5GGwTJTIhu86Qg4JEGYl.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EWMYOtsRv9Gv3me")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_EWMYOtsRv9Gv3me.begin(); iter != sbt_EWMYOtsRv9Gv3me.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi", sbt_kxyxfLg2N8NvTxkouesPMuBJbMTLZeA82lldi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI", (CX::Int64)sbt_MVyCak28Y4fx1CdyuqFARJn7unyxPZu318ajYq7E9uw1mPOpml0FKqPv5yI)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru>::Type sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGruArray;

