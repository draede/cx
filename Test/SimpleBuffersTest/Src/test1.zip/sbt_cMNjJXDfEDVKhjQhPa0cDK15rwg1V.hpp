
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_wWXXUR8;
	CX::UInt32 sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS;
	CX::IO::SimpleBuffers::Int16Array sbt_EXsWmw6Fk;
	CX::UInt64 sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ;
	CX::Int16 sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3;
	CX::IO::SimpleBuffers::UInt32Array sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza;
	CX::IO::SimpleBuffers::UInt64Array sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY;
	CX::IO::SimpleBuffers::Int8Array sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5;
	CX::UInt8 sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp;
	CX::IO::SimpleBuffers::Int64Array sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh;
	CX::IO::SimpleBuffers::UInt32Array sbt_lxx7PVia7qHjfqIkZmCfVKAcu;
	CX::Int8 sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo;
	CX::Int64 sbt_imlKm5Diid7_W1ZolmIB8l8;
	CX::UInt8 sbt_mzjaonuQNBf0B;
	CX::UInt32 sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC;
	CX::IO::SimpleBuffers::StringArray sbt_nxkY2Gx9vqkec;

	virtual void Reset()
	{
		sbt_wWXXUR8 = 0;
		sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS = 0;
		sbt_EXsWmw6Fk.clear();
		sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ = 0;
		sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3 = 0;
		sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.clear();
		sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.clear();
		sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.clear();
		sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp = 0;
		sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.clear();
		sbt_lxx7PVia7qHjfqIkZmCfVKAcu.clear();
		sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo = 0;
		sbt_imlKm5Diid7_W1ZolmIB8l8 = 0;
		sbt_mzjaonuQNBf0B = 0;
		sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC = 0;
		sbt_nxkY2Gx9vqkec.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_wWXXUR8 = -1858563694;
		sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS = 2126372638;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_EXsWmw6Fk.push_back(-7165);
		}
		sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ = 10250429989680928838;
		sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3 = -19371;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.push_back(2841173011);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.push_back(11163171499744517200);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.push_back(104);
		}
		sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp = 182;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.push_back(-7222574422519073718);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lxx7PVia7qHjfqIkZmCfVKAcu.push_back(2253047499);
		}
		sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo = -11;
		sbt_imlKm5Diid7_W1ZolmIB8l8 = -8069228505378647422;
		sbt_mzjaonuQNBf0B = 229;
		sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC = 2974872770;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_nxkY2Gx9vqkec.push_back("$-&R@NTtzKmZsDC}:m1S_P>s4I#DCLQC/V;0LJv0#it");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V *pObject = dynamic_cast<const sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wWXXUR8 != pObject->sbt_wWXXUR8)
		{
			return false;
		}
		if (sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS != pObject->sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS)
		{
			return false;
		}
		if (sbt_EXsWmw6Fk.size() != pObject->sbt_EXsWmw6Fk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EXsWmw6Fk.size(); i++)
		{
			if (sbt_EXsWmw6Fk[i] != pObject->sbt_EXsWmw6Fk[i])
			{
				return false;
			}
		}
		if (sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ != pObject->sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ)
		{
			return false;
		}
		if (sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3 != pObject->sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3)
		{
			return false;
		}
		if (sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.size() != pObject->sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.size(); i++)
		{
			if (sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza[i] != pObject->sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza[i])
			{
				return false;
			}
		}
		if (sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.size() != pObject->sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.size(); i++)
		{
			if (sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY[i] != pObject->sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY[i])
			{
				return false;
			}
		}
		if (sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.size() != pObject->sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.size(); i++)
		{
			if (sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5[i] != pObject->sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5[i])
			{
				return false;
			}
		}
		if (sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp != pObject->sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp)
		{
			return false;
		}
		if (sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.size() != pObject->sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.size(); i++)
		{
			if (sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh[i] != pObject->sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh[i])
			{
				return false;
			}
		}
		if (sbt_lxx7PVia7qHjfqIkZmCfVKAcu.size() != pObject->sbt_lxx7PVia7qHjfqIkZmCfVKAcu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lxx7PVia7qHjfqIkZmCfVKAcu.size(); i++)
		{
			if (sbt_lxx7PVia7qHjfqIkZmCfVKAcu[i] != pObject->sbt_lxx7PVia7qHjfqIkZmCfVKAcu[i])
			{
				return false;
			}
		}
		if (sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo != pObject->sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo)
		{
			return false;
		}
		if (sbt_imlKm5Diid7_W1ZolmIB8l8 != pObject->sbt_imlKm5Diid7_W1ZolmIB8l8)
		{
			return false;
		}
		if (sbt_mzjaonuQNBf0B != pObject->sbt_mzjaonuQNBf0B)
		{
			return false;
		}
		if (sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC != pObject->sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC)
		{
			return false;
		}
		if (sbt_nxkY2Gx9vqkec.size() != pObject->sbt_nxkY2Gx9vqkec.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nxkY2Gx9vqkec.size(); i++)
		{
			if (0 != cx_strcmp(sbt_nxkY2Gx9vqkec[i].c_str(), pObject->sbt_nxkY2Gx9vqkec[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_wWXXUR8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wWXXUR8 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EXsWmw6Fk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EXsWmw6Fk.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lxx7PVia7qHjfqIkZmCfVKAcu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lxx7PVia7qHjfqIkZmCfVKAcu.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_imlKm5Diid7_W1ZolmIB8l8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_imlKm5Diid7_W1ZolmIB8l8 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mzjaonuQNBf0B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mzjaonuQNBf0B = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_nxkY2Gx9vqkec")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nxkY2Gx9vqkec.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_wWXXUR8", (CX::Int64)sbt_wWXXUR8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS", (CX::Int64)sbt_ov67D3toX91D4YLn2MyeSe8XWNQoiJdQbm4FVB_XS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EXsWmw6Fk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_EXsWmw6Fk.begin(); iter != sbt_EXsWmw6Fk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ", (CX::Int64)sbt_T05xued3ZngpeHWjEt8Rc6pdHWZtn5JdLXZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3", (CX::Int64)sbt_GEtVXRYkVjiPtxWBaoqFuCr_tE0qEE3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.begin(); iter != sbt_LWNmkpxzLqudy73U7UbpRnRSAOCw7flL4KBYxOzFvMd_csRZw450ZKO3Kza.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.begin(); iter != sbt_e50kGcmnTZWF8gXl_r8r2exoa5pM_rDZ1TDtly76azO1vnY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.begin(); iter != sbt_8vK_zxjHu5QMjj3REiWCk_OnVzBs_6PCbIft5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp", (CX::Int64)sbt_MT3iClbryHsBH0jrOWr57wLJH3oVnZ_daO19spPnXGHXxb4dp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.begin(); iter != sbt_SnXv9rInnhDTTfEDPEcj29mrVVGaWzloRV_M71QAh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lxx7PVia7qHjfqIkZmCfVKAcu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lxx7PVia7qHjfqIkZmCfVKAcu.begin(); iter != sbt_lxx7PVia7qHjfqIkZmCfVKAcu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo", (CX::Int64)sbt_1jYbxzaKwx9ZZ75O9UtCwOCtlb6xCLGqFnpfDMo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_imlKm5Diid7_W1ZolmIB8l8", (CX::Int64)sbt_imlKm5Diid7_W1ZolmIB8l8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mzjaonuQNBf0B", (CX::Int64)sbt_mzjaonuQNBf0B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC", (CX::Int64)sbt_RstXHbpkJHpSwq1veWakx_r0XKqxslgNcQfNq07N1jeGsIrHKMjC3BgBJtC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nxkY2Gx9vqkec")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_nxkY2Gx9vqkec.begin(); iter != sbt_nxkY2Gx9vqkec.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V>::Type sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1VArray;

