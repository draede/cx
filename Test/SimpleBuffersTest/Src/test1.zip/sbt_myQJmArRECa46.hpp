
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos.hpp"


class sbt_myQJmArRECa46 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE;
	CX::UInt8 sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn;
	CX::IO::SimpleBuffers::UInt32Array sbt_I9ZyjH3Ye_FDHuCv1mZ;
	CX::UInt16 sbt_2cAR5ei8pDjapXasvj0tm;
	CX::Bool sbt_YnjdU;
	CX::IO::SimpleBuffers::StringArray sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g;
	CX::Double sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55;
	CX::Int64 sbt_9Beu02mQeSZrgjKU0Om;
	CX::IO::SimpleBuffers::FloatArray sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt;
	CX::String sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV;
	CX::IO::SimpleBuffers::DoubleArray sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix;
	CX::Float sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9;
	CX::IO::SimpleBuffers::UInt32Array sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6;
	CX::Int32 sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI;
	CX::UInt16 sbt_csLqzI44RvjDL;
	CX::UInt32 sbt_N;
	CX::IO::SimpleBuffers::Int16Array sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx;
	CX::IO::SimpleBuffers::StringArray sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94;
	CX::IO::SimpleBuffers::UInt64Array sbt_7LbfarVn0kQg8dLgjcW8SfI;
	CX::IO::SimpleBuffers::Int32Array sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04;
	CX::UInt32 sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ;
	CX::IO::SimpleBuffers::WStringArray sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX;
	CX::Int8 sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r;
	sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBosArray sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5;

	virtual void Reset()
	{
		sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.clear();
		sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn = 0;
		sbt_I9ZyjH3Ye_FDHuCv1mZ.clear();
		sbt_2cAR5ei8pDjapXasvj0tm = 0;
		sbt_YnjdU = false;
		sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.clear();
		sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55 = 0.0;
		sbt_9Beu02mQeSZrgjKU0Om = 0;
		sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.clear();
		sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV.clear();
		sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.clear();
		sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9 = 0.0f;
		sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.clear();
		sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI = 0;
		sbt_csLqzI44RvjDL = 0;
		sbt_N = 0;
		sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.clear();
		sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.clear();
		sbt_7LbfarVn0kQg8dLgjcW8SfI.clear();
		sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.clear();
		sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ = 0;
		sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.clear();
		sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r = 0;
		sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.push_back(-3713034808125387172);
		}
		sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn = 252;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_I9ZyjH3Ye_FDHuCv1mZ.push_back(3657589509);
		}
		sbt_2cAR5ei8pDjapXasvj0tm = 46511;
		sbt_YnjdU = true;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.push_back("s-(~^\"6d<1#$I,M'fdHaBDn7\"K}71d'\\'(XiexSOpa&G4k.v2M%\"LE:#>A");
		}
		sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55 = 0.813755;
		sbt_9Beu02mQeSZrgjKU0Om = -7727980573539381688;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.push_back(0.108040f);
		}
		sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV = "]!EMW~J^+W`=[!_(S[>:Y`cwH1/vN-GWpF+NVCavjQInVW7Q8S6}d*b=/dc3o^x";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.push_back(0.861682);
		}
		sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9 = 0.804916f;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.push_back(893119417);
		}
		sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI = -1151307703;
		sbt_csLqzI44RvjDL = 28807;
		sbt_N = 3802988299;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.push_back(4679);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.push_back("?ozix4mf94&/-\"eEj&4e_V8PuX-'n9\\qUSIFo@");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_7LbfarVn0kQg8dLgjcW8SfI.push_back(16292563494154875142);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.push_back(-1958977425);
		}
		sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ = 2770201185;
		sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r = -31;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos v;

			v.SetupWithSomeValues();
			sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_myQJmArRECa46 *pObject = dynamic_cast<const sbt_myQJmArRECa46 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.size() != pObject->sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.size(); i++)
		{
			if (sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE[i] != pObject->sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE[i])
			{
				return false;
			}
		}
		if (sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn != pObject->sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn)
		{
			return false;
		}
		if (sbt_I9ZyjH3Ye_FDHuCv1mZ.size() != pObject->sbt_I9ZyjH3Ye_FDHuCv1mZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I9ZyjH3Ye_FDHuCv1mZ.size(); i++)
		{
			if (sbt_I9ZyjH3Ye_FDHuCv1mZ[i] != pObject->sbt_I9ZyjH3Ye_FDHuCv1mZ[i])
			{
				return false;
			}
		}
		if (sbt_2cAR5ei8pDjapXasvj0tm != pObject->sbt_2cAR5ei8pDjapXasvj0tm)
		{
			return false;
		}
		if (sbt_YnjdU != pObject->sbt_YnjdU)
		{
			return false;
		}
		if (sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.size() != pObject->sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.size(); i++)
		{
			if (0 != cx_strcmp(sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g[i].c_str(), pObject->sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55 != pObject->sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55)
		{
			return false;
		}
		if (sbt_9Beu02mQeSZrgjKU0Om != pObject->sbt_9Beu02mQeSZrgjKU0Om)
		{
			return false;
		}
		if (sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.size() != pObject->sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.size(); i++)
		{
			if (sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt[i] != pObject->sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV.c_str(), pObject->sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV.c_str()))
		{
			return false;
		}
		if (sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.size() != pObject->sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.size(); i++)
		{
			if (sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix[i] != pObject->sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix[i])
			{
				return false;
			}
		}
		if (sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9 != pObject->sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9)
		{
			return false;
		}
		if (sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.size() != pObject->sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.size(); i++)
		{
			if (sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6[i] != pObject->sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6[i])
			{
				return false;
			}
		}
		if (sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI != pObject->sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI)
		{
			return false;
		}
		if (sbt_csLqzI44RvjDL != pObject->sbt_csLqzI44RvjDL)
		{
			return false;
		}
		if (sbt_N != pObject->sbt_N)
		{
			return false;
		}
		if (sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.size() != pObject->sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.size(); i++)
		{
			if (sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx[i] != pObject->sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx[i])
			{
				return false;
			}
		}
		if (sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.size() != pObject->sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.size(); i++)
		{
			if (0 != cx_strcmp(sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94[i].c_str(), pObject->sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_7LbfarVn0kQg8dLgjcW8SfI.size() != pObject->sbt_7LbfarVn0kQg8dLgjcW8SfI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7LbfarVn0kQg8dLgjcW8SfI.size(); i++)
		{
			if (sbt_7LbfarVn0kQg8dLgjcW8SfI[i] != pObject->sbt_7LbfarVn0kQg8dLgjcW8SfI[i])
			{
				return false;
			}
		}
		if (sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.size() != pObject->sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.size(); i++)
		{
			if (sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04[i] != pObject->sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04[i])
			{
				return false;
			}
		}
		if (sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ != pObject->sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ)
		{
			return false;
		}
		if (sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.size() != pObject->sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX[i].c_str(), pObject->sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r != pObject->sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r)
		{
			return false;
		}
		if (sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.size() != pObject->sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.size(); i++)
		{
			if (!sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5[i].Compare(&pObject->sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_I9ZyjH3Ye_FDHuCv1mZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I9ZyjH3Ye_FDHuCv1mZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2cAR5ei8pDjapXasvj0tm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2cAR5ei8pDjapXasvj0tm = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_YnjdU", &sbt_YnjdU)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55 = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_9Beu02mQeSZrgjKU0Om", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9Beu02mQeSZrgjKU0Om = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV", &sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_csLqzI44RvjDL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_csLqzI44RvjDL = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7LbfarVn0kQg8dLgjcW8SfI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7LbfarVn0kQg8dLgjcW8SfI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.begin(); iter != sbt_UNh7C96sVeW9bw4LLlFiDPL_Jn24cAjgE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn", (CX::Int64)sbt_SlUowAMq1wTeR95sxhTOmWOyilSX76aN2EADPVWemWpYn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I9ZyjH3Ye_FDHuCv1mZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_I9ZyjH3Ye_FDHuCv1mZ.begin(); iter != sbt_I9ZyjH3Ye_FDHuCv1mZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2cAR5ei8pDjapXasvj0tm", (CX::Int64)sbt_2cAR5ei8pDjapXasvj0tm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_YnjdU", sbt_YnjdU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.begin(); iter != sbt_WqB668AtHA4SIzHzpeBXIpJ2DCB8_qpDO7g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55", (CX::Double)sbt_OLW8Wq8wpVBsH3JBh_MhTW98xzpbkf9TALbnghKmrJr55)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9Beu02mQeSZrgjKU0Om", (CX::Int64)sbt_9Beu02mQeSZrgjKU0Om)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.begin(); iter != sbt_MOOyre2N7F0e7B5XTuJoYbLLiOZwduDz_jSivoZorEZBTtt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV", sbt_EgLIK9LGtTQg9Wo1d37XEBCoNuZf4tMagHOxJjV.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.begin(); iter != sbt_KJ_WJxaRQ3L9a5AWDC1mDq_stX_EmqVpmZykAupBpRzyxlTCJQ5ix.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9", (CX::Double)sbt_srA471V4Frf6Ue8gIkPH7cigrNnPuufnXhTPnVdBa0Zfp5Ob_Yjw9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.begin(); iter != sbt_LrPZloRdzFdOkPxe0fbRjcd5RLzn_DobZAMkdHBdIsGXYDQ2RCz1CYkx6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI", (CX::Int64)sbt_N3BE8ncHseHHcshIti4ybIyrn50_jDZjI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_csLqzI44RvjDL", (CX::Int64)sbt_csLqzI44RvjDL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N", (CX::Int64)sbt_N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.begin(); iter != sbt_kfucGkRC15Ru9mcD3UJ_beSpEizSJKx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.begin(); iter != sbt_UsxzK8xpU14I65hA2Neu_CUL5raf4INBV94.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7LbfarVn0kQg8dLgjcW8SfI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_7LbfarVn0kQg8dLgjcW8SfI.begin(); iter != sbt_7LbfarVn0kQg8dLgjcW8SfI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.begin(); iter != sbt_eg08g8G2i5PpcBKDWIB8dM4r35FQrdfFVafOtUBSGhGAZthiPD90UUw04.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ", (CX::Int64)sbt_L2l9jfeJzMweg8odIWZaTSfWbLHZAecQqbQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.begin(); iter != sbt_0_jTWW5zjtLjtdstaZtpUXi1BaX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r", (CX::Int64)sbt_OLKxaccGM9rlRFo1XzPMwZ8BGKqOy3VvIlswo3ZbOJJ31yo5r)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5")).IsNOK())
		{
			return status;
		}
		for (sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBosArray::const_iterator iter = sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.begin(); iter != sbt_HDnEPYZKpoJC_NwXpajcCS9OEJeLrBvJXA9b6Fet5mTCe78d_Q5.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_myQJmArRECa46>::Type sbt_myQJmArRECa46Array;

