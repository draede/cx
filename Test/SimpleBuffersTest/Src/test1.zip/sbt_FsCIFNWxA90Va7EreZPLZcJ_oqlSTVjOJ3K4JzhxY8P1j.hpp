
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq;
	CX::UInt8 sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G;
	CX::IO::SimpleBuffers::UInt16Array sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD;
	CX::IO::SimpleBuffers::UInt8Array sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE;
	CX::Int32 sbt_IjeO95QHdsWxvgvo8iiLf;
	CX::IO::SimpleBuffers::UInt32Array sbt_QB51z__tan0__PkgQLroLPEOG;
	CX::IO::SimpleBuffers::Int16Array sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7;
	CX::IO::SimpleBuffers::UInt64Array sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO;
	CX::IO::SimpleBuffers::UInt8Array sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K;
	CX::IO::SimpleBuffers::UInt64Array sbt_0b_L5pv7OQiWsV9tzZiLRUf;
	CX::Int8 sbt_bit834hqTSQgcqaDD;
	CX::Int32 sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5;
	CX::Bool sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B;
	CX::IO::SimpleBuffers::Int16Array sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS;
	CX::IO::SimpleBuffers::UInt32Array sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW;

	virtual void Reset()
	{
		sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.clear();
		sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G = 0;
		sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.clear();
		sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.clear();
		sbt_IjeO95QHdsWxvgvo8iiLf = 0;
		sbt_QB51z__tan0__PkgQLroLPEOG.clear();
		sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.clear();
		sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.clear();
		sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.clear();
		sbt_0b_L5pv7OQiWsV9tzZiLRUf.clear();
		sbt_bit834hqTSQgcqaDD = 0;
		sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5 = 0;
		sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B = false;
		sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.clear();
		sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.push_back(false);
		}
		sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G = 90;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.push_back(28155);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.push_back(161);
		}
		sbt_IjeO95QHdsWxvgvo8iiLf = 1564255659;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_QB51z__tan0__PkgQLroLPEOG.push_back(273097070);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.push_back(-26057);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.push_back(10484534883323635382);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.push_back(131);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_0b_L5pv7OQiWsV9tzZiLRUf.push_back(17321529965488493260);
		}
		sbt_bit834hqTSQgcqaDD = 60;
		sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5 = 1118870575;
		sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B = false;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.push_back(10813);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.push_back(2651209836);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j *pObject = dynamic_cast<const sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.size() != pObject->sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.size(); i++)
		{
			if (sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq[i] != pObject->sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq[i])
			{
				return false;
			}
		}
		if (sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G != pObject->sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G)
		{
			return false;
		}
		if (sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.size() != pObject->sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.size(); i++)
		{
			if (sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD[i] != pObject->sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD[i])
			{
				return false;
			}
		}
		if (sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.size() != pObject->sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.size(); i++)
		{
			if (sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE[i] != pObject->sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE[i])
			{
				return false;
			}
		}
		if (sbt_IjeO95QHdsWxvgvo8iiLf != pObject->sbt_IjeO95QHdsWxvgvo8iiLf)
		{
			return false;
		}
		if (sbt_QB51z__tan0__PkgQLroLPEOG.size() != pObject->sbt_QB51z__tan0__PkgQLroLPEOG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QB51z__tan0__PkgQLroLPEOG.size(); i++)
		{
			if (sbt_QB51z__tan0__PkgQLroLPEOG[i] != pObject->sbt_QB51z__tan0__PkgQLroLPEOG[i])
			{
				return false;
			}
		}
		if (sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.size() != pObject->sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.size(); i++)
		{
			if (sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7[i] != pObject->sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7[i])
			{
				return false;
			}
		}
		if (sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.size() != pObject->sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.size(); i++)
		{
			if (sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO[i] != pObject->sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO[i])
			{
				return false;
			}
		}
		if (sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.size() != pObject->sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.size(); i++)
		{
			if (sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K[i] != pObject->sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K[i])
			{
				return false;
			}
		}
		if (sbt_0b_L5pv7OQiWsV9tzZiLRUf.size() != pObject->sbt_0b_L5pv7OQiWsV9tzZiLRUf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0b_L5pv7OQiWsV9tzZiLRUf.size(); i++)
		{
			if (sbt_0b_L5pv7OQiWsV9tzZiLRUf[i] != pObject->sbt_0b_L5pv7OQiWsV9tzZiLRUf[i])
			{
				return false;
			}
		}
		if (sbt_bit834hqTSQgcqaDD != pObject->sbt_bit834hqTSQgcqaDD)
		{
			return false;
		}
		if (sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5 != pObject->sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5)
		{
			return false;
		}
		if (sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B != pObject->sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B)
		{
			return false;
		}
		if (sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.size() != pObject->sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.size(); i++)
		{
			if (sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS[i] != pObject->sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS[i])
			{
				return false;
			}
		}
		if (sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.size() != pObject->sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.size(); i++)
		{
			if (sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW[i] != pObject->sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IjeO95QHdsWxvgvo8iiLf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IjeO95QHdsWxvgvo8iiLf = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_QB51z__tan0__PkgQLroLPEOG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QB51z__tan0__PkgQLroLPEOG.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0b_L5pv7OQiWsV9tzZiLRUf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0b_L5pv7OQiWsV9tzZiLRUf.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bit834hqTSQgcqaDD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bit834hqTSQgcqaDD = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B", &sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.begin(); iter != sbt_Z0Q3n4K8z6KP6FNCzFLSxHSZSXq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G", (CX::Int64)sbt_PEd3pyYS38i87mysXHntKBuhUsAKyd04pQAzT0v10sz3BtM2G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.begin(); iter != sbt_bIKRTngV2cxqGpar5q8tJxJWl81osv4GQMLVD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.begin(); iter != sbt_Im1PlK67wtq7tM7TZudkweFcxBb4K6iX3B39ug4VNwGL2pPGboE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IjeO95QHdsWxvgvo8iiLf", (CX::Int64)sbt_IjeO95QHdsWxvgvo8iiLf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QB51z__tan0__PkgQLroLPEOG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QB51z__tan0__PkgQLroLPEOG.begin(); iter != sbt_QB51z__tan0__PkgQLroLPEOG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.begin(); iter != sbt_pTLKvnWr8bcKmhPvWvVcBy9wZf6e7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.begin(); iter != sbt_aeIN8HFbj5jorDhfkdRyJ7TYhVfWKZx1PInOCY7ZdUOuto8QaNsv2UhVwZO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.begin(); iter != sbt_jr0hhmNWo5hpdx64BY4df_5w6SglyZVizt3SxOu6K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0b_L5pv7OQiWsV9tzZiLRUf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_0b_L5pv7OQiWsV9tzZiLRUf.begin(); iter != sbt_0b_L5pv7OQiWsV9tzZiLRUf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bit834hqTSQgcqaDD", (CX::Int64)sbt_bit834hqTSQgcqaDD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5", (CX::Int64)sbt_rWZQmenx71pI706pIqbLHXcNjCsxCfyZ207qxBfsWpjL3IiXLb1JS_5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B", sbt_yOBHTDJAYh5WdzNjz1K_j0QHu1B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.begin(); iter != sbt_MgNBMwEvEM7iPh_BZUX3o0oOkSWqjiS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.begin(); iter != sbt_waCDk2rvQYIl5EhRUuTAsTeqBsFIW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j>::Type sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1jArray;

