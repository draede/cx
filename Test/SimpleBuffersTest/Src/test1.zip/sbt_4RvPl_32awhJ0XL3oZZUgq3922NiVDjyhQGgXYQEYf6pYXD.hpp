
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_5lCZz6s7wDo.hpp"


class sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7;
	CX::UInt16 sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA;
	CX::IO::SimpleBuffers::Int16Array sbt_mhh29Xoe30e;
	CX::IO::SimpleBuffers::UInt32Array sbt_knWZA6grjolxF1E1_Agde;
	CX::UInt8 sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T;
	CX::IO::SimpleBuffers::WStringArray sbt_8hl4gLlJ4OLNpR98f;
	CX::IO::SimpleBuffers::UInt32Array sbt_j5Y8vw67Hh9mYlv;
	CX::Int64 sbt_obOxebytd;
	CX::Int16 sbt_zZo3lhMrKfmrJdhpawDYhep;
	CX::Int64 sbt_GHw;
	CX::String sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG;
	CX::IO::SimpleBuffers::DoubleArray sbt_SVqWtCZ;
	CX::IO::SimpleBuffers::BoolArray sbt_sL15J9Xm0y2aJkF_1ze12ZQ;
	CX::IO::SimpleBuffers::WStringArray sbt_RoshNY8YPgwzx6_EIFAoHUK;
	CX::UInt32 sbt_N;
	CX::Double sbt_2LgNzMwGf7Pi_Dv;
	CX::Bool sbt_ndMyt;
	CX::IO::SimpleBuffers::Int32Array sbt_Em4T5dfI_e_cKyE;
	CX::IO::SimpleBuffers::UInt32Array sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN;
	CX::Int32 sbt_71dkjM5xELw276SJIn8OS;
	CX::IO::SimpleBuffers::StringArray sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7;
	CX::IO::SimpleBuffers::Int8Array sbt_ruxvQbonkaz;
	CX::IO::SimpleBuffers::FloatArray sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV;
	sbt_5lCZz6s7wDo sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu;

	virtual void Reset()
	{
		sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7 = 0;
		sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA = 0;
		sbt_mhh29Xoe30e.clear();
		sbt_knWZA6grjolxF1E1_Agde.clear();
		sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T = 0;
		sbt_8hl4gLlJ4OLNpR98f.clear();
		sbt_j5Y8vw67Hh9mYlv.clear();
		sbt_obOxebytd = 0;
		sbt_zZo3lhMrKfmrJdhpawDYhep = 0;
		sbt_GHw = 0;
		sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG.clear();
		sbt_SVqWtCZ.clear();
		sbt_sL15J9Xm0y2aJkF_1ze12ZQ.clear();
		sbt_RoshNY8YPgwzx6_EIFAoHUK.clear();
		sbt_N = 0;
		sbt_2LgNzMwGf7Pi_Dv = 0.0;
		sbt_ndMyt = false;
		sbt_Em4T5dfI_e_cKyE.clear();
		sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.clear();
		sbt_71dkjM5xELw276SJIn8OS = 0;
		sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.clear();
		sbt_ruxvQbonkaz.clear();
		sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.clear();
		sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7 = 1779115106;
		sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA = 14325;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_knWZA6grjolxF1E1_Agde.push_back(2540390986);
		}
		sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T = 37;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_8hl4gLlJ4OLNpR98f.push_back(L"zpBm`{y|O\"@99UCEn\\5fWO");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_j5Y8vw67Hh9mYlv.push_back(389851070);
		}
		sbt_obOxebytd = 3812284221487102858;
		sbt_zZo3lhMrKfmrJdhpawDYhep = -14982;
		sbt_GHw = 1172780090722444172;
		sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG = "[?hL]]JGG!s$Y<6*V:?2U48MGzB&9Q";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_SVqWtCZ.push_back(0.879562);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_sL15J9Xm0y2aJkF_1ze12ZQ.push_back(false);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_RoshNY8YPgwzx6_EIFAoHUK.push_back(L"*,wC#");
		}
		sbt_N = 2625732099;
		sbt_2LgNzMwGf7Pi_Dv = 0.182673;
		sbt_ndMyt = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_Em4T5dfI_e_cKyE.push_back(-75948123);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.push_back(3573087843);
		}
		sbt_71dkjM5xELw276SJIn8OS = 2047319212;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.push_back("45`dXRnnLt9iouuEM\"'*be0A`X$");
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_ruxvQbonkaz.push_back(-2);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.push_back(0.062716f);
		}
		sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD *pObject = dynamic_cast<const sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7 != pObject->sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7)
		{
			return false;
		}
		if (sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA != pObject->sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA)
		{
			return false;
		}
		if (sbt_mhh29Xoe30e.size() != pObject->sbt_mhh29Xoe30e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mhh29Xoe30e.size(); i++)
		{
			if (sbt_mhh29Xoe30e[i] != pObject->sbt_mhh29Xoe30e[i])
			{
				return false;
			}
		}
		if (sbt_knWZA6grjolxF1E1_Agde.size() != pObject->sbt_knWZA6grjolxF1E1_Agde.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_knWZA6grjolxF1E1_Agde.size(); i++)
		{
			if (sbt_knWZA6grjolxF1E1_Agde[i] != pObject->sbt_knWZA6grjolxF1E1_Agde[i])
			{
				return false;
			}
		}
		if (sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T != pObject->sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T)
		{
			return false;
		}
		if (sbt_8hl4gLlJ4OLNpR98f.size() != pObject->sbt_8hl4gLlJ4OLNpR98f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8hl4gLlJ4OLNpR98f.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_8hl4gLlJ4OLNpR98f[i].c_str(), pObject->sbt_8hl4gLlJ4OLNpR98f[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_j5Y8vw67Hh9mYlv.size() != pObject->sbt_j5Y8vw67Hh9mYlv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j5Y8vw67Hh9mYlv.size(); i++)
		{
			if (sbt_j5Y8vw67Hh9mYlv[i] != pObject->sbt_j5Y8vw67Hh9mYlv[i])
			{
				return false;
			}
		}
		if (sbt_obOxebytd != pObject->sbt_obOxebytd)
		{
			return false;
		}
		if (sbt_zZo3lhMrKfmrJdhpawDYhep != pObject->sbt_zZo3lhMrKfmrJdhpawDYhep)
		{
			return false;
		}
		if (sbt_GHw != pObject->sbt_GHw)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG.c_str(), pObject->sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG.c_str()))
		{
			return false;
		}
		if (sbt_SVqWtCZ.size() != pObject->sbt_SVqWtCZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SVqWtCZ.size(); i++)
		{
			if (sbt_SVqWtCZ[i] != pObject->sbt_SVqWtCZ[i])
			{
				return false;
			}
		}
		if (sbt_sL15J9Xm0y2aJkF_1ze12ZQ.size() != pObject->sbt_sL15J9Xm0y2aJkF_1ze12ZQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sL15J9Xm0y2aJkF_1ze12ZQ.size(); i++)
		{
			if (sbt_sL15J9Xm0y2aJkF_1ze12ZQ[i] != pObject->sbt_sL15J9Xm0y2aJkF_1ze12ZQ[i])
			{
				return false;
			}
		}
		if (sbt_RoshNY8YPgwzx6_EIFAoHUK.size() != pObject->sbt_RoshNY8YPgwzx6_EIFAoHUK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RoshNY8YPgwzx6_EIFAoHUK.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_RoshNY8YPgwzx6_EIFAoHUK[i].c_str(), pObject->sbt_RoshNY8YPgwzx6_EIFAoHUK[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_N != pObject->sbt_N)
		{
			return false;
		}
		if (sbt_2LgNzMwGf7Pi_Dv != pObject->sbt_2LgNzMwGf7Pi_Dv)
		{
			return false;
		}
		if (sbt_ndMyt != pObject->sbt_ndMyt)
		{
			return false;
		}
		if (sbt_Em4T5dfI_e_cKyE.size() != pObject->sbt_Em4T5dfI_e_cKyE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Em4T5dfI_e_cKyE.size(); i++)
		{
			if (sbt_Em4T5dfI_e_cKyE[i] != pObject->sbt_Em4T5dfI_e_cKyE[i])
			{
				return false;
			}
		}
		if (sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.size() != pObject->sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.size(); i++)
		{
			if (sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN[i] != pObject->sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN[i])
			{
				return false;
			}
		}
		if (sbt_71dkjM5xELw276SJIn8OS != pObject->sbt_71dkjM5xELw276SJIn8OS)
		{
			return false;
		}
		if (sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.size() != pObject->sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.size(); i++)
		{
			if (0 != cx_strcmp(sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7[i].c_str(), pObject->sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ruxvQbonkaz.size() != pObject->sbt_ruxvQbonkaz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ruxvQbonkaz.size(); i++)
		{
			if (sbt_ruxvQbonkaz[i] != pObject->sbt_ruxvQbonkaz[i])
			{
				return false;
			}
		}
		if (sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.size() != pObject->sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.size(); i++)
		{
			if (sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV[i] != pObject->sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV[i])
			{
				return false;
			}
		}
		if (!sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu.Compare(&pObject->sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mhh29Xoe30e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mhh29Xoe30e.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_knWZA6grjolxF1E1_Agde")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_knWZA6grjolxF1E1_Agde.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8hl4gLlJ4OLNpR98f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8hl4gLlJ4OLNpR98f.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j5Y8vw67Hh9mYlv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j5Y8vw67Hh9mYlv.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_obOxebytd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_obOxebytd = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zZo3lhMrKfmrJdhpawDYhep", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zZo3lhMrKfmrJdhpawDYhep = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GHw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GHw = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG", &sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SVqWtCZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SVqWtCZ.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sL15J9Xm0y2aJkF_1ze12ZQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sL15J9Xm0y2aJkF_1ze12ZQ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RoshNY8YPgwzx6_EIFAoHUK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RoshNY8YPgwzx6_EIFAoHUK.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_2LgNzMwGf7Pi_Dv", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_2LgNzMwGf7Pi_Dv = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_ndMyt", &sbt_ndMyt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Em4T5dfI_e_cKyE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Em4T5dfI_e_cKyE.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_71dkjM5xELw276SJIn8OS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_71dkjM5xELw276SJIn8OS = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ruxvQbonkaz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ruxvQbonkaz.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7", (CX::Int64)sbt_dv9Dx99kkG4mnaGbpPVD5mWmBLo81aCVzN_TsW7O_Igcj5iloI898_b0HioYZh7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA", (CX::Int64)sbt_0_W5FZe2LGSZNVniy0Tad4DkvbCcgiw6FeEjNzcCVrz4VgA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mhh29Xoe30e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_mhh29Xoe30e.begin(); iter != sbt_mhh29Xoe30e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_knWZA6grjolxF1E1_Agde")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_knWZA6grjolxF1E1_Agde.begin(); iter != sbt_knWZA6grjolxF1E1_Agde.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T", (CX::Int64)sbt_PFvhSWIewgQTDBuqEgOaf3PhJQ9QXYhZQxOnnNM0fIdHmgC4a4T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8hl4gLlJ4OLNpR98f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_8hl4gLlJ4OLNpR98f.begin(); iter != sbt_8hl4gLlJ4OLNpR98f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j5Y8vw67Hh9mYlv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_j5Y8vw67Hh9mYlv.begin(); iter != sbt_j5Y8vw67Hh9mYlv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_obOxebytd", (CX::Int64)sbt_obOxebytd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zZo3lhMrKfmrJdhpawDYhep", (CX::Int64)sbt_zZo3lhMrKfmrJdhpawDYhep)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GHw", (CX::Int64)sbt_GHw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG", sbt_32KW1K30oCyIQNUcwFIN_lldZ7fkhTZdMaIpRWF5BrPPMY8cyleWuALtG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SVqWtCZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_SVqWtCZ.begin(); iter != sbt_SVqWtCZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sL15J9Xm0y2aJkF_1ze12ZQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_sL15J9Xm0y2aJkF_1ze12ZQ.begin(); iter != sbt_sL15J9Xm0y2aJkF_1ze12ZQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RoshNY8YPgwzx6_EIFAoHUK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_RoshNY8YPgwzx6_EIFAoHUK.begin(); iter != sbt_RoshNY8YPgwzx6_EIFAoHUK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N", (CX::Int64)sbt_N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_2LgNzMwGf7Pi_Dv", (CX::Double)sbt_2LgNzMwGf7Pi_Dv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ndMyt", sbt_ndMyt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Em4T5dfI_e_cKyE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Em4T5dfI_e_cKyE.begin(); iter != sbt_Em4T5dfI_e_cKyE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.begin(); iter != sbt_cJ7qMB5kk0_L_fB_CPt2JmVQgvGpvIGEyBVpRJfY8W85PbcgKfa6HzhmN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_71dkjM5xELw276SJIn8OS", (CX::Int64)sbt_71dkjM5xELw276SJIn8OS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.begin(); iter != sbt_PKoY5uIq5bs5Sahl162xV2ZK9AYXJebn7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ruxvQbonkaz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ruxvQbonkaz.begin(); iter != sbt_ruxvQbonkaz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.begin(); iter != sbt_JadwwlQEo9uwPS1gLy7SXIIYLfxfWab5OJevsH80ZxV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_9YyQdw1JQdvVpGPNsoXHXhxIZX7srxv42IYlBDu.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD>::Type sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXDArray;

