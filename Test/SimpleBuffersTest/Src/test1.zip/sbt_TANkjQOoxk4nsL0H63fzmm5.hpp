
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r.hpp"


class sbt_TANkjQOoxk4nsL0H63fzmm5 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo;
	CX::UInt16 sbt_D;
	CX::IO::SimpleBuffers::WStringArray sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI;
	CX::Bool sbt_i7eTBesE9YnQSqUKG;
	CX::String sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_;
	CX::IO::SimpleBuffers::UInt16Array sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc;
	CX::IO::SimpleBuffers::Int16Array sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq;
	CX::Float sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg;
	CX::Int64 sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5;
	CX::IO::SimpleBuffers::Int64Array sbt_4WeUluOEcC9086RxZ4R6Q4u;
	CX::Int16 sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH;
	CX::UInt8 sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC;
	sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972rArray sbt_EkBfT6Jo0Df;

	virtual void Reset()
	{
		sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo = 0;
		sbt_D = 0;
		sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.clear();
		sbt_i7eTBesE9YnQSqUKG = false;
		sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_.clear();
		sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.clear();
		sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.clear();
		sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg = 0.0f;
		sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5 = 0;
		sbt_4WeUluOEcC9086RxZ4R6Q4u.clear();
		sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH = 0;
		sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC = 0;
		sbt_EkBfT6Jo0Df.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo = 22;
		sbt_D = 21426;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.push_back(L"#w7094aOjI.5=ST?rCt%6@nv2wT[oanQz4a^NXbR7");
		}
		sbt_i7eTBesE9YnQSqUKG = false;
		sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_ = "h}2L4'];UkZ\"Ex)@9NkMi5d$_{8'N{J@(tk6C";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.push_back(55787);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.push_back(-8140);
		}
		sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg = 0.869228f;
		sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5 = -1711170489751211556;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_4WeUluOEcC9086RxZ4R6Q4u.push_back(1772149397987599270);
		}
		sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH = 14223;
		sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC = 125;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r v;

			v.SetupWithSomeValues();
			sbt_EkBfT6Jo0Df.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_TANkjQOoxk4nsL0H63fzmm5 *pObject = dynamic_cast<const sbt_TANkjQOoxk4nsL0H63fzmm5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo != pObject->sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo)
		{
			return false;
		}
		if (sbt_D != pObject->sbt_D)
		{
			return false;
		}
		if (sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.size() != pObject->sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI[i].c_str(), pObject->sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_i7eTBesE9YnQSqUKG != pObject->sbt_i7eTBesE9YnQSqUKG)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_.c_str(), pObject->sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_.c_str()))
		{
			return false;
		}
		if (sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.size() != pObject->sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.size(); i++)
		{
			if (sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc[i] != pObject->sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc[i])
			{
				return false;
			}
		}
		if (sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.size() != pObject->sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.size(); i++)
		{
			if (sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq[i] != pObject->sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq[i])
			{
				return false;
			}
		}
		if (sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg != pObject->sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg)
		{
			return false;
		}
		if (sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5 != pObject->sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5)
		{
			return false;
		}
		if (sbt_4WeUluOEcC9086RxZ4R6Q4u.size() != pObject->sbt_4WeUluOEcC9086RxZ4R6Q4u.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4WeUluOEcC9086RxZ4R6Q4u.size(); i++)
		{
			if (sbt_4WeUluOEcC9086RxZ4R6Q4u[i] != pObject->sbt_4WeUluOEcC9086RxZ4R6Q4u[i])
			{
				return false;
			}
		}
		if (sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH != pObject->sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH)
		{
			return false;
		}
		if (sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC != pObject->sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC)
		{
			return false;
		}
		if (sbt_EkBfT6Jo0Df.size() != pObject->sbt_EkBfT6Jo0Df.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EkBfT6Jo0Df.size(); i++)
		{
			if (!sbt_EkBfT6Jo0Df[i].Compare(&pObject->sbt_EkBfT6Jo0Df[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_D", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_D = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_i7eTBesE9YnQSqUKG", &sbt_i7eTBesE9YnQSqUKG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_", &sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4WeUluOEcC9086RxZ4R6Q4u")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4WeUluOEcC9086RxZ4R6Q4u.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EkBfT6Jo0Df")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_EkBfT6Jo0Df.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo", (CX::Int64)sbt_CYkysJiWa8RMFCvsuh5y2MMs_ZL9CDo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_D", (CX::Int64)sbt_D)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.begin(); iter != sbt_Wz3XaFeNhtlUYSaX9SMjAIeVJ1Fsx7zN6HI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_i7eTBesE9YnQSqUKG", sbt_i7eTBesE9YnQSqUKG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_", sbt_JOd1si6NCoCviiHWaaQK425kWvsk4gE5QQkpXbEQMacK_MYmPP_.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.begin(); iter != sbt_4YMBmxZig565cUXmfd17tVHIAb8BpLvcKARP9vsTN3r6QJabc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.begin(); iter != sbt_xeO7ZfvIPEFUci9lm9bXuN8Ww2AeRL9vIBt7EjAaqCFAuNUZq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg", (CX::Double)sbt_SO8OVnL0DbjR0QBN9x_rgG35wX_1aCYnaI5bj7_UORNXOByiEzrP4ypy_S4lg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5", (CX::Int64)sbt_wxkOJSuAvxO78qPE97EBiNZoEhUY1UWatt5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4WeUluOEcC9086RxZ4R6Q4u")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_4WeUluOEcC9086RxZ4R6Q4u.begin(); iter != sbt_4WeUluOEcC9086RxZ4R6Q4u.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH", (CX::Int64)sbt_nDi0vLtgZWhctbKtsQxkQt1ZEMwo_mH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC", (CX::Int64)sbt_eVfLZH73fxkUL2gcYWwunkopHQyhJXaux0qXC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EkBfT6Jo0Df")).IsNOK())
		{
			return status;
		}
		for (sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972rArray::const_iterator iter = sbt_EkBfT6Jo0Df.begin(); iter != sbt_EkBfT6Jo0Df.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_TANkjQOoxk4nsL0H63fzmm5>::Type sbt_TANkjQOoxk4nsL0H63fzmm5Array;

