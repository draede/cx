
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_sAccXmCocRm4NkkyuxK419Ipt.hpp"


class sbt_SkBThSottdxsBldfWuB0_fXIQ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_XgeWx;
	CX::Double sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d;
	CX::IO::SimpleBuffers::StringArray sbt_eeWQilqwQqf3G;
	CX::WString sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B;
	CX::UInt64 sbt_XF3orRoES9gOF;
	CX::IO::SimpleBuffers::DoubleArray sbt_Zcun8;
	CX::IO::SimpleBuffers::WStringArray sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw;
	CX::UInt32 sbt_FKto1zW;
	CX::WString sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS;
	CX::IO::SimpleBuffers::FloatArray sbt_G;
	CX::Int32 sbt_n8dQJQD_7_pnUBskHYuF403rM;
	CX::IO::SimpleBuffers::Int8Array sbt_vCW3doyqrp06ctAxc;
	CX::IO::SimpleBuffers::Int16Array sbt_QAwM_gtRiuJ_z4i26KstZ;
	CX::IO::SimpleBuffers::Int64Array sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT;
	CX::IO::SimpleBuffers::BoolArray sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9;
	CX::Bool sbt_jjnQXHT5EogyuPL4UKGXLRQts;
	CX::Int32 sbt_J;
	CX::Int16 sbt_1_u;
	CX::IO::SimpleBuffers::UInt32Array sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt;
	CX::IO::SimpleBuffers::Int16Array sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY;
	CX::Int8 sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK;
	CX::Float sbt_xo66wj8zN_pKAsJH43VPfnuQNJM;
	CX::Bool sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya;
	CX::String sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if;
	CX::IO::SimpleBuffers::UInt32Array sbt_rw9Z4O_;
	sbt_sAccXmCocRm4NkkyuxK419Ipt sbt_8itc6py1NxXR9;

	virtual void Reset()
	{
		sbt_XgeWx.clear();
		sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d = 0.0;
		sbt_eeWQilqwQqf3G.clear();
		sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B.clear();
		sbt_XF3orRoES9gOF = 0;
		sbt_Zcun8.clear();
		sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.clear();
		sbt_FKto1zW = 0;
		sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS.clear();
		sbt_G.clear();
		sbt_n8dQJQD_7_pnUBskHYuF403rM = 0;
		sbt_vCW3doyqrp06ctAxc.clear();
		sbt_QAwM_gtRiuJ_z4i26KstZ.clear();
		sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.clear();
		sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.clear();
		sbt_jjnQXHT5EogyuPL4UKGXLRQts = false;
		sbt_J = 0;
		sbt_1_u = 0;
		sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.clear();
		sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.clear();
		sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK = 0;
		sbt_xo66wj8zN_pKAsJH43VPfnuQNJM = 0.0f;
		sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya = false;
		sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if.clear();
		sbt_rw9Z4O_.clear();
		sbt_8itc6py1NxXR9.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_XgeWx.push_back(105);
		}
		sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d = 0.460504;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_eeWQilqwQqf3G.push_back("/OJ'Zq+^8gfV3iH,");
		}
		sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B = L"Y6ZUi5Q'~8|El4bAlwPM!e95%Rj#siAdsy')w-=h21h\\ZxiTE`/K";
		sbt_XF3orRoES9gOF = 9425913410867618784;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Zcun8.push_back(0.245120);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.push_back(L"M?S#%Nv+iLs&VQlS%<aHgS:");
		}
		sbt_FKto1zW = 3479419451;
		sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS = L"Qs<oq^/B|m0Ko#<0'[(5UiP-$AkYs4@ARj<qdDS(nX=Yje:jAI^M*s^3c4btPsH\"";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_G.push_back(0.369633f);
		}
		sbt_n8dQJQD_7_pnUBskHYuF403rM = 625574765;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_vCW3doyqrp06ctAxc.push_back(-18);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_QAwM_gtRiuJ_z4i26KstZ.push_back(31517);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.push_back(7356131357570018658);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.push_back(false);
		}
		sbt_jjnQXHT5EogyuPL4UKGXLRQts = false;
		sbt_J = 44303156;
		sbt_1_u = -15637;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.push_back(410535965);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.push_back(-32261);
		}
		sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK = -85;
		sbt_xo66wj8zN_pKAsJH43VPfnuQNJM = 0.094681f;
		sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya = true;
		sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if = "";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_rw9Z4O_.push_back(2461480473);
		}
		sbt_8itc6py1NxXR9.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_SkBThSottdxsBldfWuB0_fXIQ *pObject = dynamic_cast<const sbt_SkBThSottdxsBldfWuB0_fXIQ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_XgeWx.size() != pObject->sbt_XgeWx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XgeWx.size(); i++)
		{
			if (sbt_XgeWx[i] != pObject->sbt_XgeWx[i])
			{
				return false;
			}
		}
		if (sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d != pObject->sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d)
		{
			return false;
		}
		if (sbt_eeWQilqwQqf3G.size() != pObject->sbt_eeWQilqwQqf3G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eeWQilqwQqf3G.size(); i++)
		{
			if (0 != cx_strcmp(sbt_eeWQilqwQqf3G[i].c_str(), pObject->sbt_eeWQilqwQqf3G[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B.c_str(), pObject->sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B.c_str()))
		{
			return false;
		}
		if (sbt_XF3orRoES9gOF != pObject->sbt_XF3orRoES9gOF)
		{
			return false;
		}
		if (sbt_Zcun8.size() != pObject->sbt_Zcun8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zcun8.size(); i++)
		{
			if (sbt_Zcun8[i] != pObject->sbt_Zcun8[i])
			{
				return false;
			}
		}
		if (sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.size() != pObject->sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw[i].c_str(), pObject->sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_FKto1zW != pObject->sbt_FKto1zW)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS.c_str(), pObject->sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS.c_str()))
		{
			return false;
		}
		if (sbt_G.size() != pObject->sbt_G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_G.size(); i++)
		{
			if (sbt_G[i] != pObject->sbt_G[i])
			{
				return false;
			}
		}
		if (sbt_n8dQJQD_7_pnUBskHYuF403rM != pObject->sbt_n8dQJQD_7_pnUBskHYuF403rM)
		{
			return false;
		}
		if (sbt_vCW3doyqrp06ctAxc.size() != pObject->sbt_vCW3doyqrp06ctAxc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vCW3doyqrp06ctAxc.size(); i++)
		{
			if (sbt_vCW3doyqrp06ctAxc[i] != pObject->sbt_vCW3doyqrp06ctAxc[i])
			{
				return false;
			}
		}
		if (sbt_QAwM_gtRiuJ_z4i26KstZ.size() != pObject->sbt_QAwM_gtRiuJ_z4i26KstZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QAwM_gtRiuJ_z4i26KstZ.size(); i++)
		{
			if (sbt_QAwM_gtRiuJ_z4i26KstZ[i] != pObject->sbt_QAwM_gtRiuJ_z4i26KstZ[i])
			{
				return false;
			}
		}
		if (sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.size() != pObject->sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.size(); i++)
		{
			if (sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT[i] != pObject->sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT[i])
			{
				return false;
			}
		}
		if (sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.size() != pObject->sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.size(); i++)
		{
			if (sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9[i] != pObject->sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9[i])
			{
				return false;
			}
		}
		if (sbt_jjnQXHT5EogyuPL4UKGXLRQts != pObject->sbt_jjnQXHT5EogyuPL4UKGXLRQts)
		{
			return false;
		}
		if (sbt_J != pObject->sbt_J)
		{
			return false;
		}
		if (sbt_1_u != pObject->sbt_1_u)
		{
			return false;
		}
		if (sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.size() != pObject->sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.size(); i++)
		{
			if (sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt[i] != pObject->sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt[i])
			{
				return false;
			}
		}
		if (sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.size() != pObject->sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.size(); i++)
		{
			if (sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY[i] != pObject->sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY[i])
			{
				return false;
			}
		}
		if (sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK != pObject->sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK)
		{
			return false;
		}
		if (sbt_xo66wj8zN_pKAsJH43VPfnuQNJM != pObject->sbt_xo66wj8zN_pKAsJH43VPfnuQNJM)
		{
			return false;
		}
		if (sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya != pObject->sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if.c_str(), pObject->sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if.c_str()))
		{
			return false;
		}
		if (sbt_rw9Z4O_.size() != pObject->sbt_rw9Z4O_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rw9Z4O_.size(); i++)
		{
			if (sbt_rw9Z4O_[i] != pObject->sbt_rw9Z4O_[i])
			{
				return false;
			}
		}
		if (!sbt_8itc6py1NxXR9.Compare(&pObject->sbt_8itc6py1NxXR9))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_XgeWx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XgeWx.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_eeWQilqwQqf3G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eeWQilqwQqf3G.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B", &sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XF3orRoES9gOF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XF3orRoES9gOF = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Zcun8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Zcun8.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FKto1zW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FKto1zW = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectWString("sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS", &sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_G.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n8dQJQD_7_pnUBskHYuF403rM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n8dQJQD_7_pnUBskHYuF403rM = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vCW3doyqrp06ctAxc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vCW3doyqrp06ctAxc.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QAwM_gtRiuJ_z4i26KstZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QAwM_gtRiuJ_z4i26KstZ.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_jjnQXHT5EogyuPL4UKGXLRQts", &sbt_jjnQXHT5EogyuPL4UKGXLRQts)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1_u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1_u = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_xo66wj8zN_pKAsJH43VPfnuQNJM", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_xo66wj8zN_pKAsJH43VPfnuQNJM = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya", &sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if", &sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rw9Z4O_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rw9Z4O_.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_8itc6py1NxXR9")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_8itc6py1NxXR9.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_XgeWx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XgeWx.begin(); iter != sbt_XgeWx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d", (CX::Double)sbt_IbGwd74F4rskqtgv61PloZzAhnoDIzlvVGA7ELAkSkh6YeO7d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eeWQilqwQqf3G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_eeWQilqwQqf3G.begin(); iter != sbt_eeWQilqwQqf3G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B", sbt_BiBhVdaSHXfUu2xSHAzQgTI9igzfuCKnPzhiL3f3B.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XF3orRoES9gOF", (CX::Int64)sbt_XF3orRoES9gOF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zcun8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Zcun8.begin(); iter != sbt_Zcun8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.begin(); iter != sbt_w0MBbvDV8k_tM2Q6S5tnQQydS0tmmVAWuRmSuLA4UGW17OnJcoorGEOFqHw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FKto1zW", (CX::Int64)sbt_FKto1zW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS", sbt_qLFfo6Ish4XyAFqjwi3Pn_oz0B6AR18Yy0r3XIwr7NvhS.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_G.begin(); iter != sbt_G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n8dQJQD_7_pnUBskHYuF403rM", (CX::Int64)sbt_n8dQJQD_7_pnUBskHYuF403rM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vCW3doyqrp06ctAxc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_vCW3doyqrp06ctAxc.begin(); iter != sbt_vCW3doyqrp06ctAxc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QAwM_gtRiuJ_z4i26KstZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_QAwM_gtRiuJ_z4i26KstZ.begin(); iter != sbt_QAwM_gtRiuJ_z4i26KstZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.begin(); iter != sbt_hBcVWQ6k2y6732eITC_qxyLNP3b_t4Ls5HBORC2br4nSqbPIh0sblVq1UECRT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.begin(); iter != sbt_kg8RdZgRHQ8l58wGZsuNcaBAkurHpR5I6X7S9P9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_jjnQXHT5EogyuPL4UKGXLRQts", sbt_jjnQXHT5EogyuPL4UKGXLRQts)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J", (CX::Int64)sbt_J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1_u", (CX::Int64)sbt_1_u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.begin(); iter != sbt_twVNETln12IM5O0TSS7fI93UQzU2ekt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.begin(); iter != sbt_KNFdL3qh2A8ywfN2XnOcH2w92P8hY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK", (CX::Int64)sbt_cH04RqoWn60OTZ7f9pbCqrX_9oCane1fUBtKMTUYW54TEgKsTeuDK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_xo66wj8zN_pKAsJH43VPfnuQNJM", (CX::Double)sbt_xo66wj8zN_pKAsJH43VPfnuQNJM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya", sbt_jWzU2hWyIAAiPCrqerxjbxKLxXe2iWSbe4V9hfv0o2TK9XT7Immya)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if", sbt_QqjZPZzpbtH1twxwzA_oNkBtmp97yeotpgS8aVS9bpv56if.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rw9Z4O_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_rw9Z4O_.begin(); iter != sbt_rw9Z4O_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_8itc6py1NxXR9")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_8itc6py1NxXR9.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_SkBThSottdxsBldfWuB0_fXIQ>::Type sbt_SkBThSottdxsBldfWuB0_fXIQArray;

