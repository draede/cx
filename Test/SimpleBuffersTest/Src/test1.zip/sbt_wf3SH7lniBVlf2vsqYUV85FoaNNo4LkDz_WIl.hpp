
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W;
	CX::IO::SimpleBuffers::BoolArray sbt_5GGYTmJuvBBGQCcDZK2;
	CX::Int32 sbt_jkZXvfguD53b0y6DAistBWGfR;
	CX::UInt8 sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs;
	CX::IO::SimpleBuffers::Int32Array sbt__Ar;

	virtual void Reset()
	{
		sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W = 0;
		sbt_5GGYTmJuvBBGQCcDZK2.clear();
		sbt_jkZXvfguD53b0y6DAistBWGfR = 0;
		sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs = 0;
		sbt__Ar.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W = 29356;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_5GGYTmJuvBBGQCcDZK2.push_back(false);
		}
		sbt_jkZXvfguD53b0y6DAistBWGfR = -1079305857;
		sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs = 22;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt__Ar.push_back(-1149683070);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl *pObject = dynamic_cast<const sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W != pObject->sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W)
		{
			return false;
		}
		if (sbt_5GGYTmJuvBBGQCcDZK2.size() != pObject->sbt_5GGYTmJuvBBGQCcDZK2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5GGYTmJuvBBGQCcDZK2.size(); i++)
		{
			if (sbt_5GGYTmJuvBBGQCcDZK2[i] != pObject->sbt_5GGYTmJuvBBGQCcDZK2[i])
			{
				return false;
			}
		}
		if (sbt_jkZXvfguD53b0y6DAistBWGfR != pObject->sbt_jkZXvfguD53b0y6DAistBWGfR)
		{
			return false;
		}
		if (sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs != pObject->sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs)
		{
			return false;
		}
		if (sbt__Ar.size() != pObject->sbt__Ar.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__Ar.size(); i++)
		{
			if (sbt__Ar[i] != pObject->sbt__Ar[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5GGYTmJuvBBGQCcDZK2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5GGYTmJuvBBGQCcDZK2.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jkZXvfguD53b0y6DAistBWGfR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jkZXvfguD53b0y6DAistBWGfR = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt__Ar")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__Ar.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W", (CX::Int64)sbt_Na7UTjgOyUInNrgHrea513Zw2MzbLDFzvAwfmXKRD_W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5GGYTmJuvBBGQCcDZK2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_5GGYTmJuvBBGQCcDZK2.begin(); iter != sbt_5GGYTmJuvBBGQCcDZK2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jkZXvfguD53b0y6DAistBWGfR", (CX::Int64)sbt_jkZXvfguD53b0y6DAistBWGfR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs", (CX::Int64)sbt__8Ie26b8RGqBVnCcZUHgfVjICTr5eJKmy0jsuQmdFFT8Xjqcs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__Ar")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt__Ar.begin(); iter != sbt__Ar.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl>::Type sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIlArray;

