
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR.hpp"


class sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_r9LJe0QjMxL;
	CX::IO::SimpleBuffers::UInt64Array sbt_5EfMUeth62_WoSCUx;
	CX::Int16 sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh;
	CX::IO::SimpleBuffers::UInt64Array sbt_aWucGQsTBpeHrMAnm8PfrZU;
	CX::IO::SimpleBuffers::Int16Array sbt_u;
	CX::IO::SimpleBuffers::WStringArray sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9;
	CX::IO::SimpleBuffers::UInt16Array sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562;
	CX::WString sbt_2IxHllmO4w2;
	CX::Int64 sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ;
	CX::UInt32 sbt_pzD4973;
	CX::IO::SimpleBuffers::UInt32Array sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ;
	CX::IO::SimpleBuffers::UInt64Array sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh;
	CX::IO::SimpleBuffers::DoubleArray sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F;
	CX::UInt16 sbt_6N3XqVKRB;
	CX::Int64 sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ;
	CX::UInt16 sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw;
	CX::UInt64 sbt_5lQ3Q1Lycof7tacTF5g;
	CX::Int64 sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho;
	CX::UInt64 sbt_10fum;
	CX::Int8 sbt_0ehPxYc6f51lHjW9V;
	CX::IO::SimpleBuffers::UInt16Array sbt_xPLvTmjmgfOJD09DQN2E_z3Eh;
	CX::UInt64 sbt_BB1WLgi8p8BEEbHGn;
	CX::UInt64 sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN;
	CX::IO::SimpleBuffers::Int16Array sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC;
	CX::IO::SimpleBuffers::DoubleArray sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK;
	CX::Double sbt_M_HdZ9YqloeK0fJFvDm;
	sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq;

	virtual void Reset()
	{
		sbt_r9LJe0QjMxL = 0;
		sbt_5EfMUeth62_WoSCUx.clear();
		sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh = 0;
		sbt_aWucGQsTBpeHrMAnm8PfrZU.clear();
		sbt_u.clear();
		sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.clear();
		sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.clear();
		sbt_2IxHllmO4w2.clear();
		sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ = 0;
		sbt_pzD4973 = 0;
		sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.clear();
		sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.clear();
		sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.clear();
		sbt_6N3XqVKRB = 0;
		sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ = 0;
		sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw = 0;
		sbt_5lQ3Q1Lycof7tacTF5g = 0;
		sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho = 0;
		sbt_10fum = 0;
		sbt_0ehPxYc6f51lHjW9V = 0;
		sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.clear();
		sbt_BB1WLgi8p8BEEbHGn = 0;
		sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN = 0;
		sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.clear();
		sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.clear();
		sbt_M_HdZ9YqloeK0fJFvDm = 0.0;
		sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_r9LJe0QjMxL = 38534;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_5EfMUeth62_WoSCUx.push_back(550363217522604196);
		}
		sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh = -27048;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_aWucGQsTBpeHrMAnm8PfrZU.push_back(12770323141091249844);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_u.push_back(-2635);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.push_back(L"c");
		}
		sbt_2IxHllmO4w2 = L"@>9D?\"Sz;d";
		sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ = 2769044523724444512;
		sbt_pzD4973 = 839414829;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.push_back(905341829);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.push_back(8895058967257756732);
		}
		sbt_6N3XqVKRB = 59298;
		sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ = -8826619158298641362;
		sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw = 35826;
		sbt_5lQ3Q1Lycof7tacTF5g = 979484806488071496;
		sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho = -123427267548695200;
		sbt_10fum = 7692153349573725668;
		sbt_0ehPxYc6f51lHjW9V = 105;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.push_back(24845);
		}
		sbt_BB1WLgi8p8BEEbHGn = 1194560743854402278;
		sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN = 16890179002074191324;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.push_back(-29066);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.push_back(0.027748);
		}
		sbt_M_HdZ9YqloeK0fJFvDm = 0.688434;
		sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M *pObject = dynamic_cast<const sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_r9LJe0QjMxL != pObject->sbt_r9LJe0QjMxL)
		{
			return false;
		}
		if (sbt_5EfMUeth62_WoSCUx.size() != pObject->sbt_5EfMUeth62_WoSCUx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5EfMUeth62_WoSCUx.size(); i++)
		{
			if (sbt_5EfMUeth62_WoSCUx[i] != pObject->sbt_5EfMUeth62_WoSCUx[i])
			{
				return false;
			}
		}
		if (sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh != pObject->sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh)
		{
			return false;
		}
		if (sbt_aWucGQsTBpeHrMAnm8PfrZU.size() != pObject->sbt_aWucGQsTBpeHrMAnm8PfrZU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aWucGQsTBpeHrMAnm8PfrZU.size(); i++)
		{
			if (sbt_aWucGQsTBpeHrMAnm8PfrZU[i] != pObject->sbt_aWucGQsTBpeHrMAnm8PfrZU[i])
			{
				return false;
			}
		}
		if (sbt_u.size() != pObject->sbt_u.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u.size(); i++)
		{
			if (sbt_u[i] != pObject->sbt_u[i])
			{
				return false;
			}
		}
		if (sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.size() != pObject->sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9[i].c_str(), pObject->sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.size() != pObject->sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.size(); i++)
		{
			if (sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562[i] != pObject->sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_2IxHllmO4w2.c_str(), pObject->sbt_2IxHllmO4w2.c_str()))
		{
			return false;
		}
		if (sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ != pObject->sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ)
		{
			return false;
		}
		if (sbt_pzD4973 != pObject->sbt_pzD4973)
		{
			return false;
		}
		if (sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.size() != pObject->sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.size(); i++)
		{
			if (sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ[i] != pObject->sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ[i])
			{
				return false;
			}
		}
		if (sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.size() != pObject->sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.size(); i++)
		{
			if (sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh[i] != pObject->sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh[i])
			{
				return false;
			}
		}
		if (sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.size() != pObject->sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.size(); i++)
		{
			if (sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F[i] != pObject->sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F[i])
			{
				return false;
			}
		}
		if (sbt_6N3XqVKRB != pObject->sbt_6N3XqVKRB)
		{
			return false;
		}
		if (sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ != pObject->sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ)
		{
			return false;
		}
		if (sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw != pObject->sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw)
		{
			return false;
		}
		if (sbt_5lQ3Q1Lycof7tacTF5g != pObject->sbt_5lQ3Q1Lycof7tacTF5g)
		{
			return false;
		}
		if (sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho != pObject->sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho)
		{
			return false;
		}
		if (sbt_10fum != pObject->sbt_10fum)
		{
			return false;
		}
		if (sbt_0ehPxYc6f51lHjW9V != pObject->sbt_0ehPxYc6f51lHjW9V)
		{
			return false;
		}
		if (sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.size() != pObject->sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.size(); i++)
		{
			if (sbt_xPLvTmjmgfOJD09DQN2E_z3Eh[i] != pObject->sbt_xPLvTmjmgfOJD09DQN2E_z3Eh[i])
			{
				return false;
			}
		}
		if (sbt_BB1WLgi8p8BEEbHGn != pObject->sbt_BB1WLgi8p8BEEbHGn)
		{
			return false;
		}
		if (sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN != pObject->sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN)
		{
			return false;
		}
		if (sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.size() != pObject->sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.size(); i++)
		{
			if (sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC[i] != pObject->sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC[i])
			{
				return false;
			}
		}
		if (sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.size() != pObject->sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.size(); i++)
		{
			if (sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK[i] != pObject->sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK[i])
			{
				return false;
			}
		}
		if (sbt_M_HdZ9YqloeK0fJFvDm != pObject->sbt_M_HdZ9YqloeK0fJFvDm)
		{
			return false;
		}
		if (!sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq.Compare(&pObject->sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_r9LJe0QjMxL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r9LJe0QjMxL = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5EfMUeth62_WoSCUx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5EfMUeth62_WoSCUx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_aWucGQsTBpeHrMAnm8PfrZU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aWucGQsTBpeHrMAnm8PfrZU.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_u")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_2IxHllmO4w2", &sbt_2IxHllmO4w2)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pzD4973", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pzD4973 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6N3XqVKRB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6N3XqVKRB = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5lQ3Q1Lycof7tacTF5g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5lQ3Q1Lycof7tacTF5g = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_10fum", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_10fum = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0ehPxYc6f51lHjW9V", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0ehPxYc6f51lHjW9V = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xPLvTmjmgfOJD09DQN2E_z3Eh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BB1WLgi8p8BEEbHGn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BB1WLgi8p8BEEbHGn = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_M_HdZ9YqloeK0fJFvDm", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_M_HdZ9YqloeK0fJFvDm = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectObject("sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_r9LJe0QjMxL", (CX::Int64)sbt_r9LJe0QjMxL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5EfMUeth62_WoSCUx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5EfMUeth62_WoSCUx.begin(); iter != sbt_5EfMUeth62_WoSCUx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh", (CX::Int64)sbt_HuqZVHM41k5AXZO4z4pGTsVq4ECsUlLfi63gy3ujT2Kn8yCAUspuDJKNh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aWucGQsTBpeHrMAnm8PfrZU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_aWucGQsTBpeHrMAnm8PfrZU.begin(); iter != sbt_aWucGQsTBpeHrMAnm8PfrZU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_u.begin(); iter != sbt_u.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.begin(); iter != sbt_cxaZvpdMzEgEv_8lUdN3WORqlTNR6Se4QwSGIpF_8hSP8hXMyu3W7oPozxbs9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.begin(); iter != sbt_TZdb4AG_6561gjL40L4AAraqghToleveQUzYhleLV60QwuXHPX562.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_2IxHllmO4w2", sbt_2IxHllmO4w2.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ", (CX::Int64)sbt_N3GVWJG8PoIi1obLvyXJac7d55rDQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pzD4973", (CX::Int64)sbt_pzD4973)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.begin(); iter != sbt_EXchuC7XX7sUJlgp64xkNmSi6dOciELfyH7L3sg37td0vRduJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.begin(); iter != sbt_eGXUIGT0eXWbi6S7Kryk64m4Pkqgb_x9ZrVwmNliIk5zFNh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.begin(); iter != sbt_JD1qtQG_SIImqAxDnLkfGR9V2Z0pAh2Wau9ujR_9rph6A8F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6N3XqVKRB", (CX::Int64)sbt_6N3XqVKRB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ", (CX::Int64)sbt_HLCssnS3GQF8yOH4f7FkzCouG5bmNFVssO8vwdhPcVt7oq7HWrFr0rJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw", (CX::Int64)sbt_nhQ2XMIfYhh5K23rvm_1_2weitSoFhPfL2AUX8rm0Aw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5lQ3Q1Lycof7tacTF5g", (CX::Int64)sbt_5lQ3Q1Lycof7tacTF5g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho", (CX::Int64)sbt_GBK9eRSnas7tfBgZCfBif6E9PTeB3Ho)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_10fum", (CX::Int64)sbt_10fum)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0ehPxYc6f51lHjW9V", (CX::Int64)sbt_0ehPxYc6f51lHjW9V)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xPLvTmjmgfOJD09DQN2E_z3Eh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.begin(); iter != sbt_xPLvTmjmgfOJD09DQN2E_z3Eh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BB1WLgi8p8BEEbHGn", (CX::Int64)sbt_BB1WLgi8p8BEEbHGn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN", (CX::Int64)sbt_BVUneKzDDdp6FxNMnOYAI6yLV1WXI_7W_6HSVXQglr4xN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.begin(); iter != sbt_lEEfiVwATj5bZbZEv5QNyrpUJNsYnndRcx76geikyIAL6iC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.begin(); iter != sbt_ZtWZtDBuuVV68aDazu3628fGAZzN7tK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_M_HdZ9YqloeK0fJFvDm", (CX::Double)sbt_M_HdZ9YqloeK0fJFvDm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_RmhClEhqLAlnRbaJzZSWAmVo3rK9R4Lq2GS3ETq.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M>::Type sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0MArray;

