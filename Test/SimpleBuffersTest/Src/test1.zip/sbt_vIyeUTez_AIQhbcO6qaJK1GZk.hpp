
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_vIyeUTez_AIQhbcO6qaJK1GZk : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_DqsLkH1;

	virtual void Reset()
	{
		sbt_DqsLkH1 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_DqsLkH1 = 314979609;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_vIyeUTez_AIQhbcO6qaJK1GZk *pObject = dynamic_cast<const sbt_vIyeUTez_AIQhbcO6qaJK1GZk *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_DqsLkH1 != pObject->sbt_DqsLkH1)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_DqsLkH1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DqsLkH1 = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_DqsLkH1", (CX::Int64)sbt_DqsLkH1)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_vIyeUTez_AIQhbcO6qaJK1GZk>::Type sbt_vIyeUTez_AIQhbcO6qaJK1GZkArray;

