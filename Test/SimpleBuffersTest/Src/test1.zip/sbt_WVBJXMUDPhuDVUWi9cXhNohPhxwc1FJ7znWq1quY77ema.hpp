
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP;
	CX::Int64 sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C;
	CX::UInt32 sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk;
	CX::IO::SimpleBuffers::UInt32Array sbt_gBieeCrFR5Vvm7xt1;
	CX::IO::SimpleBuffers::UInt8Array sbt_ZkWv_NH00pfIQAPVaOjSWiN;
	CX::IO::SimpleBuffers::Int16Array sbt_oROcx;
	CX::String sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW;
	CX::UInt32 sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm;
	CX::Int16 sbt_gfWRFo8pRZTy1PwvQf5i3;
	CX::UInt32 sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ;
	CX::IO::SimpleBuffers::UInt32Array sbt_q9vqji3;
	CX::IO::SimpleBuffers::UInt32Array sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf;
	CX::IO::SimpleBuffers::UInt8Array sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB;
	CX::IO::SimpleBuffers::UInt64Array sbt__0F;
	CX::IO::SimpleBuffers::UInt16Array sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs;
	CX::Int16 sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT;
	CX::UInt32 sbt_H;
	CX::IO::SimpleBuffers::UInt32Array sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7;
	CX::IO::SimpleBuffers::Int32Array sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts;
	CX::Int16 sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB;
	CX::IO::SimpleBuffers::StringArray sbt_ZGjaQXUJfFz;
	CX::IO::SimpleBuffers::UInt32Array sbt_FNQ6CGy3o99nb7aLOC2lrC0;
	CX::IO::SimpleBuffers::UInt32Array sbt_Vb6yStgHfZD7BLSB8;
	CX::UInt64 sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_;
	CX::UInt8 sbt_TN0J7NBE7ektnRQhmBBXo3wxE49;
	CX::Int8 sbt_KRoCQC5PhSLnqN2_bWN;

	virtual void Reset()
	{
		sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.clear();
		sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C = 0;
		sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk = 0;
		sbt_gBieeCrFR5Vvm7xt1.clear();
		sbt_ZkWv_NH00pfIQAPVaOjSWiN.clear();
		sbt_oROcx.clear();
		sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW.clear();
		sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm = 0;
		sbt_gfWRFo8pRZTy1PwvQf5i3 = 0;
		sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ = 0;
		sbt_q9vqji3.clear();
		sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.clear();
		sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.clear();
		sbt__0F.clear();
		sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.clear();
		sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT = 0;
		sbt_H = 0;
		sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.clear();
		sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.clear();
		sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB = 0;
		sbt_ZGjaQXUJfFz.clear();
		sbt_FNQ6CGy3o99nb7aLOC2lrC0.clear();
		sbt_Vb6yStgHfZD7BLSB8.clear();
		sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_ = 0;
		sbt_TN0J7NBE7ektnRQhmBBXo3wxE49 = 0;
		sbt_KRoCQC5PhSLnqN2_bWN = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C = 7964950090465312032;
		sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk = 4088291066;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_gBieeCrFR5Vvm7xt1.push_back(178378389);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ZkWv_NH00pfIQAPVaOjSWiN.push_back(168);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_oROcx.push_back(-19108);
		}
		sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW = "p6#hur$7O1/t}[]lQbl:";
		sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm = 3662217761;
		sbt_gfWRFo8pRZTy1PwvQf5i3 = -19060;
		sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ = 978412847;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_q9vqji3.push_back(3380420397);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.push_back(2183057651);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.push_back(134);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt__0F.push_back(113380749085922554);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.push_back(26426);
		}
		sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT = -26379;
		sbt_H = 3589000922;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.push_back(1992076264);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.push_back(-1104962120);
		}
		sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB = 17749;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ZGjaQXUJfFz.push_back("EUppDf");
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_FNQ6CGy3o99nb7aLOC2lrC0.push_back(3779179329);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Vb6yStgHfZD7BLSB8.push_back(2963143898);
		}
		sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_ = 17402958515349628692;
		sbt_TN0J7NBE7ektnRQhmBBXo3wxE49 = 145;
		sbt_KRoCQC5PhSLnqN2_bWN = -9;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema *pObject = dynamic_cast<const sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.size() != pObject->sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.size(); i++)
		{
			if (sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP[i] != pObject->sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP[i])
			{
				return false;
			}
		}
		if (sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C != pObject->sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C)
		{
			return false;
		}
		if (sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk != pObject->sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk)
		{
			return false;
		}
		if (sbt_gBieeCrFR5Vvm7xt1.size() != pObject->sbt_gBieeCrFR5Vvm7xt1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gBieeCrFR5Vvm7xt1.size(); i++)
		{
			if (sbt_gBieeCrFR5Vvm7xt1[i] != pObject->sbt_gBieeCrFR5Vvm7xt1[i])
			{
				return false;
			}
		}
		if (sbt_ZkWv_NH00pfIQAPVaOjSWiN.size() != pObject->sbt_ZkWv_NH00pfIQAPVaOjSWiN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZkWv_NH00pfIQAPVaOjSWiN.size(); i++)
		{
			if (sbt_ZkWv_NH00pfIQAPVaOjSWiN[i] != pObject->sbt_ZkWv_NH00pfIQAPVaOjSWiN[i])
			{
				return false;
			}
		}
		if (sbt_oROcx.size() != pObject->sbt_oROcx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oROcx.size(); i++)
		{
			if (sbt_oROcx[i] != pObject->sbt_oROcx[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW.c_str(), pObject->sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW.c_str()))
		{
			return false;
		}
		if (sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm != pObject->sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm)
		{
			return false;
		}
		if (sbt_gfWRFo8pRZTy1PwvQf5i3 != pObject->sbt_gfWRFo8pRZTy1PwvQf5i3)
		{
			return false;
		}
		if (sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ != pObject->sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ)
		{
			return false;
		}
		if (sbt_q9vqji3.size() != pObject->sbt_q9vqji3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q9vqji3.size(); i++)
		{
			if (sbt_q9vqji3[i] != pObject->sbt_q9vqji3[i])
			{
				return false;
			}
		}
		if (sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.size() != pObject->sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.size(); i++)
		{
			if (sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf[i] != pObject->sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf[i])
			{
				return false;
			}
		}
		if (sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.size() != pObject->sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.size(); i++)
		{
			if (sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB[i] != pObject->sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB[i])
			{
				return false;
			}
		}
		if (sbt__0F.size() != pObject->sbt__0F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__0F.size(); i++)
		{
			if (sbt__0F[i] != pObject->sbt__0F[i])
			{
				return false;
			}
		}
		if (sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.size() != pObject->sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.size(); i++)
		{
			if (sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs[i] != pObject->sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs[i])
			{
				return false;
			}
		}
		if (sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT != pObject->sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT)
		{
			return false;
		}
		if (sbt_H != pObject->sbt_H)
		{
			return false;
		}
		if (sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.size() != pObject->sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.size(); i++)
		{
			if (sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7[i] != pObject->sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7[i])
			{
				return false;
			}
		}
		if (sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.size() != pObject->sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.size(); i++)
		{
			if (sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts[i] != pObject->sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts[i])
			{
				return false;
			}
		}
		if (sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB != pObject->sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB)
		{
			return false;
		}
		if (sbt_ZGjaQXUJfFz.size() != pObject->sbt_ZGjaQXUJfFz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZGjaQXUJfFz.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ZGjaQXUJfFz[i].c_str(), pObject->sbt_ZGjaQXUJfFz[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_FNQ6CGy3o99nb7aLOC2lrC0.size() != pObject->sbt_FNQ6CGy3o99nb7aLOC2lrC0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FNQ6CGy3o99nb7aLOC2lrC0.size(); i++)
		{
			if (sbt_FNQ6CGy3o99nb7aLOC2lrC0[i] != pObject->sbt_FNQ6CGy3o99nb7aLOC2lrC0[i])
			{
				return false;
			}
		}
		if (sbt_Vb6yStgHfZD7BLSB8.size() != pObject->sbt_Vb6yStgHfZD7BLSB8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Vb6yStgHfZD7BLSB8.size(); i++)
		{
			if (sbt_Vb6yStgHfZD7BLSB8[i] != pObject->sbt_Vb6yStgHfZD7BLSB8[i])
			{
				return false;
			}
		}
		if (sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_ != pObject->sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_)
		{
			return false;
		}
		if (sbt_TN0J7NBE7ektnRQhmBBXo3wxE49 != pObject->sbt_TN0J7NBE7ektnRQhmBBXo3wxE49)
		{
			return false;
		}
		if (sbt_KRoCQC5PhSLnqN2_bWN != pObject->sbt_KRoCQC5PhSLnqN2_bWN)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gBieeCrFR5Vvm7xt1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gBieeCrFR5Vvm7xt1.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZkWv_NH00pfIQAPVaOjSWiN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZkWv_NH00pfIQAPVaOjSWiN.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oROcx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oROcx.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW", &sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gfWRFo8pRZTy1PwvQf5i3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gfWRFo8pRZTy1PwvQf5i3 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_q9vqji3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q9vqji3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__0F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__0F.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_H", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_H = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZGjaQXUJfFz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZGjaQXUJfFz.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FNQ6CGy3o99nb7aLOC2lrC0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FNQ6CGy3o99nb7aLOC2lrC0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Vb6yStgHfZD7BLSB8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Vb6yStgHfZD7BLSB8.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TN0J7NBE7ektnRQhmBBXo3wxE49", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TN0J7NBE7ektnRQhmBBXo3wxE49 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KRoCQC5PhSLnqN2_bWN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KRoCQC5PhSLnqN2_bWN = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.begin(); iter != sbt_NGQ3eyzyINnWa1NzAfKbaTQpoEcOP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C", (CX::Int64)sbt_xmLmjIHrkfkd1QGjWIauguYGEofaCkS33Qs55Tonp4eQFvx1C)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk", (CX::Int64)sbt_X8EK366peSUyxvvQIAeMAd8Mj0L9T3q7E9_rTIUHG0UcDRWF2sBpy1mwtsLVvuk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gBieeCrFR5Vvm7xt1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_gBieeCrFR5Vvm7xt1.begin(); iter != sbt_gBieeCrFR5Vvm7xt1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZkWv_NH00pfIQAPVaOjSWiN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ZkWv_NH00pfIQAPVaOjSWiN.begin(); iter != sbt_ZkWv_NH00pfIQAPVaOjSWiN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oROcx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_oROcx.begin(); iter != sbt_oROcx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW", sbt_96K9tfBx4oNlcmlRAZj1mG_1wrOqKAz257V0m2ATpd9_bXEotetHoOJIW.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm", (CX::Int64)sbt_rYgDSGgVDlnU8JI02dpK2Gj7imuLm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gfWRFo8pRZTy1PwvQf5i3", (CX::Int64)sbt_gfWRFo8pRZTy1PwvQf5i3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ", (CX::Int64)sbt_hN3i1aHeAkncuuGZ8RGqCxDos6uJB9OK9i7F34iNfcx88uyhiX8Mq_w8Ca_H6BZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q9vqji3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_q9vqji3.begin(); iter != sbt_q9vqji3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.begin(); iter != sbt_s1J_DGgLWIJvobhAM9XLEixz2du5ZQf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.begin(); iter != sbt_Tp5y01f7y8CPUHLnacZyNW3xzxOjIzemfxVa77KM78uPL1CkTH6QY941_gmcB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__0F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__0F.begin(); iter != sbt__0F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.begin(); iter != sbt_3hVbTNUxbebqR7GfUJCB3gZu6OMCVBx69QE9NZgXs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT", (CX::Int64)sbt_R_FJFUPJvmViDAxddGnQQaUiqTGpumT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_H", (CX::Int64)sbt_H)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.begin(); iter != sbt_KgHo5_c4JtU6kevG6aHsSRAQ31N1iCHPJAEmGXHeW3Oz6ahGI6qaYA6Thk7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.begin(); iter != sbt_mHfBu6qAd97wQAYj0Vrz8QkNci792B9Q6VB7eKd0vAJts.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB", (CX::Int64)sbt_UhyfYdLdgriVzIwW2NAPCDDxaGB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZGjaQXUJfFz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ZGjaQXUJfFz.begin(); iter != sbt_ZGjaQXUJfFz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FNQ6CGy3o99nb7aLOC2lrC0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FNQ6CGy3o99nb7aLOC2lrC0.begin(); iter != sbt_FNQ6CGy3o99nb7aLOC2lrC0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Vb6yStgHfZD7BLSB8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Vb6yStgHfZD7BLSB8.begin(); iter != sbt_Vb6yStgHfZD7BLSB8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_", (CX::Int64)sbt_cLnuE6NezdHiMKpr4KWLYWL3OWibHXk4zr_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TN0J7NBE7ektnRQhmBBXo3wxE49", (CX::Int64)sbt_TN0J7NBE7ektnRQhmBBXo3wxE49)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KRoCQC5PhSLnqN2_bWN", (CX::Int64)sbt_KRoCQC5PhSLnqN2_bWN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema>::Type sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77emaArray;

