
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4.hpp"


class sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W;
	CX::IO::SimpleBuffers::UInt64Array sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer;
	CX::Double sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG;
	CX::IO::SimpleBuffers::Int16Array sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_;
	CX::String sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR;
	CX::Bool sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6;
	CX::IO::SimpleBuffers::UInt32Array sbt_i5tQBsSlpvn7SRe;
	CX::IO::SimpleBuffers::UInt64Array sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z;
	CX::Float sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX;
	CX::IO::SimpleBuffers::Int64Array sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr;
	CX::IO::SimpleBuffers::UInt8Array sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu;
	CX::IO::SimpleBuffers::DoubleArray sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1;
	CX::Int8 sbt_pyZPQGtal;
	CX::IO::SimpleBuffers::FloatArray sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap;
	CX::IO::SimpleBuffers::UInt32Array sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax;
	CX::Bool sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya;
	sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4 sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw;

	virtual void Reset()
	{
		sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W = 0;
		sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.clear();
		sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG = 0.0;
		sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.clear();
		sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR.clear();
		sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6 = false;
		sbt_i5tQBsSlpvn7SRe.clear();
		sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.clear();
		sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX = 0.0f;
		sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.clear();
		sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.clear();
		sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.clear();
		sbt_pyZPQGtal = 0;
		sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.clear();
		sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.clear();
		sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya = false;
		sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W = -8274;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.push_back(18286270953322090244);
		}
		sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG = 0.305729;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.push_back(-18786);
		}
		sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR = "m.?Y6`yYBSTs";
		sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6 = true;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_i5tQBsSlpvn7SRe.push_back(3130983959);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.push_back(15921878351866564798);
		}
		sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX = 0.996208f;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.push_back(-8191280514871605744);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.push_back(186);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.push_back(0.723158);
		}
		sbt_pyZPQGtal = -48;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.push_back(0.092743f);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.push_back(4084144558);
		}
		sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya = true;
		sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw *pObject = dynamic_cast<const sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W != pObject->sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W)
		{
			return false;
		}
		if (sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.size() != pObject->sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.size(); i++)
		{
			if (sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer[i] != pObject->sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer[i])
			{
				return false;
			}
		}
		if (sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG != pObject->sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG)
		{
			return false;
		}
		if (sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.size() != pObject->sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.size(); i++)
		{
			if (sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_[i] != pObject->sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR.c_str(), pObject->sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR.c_str()))
		{
			return false;
		}
		if (sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6 != pObject->sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6)
		{
			return false;
		}
		if (sbt_i5tQBsSlpvn7SRe.size() != pObject->sbt_i5tQBsSlpvn7SRe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i5tQBsSlpvn7SRe.size(); i++)
		{
			if (sbt_i5tQBsSlpvn7SRe[i] != pObject->sbt_i5tQBsSlpvn7SRe[i])
			{
				return false;
			}
		}
		if (sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.size() != pObject->sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.size(); i++)
		{
			if (sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z[i] != pObject->sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z[i])
			{
				return false;
			}
		}
		if (sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX != pObject->sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX)
		{
			return false;
		}
		if (sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.size() != pObject->sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.size(); i++)
		{
			if (sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr[i] != pObject->sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr[i])
			{
				return false;
			}
		}
		if (sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.size() != pObject->sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.size(); i++)
		{
			if (sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu[i] != pObject->sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu[i])
			{
				return false;
			}
		}
		if (sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.size() != pObject->sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.size(); i++)
		{
			if (sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1[i] != pObject->sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1[i])
			{
				return false;
			}
		}
		if (sbt_pyZPQGtal != pObject->sbt_pyZPQGtal)
		{
			return false;
		}
		if (sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.size() != pObject->sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.size(); i++)
		{
			if (sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap[i] != pObject->sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap[i])
			{
				return false;
			}
		}
		if (sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.size() != pObject->sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.size(); i++)
		{
			if (sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax[i] != pObject->sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax[i])
			{
				return false;
			}
		}
		if (sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya != pObject->sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya)
		{
			return false;
		}
		if (!sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw.Compare(&pObject->sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR", &sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6", &sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_i5tQBsSlpvn7SRe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i5tQBsSlpvn7SRe.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pyZPQGtal", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pyZPQGtal = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya", &sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W", (CX::Int64)sbt_TkWRX4DDW6l7gVvX9DECgNYp4Ul05sdwfClu2gPXdMNIP2W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.begin(); iter != sbt_7_i9B9uPvnhoEnd5uZNMfU1jHfgfZvMer.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG", (CX::Double)sbt_ffQm0NZ3QMSjgTPCYI4dydB435lw1XKZJDbDlJM4Y0T7n2trB0SmVbvdKEgTG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.begin(); iter != sbt_LMzzg7vbcyeeWM9JnHMjzV7uPwgAAZCTggvA09YaTE_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR", sbt_sRL_OeMwHNFrzKvkxS2dJje8e18mmoRbzrE_iKR.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6", sbt_VztMpkfZyGqD7tnW4wbqFVplNB7lTGKy7cenq6dztwNbVVhb9T8N6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i5tQBsSlpvn7SRe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_i5tQBsSlpvn7SRe.begin(); iter != sbt_i5tQBsSlpvn7SRe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.begin(); iter != sbt_nsUYOZoFZA663cTxDb7qO8AF9sZmNTQMKgF0z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX", (CX::Double)sbt_xb7AwE9r3j33NcJt4juUp4q6GDeZFqesPDH7G21mx_pGX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.begin(); iter != sbt_tSz87Q2f6yOIPBDvRXWZWEXQweKa8WMDTP1NM49g8Q3okARr6Lr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.begin(); iter != sbt_LEws8pxmfNINrMlEkhDNhQmwc97hc9xVGFwyXtxfdpbtPZVRSeQZu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.begin(); iter != sbt_V8gO5k2LKYsZqtZIO3tgsRvutf8ARlm7rZLNQD_rl_DvKk8rHQ1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pyZPQGtal", (CX::Int64)sbt_pyZPQGtal)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.begin(); iter != sbt_Uw_ekkUa5LivcgoeAQ7PyR9Ap.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.begin(); iter != sbt_1GbfO0awEWLLK8ildYXIreRTMWfY6Icg3_AqTax.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya", sbt_3w8Y94QEhFT0JkO4LOxfNUYI1REHbsL1WnUrtcKQDkSSH3ZACya)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_5TG5Zrn2suGTyhGDoPBs8Sj4MKJKBjSt1eEHwPftTszXxD45xTbL9hw.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw>::Type sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFwArray;

