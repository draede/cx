
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_gVagUy3 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2;

	virtual void Reset()
	{
		sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.push_back(-93);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gVagUy3 *pObject = dynamic_cast<const sbt_gVagUy3 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.size() != pObject->sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.size(); i++)
		{
			if (sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2[i] != pObject->sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.begin(); iter != sbt_y0uWciPm9wFVfAMLWMhmMF3bOqjY2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gVagUy3>::Type sbt_gVagUy3Array;

