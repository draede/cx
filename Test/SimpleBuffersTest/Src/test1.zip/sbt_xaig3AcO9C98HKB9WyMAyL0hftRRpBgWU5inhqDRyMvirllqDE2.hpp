
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_IEcPBwJwXG83EtM1Q2f.hpp"


class sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2;
	CX::Int64 sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw;
	CX::Int64 sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY;
	CX::IO::SimpleBuffers::FloatArray sbt_NhtMtqx_jkX2sjmbLjp;
	CX::Int8 sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT;
	CX::Int64 sbt_mDtqpTyGsvnkdwL7VaElc;
	CX::String sbt_63urffXGv;
	CX::Bool sbt_GubiJeP;
	CX::IO::SimpleBuffers::DoubleArray sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q;
	CX::IO::SimpleBuffers::UInt32Array sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt;
	CX::IO::SimpleBuffers::UInt16Array sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI;
	CX::IO::SimpleBuffers::UInt8Array sbt_eOaRG;
	CX::IO::SimpleBuffers::Int64Array sbt_CebnS;
	CX::Bool sbt_EfoHWiY;
	CX::Int8 sbt_MUv87ElFIzS;
	CX::UInt32 sbt_qQxjg7VYjQNIRjQq8I0;
	CX::IO::SimpleBuffers::Int32Array sbt_OFAaHYD1Lzq_6Dj4NBEEklp;
	CX::Int64 sbt_HGSog;
	CX::IO::SimpleBuffers::Int32Array sbt_uPUiG;
	CX::IO::SimpleBuffers::FloatArray sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI;
	CX::Int16 sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre;
	CX::String sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc;
	CX::IO::SimpleBuffers::UInt16Array sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc;
	CX::IO::SimpleBuffers::UInt16Array sbt_Ufn5CGDljDQxuqODVj2ppBP;
	CX::Int64 sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA;
	CX::IO::SimpleBuffers::UInt16Array sbt_8HRVM7X3P2sT_FfYpDo8n;
	CX::IO::SimpleBuffers::DoubleArray sbt_m9JpefmKD8gDN0m5c;
	CX::String sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv;
	sbt_IEcPBwJwXG83EtM1Q2f sbt_8v7jdazx4ETPCHC;

	virtual void Reset()
	{
		sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2 = 0;
		sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw = 0;
		sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY = 0;
		sbt_NhtMtqx_jkX2sjmbLjp.clear();
		sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT = 0;
		sbt_mDtqpTyGsvnkdwL7VaElc = 0;
		sbt_63urffXGv.clear();
		sbt_GubiJeP = false;
		sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.clear();
		sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.clear();
		sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.clear();
		sbt_eOaRG.clear();
		sbt_CebnS.clear();
		sbt_EfoHWiY = false;
		sbt_MUv87ElFIzS = 0;
		sbt_qQxjg7VYjQNIRjQq8I0 = 0;
		sbt_OFAaHYD1Lzq_6Dj4NBEEklp.clear();
		sbt_HGSog = 0;
		sbt_uPUiG.clear();
		sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.clear();
		sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre = 0;
		sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc.clear();
		sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.clear();
		sbt_Ufn5CGDljDQxuqODVj2ppBP.clear();
		sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA = 0;
		sbt_8HRVM7X3P2sT_FfYpDo8n.clear();
		sbt_m9JpefmKD8gDN0m5c.clear();
		sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv.clear();
		sbt_8v7jdazx4ETPCHC.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2 = -364761948;
		sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw = 6593114424174978442;
		sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY = 6812072584598992564;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_NhtMtqx_jkX2sjmbLjp.push_back(0.912118f);
		}
		sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT = 82;
		sbt_mDtqpTyGsvnkdwL7VaElc = -6861813814846389238;
		sbt_63urffXGv = "ZD7!~L-<x.kl?Mva!=n4{>Z<LOB4_z-S:<RFd80P|x-bZ|<sX/TOIh";
		sbt_GubiJeP = true;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.push_back(3677379222);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.push_back(2810);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_eOaRG.push_back(111);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_CebnS.push_back(992101543882848046);
		}
		sbt_EfoHWiY = true;
		sbt_MUv87ElFIzS = 78;
		sbt_qQxjg7VYjQNIRjQq8I0 = 3299317969;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_OFAaHYD1Lzq_6Dj4NBEEklp.push_back(-1922489785);
		}
		sbt_HGSog = -8009813497583894388;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_uPUiG.push_back(-306815834);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.push_back(0.875771f);
		}
		sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre = -25367;
		sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc = "&IeiG0[h:Qz)kI]*&$goo-*=`TVMB8tCXNwpryi^!1zD8GtUyz9|";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.push_back(62364);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Ufn5CGDljDQxuqODVj2ppBP.push_back(19592);
		}
		sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA = -8958883614969847030;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_8HRVM7X3P2sT_FfYpDo8n.push_back(33959);
		}
		sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv = "$Yxa55_{Lbh]jBe]jNE-']6Iu5m4H5'wSVlZa2Bi.7&v\"Vz";
		sbt_8v7jdazx4ETPCHC.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2 *pObject = dynamic_cast<const sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2 != pObject->sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2)
		{
			return false;
		}
		if (sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw != pObject->sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw)
		{
			return false;
		}
		if (sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY != pObject->sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY)
		{
			return false;
		}
		if (sbt_NhtMtqx_jkX2sjmbLjp.size() != pObject->sbt_NhtMtqx_jkX2sjmbLjp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NhtMtqx_jkX2sjmbLjp.size(); i++)
		{
			if (sbt_NhtMtqx_jkX2sjmbLjp[i] != pObject->sbt_NhtMtqx_jkX2sjmbLjp[i])
			{
				return false;
			}
		}
		if (sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT != pObject->sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT)
		{
			return false;
		}
		if (sbt_mDtqpTyGsvnkdwL7VaElc != pObject->sbt_mDtqpTyGsvnkdwL7VaElc)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_63urffXGv.c_str(), pObject->sbt_63urffXGv.c_str()))
		{
			return false;
		}
		if (sbt_GubiJeP != pObject->sbt_GubiJeP)
		{
			return false;
		}
		if (sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.size() != pObject->sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.size(); i++)
		{
			if (sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q[i] != pObject->sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q[i])
			{
				return false;
			}
		}
		if (sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.size() != pObject->sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.size(); i++)
		{
			if (sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt[i] != pObject->sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt[i])
			{
				return false;
			}
		}
		if (sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.size() != pObject->sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.size(); i++)
		{
			if (sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI[i] != pObject->sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI[i])
			{
				return false;
			}
		}
		if (sbt_eOaRG.size() != pObject->sbt_eOaRG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eOaRG.size(); i++)
		{
			if (sbt_eOaRG[i] != pObject->sbt_eOaRG[i])
			{
				return false;
			}
		}
		if (sbt_CebnS.size() != pObject->sbt_CebnS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CebnS.size(); i++)
		{
			if (sbt_CebnS[i] != pObject->sbt_CebnS[i])
			{
				return false;
			}
		}
		if (sbt_EfoHWiY != pObject->sbt_EfoHWiY)
		{
			return false;
		}
		if (sbt_MUv87ElFIzS != pObject->sbt_MUv87ElFIzS)
		{
			return false;
		}
		if (sbt_qQxjg7VYjQNIRjQq8I0 != pObject->sbt_qQxjg7VYjQNIRjQq8I0)
		{
			return false;
		}
		if (sbt_OFAaHYD1Lzq_6Dj4NBEEklp.size() != pObject->sbt_OFAaHYD1Lzq_6Dj4NBEEklp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OFAaHYD1Lzq_6Dj4NBEEklp.size(); i++)
		{
			if (sbt_OFAaHYD1Lzq_6Dj4NBEEklp[i] != pObject->sbt_OFAaHYD1Lzq_6Dj4NBEEklp[i])
			{
				return false;
			}
		}
		if (sbt_HGSog != pObject->sbt_HGSog)
		{
			return false;
		}
		if (sbt_uPUiG.size() != pObject->sbt_uPUiG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uPUiG.size(); i++)
		{
			if (sbt_uPUiG[i] != pObject->sbt_uPUiG[i])
			{
				return false;
			}
		}
		if (sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.size() != pObject->sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.size(); i++)
		{
			if (sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI[i] != pObject->sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI[i])
			{
				return false;
			}
		}
		if (sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre != pObject->sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc.c_str(), pObject->sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc.c_str()))
		{
			return false;
		}
		if (sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.size() != pObject->sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.size(); i++)
		{
			if (sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc[i] != pObject->sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc[i])
			{
				return false;
			}
		}
		if (sbt_Ufn5CGDljDQxuqODVj2ppBP.size() != pObject->sbt_Ufn5CGDljDQxuqODVj2ppBP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ufn5CGDljDQxuqODVj2ppBP.size(); i++)
		{
			if (sbt_Ufn5CGDljDQxuqODVj2ppBP[i] != pObject->sbt_Ufn5CGDljDQxuqODVj2ppBP[i])
			{
				return false;
			}
		}
		if (sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA != pObject->sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA)
		{
			return false;
		}
		if (sbt_8HRVM7X3P2sT_FfYpDo8n.size() != pObject->sbt_8HRVM7X3P2sT_FfYpDo8n.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8HRVM7X3P2sT_FfYpDo8n.size(); i++)
		{
			if (sbt_8HRVM7X3P2sT_FfYpDo8n[i] != pObject->sbt_8HRVM7X3P2sT_FfYpDo8n[i])
			{
				return false;
			}
		}
		if (sbt_m9JpefmKD8gDN0m5c.size() != pObject->sbt_m9JpefmKD8gDN0m5c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m9JpefmKD8gDN0m5c.size(); i++)
		{
			if (sbt_m9JpefmKD8gDN0m5c[i] != pObject->sbt_m9JpefmKD8gDN0m5c[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv.c_str(), pObject->sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv.c_str()))
		{
			return false;
		}
		if (!sbt_8v7jdazx4ETPCHC.Compare(&pObject->sbt_8v7jdazx4ETPCHC))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NhtMtqx_jkX2sjmbLjp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NhtMtqx_jkX2sjmbLjp.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mDtqpTyGsvnkdwL7VaElc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mDtqpTyGsvnkdwL7VaElc = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_63urffXGv", &sbt_63urffXGv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_GubiJeP", &sbt_GubiJeP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eOaRG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eOaRG.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CebnS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CebnS.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_EfoHWiY", &sbt_EfoHWiY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MUv87ElFIzS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MUv87ElFIzS = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qQxjg7VYjQNIRjQq8I0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qQxjg7VYjQNIRjQq8I0 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OFAaHYD1Lzq_6Dj4NBEEklp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OFAaHYD1Lzq_6Dj4NBEEklp.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HGSog", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HGSog = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uPUiG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uPUiG.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc", &sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ufn5CGDljDQxuqODVj2ppBP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ufn5CGDljDQxuqODVj2ppBP.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8HRVM7X3P2sT_FfYpDo8n")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8HRVM7X3P2sT_FfYpDo8n.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_m9JpefmKD8gDN0m5c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m9JpefmKD8gDN0m5c.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv", &sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_8v7jdazx4ETPCHC")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_8v7jdazx4ETPCHC.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2", (CX::Int64)sbt_a7zrOAJQ1So4KNiuMlQ23xW47TiCZckCRlBaaWN1ybkOjaQ3vr2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw", (CX::Int64)sbt_lbIXkHvbfkEaHnPeFE0L2L6O_dxLCVYpMfw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY", (CX::Int64)sbt_9tqW3no72_sgl5S1v9TVJ9C9wrcUvzY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NhtMtqx_jkX2sjmbLjp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_NhtMtqx_jkX2sjmbLjp.begin(); iter != sbt_NhtMtqx_jkX2sjmbLjp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT", (CX::Int64)sbt_ch2DFaectme_IRcX_KD7sSHuwPv2NYR5lWudbNdbS4rIrV7m4ewepmSrLVLrT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mDtqpTyGsvnkdwL7VaElc", (CX::Int64)sbt_mDtqpTyGsvnkdwL7VaElc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_63urffXGv", sbt_63urffXGv.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GubiJeP", sbt_GubiJeP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.begin(); iter != sbt_Ac4dXI_t_wfT1RgMq_HD2L0hxfxYB6q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.begin(); iter != sbt_wkRWRBLcnp93b_XFZ_3WhuZTp_NjTXcin3VnW95J5OpWW9IvErZyjjVrpXt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.begin(); iter != sbt_FfiRf2EwO_whBIMPmabWgqbCo5BQzSC6G8vsLyArI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eOaRG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_eOaRG.begin(); iter != sbt_eOaRG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CebnS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_CebnS.begin(); iter != sbt_CebnS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_EfoHWiY", sbt_EfoHWiY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MUv87ElFIzS", (CX::Int64)sbt_MUv87ElFIzS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qQxjg7VYjQNIRjQq8I0", (CX::Int64)sbt_qQxjg7VYjQNIRjQq8I0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OFAaHYD1Lzq_6Dj4NBEEklp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_OFAaHYD1Lzq_6Dj4NBEEklp.begin(); iter != sbt_OFAaHYD1Lzq_6Dj4NBEEklp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HGSog", (CX::Int64)sbt_HGSog)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uPUiG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_uPUiG.begin(); iter != sbt_uPUiG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.begin(); iter != sbt_6RzSlqJzXrxPonoM4R_sTzmcmK4m2nrPOxl3_LI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre", (CX::Int64)sbt_SVVnYBgEpRiRW_D2Yhd3_T1pNXnre)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc", sbt_YAXGyqWPSrJ4lrHWqFexJjO_etKg5OAJrKhy3XoIc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.begin(); iter != sbt_NceyAEwxPpwJI3sFlAX7Fzyrd61qWqy9RwT8pAYntQlgt2BpKqf4UfNN0LoVc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ufn5CGDljDQxuqODVj2ppBP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Ufn5CGDljDQxuqODVj2ppBP.begin(); iter != sbt_Ufn5CGDljDQxuqODVj2ppBP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA", (CX::Int64)sbt_ST8sWcDO_ORH8VWs0qNorTdFdbVEqn5TA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8HRVM7X3P2sT_FfYpDo8n")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_8HRVM7X3P2sT_FfYpDo8n.begin(); iter != sbt_8HRVM7X3P2sT_FfYpDo8n.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_m9JpefmKD8gDN0m5c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_m9JpefmKD8gDN0m5c.begin(); iter != sbt_m9JpefmKD8gDN0m5c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv", sbt_0hviC8JnzOmyTrL8KO6nKVQEfRuqFA0sJUf654_Qgi4Tarx20yP_Oslwn7tKHVv.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_8v7jdazx4ETPCHC")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_8v7jdazx4ETPCHC.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2>::Type sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2Array;

