
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP;
	CX::UInt32 sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ;
	CX::Int8 sbt_Lym;
	CX::IO::SimpleBuffers::Int64Array sbt_i67Q2oFHSQw7V2QVgmitHAhCN;
	CX::UInt32 sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG;
	CX::IO::SimpleBuffers::UInt8Array sbt_XOYaeHSrrAGRFomMM;
	CX::UInt16 sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR;
	CX::IO::SimpleBuffers::BoolArray sbt_bwCYzeA4M1N1K_s4eZJN_sTfr;
	CX::String sbt_f7IKSjUaQSfeei1HZ3OP8982C;
	CX::Bool sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2;

	virtual void Reset()
	{
		sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.clear();
		sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ = 0;
		sbt_Lym = 0;
		sbt_i67Q2oFHSQw7V2QVgmitHAhCN.clear();
		sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG = 0;
		sbt_XOYaeHSrrAGRFomMM.clear();
		sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR = 0;
		sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.clear();
		sbt_f7IKSjUaQSfeei1HZ3OP8982C.clear();
		sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2 = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.push_back(11533977599136130768);
		}
		sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ = 65232075;
		sbt_Lym = 127;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_i67Q2oFHSQw7V2QVgmitHAhCN.push_back(-7334445120125201300);
		}
		sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG = 2555249957;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_XOYaeHSrrAGRFomMM.push_back(227);
		}
		sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR = 60473;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.push_back(false);
		}
		sbt_f7IKSjUaQSfeei1HZ3OP8982C = "nK.EG<nO1h\"_4+|#>!Sb):5^}zi@-~h";
		sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2 = false;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X *pObject = dynamic_cast<const sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.size() != pObject->sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.size(); i++)
		{
			if (sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP[i] != pObject->sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP[i])
			{
				return false;
			}
		}
		if (sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ != pObject->sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ)
		{
			return false;
		}
		if (sbt_Lym != pObject->sbt_Lym)
		{
			return false;
		}
		if (sbt_i67Q2oFHSQw7V2QVgmitHAhCN.size() != pObject->sbt_i67Q2oFHSQw7V2QVgmitHAhCN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i67Q2oFHSQw7V2QVgmitHAhCN.size(); i++)
		{
			if (sbt_i67Q2oFHSQw7V2QVgmitHAhCN[i] != pObject->sbt_i67Q2oFHSQw7V2QVgmitHAhCN[i])
			{
				return false;
			}
		}
		if (sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG != pObject->sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG)
		{
			return false;
		}
		if (sbt_XOYaeHSrrAGRFomMM.size() != pObject->sbt_XOYaeHSrrAGRFomMM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XOYaeHSrrAGRFomMM.size(); i++)
		{
			if (sbt_XOYaeHSrrAGRFomMM[i] != pObject->sbt_XOYaeHSrrAGRFomMM[i])
			{
				return false;
			}
		}
		if (sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR != pObject->sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR)
		{
			return false;
		}
		if (sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.size() != pObject->sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.size(); i++)
		{
			if (sbt_bwCYzeA4M1N1K_s4eZJN_sTfr[i] != pObject->sbt_bwCYzeA4M1N1K_s4eZJN_sTfr[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_f7IKSjUaQSfeei1HZ3OP8982C.c_str(), pObject->sbt_f7IKSjUaQSfeei1HZ3OP8982C.c_str()))
		{
			return false;
		}
		if (sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2 != pObject->sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Lym", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Lym = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_i67Q2oFHSQw7V2QVgmitHAhCN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i67Q2oFHSQw7V2QVgmitHAhCN.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XOYaeHSrrAGRFomMM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XOYaeHSrrAGRFomMM.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bwCYzeA4M1N1K_s4eZJN_sTfr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_f7IKSjUaQSfeei1HZ3OP8982C", &sbt_f7IKSjUaQSfeei1HZ3OP8982C)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2", &sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.begin(); iter != sbt_MZcQH35vRrCr25aS3LFlQGXblHs2HZP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ", (CX::Int64)sbt_DZS4Uk1ctI9Nx0SVSQwsD_6iGOsWdhlEgDJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Lym", (CX::Int64)sbt_Lym)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i67Q2oFHSQw7V2QVgmitHAhCN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_i67Q2oFHSQw7V2QVgmitHAhCN.begin(); iter != sbt_i67Q2oFHSQw7V2QVgmitHAhCN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG", (CX::Int64)sbt_E_RmnpHoUj7y5NTOKZd36zFAlfw3DSHCVfP3ytapG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XOYaeHSrrAGRFomMM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XOYaeHSrrAGRFomMM.begin(); iter != sbt_XOYaeHSrrAGRFomMM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR", (CX::Int64)sbt_qPEmgcByn2i13SfXAKTVHJnaOfugRlS9huckGIC6YqCAt28Z13pmG8kdNpR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bwCYzeA4M1N1K_s4eZJN_sTfr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.begin(); iter != sbt_bwCYzeA4M1N1K_s4eZJN_sTfr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_f7IKSjUaQSfeei1HZ3OP8982C", sbt_f7IKSjUaQSfeei1HZ3OP8982C.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2", sbt_kbGzrc8EQvQOMdUhgOvdEhZ9pf42zqyNMnrVF5YnZjZ_m046rY3P2)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X>::Type sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096XArray;

