
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_5lCZz6s7wDo.hpp"


class sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_jh94K;
	CX::IO::SimpleBuffers::UInt8Array sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC;
	CX::String sbt_1_cDptX_UKK1GF7psUc;
	CX::IO::SimpleBuffers::BoolArray sbt_B8Az4FWqbKXeG;
	CX::Int8 sbt_tNP85ounnU_oZNAunWG8E;
	CX::Int16 sbt_n_QIumrau7YX7OmaZD4M4;
	CX::IO::SimpleBuffers::Int32Array sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A;
	CX::UInt16 sbt_5;
	CX::Int64 sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ;
	CX::IO::SimpleBuffers::WStringArray sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP;
	CX::Int64 sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P;
	CX::IO::SimpleBuffers::WStringArray sbt_iRxYF9grOA8V7WTxMKAnfrDGx;
	CX::IO::SimpleBuffers::Int8Array sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7;
	CX::IO::SimpleBuffers::UInt16Array sbt_wO3l9z0yq;
	CX::Int16 sbt_ylJmjS9MqG07eu0WjNzMl;
	CX::UInt32 sbt_ApOWU7RQd2BU_MyxJAq;
	CX::IO::SimpleBuffers::StringArray sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx;
	CX::IO::SimpleBuffers::StringArray sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES;
	CX::Bool sbt_WDMZb;
	CX::IO::SimpleBuffers::UInt32Array sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB;
	CX::Int8 sbt_x;
	CX::IO::SimpleBuffers::UInt32Array sbt_d6Sw3U1OxyGG8ir;
	CX::Int16 sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W;
	CX::UInt32 sbt_sTLa4FJOm;
	CX::IO::SimpleBuffers::Int32Array sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns;
	sbt_5lCZz6s7wDoArray sbt_or4ur_secColNfuIOyOz_;

	virtual void Reset()
	{
		sbt_jh94K = 0;
		sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.clear();
		sbt_1_cDptX_UKK1GF7psUc.clear();
		sbt_B8Az4FWqbKXeG.clear();
		sbt_tNP85ounnU_oZNAunWG8E = 0;
		sbt_n_QIumrau7YX7OmaZD4M4 = 0;
		sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.clear();
		sbt_5 = 0;
		sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ = 0;
		sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.clear();
		sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P = 0;
		sbt_iRxYF9grOA8V7WTxMKAnfrDGx.clear();
		sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.clear();
		sbt_wO3l9z0yq.clear();
		sbt_ylJmjS9MqG07eu0WjNzMl = 0;
		sbt_ApOWU7RQd2BU_MyxJAq = 0;
		sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.clear();
		sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.clear();
		sbt_WDMZb = false;
		sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.clear();
		sbt_x = 0;
		sbt_d6Sw3U1OxyGG8ir.clear();
		sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W = 0;
		sbt_sTLa4FJOm = 0;
		sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.clear();
		sbt_or4ur_secColNfuIOyOz_.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_jh94K = -28329;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.push_back(126);
		}
		sbt_1_cDptX_UKK1GF7psUc = "I-*H/Ba`OpTEUPMNn4}c&r~IfA_FhM586%o'nml#):X>aj8t^ns7";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_B8Az4FWqbKXeG.push_back(false);
		}
		sbt_tNP85ounnU_oZNAunWG8E = -32;
		sbt_n_QIumrau7YX7OmaZD4M4 = 25062;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.push_back(2024180639);
		}
		sbt_5 = 28318;
		sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ = 3605601505090476698;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.push_back(L"cedy{N");
		}
		sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P = 6500214650755806688;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_iRxYF9grOA8V7WTxMKAnfrDGx.push_back(L"w__I,{<q|`Go1EK3E=cC5Wd%n4(");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.push_back(-99);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_wO3l9z0yq.push_back(43422);
		}
		sbt_ylJmjS9MqG07eu0WjNzMl = -18177;
		sbt_ApOWU7RQd2BU_MyxJAq = 3122689659;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.push_back("dlF!<qy7`^.IY");
		}
		sbt_WDMZb = true;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.push_back(3094258733);
		}
		sbt_x = 18;
		sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W = 25611;
		sbt_sTLa4FJOm = 3094988143;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.push_back(1065060206);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_5lCZz6s7wDo v;

			v.SetupWithSomeValues();
			sbt_or4ur_secColNfuIOyOz_.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg *pObject = dynamic_cast<const sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_jh94K != pObject->sbt_jh94K)
		{
			return false;
		}
		if (sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.size() != pObject->sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.size(); i++)
		{
			if (sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC[i] != pObject->sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_1_cDptX_UKK1GF7psUc.c_str(), pObject->sbt_1_cDptX_UKK1GF7psUc.c_str()))
		{
			return false;
		}
		if (sbt_B8Az4FWqbKXeG.size() != pObject->sbt_B8Az4FWqbKXeG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B8Az4FWqbKXeG.size(); i++)
		{
			if (sbt_B8Az4FWqbKXeG[i] != pObject->sbt_B8Az4FWqbKXeG[i])
			{
				return false;
			}
		}
		if (sbt_tNP85ounnU_oZNAunWG8E != pObject->sbt_tNP85ounnU_oZNAunWG8E)
		{
			return false;
		}
		if (sbt_n_QIumrau7YX7OmaZD4M4 != pObject->sbt_n_QIumrau7YX7OmaZD4M4)
		{
			return false;
		}
		if (sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.size() != pObject->sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.size(); i++)
		{
			if (sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A[i] != pObject->sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A[i])
			{
				return false;
			}
		}
		if (sbt_5 != pObject->sbt_5)
		{
			return false;
		}
		if (sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ != pObject->sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ)
		{
			return false;
		}
		if (sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.size() != pObject->sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP[i].c_str(), pObject->sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P != pObject->sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P)
		{
			return false;
		}
		if (sbt_iRxYF9grOA8V7WTxMKAnfrDGx.size() != pObject->sbt_iRxYF9grOA8V7WTxMKAnfrDGx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iRxYF9grOA8V7WTxMKAnfrDGx.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_iRxYF9grOA8V7WTxMKAnfrDGx[i].c_str(), pObject->sbt_iRxYF9grOA8V7WTxMKAnfrDGx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.size() != pObject->sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.size(); i++)
		{
			if (sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7[i] != pObject->sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7[i])
			{
				return false;
			}
		}
		if (sbt_wO3l9z0yq.size() != pObject->sbt_wO3l9z0yq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wO3l9z0yq.size(); i++)
		{
			if (sbt_wO3l9z0yq[i] != pObject->sbt_wO3l9z0yq[i])
			{
				return false;
			}
		}
		if (sbt_ylJmjS9MqG07eu0WjNzMl != pObject->sbt_ylJmjS9MqG07eu0WjNzMl)
		{
			return false;
		}
		if (sbt_ApOWU7RQd2BU_MyxJAq != pObject->sbt_ApOWU7RQd2BU_MyxJAq)
		{
			return false;
		}
		if (sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.size() != pObject->sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.size(); i++)
		{
			if (0 != cx_strcmp(sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx[i].c_str(), pObject->sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.size() != pObject->sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.size(); i++)
		{
			if (0 != cx_strcmp(sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES[i].c_str(), pObject->sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_WDMZb != pObject->sbt_WDMZb)
		{
			return false;
		}
		if (sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.size() != pObject->sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.size(); i++)
		{
			if (sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB[i] != pObject->sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB[i])
			{
				return false;
			}
		}
		if (sbt_x != pObject->sbt_x)
		{
			return false;
		}
		if (sbt_d6Sw3U1OxyGG8ir.size() != pObject->sbt_d6Sw3U1OxyGG8ir.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d6Sw3U1OxyGG8ir.size(); i++)
		{
			if (sbt_d6Sw3U1OxyGG8ir[i] != pObject->sbt_d6Sw3U1OxyGG8ir[i])
			{
				return false;
			}
		}
		if (sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W != pObject->sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W)
		{
			return false;
		}
		if (sbt_sTLa4FJOm != pObject->sbt_sTLa4FJOm)
		{
			return false;
		}
		if (sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.size() != pObject->sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.size(); i++)
		{
			if (sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns[i] != pObject->sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns[i])
			{
				return false;
			}
		}
		if (sbt_or4ur_secColNfuIOyOz_.size() != pObject->sbt_or4ur_secColNfuIOyOz_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_or4ur_secColNfuIOyOz_.size(); i++)
		{
			if (!sbt_or4ur_secColNfuIOyOz_[i].Compare(&pObject->sbt_or4ur_secColNfuIOyOz_[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_jh94K", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jh94K = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_1_cDptX_UKK1GF7psUc", &sbt_1_cDptX_UKK1GF7psUc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_B8Az4FWqbKXeG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B8Az4FWqbKXeG.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tNP85ounnU_oZNAunWG8E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tNP85ounnU_oZNAunWG8E = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_n_QIumrau7YX7OmaZD4M4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n_QIumrau7YX7OmaZD4M4 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iRxYF9grOA8V7WTxMKAnfrDGx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iRxYF9grOA8V7WTxMKAnfrDGx.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wO3l9z0yq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wO3l9z0yq.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ylJmjS9MqG07eu0WjNzMl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ylJmjS9MqG07eu0WjNzMl = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ApOWU7RQd2BU_MyxJAq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ApOWU7RQd2BU_MyxJAq = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_WDMZb", &sbt_WDMZb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_x", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_x = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_d6Sw3U1OxyGG8ir")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d6Sw3U1OxyGG8ir.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sTLa4FJOm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sTLa4FJOm = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_or4ur_secColNfuIOyOz_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_5lCZz6s7wDo tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_or4ur_secColNfuIOyOz_.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_jh94K", (CX::Int64)sbt_jh94K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.begin(); iter != sbt_tbsV9FGnCfaSXGdJhx0gzS2InjnbhX5ZPoDpBBo5enC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_1_cDptX_UKK1GF7psUc", sbt_1_cDptX_UKK1GF7psUc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B8Az4FWqbKXeG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_B8Az4FWqbKXeG.begin(); iter != sbt_B8Az4FWqbKXeG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tNP85ounnU_oZNAunWG8E", (CX::Int64)sbt_tNP85ounnU_oZNAunWG8E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n_QIumrau7YX7OmaZD4M4", (CX::Int64)sbt_n_QIumrau7YX7OmaZD4M4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.begin(); iter != sbt_USJpHI2D9cQqMQVEyEbcYyMykEwx2iJgAoI9A.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5", (CX::Int64)sbt_5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ", (CX::Int64)sbt_jvjamp5CzT1Ou7wnjlLEVTxjyTZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.begin(); iter != sbt_WXrVQCQaz13MM68QTulaB6I6Eyn55lmZ6yCruoHWqsoBDI888kkaerP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P", (CX::Int64)sbt_zol1wubTs6ab991GOJG_28CaCxJWT32OKq2oPZMmR7xdCV03lBEQYPd8P)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iRxYF9grOA8V7WTxMKAnfrDGx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_iRxYF9grOA8V7WTxMKAnfrDGx.begin(); iter != sbt_iRxYF9grOA8V7WTxMKAnfrDGx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.begin(); iter != sbt_tfEiun4DXd6ExgwTSYA6UWCEy6dV3q7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wO3l9z0yq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_wO3l9z0yq.begin(); iter != sbt_wO3l9z0yq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ylJmjS9MqG07eu0WjNzMl", (CX::Int64)sbt_ylJmjS9MqG07eu0WjNzMl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ApOWU7RQd2BU_MyxJAq", (CX::Int64)sbt_ApOWU7RQd2BU_MyxJAq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.begin(); iter != sbt_LQQi4iPUPKc_SmUaRUiUMilWmgL6z4X2esGpiqbaZkx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.begin(); iter != sbt_NpXnqrDBfwdl5JI8YQi8VF0HH_DxoPshbA7VScpyVkKumqpES.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_WDMZb", sbt_WDMZb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.begin(); iter != sbt_uq1kUzIKwtg_nbnlYu_wATt5z2ew9sDGuBp2AjJfRRVwIm9Y8GB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_x", (CX::Int64)sbt_x)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d6Sw3U1OxyGG8ir")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_d6Sw3U1OxyGG8ir.begin(); iter != sbt_d6Sw3U1OxyGG8ir.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W", (CX::Int64)sbt_lpN17bhdKbnf_Qy4BA26XdZ5JpQxZsAu31W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sTLa4FJOm", (CX::Int64)sbt_sTLa4FJOm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.begin(); iter != sbt_YgUbYfNIVJndbqLHkkj2YPcP5ZKj224M0s6qgrbF3Ro3pFmnzcFFnmPegjHns.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_or4ur_secColNfuIOyOz_")).IsNOK())
		{
			return status;
		}
		for (sbt_5lCZz6s7wDoArray::const_iterator iter = sbt_or4ur_secColNfuIOyOz_.begin(); iter != sbt_or4ur_secColNfuIOyOz_.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg>::Type sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRgArray;

