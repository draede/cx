
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3;
	CX::Int64 sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL;
	CX::String sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p;
	CX::UInt64 sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM;
	CX::String sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I;
	CX::IO::SimpleBuffers::Int8Array sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd;
	CX::Int16 sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk;
	CX::IO::SimpleBuffers::UInt32Array sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50;
	CX::IO::SimpleBuffers::Int16Array sbt_pwVOl8evQFpDef8yQKovj;
	CX::IO::SimpleBuffers::StringArray sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi;
	CX::IO::SimpleBuffers::Int64Array sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL;
	CX::UInt64 sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF;
	CX::Int16 sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q;
	CX::UInt64 sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k;
	CX::UInt32 sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg;

	virtual void Reset()
	{
		sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3 = 0;
		sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL = 0;
		sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p.clear();
		sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM = 0;
		sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I.clear();
		sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.clear();
		sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk = 0;
		sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.clear();
		sbt_pwVOl8evQFpDef8yQKovj.clear();
		sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.clear();
		sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.clear();
		sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF = 0;
		sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q = 0;
		sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k = 0;
		sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3 = -1683485355;
		sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL = 3618699411370653864;
		sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p = "bTvTlsSqwAAV5bHs0SF\\`]:!`z7xWO80gaN,UXV[*{GB,8KVY4";
		sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM = 2281124226731178310;
		sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I = "&p^]=lb;uNSAdIMd8juk>;Ud3`evfJlG<LF2aYg,uhZSDgn(fo@\"$S";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.push_back(124);
		}
		sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk = -20407;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.push_back(460205749);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_pwVOl8evQFpDef8yQKovj.push_back(-9495);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.push_back("W6rXRh+3=O1c=4Nmq!\";L_%l,+f2ED_!`w()~LqkBHh{-KS<Bq.7QKO\\tlP");
		}
		sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF = 6422580869661503482;
		sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q = 5024;
		sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k = 2279609193503703538;
		sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg = 1585578157;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 *pObject = dynamic_cast<const sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3 != pObject->sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3)
		{
			return false;
		}
		if (sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL != pObject->sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p.c_str(), pObject->sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p.c_str()))
		{
			return false;
		}
		if (sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM != pObject->sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I.c_str(), pObject->sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I.c_str()))
		{
			return false;
		}
		if (sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.size() != pObject->sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.size(); i++)
		{
			if (sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd[i] != pObject->sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd[i])
			{
				return false;
			}
		}
		if (sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk != pObject->sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk)
		{
			return false;
		}
		if (sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.size() != pObject->sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.size(); i++)
		{
			if (sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50[i] != pObject->sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50[i])
			{
				return false;
			}
		}
		if (sbt_pwVOl8evQFpDef8yQKovj.size() != pObject->sbt_pwVOl8evQFpDef8yQKovj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pwVOl8evQFpDef8yQKovj.size(); i++)
		{
			if (sbt_pwVOl8evQFpDef8yQKovj[i] != pObject->sbt_pwVOl8evQFpDef8yQKovj[i])
			{
				return false;
			}
		}
		if (sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.size() != pObject->sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.size(); i++)
		{
			if (0 != cx_strcmp(sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi[i].c_str(), pObject->sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.size() != pObject->sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.size(); i++)
		{
			if (sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL[i] != pObject->sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL[i])
			{
				return false;
			}
		}
		if (sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF != pObject->sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF)
		{
			return false;
		}
		if (sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q != pObject->sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q)
		{
			return false;
		}
		if (sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k != pObject->sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k)
		{
			return false;
		}
		if (sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg != pObject->sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p", &sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I", &sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pwVOl8evQFpDef8yQKovj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pwVOl8evQFpDef8yQKovj.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3", (CX::Int64)sbt_dzj1__hNLjZ3VcrHhdx7AZRtD20BfIkCej_GOlDM5Qh7SImLnSkLej2p3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL", (CX::Int64)sbt_0QwBBgLSBHnz6V2O2xGH2xIo9AtuxWlA9it4H64CL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p", sbt_1BJJVftn9b_S0NtbaDNixElKHEF_p.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM", (CX::Int64)sbt_yS8BnVZhAxu0sQrzIaW5dfwOdRmPqrIGnXH_zV6n54_sh2A2eszKuthD7rHEUvM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I", sbt_rihrJzFbS8w3CJUvcxqagMtIBypkMjfkkG9urPPx25Q5AzQ5VKM3I.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.begin(); iter != sbt_M0ReRMsx7Y9IUoSCq2VfSCrBd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk", (CX::Int64)sbt_SxR8cgopa7nNuLHIfRWHS2gFnxxndyO5vca0Abox7OJgFQ0K7rUsk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.begin(); iter != sbt_lvVEHkpHFfjWQ6Oc3QESwg7pjAOgupUW3PKXut2fmmD50.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pwVOl8evQFpDef8yQKovj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_pwVOl8evQFpDef8yQKovj.begin(); iter != sbt_pwVOl8evQFpDef8yQKovj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.begin(); iter != sbt_F6Q4nAkIQB_3oa4i9tVG4HtPlgb0Ny_wrABTJOmzQ5CBa9Soi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.begin(); iter != sbt_VCTm_IIjUFgr8Leejiu9pX0p1oj5x69QAcNVsTBJeKtj2RcIMWCIgtL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF", (CX::Int64)sbt_Vz225mSbsoPEWlkBK0zhpciCa7IhPHIcCo2jyPF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q", (CX::Int64)sbt_49WazfHmR1LaMcZoWSSliqps94kVpUcB1RZBE6toDPcvXvUBv_lwI1w9q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k", (CX::Int64)sbt_89qW9DBoWLNyKnhbnM9VaDIpfln9k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg", (CX::Int64)sbt_IbBA11OrPDHXdZyGhYCKrAYMlIB7XMt0KVU1SJBv3Eg)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6>::Type sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6Array;

