
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_d7J.hpp"


class sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_ROUW37TO4WOyylcGNp7KY;
	CX::IO::SimpleBuffers::UInt8Array sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK;
	CX::Int32 sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl;
	CX::IO::SimpleBuffers::UInt64Array sbt_FSJRgPeb5C9xfcs;
	CX::Int16 sbt_IUJBjLp9CSyFtWCTZAz;
	CX::UInt64 sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ;
	CX::Double sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r;
	CX::Int8 sbt_04jc9jWiYb9vXmKXrV9dR;
	CX::Double sbt_w95lfrboSzZ;
	CX::UInt64 sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7;
	CX::UInt16 sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S;
	CX::Int16 sbt_SBeOW;
	CX::IO::SimpleBuffers::Int16Array sbt_ZAtWExC_xVfnH;
	CX::Double sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh;
	CX::String sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp;
	CX::Bool sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k;
	CX::IO::SimpleBuffers::FloatArray sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7;
	CX::UInt8 sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55;
	CX::IO::SimpleBuffers::Int8Array sbt_y5Md3;
	CX::IO::SimpleBuffers::WStringArray sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5;
	CX::Int64 sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J;
	CX::IO::SimpleBuffers::BoolArray sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP;
	CX::Double sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_;
	CX::IO::SimpleBuffers::Int64Array sbt_si18dATFlYeQQrt;
	sbt_d7J sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z;

	virtual void Reset()
	{
		sbt_ROUW37TO4WOyylcGNp7KY = 0.0;
		sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.clear();
		sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl = 0;
		sbt_FSJRgPeb5C9xfcs.clear();
		sbt_IUJBjLp9CSyFtWCTZAz = 0;
		sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ = 0;
		sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r = 0.0;
		sbt_04jc9jWiYb9vXmKXrV9dR = 0;
		sbt_w95lfrboSzZ = 0.0;
		sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7 = 0;
		sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S = 0;
		sbt_SBeOW = 0;
		sbt_ZAtWExC_xVfnH.clear();
		sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh = 0.0;
		sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp.clear();
		sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k = false;
		sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.clear();
		sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55 = 0;
		sbt_y5Md3.clear();
		sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.clear();
		sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J = 0;
		sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.clear();
		sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_ = 0.0;
		sbt_si18dATFlYeQQrt.clear();
		sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ROUW37TO4WOyylcGNp7KY = 0.522410;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.push_back(115);
		}
		sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl = -1778544079;
		sbt_IUJBjLp9CSyFtWCTZAz = -31499;
		sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ = 17738239260502196752;
		sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r = 0.412649;
		sbt_04jc9jWiYb9vXmKXrV9dR = -10;
		sbt_w95lfrboSzZ = 0.448202;
		sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7 = 13414532363898724982;
		sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S = 23139;
		sbt_SBeOW = -11384;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_ZAtWExC_xVfnH.push_back(-22947);
		}
		sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh = 0.310467;
		sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp = "h4^\"Fcoaml+CRcVv!/0q.h4#cDspPp&{'_hU-pXczIs^M7D1";
		sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k = true;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.push_back(0.583764f);
		}
		sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55 = 162;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_y5Md3.push_back(44);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.push_back(L"pa\"Y(c.x2SWnlpXFBVt/WD?5F$xY!;");
		}
		sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J = 1990996711641823870;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.push_back(true);
		}
		sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_ = 0.932360;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_si18dATFlYeQQrt.push_back(4838876138650531806);
		}
		sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ *pObject = dynamic_cast<const sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ROUW37TO4WOyylcGNp7KY != pObject->sbt_ROUW37TO4WOyylcGNp7KY)
		{
			return false;
		}
		if (sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.size() != pObject->sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.size(); i++)
		{
			if (sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK[i] != pObject->sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK[i])
			{
				return false;
			}
		}
		if (sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl != pObject->sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl)
		{
			return false;
		}
		if (sbt_FSJRgPeb5C9xfcs.size() != pObject->sbt_FSJRgPeb5C9xfcs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FSJRgPeb5C9xfcs.size(); i++)
		{
			if (sbt_FSJRgPeb5C9xfcs[i] != pObject->sbt_FSJRgPeb5C9xfcs[i])
			{
				return false;
			}
		}
		if (sbt_IUJBjLp9CSyFtWCTZAz != pObject->sbt_IUJBjLp9CSyFtWCTZAz)
		{
			return false;
		}
		if (sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ != pObject->sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ)
		{
			return false;
		}
		if (sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r != pObject->sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r)
		{
			return false;
		}
		if (sbt_04jc9jWiYb9vXmKXrV9dR != pObject->sbt_04jc9jWiYb9vXmKXrV9dR)
		{
			return false;
		}
		if (sbt_w95lfrboSzZ != pObject->sbt_w95lfrboSzZ)
		{
			return false;
		}
		if (sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7 != pObject->sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7)
		{
			return false;
		}
		if (sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S != pObject->sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S)
		{
			return false;
		}
		if (sbt_SBeOW != pObject->sbt_SBeOW)
		{
			return false;
		}
		if (sbt_ZAtWExC_xVfnH.size() != pObject->sbt_ZAtWExC_xVfnH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZAtWExC_xVfnH.size(); i++)
		{
			if (sbt_ZAtWExC_xVfnH[i] != pObject->sbt_ZAtWExC_xVfnH[i])
			{
				return false;
			}
		}
		if (sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh != pObject->sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp.c_str(), pObject->sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp.c_str()))
		{
			return false;
		}
		if (sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k != pObject->sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k)
		{
			return false;
		}
		if (sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.size() != pObject->sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.size(); i++)
		{
			if (sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7[i] != pObject->sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7[i])
			{
				return false;
			}
		}
		if (sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55 != pObject->sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55)
		{
			return false;
		}
		if (sbt_y5Md3.size() != pObject->sbt_y5Md3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y5Md3.size(); i++)
		{
			if (sbt_y5Md3[i] != pObject->sbt_y5Md3[i])
			{
				return false;
			}
		}
		if (sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.size() != pObject->sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5[i].c_str(), pObject->sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J != pObject->sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J)
		{
			return false;
		}
		if (sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.size() != pObject->sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.size(); i++)
		{
			if (sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP[i] != pObject->sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP[i])
			{
				return false;
			}
		}
		if (sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_ != pObject->sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_)
		{
			return false;
		}
		if (sbt_si18dATFlYeQQrt.size() != pObject->sbt_si18dATFlYeQQrt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_si18dATFlYeQQrt.size(); i++)
		{
			if (sbt_si18dATFlYeQQrt[i] != pObject->sbt_si18dATFlYeQQrt[i])
			{
				return false;
			}
		}
		if (!sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z.Compare(&pObject->sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_ROUW37TO4WOyylcGNp7KY", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ROUW37TO4WOyylcGNp7KY = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FSJRgPeb5C9xfcs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FSJRgPeb5C9xfcs.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IUJBjLp9CSyFtWCTZAz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IUJBjLp9CSyFtWCTZAz = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_04jc9jWiYb9vXmKXrV9dR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_04jc9jWiYb9vXmKXrV9dR = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_w95lfrboSzZ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_w95lfrboSzZ = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SBeOW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SBeOW = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZAtWExC_xVfnH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZAtWExC_xVfnH.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectString("sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp", &sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k", &sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_y5Md3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y5Md3.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_ = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_si18dATFlYeQQrt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_si18dATFlYeQQrt.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_ROUW37TO4WOyylcGNp7KY", (CX::Double)sbt_ROUW37TO4WOyylcGNp7KY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.begin(); iter != sbt_oxfCvHTBcdumtGKCRJmpg6NYTWniuQ6MwvZDK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl", (CX::Int64)sbt_HOjTZHbzL2YQu4BpqPtGxuZqiTmwINl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FSJRgPeb5C9xfcs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_FSJRgPeb5C9xfcs.begin(); iter != sbt_FSJRgPeb5C9xfcs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IUJBjLp9CSyFtWCTZAz", (CX::Int64)sbt_IUJBjLp9CSyFtWCTZAz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ", (CX::Int64)sbt_Ca1hOJde_OwYnQrSoh38x_RqPCiRr40lEgJ5e2UdtvfY2TB6sdQqxzzAtofPXeZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r", (CX::Double)sbt_ZkbfiESpo9qMRXVTxAUg82BMdAW2r)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_04jc9jWiYb9vXmKXrV9dR", (CX::Int64)sbt_04jc9jWiYb9vXmKXrV9dR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_w95lfrboSzZ", (CX::Double)sbt_w95lfrboSzZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7", (CX::Int64)sbt_NDU8cCmC7qXW_fiIXUAi6joS2hIrg7m8hMwwTdtFoQZL76GiRBXX7bFd7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S", (CX::Int64)sbt_NWOcu0j11CgKXX0Zh3TuTUB9ODR24eEvfIO2iSbsoKjAyi8VdloIWOq9QOcOO4S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SBeOW", (CX::Int64)sbt_SBeOW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZAtWExC_xVfnH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ZAtWExC_xVfnH.begin(); iter != sbt_ZAtWExC_xVfnH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh", (CX::Double)sbt_RKRKK9KpRaL5zW2H5Et891mfpGNPzPGiUuIhh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp", sbt_NKcyUJ9whgA93XHpBmCRCU5mgSoWYNsXcCI3aaP78Zcpp.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k", sbt_GXu6n4YnuIe_9Nmr8cYuxvVtUWyL9nM854k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.begin(); iter != sbt_jeNPK9DkrtP6vioidP78k_yoNoQUPgHvD2H0gnm3Sp9qy8o4oR7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55", (CX::Int64)sbt_SiIdW_ZsA_30ywMbfi5UccpHzl3riEVTFaTnxuwoSli_BoNs4sgcUN6rXeL_u55)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y5Md3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_y5Md3.begin(); iter != sbt_y5Md3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.begin(); iter != sbt_x4VbxyOieHCCN7a27OJu6HXtM27KxjSTLC9WPIZ8X3c_5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J", (CX::Int64)sbt_1Dce_4dTIOCCC87mpOkNQTfolYkd9z7vp8J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.begin(); iter != sbt_Hada_HRtVPnfx5N4k_3lhWl7wvP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_", (CX::Double)sbt_oDniD3qa3QPxgX9JiwfIDt_ytDOn_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_si18dATFlYeQQrt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_si18dATFlYeQQrt.begin(); iter != sbt_si18dATFlYeQQrt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ExwoBvFu47tbwrEMaPz1dA0V5U18Z.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ>::Type sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQArray;

