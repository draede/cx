
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I;
	CX::UInt16 sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV;
	CX::IO::SimpleBuffers::Int64Array sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_;
	CX::IO::SimpleBuffers::Int8Array sbt_hR3Qu;
	CX::IO::SimpleBuffers::UInt8Array sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH;
	CX::IO::SimpleBuffers::UInt32Array sbt_NGyEJ_IO530KAad0dOe2E;
	CX::Bool sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls;
	CX::IO::SimpleBuffers::Int64Array sbt_MyV;
	CX::Int8 sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA;
	CX::Int16 sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge;
	CX::IO::SimpleBuffers::StringArray sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ;
	CX::UInt32 sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT;
	CX::IO::SimpleBuffers::StringArray sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU;
	CX::String sbt_IacqprDQrsXG0ECINiZW7cXIA86bG;
	CX::IO::SimpleBuffers::BoolArray sbt_sIs9lET68vvSiiQHksnvLh7k_;
	CX::Int16 sbt_iKTZiClzI_RpsVHuO0X2J19;

	virtual void Reset()
	{
		sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.clear();
		sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV = 0;
		sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.clear();
		sbt_hR3Qu.clear();
		sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.clear();
		sbt_NGyEJ_IO530KAad0dOe2E.clear();
		sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls = false;
		sbt_MyV.clear();
		sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA = 0;
		sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge = 0;
		sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.clear();
		sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT = 0;
		sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.clear();
		sbt_IacqprDQrsXG0ECINiZW7cXIA86bG.clear();
		sbt_sIs9lET68vvSiiQHksnvLh7k_.clear();
		sbt_iKTZiClzI_RpsVHuO0X2J19 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.push_back(-62);
		}
		sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV = 15670;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.push_back(-8633297878702112442);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_hR3Qu.push_back(116);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.push_back(75);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_NGyEJ_IO530KAad0dOe2E.push_back(2816084404);
		}
		sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_MyV.push_back(-7553844879061657974);
		}
		sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA = -43;
		sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge = -22303;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.push_back("JYK,0~O`{j|2j]}3zWj:kHCysd$w.d/");
		}
		sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT = 2639355603;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.push_back("~UwC=zgq;!QzlkTQ7#Z");
		}
		sbt_IacqprDQrsXG0ECINiZW7cXIA86bG = "sh*0rCfzU!1_2WM&aqKbgB#K2fxQqp/y]Fpuj7J]f>[Eqd|:4![";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_sIs9lET68vvSiiQHksnvLh7k_.push_back(false);
		}
		sbt_iKTZiClzI_RpsVHuO0X2J19 = 4739;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz *pObject = dynamic_cast<const sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.size() != pObject->sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.size(); i++)
		{
			if (sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I[i] != pObject->sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I[i])
			{
				return false;
			}
		}
		if (sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV != pObject->sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV)
		{
			return false;
		}
		if (sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.size() != pObject->sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.size(); i++)
		{
			if (sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_[i] != pObject->sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_[i])
			{
				return false;
			}
		}
		if (sbt_hR3Qu.size() != pObject->sbt_hR3Qu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hR3Qu.size(); i++)
		{
			if (sbt_hR3Qu[i] != pObject->sbt_hR3Qu[i])
			{
				return false;
			}
		}
		if (sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.size() != pObject->sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.size(); i++)
		{
			if (sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH[i] != pObject->sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH[i])
			{
				return false;
			}
		}
		if (sbt_NGyEJ_IO530KAad0dOe2E.size() != pObject->sbt_NGyEJ_IO530KAad0dOe2E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NGyEJ_IO530KAad0dOe2E.size(); i++)
		{
			if (sbt_NGyEJ_IO530KAad0dOe2E[i] != pObject->sbt_NGyEJ_IO530KAad0dOe2E[i])
			{
				return false;
			}
		}
		if (sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls != pObject->sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls)
		{
			return false;
		}
		if (sbt_MyV.size() != pObject->sbt_MyV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MyV.size(); i++)
		{
			if (sbt_MyV[i] != pObject->sbt_MyV[i])
			{
				return false;
			}
		}
		if (sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA != pObject->sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA)
		{
			return false;
		}
		if (sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge != pObject->sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge)
		{
			return false;
		}
		if (sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.size() != pObject->sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ[i].c_str(), pObject->sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT != pObject->sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT)
		{
			return false;
		}
		if (sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.size() != pObject->sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.size(); i++)
		{
			if (0 != cx_strcmp(sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU[i].c_str(), pObject->sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_IacqprDQrsXG0ECINiZW7cXIA86bG.c_str(), pObject->sbt_IacqprDQrsXG0ECINiZW7cXIA86bG.c_str()))
		{
			return false;
		}
		if (sbt_sIs9lET68vvSiiQHksnvLh7k_.size() != pObject->sbt_sIs9lET68vvSiiQHksnvLh7k_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sIs9lET68vvSiiQHksnvLh7k_.size(); i++)
		{
			if (sbt_sIs9lET68vvSiiQHksnvLh7k_[i] != pObject->sbt_sIs9lET68vvSiiQHksnvLh7k_[i])
			{
				return false;
			}
		}
		if (sbt_iKTZiClzI_RpsVHuO0X2J19 != pObject->sbt_iKTZiClzI_RpsVHuO0X2J19)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hR3Qu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hR3Qu.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NGyEJ_IO530KAad0dOe2E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NGyEJ_IO530KAad0dOe2E.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls", &sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MyV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MyV.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_IacqprDQrsXG0ECINiZW7cXIA86bG", &sbt_IacqprDQrsXG0ECINiZW7cXIA86bG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sIs9lET68vvSiiQHksnvLh7k_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sIs9lET68vvSiiQHksnvLh7k_.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iKTZiClzI_RpsVHuO0X2J19", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iKTZiClzI_RpsVHuO0X2J19 = (CX::Int16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.begin(); iter != sbt_FvCQV3v2OqLuGHBZGqlEVzWOJ0b_TjLabOot5QPiWyr7nsxzZ5GnEzZuiU98I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV", (CX::Int64)sbt_r7Z2vXOSxlRz6wek9EPwZ7onZQFK6rFRQvNzFEdX2IxQ47LlyvUpyWV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.begin(); iter != sbt_0FtcOpm6K30QJXz02cQ9Wx0PmfDilGeRaZxbCotE1xbGXhzO88_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hR3Qu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_hR3Qu.begin(); iter != sbt_hR3Qu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.begin(); iter != sbt_LFBZvlZ1Ch_BjWiKPedIESFOwKSk4QODl0J_xOhjI7v31HX8fNH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NGyEJ_IO530KAad0dOe2E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_NGyEJ_IO530KAad0dOe2E.begin(); iter != sbt_NGyEJ_IO530KAad0dOe2E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls", sbt_T8DZDFJiwVpuqK8sqSXcePdo9F6U6Obflls)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MyV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_MyV.begin(); iter != sbt_MyV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA", (CX::Int64)sbt_GMLjVuGFh3SrHws60wkrUJfxFnQLqpsVA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge", (CX::Int64)sbt_47Zi5vz3iZcl8ck8PZ1swRfKmttaSwG1k67LXge)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.begin(); iter != sbt_oBEYOCFhpWzyaQHwTOsLiMPVjiJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT", (CX::Int64)sbt_ytdsu33NHmeLi2Q5dRVtJCQgKutmeCjSiY5aLl6734WGo_KzmsT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.begin(); iter != sbt_yADTMDxtc1W7hj_BBeUfZyUqL_EaKAygRHU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_IacqprDQrsXG0ECINiZW7cXIA86bG", sbt_IacqprDQrsXG0ECINiZW7cXIA86bG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sIs9lET68vvSiiQHksnvLh7k_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_sIs9lET68vvSiiQHksnvLh7k_.begin(); iter != sbt_sIs9lET68vvSiiQHksnvLh7k_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iKTZiClzI_RpsVHuO0X2J19", (CX::Int64)sbt_iKTZiClzI_RpsVHuO0X2J19)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz>::Type sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVzArray;

