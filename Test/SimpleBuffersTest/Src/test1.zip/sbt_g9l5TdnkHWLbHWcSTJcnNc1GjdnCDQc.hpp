
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P;
	CX::IO::SimpleBuffers::UInt64Array sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc;
	CX::IO::SimpleBuffers::Int32Array sbt_j3fj2;
	CX::UInt32 sbt_vDiywHDIiAf;
	CX::UInt8 sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ;
	CX::UInt8 sbt_Yj2whucOBW5cbsUsI2tBY;
	CX::IO::SimpleBuffers::StringArray sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI;
	CX::IO::SimpleBuffers::BoolArray sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX;
	CX::UInt8 sbt_webILjv1kLC;

	virtual void Reset()
	{
		sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.clear();
		sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.clear();
		sbt_j3fj2.clear();
		sbt_vDiywHDIiAf = 0;
		sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ = 0;
		sbt_Yj2whucOBW5cbsUsI2tBY = 0;
		sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.clear();
		sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.clear();
		sbt_webILjv1kLC = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.push_back(12876772957770588596);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.push_back(6468607561080098622);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_j3fj2.push_back(-1289808304);
		}
		sbt_vDiywHDIiAf = 4239840753;
		sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ = 128;
		sbt_Yj2whucOBW5cbsUsI2tBY = 90;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.push_back("7z8Xw^!4*ZH#d['lf'TX}");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.push_back(true);
		}
		sbt_webILjv1kLC = 86;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc *pObject = dynamic_cast<const sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.size() != pObject->sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.size(); i++)
		{
			if (sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P[i] != pObject->sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P[i])
			{
				return false;
			}
		}
		if (sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.size() != pObject->sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.size(); i++)
		{
			if (sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc[i] != pObject->sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc[i])
			{
				return false;
			}
		}
		if (sbt_j3fj2.size() != pObject->sbt_j3fj2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j3fj2.size(); i++)
		{
			if (sbt_j3fj2[i] != pObject->sbt_j3fj2[i])
			{
				return false;
			}
		}
		if (sbt_vDiywHDIiAf != pObject->sbt_vDiywHDIiAf)
		{
			return false;
		}
		if (sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ != pObject->sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ)
		{
			return false;
		}
		if (sbt_Yj2whucOBW5cbsUsI2tBY != pObject->sbt_Yj2whucOBW5cbsUsI2tBY)
		{
			return false;
		}
		if (sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.size() != pObject->sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI[i].c_str(), pObject->sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.size() != pObject->sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.size(); i++)
		{
			if (sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX[i] != pObject->sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX[i])
			{
				return false;
			}
		}
		if (sbt_webILjv1kLC != pObject->sbt_webILjv1kLC)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j3fj2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j3fj2.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vDiywHDIiAf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vDiywHDIiAf = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Yj2whucOBW5cbsUsI2tBY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Yj2whucOBW5cbsUsI2tBY = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_webILjv1kLC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_webILjv1kLC = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.begin(); iter != sbt_acj_EgfKH26Fwa8lUfOibPYqGp5xn_ivxisad2nzmuGxkIG7xjx2N0P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.begin(); iter != sbt_AYWunQXrtJsEgYY_Tk51J8IahVWrWzTiWaB06dvk00JhB9pH4Yc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j3fj2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_j3fj2.begin(); iter != sbt_j3fj2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vDiywHDIiAf", (CX::Int64)sbt_vDiywHDIiAf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ", (CX::Int64)sbt_JttegXmG2VZe_Y2PnSvKjicDcHxSNEEqvVlFvoQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Yj2whucOBW5cbsUsI2tBY", (CX::Int64)sbt_Yj2whucOBW5cbsUsI2tBY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.begin(); iter != sbt_bRHS8YZfURpb3qVLVlCdXxOafaSbZEI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.begin(); iter != sbt_rVHphORD_UYGtSalsV5MRkng1BCAsT4qbqgu5zmAF2XfSqOxtC5Qf9caEzkzbNX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_webILjv1kLC", (CX::Int64)sbt_webILjv1kLC)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc>::Type sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQcArray;

