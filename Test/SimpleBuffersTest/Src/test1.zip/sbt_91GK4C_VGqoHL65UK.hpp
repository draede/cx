
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV.hpp"


class sbt_91GK4C_VGqoHL65UK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b;
	CX::IO::SimpleBuffers::UInt64Array sbt_e4XcbtwJF;
	CX::IO::SimpleBuffers::Int64Array sbt_rYtFvRxmP403D;
	CX::Int32 sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4;
	CX::Int64 sbt_vzK;
	CX::IO::SimpleBuffers::Int8Array sbt_MTVZZcbuIIxIf;
	CX::IO::SimpleBuffers::Int64Array sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot;
	CX::Bool sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742;
	CX::Double sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR;
	CX::IO::SimpleBuffers::StringArray sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm;
	CX::WString sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS;
	CX::IO::SimpleBuffers::UInt64Array sbt_x29E3FepgLeACjZiO;
	CX::Float sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw;
	CX::IO::SimpleBuffers::Int8Array sbt_1;
	CX::IO::SimpleBuffers::UInt64Array sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg;
	CX::Int16 sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv;
	CX::WString sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ;
	sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4;

	virtual void Reset()
	{
		sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.clear();
		sbt_e4XcbtwJF.clear();
		sbt_rYtFvRxmP403D.clear();
		sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4 = 0;
		sbt_vzK = 0;
		sbt_MTVZZcbuIIxIf.clear();
		sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.clear();
		sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742 = false;
		sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR = 0.0;
		sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.clear();
		sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS.clear();
		sbt_x29E3FepgLeACjZiO.clear();
		sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw = 0.0f;
		sbt_1.clear();
		sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.clear();
		sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv = 0;
		sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ.clear();
		sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.push_back(0.645675f);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_e4XcbtwJF.push_back(15800787589201986752);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_rYtFvRxmP403D.push_back(4217999796687188664);
		}
		sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4 = 492970152;
		sbt_vzK = 3025287588326492006;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_MTVZZcbuIIxIf.push_back(-89);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.push_back(8640200319788578944);
		}
		sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742 = false;
		sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR = 0.006847;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.push_back("74:-Z6T5:z29?|LQtkoki$}uvO<Z77s4<k\\N+6P=fhDLS|D3=2Kbi;");
		}
		sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS = L"NuYG\\QDH5N'i'I(GQoTNis7z9~1otNy";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_x29E3FepgLeACjZiO.push_back(13191049567296811956);
		}
		sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw = 0.789292f;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_1.push_back(49);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.push_back(3330123508193247730);
		}
		sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv = 4452;
		sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ = L"Q}^/{S6>St__YG%Z}1t";
		sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_91GK4C_VGqoHL65UK *pObject = dynamic_cast<const sbt_91GK4C_VGqoHL65UK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.size() != pObject->sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.size(); i++)
		{
			if (sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b[i] != pObject->sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b[i])
			{
				return false;
			}
		}
		if (sbt_e4XcbtwJF.size() != pObject->sbt_e4XcbtwJF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_e4XcbtwJF.size(); i++)
		{
			if (sbt_e4XcbtwJF[i] != pObject->sbt_e4XcbtwJF[i])
			{
				return false;
			}
		}
		if (sbt_rYtFvRxmP403D.size() != pObject->sbt_rYtFvRxmP403D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rYtFvRxmP403D.size(); i++)
		{
			if (sbt_rYtFvRxmP403D[i] != pObject->sbt_rYtFvRxmP403D[i])
			{
				return false;
			}
		}
		if (sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4 != pObject->sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4)
		{
			return false;
		}
		if (sbt_vzK != pObject->sbt_vzK)
		{
			return false;
		}
		if (sbt_MTVZZcbuIIxIf.size() != pObject->sbt_MTVZZcbuIIxIf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MTVZZcbuIIxIf.size(); i++)
		{
			if (sbt_MTVZZcbuIIxIf[i] != pObject->sbt_MTVZZcbuIIxIf[i])
			{
				return false;
			}
		}
		if (sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.size() != pObject->sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.size(); i++)
		{
			if (sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot[i] != pObject->sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot[i])
			{
				return false;
			}
		}
		if (sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742 != pObject->sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742)
		{
			return false;
		}
		if (sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR != pObject->sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR)
		{
			return false;
		}
		if (sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.size() != pObject->sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm[i].c_str(), pObject->sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS.c_str(), pObject->sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS.c_str()))
		{
			return false;
		}
		if (sbt_x29E3FepgLeACjZiO.size() != pObject->sbt_x29E3FepgLeACjZiO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x29E3FepgLeACjZiO.size(); i++)
		{
			if (sbt_x29E3FepgLeACjZiO[i] != pObject->sbt_x29E3FepgLeACjZiO[i])
			{
				return false;
			}
		}
		if (sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw != pObject->sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw)
		{
			return false;
		}
		if (sbt_1.size() != pObject->sbt_1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1.size(); i++)
		{
			if (sbt_1[i] != pObject->sbt_1[i])
			{
				return false;
			}
		}
		if (sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.size() != pObject->sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.size(); i++)
		{
			if (sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg[i] != pObject->sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg[i])
			{
				return false;
			}
		}
		if (sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv != pObject->sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ.c_str(), pObject->sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ.c_str()))
		{
			return false;
		}
		if (!sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4.Compare(&pObject->sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_e4XcbtwJF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_e4XcbtwJF.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rYtFvRxmP403D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rYtFvRxmP403D.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_vzK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vzK = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MTVZZcbuIIxIf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MTVZZcbuIIxIf.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742", &sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS", &sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_x29E3FepgLeACjZiO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x29E3FepgLeACjZiO.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ", &sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.begin(); iter != sbt_oviut6nlGJmUEzWB89KsBzVmOYXKTyas3gMCkYesrPYWwQGGvz25b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_e4XcbtwJF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_e4XcbtwJF.begin(); iter != sbt_e4XcbtwJF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rYtFvRxmP403D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_rYtFvRxmP403D.begin(); iter != sbt_rYtFvRxmP403D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4", (CX::Int64)sbt_lIUcwQBrfiNlLy1qbrPFZME1TYxJvntmICSwlO4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vzK", (CX::Int64)sbt_vzK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MTVZZcbuIIxIf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_MTVZZcbuIIxIf.begin(); iter != sbt_MTVZZcbuIIxIf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.begin(); iter != sbt_dbxNbe314x3cFauqNZA1AimDN8KEwY6E4UPCs5pMqRUE2xtHnot.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742", sbt_DRzf00LDvRzIRlQJ3Sa53jcm36_ZWWNJiweS2NspyJwpXfwcmbxiykVAF_742)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR", (CX::Double)sbt_EHyMGwm3Ugh12akDgb95ir35PuEE11pj83JAtkhJrCVEK0XgR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.begin(); iter != sbt_ZUPbRQu7GhW6kXuiLVrL3VaJgOABHFlV9ZQ68ilWSJpaeW595Lm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS", sbt_qWe0XGwpFyUkAhw2vxErJvBzexqrAhgNtZ4pdvAQHHJuyNLM9XS.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_x29E3FepgLeACjZiO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_x29E3FepgLeACjZiO.begin(); iter != sbt_x29E3FepgLeACjZiO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw", (CX::Double)sbt_k1BudNxWlnPT7b9I0x83xTBBpU1JNqEiQX3kw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_1.begin(); iter != sbt_1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.begin(); iter != sbt_CWGGmyo2bFkWxWcZVZ8_4EGsmc9tLs26en0yfn8g2D3unNg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv", (CX::Int64)sbt_GUdjiCG6SPsJCOEWq_F5jMty43mgG_f5uvKjECvpcoj9wfjH9rH_73BZv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ", sbt_DCjFyetArFVSYLah2G4aZN6F0uQ7HaJ3C3ISxGmCbQGXIvEzBGQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_T2kHu_ahAu3hmbrZ3hdT4BDYsPro8VTT4.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_91GK4C_VGqoHL65UK>::Type sbt_91GK4C_VGqoHL65UKArray;

