
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX.hpp"


class sbt_0uCXiph9R2MT1pEZxqZlDVP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG;
	CX::UInt16 sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6;
	CX::Int8 sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz;
	CX::Int16 sbt_u2zQLHrWdON3T;
	CX::WString sbt_y3myU;
	CX::IO::SimpleBuffers::BoolArray sbt_oxpIStNsnwEtL;
	CX::IO::SimpleBuffers::DoubleArray sbt_cWLGtc7CeOA;
	CX::IO::SimpleBuffers::BoolArray sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg;
	CX::IO::SimpleBuffers::Int64Array sbt_DclAZZlBJpQgP2Z4L4Z3Byc;
	CX::IO::SimpleBuffers::UInt64Array sbt_jbBylW5eb;
	CX::Float sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr;
	CX::UInt32 sbt_UhNVa;
	CX::Bool sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ;
	CX::IO::SimpleBuffers::UInt8Array sbt_OpHGUraoUd3bYm3;
	CX::IO::SimpleBuffers::DoubleArray sbt_TawjX2ZZDDEUapd;
	CX::Float sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89;
	CX::IO::SimpleBuffers::Int16Array sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C;
	CX::UInt16 sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV;
	CX::Bool sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8;
	CX::UInt8 sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_;
	CX::Bool sbt_tzsCt3aiIold2rWOGtfSg;
	CX::IO::SimpleBuffers::FloatArray sbt_6flQK;
	CX::WString sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP;
	CX::IO::SimpleBuffers::FloatArray sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW;
	CX::IO::SimpleBuffers::UInt64Array sbt_I6QQffBcdNitd;
	CX::IO::SimpleBuffers::UInt64Array sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS;
	CX::IO::SimpleBuffers::DoubleArray sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h;
	CX::UInt16 sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup;
	CX::IO::SimpleBuffers::Int32Array sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt;
	sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr;

	virtual void Reset()
	{
		sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG.clear();
		sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6 = 0;
		sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz = 0;
		sbt_u2zQLHrWdON3T = 0;
		sbt_y3myU.clear();
		sbt_oxpIStNsnwEtL.clear();
		sbt_cWLGtc7CeOA.clear();
		sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.clear();
		sbt_DclAZZlBJpQgP2Z4L4Z3Byc.clear();
		sbt_jbBylW5eb.clear();
		sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr = 0.0f;
		sbt_UhNVa = 0;
		sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ = false;
		sbt_OpHGUraoUd3bYm3.clear();
		sbt_TawjX2ZZDDEUapd.clear();
		sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89 = 0.0f;
		sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.clear();
		sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV = 0;
		sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8 = false;
		sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_ = 0;
		sbt_tzsCt3aiIold2rWOGtfSg = false;
		sbt_6flQK.clear();
		sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP.clear();
		sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.clear();
		sbt_I6QQffBcdNitd.clear();
		sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.clear();
		sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.clear();
		sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup = 0;
		sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.clear();
		sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG = "sFJX^%$gFpv#[u\"6;H0h>.J`[1jQ\"Jl.c{B\"nY\"8j";
		sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6 = 59059;
		sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz = -68;
		sbt_u2zQLHrWdON3T = -8931;
		sbt_y3myU = L"\"IgL.L$rF.IHv>zBlU0;Tyi&%~}Gqg)ycx%kjkJwF^l(&1S~+du<DAuD;F>d";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_oxpIStNsnwEtL.push_back(true);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_cWLGtc7CeOA.push_back(0.543122);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.push_back(true);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_DclAZZlBJpQgP2Z4L4Z3Byc.push_back(5536563839837972948);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_jbBylW5eb.push_back(16744407225942450214);
		}
		sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr = 0.804369f;
		sbt_UhNVa = 1079809732;
		sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_OpHGUraoUd3bYm3.push_back(158);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_TawjX2ZZDDEUapd.push_back(0.173547);
		}
		sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89 = 0.155465f;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.push_back(25237);
		}
		sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV = 24811;
		sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8 = true;
		sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_ = 176;
		sbt_tzsCt3aiIold2rWOGtfSg = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_6flQK.push_back(0.472034f);
		}
		sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP = L"Tu@0s81=$>L5}lJ{%1=Eh\"Q3><~KV9>6Qq>t(tsXr~\\\"[I/@apu^CT";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.push_back(0.618724f);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_I6QQffBcdNitd.push_back(15538957470723094376);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.push_back(18343926521697004320);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.push_back(0.173696);
		}
		sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup = 34474;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.push_back(122245808);
		}
		sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_0uCXiph9R2MT1pEZxqZlDVP *pObject = dynamic_cast<const sbt_0uCXiph9R2MT1pEZxqZlDVP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG.c_str(), pObject->sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG.c_str()))
		{
			return false;
		}
		if (sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6 != pObject->sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6)
		{
			return false;
		}
		if (sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz != pObject->sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz)
		{
			return false;
		}
		if (sbt_u2zQLHrWdON3T != pObject->sbt_u2zQLHrWdON3T)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_y3myU.c_str(), pObject->sbt_y3myU.c_str()))
		{
			return false;
		}
		if (sbt_oxpIStNsnwEtL.size() != pObject->sbt_oxpIStNsnwEtL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oxpIStNsnwEtL.size(); i++)
		{
			if (sbt_oxpIStNsnwEtL[i] != pObject->sbt_oxpIStNsnwEtL[i])
			{
				return false;
			}
		}
		if (sbt_cWLGtc7CeOA.size() != pObject->sbt_cWLGtc7CeOA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cWLGtc7CeOA.size(); i++)
		{
			if (sbt_cWLGtc7CeOA[i] != pObject->sbt_cWLGtc7CeOA[i])
			{
				return false;
			}
		}
		if (sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.size() != pObject->sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.size(); i++)
		{
			if (sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg[i] != pObject->sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg[i])
			{
				return false;
			}
		}
		if (sbt_DclAZZlBJpQgP2Z4L4Z3Byc.size() != pObject->sbt_DclAZZlBJpQgP2Z4L4Z3Byc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DclAZZlBJpQgP2Z4L4Z3Byc.size(); i++)
		{
			if (sbt_DclAZZlBJpQgP2Z4L4Z3Byc[i] != pObject->sbt_DclAZZlBJpQgP2Z4L4Z3Byc[i])
			{
				return false;
			}
		}
		if (sbt_jbBylW5eb.size() != pObject->sbt_jbBylW5eb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jbBylW5eb.size(); i++)
		{
			if (sbt_jbBylW5eb[i] != pObject->sbt_jbBylW5eb[i])
			{
				return false;
			}
		}
		if (sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr != pObject->sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr)
		{
			return false;
		}
		if (sbt_UhNVa != pObject->sbt_UhNVa)
		{
			return false;
		}
		if (sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ != pObject->sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ)
		{
			return false;
		}
		if (sbt_OpHGUraoUd3bYm3.size() != pObject->sbt_OpHGUraoUd3bYm3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OpHGUraoUd3bYm3.size(); i++)
		{
			if (sbt_OpHGUraoUd3bYm3[i] != pObject->sbt_OpHGUraoUd3bYm3[i])
			{
				return false;
			}
		}
		if (sbt_TawjX2ZZDDEUapd.size() != pObject->sbt_TawjX2ZZDDEUapd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TawjX2ZZDDEUapd.size(); i++)
		{
			if (sbt_TawjX2ZZDDEUapd[i] != pObject->sbt_TawjX2ZZDDEUapd[i])
			{
				return false;
			}
		}
		if (sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89 != pObject->sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89)
		{
			return false;
		}
		if (sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.size() != pObject->sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.size(); i++)
		{
			if (sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C[i] != pObject->sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C[i])
			{
				return false;
			}
		}
		if (sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV != pObject->sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV)
		{
			return false;
		}
		if (sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8 != pObject->sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8)
		{
			return false;
		}
		if (sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_ != pObject->sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_)
		{
			return false;
		}
		if (sbt_tzsCt3aiIold2rWOGtfSg != pObject->sbt_tzsCt3aiIold2rWOGtfSg)
		{
			return false;
		}
		if (sbt_6flQK.size() != pObject->sbt_6flQK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6flQK.size(); i++)
		{
			if (sbt_6flQK[i] != pObject->sbt_6flQK[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP.c_str(), pObject->sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP.c_str()))
		{
			return false;
		}
		if (sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.size() != pObject->sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.size(); i++)
		{
			if (sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW[i] != pObject->sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW[i])
			{
				return false;
			}
		}
		if (sbt_I6QQffBcdNitd.size() != pObject->sbt_I6QQffBcdNitd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I6QQffBcdNitd.size(); i++)
		{
			if (sbt_I6QQffBcdNitd[i] != pObject->sbt_I6QQffBcdNitd[i])
			{
				return false;
			}
		}
		if (sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.size() != pObject->sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.size(); i++)
		{
			if (sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS[i] != pObject->sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS[i])
			{
				return false;
			}
		}
		if (sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.size() != pObject->sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.size(); i++)
		{
			if (sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h[i] != pObject->sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h[i])
			{
				return false;
			}
		}
		if (sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup != pObject->sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup)
		{
			return false;
		}
		if (sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.size() != pObject->sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.size(); i++)
		{
			if (sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt[i] != pObject->sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt[i])
			{
				return false;
			}
		}
		if (!sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr.Compare(&pObject->sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG", &sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_u2zQLHrWdON3T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u2zQLHrWdON3T = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_y3myU", &sbt_y3myU)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oxpIStNsnwEtL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oxpIStNsnwEtL.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cWLGtc7CeOA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cWLGtc7CeOA.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DclAZZlBJpQgP2Z4L4Z3Byc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DclAZZlBJpQgP2Z4L4Z3Byc.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jbBylW5eb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jbBylW5eb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_UhNVa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UhNVa = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ", &sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OpHGUraoUd3bYm3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OpHGUraoUd3bYm3.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TawjX2ZZDDEUapd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TawjX2ZZDDEUapd.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8", &sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_tzsCt3aiIold2rWOGtfSg", &sbt_tzsCt3aiIold2rWOGtfSg)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6flQK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6flQK.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP", &sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I6QQffBcdNitd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I6QQffBcdNitd.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG", sbt_LgcpPKe9uCuPoFU6c0VcjZJW5kG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6", (CX::Int64)sbt_7mYXOx56TuoGV2emlAHs2Hspm60Bn3lSHjR_sNQG6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz", (CX::Int64)sbt_SGtwfpjYs1LqDkBrnwBxvYXdFs61C_kkjmdhbPz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u2zQLHrWdON3T", (CX::Int64)sbt_u2zQLHrWdON3T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_y3myU", sbt_y3myU.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oxpIStNsnwEtL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_oxpIStNsnwEtL.begin(); iter != sbt_oxpIStNsnwEtL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cWLGtc7CeOA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_cWLGtc7CeOA.begin(); iter != sbt_cWLGtc7CeOA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.begin(); iter != sbt_Lfh2DCb9N1SYOiFqL1VX4enwLG69nSFZYqVD3yUyeUdXL6Bbg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DclAZZlBJpQgP2Z4L4Z3Byc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_DclAZZlBJpQgP2Z4L4Z3Byc.begin(); iter != sbt_DclAZZlBJpQgP2Z4L4Z3Byc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jbBylW5eb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_jbBylW5eb.begin(); iter != sbt_jbBylW5eb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr", (CX::Double)sbt_mVNxPEfN3iBMM7HkA00BpHQ30G8__6GlgphyjGo6EB0V9gjRt88JgjFFr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UhNVa", (CX::Int64)sbt_UhNVa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ", sbt_6gRKUXOTg2HxTtl9vgF1g4aHtvsbcTcnTF5yw6dHZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OpHGUraoUd3bYm3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_OpHGUraoUd3bYm3.begin(); iter != sbt_OpHGUraoUd3bYm3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TawjX2ZZDDEUapd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_TawjX2ZZDDEUapd.begin(); iter != sbt_TawjX2ZZDDEUapd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89", (CX::Double)sbt__b569jVhfxV8GEYHukKJfWtY6hVlR0r89)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.begin(); iter != sbt_xeAPe7PXekUtJ0JuoafdUNHsVEoV37C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV", (CX::Int64)sbt_6Er2ciIhJYi2Inrx2hik3pacD3A22cV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8", sbt_JdIwKmR5jpvqDUN2htLqd3iC0j11Lq8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_", (CX::Int64)sbt_k1ckh7KRkpsKquwRZLkG2ORv3pG_Zh5v_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_tzsCt3aiIold2rWOGtfSg", sbt_tzsCt3aiIold2rWOGtfSg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6flQK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_6flQK.begin(); iter != sbt_6flQK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP", sbt_lUafiC29Mp94niy42QfqOvPPMKvhdP_5uzPqrf5kwZoYRFtrv0mRpkP.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.begin(); iter != sbt_vGoKlF7OTInVMdMfHhxoxDVntpsudoGyIPXrpzzoHDOjAgqAmBBqWOW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I6QQffBcdNitd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_I6QQffBcdNitd.begin(); iter != sbt_I6QQffBcdNitd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.begin(); iter != sbt_qXUnfWQNBgfbPHRWoOyiMkOY7uIO91wzWCgLnfvVhUT6QzrAB8d1d4SO4xdmS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.begin(); iter != sbt_hdLIWGNAiEB0OOZkAdsA1TBCP_OTnAV0DW9ggkIf5tUMUwVo33u43DWWW1Kos1h.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup", (CX::Int64)sbt_YZHz3NJBUIi_TZrWKZA5GdQmnBm4V6GupN0_1ccJAjfup)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.begin(); iter != sbt_U3clBLtJ08Qrt4L7dfjUu4LH6SGo5k8F5PFYdXolDW5Wt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_czf6fN1e4uiNor8Iij32thhtvZr4FMb405lLY0MTRZ1yr.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_0uCXiph9R2MT1pEZxqZlDVP>::Type sbt_0uCXiph9R2MT1pEZxqZlDVPArray;

