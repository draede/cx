
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc.hpp"


class sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_fCPJGip;
	CX::String sbt_XcPK3hbxxcZhXXL4FSNIo;
	CX::IO::SimpleBuffers::StringArray sbt_pJPFET4EgsShaWO13nTl31iHALU;
	CX::Int64 sbt_sb3wqt77Dq2;
	CX::IO::SimpleBuffers::UInt8Array sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y;
	CX::WString sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ;
	CX::Double sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa;
	CX::IO::SimpleBuffers::DoubleArray sbt_Fxmn3C5qImGw0lpxm_FaHW77I;
	CX::IO::SimpleBuffers::UInt32Array sbt_iWz6ZegXSYojoqMoAPy;
	CX::Int8 sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY;
	CX::WString sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg;
	CX::IO::SimpleBuffers::Int16Array sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb;
	CX::IO::SimpleBuffers::Int64Array sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN;
	CX::Float sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm;
	CX::UInt64 sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc;
	CX::IO::SimpleBuffers::Int32Array sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV;
	sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc sbt_f7uzaE293;

	virtual void Reset()
	{
		sbt_fCPJGip.clear();
		sbt_XcPK3hbxxcZhXXL4FSNIo.clear();
		sbt_pJPFET4EgsShaWO13nTl31iHALU.clear();
		sbt_sb3wqt77Dq2 = 0;
		sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.clear();
		sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ.clear();
		sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa = 0.0;
		sbt_Fxmn3C5qImGw0lpxm_FaHW77I.clear();
		sbt_iWz6ZegXSYojoqMoAPy.clear();
		sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY = 0;
		sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg.clear();
		sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.clear();
		sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.clear();
		sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm = 0.0f;
		sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc = 0;
		sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.clear();
		sbt_f7uzaE293.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_fCPJGip.push_back(-65);
		}
		sbt_XcPK3hbxxcZhXXL4FSNIo = "p`n4Iwcznh8.7a^AXBOn8i^ZBA!";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_pJPFET4EgsShaWO13nTl31iHALU.push_back("}kC-4_c700%:o7lex'x:xxt\\Dg.9obJm)Tn(idU_z5[8CBSWo%5UTl");
		}
		sbt_sb3wqt77Dq2 = 4267248871257476976;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.push_back(24);
		}
		sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ = L"S";
		sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa = 0.804012;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Fxmn3C5qImGw0lpxm_FaHW77I.push_back(0.310158);
		}
		sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY = 36;
		sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg = L",k]x#9%#%M4xa/Ij-jG+";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.push_back(-18499);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.push_back(-7570594519795030034);
		}
		sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm = 0.071520f;
		sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc = 13544237408603814934;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.push_back(1869120270);
		}
		sbt_f7uzaE293.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL *pObject = dynamic_cast<const sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_fCPJGip.size() != pObject->sbt_fCPJGip.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fCPJGip.size(); i++)
		{
			if (sbt_fCPJGip[i] != pObject->sbt_fCPJGip[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_XcPK3hbxxcZhXXL4FSNIo.c_str(), pObject->sbt_XcPK3hbxxcZhXXL4FSNIo.c_str()))
		{
			return false;
		}
		if (sbt_pJPFET4EgsShaWO13nTl31iHALU.size() != pObject->sbt_pJPFET4EgsShaWO13nTl31iHALU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pJPFET4EgsShaWO13nTl31iHALU.size(); i++)
		{
			if (0 != cx_strcmp(sbt_pJPFET4EgsShaWO13nTl31iHALU[i].c_str(), pObject->sbt_pJPFET4EgsShaWO13nTl31iHALU[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_sb3wqt77Dq2 != pObject->sbt_sb3wqt77Dq2)
		{
			return false;
		}
		if (sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.size() != pObject->sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.size(); i++)
		{
			if (sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y[i] != pObject->sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ.c_str(), pObject->sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ.c_str()))
		{
			return false;
		}
		if (sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa != pObject->sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa)
		{
			return false;
		}
		if (sbt_Fxmn3C5qImGw0lpxm_FaHW77I.size() != pObject->sbt_Fxmn3C5qImGw0lpxm_FaHW77I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fxmn3C5qImGw0lpxm_FaHW77I.size(); i++)
		{
			if (sbt_Fxmn3C5qImGw0lpxm_FaHW77I[i] != pObject->sbt_Fxmn3C5qImGw0lpxm_FaHW77I[i])
			{
				return false;
			}
		}
		if (sbt_iWz6ZegXSYojoqMoAPy.size() != pObject->sbt_iWz6ZegXSYojoqMoAPy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iWz6ZegXSYojoqMoAPy.size(); i++)
		{
			if (sbt_iWz6ZegXSYojoqMoAPy[i] != pObject->sbt_iWz6ZegXSYojoqMoAPy[i])
			{
				return false;
			}
		}
		if (sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY != pObject->sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg.c_str(), pObject->sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg.c_str()))
		{
			return false;
		}
		if (sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.size() != pObject->sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.size(); i++)
		{
			if (sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb[i] != pObject->sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb[i])
			{
				return false;
			}
		}
		if (sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.size() != pObject->sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.size(); i++)
		{
			if (sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN[i] != pObject->sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN[i])
			{
				return false;
			}
		}
		if (sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm != pObject->sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm)
		{
			return false;
		}
		if (sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc != pObject->sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc)
		{
			return false;
		}
		if (sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.size() != pObject->sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.size(); i++)
		{
			if (sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV[i] != pObject->sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV[i])
			{
				return false;
			}
		}
		if (!sbt_f7uzaE293.Compare(&pObject->sbt_f7uzaE293))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_fCPJGip")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fCPJGip.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_XcPK3hbxxcZhXXL4FSNIo", &sbt_XcPK3hbxxcZhXXL4FSNIo)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pJPFET4EgsShaWO13nTl31iHALU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pJPFET4EgsShaWO13nTl31iHALU.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sb3wqt77Dq2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sb3wqt77Dq2 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ", &sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Fxmn3C5qImGw0lpxm_FaHW77I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fxmn3C5qImGw0lpxm_FaHW77I.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_iWz6ZegXSYojoqMoAPy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iWz6ZegXSYojoqMoAPy.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg", &sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_f7uzaE293")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_f7uzaE293.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_fCPJGip")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_fCPJGip.begin(); iter != sbt_fCPJGip.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_XcPK3hbxxcZhXXL4FSNIo", sbt_XcPK3hbxxcZhXXL4FSNIo.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pJPFET4EgsShaWO13nTl31iHALU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_pJPFET4EgsShaWO13nTl31iHALU.begin(); iter != sbt_pJPFET4EgsShaWO13nTl31iHALU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sb3wqt77Dq2", (CX::Int64)sbt_sb3wqt77Dq2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.begin(); iter != sbt_axhtL3nvVABqdpWYdzRmYVbNQkkOK1AXkpaadwiQqrLQbQ35KMolM4fX_sUce0y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ", sbt_0CyOse2NcfHTIjTmKJFgBfVReiQSRD6l8cieuQm_uRX3cJQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa", (CX::Double)sbt_dJQnWtL45d4aaOypbwXLzYVFK9gFa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fxmn3C5qImGw0lpxm_FaHW77I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Fxmn3C5qImGw0lpxm_FaHW77I.begin(); iter != sbt_Fxmn3C5qImGw0lpxm_FaHW77I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iWz6ZegXSYojoqMoAPy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_iWz6ZegXSYojoqMoAPy.begin(); iter != sbt_iWz6ZegXSYojoqMoAPy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY", (CX::Int64)sbt_zx7faS6Usi_IbenMFxnPhbCvDhkWWU31sPRUokLPJAY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg", sbt_GSxalAPD3S9yytoGvqAmwYeXXY_zzRN45kKx42Uf9eD7LDg.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.begin(); iter != sbt_EIU4Riwe0MgM0X32gIEp05dAtkTq9jNsgBWHVc43Y33fxgyH268bHEWOwXrhFmb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.begin(); iter != sbt_0ajEhtRqDyuMo6k66s0OXWgLSt_sDlq0ZL618sz2eGQZe26kOv2OhQ7VOAAYzSN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm", (CX::Double)sbt_nbIikAIXnKqzJB11jpvjzhrxcJBXsckwZS7qibBo0GjE0VpKT57nhjwCm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc", (CX::Int64)sbt_sWSGe7Vq8ITGTXsK7fnENbRlbfndTAZ2iTocChc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.begin(); iter != sbt_FK6klNrhKRSAWucY8Ky8aR2kagHqiHbhBjXFLwNfwJ_oaDTV2Frujujc5cV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_f7uzaE293")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_f7uzaE293.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL>::Type sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fLArray;

