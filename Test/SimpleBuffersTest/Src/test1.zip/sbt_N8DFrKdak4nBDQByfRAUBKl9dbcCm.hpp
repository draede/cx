
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_9xBJUIh5AsyBf;
	CX::IO::SimpleBuffers::UInt8Array sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH;
	CX::IO::SimpleBuffers::UInt16Array sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0;
	CX::IO::SimpleBuffers::UInt32Array sbt_X0pB0KJwF2jB09F2nZl;
	CX::String sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5;
	CX::UInt64 sbt_n1oNbp8RR71;
	CX::IO::SimpleBuffers::UInt32Array sbt_M69KegdHwy5PqaO;
	CX::IO::SimpleBuffers::UInt32Array sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy;
	CX::Int16 sbt_uLmM3xZSwSYfz2pDQxioF9scndk;
	CX::IO::SimpleBuffers::BoolArray sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye;
	CX::String sbt_ItY89eiNkZTuo8LjA9dgEWn;
	CX::Int64 sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz;

	virtual void Reset()
	{
		sbt_9xBJUIh5AsyBf.clear();
		sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.clear();
		sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.clear();
		sbt_X0pB0KJwF2jB09F2nZl.clear();
		sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5.clear();
		sbt_n1oNbp8RR71 = 0;
		sbt_M69KegdHwy5PqaO.clear();
		sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.clear();
		sbt_uLmM3xZSwSYfz2pDQxioF9scndk = 0;
		sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.clear();
		sbt_ItY89eiNkZTuo8LjA9dgEWn.clear();
		sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_9xBJUIh5AsyBf.push_back(false);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.push_back(39);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.push_back(52419);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_X0pB0KJwF2jB09F2nZl.push_back(1657755529);
		}
		sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5 = "<-1/Q'[kTk7r|AP'ib4\\)\\Ae}`}y8&`v!jhkP4oh1'8?";
		sbt_n1oNbp8RR71 = 15263329363028882664;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_M69KegdHwy5PqaO.push_back(1361532988);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.push_back(2761738528);
		}
		sbt_uLmM3xZSwSYfz2pDQxioF9scndk = -11745;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.push_back(true);
		}
		sbt_ItY89eiNkZTuo8LjA9dgEWn = "FU(\"01]k{(}Ay-+fL#<\\m7C^i?\\{?I'|%_}kTqDKo6=r$b8x{od-zzF5CJ4q@N%t";
		sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz = -145570925342802480;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm *pObject = dynamic_cast<const sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9xBJUIh5AsyBf.size() != pObject->sbt_9xBJUIh5AsyBf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9xBJUIh5AsyBf.size(); i++)
		{
			if (sbt_9xBJUIh5AsyBf[i] != pObject->sbt_9xBJUIh5AsyBf[i])
			{
				return false;
			}
		}
		if (sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.size() != pObject->sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.size(); i++)
		{
			if (sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH[i] != pObject->sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH[i])
			{
				return false;
			}
		}
		if (sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.size() != pObject->sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.size(); i++)
		{
			if (sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0[i] != pObject->sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0[i])
			{
				return false;
			}
		}
		if (sbt_X0pB0KJwF2jB09F2nZl.size() != pObject->sbt_X0pB0KJwF2jB09F2nZl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X0pB0KJwF2jB09F2nZl.size(); i++)
		{
			if (sbt_X0pB0KJwF2jB09F2nZl[i] != pObject->sbt_X0pB0KJwF2jB09F2nZl[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5.c_str(), pObject->sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5.c_str()))
		{
			return false;
		}
		if (sbt_n1oNbp8RR71 != pObject->sbt_n1oNbp8RR71)
		{
			return false;
		}
		if (sbt_M69KegdHwy5PqaO.size() != pObject->sbt_M69KegdHwy5PqaO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M69KegdHwy5PqaO.size(); i++)
		{
			if (sbt_M69KegdHwy5PqaO[i] != pObject->sbt_M69KegdHwy5PqaO[i])
			{
				return false;
			}
		}
		if (sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.size() != pObject->sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.size(); i++)
		{
			if (sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy[i] != pObject->sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy[i])
			{
				return false;
			}
		}
		if (sbt_uLmM3xZSwSYfz2pDQxioF9scndk != pObject->sbt_uLmM3xZSwSYfz2pDQxioF9scndk)
		{
			return false;
		}
		if (sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.size() != pObject->sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.size(); i++)
		{
			if (sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye[i] != pObject->sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_ItY89eiNkZTuo8LjA9dgEWn.c_str(), pObject->sbt_ItY89eiNkZTuo8LjA9dgEWn.c_str()))
		{
			return false;
		}
		if (sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz != pObject->sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_9xBJUIh5AsyBf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9xBJUIh5AsyBf.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X0pB0KJwF2jB09F2nZl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X0pB0KJwF2jB09F2nZl.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5", &sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n1oNbp8RR71", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n1oNbp8RR71 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_M69KegdHwy5PqaO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M69KegdHwy5PqaO.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_uLmM3xZSwSYfz2pDQxioF9scndk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uLmM3xZSwSYfz2pDQxioF9scndk = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_ItY89eiNkZTuo8LjA9dgEWn", &sbt_ItY89eiNkZTuo8LjA9dgEWn)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz = (CX::Int64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_9xBJUIh5AsyBf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_9xBJUIh5AsyBf.begin(); iter != sbt_9xBJUIh5AsyBf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.begin(); iter != sbt_Eq3Celht6DaLEdKpsAD9hRTANMmo_T6YRUkwDTI_SMmkH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.begin(); iter != sbt_WwSXqcjgFVXNEfcSbWb1nHnao1GM0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X0pB0KJwF2jB09F2nZl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_X0pB0KJwF2jB09F2nZl.begin(); iter != sbt_X0pB0KJwF2jB09F2nZl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5", sbt_fi_C0ApBRCtixEgeDygycBBObAAR1l0YZGJ6NXKnMe5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n1oNbp8RR71", (CX::Int64)sbt_n1oNbp8RR71)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M69KegdHwy5PqaO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_M69KegdHwy5PqaO.begin(); iter != sbt_M69KegdHwy5PqaO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.begin(); iter != sbt_OrRHhl4JrlWB43p9EhMePlh7KECxj1wqyTXgi3_Z1MxARpi287Isy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uLmM3xZSwSYfz2pDQxioF9scndk", (CX::Int64)sbt_uLmM3xZSwSYfz2pDQxioF9scndk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.begin(); iter != sbt_iNL39xhIeS4PtqpjsxOXsJ188Fe8sSIOOgGah9g_Sb72lZn_Tye.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ItY89eiNkZTuo8LjA9dgEWn", sbt_ItY89eiNkZTuo8LjA9dgEWn.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz", (CX::Int64)sbt_mDrRagkSrIwZLfZ_Bqr3tiIMFtnBXQXL4qNLMWxMlaXQWMURTUV4Xaz)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm>::Type sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCmArray;

