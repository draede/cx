
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_E.hpp"


class sbt_QEU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp;
	CX::IO::SimpleBuffers::WStringArray sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT;
	CX::IO::SimpleBuffers::Int16Array sbt_n1fv0dYAvRAe7Ha;
	CX::UInt32 sbt_HbA;
	CX::UInt16 sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn;
	CX::Double sbt_twCy6ixwxTyBVCFVdp46r5Xny;
	CX::IO::SimpleBuffers::BoolArray sbt_32UT6kj89TKTJFAUExiIxyApZ;
	CX::IO::SimpleBuffers::Int16Array sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH;
	CX::WString sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk;
	CX::IO::SimpleBuffers::UInt8Array sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb;
	CX::IO::SimpleBuffers::UInt32Array sbt_QlOKrKiV5Fe;
	CX::Int8 sbt_77J0tYc584DLuLtbv_4T7mwf7;
	CX::IO::SimpleBuffers::UInt16Array sbt_k;
	CX::Bool sbt_4niAl6MNOMdyGJE;
	CX::IO::SimpleBuffers::Int32Array sbt_CNEOELGY0Cu36Khyo;
	sbt_EArray sbt_T9szRFGpjCUNU7J_X;

	virtual void Reset()
	{
		sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.clear();
		sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.clear();
		sbt_n1fv0dYAvRAe7Ha.clear();
		sbt_HbA = 0;
		sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn = 0;
		sbt_twCy6ixwxTyBVCFVdp46r5Xny = 0.0;
		sbt_32UT6kj89TKTJFAUExiIxyApZ.clear();
		sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.clear();
		sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk.clear();
		sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.clear();
		sbt_QlOKrKiV5Fe.clear();
		sbt_77J0tYc584DLuLtbv_4T7mwf7 = 0;
		sbt_k.clear();
		sbt_4niAl6MNOMdyGJE = false;
		sbt_CNEOELGY0Cu36Khyo.clear();
		sbt_T9szRFGpjCUNU7J_X.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.push_back(81);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.push_back(L"P/RtL@Ykv9}kn6[5hT)4=z[[f=2v+_a.!v18N^&psYQr2~*<");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_n1fv0dYAvRAe7Ha.push_back(-5138);
		}
		sbt_HbA = 2125298889;
		sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn = 25771;
		sbt_twCy6ixwxTyBVCFVdp46r5Xny = 0.236397;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_32UT6kj89TKTJFAUExiIxyApZ.push_back(true);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.push_back(22566);
		}
		sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk = L"Oz$/jpN+*(\\P,PIY7\"*)AEvl5gF:Ub{>!";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.push_back(12);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_QlOKrKiV5Fe.push_back(1101667740);
		}
		sbt_77J0tYc584DLuLtbv_4T7mwf7 = -64;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_k.push_back(52941);
		}
		sbt_4niAl6MNOMdyGJE = true;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_CNEOELGY0Cu36Khyo.push_back(-966199775);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_E v;

			v.SetupWithSomeValues();
			sbt_T9szRFGpjCUNU7J_X.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_QEU *pObject = dynamic_cast<const sbt_QEU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.size() != pObject->sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.size(); i++)
		{
			if (sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp[i] != pObject->sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp[i])
			{
				return false;
			}
		}
		if (sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.size() != pObject->sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT[i].c_str(), pObject->sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_n1fv0dYAvRAe7Ha.size() != pObject->sbt_n1fv0dYAvRAe7Ha.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n1fv0dYAvRAe7Ha.size(); i++)
		{
			if (sbt_n1fv0dYAvRAe7Ha[i] != pObject->sbt_n1fv0dYAvRAe7Ha[i])
			{
				return false;
			}
		}
		if (sbt_HbA != pObject->sbt_HbA)
		{
			return false;
		}
		if (sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn != pObject->sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn)
		{
			return false;
		}
		if (sbt_twCy6ixwxTyBVCFVdp46r5Xny != pObject->sbt_twCy6ixwxTyBVCFVdp46r5Xny)
		{
			return false;
		}
		if (sbt_32UT6kj89TKTJFAUExiIxyApZ.size() != pObject->sbt_32UT6kj89TKTJFAUExiIxyApZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_32UT6kj89TKTJFAUExiIxyApZ.size(); i++)
		{
			if (sbt_32UT6kj89TKTJFAUExiIxyApZ[i] != pObject->sbt_32UT6kj89TKTJFAUExiIxyApZ[i])
			{
				return false;
			}
		}
		if (sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.size() != pObject->sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.size(); i++)
		{
			if (sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH[i] != pObject->sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk.c_str(), pObject->sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk.c_str()))
		{
			return false;
		}
		if (sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.size() != pObject->sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.size(); i++)
		{
			if (sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb[i] != pObject->sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb[i])
			{
				return false;
			}
		}
		if (sbt_QlOKrKiV5Fe.size() != pObject->sbt_QlOKrKiV5Fe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QlOKrKiV5Fe.size(); i++)
		{
			if (sbt_QlOKrKiV5Fe[i] != pObject->sbt_QlOKrKiV5Fe[i])
			{
				return false;
			}
		}
		if (sbt_77J0tYc584DLuLtbv_4T7mwf7 != pObject->sbt_77J0tYc584DLuLtbv_4T7mwf7)
		{
			return false;
		}
		if (sbt_k.size() != pObject->sbt_k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k.size(); i++)
		{
			if (sbt_k[i] != pObject->sbt_k[i])
			{
				return false;
			}
		}
		if (sbt_4niAl6MNOMdyGJE != pObject->sbt_4niAl6MNOMdyGJE)
		{
			return false;
		}
		if (sbt_CNEOELGY0Cu36Khyo.size() != pObject->sbt_CNEOELGY0Cu36Khyo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CNEOELGY0Cu36Khyo.size(); i++)
		{
			if (sbt_CNEOELGY0Cu36Khyo[i] != pObject->sbt_CNEOELGY0Cu36Khyo[i])
			{
				return false;
			}
		}
		if (sbt_T9szRFGpjCUNU7J_X.size() != pObject->sbt_T9szRFGpjCUNU7J_X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_T9szRFGpjCUNU7J_X.size(); i++)
		{
			if (!sbt_T9szRFGpjCUNU7J_X[i].Compare(&pObject->sbt_T9szRFGpjCUNU7J_X[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n1fv0dYAvRAe7Ha")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n1fv0dYAvRAe7Ha.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HbA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HbA = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_twCy6ixwxTyBVCFVdp46r5Xny", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_twCy6ixwxTyBVCFVdp46r5Xny = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_32UT6kj89TKTJFAUExiIxyApZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_32UT6kj89TKTJFAUExiIxyApZ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk", &sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QlOKrKiV5Fe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QlOKrKiV5Fe.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_77J0tYc584DLuLtbv_4T7mwf7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_77J0tYc584DLuLtbv_4T7mwf7 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_4niAl6MNOMdyGJE", &sbt_4niAl6MNOMdyGJE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CNEOELGY0Cu36Khyo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CNEOELGY0Cu36Khyo.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_T9szRFGpjCUNU7J_X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_E tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_T9szRFGpjCUNU7J_X.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.begin(); iter != sbt_RhPxTvy6jFXDUCfFPHA5Vvp5ups2nkm96WzdnZqwEw37hfp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.begin(); iter != sbt_YFSUcAkV5DOZ_dwR4pvirq1v8Za1TpGy0z1lW_kXT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n1fv0dYAvRAe7Ha")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_n1fv0dYAvRAe7Ha.begin(); iter != sbt_n1fv0dYAvRAe7Ha.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HbA", (CX::Int64)sbt_HbA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn", (CX::Int64)sbt_CKTDPQeT0Dk5jJmZIpqwKEJM8VAauXQ4ZYn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_twCy6ixwxTyBVCFVdp46r5Xny", (CX::Double)sbt_twCy6ixwxTyBVCFVdp46r5Xny)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_32UT6kj89TKTJFAUExiIxyApZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_32UT6kj89TKTJFAUExiIxyApZ.begin(); iter != sbt_32UT6kj89TKTJFAUExiIxyApZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.begin(); iter != sbt_kKmBMRbgcWBEZ2AmhOSmsLovAb3kybpekBEe8LwuVjcuNfpJbBH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk", sbt_GP_IfO_XwWfD555UQ4FQuxlFbnPf2ReJk.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.begin(); iter != sbt_to1hDqbpOd3AaH7XaxbObVlzdFGMRcLt9LPxd5t7bm4zCvldT5Rm5mvSqVsStVb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QlOKrKiV5Fe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QlOKrKiV5Fe.begin(); iter != sbt_QlOKrKiV5Fe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_77J0tYc584DLuLtbv_4T7mwf7", (CX::Int64)sbt_77J0tYc584DLuLtbv_4T7mwf7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_k.begin(); iter != sbt_k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_4niAl6MNOMdyGJE", sbt_4niAl6MNOMdyGJE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CNEOELGY0Cu36Khyo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_CNEOELGY0Cu36Khyo.begin(); iter != sbt_CNEOELGY0Cu36Khyo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_T9szRFGpjCUNU7J_X")).IsNOK())
		{
			return status;
		}
		for (sbt_EArray::const_iterator iter = sbt_T9szRFGpjCUNU7J_X.begin(); iter != sbt_T9szRFGpjCUNU7J_X.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_QEU>::Type sbt_QEUArray;

