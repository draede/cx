
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp.hpp"


class sbt_cOeLQAg366GjPE6SHlT : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_IL58QB6mdwRHL1HunOeRgdA;
	CX::Bool sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH;
	CX::IO::SimpleBuffers::UInt8Array sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK;
	CX::Int8 sbt_wzosZkNDCsm3GYrlz;
	CX::Float sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8;
	CX::String sbt__UfnTvYt35wC4YbCKVOXR5GA3;
	CX::IO::SimpleBuffers::BoolArray sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV;
	CX::IO::SimpleBuffers::DoubleArray sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G;
	CX::UInt16 sbt_yss;
	CX::Bool sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL;
	CX::Bool sbt_nGoSg;
	CX::Double sbt_bcmuGGxL_viyeWaC8dU;
	CX::Float sbt_pXb;
	sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRpArray sbt_4QkqzBBENLoW85LGQa2jLC1;

	virtual void Reset()
	{
		sbt_IL58QB6mdwRHL1HunOeRgdA.clear();
		sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH = false;
		sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.clear();
		sbt_wzosZkNDCsm3GYrlz = 0;
		sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8 = 0.0f;
		sbt__UfnTvYt35wC4YbCKVOXR5GA3.clear();
		sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.clear();
		sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.clear();
		sbt_yss = 0;
		sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL = false;
		sbt_nGoSg = false;
		sbt_bcmuGGxL_viyeWaC8dU = 0.0;
		sbt_pXb = 0.0f;
		sbt_4QkqzBBENLoW85LGQa2jLC1.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_IL58QB6mdwRHL1HunOeRgdA.push_back(L"*rb$PYSzFD/i-956F");
		}
		sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.push_back(186);
		}
		sbt_wzosZkNDCsm3GYrlz = -42;
		sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8 = 0.388244f;
		sbt__UfnTvYt35wC4YbCKVOXR5GA3 = "?Fqr?X+\\~6-VE@|lv^5*V6(/NZ.82aDLa";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.push_back(true);
		}
		sbt_yss = 7910;
		sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL = false;
		sbt_nGoSg = false;
		sbt_bcmuGGxL_viyeWaC8dU = 0.895532;
		sbt_pXb = 0.218885f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp v;

			v.SetupWithSomeValues();
			sbt_4QkqzBBENLoW85LGQa2jLC1.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_cOeLQAg366GjPE6SHlT *pObject = dynamic_cast<const sbt_cOeLQAg366GjPE6SHlT *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_IL58QB6mdwRHL1HunOeRgdA.size() != pObject->sbt_IL58QB6mdwRHL1HunOeRgdA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IL58QB6mdwRHL1HunOeRgdA.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_IL58QB6mdwRHL1HunOeRgdA[i].c_str(), pObject->sbt_IL58QB6mdwRHL1HunOeRgdA[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH != pObject->sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH)
		{
			return false;
		}
		if (sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.size() != pObject->sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.size(); i++)
		{
			if (sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK[i] != pObject->sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK[i])
			{
				return false;
			}
		}
		if (sbt_wzosZkNDCsm3GYrlz != pObject->sbt_wzosZkNDCsm3GYrlz)
		{
			return false;
		}
		if (sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8 != pObject->sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt__UfnTvYt35wC4YbCKVOXR5GA3.c_str(), pObject->sbt__UfnTvYt35wC4YbCKVOXR5GA3.c_str()))
		{
			return false;
		}
		if (sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.size() != pObject->sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.size(); i++)
		{
			if (sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV[i] != pObject->sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV[i])
			{
				return false;
			}
		}
		if (sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.size() != pObject->sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.size(); i++)
		{
			if (sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G[i] != pObject->sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G[i])
			{
				return false;
			}
		}
		if (sbt_yss != pObject->sbt_yss)
		{
			return false;
		}
		if (sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL != pObject->sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL)
		{
			return false;
		}
		if (sbt_nGoSg != pObject->sbt_nGoSg)
		{
			return false;
		}
		if (sbt_bcmuGGxL_viyeWaC8dU != pObject->sbt_bcmuGGxL_viyeWaC8dU)
		{
			return false;
		}
		if (sbt_pXb != pObject->sbt_pXb)
		{
			return false;
		}
		if (sbt_4QkqzBBENLoW85LGQa2jLC1.size() != pObject->sbt_4QkqzBBENLoW85LGQa2jLC1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4QkqzBBENLoW85LGQa2jLC1.size(); i++)
		{
			if (!sbt_4QkqzBBENLoW85LGQa2jLC1[i].Compare(&pObject->sbt_4QkqzBBENLoW85LGQa2jLC1[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_IL58QB6mdwRHL1HunOeRgdA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IL58QB6mdwRHL1HunOeRgdA.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH", &sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wzosZkNDCsm3GYrlz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wzosZkNDCsm3GYrlz = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectString("sbt__UfnTvYt35wC4YbCKVOXR5GA3", &sbt__UfnTvYt35wC4YbCKVOXR5GA3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yss", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yss = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL", &sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_nGoSg", &sbt_nGoSg)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_bcmuGGxL_viyeWaC8dU", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_bcmuGGxL_viyeWaC8dU = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_pXb", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_pXb = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_4QkqzBBENLoW85LGQa2jLC1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_4QkqzBBENLoW85LGQa2jLC1.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_IL58QB6mdwRHL1HunOeRgdA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_IL58QB6mdwRHL1HunOeRgdA.begin(); iter != sbt_IL58QB6mdwRHL1HunOeRgdA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH", sbt_y9bSZ8paOuBXFp2meBRvRPmVapH8orPx5k372xUjpJDdAxkcCBDSWAwOvKbRH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.begin(); iter != sbt_V0zNJXl86oRupsFrf00wD0u2Tc6FcnsacN5nwZCoU5zDK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wzosZkNDCsm3GYrlz", (CX::Int64)sbt_wzosZkNDCsm3GYrlz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8", (CX::Double)sbt_tzybXkLOqCH1CTbqZMVYJy0oBUF1hLDvJSv3uIwDfIq72a4HeGFT8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt__UfnTvYt35wC4YbCKVOXR5GA3", sbt__UfnTvYt35wC4YbCKVOXR5GA3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.begin(); iter != sbt_JFjTrKupGBj3RjfjBVh94aeMNTpGV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.begin(); iter != sbt_9BG8s0e1g3yQJp7TrfXvUdpYLggtOvbHYgRyOEC4hGVIQ0zsJ5G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yss", (CX::Int64)sbt_yss)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL", sbt_cgXZNTz4qoe1N8EhEnE41lmGdiV5dzlHL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_nGoSg", sbt_nGoSg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_bcmuGGxL_viyeWaC8dU", (CX::Double)sbt_bcmuGGxL_viyeWaC8dU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_pXb", (CX::Double)sbt_pXb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4QkqzBBENLoW85LGQa2jLC1")).IsNOK())
		{
			return status;
		}
		for (sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRpArray::const_iterator iter = sbt_4QkqzBBENLoW85LGQa2jLC1.begin(); iter != sbt_4QkqzBBENLoW85LGQa2jLC1.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_cOeLQAg366GjPE6SHlT>::Type sbt_cOeLQAg366GjPE6SHlTArray;

