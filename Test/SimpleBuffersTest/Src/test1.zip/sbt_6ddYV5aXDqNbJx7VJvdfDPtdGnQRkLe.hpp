
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9;
	CX::IO::SimpleBuffers::BoolArray sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng;
	CX::IO::SimpleBuffers::Int8Array sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R;
	CX::UInt16 sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36;
	CX::UInt32 sbt_qb35cWHjdyGbFiLKoBRpudV;
	CX::IO::SimpleBuffers::Int64Array sbt_fphRZQCgo6YXiRo;
	CX::Int16 sbt_ZTiwNxJcF;
	CX::Int8 sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU;
	CX::IO::SimpleBuffers::UInt8Array sbt_lbX0ZBesGUBH4;
	CX::IO::SimpleBuffers::Int8Array sbt_H;
	CX::Int8 sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K;
	CX::Int32 sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7;
	CX::IO::SimpleBuffers::UInt64Array sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO;
	CX::UInt64 sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh;
	CX::Int32 sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe;
	CX::UInt8 sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS;

	virtual void Reset()
	{
		sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.clear();
		sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.clear();
		sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.clear();
		sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36 = 0;
		sbt_qb35cWHjdyGbFiLKoBRpudV = 0;
		sbt_fphRZQCgo6YXiRo.clear();
		sbt_ZTiwNxJcF = 0;
		sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU = 0;
		sbt_lbX0ZBesGUBH4.clear();
		sbt_H.clear();
		sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K = 0;
		sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7 = 0;
		sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.clear();
		sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh = 0;
		sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe = 0;
		sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.push_back(false);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.push_back(true);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.push_back(-61);
		}
		sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36 = 17204;
		sbt_qb35cWHjdyGbFiLKoBRpudV = 1879014210;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_fphRZQCgo6YXiRo.push_back(-696714283182225026);
		}
		sbt_ZTiwNxJcF = -23435;
		sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU = 31;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_lbX0ZBesGUBH4.push_back(106);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_H.push_back(-68);
		}
		sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K = 122;
		sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7 = -935259416;
		sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh = 5473158171118097004;
		sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe = 1764359982;
		sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS = 66;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe *pObject = dynamic_cast<const sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.size() != pObject->sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.size(); i++)
		{
			if (sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9[i] != pObject->sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9[i])
			{
				return false;
			}
		}
		if (sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.size() != pObject->sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.size(); i++)
		{
			if (sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng[i] != pObject->sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng[i])
			{
				return false;
			}
		}
		if (sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.size() != pObject->sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.size(); i++)
		{
			if (sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R[i] != pObject->sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R[i])
			{
				return false;
			}
		}
		if (sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36 != pObject->sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36)
		{
			return false;
		}
		if (sbt_qb35cWHjdyGbFiLKoBRpudV != pObject->sbt_qb35cWHjdyGbFiLKoBRpudV)
		{
			return false;
		}
		if (sbt_fphRZQCgo6YXiRo.size() != pObject->sbt_fphRZQCgo6YXiRo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fphRZQCgo6YXiRo.size(); i++)
		{
			if (sbt_fphRZQCgo6YXiRo[i] != pObject->sbt_fphRZQCgo6YXiRo[i])
			{
				return false;
			}
		}
		if (sbt_ZTiwNxJcF != pObject->sbt_ZTiwNxJcF)
		{
			return false;
		}
		if (sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU != pObject->sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU)
		{
			return false;
		}
		if (sbt_lbX0ZBesGUBH4.size() != pObject->sbt_lbX0ZBesGUBH4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lbX0ZBesGUBH4.size(); i++)
		{
			if (sbt_lbX0ZBesGUBH4[i] != pObject->sbt_lbX0ZBesGUBH4[i])
			{
				return false;
			}
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K != pObject->sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K)
		{
			return false;
		}
		if (sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7 != pObject->sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7)
		{
			return false;
		}
		if (sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.size() != pObject->sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.size(); i++)
		{
			if (sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO[i] != pObject->sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO[i])
			{
				return false;
			}
		}
		if (sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh != pObject->sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh)
		{
			return false;
		}
		if (sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe != pObject->sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe)
		{
			return false;
		}
		if (sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS != pObject->sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qb35cWHjdyGbFiLKoBRpudV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qb35cWHjdyGbFiLKoBRpudV = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fphRZQCgo6YXiRo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fphRZQCgo6YXiRo.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZTiwNxJcF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZTiwNxJcF = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lbX0ZBesGUBH4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lbX0ZBesGUBH4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.begin(); iter != sbt_j7egIvRuZyHTC2X_Ep3bVNHwdqAMbxq2L2VDk5CQGqaocNUFZBWLd2TCRe9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.begin(); iter != sbt_zAcPNwx_PffpQkobKTbAbk519G_NSri5PJLng.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.begin(); iter != sbt_wb6Z7fIYsNArE5tRWsWu00c1i5me39y9rj3r9KEaP4AgHedB5OGvDV6f7_ql93R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36", (CX::Int64)sbt_YuQutu6hzslbfifDdpeJfz8QpOfzLPkbB36)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qb35cWHjdyGbFiLKoBRpudV", (CX::Int64)sbt_qb35cWHjdyGbFiLKoBRpudV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fphRZQCgo6YXiRo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_fphRZQCgo6YXiRo.begin(); iter != sbt_fphRZQCgo6YXiRo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZTiwNxJcF", (CX::Int64)sbt_ZTiwNxJcF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU", (CX::Int64)sbt_ZMipvWX1MTGMvjr3Qw0hhh6r_Cj5RK2EQWU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lbX0ZBesGUBH4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_lbX0ZBesGUBH4.begin(); iter != sbt_lbX0ZBesGUBH4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K", (CX::Int64)sbt_D0E0cx1oUd_tX1kULF1cOsPR7v9_JySRCBZngXbGcvt_UtzuoOcie1K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7", (CX::Int64)sbt_ICO73T92bKGiY5e70m0iI0KcgJ0cz0BXckAcRgVzBs9yG46aFMQohNoyWnTm7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.begin(); iter != sbt_WxKi6zBMByRxJFefdA9lTL1bmGKPzK5QCNyew_86_J9JBG5zBJhmO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh", (CX::Int64)sbt_qAuNLMUxPM67AwzGaDIaZ3_WVlT5lYspwQbEeKh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe", (CX::Int64)sbt_3Scd8bt5S4j6UtMPR9xckXl9NUTgyiN9D8laWBnbYLlWVfe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS", (CX::Int64)sbt_VEGfS2NmeA4yzupcAa2amfgAx1NsGdsJdn7H6LeJqPpP9pS)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe>::Type sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLeArray;

