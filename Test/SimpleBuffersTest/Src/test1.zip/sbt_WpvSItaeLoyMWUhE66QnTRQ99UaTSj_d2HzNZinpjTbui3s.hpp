
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1;
	CX::IO::SimpleBuffers::UInt64Array sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG;
	CX::UInt32 sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd;
	CX::UInt16 sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4;
	CX::IO::SimpleBuffers::UInt32Array sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3;
	CX::IO::SimpleBuffers::Int32Array sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe;
	CX::IO::SimpleBuffers::UInt32Array sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac;
	CX::IO::SimpleBuffers::UInt16Array sbt_g92t9J1IrBZ;
	CX::IO::SimpleBuffers::UInt64Array sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW;
	CX::IO::SimpleBuffers::Int16Array sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C;

	virtual void Reset()
	{
		sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1 = 0;
		sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.clear();
		sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd = 0;
		sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4 = 0;
		sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.clear();
		sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.clear();
		sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.clear();
		sbt_g92t9J1IrBZ.clear();
		sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.clear();
		sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1 = 44743;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.push_back(15992814154418394280);
		}
		sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd = 2456044991;
		sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4 = 18423;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.push_back(4057156946);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.push_back(-332738069);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.push_back(309150263);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_g92t9J1IrBZ.push_back(49523);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.push_back(13320677773099923890);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.push_back(17046);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s *pObject = dynamic_cast<const sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1 != pObject->sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1)
		{
			return false;
		}
		if (sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.size() != pObject->sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.size(); i++)
		{
			if (sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG[i] != pObject->sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG[i])
			{
				return false;
			}
		}
		if (sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd != pObject->sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd)
		{
			return false;
		}
		if (sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4 != pObject->sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4)
		{
			return false;
		}
		if (sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.size() != pObject->sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.size(); i++)
		{
			if (sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3[i] != pObject->sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3[i])
			{
				return false;
			}
		}
		if (sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.size() != pObject->sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.size(); i++)
		{
			if (sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe[i] != pObject->sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe[i])
			{
				return false;
			}
		}
		if (sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.size() != pObject->sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.size(); i++)
		{
			if (sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac[i] != pObject->sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac[i])
			{
				return false;
			}
		}
		if (sbt_g92t9J1IrBZ.size() != pObject->sbt_g92t9J1IrBZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_g92t9J1IrBZ.size(); i++)
		{
			if (sbt_g92t9J1IrBZ[i] != pObject->sbt_g92t9J1IrBZ[i])
			{
				return false;
			}
		}
		if (sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.size() != pObject->sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.size(); i++)
		{
			if (sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW[i] != pObject->sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW[i])
			{
				return false;
			}
		}
		if (sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.size() != pObject->sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.size(); i++)
		{
			if (sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C[i] != pObject->sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_g92t9J1IrBZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_g92t9J1IrBZ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1", (CX::Int64)sbt_0g0Spon1yLv4n_vY1AVY_mxCzq1Wne1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.begin(); iter != sbt_yRRdwzpkKCpqUJSO93KcdQTc4ItjsPA8Gw2UWqlX0GULcO4sAUG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd", (CX::Int64)sbt_hmo_8EWYlvKyXztouBvCvFzkATB3lq5SrLB67p7u4MW51sJ2oQAkQDXELnz2Qhd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4", (CX::Int64)sbt_O5wbFvyRupbaA_5uyAfoYzV_kQorSZAzDHG4YCwH8KAU7sywgFWmeT4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.begin(); iter != sbt_7HWmdm8mEeYYNtRXPoYdRHL6mphG3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.begin(); iter != sbt_uqx26jWmn9xsOACyvmX_xEv4Bj6MfSvnQCe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.begin(); iter != sbt_lsQQS0xhvXrTep5hQ068d6ijw9ASus1Ac.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_g92t9J1IrBZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_g92t9J1IrBZ.begin(); iter != sbt_g92t9J1IrBZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.begin(); iter != sbt_ODmTZYwa1EZjdiMW_O65N3BNYZIGr4W5TywQL0zDulti1A9lW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.begin(); iter != sbt_fFq8m8dj98PvoElSaMI4w6Q6FnKcQgTsH5xieAkD6OlZU8C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s>::Type sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3sArray;

