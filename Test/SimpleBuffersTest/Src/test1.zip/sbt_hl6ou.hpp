
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_hl6ou : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_YenTfA7wn5hFUFBKIpc1_JUlr;
	CX::UInt8 sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR;
	CX::IO::SimpleBuffers::UInt16Array sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp;
	CX::Int64 sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq;
	CX::IO::SimpleBuffers::Int16Array sbt_BXEwONLmUTgt6SKXDS5;
	CX::IO::SimpleBuffers::UInt32Array sbt_h25;
	CX::UInt32 sbt_G;

	virtual void Reset()
	{
		sbt_YenTfA7wn5hFUFBKIpc1_JUlr.clear();
		sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR = 0;
		sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.clear();
		sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq = 0;
		sbt_BXEwONLmUTgt6SKXDS5.clear();
		sbt_h25.clear();
		sbt_G = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_YenTfA7wn5hFUFBKIpc1_JUlr.push_back(159);
		}
		sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR = 181;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.push_back(37969);
		}
		sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq = -5765872061118979622;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_BXEwONLmUTgt6SKXDS5.push_back(3595);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_h25.push_back(2042800008);
		}
		sbt_G = 906301500;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_hl6ou *pObject = dynamic_cast<const sbt_hl6ou *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_YenTfA7wn5hFUFBKIpc1_JUlr.size() != pObject->sbt_YenTfA7wn5hFUFBKIpc1_JUlr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YenTfA7wn5hFUFBKIpc1_JUlr.size(); i++)
		{
			if (sbt_YenTfA7wn5hFUFBKIpc1_JUlr[i] != pObject->sbt_YenTfA7wn5hFUFBKIpc1_JUlr[i])
			{
				return false;
			}
		}
		if (sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR != pObject->sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR)
		{
			return false;
		}
		if (sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.size() != pObject->sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.size(); i++)
		{
			if (sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp[i] != pObject->sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp[i])
			{
				return false;
			}
		}
		if (sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq != pObject->sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq)
		{
			return false;
		}
		if (sbt_BXEwONLmUTgt6SKXDS5.size() != pObject->sbt_BXEwONLmUTgt6SKXDS5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BXEwONLmUTgt6SKXDS5.size(); i++)
		{
			if (sbt_BXEwONLmUTgt6SKXDS5[i] != pObject->sbt_BXEwONLmUTgt6SKXDS5[i])
			{
				return false;
			}
		}
		if (sbt_h25.size() != pObject->sbt_h25.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h25.size(); i++)
		{
			if (sbt_h25[i] != pObject->sbt_h25[i])
			{
				return false;
			}
		}
		if (sbt_G != pObject->sbt_G)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_YenTfA7wn5hFUFBKIpc1_JUlr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YenTfA7wn5hFUFBKIpc1_JUlr.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BXEwONLmUTgt6SKXDS5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BXEwONLmUTgt6SKXDS5.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h25")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h25.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_YenTfA7wn5hFUFBKIpc1_JUlr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_YenTfA7wn5hFUFBKIpc1_JUlr.begin(); iter != sbt_YenTfA7wn5hFUFBKIpc1_JUlr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR", (CX::Int64)sbt_P8jcDI035SnmUfwsb4Yscm03v8sqnfR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.begin(); iter != sbt_pYkA0U7jnkyG1oWU9Vj0hhVp3dsUp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq", (CX::Int64)sbt_UCGlyeDeuEd0gulGnmMjwxi2rTibB8KoN5d0CoUMzZTBKeXMroOENCVeq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BXEwONLmUTgt6SKXDS5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_BXEwONLmUTgt6SKXDS5.begin(); iter != sbt_BXEwONLmUTgt6SKXDS5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h25")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_h25.begin(); iter != sbt_h25.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G", (CX::Int64)sbt_G)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_hl6ou>::Type sbt_hl6ouArray;

