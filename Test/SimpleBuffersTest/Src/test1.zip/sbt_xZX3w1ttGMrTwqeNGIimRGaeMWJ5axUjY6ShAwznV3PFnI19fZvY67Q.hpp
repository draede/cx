
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_5i5d3fqW3oT;
	CX::IO::SimpleBuffers::UInt16Array sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT;
	CX::UInt16 sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0;
	CX::String sbt_hjiHnPSA37a;
	CX::UInt16 sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV;
	CX::IO::SimpleBuffers::StringArray sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3;
	CX::Int16 sbt_IfuIIXpkHzOwjo18lqkmc;
	CX::IO::SimpleBuffers::UInt16Array sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk;
	CX::IO::SimpleBuffers::Int32Array sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx;
	CX::IO::SimpleBuffers::UInt64Array sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58;
	CX::UInt32 sbt_JecrCia;
	CX::UInt32 sbt_RRzLy1Ce3hj77NW4wlT;
	CX::IO::SimpleBuffers::Int64Array sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz;
	CX::UInt8 sbt_FDw4rsyeKVTxuUOnGm7HdbJ;
	CX::IO::SimpleBuffers::UInt32Array sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW;

	virtual void Reset()
	{
		sbt_5i5d3fqW3oT.clear();
		sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.clear();
		sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0 = 0;
		sbt_hjiHnPSA37a.clear();
		sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV = 0;
		sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.clear();
		sbt_IfuIIXpkHzOwjo18lqkmc = 0;
		sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.clear();
		sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.clear();
		sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.clear();
		sbt_JecrCia = 0;
		sbt_RRzLy1Ce3hj77NW4wlT = 0;
		sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.clear();
		sbt_FDw4rsyeKVTxuUOnGm7HdbJ = 0;
		sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_5i5d3fqW3oT.push_back("K(x)LgzD]8g;yGu[e!YPqaXi3SU6%}8T4nqZ<I{)B,pS(hG^[mY.D");
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.push_back(56234);
		}
		sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0 = 60413;
		sbt_hjiHnPSA37a = "T^7p``@9wjPsW'?9Z3U+HQ~!jI$/?`pQ%{o$Hm{Y3";
		sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV = 56358;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.push_back("w@G},JJH<q|pbj07;~d5uvgT7\\%o`,WY_1\\aSv!Dzx&+s}&^Fr-\"nMOib}YJ");
		}
		sbt_IfuIIXpkHzOwjo18lqkmc = 20771;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.push_back(41489);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.push_back(909169458);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.push_back(1889339148086445878);
		}
		sbt_JecrCia = 4063337129;
		sbt_RRzLy1Ce3hj77NW4wlT = 1277433666;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.push_back(-6589887568080339070);
		}
		sbt_FDw4rsyeKVTxuUOnGm7HdbJ = 166;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.push_back(788872512);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q *pObject = dynamic_cast<const sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_5i5d3fqW3oT.size() != pObject->sbt_5i5d3fqW3oT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5i5d3fqW3oT.size(); i++)
		{
			if (0 != cx_strcmp(sbt_5i5d3fqW3oT[i].c_str(), pObject->sbt_5i5d3fqW3oT[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.size() != pObject->sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.size(); i++)
		{
			if (sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT[i] != pObject->sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT[i])
			{
				return false;
			}
		}
		if (sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0 != pObject->sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_hjiHnPSA37a.c_str(), pObject->sbt_hjiHnPSA37a.c_str()))
		{
			return false;
		}
		if (sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV != pObject->sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV)
		{
			return false;
		}
		if (sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.size() != pObject->sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.size(); i++)
		{
			if (0 != cx_strcmp(sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3[i].c_str(), pObject->sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_IfuIIXpkHzOwjo18lqkmc != pObject->sbt_IfuIIXpkHzOwjo18lqkmc)
		{
			return false;
		}
		if (sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.size() != pObject->sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.size(); i++)
		{
			if (sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk[i] != pObject->sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk[i])
			{
				return false;
			}
		}
		if (sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.size() != pObject->sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.size(); i++)
		{
			if (sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx[i] != pObject->sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx[i])
			{
				return false;
			}
		}
		if (sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.size() != pObject->sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.size(); i++)
		{
			if (sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58[i] != pObject->sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58[i])
			{
				return false;
			}
		}
		if (sbt_JecrCia != pObject->sbt_JecrCia)
		{
			return false;
		}
		if (sbt_RRzLy1Ce3hj77NW4wlT != pObject->sbt_RRzLy1Ce3hj77NW4wlT)
		{
			return false;
		}
		if (sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.size() != pObject->sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.size(); i++)
		{
			if (sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz[i] != pObject->sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz[i])
			{
				return false;
			}
		}
		if (sbt_FDw4rsyeKVTxuUOnGm7HdbJ != pObject->sbt_FDw4rsyeKVTxuUOnGm7HdbJ)
		{
			return false;
		}
		if (sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.size() != pObject->sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.size(); i++)
		{
			if (sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW[i] != pObject->sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_5i5d3fqW3oT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5i5d3fqW3oT.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_hjiHnPSA37a", &sbt_hjiHnPSA37a)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IfuIIXpkHzOwjo18lqkmc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IfuIIXpkHzOwjo18lqkmc = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JecrCia", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JecrCia = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RRzLy1Ce3hj77NW4wlT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RRzLy1Ce3hj77NW4wlT = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FDw4rsyeKVTxuUOnGm7HdbJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FDw4rsyeKVTxuUOnGm7HdbJ = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_5i5d3fqW3oT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_5i5d3fqW3oT.begin(); iter != sbt_5i5d3fqW3oT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.begin(); iter != sbt_9tHDlQVv9IblbLCX2oNFDYbrvhONDvBBewPrs78C_ztbwVT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0", (CX::Int64)sbt_mST0gOpK7DJYWNuTFANMEAa2afH0n0aa0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_hjiHnPSA37a", sbt_hjiHnPSA37a.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV", (CX::Int64)sbt_aiHJaw4nuBeSrfHW7vMBxDsmZBM3EF_QqsJKrJQt1WSBrwV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.begin(); iter != sbt_iWyJzgMH2yPntvh_vEBq8kvWi1nFR4nTWWYIU9HB3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IfuIIXpkHzOwjo18lqkmc", (CX::Int64)sbt_IfuIIXpkHzOwjo18lqkmc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.begin(); iter != sbt_K6fikXDweeNyH_f8cdVxhrkEkOceKpBP0Xk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.begin(); iter != sbt_ezbAagQenyTUyXq_FQjGgX12BRt9Ywzy5Fqe0BkV6Bx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.begin(); iter != sbt_Wh9hZD8QVLMhmP7jx5hVDExLm4KJ29TfxOoQMmJz7Y_GqUm58.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JecrCia", (CX::Int64)sbt_JecrCia)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RRzLy1Ce3hj77NW4wlT", (CX::Int64)sbt_RRzLy1Ce3hj77NW4wlT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.begin(); iter != sbt_vg3597yXO6Pn0Kl5ZiOu1lvQr1MYGisu9WQY6I6582yOGX3swTOYeSbZz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FDw4rsyeKVTxuUOnGm7HdbJ", (CX::Int64)sbt_FDw4rsyeKVTxuUOnGm7HdbJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.begin(); iter != sbt_JlmtNoZ__Sj9uyyTLhlhSPjK4R5fW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q>::Type sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67QArray;

