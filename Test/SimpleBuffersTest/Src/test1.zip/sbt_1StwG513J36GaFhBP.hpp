
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Fxu3FQkTl3BJionNv6S.hpp"


class sbt_1StwG513J36GaFhBP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD;
	CX::IO::SimpleBuffers::UInt64Array sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy;
	CX::IO::SimpleBuffers::Int16Array sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51;
	CX::IO::SimpleBuffers::WStringArray sbt_7GPKcVQbGsNBggCApQAYp;
	CX::UInt64 sbt_eY6Yr06RvgKtqjo;
	sbt_Fxu3FQkTl3BJionNv6S sbt_D78bZVSRPrRv3;

	virtual void Reset()
	{
		sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD = 0;
		sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.clear();
		sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.clear();
		sbt_7GPKcVQbGsNBggCApQAYp.clear();
		sbt_eY6Yr06RvgKtqjo = 0;
		sbt_D78bZVSRPrRv3.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD = 47548;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.push_back(8252058198286051438);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.push_back(-11700);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_7GPKcVQbGsNBggCApQAYp.push_back(L"yiz!migu#s-ig^VYhygMDVYzC':QnP$EL;Jpoq{x^");
		}
		sbt_eY6Yr06RvgKtqjo = 11193252864383003044;
		sbt_D78bZVSRPrRv3.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_1StwG513J36GaFhBP *pObject = dynamic_cast<const sbt_1StwG513J36GaFhBP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD != pObject->sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD)
		{
			return false;
		}
		if (sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.size() != pObject->sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.size(); i++)
		{
			if (sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy[i] != pObject->sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy[i])
			{
				return false;
			}
		}
		if (sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.size() != pObject->sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.size(); i++)
		{
			if (sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51[i] != pObject->sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51[i])
			{
				return false;
			}
		}
		if (sbt_7GPKcVQbGsNBggCApQAYp.size() != pObject->sbt_7GPKcVQbGsNBggCApQAYp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7GPKcVQbGsNBggCApQAYp.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_7GPKcVQbGsNBggCApQAYp[i].c_str(), pObject->sbt_7GPKcVQbGsNBggCApQAYp[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_eY6Yr06RvgKtqjo != pObject->sbt_eY6Yr06RvgKtqjo)
		{
			return false;
		}
		if (!sbt_D78bZVSRPrRv3.Compare(&pObject->sbt_D78bZVSRPrRv3))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7GPKcVQbGsNBggCApQAYp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7GPKcVQbGsNBggCApQAYp.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_eY6Yr06RvgKtqjo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eY6Yr06RvgKtqjo = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectObject("sbt_D78bZVSRPrRv3")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_D78bZVSRPrRv3.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD", (CX::Int64)sbt_TpWWmlNvVBRAwvLLrDDRzFFWaMz53OHcBySrHAzB8UFwfYYUnwYV1_gVD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.begin(); iter != sbt_SbI3eYFjXgITjFA7Profkxg2lenViF4ik7qzm6C3wostooy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.begin(); iter != sbt_MEqgkieLnaISd0UfQ8S1NdEZqU7NlJ_pqRcBwo1ouPyRMnwcaoCAiyn2F51.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7GPKcVQbGsNBggCApQAYp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_7GPKcVQbGsNBggCApQAYp.begin(); iter != sbt_7GPKcVQbGsNBggCApQAYp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eY6Yr06RvgKtqjo", (CX::Int64)sbt_eY6Yr06RvgKtqjo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_D78bZVSRPrRv3")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_D78bZVSRPrRv3.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_1StwG513J36GaFhBP>::Type sbt_1StwG513J36GaFhBPArray;

