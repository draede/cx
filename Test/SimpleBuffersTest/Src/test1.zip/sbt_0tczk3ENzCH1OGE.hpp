
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib.hpp"


class sbt_0tczk3ENzCH1OGE : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_CGF;
	CX::WString sbt_v;
	CX::String sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx;
	CX::IO::SimpleBuffers::DoubleArray sbt_jeogCfUh5;
	CX::String sbt_7x3pe;
	CX::WString sbt_skti2UZGLt941LpCm4bKT;
	CX::Float sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por;
	CX::IO::SimpleBuffers::UInt32Array sbt_VPo7EzV;
	CX::String sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_;
	sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib sbt_MRLdMibLoceIY624tO9AwYG;

	virtual void Reset()
	{
		sbt_CGF.clear();
		sbt_v.clear();
		sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx.clear();
		sbt_jeogCfUh5.clear();
		sbt_7x3pe.clear();
		sbt_skti2UZGLt941LpCm4bKT.clear();
		sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por = 0.0f;
		sbt_VPo7EzV.clear();
		sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_.clear();
		sbt_MRLdMibLoceIY624tO9AwYG.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_CGF.push_back(-8453);
		}
		sbt_v = L"J+voIBK:GaqBLj46wHXFW`k|.Y3xG8TG[KB4wGwq7M`!lY9tS$pC\\ENYV";
		sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx = "VIMa#I]9DBAt25XS+6m)<j.s<q`h'hOt=1DT0S3RXEBmbmB<//N3mk$\"!xK@HX";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_jeogCfUh5.push_back(0.008208);
		}
		sbt_7x3pe = "F;+5:2~VRh[Sv%~ank\".4f5)p:Cp#FpBmx";
		sbt_skti2UZGLt941LpCm4bKT = L"qS=6d&#.";
		sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por = 0.515347f;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_VPo7EzV.push_back(1457571331);
		}
		sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_ = "(E,2|7F/lCSu";
		sbt_MRLdMibLoceIY624tO9AwYG.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_0tczk3ENzCH1OGE *pObject = dynamic_cast<const sbt_0tczk3ENzCH1OGE *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_CGF.size() != pObject->sbt_CGF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CGF.size(); i++)
		{
			if (sbt_CGF[i] != pObject->sbt_CGF[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_v.c_str(), pObject->sbt_v.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx.c_str(), pObject->sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx.c_str()))
		{
			return false;
		}
		if (sbt_jeogCfUh5.size() != pObject->sbt_jeogCfUh5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jeogCfUh5.size(); i++)
		{
			if (sbt_jeogCfUh5[i] != pObject->sbt_jeogCfUh5[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_7x3pe.c_str(), pObject->sbt_7x3pe.c_str()))
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_skti2UZGLt941LpCm4bKT.c_str(), pObject->sbt_skti2UZGLt941LpCm4bKT.c_str()))
		{
			return false;
		}
		if (sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por != pObject->sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por)
		{
			return false;
		}
		if (sbt_VPo7EzV.size() != pObject->sbt_VPo7EzV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VPo7EzV.size(); i++)
		{
			if (sbt_VPo7EzV[i] != pObject->sbt_VPo7EzV[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_.c_str(), pObject->sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_.c_str()))
		{
			return false;
		}
		if (!sbt_MRLdMibLoceIY624tO9AwYG.Compare(&pObject->sbt_MRLdMibLoceIY624tO9AwYG))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_CGF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CGF.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_v", &sbt_v)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx", &sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jeogCfUh5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jeogCfUh5.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_7x3pe", &sbt_7x3pe)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_skti2UZGLt941LpCm4bKT", &sbt_skti2UZGLt941LpCm4bKT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_VPo7EzV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VPo7EzV.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_", &sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_MRLdMibLoceIY624tO9AwYG")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_MRLdMibLoceIY624tO9AwYG.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_CGF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_CGF.begin(); iter != sbt_CGF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_v", sbt_v.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx", sbt_3cSTqLczaYtqVbkDLQwTqJxMDJ22uI6fZVMxz0euchGJzQI5GmvjGZ6O2Oi7Dbx.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jeogCfUh5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_jeogCfUh5.begin(); iter != sbt_jeogCfUh5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_7x3pe", sbt_7x3pe.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_skti2UZGLt941LpCm4bKT", sbt_skti2UZGLt941LpCm4bKT.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por", (CX::Double)sbt_aRaI2gmiLQX4MjmNrJ2tPiPMQC5O4ksmgOkMGSapzkWPGQayLzU3Por)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VPo7EzV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_VPo7EzV.begin(); iter != sbt_VPo7EzV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_", sbt_NVfa0HrdbZySgBMxbAIYXPMDpX_.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_MRLdMibLoceIY624tO9AwYG")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_MRLdMibLoceIY624tO9AwYG.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_0tczk3ENzCH1OGE>::Type sbt_0tczk3ENzCH1OGEArray;

