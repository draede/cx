
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_2hPj9wyuJ.hpp"


class sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN;
	CX::Int32 sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT;
	CX::Int32 sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w;
	CX::Double sbt_DoZMWGh;
	CX::UInt8 sbt_cE0o6FMFQePkrYn;
	CX::IO::SimpleBuffers::FloatArray sbt_d0L6t;
	CX::IO::SimpleBuffers::DoubleArray sbt_ouilRgEQXFkEsqp;
	CX::IO::SimpleBuffers::WStringArray sbt_9gwGDwAUNmIbmGY3_YaiIKXX2;
	CX::IO::SimpleBuffers::Int64Array sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb;
	sbt_2hPj9wyuJ sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb;

	virtual void Reset()
	{
		sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN.clear();
		sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT = 0;
		sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w = 0;
		sbt_DoZMWGh = 0.0;
		sbt_cE0o6FMFQePkrYn = 0;
		sbt_d0L6t.clear();
		sbt_ouilRgEQXFkEsqp.clear();
		sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.clear();
		sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.clear();
		sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN = "#Li'iMFx2KFR7ib,D!g4@rL)BxZEL\"3aQq|2hz}3{f/Xl-@TS^:br&{jC6\"oK#";
		sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT = -1252830003;
		sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w = 1071100590;
		sbt_DoZMWGh = 0.918790;
		sbt_cE0o6FMFQePkrYn = 225;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_d0L6t.push_back(0.728978f);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_ouilRgEQXFkEsqp.push_back(0.284520);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.push_back(-2565707579533696864);
		}
		sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2 *pObject = dynamic_cast<const sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN.c_str(), pObject->sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN.c_str()))
		{
			return false;
		}
		if (sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT != pObject->sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT)
		{
			return false;
		}
		if (sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w != pObject->sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w)
		{
			return false;
		}
		if (sbt_DoZMWGh != pObject->sbt_DoZMWGh)
		{
			return false;
		}
		if (sbt_cE0o6FMFQePkrYn != pObject->sbt_cE0o6FMFQePkrYn)
		{
			return false;
		}
		if (sbt_d0L6t.size() != pObject->sbt_d0L6t.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d0L6t.size(); i++)
		{
			if (sbt_d0L6t[i] != pObject->sbt_d0L6t[i])
			{
				return false;
			}
		}
		if (sbt_ouilRgEQXFkEsqp.size() != pObject->sbt_ouilRgEQXFkEsqp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ouilRgEQXFkEsqp.size(); i++)
		{
			if (sbt_ouilRgEQXFkEsqp[i] != pObject->sbt_ouilRgEQXFkEsqp[i])
			{
				return false;
			}
		}
		if (sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.size() != pObject->sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_9gwGDwAUNmIbmGY3_YaiIKXX2[i].c_str(), pObject->sbt_9gwGDwAUNmIbmGY3_YaiIKXX2[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.size() != pObject->sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.size(); i++)
		{
			if (sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb[i] != pObject->sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb[i])
			{
				return false;
			}
		}
		if (!sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb.Compare(&pObject->sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN", &sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_DoZMWGh", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_DoZMWGh = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_cE0o6FMFQePkrYn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cE0o6FMFQePkrYn = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_d0L6t")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d0L6t.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ouilRgEQXFkEsqp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ouilRgEQXFkEsqp.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9gwGDwAUNmIbmGY3_YaiIKXX2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN", sbt_Kyw7xpdC0ISCWvANSdi0dChesvSDW4DZN.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT", (CX::Int64)sbt_ZGk8v3rLpwuBAbW6RitlQJWssFItdVD65R6F8wFswqT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w", (CX::Int64)sbt_qoQdlnPPgDZkuthjgH48YKkOOGgsXCJDrrgrO5zn9GelQ0DtwiH3w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_DoZMWGh", (CX::Double)sbt_DoZMWGh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cE0o6FMFQePkrYn", (CX::Int64)sbt_cE0o6FMFQePkrYn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d0L6t")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_d0L6t.begin(); iter != sbt_d0L6t.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ouilRgEQXFkEsqp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_ouilRgEQXFkEsqp.begin(); iter != sbt_ouilRgEQXFkEsqp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9gwGDwAUNmIbmGY3_YaiIKXX2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.begin(); iter != sbt_9gwGDwAUNmIbmGY3_YaiIKXX2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.begin(); iter != sbt_XCHhhOBkSwyfMOfGl7DkAY2JszWbWoeXlLf5Ph6sS5WH9gb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_UCzLcDRAobPmKsgSgt3Rb7cYq65BSVt_MfRtgx7HrLGeb.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2>::Type sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2Array;

