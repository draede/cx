
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_ebD2YgyqSIxzwq4eQrvNF.hpp"


class sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5 : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_ebD2YgyqSIxzwq4eQrvNF sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh;

	virtual void Reset()
	{
		sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5 *pObject = dynamic_cast<const sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (!sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh.Compare(&pObject->sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectObject("sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectObject("sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_l_BMjg_Jr1HtTCblWPbKPFZ8A3axUHB0x6h_JEbFh.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5>::Type sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5Array;

