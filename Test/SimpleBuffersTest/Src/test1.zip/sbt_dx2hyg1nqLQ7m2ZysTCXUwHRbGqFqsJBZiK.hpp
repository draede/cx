
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_v8y.hpp"


class sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS;
	CX::Float sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f;
	CX::Bool sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ;
	CX::IO::SimpleBuffers::WStringArray sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz;
	CX::Int32 sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj;
	CX::IO::SimpleBuffers::BoolArray sbt_6qXE6yELqp04S4hhPuk4d2g8kzq;
	CX::IO::SimpleBuffers::UInt16Array sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw;
	CX::UInt64 sbt_i7gSRk8;
	CX::IO::SimpleBuffers::DoubleArray sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA;
	CX::IO::SimpleBuffers::Int16Array sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA;
	CX::IO::SimpleBuffers::BoolArray sbt_DX5Gd0H7C4N;
	CX::IO::SimpleBuffers::Int32Array sbt_fk2paoekhaLTB;
	CX::UInt64 sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd;
	CX::Int32 sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp;
	sbt_v8y sbt_w17;

	virtual void Reset()
	{
		sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS = false;
		sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f = 0.0f;
		sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ = false;
		sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.clear();
		sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj = 0;
		sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.clear();
		sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.clear();
		sbt_i7gSRk8 = 0;
		sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.clear();
		sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.clear();
		sbt_DX5Gd0H7C4N.clear();
		sbt_fk2paoekhaLTB.clear();
		sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd = 0;
		sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp = 0;
		sbt_w17.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS = true;
		sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f = 0.691060f;
		sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.push_back(L"|RaQ{c}\\8[:Y{ZktIDAX@p!*sNkIKxh_*Be}5245233!}@zSXA^ce");
		}
		sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj = 1365501744;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.push_back(true);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.push_back(29818);
		}
		sbt_i7gSRk8 = 4552553488152524564;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.push_back(0.194636);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.push_back(-25273);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_DX5Gd0H7C4N.push_back(false);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_fk2paoekhaLTB.push_back(1700966134);
		}
		sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd = 1720323576427586716;
		sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp = 47868802;
		sbt_w17.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK *pObject = dynamic_cast<const sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS != pObject->sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS)
		{
			return false;
		}
		if (sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f != pObject->sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f)
		{
			return false;
		}
		if (sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ != pObject->sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ)
		{
			return false;
		}
		if (sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.size() != pObject->sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz[i].c_str(), pObject->sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj != pObject->sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj)
		{
			return false;
		}
		if (sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.size() != pObject->sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.size(); i++)
		{
			if (sbt_6qXE6yELqp04S4hhPuk4d2g8kzq[i] != pObject->sbt_6qXE6yELqp04S4hhPuk4d2g8kzq[i])
			{
				return false;
			}
		}
		if (sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.size() != pObject->sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.size(); i++)
		{
			if (sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw[i] != pObject->sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw[i])
			{
				return false;
			}
		}
		if (sbt_i7gSRk8 != pObject->sbt_i7gSRk8)
		{
			return false;
		}
		if (sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.size() != pObject->sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.size(); i++)
		{
			if (sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA[i] != pObject->sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA[i])
			{
				return false;
			}
		}
		if (sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.size() != pObject->sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.size(); i++)
		{
			if (sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA[i] != pObject->sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA[i])
			{
				return false;
			}
		}
		if (sbt_DX5Gd0H7C4N.size() != pObject->sbt_DX5Gd0H7C4N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DX5Gd0H7C4N.size(); i++)
		{
			if (sbt_DX5Gd0H7C4N[i] != pObject->sbt_DX5Gd0H7C4N[i])
			{
				return false;
			}
		}
		if (sbt_fk2paoekhaLTB.size() != pObject->sbt_fk2paoekhaLTB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fk2paoekhaLTB.size(); i++)
		{
			if (sbt_fk2paoekhaLTB[i] != pObject->sbt_fk2paoekhaLTB[i])
			{
				return false;
			}
		}
		if (sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd != pObject->sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd)
		{
			return false;
		}
		if (sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp != pObject->sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp)
		{
			return false;
		}
		if (!sbt_w17.Compare(&pObject->sbt_w17))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS", &sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ", &sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6qXE6yELqp04S4hhPuk4d2g8kzq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_i7gSRk8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_i7gSRk8 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DX5Gd0H7C4N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DX5Gd0H7C4N.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fk2paoekhaLTB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fk2paoekhaLTB.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_w17")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_w17.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS", sbt_hg7yzfP1DiDj3E0tHBBwqIeGiKcUxqyLS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f", (CX::Double)sbt_ITNTI32LfTckyN3B0RpXAHcH_YIWpq2JwuN3R8tzHyuTPOenaDKImPI0f)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ", sbt_OF8tp8ZogcV0KBXO2gtglDcfdRzmsPQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.begin(); iter != sbt_lioN9Ik5jGz84UERg3ZFeE07OOhvNCpcoqa0_Skc7slgH2SHJuBz3ozViBFnz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj", (CX::Int64)sbt_tzvvY4SkHKjvD_kIIOASQhGx8qMxfDyzCyta_pGWRFj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6qXE6yELqp04S4hhPuk4d2g8kzq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.begin(); iter != sbt_6qXE6yELqp04S4hhPuk4d2g8kzq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.begin(); iter != sbt_DeMRQlHZ22nwMBE2UbgXNxyHK8f9AkhpIDC_V4Z3EARpkG3FmnZdJu7rpvw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_i7gSRk8", (CX::Int64)sbt_i7gSRk8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.begin(); iter != sbt_uu0Im2qnZ1JbjW7COkaX4nc2j7XTzj1sA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.begin(); iter != sbt_pMnfaQTsT0_Zmrr4tiSCG9aRUi9gObx9o9n2qO0FYs94jjd0YZSBA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DX5Gd0H7C4N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_DX5Gd0H7C4N.begin(); iter != sbt_DX5Gd0H7C4N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fk2paoekhaLTB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_fk2paoekhaLTB.begin(); iter != sbt_fk2paoekhaLTB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd", (CX::Int64)sbt_o5JQTkVH7Kh6vX2uedxRlbDTJCOcIQZhZ_nzbTBr_w2EtWVpphMEGDd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp", (CX::Int64)sbt_wdecK_ToeCB45IWZLMfFKmaS_oWATzArAQ1zWg9HtlZR1pp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_w17")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_w17.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK>::Type sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiKArray;

