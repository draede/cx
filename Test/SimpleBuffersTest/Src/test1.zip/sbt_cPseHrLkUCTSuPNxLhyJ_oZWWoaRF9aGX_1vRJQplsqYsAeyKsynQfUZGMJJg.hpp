
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt__O0rzbe7K5DbY.hpp"


class sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_hHMz1BqnYA3;
	CX::Int16 sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk;
	CX::Int8 sbt_jadn8DkSBId;
	CX::IO::SimpleBuffers::UInt32Array sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU;
	CX::UInt16 sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn;
	CX::UInt8 sbt_5UfVq;
	CX::UInt64 sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y;
	CX::IO::SimpleBuffers::Int32Array sbt_g6nNSvdQKMcrOI_sPWdp5;
	CX::UInt64 sbt_ydJR9tfD9dBS9tbuydBwi;
	CX::IO::SimpleBuffers::WStringArray sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk;
	CX::Int64 sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE;
	CX::WString sbt_RfopL;
	CX::UInt32 sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl;
	sbt__O0rzbe7K5DbY sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt;

	virtual void Reset()
	{
		sbt_hHMz1BqnYA3.clear();
		sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk = 0;
		sbt_jadn8DkSBId = 0;
		sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.clear();
		sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn = 0;
		sbt_5UfVq = 0;
		sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y = 0;
		sbt_g6nNSvdQKMcrOI_sPWdp5.clear();
		sbt_ydJR9tfD9dBS9tbuydBwi = 0;
		sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.clear();
		sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE = 0;
		sbt_RfopL.clear();
		sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl = 0;
		sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_hHMz1BqnYA3.push_back(0.953831f);
		}
		sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk = 11922;
		sbt_jadn8DkSBId = 1;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.push_back(1960815383);
		}
		sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn = 18199;
		sbt_5UfVq = 180;
		sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y = 1155519239216065412;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_g6nNSvdQKMcrOI_sPWdp5.push_back(213886197);
		}
		sbt_ydJR9tfD9dBS9tbuydBwi = 11617821344312982484;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.push_back(L"sf%\\hRwXsq9SBIcF/((}R@:H49P^c>OXKL!f4iM3lh1zi;4`");
		}
		sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE = -5000804849445765830;
		sbt_RfopL = L"u.O1Quf8<HGL,Gy,m$L*=g~qA,,gc7.";
		sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl = 1691284617;
		sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg *pObject = dynamic_cast<const sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_hHMz1BqnYA3.size() != pObject->sbt_hHMz1BqnYA3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hHMz1BqnYA3.size(); i++)
		{
			if (sbt_hHMz1BqnYA3[i] != pObject->sbt_hHMz1BqnYA3[i])
			{
				return false;
			}
		}
		if (sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk != pObject->sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk)
		{
			return false;
		}
		if (sbt_jadn8DkSBId != pObject->sbt_jadn8DkSBId)
		{
			return false;
		}
		if (sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.size() != pObject->sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.size(); i++)
		{
			if (sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU[i] != pObject->sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU[i])
			{
				return false;
			}
		}
		if (sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn != pObject->sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn)
		{
			return false;
		}
		if (sbt_5UfVq != pObject->sbt_5UfVq)
		{
			return false;
		}
		if (sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y != pObject->sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y)
		{
			return false;
		}
		if (sbt_g6nNSvdQKMcrOI_sPWdp5.size() != pObject->sbt_g6nNSvdQKMcrOI_sPWdp5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_g6nNSvdQKMcrOI_sPWdp5.size(); i++)
		{
			if (sbt_g6nNSvdQKMcrOI_sPWdp5[i] != pObject->sbt_g6nNSvdQKMcrOI_sPWdp5[i])
			{
				return false;
			}
		}
		if (sbt_ydJR9tfD9dBS9tbuydBwi != pObject->sbt_ydJR9tfD9dBS9tbuydBwi)
		{
			return false;
		}
		if (sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.size() != pObject->sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk[i].c_str(), pObject->sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE != pObject->sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_RfopL.c_str(), pObject->sbt_RfopL.c_str()))
		{
			return false;
		}
		if (sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl != pObject->sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl)
		{
			return false;
		}
		if (!sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt.Compare(&pObject->sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_hHMz1BqnYA3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hHMz1BqnYA3.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jadn8DkSBId", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jadn8DkSBId = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5UfVq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5UfVq = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_g6nNSvdQKMcrOI_sPWdp5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_g6nNSvdQKMcrOI_sPWdp5.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ydJR9tfD9dBS9tbuydBwi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ydJR9tfD9dBS9tbuydBwi = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_RfopL", &sbt_RfopL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_hHMz1BqnYA3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_hHMz1BqnYA3.begin(); iter != sbt_hHMz1BqnYA3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk", (CX::Int64)sbt_YAamnLk3Nzd3wmO5Tx4C7awOBfSt_3oyCHm0NLxioqGMgl8k8Pi6OwLkCUsOk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jadn8DkSBId", (CX::Int64)sbt_jadn8DkSBId)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.begin(); iter != sbt_ISJpPdZJZYqeEa8RpuUDy16LsbIocdeSBYzERt7HIFAKQbU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn", (CX::Int64)sbt_lCbgOwANmkAbULAVYHxxShX4qDzmCGn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5UfVq", (CX::Int64)sbt_5UfVq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y", (CX::Int64)sbt_JSeGHStyjNxqE2VrutcQjyUp2kRAFlKLRs9yJU_eaLf8Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_g6nNSvdQKMcrOI_sPWdp5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_g6nNSvdQKMcrOI_sPWdp5.begin(); iter != sbt_g6nNSvdQKMcrOI_sPWdp5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ydJR9tfD9dBS9tbuydBwi", (CX::Int64)sbt_ydJR9tfD9dBS9tbuydBwi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.begin(); iter != sbt_tuheHPouq6UNqMuA4YQiL3Zu6MRJrZx9HWndKaTQFw2cviYmp7bPx89Yk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE", (CX::Int64)sbt_XaYo7Jz4oNizCnPZG2d66h78o0IzTjwgSeTIjYcIrVuWnt4NYdM91kB5OgBftdE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_RfopL", sbt_RfopL.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl", (CX::Int64)sbt_fZwdQXtQwDF9ZOdGiq24YyyiHGl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_fz7lqXQnhrQgL8NM44OsqfFgiUFxvpt.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg>::Type sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJgArray;

