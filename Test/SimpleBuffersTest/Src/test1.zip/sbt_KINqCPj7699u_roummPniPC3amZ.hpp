
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_HLTF_vOHD2xgzZVQMatt200jNZdABGtxM.hpp"


class sbt_KINqCPj7699u_roummPniPC3amZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN;
	CX::WString sbt_aSOQomPizqSE5rRtWg6;
	CX::IO::SimpleBuffers::FloatArray sbt_KFebWB8WJ;
	CX::IO::SimpleBuffers::BoolArray sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ;
	CX::Int32 sbt_HUAuigWOYtghP3tGVcOEXeCyF_1;
	CX::IO::SimpleBuffers::DoubleArray sbt_OpogSmGCQ149nDnRi;
	sbt_HLTF_vOHD2xgzZVQMatt200jNZdABGtxM sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7;

	virtual void Reset()
	{
		sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN = 0.0;
		sbt_aSOQomPizqSE5rRtWg6.clear();
		sbt_KFebWB8WJ.clear();
		sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.clear();
		sbt_HUAuigWOYtghP3tGVcOEXeCyF_1 = 0;
		sbt_OpogSmGCQ149nDnRi.clear();
		sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN = 0.418579;
		sbt_aSOQomPizqSE5rRtWg6 = L"jH]&oGdjj0i_`26~r[:Zq8[n7BY)(+*(SA@.O)";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_KFebWB8WJ.push_back(0.033614f);
		}
		sbt_HUAuigWOYtghP3tGVcOEXeCyF_1 = 553893578;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_OpogSmGCQ149nDnRi.push_back(0.940166);
		}
		sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KINqCPj7699u_roummPniPC3amZ *pObject = dynamic_cast<const sbt_KINqCPj7699u_roummPniPC3amZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN != pObject->sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_aSOQomPizqSE5rRtWg6.c_str(), pObject->sbt_aSOQomPizqSE5rRtWg6.c_str()))
		{
			return false;
		}
		if (sbt_KFebWB8WJ.size() != pObject->sbt_KFebWB8WJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KFebWB8WJ.size(); i++)
		{
			if (sbt_KFebWB8WJ[i] != pObject->sbt_KFebWB8WJ[i])
			{
				return false;
			}
		}
		if (sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.size() != pObject->sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.size(); i++)
		{
			if (sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ[i] != pObject->sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ[i])
			{
				return false;
			}
		}
		if (sbt_HUAuigWOYtghP3tGVcOEXeCyF_1 != pObject->sbt_HUAuigWOYtghP3tGVcOEXeCyF_1)
		{
			return false;
		}
		if (sbt_OpogSmGCQ149nDnRi.size() != pObject->sbt_OpogSmGCQ149nDnRi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OpogSmGCQ149nDnRi.size(); i++)
		{
			if (sbt_OpogSmGCQ149nDnRi[i] != pObject->sbt_OpogSmGCQ149nDnRi[i])
			{
				return false;
			}
		}
		if (!sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7.Compare(&pObject->sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_aSOQomPizqSE5rRtWg6", &sbt_aSOQomPizqSE5rRtWg6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KFebWB8WJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KFebWB8WJ.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HUAuigWOYtghP3tGVcOEXeCyF_1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HUAuigWOYtghP3tGVcOEXeCyF_1 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OpogSmGCQ149nDnRi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OpogSmGCQ149nDnRi.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN", (CX::Double)sbt_MkPSNmkmRLTnmOmgxMZWv07Lag7FPuRGKIwbHseCrmjAAcN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_aSOQomPizqSE5rRtWg6", sbt_aSOQomPizqSE5rRtWg6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KFebWB8WJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_KFebWB8WJ.begin(); iter != sbt_KFebWB8WJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.begin(); iter != sbt_O3R8liETB6GAj2ZhjNgAUtrlx4y0pDEmJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HUAuigWOYtghP3tGVcOEXeCyF_1", (CX::Int64)sbt_HUAuigWOYtghP3tGVcOEXeCyF_1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OpogSmGCQ149nDnRi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_OpogSmGCQ149nDnRi.begin(); iter != sbt_OpogSmGCQ149nDnRi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TV0L_hPvCQwQCQm_QmONE5cI_nNTdCgVpYsmzCEIFyERC5R7zd7.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KINqCPj7699u_roummPniPC3amZ>::Type sbt_KINqCPj7699u_roummPniPC3amZArray;

