
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_V8NCIDRFyGs1mf_MwAH4EVs;
	CX::IO::SimpleBuffers::Int32Array sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT;
	CX::UInt64 sbt_Xr8SMskhPEj;
	CX::IO::SimpleBuffers::UInt64Array sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT;
	CX::Int8 sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96;
	CX::UInt64 sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy;
	CX::IO::SimpleBuffers::UInt16Array sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io;
	CX::IO::SimpleBuffers::StringArray sbt_roNHTDm1b8owr6p;
	CX::IO::SimpleBuffers::UInt32Array sbt_0LGPUGX8evZbuhqGfinaf;
	CX::IO::SimpleBuffers::UInt64Array sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY;
	CX::UInt64 sbt_pXIhyqn_NT8nfST;
	CX::IO::SimpleBuffers::Int16Array sbt_H_WnOU7cag2ZP6QoKwbjR;
	CX::Bool sbt_H4JilicsanH1B5CaXuB1aoqN0;
	CX::Int64 sbt_t239BNEoH;
	CX::Int64 sbt_WOMo9fbhZc1;
	CX::IO::SimpleBuffers::Int8Array sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst;
	CX::IO::SimpleBuffers::Int8Array sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI;
	CX::IO::SimpleBuffers::Int32Array sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi;
	CX::IO::SimpleBuffers::Int32Array sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU;
	CX::Int8 sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_;
	CX::IO::SimpleBuffers::UInt32Array sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ;
	CX::UInt32 sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0;

	virtual void Reset()
	{
		sbt_V8NCIDRFyGs1mf_MwAH4EVs = 0;
		sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.clear();
		sbt_Xr8SMskhPEj = 0;
		sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.clear();
		sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96 = 0;
		sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy = 0;
		sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.clear();
		sbt_roNHTDm1b8owr6p.clear();
		sbt_0LGPUGX8evZbuhqGfinaf.clear();
		sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.clear();
		sbt_pXIhyqn_NT8nfST = 0;
		sbt_H_WnOU7cag2ZP6QoKwbjR.clear();
		sbt_H4JilicsanH1B5CaXuB1aoqN0 = false;
		sbt_t239BNEoH = 0;
		sbt_WOMo9fbhZc1 = 0;
		sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.clear();
		sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.clear();
		sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.clear();
		sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.clear();
		sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_ = 0;
		sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.clear();
		sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_V8NCIDRFyGs1mf_MwAH4EVs = 16904020737001641580;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.push_back(-218471846);
		}
		sbt_Xr8SMskhPEj = 4559254344186850466;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.push_back(2558183898456737734);
		}
		sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96 = -93;
		sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy = 2655153438986136462;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.push_back(16303);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_roNHTDm1b8owr6p.push_back(":*\"#J:m+0Pa]]tM");
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_0LGPUGX8evZbuhqGfinaf.push_back(4262472450);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.push_back(5191896810463597608);
		}
		sbt_pXIhyqn_NT8nfST = 11896326110058099656;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_H_WnOU7cag2ZP6QoKwbjR.push_back(-26461);
		}
		sbt_H4JilicsanH1B5CaXuB1aoqN0 = true;
		sbt_t239BNEoH = -4661908954161697674;
		sbt_WOMo9fbhZc1 = -5449398414921597078;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.push_back(106);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.push_back(-124);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.push_back(871435630);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.push_back(761939494);
		}
		sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_ = 35;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.push_back(121423588);
		}
		sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0 = 2575448603;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o *pObject = dynamic_cast<const sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_V8NCIDRFyGs1mf_MwAH4EVs != pObject->sbt_V8NCIDRFyGs1mf_MwAH4EVs)
		{
			return false;
		}
		if (sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.size() != pObject->sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.size(); i++)
		{
			if (sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT[i] != pObject->sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT[i])
			{
				return false;
			}
		}
		if (sbt_Xr8SMskhPEj != pObject->sbt_Xr8SMskhPEj)
		{
			return false;
		}
		if (sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.size() != pObject->sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.size(); i++)
		{
			if (sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT[i] != pObject->sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT[i])
			{
				return false;
			}
		}
		if (sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96 != pObject->sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96)
		{
			return false;
		}
		if (sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy != pObject->sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy)
		{
			return false;
		}
		if (sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.size() != pObject->sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.size(); i++)
		{
			if (sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io[i] != pObject->sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io[i])
			{
				return false;
			}
		}
		if (sbt_roNHTDm1b8owr6p.size() != pObject->sbt_roNHTDm1b8owr6p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_roNHTDm1b8owr6p.size(); i++)
		{
			if (0 != cx_strcmp(sbt_roNHTDm1b8owr6p[i].c_str(), pObject->sbt_roNHTDm1b8owr6p[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_0LGPUGX8evZbuhqGfinaf.size() != pObject->sbt_0LGPUGX8evZbuhqGfinaf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0LGPUGX8evZbuhqGfinaf.size(); i++)
		{
			if (sbt_0LGPUGX8evZbuhqGfinaf[i] != pObject->sbt_0LGPUGX8evZbuhqGfinaf[i])
			{
				return false;
			}
		}
		if (sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.size() != pObject->sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.size(); i++)
		{
			if (sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY[i] != pObject->sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY[i])
			{
				return false;
			}
		}
		if (sbt_pXIhyqn_NT8nfST != pObject->sbt_pXIhyqn_NT8nfST)
		{
			return false;
		}
		if (sbt_H_WnOU7cag2ZP6QoKwbjR.size() != pObject->sbt_H_WnOU7cag2ZP6QoKwbjR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H_WnOU7cag2ZP6QoKwbjR.size(); i++)
		{
			if (sbt_H_WnOU7cag2ZP6QoKwbjR[i] != pObject->sbt_H_WnOU7cag2ZP6QoKwbjR[i])
			{
				return false;
			}
		}
		if (sbt_H4JilicsanH1B5CaXuB1aoqN0 != pObject->sbt_H4JilicsanH1B5CaXuB1aoqN0)
		{
			return false;
		}
		if (sbt_t239BNEoH != pObject->sbt_t239BNEoH)
		{
			return false;
		}
		if (sbt_WOMo9fbhZc1 != pObject->sbt_WOMo9fbhZc1)
		{
			return false;
		}
		if (sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.size() != pObject->sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.size(); i++)
		{
			if (sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst[i] != pObject->sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst[i])
			{
				return false;
			}
		}
		if (sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.size() != pObject->sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.size(); i++)
		{
			if (sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI[i] != pObject->sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI[i])
			{
				return false;
			}
		}
		if (sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.size() != pObject->sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.size(); i++)
		{
			if (sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi[i] != pObject->sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi[i])
			{
				return false;
			}
		}
		if (sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.size() != pObject->sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.size(); i++)
		{
			if (sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU[i] != pObject->sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU[i])
			{
				return false;
			}
		}
		if (sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_ != pObject->sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_)
		{
			return false;
		}
		if (sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.size() != pObject->sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.size(); i++)
		{
			if (sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ[i] != pObject->sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ[i])
			{
				return false;
			}
		}
		if (sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0 != pObject->sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_V8NCIDRFyGs1mf_MwAH4EVs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_V8NCIDRFyGs1mf_MwAH4EVs = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Xr8SMskhPEj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Xr8SMskhPEj = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_roNHTDm1b8owr6p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_roNHTDm1b8owr6p.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0LGPUGX8evZbuhqGfinaf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0LGPUGX8evZbuhqGfinaf.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pXIhyqn_NT8nfST", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pXIhyqn_NT8nfST = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_H_WnOU7cag2ZP6QoKwbjR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H_WnOU7cag2ZP6QoKwbjR.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_H4JilicsanH1B5CaXuB1aoqN0", &sbt_H4JilicsanH1B5CaXuB1aoqN0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t239BNEoH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t239BNEoH = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WOMo9fbhZc1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WOMo9fbhZc1 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0 = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_V8NCIDRFyGs1mf_MwAH4EVs", (CX::Int64)sbt_V8NCIDRFyGs1mf_MwAH4EVs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.begin(); iter != sbt_Nx2iFHIdennNrbRk_8R4qVQkHvhUUUbUIVt87qoANCqMLwBGVNK7TX8YT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Xr8SMskhPEj", (CX::Int64)sbt_Xr8SMskhPEj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.begin(); iter != sbt_ebt3tbb7Y7zrAE8md9DfrHmEhBf2wf4jzrl471DOQWu_2CfhjsFhjpFpqkT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96", (CX::Int64)sbt_A1IfIqT02uTelr_kJrID8_wa4a9j3Lm5BtOEmtaeSpjUUA0m_S1DA96)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy", (CX::Int64)sbt_n3_XuGBXXNDpyAlsZ0nhzptIbiwYq4Uw_oOcz23BUWPWy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.begin(); iter != sbt_FNMi89E1FTMhrN6ZNglQSPqGz4ZM3IFO3Io.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_roNHTDm1b8owr6p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_roNHTDm1b8owr6p.begin(); iter != sbt_roNHTDm1b8owr6p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0LGPUGX8evZbuhqGfinaf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0LGPUGX8evZbuhqGfinaf.begin(); iter != sbt_0LGPUGX8evZbuhqGfinaf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.begin(); iter != sbt_Ewepl08mNELmtOEvkjIo6JzIWC0oDJG6IsxrBwNjcoVbznY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pXIhyqn_NT8nfST", (CX::Int64)sbt_pXIhyqn_NT8nfST)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H_WnOU7cag2ZP6QoKwbjR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_H_WnOU7cag2ZP6QoKwbjR.begin(); iter != sbt_H_WnOU7cag2ZP6QoKwbjR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_H4JilicsanH1B5CaXuB1aoqN0", sbt_H4JilicsanH1B5CaXuB1aoqN0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t239BNEoH", (CX::Int64)sbt_t239BNEoH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WOMo9fbhZc1", (CX::Int64)sbt_WOMo9fbhZc1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.begin(); iter != sbt_eCOj0abRnrPL7sd1u3eloEvAG7kXzuVst.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.begin(); iter != sbt_X0yxJtiGNig7lceuzI58tbt7a7C7zLrBAKlvrV4JKnQTPtI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.begin(); iter != sbt_3I6JPUZk91ZxU9ZVLMG7Dxb8774CBxHaQCbb7yxhJuoGRqi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.begin(); iter != sbt_KTEfgJYrWwknCti0jykGROPJy5dOQewUN_e_psYeUr_gqpZP9EU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_", (CX::Int64)sbt_FRFdeD02WoxPN6RhJfPPwPFw2LYtxdMgqMYQv4LmaP1vjjgeEibdSPwm_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.begin(); iter != sbt_h6v3dBpNJfDCuj_ZdAw6dL6yvMfE2H5QbIQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0", (CX::Int64)sbt_nkc6SmilhbHFR8GePOwFSG0JP3ZAcW0)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o>::Type sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8oArray;

