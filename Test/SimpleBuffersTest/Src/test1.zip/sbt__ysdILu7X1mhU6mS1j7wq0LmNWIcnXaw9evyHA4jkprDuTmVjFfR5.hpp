
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj.hpp"


class sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_2IBIZM6B7_NQJUq2ahkRy6zkp;
	CX::WString sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx;
	sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqjArray sbt_ya7EgWiLh9Zoqx3OE_eAH;

	virtual void Reset()
	{
		sbt_2IBIZM6B7_NQJUq2ahkRy6zkp = 0;
		sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx.clear();
		sbt_ya7EgWiLh9Zoqx3OE_eAH.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_2IBIZM6B7_NQJUq2ahkRy6zkp = 234;
		sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx = L"3q?.U'IN`Zm{'5j[Z_9*][M,VcDr";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj v;

			v.SetupWithSomeValues();
			sbt_ya7EgWiLh9Zoqx3OE_eAH.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5 *pObject = dynamic_cast<const sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_2IBIZM6B7_NQJUq2ahkRy6zkp != pObject->sbt_2IBIZM6B7_NQJUq2ahkRy6zkp)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx.c_str(), pObject->sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx.c_str()))
		{
			return false;
		}
		if (sbt_ya7EgWiLh9Zoqx3OE_eAH.size() != pObject->sbt_ya7EgWiLh9Zoqx3OE_eAH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ya7EgWiLh9Zoqx3OE_eAH.size(); i++)
		{
			if (!sbt_ya7EgWiLh9Zoqx3OE_eAH[i].Compare(&pObject->sbt_ya7EgWiLh9Zoqx3OE_eAH[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_2IBIZM6B7_NQJUq2ahkRy6zkp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2IBIZM6B7_NQJUq2ahkRy6zkp = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx", &sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ya7EgWiLh9Zoqx3OE_eAH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_ya7EgWiLh9Zoqx3OE_eAH.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_2IBIZM6B7_NQJUq2ahkRy6zkp", (CX::Int64)sbt_2IBIZM6B7_NQJUq2ahkRy6zkp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx", sbt_Vbv1XUjruy30f24ZPVgzZDceX0i0_G2ShoOr_DSRiRigx.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ya7EgWiLh9Zoqx3OE_eAH")).IsNOK())
		{
			return status;
		}
		for (sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqjArray::const_iterator iter = sbt_ya7EgWiLh9Zoqx3OE_eAH.begin(); iter != sbt_ya7EgWiLh9Zoqx3OE_eAH.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5>::Type sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5Array;

