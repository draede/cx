
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o.hpp"


class sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::DoubleArray sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu;
	CX::UInt8 sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg;
	CX::UInt32 sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2;
	CX::Double sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv;
	CX::IO::SimpleBuffers::UInt16Array sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI;
	CX::WString sbt_th91EokPsdIEc;
	CX::IO::SimpleBuffers::StringArray sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR;
	CX::IO::SimpleBuffers::Int32Array sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm;
	sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ;

	virtual void Reset()
	{
		sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.clear();
		sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg = 0;
		sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2 = 0;
		sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv = 0.0;
		sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.clear();
		sbt_th91EokPsdIEc.clear();
		sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.clear();
		sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.clear();
		sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.push_back(0.188115);
		}
		sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg = 5;
		sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2 = 3183181226;
		sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv = 0.333753;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.push_back(57331);
		}
		sbt_th91EokPsdIEc = L"%zqb:s<";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.push_back("%BOB/#E{Y\"?P#IE18!0-a5}\\Ug)hYyiYb{CP\".cOiktG|v)?)O4");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.push_back(-42609248);
		}
		sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX *pObject = dynamic_cast<const sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.size() != pObject->sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.size(); i++)
		{
			if (sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu[i] != pObject->sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu[i])
			{
				return false;
			}
		}
		if (sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg != pObject->sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg)
		{
			return false;
		}
		if (sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2 != pObject->sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2)
		{
			return false;
		}
		if (sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv != pObject->sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv)
		{
			return false;
		}
		if (sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.size() != pObject->sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.size(); i++)
		{
			if (sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI[i] != pObject->sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_th91EokPsdIEc.c_str(), pObject->sbt_th91EokPsdIEc.c_str()))
		{
			return false;
		}
		if (sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.size() != pObject->sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.size(); i++)
		{
			if (0 != cx_strcmp(sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR[i].c_str(), pObject->sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.size() != pObject->sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.size(); i++)
		{
			if (sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm[i] != pObject->sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm[i])
			{
				return false;
			}
		}
		if (!sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ.Compare(&pObject->sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_th91EokPsdIEc", &sbt_th91EokPsdIEc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.begin(); iter != sbt_x6jsum5ehROCq4KEOxJBjJZyF8nv7AEuu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg", (CX::Int64)sbt_pcZTdUDRhfXbEjKSXZempuOC21Dvg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2", (CX::Int64)sbt_N0Gj_6NIqz1TJQwXCDf9LxJwf7jdKaK7J5KxRijxiMYoeRIc0DwRuvDfNbNQra2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv", (CX::Double)sbt_yqN4XyJfgUii3NBAWtqismE38WfIDzXKiWbr3GNDdwoI5GofmGbZHUgXPhv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.begin(); iter != sbt_rQ9XEMCndIY5zGnVlERSamd3jbUQ6vI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_th91EokPsdIEc", sbt_th91EokPsdIEc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.begin(); iter != sbt_0bAdhuS7PKpZmziBxJW7ujVJ8j34bSDmR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.begin(); iter != sbt_tO26GruyCnken51aoO2OtJeTq6VZlUGojxxByfsG3j0C05HHKg9kDkDUEeWUrCm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_vyjBzNxhKriH5r95DMGARbmkxbRbZ.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX>::Type sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxXArray;

