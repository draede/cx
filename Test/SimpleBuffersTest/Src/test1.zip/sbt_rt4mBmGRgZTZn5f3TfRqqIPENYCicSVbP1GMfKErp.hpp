
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH.hpp"


class sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_g1OI1TpHvtQQ8OBhuRFYT;
	CX::IO::SimpleBuffers::Int32Array sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83;
	CX::UInt8 sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7;
	CX::IO::SimpleBuffers::StringArray sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V;
	CX::Int16 sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC;
	CX::IO::SimpleBuffers::StringArray sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1;
	CX::IO::SimpleBuffers::Int16Array sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC;
	CX::IO::SimpleBuffers::Int32Array sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9;
	CX::Bool sbt_w8ogn1DCfj92aD5pr;
	CX::Int8 sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI;
	CX::IO::SimpleBuffers::Int8Array sbt_t3xDrng5dgAvUk0sJHoQDotpXC6;
	CX::IO::SimpleBuffers::UInt64Array sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD;
	CX::IO::SimpleBuffers::UInt16Array sbt_9JJUPdotl3uocPU;
	CX::IO::SimpleBuffers::UInt16Array sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA;
	CX::IO::SimpleBuffers::Int8Array sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf;
	CX::UInt8 sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw;
	CX::IO::SimpleBuffers::Int32Array sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW;
	CX::IO::SimpleBuffers::Int16Array sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S;
	CX::IO::SimpleBuffers::Int32Array sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG;
	CX::UInt16 sbt_f;
	CX::String sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp;
	CX::IO::SimpleBuffers::Int64Array sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF;
	CX::Int8 sbt_35lNi_lqv7drHyfcg6p;
	CX::UInt64 sbt_LZrGUyewpBUYHZ4rbztlW3cDm;
	sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzHArray sbt_jP4xk0uBomy;

	virtual void Reset()
	{
		sbt_g1OI1TpHvtQQ8OBhuRFYT = 0;
		sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.clear();
		sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7 = 0;
		sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.clear();
		sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC = 0;
		sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.clear();
		sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.clear();
		sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.clear();
		sbt_w8ogn1DCfj92aD5pr = false;
		sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI = 0;
		sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.clear();
		sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.clear();
		sbt_9JJUPdotl3uocPU.clear();
		sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.clear();
		sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.clear();
		sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw = 0;
		sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.clear();
		sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.clear();
		sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.clear();
		sbt_f = 0;
		sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp.clear();
		sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.clear();
		sbt_35lNi_lqv7drHyfcg6p = 0;
		sbt_LZrGUyewpBUYHZ4rbztlW3cDm = 0;
		sbt_jP4xk0uBomy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_g1OI1TpHvtQQ8OBhuRFYT = 11950413958918842012;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.push_back(655496816);
		}
		sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7 = 182;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.push_back("");
		}
		sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC = -11448;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.push_back("xucPujWRqDa0AK@0`|]]_AiA~b|U_r$5y6y9z#Z[|5Lx");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.push_back(11371);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.push_back(908995505);
		}
		sbt_w8ogn1DCfj92aD5pr = true;
		sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI = 44;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.push_back(-114);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.push_back(13767977515831178668);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_9JJUPdotl3uocPU.push_back(47625);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.push_back(46017);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.push_back(-9);
		}
		sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw = 44;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.push_back(-1357822808);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.push_back(1084116224);
		}
		sbt_f = 54479;
		sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp = "glLR$QF8V%=;:umfYtaiJ3|3nc0^:,6.Oc|t|o&N#Q2{c?$j^WP%q1";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.push_back(-2472842144092364926);
		}
		sbt_35lNi_lqv7drHyfcg6p = -126;
		sbt_LZrGUyewpBUYHZ4rbztlW3cDm = 12515333022205031072;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH v;

			v.SetupWithSomeValues();
			sbt_jP4xk0uBomy.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp *pObject = dynamic_cast<const sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_g1OI1TpHvtQQ8OBhuRFYT != pObject->sbt_g1OI1TpHvtQQ8OBhuRFYT)
		{
			return false;
		}
		if (sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.size() != pObject->sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.size(); i++)
		{
			if (sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83[i] != pObject->sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83[i])
			{
				return false;
			}
		}
		if (sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7 != pObject->sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7)
		{
			return false;
		}
		if (sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.size() != pObject->sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.size(); i++)
		{
			if (0 != cx_strcmp(sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V[i].c_str(), pObject->sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC != pObject->sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC)
		{
			return false;
		}
		if (sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.size() != pObject->sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.size(); i++)
		{
			if (0 != cx_strcmp(sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1[i].c_str(), pObject->sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.size() != pObject->sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.size(); i++)
		{
			if (sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC[i] != pObject->sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC[i])
			{
				return false;
			}
		}
		if (sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.size() != pObject->sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.size(); i++)
		{
			if (sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9[i] != pObject->sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9[i])
			{
				return false;
			}
		}
		if (sbt_w8ogn1DCfj92aD5pr != pObject->sbt_w8ogn1DCfj92aD5pr)
		{
			return false;
		}
		if (sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI != pObject->sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI)
		{
			return false;
		}
		if (sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.size() != pObject->sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.size(); i++)
		{
			if (sbt_t3xDrng5dgAvUk0sJHoQDotpXC6[i] != pObject->sbt_t3xDrng5dgAvUk0sJHoQDotpXC6[i])
			{
				return false;
			}
		}
		if (sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.size() != pObject->sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.size(); i++)
		{
			if (sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD[i] != pObject->sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD[i])
			{
				return false;
			}
		}
		if (sbt_9JJUPdotl3uocPU.size() != pObject->sbt_9JJUPdotl3uocPU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9JJUPdotl3uocPU.size(); i++)
		{
			if (sbt_9JJUPdotl3uocPU[i] != pObject->sbt_9JJUPdotl3uocPU[i])
			{
				return false;
			}
		}
		if (sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.size() != pObject->sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.size(); i++)
		{
			if (sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA[i] != pObject->sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA[i])
			{
				return false;
			}
		}
		if (sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.size() != pObject->sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.size(); i++)
		{
			if (sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf[i] != pObject->sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf[i])
			{
				return false;
			}
		}
		if (sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw != pObject->sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw)
		{
			return false;
		}
		if (sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.size() != pObject->sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.size(); i++)
		{
			if (sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW[i] != pObject->sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW[i])
			{
				return false;
			}
		}
		if (sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.size() != pObject->sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.size(); i++)
		{
			if (sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S[i] != pObject->sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S[i])
			{
				return false;
			}
		}
		if (sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.size() != pObject->sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.size(); i++)
		{
			if (sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG[i] != pObject->sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG[i])
			{
				return false;
			}
		}
		if (sbt_f != pObject->sbt_f)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp.c_str(), pObject->sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp.c_str()))
		{
			return false;
		}
		if (sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.size() != pObject->sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.size(); i++)
		{
			if (sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF[i] != pObject->sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF[i])
			{
				return false;
			}
		}
		if (sbt_35lNi_lqv7drHyfcg6p != pObject->sbt_35lNi_lqv7drHyfcg6p)
		{
			return false;
		}
		if (sbt_LZrGUyewpBUYHZ4rbztlW3cDm != pObject->sbt_LZrGUyewpBUYHZ4rbztlW3cDm)
		{
			return false;
		}
		if (sbt_jP4xk0uBomy.size() != pObject->sbt_jP4xk0uBomy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jP4xk0uBomy.size(); i++)
		{
			if (!sbt_jP4xk0uBomy[i].Compare(&pObject->sbt_jP4xk0uBomy[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_g1OI1TpHvtQQ8OBhuRFYT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_g1OI1TpHvtQQ8OBhuRFYT = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_w8ogn1DCfj92aD5pr", &sbt_w8ogn1DCfj92aD5pr)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_t3xDrng5dgAvUk0sJHoQDotpXC6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9JJUPdotl3uocPU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9JJUPdotl3uocPU.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_f", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_f = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp", &sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_35lNi_lqv7drHyfcg6p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_35lNi_lqv7drHyfcg6p = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LZrGUyewpBUYHZ4rbztlW3cDm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LZrGUyewpBUYHZ4rbztlW3cDm = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jP4xk0uBomy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_jP4xk0uBomy.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_g1OI1TpHvtQQ8OBhuRFYT", (CX::Int64)sbt_g1OI1TpHvtQQ8OBhuRFYT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.begin(); iter != sbt_trerzGZXlHOjHbFp6Uto_ayTyLKERau9vxiOzfa7TF7Zplq83.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7", (CX::Int64)sbt_iz37BAUqUqhnoxDrobI0L1jlCsKurZx61sg06wXdJRp9leFkOfBi7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.begin(); iter != sbt_7hZ6gCn1Ayy2Bhgy44d3LdDl7cVvYpgrXDCF4Ro4V.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC", (CX::Int64)sbt_lYdRGW9GuaPD54QFxmOh6plEguugTX0ASNKUC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.begin(); iter != sbt_GmW2C_HStNrP6p779q3NdWY0CWmJ1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.begin(); iter != sbt_2FxoxvqXFe0k6Uxd3PZXYZQ3kNjQpjQOp_UrC3_JOtgIvlLsQEbBC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.begin(); iter != sbt_Wj4bD876qIaDXBKVPhGa3PTo09AwEt5c9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_w8ogn1DCfj92aD5pr", sbt_w8ogn1DCfj92aD5pr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI", (CX::Int64)sbt_RhPB_Hy2cGDdPnTy2a3QmJZLiSFdXtOWvvFoI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t3xDrng5dgAvUk0sJHoQDotpXC6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.begin(); iter != sbt_t3xDrng5dgAvUk0sJHoQDotpXC6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.begin(); iter != sbt_GbvTVvomWB8CHTbyuEV__dBo4lXQFJsu2vEV_k8Lj_RnxAD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9JJUPdotl3uocPU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9JJUPdotl3uocPU.begin(); iter != sbt_9JJUPdotl3uocPU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.begin(); iter != sbt_5IlJxjvwXNSZkXQ_YfHOiJqhsVjrnpim1LycG0sdA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.begin(); iter != sbt_QRDriPmf5xT69DCk7eZPVTKVoxktfT0vYOdXatoGLEf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw", (CX::Int64)sbt_SFye6V0VJLPxWoT0lq2P2ojBbjlNGd5BA3Ab5hIc7TYYxqVYrsQ0rY8dw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.begin(); iter != sbt_2BdWZ3dwH18YxzHQDSTBcIjw963zW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.begin(); iter != sbt_rwZwEb2oCTc4tBICMEm74Yp7zSmlZKTB_qC3OpNu76S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.begin(); iter != sbt_oA_EJBzqkMynoB8R2VMroiuj63fCZtmj2fR49KnQG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_f", (CX::Int64)sbt_f)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp", sbt_DoFTGk2KjZZAf3IlauQqkNW11JveEPegHjuwBzM4d3Mi_CZ4Itp.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.begin(); iter != sbt_Cp1GIh5JHq6B2zLXeclHwrPmL963dPF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_35lNi_lqv7drHyfcg6p", (CX::Int64)sbt_35lNi_lqv7drHyfcg6p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LZrGUyewpBUYHZ4rbztlW3cDm", (CX::Int64)sbt_LZrGUyewpBUYHZ4rbztlW3cDm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jP4xk0uBomy")).IsNOK())
		{
			return status;
		}
		for (sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzHArray::const_iterator iter = sbt_jP4xk0uBomy.begin(); iter != sbt_jP4xk0uBomy.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp>::Type sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErpArray;

