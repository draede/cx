
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_Z;
	CX::IO::SimpleBuffers::UInt8Array sbt_gG3jWBSYF3ZzGI_baTv;
	CX::UInt64 sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL;

	virtual void Reset()
	{
		sbt_Z.clear();
		sbt_gG3jWBSYF3ZzGI_baTv.clear();
		sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Z.push_back(6915903980721799386);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_gG3jWBSYF3ZzGI_baTv.push_back(75);
		}
		sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL = 4518199018763021520;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP *pObject = dynamic_cast<const sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Z.size() != pObject->sbt_Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z.size(); i++)
		{
			if (sbt_Z[i] != pObject->sbt_Z[i])
			{
				return false;
			}
		}
		if (sbt_gG3jWBSYF3ZzGI_baTv.size() != pObject->sbt_gG3jWBSYF3ZzGI_baTv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gG3jWBSYF3ZzGI_baTv.size(); i++)
		{
			if (sbt_gG3jWBSYF3ZzGI_baTv[i] != pObject->sbt_gG3jWBSYF3ZzGI_baTv[i])
			{
				return false;
			}
		}
		if (sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL != pObject->sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gG3jWBSYF3ZzGI_baTv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gG3jWBSYF3ZzGI_baTv.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Z.begin(); iter != sbt_Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gG3jWBSYF3ZzGI_baTv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_gG3jWBSYF3ZzGI_baTv.begin(); iter != sbt_gG3jWBSYF3ZzGI_baTv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL", (CX::Int64)sbt_F_FR0J3LIVbz7S25Lcc2sQ8a9baadkL)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP>::Type sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaPArray;

