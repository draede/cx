
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ.hpp"


class sbt_ebD2YgyqSIxzwq4eQrvNF : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_BZQrqG7C1QHlMzek4LPGJ;
	CX::IO::SimpleBuffers::StringArray sbt_9ET6nBy61l92RQfGuKK3wHc;
	CX::IO::SimpleBuffers::Int8Array sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh;
	CX::IO::SimpleBuffers::Int64Array sbt_2QMwLo_xvTLwrlShW;
	CX::Int64 sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ;
	CX::IO::SimpleBuffers::UInt8Array sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio;
	CX::IO::SimpleBuffers::StringArray sbt_vbvIunm3ZdWozXriQ;
	CX::WString sbt_bRF;
	CX::UInt16 sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl;
	CX::UInt8 sbt_CWMVc;
	sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJArray sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU;

	virtual void Reset()
	{
		sbt_BZQrqG7C1QHlMzek4LPGJ = 0;
		sbt_9ET6nBy61l92RQfGuKK3wHc.clear();
		sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.clear();
		sbt_2QMwLo_xvTLwrlShW.clear();
		sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ = 0;
		sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.clear();
		sbt_vbvIunm3ZdWozXriQ.clear();
		sbt_bRF.clear();
		sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl = 0;
		sbt_CWMVc = 0;
		sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_BZQrqG7C1QHlMzek4LPGJ = 120;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_9ET6nBy61l92RQfGuKK3wHc.push_back("oWD!!DMHS");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.push_back(-31);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_2QMwLo_xvTLwrlShW.push_back(-7520112991652231494);
		}
		sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ = -5272588572779877044;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.push_back(141);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_vbvIunm3ZdWozXriQ.push_back("BnCUbL\\yWWE05[AQ9uMm*#<?h_@OD)[^hDiiAw;t,yL$/X'Z\\L<)tc7u4");
		}
		sbt_bRF = L"ET8mPattx,S:VJ5O_v@F/GKx/;";
		sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl = 2748;
		sbt_CWMVc = 186;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ v;

			v.SetupWithSomeValues();
			sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ebD2YgyqSIxzwq4eQrvNF *pObject = dynamic_cast<const sbt_ebD2YgyqSIxzwq4eQrvNF *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_BZQrqG7C1QHlMzek4LPGJ != pObject->sbt_BZQrqG7C1QHlMzek4LPGJ)
		{
			return false;
		}
		if (sbt_9ET6nBy61l92RQfGuKK3wHc.size() != pObject->sbt_9ET6nBy61l92RQfGuKK3wHc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9ET6nBy61l92RQfGuKK3wHc.size(); i++)
		{
			if (0 != cx_strcmp(sbt_9ET6nBy61l92RQfGuKK3wHc[i].c_str(), pObject->sbt_9ET6nBy61l92RQfGuKK3wHc[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.size() != pObject->sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.size(); i++)
		{
			if (sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh[i] != pObject->sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh[i])
			{
				return false;
			}
		}
		if (sbt_2QMwLo_xvTLwrlShW.size() != pObject->sbt_2QMwLo_xvTLwrlShW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2QMwLo_xvTLwrlShW.size(); i++)
		{
			if (sbt_2QMwLo_xvTLwrlShW[i] != pObject->sbt_2QMwLo_xvTLwrlShW[i])
			{
				return false;
			}
		}
		if (sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ != pObject->sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ)
		{
			return false;
		}
		if (sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.size() != pObject->sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.size(); i++)
		{
			if (sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio[i] != pObject->sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio[i])
			{
				return false;
			}
		}
		if (sbt_vbvIunm3ZdWozXriQ.size() != pObject->sbt_vbvIunm3ZdWozXriQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vbvIunm3ZdWozXriQ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_vbvIunm3ZdWozXriQ[i].c_str(), pObject->sbt_vbvIunm3ZdWozXriQ[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_bRF.c_str(), pObject->sbt_bRF.c_str()))
		{
			return false;
		}
		if (sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl != pObject->sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl)
		{
			return false;
		}
		if (sbt_CWMVc != pObject->sbt_CWMVc)
		{
			return false;
		}
		if (sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.size() != pObject->sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.size(); i++)
		{
			if (!sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU[i].Compare(&pObject->sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_BZQrqG7C1QHlMzek4LPGJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BZQrqG7C1QHlMzek4LPGJ = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9ET6nBy61l92RQfGuKK3wHc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9ET6nBy61l92RQfGuKK3wHc.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2QMwLo_xvTLwrlShW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2QMwLo_xvTLwrlShW.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vbvIunm3ZdWozXriQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vbvIunm3ZdWozXriQ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_bRF", &sbt_bRF)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_CWMVc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CWMVc = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_BZQrqG7C1QHlMzek4LPGJ", (CX::Int64)sbt_BZQrqG7C1QHlMzek4LPGJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9ET6nBy61l92RQfGuKK3wHc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_9ET6nBy61l92RQfGuKK3wHc.begin(); iter != sbt_9ET6nBy61l92RQfGuKK3wHc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.begin(); iter != sbt_NgDgJLbtaSx14Odk02BAW3U7vLu3TyxnFgGY0rV_FsehSIqeh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2QMwLo_xvTLwrlShW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_2QMwLo_xvTLwrlShW.begin(); iter != sbt_2QMwLo_xvTLwrlShW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ", (CX::Int64)sbt_v2LV4u2GV3ZGN1lihEoSbMbQQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.begin(); iter != sbt_cS0hgaZTbuEh2qMN6jQxcquV2mMj13jWLWTS75w6aHm7xOFio.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vbvIunm3ZdWozXriQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_vbvIunm3ZdWozXriQ.begin(); iter != sbt_vbvIunm3ZdWozXriQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_bRF", sbt_bRF.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl", (CX::Int64)sbt__gXnZTzqXuFG9Gh0xRmikBdidxoEzB3_RROScNS8vJUTl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CWMVc", (CX::Int64)sbt_CWMVc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU")).IsNOK())
		{
			return status;
		}
		for (sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJArray::const_iterator iter = sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.begin(); iter != sbt_YoelwNnG0yPlR1EeYtc2LB9tX4nNU.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ebD2YgyqSIxzwq4eQrvNF>::Type sbt_ebD2YgyqSIxzwq4eQrvNFArray;

