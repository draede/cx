
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf.hpp"


class sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_RHUf4_K_4rpdWGyuW8s5sa8;
	CX::UInt32 sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws;
	CX::WString sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL;
	CX::IO::SimpleBuffers::BoolArray sbt_tsBTbxLGMfFne;
	CX::IO::SimpleBuffers::UInt8Array sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM;
	CX::IO::SimpleBuffers::UInt64Array sbt_n8_BwQMQNI87saEPe;
	CX::Double sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo;
	CX::IO::SimpleBuffers::UInt64Array sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_;
	CX::IO::SimpleBuffers::Int32Array sbt_M;
	CX::UInt32 sbt_wMeGTpEoeq1fPaTuYxr;
	CX::UInt64 sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW;
	CX::UInt64 sbt_eaFqJ7oDm_fRkhe;
	CX::Int8 sbt_b2cmL6X_e;
	CX::Int8 sbt_MXhMCq_rpmtt5;
	CX::UInt32 sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW;
	CX::IO::SimpleBuffers::Int32Array sbt_uCu;
	CX::Bool sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh;
	CX::Int8 sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc;
	sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlfArray sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb;

	virtual void Reset()
	{
		sbt_RHUf4_K_4rpdWGyuW8s5sa8.clear();
		sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws = 0;
		sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL.clear();
		sbt_tsBTbxLGMfFne.clear();
		sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.clear();
		sbt_n8_BwQMQNI87saEPe.clear();
		sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo = 0.0;
		sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.clear();
		sbt_M.clear();
		sbt_wMeGTpEoeq1fPaTuYxr = 0;
		sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW = 0;
		sbt_eaFqJ7oDm_fRkhe = 0;
		sbt_b2cmL6X_e = 0;
		sbt_MXhMCq_rpmtt5 = 0;
		sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW = 0;
		sbt_uCu.clear();
		sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh = false;
		sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc = 0;
		sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_RHUf4_K_4rpdWGyuW8s5sa8.push_back(172);
		}
		sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws = 2583094032;
		sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL = L"\\yp_X3O348N!(p`(@V1#?9V(x5ty8n%+j<-v6og'y$;t\"w00exxo";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_tsBTbxLGMfFne.push_back(false);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.push_back(209);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_n8_BwQMQNI87saEPe.push_back(4822588489560749444);
		}
		sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo = 0.014787;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.push_back(17791505580577223432);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_M.push_back(987905983);
		}
		sbt_wMeGTpEoeq1fPaTuYxr = 3069488473;
		sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW = 13745133694121421100;
		sbt_eaFqJ7oDm_fRkhe = 16378374476839707542;
		sbt_b2cmL6X_e = -44;
		sbt_MXhMCq_rpmtt5 = -75;
		sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW = 1637758676;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_uCu.push_back(1081812637);
		}
		sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh = false;
		sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc = -87;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf v;

			v.SetupWithSomeValues();
			sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb *pObject = dynamic_cast<const sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_RHUf4_K_4rpdWGyuW8s5sa8.size() != pObject->sbt_RHUf4_K_4rpdWGyuW8s5sa8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RHUf4_K_4rpdWGyuW8s5sa8.size(); i++)
		{
			if (sbt_RHUf4_K_4rpdWGyuW8s5sa8[i] != pObject->sbt_RHUf4_K_4rpdWGyuW8s5sa8[i])
			{
				return false;
			}
		}
		if (sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws != pObject->sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL.c_str(), pObject->sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL.c_str()))
		{
			return false;
		}
		if (sbt_tsBTbxLGMfFne.size() != pObject->sbt_tsBTbxLGMfFne.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tsBTbxLGMfFne.size(); i++)
		{
			if (sbt_tsBTbxLGMfFne[i] != pObject->sbt_tsBTbxLGMfFne[i])
			{
				return false;
			}
		}
		if (sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.size() != pObject->sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.size(); i++)
		{
			if (sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM[i] != pObject->sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM[i])
			{
				return false;
			}
		}
		if (sbt_n8_BwQMQNI87saEPe.size() != pObject->sbt_n8_BwQMQNI87saEPe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n8_BwQMQNI87saEPe.size(); i++)
		{
			if (sbt_n8_BwQMQNI87saEPe[i] != pObject->sbt_n8_BwQMQNI87saEPe[i])
			{
				return false;
			}
		}
		if (sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo != pObject->sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo)
		{
			return false;
		}
		if (sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.size() != pObject->sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.size(); i++)
		{
			if (sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_[i] != pObject->sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_[i])
			{
				return false;
			}
		}
		if (sbt_M.size() != pObject->sbt_M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M.size(); i++)
		{
			if (sbt_M[i] != pObject->sbt_M[i])
			{
				return false;
			}
		}
		if (sbt_wMeGTpEoeq1fPaTuYxr != pObject->sbt_wMeGTpEoeq1fPaTuYxr)
		{
			return false;
		}
		if (sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW != pObject->sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW)
		{
			return false;
		}
		if (sbt_eaFqJ7oDm_fRkhe != pObject->sbt_eaFqJ7oDm_fRkhe)
		{
			return false;
		}
		if (sbt_b2cmL6X_e != pObject->sbt_b2cmL6X_e)
		{
			return false;
		}
		if (sbt_MXhMCq_rpmtt5 != pObject->sbt_MXhMCq_rpmtt5)
		{
			return false;
		}
		if (sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW != pObject->sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW)
		{
			return false;
		}
		if (sbt_uCu.size() != pObject->sbt_uCu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uCu.size(); i++)
		{
			if (sbt_uCu[i] != pObject->sbt_uCu[i])
			{
				return false;
			}
		}
		if (sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh != pObject->sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh)
		{
			return false;
		}
		if (sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc != pObject->sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc)
		{
			return false;
		}
		if (sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.size() != pObject->sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.size(); i++)
		{
			if (!sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb[i].Compare(&pObject->sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_RHUf4_K_4rpdWGyuW8s5sa8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RHUf4_K_4rpdWGyuW8s5sa8.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectWString("sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL", &sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tsBTbxLGMfFne")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tsBTbxLGMfFne.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n8_BwQMQNI87saEPe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n8_BwQMQNI87saEPe.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wMeGTpEoeq1fPaTuYxr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wMeGTpEoeq1fPaTuYxr = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eaFqJ7oDm_fRkhe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eaFqJ7oDm_fRkhe = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_b2cmL6X_e", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b2cmL6X_e = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MXhMCq_rpmtt5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MXhMCq_rpmtt5 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uCu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uCu.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh", &sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_RHUf4_K_4rpdWGyuW8s5sa8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_RHUf4_K_4rpdWGyuW8s5sa8.begin(); iter != sbt_RHUf4_K_4rpdWGyuW8s5sa8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws", (CX::Int64)sbt_UCoZK_tO2BEtXRs7ASR3QWZ02ulV0Nj0AdUSyJttCXNL4Ws)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL", sbt_0WiRdiek7nBmq5mhin7_wYO9POdWJQUUL.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tsBTbxLGMfFne")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_tsBTbxLGMfFne.begin(); iter != sbt_tsBTbxLGMfFne.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.begin(); iter != sbt_4EaKjwXDGmmzAMZhuUajYypgyRW9fjGY2FNOdY2V8suxM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n8_BwQMQNI87saEPe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_n8_BwQMQNI87saEPe.begin(); iter != sbt_n8_BwQMQNI87saEPe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo", (CX::Double)sbt_kmA1htSV4FK1LOa3RaAxERThlb_O_rap514NVmLXHbzZVs0J2exmG2fEo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.begin(); iter != sbt_GCTkvmonm_mF9frc98zqk_fKUZ0_sl_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_M.begin(); iter != sbt_M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wMeGTpEoeq1fPaTuYxr", (CX::Int64)sbt_wMeGTpEoeq1fPaTuYxr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW", (CX::Int64)sbt_LYx2djEWFRpxjXm9DxLqAYCC8yPL2r46Y100njbTwm6c_9k_xtBMCaTGmyaf_JW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eaFqJ7oDm_fRkhe", (CX::Int64)sbt_eaFqJ7oDm_fRkhe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b2cmL6X_e", (CX::Int64)sbt_b2cmL6X_e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MXhMCq_rpmtt5", (CX::Int64)sbt_MXhMCq_rpmtt5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW", (CX::Int64)sbt_Zv_qX4g2ixO3gvaKT8z9McjoXuqjxblT5Fg6taemW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uCu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_uCu.begin(); iter != sbt_uCu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh", sbt_rjVoeTqZVblYDaKy3m_Xvg_vYzGTiIRTA_jTj7OAkZh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc", (CX::Int64)sbt_2aKY7BakzBmedaG7TrlKSqz9BQjgGXRkcdc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb")).IsNOK())
		{
			return status;
		}
		for (sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlfArray::const_iterator iter = sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.begin(); iter != sbt_8EV2Op0hWm1tTWYr_chabxpDH9H_yqrwDvmRb.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb>::Type sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrbArray;

