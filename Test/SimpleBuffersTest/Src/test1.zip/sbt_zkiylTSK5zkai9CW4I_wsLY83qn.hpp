
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka.hpp"


class sbt_zkiylTSK5zkai9CW4I_wsLY83qn : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_RPToi3Z3RnmG2eNfjRKRNol;
	sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU;

	virtual void Reset()
	{
		sbt_RPToi3Z3RnmG2eNfjRKRNol = 0;
		sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_RPToi3Z3RnmG2eNfjRKRNol = 3432742696;
		sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zkiylTSK5zkai9CW4I_wsLY83qn *pObject = dynamic_cast<const sbt_zkiylTSK5zkai9CW4I_wsLY83qn *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_RPToi3Z3RnmG2eNfjRKRNol != pObject->sbt_RPToi3Z3RnmG2eNfjRKRNol)
		{
			return false;
		}
		if (!sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU.Compare(&pObject->sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_RPToi3Z3RnmG2eNfjRKRNol", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RPToi3Z3RnmG2eNfjRKRNol = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_RPToi3Z3RnmG2eNfjRKRNol", (CX::Int64)sbt_RPToi3Z3RnmG2eNfjRKRNol)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_P6xyRxaGUIt4uihMVuHiHO27MeqWNVkA2HL6X5zSsDU.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zkiylTSK5zkai9CW4I_wsLY83qn>::Type sbt_zkiylTSK5zkai9CW4I_wsLY83qnArray;

