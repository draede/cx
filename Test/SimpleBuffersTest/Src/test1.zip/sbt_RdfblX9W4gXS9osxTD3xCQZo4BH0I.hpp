
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR;
	CX::UInt32 sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7;
	CX::UInt32 sbt_wnlotcruZBvl1OuRuxXag;
	CX::IO::SimpleBuffers::StringArray sbt_kvbMWgllUQ96ZpxfYK4Dd16;
	CX::UInt16 sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD;
	CX::IO::SimpleBuffers::Int16Array sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA;
	CX::IO::SimpleBuffers::UInt32Array sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV;

	virtual void Reset()
	{
		sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR = 0;
		sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7 = 0;
		sbt_wnlotcruZBvl1OuRuxXag = 0;
		sbt_kvbMWgllUQ96ZpxfYK4Dd16.clear();
		sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD = 0;
		sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.clear();
		sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR = 2942872056274636462;
		sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7 = 1551124648;
		sbt_wnlotcruZBvl1OuRuxXag = 1011090515;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_kvbMWgllUQ96ZpxfYK4Dd16.push_back("R't");
		}
		sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD = 23520;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.push_back(-21739);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.push_back(4108658696);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I *pObject = dynamic_cast<const sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR != pObject->sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR)
		{
			return false;
		}
		if (sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7 != pObject->sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7)
		{
			return false;
		}
		if (sbt_wnlotcruZBvl1OuRuxXag != pObject->sbt_wnlotcruZBvl1OuRuxXag)
		{
			return false;
		}
		if (sbt_kvbMWgllUQ96ZpxfYK4Dd16.size() != pObject->sbt_kvbMWgllUQ96ZpxfYK4Dd16.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kvbMWgllUQ96ZpxfYK4Dd16.size(); i++)
		{
			if (0 != cx_strcmp(sbt_kvbMWgllUQ96ZpxfYK4Dd16[i].c_str(), pObject->sbt_kvbMWgllUQ96ZpxfYK4Dd16[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD != pObject->sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD)
		{
			return false;
		}
		if (sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.size() != pObject->sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.size(); i++)
		{
			if (sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA[i] != pObject->sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA[i])
			{
				return false;
			}
		}
		if (sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.size() != pObject->sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.size(); i++)
		{
			if (sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV[i] != pObject->sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wnlotcruZBvl1OuRuxXag", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wnlotcruZBvl1OuRuxXag = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kvbMWgllUQ96ZpxfYK4Dd16")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kvbMWgllUQ96ZpxfYK4Dd16.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR", (CX::Int64)sbt_Ee39G9vseZb_f2g_z5HctDBcaeWnvsDGuqWcaC77xRDyGRLYV04jmHOB3WR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7", (CX::Int64)sbt_qFOKNrkBsvziFAOMYjIb2FoqSqeLEwMdBcDlTRpQGYFp0xNry_0T7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wnlotcruZBvl1OuRuxXag", (CX::Int64)sbt_wnlotcruZBvl1OuRuxXag)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kvbMWgllUQ96ZpxfYK4Dd16")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_kvbMWgllUQ96ZpxfYK4Dd16.begin(); iter != sbt_kvbMWgllUQ96ZpxfYK4Dd16.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD", (CX::Int64)sbt_5PHLXbfbOvhw5PVd75sb_sNaaHJzEqAnb5zfW4WtWlNDRfmtp2im8ZiTD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.begin(); iter != sbt_JATYBHu2KgDC_6TShLNDRtgTmYJ70mdKKSmG8pehQxvVotcPC_7OHhnWA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.begin(); iter != sbt_yDzyIlPnFxIfBtQb6A8pUNk3_bQomSu_LtF56GZk5qV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I>::Type sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0IArray;

