
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_LVC_XWdgaXFYEfcKA_BHo;
	CX::UInt8 sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg;
	CX::IO::SimpleBuffers::UInt64Array sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha;
	CX::IO::SimpleBuffers::UInt64Array sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb;
	CX::UInt16 sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1;
	CX::IO::SimpleBuffers::UInt64Array sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc;
	CX::Int8 sbt_3;
	CX::IO::SimpleBuffers::Int16Array sbt_Ah17equEOPmQAvdLAXj;
	CX::UInt32 sbt_A8sz5cC3QgQGsABxAcH;
	CX::IO::SimpleBuffers::StringArray sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D;
	CX::IO::SimpleBuffers::UInt32Array sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G;
	CX::IO::SimpleBuffers::UInt16Array sbt_H;
	CX::IO::SimpleBuffers::UInt8Array sbt_q8mOPyBVQ8uejWSjmpUML;
	CX::UInt8 sbt_tmyKYIJaEmsyCdq;
	CX::IO::SimpleBuffers::UInt64Array sbt_pQUeYNimNzoftegyrUE;
	CX::UInt32 sbt_jsJN6LwlaVDuQ;
	CX::Bool sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX;
	CX::IO::SimpleBuffers::UInt64Array sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ;
	CX::String sbt_aIOopfr69XqHx_kiNhZ;
	CX::IO::SimpleBuffers::Int32Array sbt_jGPx81HH6A_bPzyjihUE6d2;
	CX::IO::SimpleBuffers::UInt32Array sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd;
	CX::IO::SimpleBuffers::UInt64Array sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW;
	CX::UInt64 sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU;

	virtual void Reset()
	{
		sbt_LVC_XWdgaXFYEfcKA_BHo.clear();
		sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg = 0;
		sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.clear();
		sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.clear();
		sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1 = 0;
		sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.clear();
		sbt_3 = 0;
		sbt_Ah17equEOPmQAvdLAXj.clear();
		sbt_A8sz5cC3QgQGsABxAcH = 0;
		sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.clear();
		sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.clear();
		sbt_H.clear();
		sbt_q8mOPyBVQ8uejWSjmpUML.clear();
		sbt_tmyKYIJaEmsyCdq = 0;
		sbt_pQUeYNimNzoftegyrUE.clear();
		sbt_jsJN6LwlaVDuQ = 0;
		sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX = false;
		sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.clear();
		sbt_aIOopfr69XqHx_kiNhZ.clear();
		sbt_jGPx81HH6A_bPzyjihUE6d2.clear();
		sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.clear();
		sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.clear();
		sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_LVC_XWdgaXFYEfcKA_BHo.push_back(47838);
		}
		sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg = 16;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.push_back(17337841204790807698);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.push_back(14218795168768424752);
		}
		sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1 = 15176;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.push_back(3029633126320199394);
		}
		sbt_3 = -97;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Ah17equEOPmQAvdLAXj.push_back(-25005);
		}
		sbt_A8sz5cC3QgQGsABxAcH = 2396594133;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.push_back("Sf");
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.push_back(2662762327);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_q8mOPyBVQ8uejWSjmpUML.push_back(96);
		}
		sbt_tmyKYIJaEmsyCdq = 65;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_pQUeYNimNzoftegyrUE.push_back(10695582436207444842);
		}
		sbt_jsJN6LwlaVDuQ = 234755602;
		sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.push_back(7944784920961514372);
		}
		sbt_aIOopfr69XqHx_kiNhZ = "?lzYZHq0QA^{T)KZf";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_jGPx81HH6A_bPzyjihUE6d2.push_back(2140161886);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.push_back(762553125);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.push_back(11371245892415683920);
		}
		sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU = 2704346358944725990;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8 *pObject = dynamic_cast<const sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_LVC_XWdgaXFYEfcKA_BHo.size() != pObject->sbt_LVC_XWdgaXFYEfcKA_BHo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LVC_XWdgaXFYEfcKA_BHo.size(); i++)
		{
			if (sbt_LVC_XWdgaXFYEfcKA_BHo[i] != pObject->sbt_LVC_XWdgaXFYEfcKA_BHo[i])
			{
				return false;
			}
		}
		if (sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg != pObject->sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg)
		{
			return false;
		}
		if (sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.size() != pObject->sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.size(); i++)
		{
			if (sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha[i] != pObject->sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha[i])
			{
				return false;
			}
		}
		if (sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.size() != pObject->sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.size(); i++)
		{
			if (sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb[i] != pObject->sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb[i])
			{
				return false;
			}
		}
		if (sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1 != pObject->sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1)
		{
			return false;
		}
		if (sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.size() != pObject->sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.size(); i++)
		{
			if (sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc[i] != pObject->sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc[i])
			{
				return false;
			}
		}
		if (sbt_3 != pObject->sbt_3)
		{
			return false;
		}
		if (sbt_Ah17equEOPmQAvdLAXj.size() != pObject->sbt_Ah17equEOPmQAvdLAXj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ah17equEOPmQAvdLAXj.size(); i++)
		{
			if (sbt_Ah17equEOPmQAvdLAXj[i] != pObject->sbt_Ah17equEOPmQAvdLAXj[i])
			{
				return false;
			}
		}
		if (sbt_A8sz5cC3QgQGsABxAcH != pObject->sbt_A8sz5cC3QgQGsABxAcH)
		{
			return false;
		}
		if (sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.size() != pObject->sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.size(); i++)
		{
			if (0 != cx_strcmp(sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D[i].c_str(), pObject->sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.size() != pObject->sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.size(); i++)
		{
			if (sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G[i] != pObject->sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G[i])
			{
				return false;
			}
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_q8mOPyBVQ8uejWSjmpUML.size() != pObject->sbt_q8mOPyBVQ8uejWSjmpUML.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q8mOPyBVQ8uejWSjmpUML.size(); i++)
		{
			if (sbt_q8mOPyBVQ8uejWSjmpUML[i] != pObject->sbt_q8mOPyBVQ8uejWSjmpUML[i])
			{
				return false;
			}
		}
		if (sbt_tmyKYIJaEmsyCdq != pObject->sbt_tmyKYIJaEmsyCdq)
		{
			return false;
		}
		if (sbt_pQUeYNimNzoftegyrUE.size() != pObject->sbt_pQUeYNimNzoftegyrUE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pQUeYNimNzoftegyrUE.size(); i++)
		{
			if (sbt_pQUeYNimNzoftegyrUE[i] != pObject->sbt_pQUeYNimNzoftegyrUE[i])
			{
				return false;
			}
		}
		if (sbt_jsJN6LwlaVDuQ != pObject->sbt_jsJN6LwlaVDuQ)
		{
			return false;
		}
		if (sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX != pObject->sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX)
		{
			return false;
		}
		if (sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.size() != pObject->sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.size(); i++)
		{
			if (sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ[i] != pObject->sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_aIOopfr69XqHx_kiNhZ.c_str(), pObject->sbt_aIOopfr69XqHx_kiNhZ.c_str()))
		{
			return false;
		}
		if (sbt_jGPx81HH6A_bPzyjihUE6d2.size() != pObject->sbt_jGPx81HH6A_bPzyjihUE6d2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jGPx81HH6A_bPzyjihUE6d2.size(); i++)
		{
			if (sbt_jGPx81HH6A_bPzyjihUE6d2[i] != pObject->sbt_jGPx81HH6A_bPzyjihUE6d2[i])
			{
				return false;
			}
		}
		if (sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.size() != pObject->sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.size(); i++)
		{
			if (sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd[i] != pObject->sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd[i])
			{
				return false;
			}
		}
		if (sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.size() != pObject->sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.size(); i++)
		{
			if (sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW[i] != pObject->sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW[i])
			{
				return false;
			}
		}
		if (sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU != pObject->sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_LVC_XWdgaXFYEfcKA_BHo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LVC_XWdgaXFYEfcKA_BHo.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Ah17equEOPmQAvdLAXj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ah17equEOPmQAvdLAXj.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A8sz5cC3QgQGsABxAcH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A8sz5cC3QgQGsABxAcH = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_q8mOPyBVQ8uejWSjmpUML")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q8mOPyBVQ8uejWSjmpUML.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tmyKYIJaEmsyCdq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tmyKYIJaEmsyCdq = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pQUeYNimNzoftegyrUE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pQUeYNimNzoftegyrUE.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jsJN6LwlaVDuQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jsJN6LwlaVDuQ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX", &sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_aIOopfr69XqHx_kiNhZ", &sbt_aIOopfr69XqHx_kiNhZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jGPx81HH6A_bPzyjihUE6d2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jGPx81HH6A_bPzyjihUE6d2.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_LVC_XWdgaXFYEfcKA_BHo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_LVC_XWdgaXFYEfcKA_BHo.begin(); iter != sbt_LVC_XWdgaXFYEfcKA_BHo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg", (CX::Int64)sbt_VZYb5ZbT2A2dhtrhC1prVRNlWeuwcmCiy2EtFA8f7zYiLhPopzg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.begin(); iter != sbt_AohyC9PWrI14FViXyCVetovM9BX78o06HPAha.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.begin(); iter != sbt_j4u40BZODKeC117iZK7py8yWO96k5OhLFDVtYEb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1", (CX::Int64)sbt_8Q8HFL97qICB2OOuvF3JEwjZui_jwBOTwGncbFgEw2qwjIELPOVKStF8nT5RYT1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.begin(); iter != sbt_fI0ZEij3RVFR6w0S0ynxUbMx0Dc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3", (CX::Int64)sbt_3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ah17equEOPmQAvdLAXj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Ah17equEOPmQAvdLAXj.begin(); iter != sbt_Ah17equEOPmQAvdLAXj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A8sz5cC3QgQGsABxAcH", (CX::Int64)sbt_A8sz5cC3QgQGsABxAcH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.begin(); iter != sbt_2C5FG6EZeynHK15JVhun3cbCJm8fBYUwe3D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.begin(); iter != sbt_yBRrwueYNaEe2kdNer9F2lhTSNyiYaq88LH8G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q8mOPyBVQ8uejWSjmpUML")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_q8mOPyBVQ8uejWSjmpUML.begin(); iter != sbt_q8mOPyBVQ8uejWSjmpUML.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tmyKYIJaEmsyCdq", (CX::Int64)sbt_tmyKYIJaEmsyCdq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pQUeYNimNzoftegyrUE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_pQUeYNimNzoftegyrUE.begin(); iter != sbt_pQUeYNimNzoftegyrUE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jsJN6LwlaVDuQ", (CX::Int64)sbt_jsJN6LwlaVDuQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX", sbt_q7OTV0dCtq9opydFYsviWFSGi8m9QxdQNVNGyCECYEpZ32CQ_cX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.begin(); iter != sbt_mZPzCpKEpWxra6osXBb2lk51qgYioxaT1Yy2qssOEkcVQP5LJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_aIOopfr69XqHx_kiNhZ", sbt_aIOopfr69XqHx_kiNhZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jGPx81HH6A_bPzyjihUE6d2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_jGPx81HH6A_bPzyjihUE6d2.begin(); iter != sbt_jGPx81HH6A_bPzyjihUE6d2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.begin(); iter != sbt_lGpU47nLcsaR0wXG1NNOQC70GnlVPuyvtbOxasN1vm_uMNd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.begin(); iter != sbt_JUJodczMsueKZD3hk_u5eLipeGWNGqTmJ1bXwjgYW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU", (CX::Int64)sbt_CcVZO9TOZyTtNiGH8ahLYgmPdiqNqIr4z1SzbL9mHBOEh_AF3TlX3rU)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8>::Type sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8Array;

