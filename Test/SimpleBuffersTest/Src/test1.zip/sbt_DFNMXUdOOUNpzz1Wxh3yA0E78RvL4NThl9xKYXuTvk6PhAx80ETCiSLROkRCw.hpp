
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_YC56TP18W.hpp"


class sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9;
	CX::String sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR;
	CX::Int32 sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10;
	CX::IO::SimpleBuffers::FloatArray sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb;
	CX::IO::SimpleBuffers::UInt64Array sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp;
	CX::IO::SimpleBuffers::UInt32Array sbt_SlpHZY3u5;
	CX::IO::SimpleBuffers::UInt16Array sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei;
	CX::IO::SimpleBuffers::UInt32Array sbt_NWtRdH0on46AeCVJoY9sfBYoCRM;
	CX::Bool sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP;
	CX::Int64 sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN;
	CX::IO::SimpleBuffers::FloatArray sbt_Y;
	CX::Float sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O;
	CX::IO::SimpleBuffers::BoolArray sbt_YJwyVN4TfqTwkb91hFXcK2Waz;
	sbt_YC56TP18WArray sbt_KJbf6yTy4qhVJVQ;

	virtual void Reset()
	{
		sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.clear();
		sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR.clear();
		sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10 = 0;
		sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.clear();
		sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.clear();
		sbt_SlpHZY3u5.clear();
		sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.clear();
		sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.clear();
		sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP = false;
		sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN = 0;
		sbt_Y.clear();
		sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O = 0.0f;
		sbt_YJwyVN4TfqTwkb91hFXcK2Waz.clear();
		sbt_KJbf6yTy4qhVJVQ.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.push_back(true);
		}
		sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR = "&(DzpmVA_1]8NfD{E{194Vw.j<jH\"62vUyeP{r4+b1_S&8u\"";
		sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10 = -1708525092;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.push_back(0.340692f);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.push_back(16521807389656832806);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_SlpHZY3u5.push_back(290671295);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.push_back(33382);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.push_back(36558689);
		}
		sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP = true;
		sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN = -7942023407647695718;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Y.push_back(0.544611f);
		}
		sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O = 0.138338f;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_YJwyVN4TfqTwkb91hFXcK2Waz.push_back(true);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_YC56TP18W v;

			v.SetupWithSomeValues();
			sbt_KJbf6yTy4qhVJVQ.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw *pObject = dynamic_cast<const sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.size() != pObject->sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.size(); i++)
		{
			if (sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9[i] != pObject->sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR.c_str(), pObject->sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR.c_str()))
		{
			return false;
		}
		if (sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10 != pObject->sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10)
		{
			return false;
		}
		if (sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.size() != pObject->sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.size(); i++)
		{
			if (sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb[i] != pObject->sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb[i])
			{
				return false;
			}
		}
		if (sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.size() != pObject->sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.size(); i++)
		{
			if (sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp[i] != pObject->sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp[i])
			{
				return false;
			}
		}
		if (sbt_SlpHZY3u5.size() != pObject->sbt_SlpHZY3u5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SlpHZY3u5.size(); i++)
		{
			if (sbt_SlpHZY3u5[i] != pObject->sbt_SlpHZY3u5[i])
			{
				return false;
			}
		}
		if (sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.size() != pObject->sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.size(); i++)
		{
			if (sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei[i] != pObject->sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei[i])
			{
				return false;
			}
		}
		if (sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.size() != pObject->sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.size(); i++)
		{
			if (sbt_NWtRdH0on46AeCVJoY9sfBYoCRM[i] != pObject->sbt_NWtRdH0on46AeCVJoY9sfBYoCRM[i])
			{
				return false;
			}
		}
		if (sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP != pObject->sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP)
		{
			return false;
		}
		if (sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN != pObject->sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN)
		{
			return false;
		}
		if (sbt_Y.size() != pObject->sbt_Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y.size(); i++)
		{
			if (sbt_Y[i] != pObject->sbt_Y[i])
			{
				return false;
			}
		}
		if (sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O != pObject->sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O)
		{
			return false;
		}
		if (sbt_YJwyVN4TfqTwkb91hFXcK2Waz.size() != pObject->sbt_YJwyVN4TfqTwkb91hFXcK2Waz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YJwyVN4TfqTwkb91hFXcK2Waz.size(); i++)
		{
			if (sbt_YJwyVN4TfqTwkb91hFXcK2Waz[i] != pObject->sbt_YJwyVN4TfqTwkb91hFXcK2Waz[i])
			{
				return false;
			}
		}
		if (sbt_KJbf6yTy4qhVJVQ.size() != pObject->sbt_KJbf6yTy4qhVJVQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KJbf6yTy4qhVJVQ.size(); i++)
		{
			if (!sbt_KJbf6yTy4qhVJVQ[i].Compare(&pObject->sbt_KJbf6yTy4qhVJVQ[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR", &sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SlpHZY3u5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SlpHZY3u5.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NWtRdH0on46AeCVJoY9sfBYoCRM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP", &sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_YJwyVN4TfqTwkb91hFXcK2Waz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YJwyVN4TfqTwkb91hFXcK2Waz.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KJbf6yTy4qhVJVQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_YC56TP18W tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_KJbf6yTy4qhVJVQ.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.begin(); iter != sbt_QwbxJbiYaW9e9bZyHrj7RHQK7xOCmRBqBmq4iDKdJzNDRfsjCL9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR", sbt_UCCF8r7Km1cmahmRjmREu_xEZMUgBuPoWgPZe5C6FTHGyOWbCGR.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10", (CX::Int64)sbt_aMMd67eZRxcRdSjiDyMoIjgm0AQOwTGwCckMDAlyyJazk10)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.begin(); iter != sbt_1G116g8o9JhxgKb2MJA3SpC22IM0E8tqy6Br1Q2FzgCOG2x2OgTZ4pevb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.begin(); iter != sbt_7u3RhkIw81WCzaG_h4H2jcgTMxmDHrsw8yNq4sMeDoSNp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SlpHZY3u5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_SlpHZY3u5.begin(); iter != sbt_SlpHZY3u5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.begin(); iter != sbt_dxVBk1nXAVGRQrMchQztPdAm0MR77yKA6ei.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NWtRdH0on46AeCVJoY9sfBYoCRM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.begin(); iter != sbt_NWtRdH0on46AeCVJoY9sfBYoCRM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP", sbt_qpTaJmvgJi28qFZNWvJnh5Yi0D3l2wNJT3IzDswDnff9ccUE8UxooebFQjaOqIP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN", (CX::Int64)sbt_LBoiqNkRl96wGo_CSSOEjR4QE__YpXPUahxSJqML2IkxKGkShQN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Y.begin(); iter != sbt_Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O", (CX::Double)sbt_3oJLt0_K2GiHp3dO84L5LDfQdOwrE9v2Y4h4O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YJwyVN4TfqTwkb91hFXcK2Waz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_YJwyVN4TfqTwkb91hFXcK2Waz.begin(); iter != sbt_YJwyVN4TfqTwkb91hFXcK2Waz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KJbf6yTy4qhVJVQ")).IsNOK())
		{
			return status;
		}
		for (sbt_YC56TP18WArray::const_iterator iter = sbt_KJbf6yTy4qhVJVQ.begin(); iter != sbt_KJbf6yTy4qhVJVQ.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw>::Type sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCwArray;

