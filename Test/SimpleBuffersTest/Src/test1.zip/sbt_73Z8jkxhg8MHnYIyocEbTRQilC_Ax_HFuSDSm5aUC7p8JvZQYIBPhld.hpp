
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p;
	CX::IO::SimpleBuffers::Int16Array sbt_WR7zVGljujJ3Z;
	CX::Int16 sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_;
	CX::IO::SimpleBuffers::UInt16Array sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2;
	CX::UInt16 sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O;
	CX::IO::SimpleBuffers::BoolArray sbt_8vyHICgstwjXAO6;
	CX::Int64 sbt_rPJfGMoGDRmi3mK;
	CX::IO::SimpleBuffers::UInt16Array sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv;
	CX::UInt64 sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty;
	CX::Int16 sbt_R;
	CX::IO::SimpleBuffers::UInt32Array sbt_8w9;
	CX::IO::SimpleBuffers::UInt64Array sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF;
	CX::UInt32 sbt_G;
	CX::IO::SimpleBuffers::Int32Array sbt_EIi67P_RUc3LcbJkkUePkI972hX34;
	CX::UInt32 sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD;
	CX::IO::SimpleBuffers::UInt64Array sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi;
	CX::IO::SimpleBuffers::UInt64Array sbt_s;
	CX::UInt32 sbt_wK930;
	CX::IO::SimpleBuffers::Int64Array sbt_A5r7o;
	CX::Bool sbt_F14Km;
	CX::String sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO;
	CX::Int32 sbt_EVk;
	CX::IO::SimpleBuffers::Int64Array sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp;
	CX::IO::SimpleBuffers::UInt32Array sbt_raX42RqkU;
	CX::Int16 sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5;
	CX::IO::SimpleBuffers::UInt32Array sbt_HFd5zCJa5jsyDar;

	virtual void Reset()
	{
		sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.clear();
		sbt_WR7zVGljujJ3Z.clear();
		sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_ = 0;
		sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.clear();
		sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O = 0;
		sbt_8vyHICgstwjXAO6.clear();
		sbt_rPJfGMoGDRmi3mK = 0;
		sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.clear();
		sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty = 0;
		sbt_R = 0;
		sbt_8w9.clear();
		sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.clear();
		sbt_G = 0;
		sbt_EIi67P_RUc3LcbJkkUePkI972hX34.clear();
		sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD = 0;
		sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.clear();
		sbt_s.clear();
		sbt_wK930 = 0;
		sbt_A5r7o.clear();
		sbt_F14Km = false;
		sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO.clear();
		sbt_EVk = 0;
		sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.clear();
		sbt_raX42RqkU.clear();
		sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5 = 0;
		sbt_HFd5zCJa5jsyDar.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.push_back(33);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_WR7zVGljujJ3Z.push_back(14056);
		}
		sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_ = 18121;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.push_back(6224);
		}
		sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O = 36494;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_8vyHICgstwjXAO6.push_back(true);
		}
		sbt_rPJfGMoGDRmi3mK = 8563683115400588508;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.push_back(51153);
		}
		sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty = 8862910849360481168;
		sbt_R = -9438;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_8w9.push_back(4035481388);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.push_back(1377455712975327446);
		}
		sbt_G = 416036149;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_EIi67P_RUc3LcbJkkUePkI972hX34.push_back(346655694);
		}
		sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD = 3202988294;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.push_back(14367749099576746980);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_s.push_back(4875515180740959142);
		}
		sbt_wK930 = 2494869533;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_A5r7o.push_back(-6524050988617645940);
		}
		sbt_F14Km = true;
		sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO = "Nsp//K{T%4D}~D66aRtKMLw'XfQYx";
		sbt_EVk = -2024410759;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.push_back(-2760507454312657530);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_raX42RqkU.push_back(3171692753);
		}
		sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5 = -25767;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_HFd5zCJa5jsyDar.push_back(2798995135);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld *pObject = dynamic_cast<const sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.size() != pObject->sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.size(); i++)
		{
			if (sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p[i] != pObject->sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p[i])
			{
				return false;
			}
		}
		if (sbt_WR7zVGljujJ3Z.size() != pObject->sbt_WR7zVGljujJ3Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WR7zVGljujJ3Z.size(); i++)
		{
			if (sbt_WR7zVGljujJ3Z[i] != pObject->sbt_WR7zVGljujJ3Z[i])
			{
				return false;
			}
		}
		if (sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_ != pObject->sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_)
		{
			return false;
		}
		if (sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.size() != pObject->sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.size(); i++)
		{
			if (sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2[i] != pObject->sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2[i])
			{
				return false;
			}
		}
		if (sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O != pObject->sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O)
		{
			return false;
		}
		if (sbt_8vyHICgstwjXAO6.size() != pObject->sbt_8vyHICgstwjXAO6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8vyHICgstwjXAO6.size(); i++)
		{
			if (sbt_8vyHICgstwjXAO6[i] != pObject->sbt_8vyHICgstwjXAO6[i])
			{
				return false;
			}
		}
		if (sbt_rPJfGMoGDRmi3mK != pObject->sbt_rPJfGMoGDRmi3mK)
		{
			return false;
		}
		if (sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.size() != pObject->sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.size(); i++)
		{
			if (sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv[i] != pObject->sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv[i])
			{
				return false;
			}
		}
		if (sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty != pObject->sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty)
		{
			return false;
		}
		if (sbt_R != pObject->sbt_R)
		{
			return false;
		}
		if (sbt_8w9.size() != pObject->sbt_8w9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8w9.size(); i++)
		{
			if (sbt_8w9[i] != pObject->sbt_8w9[i])
			{
				return false;
			}
		}
		if (sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.size() != pObject->sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.size(); i++)
		{
			if (sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF[i] != pObject->sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF[i])
			{
				return false;
			}
		}
		if (sbt_G != pObject->sbt_G)
		{
			return false;
		}
		if (sbt_EIi67P_RUc3LcbJkkUePkI972hX34.size() != pObject->sbt_EIi67P_RUc3LcbJkkUePkI972hX34.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EIi67P_RUc3LcbJkkUePkI972hX34.size(); i++)
		{
			if (sbt_EIi67P_RUc3LcbJkkUePkI972hX34[i] != pObject->sbt_EIi67P_RUc3LcbJkkUePkI972hX34[i])
			{
				return false;
			}
		}
		if (sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD != pObject->sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD)
		{
			return false;
		}
		if (sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.size() != pObject->sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.size(); i++)
		{
			if (sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi[i] != pObject->sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi[i])
			{
				return false;
			}
		}
		if (sbt_s.size() != pObject->sbt_s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s.size(); i++)
		{
			if (sbt_s[i] != pObject->sbt_s[i])
			{
				return false;
			}
		}
		if (sbt_wK930 != pObject->sbt_wK930)
		{
			return false;
		}
		if (sbt_A5r7o.size() != pObject->sbt_A5r7o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A5r7o.size(); i++)
		{
			if (sbt_A5r7o[i] != pObject->sbt_A5r7o[i])
			{
				return false;
			}
		}
		if (sbt_F14Km != pObject->sbt_F14Km)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO.c_str(), pObject->sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO.c_str()))
		{
			return false;
		}
		if (sbt_EVk != pObject->sbt_EVk)
		{
			return false;
		}
		if (sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.size() != pObject->sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.size(); i++)
		{
			if (sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp[i] != pObject->sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp[i])
			{
				return false;
			}
		}
		if (sbt_raX42RqkU.size() != pObject->sbt_raX42RqkU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_raX42RqkU.size(); i++)
		{
			if (sbt_raX42RqkU[i] != pObject->sbt_raX42RqkU[i])
			{
				return false;
			}
		}
		if (sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5 != pObject->sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5)
		{
			return false;
		}
		if (sbt_HFd5zCJa5jsyDar.size() != pObject->sbt_HFd5zCJa5jsyDar.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HFd5zCJa5jsyDar.size(); i++)
		{
			if (sbt_HFd5zCJa5jsyDar[i] != pObject->sbt_HFd5zCJa5jsyDar[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WR7zVGljujJ3Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WR7zVGljujJ3Z.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8vyHICgstwjXAO6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8vyHICgstwjXAO6.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rPJfGMoGDRmi3mK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rPJfGMoGDRmi3mK = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_R", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_R = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8w9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8w9.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EIi67P_RUc3LcbJkkUePkI972hX34")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EIi67P_RUc3LcbJkkUePkI972hX34.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wK930", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wK930 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_A5r7o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A5r7o.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_F14Km", &sbt_F14Km)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO", &sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EVk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EVk = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_raX42RqkU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_raX42RqkU.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HFd5zCJa5jsyDar")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HFd5zCJa5jsyDar.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.begin(); iter != sbt_Getu1l68FKngQRbKyzOKJBBJJyh2ZwUIt8p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WR7zVGljujJ3Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_WR7zVGljujJ3Z.begin(); iter != sbt_WR7zVGljujJ3Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_", (CX::Int64)sbt_sYcaauJa5MA1G6OniiBGJUSNRD0Nde_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.begin(); iter != sbt_Uhf01RA8Nki3ot6oXEsZmyiHgb2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O", (CX::Int64)sbt_8d4NCnvDXvmpZ5ZbDdMEr9Oxkea5faAYaK08O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8vyHICgstwjXAO6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_8vyHICgstwjXAO6.begin(); iter != sbt_8vyHICgstwjXAO6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rPJfGMoGDRmi3mK", (CX::Int64)sbt_rPJfGMoGDRmi3mK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.begin(); iter != sbt_GPl1emdZYFvfxiOSTW4P9tHNhILoRR99CtMzv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty", (CX::Int64)sbt_F_BMxXwdTdZTNnOrr9W6s1Tm6sNct_Kpjwmvduon796z0rFty)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_R", (CX::Int64)sbt_R)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8w9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_8w9.begin(); iter != sbt_8w9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.begin(); iter != sbt_vugFLWxHRDMDCYvWHywXMaqueLdUEkBkokBOi19FWAF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G", (CX::Int64)sbt_G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EIi67P_RUc3LcbJkkUePkI972hX34")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_EIi67P_RUc3LcbJkkUePkI972hX34.begin(); iter != sbt_EIi67P_RUc3LcbJkkUePkI972hX34.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD", (CX::Int64)sbt_VSFz2OAXQbxyqHzklHSulh8sMt7h6qwxGYiKXeD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.begin(); iter != sbt_OxZcNfTxZ92FdeAX70aXU36v5lJJ4qLOmRvwFVkYLwi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_s.begin(); iter != sbt_s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wK930", (CX::Int64)sbt_wK930)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A5r7o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_A5r7o.begin(); iter != sbt_A5r7o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_F14Km", sbt_F14Km)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO", sbt_EIGPLrVAf1Y0TIJ0y4TPpwLne7zekGMYQEO.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EVk", (CX::Int64)sbt_EVk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.begin(); iter != sbt_PFGUsaWF25yQptA_Tde8Pn3EvjkocfXMp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_raX42RqkU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_raX42RqkU.begin(); iter != sbt_raX42RqkU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5", (CX::Int64)sbt_D9Ri4yA3yNwhBi7_FWSKfSlfrZ4JLcKRtz5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HFd5zCJa5jsyDar")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_HFd5zCJa5jsyDar.begin(); iter != sbt_HFd5zCJa5jsyDar.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld>::Type sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhldArray;

