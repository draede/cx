
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_1a8ss7O616bqBSA0o : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1;
	CX::UInt32 sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ;
	CX::UInt32 sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU;
	CX::Int8 sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX;
	CX::IO::SimpleBuffers::UInt32Array sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2;
	CX::String sbt__VhumaclnWIb4PVAnsIjY;
	CX::IO::SimpleBuffers::BoolArray sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H;

	virtual void Reset()
	{
		sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1 = 0;
		sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ = 0;
		sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU = 0;
		sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX = 0;
		sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.clear();
		sbt__VhumaclnWIb4PVAnsIjY.clear();
		sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1 = 178;
		sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ = 200622790;
		sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU = 102905102;
		sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX = -63;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.push_back(2383247951);
		}
		sbt__VhumaclnWIb4PVAnsIjY = "!$U0Mc<l(d9X-o&<,@Z~wP%X0.{7ha`E.jUz:hMwv6nTYCd$_E]4<5";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_1a8ss7O616bqBSA0o *pObject = dynamic_cast<const sbt_1a8ss7O616bqBSA0o *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1 != pObject->sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1)
		{
			return false;
		}
		if (sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ != pObject->sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ)
		{
			return false;
		}
		if (sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU != pObject->sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU)
		{
			return false;
		}
		if (sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX != pObject->sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX)
		{
			return false;
		}
		if (sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.size() != pObject->sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.size(); i++)
		{
			if (sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2[i] != pObject->sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt__VhumaclnWIb4PVAnsIjY.c_str(), pObject->sbt__VhumaclnWIb4PVAnsIjY.c_str()))
		{
			return false;
		}
		if (sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.size() != pObject->sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.size(); i++)
		{
			if (sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H[i] != pObject->sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt__VhumaclnWIb4PVAnsIjY", &sbt__VhumaclnWIb4PVAnsIjY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1", (CX::Int64)sbt_eydEUe0j7FfzKtC1aAIq73ctU2NMw8fjRi1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ", (CX::Int64)sbt_zDOBoDLbPEgP8c7p35PpSDxU4VOOZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU", (CX::Int64)sbt_RqPntxCdLBpj2oaglHVU137DDqpENxoxjJ8Nl52RWdFhZs5gT0k_WpU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX", (CX::Int64)sbt_rkcAl1LYnkbfMUKCidv_rHlPB7qbxarKO5jsC0KnzxtcrMX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.begin(); iter != sbt_ZxnA1xfwV27kGb01DXPAghg2xptDx14mWS2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt__VhumaclnWIb4PVAnsIjY", sbt__VhumaclnWIb4PVAnsIjY.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.begin(); iter != sbt_ikHaKaMt3k_eJ4_XsqIyXk8cJYWdzhsDnCXeNpVf9zeN4EfmSeCtHImy5y57H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_1a8ss7O616bqBSA0o>::Type sbt_1a8ss7O616bqBSA0oArray;

