
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_3cmksv9geLsONvo : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj;
	CX::UInt16 sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm;
	CX::Bool sbt_Gklmt9WNyt4;
	CX::UInt16 sbt_g3lcn;
	CX::IO::SimpleBuffers::BoolArray sbt_4ilXj54J9nWtpeUzUZURrHadeUp;
	CX::IO::SimpleBuffers::Int16Array sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86;
	CX::IO::SimpleBuffers::UInt32Array sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq;
	CX::IO::SimpleBuffers::StringArray sbt_fXmb3Uc0qsPnMviYlxW_e;
	CX::UInt64 sbt_u;
	CX::UInt32 sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY;
	CX::IO::SimpleBuffers::UInt32Array sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9;
	CX::IO::SimpleBuffers::BoolArray sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3;
	CX::IO::SimpleBuffers::Int8Array sbt_cFNgN8vGqJiyU;
	CX::UInt64 sbt_P;

	virtual void Reset()
	{
		sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.clear();
		sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm = 0;
		sbt_Gklmt9WNyt4 = false;
		sbt_g3lcn = 0;
		sbt_4ilXj54J9nWtpeUzUZURrHadeUp.clear();
		sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.clear();
		sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.clear();
		sbt_fXmb3Uc0qsPnMviYlxW_e.clear();
		sbt_u = 0;
		sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY = 0;
		sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.clear();
		sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.clear();
		sbt_cFNgN8vGqJiyU.clear();
		sbt_P = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.push_back(42105);
		}
		sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm = 61402;
		sbt_Gklmt9WNyt4 = true;
		sbt_g3lcn = 27596;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_4ilXj54J9nWtpeUzUZURrHadeUp.push_back(true);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.push_back(27237);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.push_back(2913146670);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_fXmb3Uc0qsPnMviYlxW_e.push_back("e4XA(O9*?S5uwv*]tE44M<Y6qIzdx;EE8");
		}
		sbt_u = 9569975055807274980;
		sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY = 1284665454;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.push_back(3559194485);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.push_back(false);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_cFNgN8vGqJiyU.push_back(90);
		}
		sbt_P = 11695177217775345600;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3cmksv9geLsONvo *pObject = dynamic_cast<const sbt_3cmksv9geLsONvo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.size() != pObject->sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.size(); i++)
		{
			if (sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj[i] != pObject->sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj[i])
			{
				return false;
			}
		}
		if (sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm != pObject->sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm)
		{
			return false;
		}
		if (sbt_Gklmt9WNyt4 != pObject->sbt_Gklmt9WNyt4)
		{
			return false;
		}
		if (sbt_g3lcn != pObject->sbt_g3lcn)
		{
			return false;
		}
		if (sbt_4ilXj54J9nWtpeUzUZURrHadeUp.size() != pObject->sbt_4ilXj54J9nWtpeUzUZURrHadeUp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4ilXj54J9nWtpeUzUZURrHadeUp.size(); i++)
		{
			if (sbt_4ilXj54J9nWtpeUzUZURrHadeUp[i] != pObject->sbt_4ilXj54J9nWtpeUzUZURrHadeUp[i])
			{
				return false;
			}
		}
		if (sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.size() != pObject->sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.size(); i++)
		{
			if (sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86[i] != pObject->sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86[i])
			{
				return false;
			}
		}
		if (sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.size() != pObject->sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.size(); i++)
		{
			if (sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq[i] != pObject->sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq[i])
			{
				return false;
			}
		}
		if (sbt_fXmb3Uc0qsPnMviYlxW_e.size() != pObject->sbt_fXmb3Uc0qsPnMviYlxW_e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fXmb3Uc0qsPnMviYlxW_e.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fXmb3Uc0qsPnMviYlxW_e[i].c_str(), pObject->sbt_fXmb3Uc0qsPnMviYlxW_e[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_u != pObject->sbt_u)
		{
			return false;
		}
		if (sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY != pObject->sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY)
		{
			return false;
		}
		if (sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.size() != pObject->sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.size(); i++)
		{
			if (sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9[i] != pObject->sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9[i])
			{
				return false;
			}
		}
		if (sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.size() != pObject->sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.size(); i++)
		{
			if (sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3[i] != pObject->sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3[i])
			{
				return false;
			}
		}
		if (sbt_cFNgN8vGqJiyU.size() != pObject->sbt_cFNgN8vGqJiyU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cFNgN8vGqJiyU.size(); i++)
		{
			if (sbt_cFNgN8vGqJiyU[i] != pObject->sbt_cFNgN8vGqJiyU[i])
			{
				return false;
			}
		}
		if (sbt_P != pObject->sbt_P)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_Gklmt9WNyt4", &sbt_Gklmt9WNyt4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_g3lcn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_g3lcn = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4ilXj54J9nWtpeUzUZURrHadeUp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4ilXj54J9nWtpeUzUZURrHadeUp.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fXmb3Uc0qsPnMviYlxW_e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fXmb3Uc0qsPnMviYlxW_e.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cFNgN8vGqJiyU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cFNgN8vGqJiyU.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.begin(); iter != sbt_AqKHSs03apGtMvIu3Kv9eQQ0iAj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm", (CX::Int64)sbt_UkA_cAEYXO6VQb1cAQ9sFpaE_EOO42Oc4qIqm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Gklmt9WNyt4", sbt_Gklmt9WNyt4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_g3lcn", (CX::Int64)sbt_g3lcn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4ilXj54J9nWtpeUzUZURrHadeUp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_4ilXj54J9nWtpeUzUZURrHadeUp.begin(); iter != sbt_4ilXj54J9nWtpeUzUZURrHadeUp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.begin(); iter != sbt_c3P4AvGKIqceDDNVkdeVvyDVoCa_QIbrxNtvY86.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.begin(); iter != sbt_UoQf7OC4vqlFlWzz_fabwW0nKK_dTq2CSUQtPH0jtAcW3nPo2aq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fXmb3Uc0qsPnMviYlxW_e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fXmb3Uc0qsPnMviYlxW_e.begin(); iter != sbt_fXmb3Uc0qsPnMviYlxW_e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u", (CX::Int64)sbt_u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY", (CX::Int64)sbt_Qp1xGMMdtceGsUvUL_m4c7KTsxve5vY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.begin(); iter != sbt_g8Gl3z4jQYgCMXpwdvKMwV6jOHwVK_fGNTFXYKreQuWgX9WlLy9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.begin(); iter != sbt_BqEFHeafoLjOua3M4XkrybAP8g7TKr5tt_lSUaWS1vYtPVxPwIplac3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cFNgN8vGqJiyU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_cFNgN8vGqJiyU.begin(); iter != sbt_cFNgN8vGqJiyU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P", (CX::Int64)sbt_P)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3cmksv9geLsONvo>::Type sbt_3cmksv9geLsONvoArray;

