
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_r : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_cqWlpdNsepU9h8PKZ;
	CX::UInt16 sbt_j4UnI3nHNlZm8kRqDvjqP;
	CX::UInt64 sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua;
	CX::Int64 sbt_dtVxgp5g0;
	CX::IO::SimpleBuffers::Int64Array sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63;
	CX::IO::SimpleBuffers::BoolArray sbt_Qjz5uW8aInlq7;
	CX::IO::SimpleBuffers::UInt64Array sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A;
	CX::UInt64 sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6;
	CX::Int32 sbt_QIp0ARmpSZR_pk4NW;
	CX::IO::SimpleBuffers::Int32Array sbt_41dTI2pIQMcxOUeaQG6;
	CX::IO::SimpleBuffers::StringArray sbt_ILPM8yeGdbYuTA3iELWRgu_wN;
	CX::UInt64 sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5;
	CX::IO::SimpleBuffers::UInt8Array sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq;
	CX::IO::SimpleBuffers::UInt8Array sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74;
	CX::IO::SimpleBuffers::Int8Array sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4;
	CX::UInt64 sbt_3;
	CX::UInt64 sbt_yI1xNbZgHjFeDWpsjN2;
	CX::UInt32 sbt_A1XUs84rbK5OzFjWc;
	CX::UInt32 sbt_ABM6l;

	virtual void Reset()
	{
		sbt_cqWlpdNsepU9h8PKZ.clear();
		sbt_j4UnI3nHNlZm8kRqDvjqP = 0;
		sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua = 0;
		sbt_dtVxgp5g0 = 0;
		sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.clear();
		sbt_Qjz5uW8aInlq7.clear();
		sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.clear();
		sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6 = 0;
		sbt_QIp0ARmpSZR_pk4NW = 0;
		sbt_41dTI2pIQMcxOUeaQG6.clear();
		sbt_ILPM8yeGdbYuTA3iELWRgu_wN.clear();
		sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5 = 0;
		sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.clear();
		sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.clear();
		sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.clear();
		sbt_3 = 0;
		sbt_yI1xNbZgHjFeDWpsjN2 = 0;
		sbt_A1XUs84rbK5OzFjWc = 0;
		sbt_ABM6l = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_cqWlpdNsepU9h8PKZ.push_back("HwFCg31fe<tw@/~U[");
		}
		sbt_j4UnI3nHNlZm8kRqDvjqP = 39;
		sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua = 12206168697974566490;
		sbt_dtVxgp5g0 = -6133268253988152246;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.push_back(-6921472398741792942);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Qjz5uW8aInlq7.push_back(false);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.push_back(1194098708945457440);
		}
		sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6 = 17977924272700359714;
		sbt_QIp0ARmpSZR_pk4NW = 1108884089;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_41dTI2pIQMcxOUeaQG6.push_back(-937603098);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ILPM8yeGdbYuTA3iELWRgu_wN.push_back("[#)m]Pa[uWS*[Xdy1Z9");
		}
		sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5 = 2576963527117765216;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.push_back(52);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.push_back(34);
		}
		sbt_3 = 4549618466757663052;
		sbt_yI1xNbZgHjFeDWpsjN2 = 14726448781784019898;
		sbt_A1XUs84rbK5OzFjWc = 2619125821;
		sbt_ABM6l = 400349140;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_r *pObject = dynamic_cast<const sbt_r *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_cqWlpdNsepU9h8PKZ.size() != pObject->sbt_cqWlpdNsepU9h8PKZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cqWlpdNsepU9h8PKZ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_cqWlpdNsepU9h8PKZ[i].c_str(), pObject->sbt_cqWlpdNsepU9h8PKZ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_j4UnI3nHNlZm8kRqDvjqP != pObject->sbt_j4UnI3nHNlZm8kRqDvjqP)
		{
			return false;
		}
		if (sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua != pObject->sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua)
		{
			return false;
		}
		if (sbt_dtVxgp5g0 != pObject->sbt_dtVxgp5g0)
		{
			return false;
		}
		if (sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.size() != pObject->sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.size(); i++)
		{
			if (sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63[i] != pObject->sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63[i])
			{
				return false;
			}
		}
		if (sbt_Qjz5uW8aInlq7.size() != pObject->sbt_Qjz5uW8aInlq7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Qjz5uW8aInlq7.size(); i++)
		{
			if (sbt_Qjz5uW8aInlq7[i] != pObject->sbt_Qjz5uW8aInlq7[i])
			{
				return false;
			}
		}
		if (sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.size() != pObject->sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.size(); i++)
		{
			if (sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A[i] != pObject->sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A[i])
			{
				return false;
			}
		}
		if (sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6 != pObject->sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6)
		{
			return false;
		}
		if (sbt_QIp0ARmpSZR_pk4NW != pObject->sbt_QIp0ARmpSZR_pk4NW)
		{
			return false;
		}
		if (sbt_41dTI2pIQMcxOUeaQG6.size() != pObject->sbt_41dTI2pIQMcxOUeaQG6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_41dTI2pIQMcxOUeaQG6.size(); i++)
		{
			if (sbt_41dTI2pIQMcxOUeaQG6[i] != pObject->sbt_41dTI2pIQMcxOUeaQG6[i])
			{
				return false;
			}
		}
		if (sbt_ILPM8yeGdbYuTA3iELWRgu_wN.size() != pObject->sbt_ILPM8yeGdbYuTA3iELWRgu_wN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ILPM8yeGdbYuTA3iELWRgu_wN.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ILPM8yeGdbYuTA3iELWRgu_wN[i].c_str(), pObject->sbt_ILPM8yeGdbYuTA3iELWRgu_wN[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5 != pObject->sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5)
		{
			return false;
		}
		if (sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.size() != pObject->sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.size(); i++)
		{
			if (sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq[i] != pObject->sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq[i])
			{
				return false;
			}
		}
		if (sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.size() != pObject->sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.size(); i++)
		{
			if (sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74[i] != pObject->sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74[i])
			{
				return false;
			}
		}
		if (sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.size() != pObject->sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.size(); i++)
		{
			if (sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4[i] != pObject->sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4[i])
			{
				return false;
			}
		}
		if (sbt_3 != pObject->sbt_3)
		{
			return false;
		}
		if (sbt_yI1xNbZgHjFeDWpsjN2 != pObject->sbt_yI1xNbZgHjFeDWpsjN2)
		{
			return false;
		}
		if (sbt_A1XUs84rbK5OzFjWc != pObject->sbt_A1XUs84rbK5OzFjWc)
		{
			return false;
		}
		if (sbt_ABM6l != pObject->sbt_ABM6l)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_cqWlpdNsepU9h8PKZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cqWlpdNsepU9h8PKZ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_j4UnI3nHNlZm8kRqDvjqP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_j4UnI3nHNlZm8kRqDvjqP = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dtVxgp5g0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dtVxgp5g0 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Qjz5uW8aInlq7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Qjz5uW8aInlq7.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QIp0ARmpSZR_pk4NW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QIp0ARmpSZR_pk4NW = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_41dTI2pIQMcxOUeaQG6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_41dTI2pIQMcxOUeaQG6.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ILPM8yeGdbYuTA3iELWRgu_wN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ILPM8yeGdbYuTA3iELWRgu_wN.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_yI1xNbZgHjFeDWpsjN2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yI1xNbZgHjFeDWpsjN2 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_A1XUs84rbK5OzFjWc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A1XUs84rbK5OzFjWc = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ABM6l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ABM6l = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_cqWlpdNsepU9h8PKZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_cqWlpdNsepU9h8PKZ.begin(); iter != sbt_cqWlpdNsepU9h8PKZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_j4UnI3nHNlZm8kRqDvjqP", (CX::Int64)sbt_j4UnI3nHNlZm8kRqDvjqP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua", (CX::Int64)sbt_gjSBED0EteCcfyIU8jA1KJNHG0TVhZYje3lgn9JpDlx723GjApNkXgE13ua)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dtVxgp5g0", (CX::Int64)sbt_dtVxgp5g0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.begin(); iter != sbt_BPZTb59KUzQGeC1GY0jY71hcwuTqbnQ6R7qPTyGTUuYLkzF5arR63.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Qjz5uW8aInlq7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Qjz5uW8aInlq7.begin(); iter != sbt_Qjz5uW8aInlq7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.begin(); iter != sbt_ggrOda2FkVdNH_Eq909ZJkFD7DUsFjkv54oCGQlPEsZChpjjLv5gy0_G64A.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6", (CX::Int64)sbt_8iPzesyMdPMbo7mJ2vTXIVW4yDYmo48Vo21oP3UpDbntwyOt0XMViSl3mr6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QIp0ARmpSZR_pk4NW", (CX::Int64)sbt_QIp0ARmpSZR_pk4NW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_41dTI2pIQMcxOUeaQG6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_41dTI2pIQMcxOUeaQG6.begin(); iter != sbt_41dTI2pIQMcxOUeaQG6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ILPM8yeGdbYuTA3iELWRgu_wN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ILPM8yeGdbYuTA3iELWRgu_wN.begin(); iter != sbt_ILPM8yeGdbYuTA3iELWRgu_wN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5", (CX::Int64)sbt_mQoNqe4sR4c_NB3hTnXBT6yOEaibchN5Uc0L_YPutkbV_3uwSBBF5KOb5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.begin(); iter != sbt_eKMRBkRABG0vGN2Kgvsx1hlrjO6qZPpTEgLDSKfgdLFKq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.begin(); iter != sbt_VBor3rpYOs3Kkv1sjUmQ09JjGXGOaNJ74.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.begin(); iter != sbt_xsYxTGbqPQVZ3nRJ2_nOn96WCBbpQM7csukP2lOifbBOjx4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3", (CX::Int64)sbt_3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yI1xNbZgHjFeDWpsjN2", (CX::Int64)sbt_yI1xNbZgHjFeDWpsjN2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A1XUs84rbK5OzFjWc", (CX::Int64)sbt_A1XUs84rbK5OzFjWc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ABM6l", (CX::Int64)sbt_ABM6l)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_r>::Type sbt_rArray;

