
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Pl1G7KOQyDq0chahR.hpp"


class sbt_n9bzv9w : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh;
	CX::IO::SimpleBuffers::UInt16Array sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48;
	sbt_Pl1G7KOQyDq0chahRArray sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac;

	virtual void Reset()
	{
		sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh.clear();
		sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.clear();
		sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh = "/`8J<1!P\\XU@}*ee9";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.push_back(60600);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Pl1G7KOQyDq0chahR v;

			v.SetupWithSomeValues();
			sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_n9bzv9w *pObject = dynamic_cast<const sbt_n9bzv9w *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh.c_str(), pObject->sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh.c_str()))
		{
			return false;
		}
		if (sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.size() != pObject->sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.size(); i++)
		{
			if (sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48[i] != pObject->sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48[i])
			{
				return false;
			}
		}
		if (sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.size() != pObject->sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.size(); i++)
		{
			if (!sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac[i].Compare(&pObject->sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh", &sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_Pl1G7KOQyDq0chahR tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh", sbt_NNB7ahPQ5FjP7_wioBTRTMIVBScInlDWM54EwqMDWTF5jlh.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.begin(); iter != sbt_AZZnc7XU2pGHJW4wIlg_sf1Xcxg7zZhXSPq6cM5X55lubSk48.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac")).IsNOK())
		{
			return status;
		}
		for (sbt_Pl1G7KOQyDq0chahRArray::const_iterator iter = sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.begin(); iter != sbt_a57k_s3Gc1GtGSCTRgyMVc5g2YAac.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_n9bzv9w>::Type sbt_n9bzv9wArray;

