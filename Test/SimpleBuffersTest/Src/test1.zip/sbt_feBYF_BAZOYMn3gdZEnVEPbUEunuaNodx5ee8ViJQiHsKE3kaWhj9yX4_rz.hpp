
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_lPzTKyNT9utY3vGIhbt;
	CX::IO::SimpleBuffers::Int32Array sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX;
	CX::String sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6;
	CX::IO::SimpleBuffers::UInt8Array sbt_nPrtgU_7k;
	CX::IO::SimpleBuffers::Int32Array sbt_TnHolS2F0zpBnE4;
	CX::Int64 sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId;
	CX::IO::SimpleBuffers::UInt64Array sbt_KIQb0jKloaic1PzmoT2GrD6J3;
	CX::Int64 sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n;
	CX::IO::SimpleBuffers::UInt32Array sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u;
	CX::Int8 sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq;
	CX::UInt64 sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX;
	CX::IO::SimpleBuffers::UInt64Array sbt_H;
	CX::UInt8 sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM;
	CX::IO::SimpleBuffers::UInt8Array sbt_r;
	CX::IO::SimpleBuffers::UInt8Array sbt_t5B6tvR1Vt5GNDR;
	CX::IO::SimpleBuffers::UInt8Array sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH;
	CX::String sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt;
	CX::IO::SimpleBuffers::UInt64Array sbt_X0rnzgq_UGJCR9yAEAy8r;
	CX::IO::SimpleBuffers::UInt16Array sbt_5nJe4;
	CX::UInt32 sbt_H7H0kN4Sm7iIR0cWxrebw2F;

	virtual void Reset()
	{
		sbt_lPzTKyNT9utY3vGIhbt.clear();
		sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.clear();
		sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6.clear();
		sbt_nPrtgU_7k.clear();
		sbt_TnHolS2F0zpBnE4.clear();
		sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId = 0;
		sbt_KIQb0jKloaic1PzmoT2GrD6J3.clear();
		sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n = 0;
		sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.clear();
		sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq = 0;
		sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX = 0;
		sbt_H.clear();
		sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM = 0;
		sbt_r.clear();
		sbt_t5B6tvR1Vt5GNDR.clear();
		sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.clear();
		sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt.clear();
		sbt_X0rnzgq_UGJCR9yAEAy8r.clear();
		sbt_5nJe4.clear();
		sbt_H7H0kN4Sm7iIR0cWxrebw2F = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_lPzTKyNT9utY3vGIhbt.push_back(-50);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.push_back(-636498385);
		}
		sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6 = "hoNfd*";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_nPrtgU_7k.push_back(178);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_TnHolS2F0zpBnE4.push_back(-1239895946);
		}
		sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId = 7170720383043817826;
		sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n = -4798895509443568878;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.push_back(2984011911);
		}
		sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq = -94;
		sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX = 7326540978843896916;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_H.push_back(13822425803433733178);
		}
		sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM = 233;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_r.push_back(141);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_t5B6tvR1Vt5GNDR.push_back(248);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.push_back(143);
		}
		sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt = "&^_S?4L?)ZPkE}8%8==HgPePf,^Q,l(W.5/yat";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_X0rnzgq_UGJCR9yAEAy8r.push_back(2626085271553589532);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_5nJe4.push_back(60332);
		}
		sbt_H7H0kN4Sm7iIR0cWxrebw2F = 1671951250;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz *pObject = dynamic_cast<const sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_lPzTKyNT9utY3vGIhbt.size() != pObject->sbt_lPzTKyNT9utY3vGIhbt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lPzTKyNT9utY3vGIhbt.size(); i++)
		{
			if (sbt_lPzTKyNT9utY3vGIhbt[i] != pObject->sbt_lPzTKyNT9utY3vGIhbt[i])
			{
				return false;
			}
		}
		if (sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.size() != pObject->sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.size(); i++)
		{
			if (sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX[i] != pObject->sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6.c_str(), pObject->sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6.c_str()))
		{
			return false;
		}
		if (sbt_nPrtgU_7k.size() != pObject->sbt_nPrtgU_7k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nPrtgU_7k.size(); i++)
		{
			if (sbt_nPrtgU_7k[i] != pObject->sbt_nPrtgU_7k[i])
			{
				return false;
			}
		}
		if (sbt_TnHolS2F0zpBnE4.size() != pObject->sbt_TnHolS2F0zpBnE4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TnHolS2F0zpBnE4.size(); i++)
		{
			if (sbt_TnHolS2F0zpBnE4[i] != pObject->sbt_TnHolS2F0zpBnE4[i])
			{
				return false;
			}
		}
		if (sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId != pObject->sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId)
		{
			return false;
		}
		if (sbt_KIQb0jKloaic1PzmoT2GrD6J3.size() != pObject->sbt_KIQb0jKloaic1PzmoT2GrD6J3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KIQb0jKloaic1PzmoT2GrD6J3.size(); i++)
		{
			if (sbt_KIQb0jKloaic1PzmoT2GrD6J3[i] != pObject->sbt_KIQb0jKloaic1PzmoT2GrD6J3[i])
			{
				return false;
			}
		}
		if (sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n != pObject->sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n)
		{
			return false;
		}
		if (sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.size() != pObject->sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.size(); i++)
		{
			if (sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u[i] != pObject->sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u[i])
			{
				return false;
			}
		}
		if (sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq != pObject->sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq)
		{
			return false;
		}
		if (sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX != pObject->sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX)
		{
			return false;
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM != pObject->sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM)
		{
			return false;
		}
		if (sbt_r.size() != pObject->sbt_r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r.size(); i++)
		{
			if (sbt_r[i] != pObject->sbt_r[i])
			{
				return false;
			}
		}
		if (sbt_t5B6tvR1Vt5GNDR.size() != pObject->sbt_t5B6tvR1Vt5GNDR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t5B6tvR1Vt5GNDR.size(); i++)
		{
			if (sbt_t5B6tvR1Vt5GNDR[i] != pObject->sbt_t5B6tvR1Vt5GNDR[i])
			{
				return false;
			}
		}
		if (sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.size() != pObject->sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.size(); i++)
		{
			if (sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH[i] != pObject->sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt.c_str(), pObject->sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt.c_str()))
		{
			return false;
		}
		if (sbt_X0rnzgq_UGJCR9yAEAy8r.size() != pObject->sbt_X0rnzgq_UGJCR9yAEAy8r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X0rnzgq_UGJCR9yAEAy8r.size(); i++)
		{
			if (sbt_X0rnzgq_UGJCR9yAEAy8r[i] != pObject->sbt_X0rnzgq_UGJCR9yAEAy8r[i])
			{
				return false;
			}
		}
		if (sbt_5nJe4.size() != pObject->sbt_5nJe4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5nJe4.size(); i++)
		{
			if (sbt_5nJe4[i] != pObject->sbt_5nJe4[i])
			{
				return false;
			}
		}
		if (sbt_H7H0kN4Sm7iIR0cWxrebw2F != pObject->sbt_H7H0kN4Sm7iIR0cWxrebw2F)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_lPzTKyNT9utY3vGIhbt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lPzTKyNT9utY3vGIhbt.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6", &sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nPrtgU_7k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nPrtgU_7k.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TnHolS2F0zpBnE4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TnHolS2F0zpBnE4.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KIQb0jKloaic1PzmoT2GrD6J3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KIQb0jKloaic1PzmoT2GrD6J3.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_t5B6tvR1Vt5GNDR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t5B6tvR1Vt5GNDR.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt", &sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X0rnzgq_UGJCR9yAEAy8r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X0rnzgq_UGJCR9yAEAy8r.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5nJe4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5nJe4.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_H7H0kN4Sm7iIR0cWxrebw2F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_H7H0kN4Sm7iIR0cWxrebw2F = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_lPzTKyNT9utY3vGIhbt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_lPzTKyNT9utY3vGIhbt.begin(); iter != sbt_lPzTKyNT9utY3vGIhbt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.begin(); iter != sbt_bNIiKNFZBSyXgQ2rgN9oH_dfpFO_DbIJUeomAx0rbyklX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6", sbt_qeQpFC77j0UKCASp7QsBa3rpZv4lWoH7rOTURO1eV3aGuZSDeG6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nPrtgU_7k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_nPrtgU_7k.begin(); iter != sbt_nPrtgU_7k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TnHolS2F0zpBnE4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_TnHolS2F0zpBnE4.begin(); iter != sbt_TnHolS2F0zpBnE4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId", (CX::Int64)sbt_FxwxHsouOB6soY8WviKDGQ3JNJ4d1AIfOId)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KIQb0jKloaic1PzmoT2GrD6J3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_KIQb0jKloaic1PzmoT2GrD6J3.begin(); iter != sbt_KIQb0jKloaic1PzmoT2GrD6J3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n", (CX::Int64)sbt_fw5tW5C90O0ZOWbtx4X39InpCc2ejHfTsk1P0qLs51LAH815V8n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.begin(); iter != sbt_q_TDutCXl_uQaJUMtBO1F3JbkNN2j_d1u.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq", (CX::Int64)sbt_a1vAJwOUBTOtMTUM4LV5G1LxiFjJq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX", (CX::Int64)sbt_DARlEzU_h_x3UpF413G7UfQHVk5eCSYfbpX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM", (CX::Int64)sbt_8b3pEGyv7GQkIhHrokUdE0gmcEFd2thz83FgJRQFVgUvTqM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_r.begin(); iter != sbt_r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t5B6tvR1Vt5GNDR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_t5B6tvR1Vt5GNDR.begin(); iter != sbt_t5B6tvR1Vt5GNDR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.begin(); iter != sbt_vcwTXsVDOzB_qgcGDEWb2OW6YZqZAKUaTQiPLjY_nHmCjgH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt", sbt_sdCaYcj92lO8LY3ElZtppNTi8J3zaJNOt.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X0rnzgq_UGJCR9yAEAy8r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_X0rnzgq_UGJCR9yAEAy8r.begin(); iter != sbt_X0rnzgq_UGJCR9yAEAy8r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5nJe4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_5nJe4.begin(); iter != sbt_5nJe4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_H7H0kN4Sm7iIR0cWxrebw2F", (CX::Int64)sbt_H7H0kN4Sm7iIR0cWxrebw2F)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz>::Type sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rzArray;

