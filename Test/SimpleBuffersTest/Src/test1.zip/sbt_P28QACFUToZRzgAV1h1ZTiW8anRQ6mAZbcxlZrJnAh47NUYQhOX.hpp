
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Fxu3FQkTl3BJionNv6S.hpp"


class sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q;
	CX::IO::SimpleBuffers::Int8Array sbt_yYCMSR3Rz9hFXC51LUqAO;
	CX::WString sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO;
	CX::IO::SimpleBuffers::UInt32Array sbt_OBzZ6vgSrI6T0ZO1V;
	CX::Int32 sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ;
	CX::IO::SimpleBuffers::StringArray sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf;
	CX::IO::SimpleBuffers::Int64Array sbt_Pwt9G56;
	CX::String sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60;
	CX::IO::SimpleBuffers::BoolArray sbt_2KW66MCAvCPhB0eL8LYrCiA59OD;
	CX::Int8 sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM;
	CX::IO::SimpleBuffers::Int8Array sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt;
	CX::Int8 sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk;
	CX::Bool sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S;
	CX::UInt64 sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt;
	CX::UInt8 sbt_aapb2nASfdXirKfOmnuE5Zp;
	CX::IO::SimpleBuffers::FloatArray sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil;
	CX::IO::SimpleBuffers::UInt8Array sbt_qujR7SAbIXXxe;
	CX::IO::SimpleBuffers::Int16Array sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG;
	CX::IO::SimpleBuffers::UInt8Array sbt_0RHNMWeMpOy;
	CX::IO::SimpleBuffers::FloatArray sbt_baLW2WEdiQR;
	CX::Int8 sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik;
	CX::WString sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ;
	CX::IO::SimpleBuffers::BoolArray sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4;
	CX::UInt32 sbt_SdYBuGVhIU5;
	CX::IO::SimpleBuffers::UInt32Array sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM;
	CX::IO::SimpleBuffers::UInt64Array sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply;
	CX::IO::SimpleBuffers::UInt32Array sbt_w6LRwrJciSVMnUJy9_bKb;
	CX::Int8 sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX;
	sbt_Fxu3FQkTl3BJionNv6SArray sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV;

	virtual void Reset()
	{
		sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.clear();
		sbt_yYCMSR3Rz9hFXC51LUqAO.clear();
		sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO.clear();
		sbt_OBzZ6vgSrI6T0ZO1V.clear();
		sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ = 0;
		sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.clear();
		sbt_Pwt9G56.clear();
		sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60.clear();
		sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.clear();
		sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM = 0;
		sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.clear();
		sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk = 0;
		sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S = false;
		sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt = 0;
		sbt_aapb2nASfdXirKfOmnuE5Zp = 0;
		sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.clear();
		sbt_qujR7SAbIXXxe.clear();
		sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.clear();
		sbt_0RHNMWeMpOy.clear();
		sbt_baLW2WEdiQR.clear();
		sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik = 0;
		sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ.clear();
		sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.clear();
		sbt_SdYBuGVhIU5 = 0;
		sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.clear();
		sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.clear();
		sbt_w6LRwrJciSVMnUJy9_bKb.clear();
		sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX = 0;
		sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.push_back(6030440281377505958);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_yYCMSR3Rz9hFXC51LUqAO.push_back(3);
		}
		sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO = L"GP};#bkSm!zamGorj{m]-=>x>P$^C_\\<b(>0^gT(sIw(g2/=vb=8";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_OBzZ6vgSrI6T0ZO1V.push_back(1254645188);
		}
		sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ = -724090540;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.push_back("UE7DY=DfSEDs=GP9iohMuSH)u=9eYbQL/'-");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Pwt9G56.push_back(-8071718714180289324);
		}
		sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60 = "er_T?rl\"+#/;AVJXdv]~%(f7s&nV3AWW*";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.push_back(true);
		}
		sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM = 49;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.push_back(117);
		}
		sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk = 40;
		sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S = true;
		sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt = 9729910620986453040;
		sbt_aapb2nASfdXirKfOmnuE5Zp = 229;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.push_back(0.985417f);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_qujR7SAbIXXxe.push_back(172);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.push_back(-1766);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_0RHNMWeMpOy.push_back(42);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_baLW2WEdiQR.push_back(0.635636f);
		}
		sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik = 90;
		sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ = L"Irfdd{<:@O.u%wCkHg<5vpn^9AP4^#{:4Fvt@l]7=1Q0w#.F9lAm";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.push_back(true);
		}
		sbt_SdYBuGVhIU5 = 1960035669;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.push_back(1043536697);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.push_back(624805469334557984);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_w6LRwrJciSVMnUJy9_bKb.push_back(3372693253);
		}
		sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX = -55;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Fxu3FQkTl3BJionNv6S v;

			v.SetupWithSomeValues();
			sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX *pObject = dynamic_cast<const sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.size() != pObject->sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.size(); i++)
		{
			if (sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q[i] != pObject->sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q[i])
			{
				return false;
			}
		}
		if (sbt_yYCMSR3Rz9hFXC51LUqAO.size() != pObject->sbt_yYCMSR3Rz9hFXC51LUqAO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yYCMSR3Rz9hFXC51LUqAO.size(); i++)
		{
			if (sbt_yYCMSR3Rz9hFXC51LUqAO[i] != pObject->sbt_yYCMSR3Rz9hFXC51LUqAO[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO.c_str(), pObject->sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO.c_str()))
		{
			return false;
		}
		if (sbt_OBzZ6vgSrI6T0ZO1V.size() != pObject->sbt_OBzZ6vgSrI6T0ZO1V.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OBzZ6vgSrI6T0ZO1V.size(); i++)
		{
			if (sbt_OBzZ6vgSrI6T0ZO1V[i] != pObject->sbt_OBzZ6vgSrI6T0ZO1V[i])
			{
				return false;
			}
		}
		if (sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ != pObject->sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ)
		{
			return false;
		}
		if (sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.size() != pObject->sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.size(); i++)
		{
			if (0 != cx_strcmp(sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf[i].c_str(), pObject->sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Pwt9G56.size() != pObject->sbt_Pwt9G56.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Pwt9G56.size(); i++)
		{
			if (sbt_Pwt9G56[i] != pObject->sbt_Pwt9G56[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60.c_str(), pObject->sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60.c_str()))
		{
			return false;
		}
		if (sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.size() != pObject->sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.size(); i++)
		{
			if (sbt_2KW66MCAvCPhB0eL8LYrCiA59OD[i] != pObject->sbt_2KW66MCAvCPhB0eL8LYrCiA59OD[i])
			{
				return false;
			}
		}
		if (sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM != pObject->sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM)
		{
			return false;
		}
		if (sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.size() != pObject->sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.size(); i++)
		{
			if (sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt[i] != pObject->sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt[i])
			{
				return false;
			}
		}
		if (sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk != pObject->sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk)
		{
			return false;
		}
		if (sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S != pObject->sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S)
		{
			return false;
		}
		if (sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt != pObject->sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt)
		{
			return false;
		}
		if (sbt_aapb2nASfdXirKfOmnuE5Zp != pObject->sbt_aapb2nASfdXirKfOmnuE5Zp)
		{
			return false;
		}
		if (sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.size() != pObject->sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.size(); i++)
		{
			if (sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil[i] != pObject->sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil[i])
			{
				return false;
			}
		}
		if (sbt_qujR7SAbIXXxe.size() != pObject->sbt_qujR7SAbIXXxe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qujR7SAbIXXxe.size(); i++)
		{
			if (sbt_qujR7SAbIXXxe[i] != pObject->sbt_qujR7SAbIXXxe[i])
			{
				return false;
			}
		}
		if (sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.size() != pObject->sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.size(); i++)
		{
			if (sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG[i] != pObject->sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG[i])
			{
				return false;
			}
		}
		if (sbt_0RHNMWeMpOy.size() != pObject->sbt_0RHNMWeMpOy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0RHNMWeMpOy.size(); i++)
		{
			if (sbt_0RHNMWeMpOy[i] != pObject->sbt_0RHNMWeMpOy[i])
			{
				return false;
			}
		}
		if (sbt_baLW2WEdiQR.size() != pObject->sbt_baLW2WEdiQR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_baLW2WEdiQR.size(); i++)
		{
			if (sbt_baLW2WEdiQR[i] != pObject->sbt_baLW2WEdiQR[i])
			{
				return false;
			}
		}
		if (sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik != pObject->sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ.c_str(), pObject->sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ.c_str()))
		{
			return false;
		}
		if (sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.size() != pObject->sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.size(); i++)
		{
			if (sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4[i] != pObject->sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4[i])
			{
				return false;
			}
		}
		if (sbt_SdYBuGVhIU5 != pObject->sbt_SdYBuGVhIU5)
		{
			return false;
		}
		if (sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.size() != pObject->sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.size(); i++)
		{
			if (sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM[i] != pObject->sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM[i])
			{
				return false;
			}
		}
		if (sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.size() != pObject->sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.size(); i++)
		{
			if (sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply[i] != pObject->sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply[i])
			{
				return false;
			}
		}
		if (sbt_w6LRwrJciSVMnUJy9_bKb.size() != pObject->sbt_w6LRwrJciSVMnUJy9_bKb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_w6LRwrJciSVMnUJy9_bKb.size(); i++)
		{
			if (sbt_w6LRwrJciSVMnUJy9_bKb[i] != pObject->sbt_w6LRwrJciSVMnUJy9_bKb[i])
			{
				return false;
			}
		}
		if (sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX != pObject->sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX)
		{
			return false;
		}
		if (sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.size() != pObject->sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.size(); i++)
		{
			if (!sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV[i].Compare(&pObject->sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yYCMSR3Rz9hFXC51LUqAO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yYCMSR3Rz9hFXC51LUqAO.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO", &sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OBzZ6vgSrI6T0ZO1V")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OBzZ6vgSrI6T0ZO1V.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Pwt9G56")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Pwt9G56.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60", &sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2KW66MCAvCPhB0eL8LYrCiA59OD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S", &sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_aapb2nASfdXirKfOmnuE5Zp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aapb2nASfdXirKfOmnuE5Zp = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qujR7SAbIXXxe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qujR7SAbIXXxe.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0RHNMWeMpOy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0RHNMWeMpOy.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_baLW2WEdiQR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_baLW2WEdiQR.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ", &sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SdYBuGVhIU5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SdYBuGVhIU5 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_w6LRwrJciSVMnUJy9_bKb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_w6LRwrJciSVMnUJy9_bKb.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_Fxu3FQkTl3BJionNv6S tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.begin(); iter != sbt_0IhLjUbUAGADmFGfHBEsgtoxVyPNhKqvQNjuxwG87xtk1iwuyeAOaNQqmH59q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yYCMSR3Rz9hFXC51LUqAO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_yYCMSR3Rz9hFXC51LUqAO.begin(); iter != sbt_yYCMSR3Rz9hFXC51LUqAO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO", sbt_zAwQORw6CMmbHPAu3lRKWqn7J9CdDHuquIO3l6QSarF4E43s9Rxv_ujwO.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OBzZ6vgSrI6T0ZO1V")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_OBzZ6vgSrI6T0ZO1V.begin(); iter != sbt_OBzZ6vgSrI6T0ZO1V.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ", (CX::Int64)sbt_X1YKMCmjefG65hrQ3v_HdUwATnE80vl48quAUsNZF45TweAHJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.begin(); iter != sbt_HLQt12j4lKgNkPkrbdL5bySbCODCAhJqBwf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Pwt9G56")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Pwt9G56.begin(); iter != sbt_Pwt9G56.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60", sbt_v4D4BLNJ0ggv9U0O3uYpNj2pdZKHplcSBMyJYQkYUWKE8Zo4rfU60.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2KW66MCAvCPhB0eL8LYrCiA59OD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.begin(); iter != sbt_2KW66MCAvCPhB0eL8LYrCiA59OD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM", (CX::Int64)sbt_tGIYavLLBl09RDaNWheeBwRsFlG_OBM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.begin(); iter != sbt_HTctLyGotjU5AQF7SrQTD1WXO1RGOwkQZCt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk", (CX::Int64)sbt_F1_VvxKK1PG9ohPRO762ilQPUWLjN3AJEsfCCLvmifus1IkA0Rlncpk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S", sbt_pLWbpQ3wkZm_mzwDcXDF2VQ2jAh03sujLyzsGmuPj1S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt", (CX::Int64)sbt_LJ8V0DqnFfUOHZmuGaw4t4go0FXpfCaY1pt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aapb2nASfdXirKfOmnuE5Zp", (CX::Int64)sbt_aapb2nASfdXirKfOmnuE5Zp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.begin(); iter != sbt_brbUJowFgaOa8NuXgLeZXv7Eni_fQuaYbJCX3V8TtgSN2Zuil.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qujR7SAbIXXxe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_qujR7SAbIXXxe.begin(); iter != sbt_qujR7SAbIXXxe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.begin(); iter != sbt_DbBLnbJAePhJVU3k44yAOFUwu8EIvuQMpk_tria3M1PqG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0RHNMWeMpOy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_0RHNMWeMpOy.begin(); iter != sbt_0RHNMWeMpOy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_baLW2WEdiQR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_baLW2WEdiQR.begin(); iter != sbt_baLW2WEdiQR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik", (CX::Int64)sbt_oxrZKYxevfPixkAYKHmmbUygyc5Tew6Igik)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ", sbt_j3P4uK_bgeFM0oOHZtVwfZy5VOikJ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.begin(); iter != sbt_Bdkc8fr7VIciOdY24vaUT94tiLE5obmAwKCrFE4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SdYBuGVhIU5", (CX::Int64)sbt_SdYBuGVhIU5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.begin(); iter != sbt_a01G5dfOWMQkn0NBP4dO3UDOawQFQwc3U4idAOdBzwD2iJRdGn0aM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.begin(); iter != sbt_n5y8sSMyZcW6oaGf8ouopuvLIBzzQcTjTZJyI_hp2DqQx86BbrtIYEeBgOply.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_w6LRwrJciSVMnUJy9_bKb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_w6LRwrJciSVMnUJy9_bKb.begin(); iter != sbt_w6LRwrJciSVMnUJy9_bKb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX", (CX::Int64)sbt_k7Q3J83CcZfD_zK6mV54oyBf773iuPyTc4jqasyqLtJXmANoFcGyX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV")).IsNOK())
		{
			return status;
		}
		for (sbt_Fxu3FQkTl3BJionNv6SArray::const_iterator iter = sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.begin(); iter != sbt_usQOdqASy8sumcg5KuQ5ZL93exmN4XV.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX>::Type sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOXArray;

