
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js.hpp"


class sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672;
	CX::IO::SimpleBuffers::StringArray sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP;
	CX::Double sbt_iv1QO;
	CX::IO::SimpleBuffers::Int16Array sbt_JTiON5AKkWo01WXmqOlnkC8;
	CX::IO::SimpleBuffers::Int16Array sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3;
	CX::IO::SimpleBuffers::Int64Array sbt_HRNn88BNwp4W_KrfH;
	CX::IO::SimpleBuffers::Int8Array sbt_TMnRpWtdefkevie8YSVAAfC;
	CX::Int32 sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee;
	CX::Int32 sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ;
	CX::IO::SimpleBuffers::Int64Array sbt_P3hSslq9U0OjRLY9XsSbR;
	CX::IO::SimpleBuffers::Int16Array sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR;
	CX::IO::SimpleBuffers::BoolArray sbt_IwBVDBjelv4SXMQK2NhTL5yaJ;
	CX::Double sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO;
	CX::IO::SimpleBuffers::UInt64Array sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN;
	CX::WString sbt_3;
	CX::Double sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT;
	CX::UInt8 sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28;
	CX::IO::SimpleBuffers::WStringArray sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv;
	sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz;

	virtual void Reset()
	{
		sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.clear();
		sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.clear();
		sbt_iv1QO = 0.0;
		sbt_JTiON5AKkWo01WXmqOlnkC8.clear();
		sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.clear();
		sbt_HRNn88BNwp4W_KrfH.clear();
		sbt_TMnRpWtdefkevie8YSVAAfC.clear();
		sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee = 0;
		sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ = 0;
		sbt_P3hSslq9U0OjRLY9XsSbR.clear();
		sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.clear();
		sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.clear();
		sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO = 0.0;
		sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.clear();
		sbt_3.clear();
		sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT = 0.0;
		sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28 = 0;
		sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.clear();
		sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.push_back(6776);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.push_back("6FfsfjN#iRA8VEm5WZr=5f4nd;HKo)i%:sO-/v=5e6<}~w&=a}{0AtM~>");
		}
		sbt_iv1QO = 0.714066;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_JTiON5AKkWo01WXmqOlnkC8.push_back(11598);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.push_back(3186);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_HRNn88BNwp4W_KrfH.push_back(1687264140867953196);
		}
		sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee = 113672023;
		sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ = -1122320805;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_P3hSslq9U0OjRLY9XsSbR.push_back(5046771910037007630);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.push_back(11182);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.push_back(false);
		}
		sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO = 0.933415;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.push_back(18213727592228506834);
		}
		sbt_3 = L"Bq}cC+P`u7v`:`QT\\*$gREJlM=\\neFG_2/><S8D{p";
		sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT = 0.923544;
		sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28 = 133;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.push_back(L"d<4k'pJ}rV)$I7}bw5J^u0`\"e!P5(U$");
		}
		sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK *pObject = dynamic_cast<const sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.size() != pObject->sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.size(); i++)
		{
			if (sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672[i] != pObject->sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672[i])
			{
				return false;
			}
		}
		if (sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.size() != pObject->sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP[i].c_str(), pObject->sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_iv1QO != pObject->sbt_iv1QO)
		{
			return false;
		}
		if (sbt_JTiON5AKkWo01WXmqOlnkC8.size() != pObject->sbt_JTiON5AKkWo01WXmqOlnkC8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JTiON5AKkWo01WXmqOlnkC8.size(); i++)
		{
			if (sbt_JTiON5AKkWo01WXmqOlnkC8[i] != pObject->sbt_JTiON5AKkWo01WXmqOlnkC8[i])
			{
				return false;
			}
		}
		if (sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.size() != pObject->sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.size(); i++)
		{
			if (sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3[i] != pObject->sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3[i])
			{
				return false;
			}
		}
		if (sbt_HRNn88BNwp4W_KrfH.size() != pObject->sbt_HRNn88BNwp4W_KrfH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HRNn88BNwp4W_KrfH.size(); i++)
		{
			if (sbt_HRNn88BNwp4W_KrfH[i] != pObject->sbt_HRNn88BNwp4W_KrfH[i])
			{
				return false;
			}
		}
		if (sbt_TMnRpWtdefkevie8YSVAAfC.size() != pObject->sbt_TMnRpWtdefkevie8YSVAAfC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TMnRpWtdefkevie8YSVAAfC.size(); i++)
		{
			if (sbt_TMnRpWtdefkevie8YSVAAfC[i] != pObject->sbt_TMnRpWtdefkevie8YSVAAfC[i])
			{
				return false;
			}
		}
		if (sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee != pObject->sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee)
		{
			return false;
		}
		if (sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ != pObject->sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ)
		{
			return false;
		}
		if (sbt_P3hSslq9U0OjRLY9XsSbR.size() != pObject->sbt_P3hSslq9U0OjRLY9XsSbR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P3hSslq9U0OjRLY9XsSbR.size(); i++)
		{
			if (sbt_P3hSslq9U0OjRLY9XsSbR[i] != pObject->sbt_P3hSslq9U0OjRLY9XsSbR[i])
			{
				return false;
			}
		}
		if (sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.size() != pObject->sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.size(); i++)
		{
			if (sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR[i] != pObject->sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR[i])
			{
				return false;
			}
		}
		if (sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.size() != pObject->sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.size(); i++)
		{
			if (sbt_IwBVDBjelv4SXMQK2NhTL5yaJ[i] != pObject->sbt_IwBVDBjelv4SXMQK2NhTL5yaJ[i])
			{
				return false;
			}
		}
		if (sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO != pObject->sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO)
		{
			return false;
		}
		if (sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.size() != pObject->sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.size(); i++)
		{
			if (sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN[i] != pObject->sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_3.c_str(), pObject->sbt_3.c_str()))
		{
			return false;
		}
		if (sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT != pObject->sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT)
		{
			return false;
		}
		if (sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28 != pObject->sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28)
		{
			return false;
		}
		if (sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.size() != pObject->sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv[i].c_str(), pObject->sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv[i].c_str()))
			{
				return false;
			}
		}
		if (!sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz.Compare(&pObject->sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_iv1QO", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_iv1QO = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_JTiON5AKkWo01WXmqOlnkC8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JTiON5AKkWo01WXmqOlnkC8.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HRNn88BNwp4W_KrfH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HRNn88BNwp4W_KrfH.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TMnRpWtdefkevie8YSVAAfC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TMnRpWtdefkevie8YSVAAfC.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_P3hSslq9U0OjRLY9XsSbR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P3hSslq9U0OjRLY9XsSbR.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IwBVDBjelv4SXMQK2NhTL5yaJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_3", &sbt_3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.begin(); iter != sbt_w_tKrQRW4d42oLlqpaGaHHvZppVPtE99rLZ3672.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.begin(); iter != sbt_tCoAcHykPSqx8ZYQA6TwUbjPHfbGP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_iv1QO", (CX::Double)sbt_iv1QO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JTiON5AKkWo01WXmqOlnkC8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_JTiON5AKkWo01WXmqOlnkC8.begin(); iter != sbt_JTiON5AKkWo01WXmqOlnkC8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.begin(); iter != sbt_s6yPpFnUbkAGKsGJulTB4uJgR7Od_S3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HRNn88BNwp4W_KrfH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_HRNn88BNwp4W_KrfH.begin(); iter != sbt_HRNn88BNwp4W_KrfH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TMnRpWtdefkevie8YSVAAfC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_TMnRpWtdefkevie8YSVAAfC.begin(); iter != sbt_TMnRpWtdefkevie8YSVAAfC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee", (CX::Int64)sbt_yA6iqHwueItXCWKMSI7XXInBTR5n2lzhxADxF9f9zMjFuQKJ1Jhenee)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ", (CX::Int64)sbt_Gn0B1lYBzLIWkhGmdBMQoKVBZbLH6jU5xTBX9zhzbJs1JrRnyafUJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P3hSslq9U0OjRLY9XsSbR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_P3hSslq9U0OjRLY9XsSbR.begin(); iter != sbt_P3hSslq9U0OjRLY9XsSbR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.begin(); iter != sbt_4DQJF0kpTM9GdJjQL3uLa2WaVMcnni0amLuwR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IwBVDBjelv4SXMQK2NhTL5yaJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.begin(); iter != sbt_IwBVDBjelv4SXMQK2NhTL5yaJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO", (CX::Double)sbt_r0UmNukZqY7vxfY7qNI0wtLWiziDO8xbEag7etK3V8rhrqVUHwmVqlsolftSO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.begin(); iter != sbt_fNho85W2vXLQQfjldo36U46f1TDJZUp4lCirliG9eUbXR1NEFEX8HxQGnN9gCRN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_3", sbt_3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT", (CX::Double)sbt_9axlQOxo3FhwIN2ZW8c5OOZ8B_r7dBQMhQMFCfNIyQh9Y_XLK7l_9oT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28", (CX::Int64)sbt_qHJcTs4qjEh7o8EJZycY3ZnvFJgXs28)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.begin(); iter != sbt_VQDQrpSc631yDwiIQ2ZDi1wU8aU0QCz2oYTz2kG946_k5et_JuRqOQMvckafv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_lOtnXG9Rt4bGcxWNGoNy_gJWQlYPul8_Ioybe1uBjesrzTfNV8on5fz.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK>::Type sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeKArray;

