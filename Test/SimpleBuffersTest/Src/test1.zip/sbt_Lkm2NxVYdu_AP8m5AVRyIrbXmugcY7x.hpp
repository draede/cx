
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP;
	CX::IO::SimpleBuffers::UInt32Array sbt_s;
	CX::IO::SimpleBuffers::UInt64Array sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo;
	CX::IO::SimpleBuffers::UInt64Array sbt_ggK3_kOBldCEH8dfMJur044IKXu;
	CX::UInt64 sbt_GZ1A6Wd7fBMFrQvJI;
	CX::UInt64 sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os;
	CX::Int8 sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z;
	CX::UInt32 sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY;
	CX::UInt16 sbt_8t_5Ejt;
	CX::UInt64 sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG;
	CX::UInt8 sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41;
	CX::IO::SimpleBuffers::BoolArray sbt_xpSH4jjRbFj_U;
	CX::UInt16 sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC;
	CX::IO::SimpleBuffers::UInt64Array sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN;
	CX::IO::SimpleBuffers::Int32Array sbt__ZrPeM1XDEHk2JW;
	CX::IO::SimpleBuffers::UInt8Array sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F;
	CX::IO::SimpleBuffers::UInt32Array sbt__;
	CX::Int32 sbt_pw8kO;
	CX::String sbt_P;
	CX::UInt64 sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo;
	CX::IO::SimpleBuffers::Int64Array sbt_23L;
	CX::IO::SimpleBuffers::Int8Array sbt_B7Y;

	virtual void Reset()
	{
		sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.clear();
		sbt_s.clear();
		sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.clear();
		sbt_ggK3_kOBldCEH8dfMJur044IKXu.clear();
		sbt_GZ1A6Wd7fBMFrQvJI = 0;
		sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os = 0;
		sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z = 0;
		sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY = 0;
		sbt_8t_5Ejt = 0;
		sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG = 0;
		sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41 = 0;
		sbt_xpSH4jjRbFj_U.clear();
		sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC = 0;
		sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.clear();
		sbt__ZrPeM1XDEHk2JW.clear();
		sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.clear();
		sbt__.clear();
		sbt_pw8kO = 0;
		sbt_P.clear();
		sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo = 0;
		sbt_23L.clear();
		sbt_B7Y.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.push_back(2791524711838722304);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_s.push_back(2783271799);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.push_back(10450881910268346706);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ggK3_kOBldCEH8dfMJur044IKXu.push_back(16883695017895924100);
		}
		sbt_GZ1A6Wd7fBMFrQvJI = 8942879441965339848;
		sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os = 4502293404473491948;
		sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z = 36;
		sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY = 2500166147;
		sbt_8t_5Ejt = 27475;
		sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG = 16096722795555808708;
		sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41 = 252;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_xpSH4jjRbFj_U.push_back(false);
		}
		sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC = 3198;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.push_back(12375106920115562746);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt__ZrPeM1XDEHk2JW.push_back(917924573);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.push_back(192);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt__.push_back(3229794613);
		}
		sbt_pw8kO = -1768189529;
		sbt_P = "`Y@:]\\*:m>}:wdSY#aiS:j~TE!AXW*_Q\\@XXNe,24q8F+Y+gk?B*wB7v]Mte";
		sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo = 4180866675845015804;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_23L.push_back(-191992133285805016);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_B7Y.push_back(112);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x *pObject = dynamic_cast<const sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.size() != pObject->sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.size(); i++)
		{
			if (sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP[i] != pObject->sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP[i])
			{
				return false;
			}
		}
		if (sbt_s.size() != pObject->sbt_s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s.size(); i++)
		{
			if (sbt_s[i] != pObject->sbt_s[i])
			{
				return false;
			}
		}
		if (sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.size() != pObject->sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.size(); i++)
		{
			if (sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo[i] != pObject->sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo[i])
			{
				return false;
			}
		}
		if (sbt_ggK3_kOBldCEH8dfMJur044IKXu.size() != pObject->sbt_ggK3_kOBldCEH8dfMJur044IKXu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ggK3_kOBldCEH8dfMJur044IKXu.size(); i++)
		{
			if (sbt_ggK3_kOBldCEH8dfMJur044IKXu[i] != pObject->sbt_ggK3_kOBldCEH8dfMJur044IKXu[i])
			{
				return false;
			}
		}
		if (sbt_GZ1A6Wd7fBMFrQvJI != pObject->sbt_GZ1A6Wd7fBMFrQvJI)
		{
			return false;
		}
		if (sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os != pObject->sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os)
		{
			return false;
		}
		if (sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z != pObject->sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z)
		{
			return false;
		}
		if (sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY != pObject->sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY)
		{
			return false;
		}
		if (sbt_8t_5Ejt != pObject->sbt_8t_5Ejt)
		{
			return false;
		}
		if (sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG != pObject->sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG)
		{
			return false;
		}
		if (sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41 != pObject->sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41)
		{
			return false;
		}
		if (sbt_xpSH4jjRbFj_U.size() != pObject->sbt_xpSH4jjRbFj_U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xpSH4jjRbFj_U.size(); i++)
		{
			if (sbt_xpSH4jjRbFj_U[i] != pObject->sbt_xpSH4jjRbFj_U[i])
			{
				return false;
			}
		}
		if (sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC != pObject->sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC)
		{
			return false;
		}
		if (sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.size() != pObject->sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.size(); i++)
		{
			if (sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN[i] != pObject->sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN[i])
			{
				return false;
			}
		}
		if (sbt__ZrPeM1XDEHk2JW.size() != pObject->sbt__ZrPeM1XDEHk2JW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__ZrPeM1XDEHk2JW.size(); i++)
		{
			if (sbt__ZrPeM1XDEHk2JW[i] != pObject->sbt__ZrPeM1XDEHk2JW[i])
			{
				return false;
			}
		}
		if (sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.size() != pObject->sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.size(); i++)
		{
			if (sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F[i] != pObject->sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F[i])
			{
				return false;
			}
		}
		if (sbt__.size() != pObject->sbt__.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__.size(); i++)
		{
			if (sbt__[i] != pObject->sbt__[i])
			{
				return false;
			}
		}
		if (sbt_pw8kO != pObject->sbt_pw8kO)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_P.c_str(), pObject->sbt_P.c_str()))
		{
			return false;
		}
		if (sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo != pObject->sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo)
		{
			return false;
		}
		if (sbt_23L.size() != pObject->sbt_23L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_23L.size(); i++)
		{
			if (sbt_23L[i] != pObject->sbt_23L[i])
			{
				return false;
			}
		}
		if (sbt_B7Y.size() != pObject->sbt_B7Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B7Y.size(); i++)
		{
			if (sbt_B7Y[i] != pObject->sbt_B7Y[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ggK3_kOBldCEH8dfMJur044IKXu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ggK3_kOBldCEH8dfMJur044IKXu.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GZ1A6Wd7fBMFrQvJI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GZ1A6Wd7fBMFrQvJI = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8t_5Ejt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8t_5Ejt = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xpSH4jjRbFj_U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xpSH4jjRbFj_U.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__ZrPeM1XDEHk2JW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__ZrPeM1XDEHk2JW.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pw8kO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pw8kO = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_P", &sbt_P)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_23L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_23L.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_B7Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B7Y.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.begin(); iter != sbt_bP_Yp1P2rSjLBnVAz3wwzj5f7mP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_s.begin(); iter != sbt_s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.begin(); iter != sbt_XFfwEagG6w_7unSS7Wr_MJsRGdaRO5gZds5XNxQlwYuXW27imPa7KGxp4YZPo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ggK3_kOBldCEH8dfMJur044IKXu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ggK3_kOBldCEH8dfMJur044IKXu.begin(); iter != sbt_ggK3_kOBldCEH8dfMJur044IKXu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GZ1A6Wd7fBMFrQvJI", (CX::Int64)sbt_GZ1A6Wd7fBMFrQvJI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os", (CX::Int64)sbt_kkYZfHWuK6ECY8f_R6uMslBwMavQ5qwE8os)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z", (CX::Int64)sbt_6bviyGduF17r8e5LljlFlSNY7NILJDWbM3wD1yrcKkk8Zn7SN7itO2Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY", (CX::Int64)sbt_jF1ChyVHlO7kHyH1IRTipjDZAA_euvY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8t_5Ejt", (CX::Int64)sbt_8t_5Ejt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG", (CX::Int64)sbt_cfnKW0ya2t_QWeWSwHEhW3_0guQWAUcsBMEXfdrqg2BB4mG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41", (CX::Int64)sbt_dCiIxRUrx6cUBF8m0zLspiVWadRao5kySHWgz41)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xpSH4jjRbFj_U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_xpSH4jjRbFj_U.begin(); iter != sbt_xpSH4jjRbFj_U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC", (CX::Int64)sbt_gmTvWzMqgjqGWYDTwfv28UI80K9_9sBukkC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.begin(); iter != sbt_8vZVfUEq4yqOYJBims7Sqaa9JJDBIN4a0LGXN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__ZrPeM1XDEHk2JW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt__ZrPeM1XDEHk2JW.begin(); iter != sbt__ZrPeM1XDEHk2JW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.begin(); iter != sbt_YxsGof3x7KYwIBnowZQiL5hsFcqako99LSRjNz555uZC9r1rNMbqmyZ8F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt__.begin(); iter != sbt__.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pw8kO", (CX::Int64)sbt_pw8kO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_P", sbt_P.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo", (CX::Int64)sbt_jgCaPlPtFoFdj_f6Z0xzMyuREtUKfBjg_VKdS7UZwnlp4yo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_23L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_23L.begin(); iter != sbt_23L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B7Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_B7Y.begin(); iter != sbt_B7Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x>::Type sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7xArray;

