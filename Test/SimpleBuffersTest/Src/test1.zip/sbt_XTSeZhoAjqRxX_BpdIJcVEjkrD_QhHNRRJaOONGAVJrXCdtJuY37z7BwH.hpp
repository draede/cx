
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r.hpp"


class sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd;
	CX::String sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b;
	CX::Double sbt_iDVbh7tCOpmf5OgmQ;
	CX::WString sbt_irqSl;
	CX::IO::SimpleBuffers::Int16Array sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1;
	CX::UInt8 sbt_OwyXTvCqa;
	CX::IO::SimpleBuffers::UInt32Array sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN;
	sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972rArray sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2;

	virtual void Reset()
	{
		sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.clear();
		sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b.clear();
		sbt_iDVbh7tCOpmf5OgmQ = 0.0;
		sbt_irqSl.clear();
		sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.clear();
		sbt_OwyXTvCqa = 0;
		sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.clear();
		sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.push_back(818699475694165818);
		}
		sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b = "PKNt>ijpnn/+^tAX35ZsF\"ZU4B}de*xN$L;Dp^\"Ev6hs]5B~#;qF5(w9buIC}t";
		sbt_iDVbh7tCOpmf5OgmQ = 0.381841;
		sbt_irqSl = L"";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.push_back(-6611);
		}
		sbt_OwyXTvCqa = 84;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.push_back(804228091);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH *pObject = dynamic_cast<const sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.size() != pObject->sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.size(); i++)
		{
			if (sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd[i] != pObject->sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b.c_str(), pObject->sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b.c_str()))
		{
			return false;
		}
		if (sbt_iDVbh7tCOpmf5OgmQ != pObject->sbt_iDVbh7tCOpmf5OgmQ)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_irqSl.c_str(), pObject->sbt_irqSl.c_str()))
		{
			return false;
		}
		if (sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.size() != pObject->sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.size(); i++)
		{
			if (sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1[i] != pObject->sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1[i])
			{
				return false;
			}
		}
		if (sbt_OwyXTvCqa != pObject->sbt_OwyXTvCqa)
		{
			return false;
		}
		if (sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.size() != pObject->sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.size(); i++)
		{
			if (sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN[i] != pObject->sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN[i])
			{
				return false;
			}
		}
		if (sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.size() != pObject->sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.size(); i++)
		{
			if (!sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2[i].Compare(&pObject->sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b", &sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_iDVbh7tCOpmf5OgmQ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_iDVbh7tCOpmf5OgmQ = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_irqSl", &sbt_irqSl)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OwyXTvCqa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OwyXTvCqa = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.begin(); iter != sbt_BT2zj_9SZFMu3_oVmVaaGVjWgQvzxAjpIp_LVhvaf6Y5jMH_gkRqJhucd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b", sbt_YiKHv3ePjWGfz2EskTMg5slNytA3UOk1n8b.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_iDVbh7tCOpmf5OgmQ", (CX::Double)sbt_iDVbh7tCOpmf5OgmQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_irqSl", sbt_irqSl.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.begin(); iter != sbt_AKOhrgT7Hu5IW1PpXWdUd1Ir3swcOe5oNQn2JWzzqPMbOjnG0KYyt0NGWH1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OwyXTvCqa", (CX::Int64)sbt_OwyXTvCqa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.begin(); iter != sbt_EsbGgCVmuqPuTk8_eqEP8sTR3NlVaoauGd9lXAjFvoF8FcVEWooJbO9QN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2")).IsNOK())
		{
			return status;
		}
		for (sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972rArray::const_iterator iter = sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.begin(); iter != sbt_Zz8PaPQNX9xOIEMkxEP_nFEjgGXEGqfKRyOUV8md_DZFw4uAuzeI2.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH>::Type sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwHArray;

