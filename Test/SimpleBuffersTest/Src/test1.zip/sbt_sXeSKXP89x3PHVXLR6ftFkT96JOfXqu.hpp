
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_yHtdD6gIK6n;
	CX::Bool sbt_e;
	CX::IO::SimpleBuffers::Int16Array sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT;
	CX::IO::SimpleBuffers::UInt8Array sbt_UjlD0;
	CX::IO::SimpleBuffers::UInt64Array sbt_P5WybOyTNcD8i1myqZrkd;
	CX::Int64 sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ;
	CX::UInt32 sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66;
	CX::UInt32 sbt_rMmsOjLM9YQxy;
	CX::IO::SimpleBuffers::StringArray sbt_l_KrBn3DESrYlwa;
	CX::IO::SimpleBuffers::UInt32Array sbt_wNd7vTb8FmnC2nsgxiUL7;
	CX::Int64 sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d;
	CX::IO::SimpleBuffers::Int32Array sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI;
	CX::Int64 sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a;
	CX::IO::SimpleBuffers::Int64Array sbt_FJtA45Dpo2aIl00Fv;

	virtual void Reset()
	{
		sbt_yHtdD6gIK6n = 0;
		sbt_e = false;
		sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.clear();
		sbt_UjlD0.clear();
		sbt_P5WybOyTNcD8i1myqZrkd.clear();
		sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ = 0;
		sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66 = 0;
		sbt_rMmsOjLM9YQxy = 0;
		sbt_l_KrBn3DESrYlwa.clear();
		sbt_wNd7vTb8FmnC2nsgxiUL7.clear();
		sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d = 0;
		sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.clear();
		sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a = 0;
		sbt_FJtA45Dpo2aIl00Fv.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_yHtdD6gIK6n = -2990395756584825368;
		sbt_e = false;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.push_back(-22542);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_UjlD0.push_back(210);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_P5WybOyTNcD8i1myqZrkd.push_back(17096689501210789172);
		}
		sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ = -4042636673548756216;
		sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66 = 3553953028;
		sbt_rMmsOjLM9YQxy = 2546618157;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_l_KrBn3DESrYlwa.push_back(",j?1G{qcJ8^s?Z\"!2x:i9pd/vRUMi8ky9-{^&~'Mm+KY\"w4@!88RYcfErK6i");
		}
		sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d = -5196830229600119016;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.push_back(-58617329);
		}
		sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a = -6070400177969604944;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_FJtA45Dpo2aIl00Fv.push_back(5324007449334751302);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu *pObject = dynamic_cast<const sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_yHtdD6gIK6n != pObject->sbt_yHtdD6gIK6n)
		{
			return false;
		}
		if (sbt_e != pObject->sbt_e)
		{
			return false;
		}
		if (sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.size() != pObject->sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.size(); i++)
		{
			if (sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT[i] != pObject->sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT[i])
			{
				return false;
			}
		}
		if (sbt_UjlD0.size() != pObject->sbt_UjlD0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UjlD0.size(); i++)
		{
			if (sbt_UjlD0[i] != pObject->sbt_UjlD0[i])
			{
				return false;
			}
		}
		if (sbt_P5WybOyTNcD8i1myqZrkd.size() != pObject->sbt_P5WybOyTNcD8i1myqZrkd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P5WybOyTNcD8i1myqZrkd.size(); i++)
		{
			if (sbt_P5WybOyTNcD8i1myqZrkd[i] != pObject->sbt_P5WybOyTNcD8i1myqZrkd[i])
			{
				return false;
			}
		}
		if (sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ != pObject->sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ)
		{
			return false;
		}
		if (sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66 != pObject->sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66)
		{
			return false;
		}
		if (sbt_rMmsOjLM9YQxy != pObject->sbt_rMmsOjLM9YQxy)
		{
			return false;
		}
		if (sbt_l_KrBn3DESrYlwa.size() != pObject->sbt_l_KrBn3DESrYlwa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l_KrBn3DESrYlwa.size(); i++)
		{
			if (0 != cx_strcmp(sbt_l_KrBn3DESrYlwa[i].c_str(), pObject->sbt_l_KrBn3DESrYlwa[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_wNd7vTb8FmnC2nsgxiUL7.size() != pObject->sbt_wNd7vTb8FmnC2nsgxiUL7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wNd7vTb8FmnC2nsgxiUL7.size(); i++)
		{
			if (sbt_wNd7vTb8FmnC2nsgxiUL7[i] != pObject->sbt_wNd7vTb8FmnC2nsgxiUL7[i])
			{
				return false;
			}
		}
		if (sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d != pObject->sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d)
		{
			return false;
		}
		if (sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.size() != pObject->sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.size(); i++)
		{
			if (sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI[i] != pObject->sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI[i])
			{
				return false;
			}
		}
		if (sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a != pObject->sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a)
		{
			return false;
		}
		if (sbt_FJtA45Dpo2aIl00Fv.size() != pObject->sbt_FJtA45Dpo2aIl00Fv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FJtA45Dpo2aIl00Fv.size(); i++)
		{
			if (sbt_FJtA45Dpo2aIl00Fv[i] != pObject->sbt_FJtA45Dpo2aIl00Fv[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_yHtdD6gIK6n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yHtdD6gIK6n = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_e", &sbt_e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UjlD0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UjlD0.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P5WybOyTNcD8i1myqZrkd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P5WybOyTNcD8i1myqZrkd.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rMmsOjLM9YQxy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rMmsOjLM9YQxy = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_l_KrBn3DESrYlwa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l_KrBn3DESrYlwa.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wNd7vTb8FmnC2nsgxiUL7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wNd7vTb8FmnC2nsgxiUL7.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FJtA45Dpo2aIl00Fv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FJtA45Dpo2aIl00Fv.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_yHtdD6gIK6n", (CX::Int64)sbt_yHtdD6gIK6n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_e", sbt_e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.begin(); iter != sbt_2hTfSzBix6TUqX0DHA_ffX8vlcT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UjlD0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_UjlD0.begin(); iter != sbt_UjlD0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P5WybOyTNcD8i1myqZrkd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_P5WybOyTNcD8i1myqZrkd.begin(); iter != sbt_P5WybOyTNcD8i1myqZrkd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ", (CX::Int64)sbt_NUeAVcujhsDZZTnicQniGvPYn6wpJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66", (CX::Int64)sbt_KTdqfETLnpFWFWkB95iODhSvIMuFCXupiQlRm66)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rMmsOjLM9YQxy", (CX::Int64)sbt_rMmsOjLM9YQxy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l_KrBn3DESrYlwa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_l_KrBn3DESrYlwa.begin(); iter != sbt_l_KrBn3DESrYlwa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wNd7vTb8FmnC2nsgxiUL7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_wNd7vTb8FmnC2nsgxiUL7.begin(); iter != sbt_wNd7vTb8FmnC2nsgxiUL7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d", (CX::Int64)sbt_KAW2BOb5hdEJJtSkcUvDORH5CeP_brwSbYusOU7v9q8z0pcJlnDCxgCVLsA8d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.begin(); iter != sbt_maHvk2FSmo851P0qKMSy5FEqD8SmbURBDv9Fj9OfalgyrX4RuAI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a", (CX::Int64)sbt_fekzWZZ_lkpcjXiRaG_iSCLJcQzhAzXQ7641a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FJtA45Dpo2aIl00Fv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_FJtA45Dpo2aIl00Fv.begin(); iter != sbt_FJtA45Dpo2aIl00Fv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu>::Type sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXquArray;

