
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ;
	CX::IO::SimpleBuffers::UInt32Array sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6;
	CX::Int32 sbt_Ea6MkPO1fSDKBieBA_DVarGpi;
	CX::UInt32 sbt_PwrsDuu_FZjoq;
	CX::UInt64 sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf;
	CX::IO::SimpleBuffers::Int8Array sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j;
	CX::IO::SimpleBuffers::UInt32Array sbt_WEIIY;

	virtual void Reset()
	{
		sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ = 0;
		sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.clear();
		sbt_Ea6MkPO1fSDKBieBA_DVarGpi = 0;
		sbt_PwrsDuu_FZjoq = 0;
		sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf = 0;
		sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.clear();
		sbt_WEIIY.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ = 9781282321996773142;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.push_back(299004074);
		}
		sbt_Ea6MkPO1fSDKBieBA_DVarGpi = 29521734;
		sbt_PwrsDuu_FZjoq = 1535288032;
		sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf = 7833693737838343692;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_WEIIY.push_back(2685968981);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp *pObject = dynamic_cast<const sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ != pObject->sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ)
		{
			return false;
		}
		if (sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.size() != pObject->sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.size(); i++)
		{
			if (sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6[i] != pObject->sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6[i])
			{
				return false;
			}
		}
		if (sbt_Ea6MkPO1fSDKBieBA_DVarGpi != pObject->sbt_Ea6MkPO1fSDKBieBA_DVarGpi)
		{
			return false;
		}
		if (sbt_PwrsDuu_FZjoq != pObject->sbt_PwrsDuu_FZjoq)
		{
			return false;
		}
		if (sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf != pObject->sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf)
		{
			return false;
		}
		if (sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.size() != pObject->sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.size(); i++)
		{
			if (sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j[i] != pObject->sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j[i])
			{
				return false;
			}
		}
		if (sbt_WEIIY.size() != pObject->sbt_WEIIY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WEIIY.size(); i++)
		{
			if (sbt_WEIIY[i] != pObject->sbt_WEIIY[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Ea6MkPO1fSDKBieBA_DVarGpi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ea6MkPO1fSDKBieBA_DVarGpi = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_PwrsDuu_FZjoq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PwrsDuu_FZjoq = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WEIIY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WEIIY.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ", (CX::Int64)sbt_YTdZE2to8D2CAiWVOKsSz5kyhhpRhOGfIqKAQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.begin(); iter != sbt_3rI3bDHWbG4cM1kNL_l2ElucOA1O_oUs3BT7z6PD6_6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ea6MkPO1fSDKBieBA_DVarGpi", (CX::Int64)sbt_Ea6MkPO1fSDKBieBA_DVarGpi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PwrsDuu_FZjoq", (CX::Int64)sbt_PwrsDuu_FZjoq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf", (CX::Int64)sbt_czYNboFJvON1FFqW01JXTp1o3pU6aKqz7J7kf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.begin(); iter != sbt_y9udnIrKm2OjaCNB8ervi3Lztih6coyPeHkISwMmvIEIjZHewEOnk9Pbw9oKw5j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WEIIY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_WEIIY.begin(); iter != sbt_WEIIY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp>::Type sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jpArray;

