
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w.hpp"


class sbt_0Mk8Rck1rfINzZy : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3;
	CX::IO::SimpleBuffers::Int16Array sbt_H;
	sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1wArray sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy;

	virtual void Reset()
	{
		sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3.clear();
		sbt_H.clear();
		sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3 = ".ew}zY3U7i\\q-8E#bh6$:W&GGq8`";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_0Mk8Rck1rfINzZy *pObject = dynamic_cast<const sbt_0Mk8Rck1rfINzZy *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3.c_str(), pObject->sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3.c_str()))
		{
			return false;
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.size() != pObject->sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.size(); i++)
		{
			if (!sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy[i].Compare(&pObject->sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3", &sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3", sbt_kvfp3wJGLccC_gZKROhhumW8ma9B9n2jOScd3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy")).IsNOK())
		{
			return status;
		}
		for (sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1wArray::const_iterator iter = sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.begin(); iter != sbt_FxxG9dPTm1Wfhr_Y2qemMyRAgeiWUNvbG2uqR9v0dLCxy.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_0Mk8Rck1rfINzZy>::Type sbt_0Mk8Rck1rfINzZyArray;

