
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_Agn40ySHp1dKM3X847XwHuihWUF3k;
	CX::IO::SimpleBuffers::StringArray sbt_H4zbM976giNxeKG58VUBz_GQJ;
	CX::UInt32 sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4;
	CX::IO::SimpleBuffers::UInt32Array sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio;
	CX::IO::SimpleBuffers::StringArray sbt_2FD__0W9rVnVv3qzJ;
	CX::IO::SimpleBuffers::Int32Array sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM;
	CX::Int8 sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8;
	CX::IO::SimpleBuffers::UInt64Array sbt_yAa1abnP7gVgh;
	CX::Int32 sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a;
	CX::UInt16 sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z;
	CX::UInt16 sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b;

	virtual void Reset()
	{
		sbt_Agn40ySHp1dKM3X847XwHuihWUF3k = 0;
		sbt_H4zbM976giNxeKG58VUBz_GQJ.clear();
		sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4 = 0;
		sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.clear();
		sbt_2FD__0W9rVnVv3qzJ.clear();
		sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.clear();
		sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8 = 0;
		sbt_yAa1abnP7gVgh.clear();
		sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a = 0;
		sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z = 0;
		sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Agn40ySHp1dKM3X847XwHuihWUF3k = 55;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_H4zbM976giNxeKG58VUBz_GQJ.push_back("z7)QcP:5hjEN+vF,UmZ8vQK,x6PaLS/{go\\UGJL=tLoW):8yHyf]aP");
		}
		sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4 = 1400853946;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.push_back(2172297281);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_2FD__0W9rVnVv3qzJ.push_back("A{XFi|J^O&p5pb&$c^qWFB-q:GRHWwJ+{nH!jX.}4P\"TMoQo0g");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.push_back(1830326584);
		}
		sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8 = 64;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_yAa1abnP7gVgh.push_back(18055799074603886250);
		}
		sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a = 873881138;
		sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z = 4723;
		sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b = 4346;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU *pObject = dynamic_cast<const sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Agn40ySHp1dKM3X847XwHuihWUF3k != pObject->sbt_Agn40ySHp1dKM3X847XwHuihWUF3k)
		{
			return false;
		}
		if (sbt_H4zbM976giNxeKG58VUBz_GQJ.size() != pObject->sbt_H4zbM976giNxeKG58VUBz_GQJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H4zbM976giNxeKG58VUBz_GQJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_H4zbM976giNxeKG58VUBz_GQJ[i].c_str(), pObject->sbt_H4zbM976giNxeKG58VUBz_GQJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4 != pObject->sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4)
		{
			return false;
		}
		if (sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.size() != pObject->sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.size(); i++)
		{
			if (sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio[i] != pObject->sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio[i])
			{
				return false;
			}
		}
		if (sbt_2FD__0W9rVnVv3qzJ.size() != pObject->sbt_2FD__0W9rVnVv3qzJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2FD__0W9rVnVv3qzJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_2FD__0W9rVnVv3qzJ[i].c_str(), pObject->sbt_2FD__0W9rVnVv3qzJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.size() != pObject->sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.size(); i++)
		{
			if (sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM[i] != pObject->sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM[i])
			{
				return false;
			}
		}
		if (sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8 != pObject->sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8)
		{
			return false;
		}
		if (sbt_yAa1abnP7gVgh.size() != pObject->sbt_yAa1abnP7gVgh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yAa1abnP7gVgh.size(); i++)
		{
			if (sbt_yAa1abnP7gVgh[i] != pObject->sbt_yAa1abnP7gVgh[i])
			{
				return false;
			}
		}
		if (sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a != pObject->sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a)
		{
			return false;
		}
		if (sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z != pObject->sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z)
		{
			return false;
		}
		if (sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b != pObject->sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_Agn40ySHp1dKM3X847XwHuihWUF3k", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Agn40ySHp1dKM3X847XwHuihWUF3k = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_H4zbM976giNxeKG58VUBz_GQJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H4zbM976giNxeKG58VUBz_GQJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2FD__0W9rVnVv3qzJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2FD__0W9rVnVv3qzJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yAa1abnP7gVgh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yAa1abnP7gVgh.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_Agn40ySHp1dKM3X847XwHuihWUF3k", (CX::Int64)sbt_Agn40ySHp1dKM3X847XwHuihWUF3k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H4zbM976giNxeKG58VUBz_GQJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_H4zbM976giNxeKG58VUBz_GQJ.begin(); iter != sbt_H4zbM976giNxeKG58VUBz_GQJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4", (CX::Int64)sbt_eaW0XYdAGLL3UYbz3RjcOeqoP5dMez4wkdajCxKnPaLhwkR28s4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.begin(); iter != sbt_t8copQyvit_cyLZnPW0En5HjxD_lgxIbLio.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2FD__0W9rVnVv3qzJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_2FD__0W9rVnVv3qzJ.begin(); iter != sbt_2FD__0W9rVnVv3qzJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.begin(); iter != sbt_518_O6WerfZUoBSimWTdjob1MBZpxHBCLn069pCYXBrGs62uRI866iELM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8", (CX::Int64)sbt_sgXwolmOQTkeuBpCgS5Elx8EQ3gZWo8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yAa1abnP7gVgh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yAa1abnP7gVgh.begin(); iter != sbt_yAa1abnP7gVgh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a", (CX::Int64)sbt_sg4MUdRVJqxqRSurup9An_oObDqN1lH2Jp7eqX8rQNUEgYnGW0a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z", (CX::Int64)sbt_91jv0Ix5WkRpNDBgHs4fqcp0Wa3VS0OkY2oI18bzEEJ0Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b", (CX::Int64)sbt_MavgHiMmBdR9dsmht1WO_3EQ89hO0W8jLdOjtcGIE0b)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU>::Type sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJUArray;

