
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN;
	CX::IO::SimpleBuffers::Int16Array sbt_C;
	CX::UInt32 sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW;
	CX::IO::SimpleBuffers::UInt64Array sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H;
	CX::IO::SimpleBuffers::Int32Array sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3;
	CX::IO::SimpleBuffers::UInt64Array sbt_1riB8t9zBEy4uorseol;
	CX::Int8 sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_;
	CX::Int64 sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE;
	CX::IO::SimpleBuffers::UInt32Array sbt_2d1IP;
	CX::IO::SimpleBuffers::UInt32Array sbt_R;
	CX::String sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ;
	CX::IO::SimpleBuffers::Int16Array sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl;
	CX::Bool sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH;
	CX::IO::SimpleBuffers::UInt16Array sbt_qAbsriejy_oYfn9W0Gwsy;
	CX::UInt64 sbt_EbjrmqojrMMfeb6;
	CX::IO::SimpleBuffers::UInt8Array sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa;

	virtual void Reset()
	{
		sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN = 0;
		sbt_C.clear();
		sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW = 0;
		sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.clear();
		sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.clear();
		sbt_1riB8t9zBEy4uorseol.clear();
		sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_ = 0;
		sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE = 0;
		sbt_2d1IP.clear();
		sbt_R.clear();
		sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ.clear();
		sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.clear();
		sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH = false;
		sbt_qAbsriejy_oYfn9W0Gwsy.clear();
		sbt_EbjrmqojrMMfeb6 = 0;
		sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN = 286758668;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_C.push_back(15806);
		}
		sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW = 1607130308;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.push_back(7775235270791209690);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.push_back(-1047777644);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_1riB8t9zBEy4uorseol.push_back(12196626651235988246);
		}
		sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_ = 48;
		sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE = -3556359310680695726;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_2d1IP.push_back(3203867092);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_R.push_back(1407079881);
		}
		sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ = ">np~dZGR[#t;(Q2'M,ECxza_nOdcF'Z}p4(";
		sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH = false;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_qAbsriejy_oYfn9W0Gwsy.push_back(40401);
		}
		sbt_EbjrmqojrMMfeb6 = 3024349020865780624;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.push_back(116);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW *pObject = dynamic_cast<const sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN != pObject->sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN)
		{
			return false;
		}
		if (sbt_C.size() != pObject->sbt_C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C.size(); i++)
		{
			if (sbt_C[i] != pObject->sbt_C[i])
			{
				return false;
			}
		}
		if (sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW != pObject->sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW)
		{
			return false;
		}
		if (sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.size() != pObject->sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.size(); i++)
		{
			if (sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H[i] != pObject->sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H[i])
			{
				return false;
			}
		}
		if (sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.size() != pObject->sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.size(); i++)
		{
			if (sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3[i] != pObject->sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3[i])
			{
				return false;
			}
		}
		if (sbt_1riB8t9zBEy4uorseol.size() != pObject->sbt_1riB8t9zBEy4uorseol.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1riB8t9zBEy4uorseol.size(); i++)
		{
			if (sbt_1riB8t9zBEy4uorseol[i] != pObject->sbt_1riB8t9zBEy4uorseol[i])
			{
				return false;
			}
		}
		if (sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_ != pObject->sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_)
		{
			return false;
		}
		if (sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE != pObject->sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE)
		{
			return false;
		}
		if (sbt_2d1IP.size() != pObject->sbt_2d1IP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2d1IP.size(); i++)
		{
			if (sbt_2d1IP[i] != pObject->sbt_2d1IP[i])
			{
				return false;
			}
		}
		if (sbt_R.size() != pObject->sbt_R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R.size(); i++)
		{
			if (sbt_R[i] != pObject->sbt_R[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ.c_str(), pObject->sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ.c_str()))
		{
			return false;
		}
		if (sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.size() != pObject->sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.size(); i++)
		{
			if (sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl[i] != pObject->sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl[i])
			{
				return false;
			}
		}
		if (sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH != pObject->sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH)
		{
			return false;
		}
		if (sbt_qAbsriejy_oYfn9W0Gwsy.size() != pObject->sbt_qAbsriejy_oYfn9W0Gwsy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qAbsriejy_oYfn9W0Gwsy.size(); i++)
		{
			if (sbt_qAbsriejy_oYfn9W0Gwsy[i] != pObject->sbt_qAbsriejy_oYfn9W0Gwsy[i])
			{
				return false;
			}
		}
		if (sbt_EbjrmqojrMMfeb6 != pObject->sbt_EbjrmqojrMMfeb6)
		{
			return false;
		}
		if (sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.size() != pObject->sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.size(); i++)
		{
			if (sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa[i] != pObject->sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1riB8t9zBEy4uorseol")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1riB8t9zBEy4uorseol.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2d1IP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2d1IP.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ", &sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH", &sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qAbsriejy_oYfn9W0Gwsy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qAbsriejy_oYfn9W0Gwsy.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EbjrmqojrMMfeb6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EbjrmqojrMMfeb6 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN", (CX::Int64)sbt_mFlgUsrCR9OrYejK4BpVAHEuKQN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_C.begin(); iter != sbt_C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW", (CX::Int64)sbt_A7A4qndBpsDohz_h7oGFMGqJ9k6YvCwMhmUlW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.begin(); iter != sbt_FmN893GVKWvvgCz87bgtCwb3cuhsw5w2k4wAaMk9oSc5H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.begin(); iter != sbt_xwKRaN9WJXaAW77bYI6pBQ3hP_hCwv0zUVav5igf3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1riB8t9zBEy4uorseol")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_1riB8t9zBEy4uorseol.begin(); iter != sbt_1riB8t9zBEy4uorseol.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_", (CX::Int64)sbt_XqqrQPApEuPv0KfyfxyMFWIXKsXymWNm_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE", (CX::Int64)sbt_i_4nfvguJY6W_wSzRyn65R9K28gdZhE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2d1IP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_2d1IP.begin(); iter != sbt_2d1IP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_R.begin(); iter != sbt_R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ", sbt_PFB6mp67_aR8mFR6NO29drHQt3w3LkXjQOurh4ZiZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.begin(); iter != sbt_s3mkiN9aHvNFxOEeKUsAA4tU73zEomPYKkl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH", sbt_aJXYjzyNUPDlgH1Wc8qjYDqBKtM28tClUqLmYzH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qAbsriejy_oYfn9W0Gwsy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_qAbsriejy_oYfn9W0Gwsy.begin(); iter != sbt_qAbsriejy_oYfn9W0Gwsy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EbjrmqojrMMfeb6", (CX::Int64)sbt_EbjrmqojrMMfeb6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.begin(); iter != sbt_PRapkjaoOhupIBu1mvYsbI72nkBrVEDcTzQQMC4TBkiK67aSdQ8gEDXsNcKM3Aa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW>::Type sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrWArray;

