
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_E.hpp"


class sbt_3UdYyNZlY8degDivo : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_fFznzpfsxm4tvM4Qy13FYbSNy;
	CX::Double sbt_fUzkXBjKzSCbrRA6Iqb;
	CX::Int8 sbt_esKf5zJSssiKnVEb1;
	CX::IO::SimpleBuffers::UInt16Array sbt_Tes5vdE3pAgGT14RZBFzG_Q;
	CX::IO::SimpleBuffers::UInt64Array sbt_JWsl83a;
	CX::Int8 sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0;
	CX::UInt16 sbt_EIj_4pOaLMr3QhAzzQB;
	CX::UInt8 sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt;
	CX::IO::SimpleBuffers::FloatArray sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2;
	CX::UInt32 sbt_tZ305u8TbTWcyJU;
	CX::IO::SimpleBuffers::UInt32Array sbt_FcFdFQHsZ60;
	CX::IO::SimpleBuffers::DoubleArray sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL;
	CX::IO::SimpleBuffers::Int8Array sbt_AhbkJWBaOT4AUzuWgoy80Y0;
	CX::Bool sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7;
	CX::Int64 sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN;
	CX::IO::SimpleBuffers::Int64Array sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD;
	CX::Int32 sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo;
	CX::String sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9;
	CX::IO::SimpleBuffers::StringArray sbt_BRJeL6PrxFN7B4hcSB3;
	sbt_EArray sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W;

	virtual void Reset()
	{
		sbt_fFznzpfsxm4tvM4Qy13FYbSNy = 0;
		sbt_fUzkXBjKzSCbrRA6Iqb = 0.0;
		sbt_esKf5zJSssiKnVEb1 = 0;
		sbt_Tes5vdE3pAgGT14RZBFzG_Q.clear();
		sbt_JWsl83a.clear();
		sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0 = 0;
		sbt_EIj_4pOaLMr3QhAzzQB = 0;
		sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt = 0;
		sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.clear();
		sbt_tZ305u8TbTWcyJU = 0;
		sbt_FcFdFQHsZ60.clear();
		sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.clear();
		sbt_AhbkJWBaOT4AUzuWgoy80Y0.clear();
		sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7 = false;
		sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN = 0;
		sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.clear();
		sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo = 0;
		sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9.clear();
		sbt_BRJeL6PrxFN7B4hcSB3.clear();
		sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_fFznzpfsxm4tvM4Qy13FYbSNy = 672006268;
		sbt_fUzkXBjKzSCbrRA6Iqb = 0.180038;
		sbt_esKf5zJSssiKnVEb1 = 86;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Tes5vdE3pAgGT14RZBFzG_Q.push_back(56093);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_JWsl83a.push_back(3614800259420412616);
		}
		sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0 = -38;
		sbt_EIj_4pOaLMr3QhAzzQB = 12577;
		sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt = 248;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.push_back(0.452695f);
		}
		sbt_tZ305u8TbTWcyJU = 572164194;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_FcFdFQHsZ60.push_back(861277400);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.push_back(0.439666);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_AhbkJWBaOT4AUzuWgoy80Y0.push_back(-88);
		}
		sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7 = true;
		sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN = 211484303927573132;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.push_back(-4562243665187880996);
		}
		sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo = 555834628;
		sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9 = "_2GJ7HNs}";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_BRJeL6PrxFN7B4hcSB3.push_back("O/,%FEX_7#");
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_E v;

			v.SetupWithSomeValues();
			sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3UdYyNZlY8degDivo *pObject = dynamic_cast<const sbt_3UdYyNZlY8degDivo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_fFznzpfsxm4tvM4Qy13FYbSNy != pObject->sbt_fFznzpfsxm4tvM4Qy13FYbSNy)
		{
			return false;
		}
		if (sbt_fUzkXBjKzSCbrRA6Iqb != pObject->sbt_fUzkXBjKzSCbrRA6Iqb)
		{
			return false;
		}
		if (sbt_esKf5zJSssiKnVEb1 != pObject->sbt_esKf5zJSssiKnVEb1)
		{
			return false;
		}
		if (sbt_Tes5vdE3pAgGT14RZBFzG_Q.size() != pObject->sbt_Tes5vdE3pAgGT14RZBFzG_Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Tes5vdE3pAgGT14RZBFzG_Q.size(); i++)
		{
			if (sbt_Tes5vdE3pAgGT14RZBFzG_Q[i] != pObject->sbt_Tes5vdE3pAgGT14RZBFzG_Q[i])
			{
				return false;
			}
		}
		if (sbt_JWsl83a.size() != pObject->sbt_JWsl83a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JWsl83a.size(); i++)
		{
			if (sbt_JWsl83a[i] != pObject->sbt_JWsl83a[i])
			{
				return false;
			}
		}
		if (sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0 != pObject->sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0)
		{
			return false;
		}
		if (sbt_EIj_4pOaLMr3QhAzzQB != pObject->sbt_EIj_4pOaLMr3QhAzzQB)
		{
			return false;
		}
		if (sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt != pObject->sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt)
		{
			return false;
		}
		if (sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.size() != pObject->sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.size(); i++)
		{
			if (sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2[i] != pObject->sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2[i])
			{
				return false;
			}
		}
		if (sbt_tZ305u8TbTWcyJU != pObject->sbt_tZ305u8TbTWcyJU)
		{
			return false;
		}
		if (sbt_FcFdFQHsZ60.size() != pObject->sbt_FcFdFQHsZ60.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FcFdFQHsZ60.size(); i++)
		{
			if (sbt_FcFdFQHsZ60[i] != pObject->sbt_FcFdFQHsZ60[i])
			{
				return false;
			}
		}
		if (sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.size() != pObject->sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.size(); i++)
		{
			if (sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL[i] != pObject->sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL[i])
			{
				return false;
			}
		}
		if (sbt_AhbkJWBaOT4AUzuWgoy80Y0.size() != pObject->sbt_AhbkJWBaOT4AUzuWgoy80Y0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AhbkJWBaOT4AUzuWgoy80Y0.size(); i++)
		{
			if (sbt_AhbkJWBaOT4AUzuWgoy80Y0[i] != pObject->sbt_AhbkJWBaOT4AUzuWgoy80Y0[i])
			{
				return false;
			}
		}
		if (sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7 != pObject->sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7)
		{
			return false;
		}
		if (sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN != pObject->sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN)
		{
			return false;
		}
		if (sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.size() != pObject->sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.size(); i++)
		{
			if (sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD[i] != pObject->sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD[i])
			{
				return false;
			}
		}
		if (sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo != pObject->sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9.c_str(), pObject->sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9.c_str()))
		{
			return false;
		}
		if (sbt_BRJeL6PrxFN7B4hcSB3.size() != pObject->sbt_BRJeL6PrxFN7B4hcSB3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BRJeL6PrxFN7B4hcSB3.size(); i++)
		{
			if (0 != cx_strcmp(sbt_BRJeL6PrxFN7B4hcSB3[i].c_str(), pObject->sbt_BRJeL6PrxFN7B4hcSB3[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.size() != pObject->sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.size(); i++)
		{
			if (!sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W[i].Compare(&pObject->sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_fFznzpfsxm4tvM4Qy13FYbSNy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fFznzpfsxm4tvM4Qy13FYbSNy = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_fUzkXBjKzSCbrRA6Iqb", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fUzkXBjKzSCbrRA6Iqb = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_esKf5zJSssiKnVEb1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_esKf5zJSssiKnVEb1 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Tes5vdE3pAgGT14RZBFzG_Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Tes5vdE3pAgGT14RZBFzG_Q.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JWsl83a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JWsl83a.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EIj_4pOaLMr3QhAzzQB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EIj_4pOaLMr3QhAzzQB = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tZ305u8TbTWcyJU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tZ305u8TbTWcyJU = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FcFdFQHsZ60")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FcFdFQHsZ60.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AhbkJWBaOT4AUzuWgoy80Y0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AhbkJWBaOT4AUzuWgoy80Y0.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7", &sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9", &sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BRJeL6PrxFN7B4hcSB3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BRJeL6PrxFN7B4hcSB3.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_E tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_fFznzpfsxm4tvM4Qy13FYbSNy", (CX::Int64)sbt_fFznzpfsxm4tvM4Qy13FYbSNy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fUzkXBjKzSCbrRA6Iqb", (CX::Double)sbt_fUzkXBjKzSCbrRA6Iqb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_esKf5zJSssiKnVEb1", (CX::Int64)sbt_esKf5zJSssiKnVEb1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Tes5vdE3pAgGT14RZBFzG_Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Tes5vdE3pAgGT14RZBFzG_Q.begin(); iter != sbt_Tes5vdE3pAgGT14RZBFzG_Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JWsl83a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_JWsl83a.begin(); iter != sbt_JWsl83a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0", (CX::Int64)sbt_llVRFIOk_x3L3UXume2ZkHTBqR8wvLIY_AYFcCPp0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EIj_4pOaLMr3QhAzzQB", (CX::Int64)sbt_EIj_4pOaLMr3QhAzzQB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt", (CX::Int64)sbt_hzeI76DybrhR7idoa2rR5allt5aAacOkCES1KvoBtPPHP9LMBZYar06S9pTEt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.begin(); iter != sbt_23wFWDN_cX5jmqLupT31ScQbxcKwXFvsXMcHfTVw9hjrAlSZ8L2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tZ305u8TbTWcyJU", (CX::Int64)sbt_tZ305u8TbTWcyJU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FcFdFQHsZ60")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FcFdFQHsZ60.begin(); iter != sbt_FcFdFQHsZ60.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.begin(); iter != sbt_UpSA0EcnuIDBX1Glh0uXjOnM9LPiL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AhbkJWBaOT4AUzuWgoy80Y0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_AhbkJWBaOT4AUzuWgoy80Y0.begin(); iter != sbt_AhbkJWBaOT4AUzuWgoy80Y0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7", sbt_M5mJpmxZoublVX73e2W9EZWycuq7M_PhrEL5tJ7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN", (CX::Int64)sbt_PN_aZk5QkENthJ1rgVat4V4BzmmJxgkRz8xv3eHI8vN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.begin(); iter != sbt_hEjHZYXG1LPJkoLwCaydnEDN7cOF1olzed2U8QioS5KlNkD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo", (CX::Int64)sbt_rbtFXqCRfQFJg2bde00CVMeltI9W5xELTlVyPLWJDyeMIEu5ksPQrv5EkuiRo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9", sbt_boXqKTI0pklQ0p5Vni9c60AQovqd7ZrA0K9.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BRJeL6PrxFN7B4hcSB3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_BRJeL6PrxFN7B4hcSB3.begin(); iter != sbt_BRJeL6PrxFN7B4hcSB3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W")).IsNOK())
		{
			return status;
		}
		for (sbt_EArray::const_iterator iter = sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.begin(); iter != sbt_TRjBQsw2VXdlU2uIuTaXc3woCLbnNaHH0eHBVRYwCA8CnOkTgj0vZ3W.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3UdYyNZlY8degDivo>::Type sbt_3UdYyNZlY8degDivoArray;

