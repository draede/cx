
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_F1HEPEiQDJ1M5hlke : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5;
	CX::String sbt_O;
	CX::Bool sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm;
	CX::Int64 sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P;
	CX::IO::SimpleBuffers::StringArray sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf;
	CX::UInt64 sbt_S2GbLXb4bh9;
	CX::IO::SimpleBuffers::Int64Array sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA;
	CX::IO::SimpleBuffers::UInt32Array sbt_5HECj31OymTB4hBctxFBvp8m8uf;
	CX::IO::SimpleBuffers::UInt64Array sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An;
	CX::IO::SimpleBuffers::Int64Array sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds;
	CX::IO::SimpleBuffers::UInt64Array sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi;
	CX::IO::SimpleBuffers::StringArray sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP;
	CX::String sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4;
	CX::IO::SimpleBuffers::UInt8Array sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL;
	CX::IO::SimpleBuffers::Int64Array sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj;
	CX::IO::SimpleBuffers::Int64Array sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3;
	CX::IO::SimpleBuffers::UInt16Array sbt_J2s4ujBi5mhhLKR0Z;

	virtual void Reset()
	{
		sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.clear();
		sbt_O.clear();
		sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm = false;
		sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P = 0;
		sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.clear();
		sbt_S2GbLXb4bh9 = 0;
		sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.clear();
		sbt_5HECj31OymTB4hBctxFBvp8m8uf.clear();
		sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.clear();
		sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.clear();
		sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.clear();
		sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.clear();
		sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4.clear();
		sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.clear();
		sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.clear();
		sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.clear();
		sbt_J2s4ujBi5mhhLKR0Z.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.push_back(10745701904002895922);
		}
		sbt_O = "R(S2Upy#Eh\"&M7Fu3L@&gWz+._}2hpkA-N$nN;@?wwQilNp";
		sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm = true;
		sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P = -4275411422027064350;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.push_back("(YNgmF(fhl&tV}UtW$$#Z#f12bT@!gR_Y;");
		}
		sbt_S2GbLXb4bh9 = 8563643628384878954;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.push_back(-2029336824645098540);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_5HECj31OymTB4hBctxFBvp8m8uf.push_back(1263098213);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.push_back(13844746150881303446);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.push_back(2359196409658989732);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.push_back(14143284852076787890);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.push_back("XS~6|mv19Uj1XKw2`5h(5Y\\d\"");
		}
		sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4 = "v>h8@>D?jV<yeKwmR3:)X2,Z*)8}K";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.push_back(198);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.push_back(-1103024526738272882);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_J2s4ujBi5mhhLKR0Z.push_back(36281);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_F1HEPEiQDJ1M5hlke *pObject = dynamic_cast<const sbt_F1HEPEiQDJ1M5hlke *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.size() != pObject->sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.size(); i++)
		{
			if (sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5[i] != pObject->sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_O.c_str(), pObject->sbt_O.c_str()))
		{
			return false;
		}
		if (sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm != pObject->sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm)
		{
			return false;
		}
		if (sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P != pObject->sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P)
		{
			return false;
		}
		if (sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.size() != pObject->sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.size(); i++)
		{
			if (0 != cx_strcmp(sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf[i].c_str(), pObject->sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_S2GbLXb4bh9 != pObject->sbt_S2GbLXb4bh9)
		{
			return false;
		}
		if (sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.size() != pObject->sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.size(); i++)
		{
			if (sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA[i] != pObject->sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA[i])
			{
				return false;
			}
		}
		if (sbt_5HECj31OymTB4hBctxFBvp8m8uf.size() != pObject->sbt_5HECj31OymTB4hBctxFBvp8m8uf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5HECj31OymTB4hBctxFBvp8m8uf.size(); i++)
		{
			if (sbt_5HECj31OymTB4hBctxFBvp8m8uf[i] != pObject->sbt_5HECj31OymTB4hBctxFBvp8m8uf[i])
			{
				return false;
			}
		}
		if (sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.size() != pObject->sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.size(); i++)
		{
			if (sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An[i] != pObject->sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An[i])
			{
				return false;
			}
		}
		if (sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.size() != pObject->sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.size(); i++)
		{
			if (sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds[i] != pObject->sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds[i])
			{
				return false;
			}
		}
		if (sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.size() != pObject->sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.size(); i++)
		{
			if (sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi[i] != pObject->sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi[i])
			{
				return false;
			}
		}
		if (sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.size() != pObject->sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.size(); i++)
		{
			if (0 != cx_strcmp(sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP[i].c_str(), pObject->sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4.c_str(), pObject->sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4.c_str()))
		{
			return false;
		}
		if (sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.size() != pObject->sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.size(); i++)
		{
			if (sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL[i] != pObject->sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL[i])
			{
				return false;
			}
		}
		if (sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.size() != pObject->sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.size(); i++)
		{
			if (sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj[i] != pObject->sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj[i])
			{
				return false;
			}
		}
		if (sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.size() != pObject->sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.size(); i++)
		{
			if (sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3[i] != pObject->sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3[i])
			{
				return false;
			}
		}
		if (sbt_J2s4ujBi5mhhLKR0Z.size() != pObject->sbt_J2s4ujBi5mhhLKR0Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J2s4ujBi5mhhLKR0Z.size(); i++)
		{
			if (sbt_J2s4ujBi5mhhLKR0Z[i] != pObject->sbt_J2s4ujBi5mhhLKR0Z[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_O", &sbt_O)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm", &sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_S2GbLXb4bh9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S2GbLXb4bh9 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5HECj31OymTB4hBctxFBvp8m8uf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5HECj31OymTB4hBctxFBvp8m8uf.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4", &sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_J2s4ujBi5mhhLKR0Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J2s4ujBi5mhhLKR0Z.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.begin(); iter != sbt_yopvIjRLwPq2eDCa74NJqyJrQkykTzWLHvdRUPqnBqWdN3ZLxMtK6igRMg5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_O", sbt_O.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm", sbt_PK72OzLfnrrIAoOlGtrLddMG_oLl7T41g8iksdBDqzm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P", (CX::Int64)sbt_15WPL4O0n_zID2xJ9ozA43ZdDgCETVvjO_x1P)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.begin(); iter != sbt_x6R1fLgQjm2vkFsZLnEpNUfEksmL1AkyM7pzpUf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S2GbLXb4bh9", (CX::Int64)sbt_S2GbLXb4bh9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.begin(); iter != sbt_Lur1CAQi0hHmxyVKTO1QXFI_TwkhXUQdIOuAfSCUdyPDJuA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5HECj31OymTB4hBctxFBvp8m8uf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5HECj31OymTB4hBctxFBvp8m8uf.begin(); iter != sbt_5HECj31OymTB4hBctxFBvp8m8uf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.begin(); iter != sbt_3A_xRlGpBDT4fxwspd9sCuEvnQnjB6vdGycO6An.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.begin(); iter != sbt_yniI8Adz9ZfoaJSALgY7Ikdt4LMnTq1FiaN57NQQkKFTl2h6IPHYwNNcXeHTzds.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.begin(); iter != sbt_kZy7jHKN0CHydIzcG1ZrZT7ZYjQZMejJHkyiD4ipSB3heTBCJaKJ4QYAi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.begin(); iter != sbt_8IxLQ3U1f8NF0jy9W1jE41RPvQP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4", sbt_3Zf_vQOaHwB9FeUobt56S2bgLRILTufWs3EeZX4.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.begin(); iter != sbt_EbJQcftLPUXsj9Y10dONVZ6yG3ZyaMsbt1fvEKeTfsm5XfydL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.begin(); iter != sbt_zelO7Lqf8p65ATc0vF5KhekqN0Xhh6SdLgAERy2vi18leuN0zjZUObEiyjBwj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.begin(); iter != sbt_jRRomgcci70Wi0N_tkowko_ionlfTp1tC7G_4EIezG_A8YxNaD4j3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J2s4ujBi5mhhLKR0Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_J2s4ujBi5mhhLKR0Z.begin(); iter != sbt_J2s4ujBi5mhhLKR0Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_F1HEPEiQDJ1M5hlke>::Type sbt_F1HEPEiQDJ1M5hlkeArray;

