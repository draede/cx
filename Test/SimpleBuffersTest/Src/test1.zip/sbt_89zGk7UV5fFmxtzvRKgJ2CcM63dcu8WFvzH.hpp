
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib.hpp"


class sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_zooEV8GG5lu6BYB5TEUC8;
	CX::IO::SimpleBuffers::FloatArray sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW;
	CX::IO::SimpleBuffers::UInt32Array sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX;
	CX::WString sbt_9QOziotVQl4ejZM5fluio;
	CX::IO::SimpleBuffers::StringArray sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB;
	CX::IO::SimpleBuffers::UInt16Array sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk;
	CX::UInt64 sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc;
	CX::UInt64 sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc;
	CX::Int8 sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD;
	CX::Int16 sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC;
	CX::Bool sbt_6G0r9uT6tT7N96BtZ;
	CX::Int64 sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf;
	CX::IO::SimpleBuffers::WStringArray sbt_KlX;
	CX::WString sbt_23B;
	CX::Int16 sbt_trqet;
	CX::IO::SimpleBuffers::Int64Array sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD;
	CX::Int8 sbt_2yyDiaJzOiQsORLmG9K;
	CX::UInt64 sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9;
	CX::Bool sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv;
	CX::IO::SimpleBuffers::Int32Array sbt_8GD3dbs7zFjNQHBpt;
	CX::IO::SimpleBuffers::StringArray sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3;
	CX::Float sbt_GfHw4lV6BgZT667SaQ_oh_iyN;
	CX::IO::SimpleBuffers::Int32Array sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu;
	CX::Float sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_;
	CX::IO::SimpleBuffers::FloatArray sbt_ZZdC8h8QEEo;
	CX::Int8 sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr;
	sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib sbt_y0XxukopF9jXbmbc2MP;

	virtual void Reset()
	{
		sbt_zooEV8GG5lu6BYB5TEUC8.clear();
		sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.clear();
		sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.clear();
		sbt_9QOziotVQl4ejZM5fluio.clear();
		sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.clear();
		sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.clear();
		sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc = 0;
		sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc = 0;
		sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD = 0;
		sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC = 0;
		sbt_6G0r9uT6tT7N96BtZ = false;
		sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf = 0;
		sbt_KlX.clear();
		sbt_23B.clear();
		sbt_trqet = 0;
		sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.clear();
		sbt_2yyDiaJzOiQsORLmG9K = 0;
		sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9 = 0;
		sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv = false;
		sbt_8GD3dbs7zFjNQHBpt.clear();
		sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.clear();
		sbt_GfHw4lV6BgZT667SaQ_oh_iyN = 0.0f;
		sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.clear();
		sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_ = 0.0f;
		sbt_ZZdC8h8QEEo.clear();
		sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr = 0;
		sbt_y0XxukopF9jXbmbc2MP.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_zooEV8GG5lu6BYB5TEUC8.push_back(207);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.push_back(0.143152f);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.push_back(2245242658);
		}
		sbt_9QOziotVQl4ejZM5fluio = L"1})j3%~vBW1YJ#yu-!V;!e%)&gp#ea,<m*B5l@6truVPX3anG(F0t/6";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.push_back("3q7*(W\"oo/SvlsQ)nY5z}b'");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.push_back(59580);
		}
		sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc = 6909983578323167442;
		sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc = 17995586652114354258;
		sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD = 57;
		sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC = -8740;
		sbt_6G0r9uT6tT7N96BtZ = true;
		sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf = 4885159192357700836;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_KlX.push_back(L"cyWn_KTyDyK|gk4#P*}Jh/C=2)4uK6:-<L@4KN%{k1j)+93r_|nO:%P");
		}
		sbt_23B = L"$E4|UsV\\yN/rAQ)z;,0LvKT-dtS(%x?|Wyy;2(+f9y";
		sbt_trqet = -31467;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.push_back(7930011417407321284);
		}
		sbt_2yyDiaJzOiQsORLmG9K = 73;
		sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9 = 18180846656887252516;
		sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv = false;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.push_back("i2t$>3jLq_O`7~d:Fm4rb");
		}
		sbt_GfHw4lV6BgZT667SaQ_oh_iyN = 0.925799f;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.push_back(-910189425);
		}
		sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_ = 0.980996f;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ZZdC8h8QEEo.push_back(0.016024f);
		}
		sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr = 120;
		sbt_y0XxukopF9jXbmbc2MP.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH *pObject = dynamic_cast<const sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_zooEV8GG5lu6BYB5TEUC8.size() != pObject->sbt_zooEV8GG5lu6BYB5TEUC8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zooEV8GG5lu6BYB5TEUC8.size(); i++)
		{
			if (sbt_zooEV8GG5lu6BYB5TEUC8[i] != pObject->sbt_zooEV8GG5lu6BYB5TEUC8[i])
			{
				return false;
			}
		}
		if (sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.size() != pObject->sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.size(); i++)
		{
			if (sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW[i] != pObject->sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW[i])
			{
				return false;
			}
		}
		if (sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.size() != pObject->sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.size(); i++)
		{
			if (sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX[i] != pObject->sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_9QOziotVQl4ejZM5fluio.c_str(), pObject->sbt_9QOziotVQl4ejZM5fluio.c_str()))
		{
			return false;
		}
		if (sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.size() != pObject->sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.size(); i++)
		{
			if (0 != cx_strcmp(sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB[i].c_str(), pObject->sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.size() != pObject->sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.size(); i++)
		{
			if (sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk[i] != pObject->sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk[i])
			{
				return false;
			}
		}
		if (sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc != pObject->sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc)
		{
			return false;
		}
		if (sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc != pObject->sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc)
		{
			return false;
		}
		if (sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD != pObject->sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD)
		{
			return false;
		}
		if (sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC != pObject->sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC)
		{
			return false;
		}
		if (sbt_6G0r9uT6tT7N96BtZ != pObject->sbt_6G0r9uT6tT7N96BtZ)
		{
			return false;
		}
		if (sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf != pObject->sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf)
		{
			return false;
		}
		if (sbt_KlX.size() != pObject->sbt_KlX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KlX.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_KlX[i].c_str(), pObject->sbt_KlX[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_23B.c_str(), pObject->sbt_23B.c_str()))
		{
			return false;
		}
		if (sbt_trqet != pObject->sbt_trqet)
		{
			return false;
		}
		if (sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.size() != pObject->sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.size(); i++)
		{
			if (sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD[i] != pObject->sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD[i])
			{
				return false;
			}
		}
		if (sbt_2yyDiaJzOiQsORLmG9K != pObject->sbt_2yyDiaJzOiQsORLmG9K)
		{
			return false;
		}
		if (sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9 != pObject->sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9)
		{
			return false;
		}
		if (sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv != pObject->sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv)
		{
			return false;
		}
		if (sbt_8GD3dbs7zFjNQHBpt.size() != pObject->sbt_8GD3dbs7zFjNQHBpt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8GD3dbs7zFjNQHBpt.size(); i++)
		{
			if (sbt_8GD3dbs7zFjNQHBpt[i] != pObject->sbt_8GD3dbs7zFjNQHBpt[i])
			{
				return false;
			}
		}
		if (sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.size() != pObject->sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.size(); i++)
		{
			if (0 != cx_strcmp(sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3[i].c_str(), pObject->sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_GfHw4lV6BgZT667SaQ_oh_iyN != pObject->sbt_GfHw4lV6BgZT667SaQ_oh_iyN)
		{
			return false;
		}
		if (sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.size() != pObject->sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.size(); i++)
		{
			if (sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu[i] != pObject->sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu[i])
			{
				return false;
			}
		}
		if (sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_ != pObject->sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_)
		{
			return false;
		}
		if (sbt_ZZdC8h8QEEo.size() != pObject->sbt_ZZdC8h8QEEo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZZdC8h8QEEo.size(); i++)
		{
			if (sbt_ZZdC8h8QEEo[i] != pObject->sbt_ZZdC8h8QEEo[i])
			{
				return false;
			}
		}
		if (sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr != pObject->sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr)
		{
			return false;
		}
		if (!sbt_y0XxukopF9jXbmbc2MP.Compare(&pObject->sbt_y0XxukopF9jXbmbc2MP))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_zooEV8GG5lu6BYB5TEUC8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zooEV8GG5lu6BYB5TEUC8.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_9QOziotVQl4ejZM5fluio", &sbt_9QOziotVQl4ejZM5fluio)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_6G0r9uT6tT7N96BtZ", &sbt_6G0r9uT6tT7N96BtZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KlX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KlX.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_23B", &sbt_23B)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_trqet", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_trqet = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2yyDiaJzOiQsORLmG9K", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2yyDiaJzOiQsORLmG9K = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv", &sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8GD3dbs7zFjNQHBpt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8GD3dbs7zFjNQHBpt.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_GfHw4lV6BgZT667SaQ_oh_iyN", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_GfHw4lV6BgZT667SaQ_oh_iyN = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_ = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_ZZdC8h8QEEo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZZdC8h8QEEo.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_y0XxukopF9jXbmbc2MP")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_y0XxukopF9jXbmbc2MP.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_zooEV8GG5lu6BYB5TEUC8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_zooEV8GG5lu6BYB5TEUC8.begin(); iter != sbt_zooEV8GG5lu6BYB5TEUC8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.begin(); iter != sbt_bsZPpkZrvjg8hXj4wDGvdsbAyzPDPpCBxY2AIXnOl2QejIbybaNqRR7VW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.begin(); iter != sbt_gt1ViSTpUjrDZ8InGorK9ffjYULZUeCdGdbeOeuifc6GTxGCzmEUX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_9QOziotVQl4ejZM5fluio", sbt_9QOziotVQl4ejZM5fluio.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.begin(); iter != sbt_nkAr7tNgDsoHVKRcSSXlaF0Ynas12gTYMxoK6KiAp1U9XCB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.begin(); iter != sbt_VR7u76JGB5Mq79gH65gv6RaYgabQ6B_u_8IPbPDu5TfXtS273zk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc", (CX::Int64)sbt_D6SYCtjfVxj8EwKeB4Gmrgj48zHlZUsxjKpPkB0hE1zlNjd_4JIsc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc", (CX::Int64)sbt_G43Yx0ekkQhlKyOrdbZCTC8kMxc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD", (CX::Int64)sbt_qSjjRLLS4w6LI2qs4oeKFEtkFwmZoYXJ38RQfMfMD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC", (CX::Int64)sbt_w0X4F_duL9Fa3CB1ZxRsq8WPOnotDTtTC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_6G0r9uT6tT7N96BtZ", sbt_6G0r9uT6tT7N96BtZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf", (CX::Int64)sbt_fhWHjQnw5JujXUVZEHmXTZ1WsikzQJAuNUCzTQ6cf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KlX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_KlX.begin(); iter != sbt_KlX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_23B", sbt_23B.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_trqet", (CX::Int64)sbt_trqet)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.begin(); iter != sbt_HbwAaY3m6ofCI11iI3wqi_eggaGg6gD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2yyDiaJzOiQsORLmG9K", (CX::Int64)sbt_2yyDiaJzOiQsORLmG9K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9", (CX::Int64)sbt_IcjSZkzG6HWKECo_PZf8FHCAzdrNVtNHTfNubq9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv", sbt_XcUCEZagBEzyBLrFZx6f0oh2RUxEVLtAHyv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8GD3dbs7zFjNQHBpt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_8GD3dbs7zFjNQHBpt.begin(); iter != sbt_8GD3dbs7zFjNQHBpt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.begin(); iter != sbt_snZvHbZbQZDaHblvfW0uyYEwogrAjQQ_YiKqPKiZ3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_GfHw4lV6BgZT667SaQ_oh_iyN", (CX::Double)sbt_GfHw4lV6BgZT667SaQ_oh_iyN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.begin(); iter != sbt_oAqa_aLG72UgOtmcHVTBVluyLDWQPeptu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_", (CX::Double)sbt_sR7ZlICXjXakZ1TTYlmkbIa9nJpl2lAwLeAV_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZZdC8h8QEEo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_ZZdC8h8QEEo.begin(); iter != sbt_ZZdC8h8QEEo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr", (CX::Int64)sbt_xlKfFLo58xfJopdYmsMn0nzcH_FekUk6FxeOr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_y0XxukopF9jXbmbc2MP")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_y0XxukopF9jXbmbc2MP.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH>::Type sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzHArray;

