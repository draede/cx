
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6.hpp"


class sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::DoubleArray sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt;
	CX::IO::SimpleBuffers::StringArray sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC;
	CX::Int16 sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L;
	CX::WString sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ;
	CX::IO::SimpleBuffers::StringArray sbt_CWyW1;
	CX::IO::SimpleBuffers::UInt32Array sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS;
	CX::Int16 sbt_l8csnpnylQwnU8ulN2x80;
	CX::IO::SimpleBuffers::Int8Array sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE;
	CX::String sbt_tceuhUbjjykzYbZ70JMjQ;
	CX::IO::SimpleBuffers::Int16Array sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs;
	CX::UInt64 sbt_W4q6F0LLI;
	CX::Int16 sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9;
	CX::IO::SimpleBuffers::FloatArray sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f;
	CX::IO::SimpleBuffers::UInt32Array sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x;
	CX::IO::SimpleBuffers::Int32Array sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW;
	CX::Double sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i;
	CX::IO::SimpleBuffers::UInt64Array sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh;
	CX::IO::SimpleBuffers::WStringArray sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw;
	CX::IO::SimpleBuffers::FloatArray sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W;
	CX::IO::SimpleBuffers::Int8Array sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV;
	CX::WString sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV;
	CX::Int16 sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u;
	CX::UInt8 sbt_6ok;
	CX::Int32 sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe;
	CX::String sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy;
	CX::UInt64 sbt_seALNmFC3XW;
	CX::Bool sbt_J2RFc0v1HzooHg80C;
	sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 sbt_OIyU7O2bPjR;

	virtual void Reset()
	{
		sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.clear();
		sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.clear();
		sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L = 0;
		sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ.clear();
		sbt_CWyW1.clear();
		sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.clear();
		sbt_l8csnpnylQwnU8ulN2x80 = 0;
		sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.clear();
		sbt_tceuhUbjjykzYbZ70JMjQ.clear();
		sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.clear();
		sbt_W4q6F0LLI = 0;
		sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9 = 0;
		sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.clear();
		sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.clear();
		sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.clear();
		sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i = 0.0;
		sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.clear();
		sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.clear();
		sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.clear();
		sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.clear();
		sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV.clear();
		sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u = 0;
		sbt_6ok = 0;
		sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe = 0;
		sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy.clear();
		sbt_seALNmFC3XW = 0;
		sbt_J2RFc0v1HzooHg80C = false;
		sbt_OIyU7O2bPjR.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.push_back(0.666351);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.push_back("!<QK.,Km=3p4$%}*o4~$|hknWn:<(7*fu($@6qfK~WJW");
		}
		sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L = 11842;
		sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ = L"Qb@}t-W&WN`!icNFgD(r3R8Cpk-o!s\\m0Pv\"Fb`e\\nW|";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_CWyW1.push_back("\"vYm/pPCZ+'VR'2j<@%xY;LvGE]G>iGo,+[qijio|BB6D)-Dr?0Mdo4");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.push_back(3524567736);
		}
		sbt_l8csnpnylQwnU8ulN2x80 = -21924;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.push_back(58);
		}
		sbt_tceuhUbjjykzYbZ70JMjQ = "pb-&f17(F(#@k(^wTM-y@Ol_EP$5'_Tf5tn@=j)u;h,<MJiuecH4[oXt.Yj";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.push_back(28668);
		}
		sbt_W4q6F0LLI = 8379982122774477786;
		sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9 = 14105;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.push_back(0.017183f);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.push_back(1347152268);
		}
		sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i = 0.643215;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.push_back(4693137653083699254);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.push_back(L"%AD;5Z$rZL;Ajx)o89:ps$/9|T*-HbZt=X/(2^xpjnQpv|g-omQM#MOa|6aP*2");
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.push_back(0.965943f);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.push_back(-104);
		}
		sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV = L"0kd++RfJC4\"|i;G$4(";
		sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u = -29365;
		sbt_6ok = 152;
		sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe = 335970230;
		sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy = ".HTjn(4WC{bSC!B&fB6fm+Fr;V]**O`&@";
		sbt_seALNmFC3XW = 7609932023130250530;
		sbt_J2RFc0v1HzooHg80C = false;
		sbt_OIyU7O2bPjR.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w *pObject = dynamic_cast<const sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.size() != pObject->sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.size(); i++)
		{
			if (sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt[i] != pObject->sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt[i])
			{
				return false;
			}
		}
		if (sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.size() != pObject->sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.size(); i++)
		{
			if (0 != cx_strcmp(sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC[i].c_str(), pObject->sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L != pObject->sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ.c_str(), pObject->sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ.c_str()))
		{
			return false;
		}
		if (sbt_CWyW1.size() != pObject->sbt_CWyW1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CWyW1.size(); i++)
		{
			if (0 != cx_strcmp(sbt_CWyW1[i].c_str(), pObject->sbt_CWyW1[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.size() != pObject->sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.size(); i++)
		{
			if (sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS[i] != pObject->sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS[i])
			{
				return false;
			}
		}
		if (sbt_l8csnpnylQwnU8ulN2x80 != pObject->sbt_l8csnpnylQwnU8ulN2x80)
		{
			return false;
		}
		if (sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.size() != pObject->sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.size(); i++)
		{
			if (sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE[i] != pObject->sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_tceuhUbjjykzYbZ70JMjQ.c_str(), pObject->sbt_tceuhUbjjykzYbZ70JMjQ.c_str()))
		{
			return false;
		}
		if (sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.size() != pObject->sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.size(); i++)
		{
			if (sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs[i] != pObject->sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs[i])
			{
				return false;
			}
		}
		if (sbt_W4q6F0LLI != pObject->sbt_W4q6F0LLI)
		{
			return false;
		}
		if (sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9 != pObject->sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9)
		{
			return false;
		}
		if (sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.size() != pObject->sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.size(); i++)
		{
			if (sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f[i] != pObject->sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f[i])
			{
				return false;
			}
		}
		if (sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.size() != pObject->sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.size(); i++)
		{
			if (sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x[i] != pObject->sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x[i])
			{
				return false;
			}
		}
		if (sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.size() != pObject->sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.size(); i++)
		{
			if (sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW[i] != pObject->sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW[i])
			{
				return false;
			}
		}
		if (sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i != pObject->sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i)
		{
			return false;
		}
		if (sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.size() != pObject->sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.size(); i++)
		{
			if (sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh[i] != pObject->sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh[i])
			{
				return false;
			}
		}
		if (sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.size() != pObject->sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw[i].c_str(), pObject->sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.size() != pObject->sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.size(); i++)
		{
			if (sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W[i] != pObject->sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W[i])
			{
				return false;
			}
		}
		if (sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.size() != pObject->sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.size(); i++)
		{
			if (sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV[i] != pObject->sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV.c_str(), pObject->sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV.c_str()))
		{
			return false;
		}
		if (sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u != pObject->sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u)
		{
			return false;
		}
		if (sbt_6ok != pObject->sbt_6ok)
		{
			return false;
		}
		if (sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe != pObject->sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy.c_str(), pObject->sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy.c_str()))
		{
			return false;
		}
		if (sbt_seALNmFC3XW != pObject->sbt_seALNmFC3XW)
		{
			return false;
		}
		if (sbt_J2RFc0v1HzooHg80C != pObject->sbt_J2RFc0v1HzooHg80C)
		{
			return false;
		}
		if (!sbt_OIyU7O2bPjR.Compare(&pObject->sbt_OIyU7O2bPjR))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ", &sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CWyW1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CWyW1.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_l8csnpnylQwnU8ulN2x80", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_l8csnpnylQwnU8ulN2x80 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_tceuhUbjjykzYbZ70JMjQ", &sbt_tceuhUbjjykzYbZ70JMjQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_W4q6F0LLI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_W4q6F0LLI = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV", &sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_6ok", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6ok = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy", &sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_seALNmFC3XW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_seALNmFC3XW = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_J2RFc0v1HzooHg80C", &sbt_J2RFc0v1HzooHg80C)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_OIyU7O2bPjR")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_OIyU7O2bPjR.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.begin(); iter != sbt_10fD_N5IedRByngod40Yc0ESbtFRJ8c974UA8oKzCHjiNPMuvaflt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.begin(); iter != sbt_sZ5MGF1tV43ciS46dRn7diZH6vPf1VyBO_YKidkkOjnAM9Ub9WI41d6FC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L", (CX::Int64)sbt_EB7iJko5uQDJiWjIN_JUzN9TTqaU3GScPN_DCzPIR2l6C7L)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ", sbt_FLhhpihaz7p4fzYWqjJRdE51FZt11e080nsDQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CWyW1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_CWyW1.begin(); iter != sbt_CWyW1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.begin(); iter != sbt_RxLskdki8AgWSsVX9DzslkVGjd03Tdys0QRhTBNpoRz6kOYuNCvGegNOS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_l8csnpnylQwnU8ulN2x80", (CX::Int64)sbt_l8csnpnylQwnU8ulN2x80)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.begin(); iter != sbt_Dyq_8ltGoEhWY3f07U1O5sHS2dfBgpX3mTxS37jL1Kxe5H7wE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_tceuhUbjjykzYbZ70JMjQ", sbt_tceuhUbjjykzYbZ70JMjQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.begin(); iter != sbt_vUz3zZVbW8nmhEKOS6yeuHJwK3GDyjZ8rvs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_W4q6F0LLI", (CX::Int64)sbt_W4q6F0LLI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9", (CX::Int64)sbt__jmmEZT8qML4irhoMK0FsKVECdM8ytxW7O9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.begin(); iter != sbt_6GyD5fHHeDEqT_1JH_0itILsyWt6A4uT4dtWGBm8jWTWB4f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.begin(); iter != sbt_2RBf0c2MMgaPb8dithj_mmxeQHikFVvBjUdYV0x.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.begin(); iter != sbt_X6pd60vTnDxhkpDL6Pvh7CTSE_ajfnugKWTGZZq6fgc3sPEmDNW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i", (CX::Double)sbt_HEuFkuYmdFzKmjpJvj0esjeaJs5Z0zTg5m7Fzij36Klan9i)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.begin(); iter != sbt_u3zxwYh7EQMKJQkuGJilSCWKTCFRxM0Ra0zlhf77CkBXh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.begin(); iter != sbt_E6ooPhrqFQBptOHSaRu7KE7nEPWsMFIvw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.begin(); iter != sbt_75CuLqRTPbfHlojJci1pwztqY_PCSQKgS40A1WqvDLV3W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.begin(); iter != sbt_ZzUM3fwL0XkeBuJkxqRRjB7H45KsPfSerFJibFEoso_fV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV", sbt__bEHndYOx5cgbKVeBDlrnW572zP8TH4divwTrEwmV.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u", (CX::Int64)sbt_XjVJ1uGJOnLNR5zMg7Tx1bP6kjO5zFj1aNBGwTjQgpQJNEKAD7u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6ok", (CX::Int64)sbt_6ok)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe", (CX::Int64)sbt_7rvuyk6qa1vF8NhhOL8nkEPA65qshmw1bVXAaf9sTtDBrWY4zNA6CIZfe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy", sbt_VH6C1xRpu49kENmVMOAdCOyV3TeSjKy.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_seALNmFC3XW", (CX::Int64)sbt_seALNmFC3XW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_J2RFc0v1HzooHg80C", sbt_J2RFc0v1HzooHg80C)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_OIyU7O2bPjR")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_OIyU7O2bPjR.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w>::Type sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1wArray;

