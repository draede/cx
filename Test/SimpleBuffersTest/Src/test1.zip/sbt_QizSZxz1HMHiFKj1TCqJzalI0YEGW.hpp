
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt__9Qwo.hpp"


class sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_6WeJhJdWKNvYpdoumtybDHfq3m2;
	CX::IO::SimpleBuffers::UInt8Array sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd;
	CX::IO::SimpleBuffers::Int32Array sbt_SG11StIXza5DFu9DZn02tQr;
	CX::IO::SimpleBuffers::WStringArray sbt_zq6JG;
	CX::IO::SimpleBuffers::Int32Array sbt_Sgf;
	sbt__9Qwo sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY;

	virtual void Reset()
	{
		sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.clear();
		sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.clear();
		sbt_SG11StIXza5DFu9DZn02tQr.clear();
		sbt_zq6JG.clear();
		sbt_Sgf.clear();
		sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.push_back("b74JtONu_yyoFC$N]!x)h~'-1s~Qf>|z>(]");
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.push_back(25);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_SG11StIXza5DFu9DZn02tQr.push_back(1298393325);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_zq6JG.push_back(L"\"q6Re|?W'}?RBg|,cJ+_FEe0QfdMX`ffH");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Sgf.push_back(1163913822);
		}
		sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW *pObject = dynamic_cast<const sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.size() != pObject->sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.size(); i++)
		{
			if (0 != cx_strcmp(sbt_6WeJhJdWKNvYpdoumtybDHfq3m2[i].c_str(), pObject->sbt_6WeJhJdWKNvYpdoumtybDHfq3m2[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.size() != pObject->sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.size(); i++)
		{
			if (sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd[i] != pObject->sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd[i])
			{
				return false;
			}
		}
		if (sbt_SG11StIXza5DFu9DZn02tQr.size() != pObject->sbt_SG11StIXza5DFu9DZn02tQr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SG11StIXza5DFu9DZn02tQr.size(); i++)
		{
			if (sbt_SG11StIXza5DFu9DZn02tQr[i] != pObject->sbt_SG11StIXza5DFu9DZn02tQr[i])
			{
				return false;
			}
		}
		if (sbt_zq6JG.size() != pObject->sbt_zq6JG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zq6JG.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_zq6JG[i].c_str(), pObject->sbt_zq6JG[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Sgf.size() != pObject->sbt_Sgf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Sgf.size(); i++)
		{
			if (sbt_Sgf[i] != pObject->sbt_Sgf[i])
			{
				return false;
			}
		}
		if (!sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY.Compare(&pObject->sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_6WeJhJdWKNvYpdoumtybDHfq3m2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SG11StIXza5DFu9DZn02tQr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SG11StIXza5DFu9DZn02tQr.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zq6JG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zq6JG.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Sgf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Sgf.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_6WeJhJdWKNvYpdoumtybDHfq3m2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.begin(); iter != sbt_6WeJhJdWKNvYpdoumtybDHfq3m2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.begin(); iter != sbt_smDpngnpBAL6vetgFSN_2rTaPYUdsNP8dUq586ITJWhy06_yWT6ypfd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SG11StIXza5DFu9DZn02tQr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_SG11StIXza5DFu9DZn02tQr.begin(); iter != sbt_SG11StIXza5DFu9DZn02tQr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zq6JG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_zq6JG.begin(); iter != sbt_zq6JG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Sgf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Sgf.begin(); iter != sbt_Sgf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_LXhhHl8qbv_e7u4aU8gLx74G3ejFuZZrm9pmtfHa6Gd8QQdHY.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW>::Type sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGWArray;

