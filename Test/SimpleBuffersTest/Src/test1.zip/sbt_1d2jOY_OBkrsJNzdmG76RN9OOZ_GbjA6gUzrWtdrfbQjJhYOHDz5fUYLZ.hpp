
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp.hpp"


class sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ;
	CX::Int64 sbt__WnkA6W;
	CX::UInt32 sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q;
	CX::IO::SimpleBuffers::Int32Array sbt_f3CylPdfCDkdDJl;
	CX::IO::SimpleBuffers::UInt64Array sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6;
	CX::UInt8 sbt__;
	CX::UInt8 sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2;
	sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX;

	virtual void Reset()
	{
		sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.clear();
		sbt__WnkA6W = 0;
		sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q = 0;
		sbt_f3CylPdfCDkdDJl.clear();
		sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.clear();
		sbt__ = 0;
		sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2 = 0;
		sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt__WnkA6W = 2060899120575056534;
		sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q = 1162950249;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.push_back(14929337715230856618);
		}
		sbt__ = 227;
		sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2 = 73;
		sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ *pObject = dynamic_cast<const sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.size() != pObject->sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.size(); i++)
		{
			if (sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ[i] != pObject->sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ[i])
			{
				return false;
			}
		}
		if (sbt__WnkA6W != pObject->sbt__WnkA6W)
		{
			return false;
		}
		if (sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q != pObject->sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q)
		{
			return false;
		}
		if (sbt_f3CylPdfCDkdDJl.size() != pObject->sbt_f3CylPdfCDkdDJl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f3CylPdfCDkdDJl.size(); i++)
		{
			if (sbt_f3CylPdfCDkdDJl[i] != pObject->sbt_f3CylPdfCDkdDJl[i])
			{
				return false;
			}
		}
		if (sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.size() != pObject->sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.size(); i++)
		{
			if (sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6[i] != pObject->sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6[i])
			{
				return false;
			}
		}
		if (sbt__ != pObject->sbt__)
		{
			return false;
		}
		if (sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2 != pObject->sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2)
		{
			return false;
		}
		if (!sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX.Compare(&pObject->sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__WnkA6W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__WnkA6W = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_f3CylPdfCDkdDJl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f3CylPdfCDkdDJl.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.begin(); iter != sbt_3AMir0fMdc0_or5iMOu_NK4WuGTSHnxteghSJgkmnGTrrQF2NW6rzfBi7cmkZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__WnkA6W", (CX::Int64)sbt__WnkA6W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q", (CX::Int64)sbt_n9wJ1wlOM0o_TKj40GOB5BD2s5Xmh4uYqMOuG6Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f3CylPdfCDkdDJl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_f3CylPdfCDkdDJl.begin(); iter != sbt_f3CylPdfCDkdDJl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.begin(); iter != sbt_O0Zkkx6EPyusEyMN8E2F3pY9vZA9hEv36oqqZgM8SaXBd77pXOUE6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__", (CX::Int64)sbt__)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2", (CX::Int64)sbt_DnP_FYcjGzo6QMn_a3Ya9gvR8YP1gEvrKAkeFwxnISuzS0oc2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_O5crQEbgCmRy_Y1vONFLY8tsSZ1LRy4Fb6euunsRXpr3vq4lp02yGZJZ1j_mX.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ>::Type sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZArray;

