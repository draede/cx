
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_o2fQv0E1teA4PJ2EmUSNtlc9a : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q;
	CX::UInt16 sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ;
	CX::Int8 sbt_m2J88zjgrdsvMnA;
	CX::IO::SimpleBuffers::UInt64Array sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A;
	CX::IO::SimpleBuffers::UInt32Array sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo;
	CX::IO::SimpleBuffers::UInt64Array sbt_jJFA0eokf976bdhAE;
	CX::UInt16 sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe;
	CX::UInt32 sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb;
	CX::UInt16 sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i;
	CX::IO::SimpleBuffers::UInt32Array sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0;
	CX::IO::SimpleBuffers::UInt32Array sbt_7FeYibRPpgOrr91DSuKEWAXtS;
	CX::IO::SimpleBuffers::UInt8Array sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0;
	CX::IO::SimpleBuffers::UInt32Array sbt_a;
	CX::IO::SimpleBuffers::UInt16Array sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst;

	virtual void Reset()
	{
		sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q = 0;
		sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ = 0;
		sbt_m2J88zjgrdsvMnA = 0;
		sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.clear();
		sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.clear();
		sbt_jJFA0eokf976bdhAE.clear();
		sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe = 0;
		sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb = 0;
		sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i = 0;
		sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.clear();
		sbt_7FeYibRPpgOrr91DSuKEWAXtS.clear();
		sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.clear();
		sbt_a.clear();
		sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q = 480;
		sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ = 23384;
		sbt_m2J88zjgrdsvMnA = 10;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.push_back(9279601616005221496);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.push_back(3848301859);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_jJFA0eokf976bdhAE.push_back(7096781818987327902);
		}
		sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe = 15909;
		sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb = 2597376727;
		sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i = 59025;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.push_back(3262892982);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_7FeYibRPpgOrr91DSuKEWAXtS.push_back(309300404);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.push_back(193);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_a.push_back(1295309794);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.push_back(3823);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_o2fQv0E1teA4PJ2EmUSNtlc9a *pObject = dynamic_cast<const sbt_o2fQv0E1teA4PJ2EmUSNtlc9a *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q != pObject->sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q)
		{
			return false;
		}
		if (sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ != pObject->sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ)
		{
			return false;
		}
		if (sbt_m2J88zjgrdsvMnA != pObject->sbt_m2J88zjgrdsvMnA)
		{
			return false;
		}
		if (sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.size() != pObject->sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.size(); i++)
		{
			if (sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A[i] != pObject->sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A[i])
			{
				return false;
			}
		}
		if (sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.size() != pObject->sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.size(); i++)
		{
			if (sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo[i] != pObject->sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo[i])
			{
				return false;
			}
		}
		if (sbt_jJFA0eokf976bdhAE.size() != pObject->sbt_jJFA0eokf976bdhAE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jJFA0eokf976bdhAE.size(); i++)
		{
			if (sbt_jJFA0eokf976bdhAE[i] != pObject->sbt_jJFA0eokf976bdhAE[i])
			{
				return false;
			}
		}
		if (sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe != pObject->sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe)
		{
			return false;
		}
		if (sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb != pObject->sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb)
		{
			return false;
		}
		if (sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i != pObject->sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i)
		{
			return false;
		}
		if (sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.size() != pObject->sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.size(); i++)
		{
			if (sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0[i] != pObject->sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0[i])
			{
				return false;
			}
		}
		if (sbt_7FeYibRPpgOrr91DSuKEWAXtS.size() != pObject->sbt_7FeYibRPpgOrr91DSuKEWAXtS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7FeYibRPpgOrr91DSuKEWAXtS.size(); i++)
		{
			if (sbt_7FeYibRPpgOrr91DSuKEWAXtS[i] != pObject->sbt_7FeYibRPpgOrr91DSuKEWAXtS[i])
			{
				return false;
			}
		}
		if (sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.size() != pObject->sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.size(); i++)
		{
			if (sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0[i] != pObject->sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0[i])
			{
				return false;
			}
		}
		if (sbt_a.size() != pObject->sbt_a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a.size(); i++)
		{
			if (sbt_a[i] != pObject->sbt_a[i])
			{
				return false;
			}
		}
		if (sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.size() != pObject->sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.size(); i++)
		{
			if (sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst[i] != pObject->sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_m2J88zjgrdsvMnA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_m2J88zjgrdsvMnA = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jJFA0eokf976bdhAE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jJFA0eokf976bdhAE.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7FeYibRPpgOrr91DSuKEWAXtS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7FeYibRPpgOrr91DSuKEWAXtS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q", (CX::Int64)sbt_VFNaP6yLHkxEFRtyUcqw8QlNB79zAhujJ6csMX_0Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ", (CX::Int64)sbt_ig8sGhHDOZCU4eREGgVTHqCYRTEvGOrFfAbE5gb8yn0WYDJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_m2J88zjgrdsvMnA", (CX::Int64)sbt_m2J88zjgrdsvMnA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.begin(); iter != sbt_UkaNEQf6HAo6Xsa7xm7M_kUxWiUQxZeVGHC2JwjDgWqNOvItOckfD3RrB0A.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.begin(); iter != sbt_DyR8VJxSZJMeYJB4_zFTxcu0hH8hW534tCo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jJFA0eokf976bdhAE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_jJFA0eokf976bdhAE.begin(); iter != sbt_jJFA0eokf976bdhAE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe", (CX::Int64)sbt_6ZUdYptFKplAkFTPH0UOmIdcSVe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb", (CX::Int64)sbt_NCpZwnoezVVVHPOjRKFYD3KdWCbzsQwNtrjM8VEX2qDJb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i", (CX::Int64)sbt_EPkWQZjkZJpv6vkVpkOolWeK_iiO1yVxvS1DVRBmspfC_dnIRco9i)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.begin(); iter != sbt_p8Espk6AkZRxWHKYtXZbpJuwCBOn9Md2yd0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7FeYibRPpgOrr91DSuKEWAXtS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7FeYibRPpgOrr91DSuKEWAXtS.begin(); iter != sbt_7FeYibRPpgOrr91DSuKEWAXtS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.begin(); iter != sbt_yh7EaQoTWMVtwuWMidADxiXMoszEGHDo5UnjjQL2qZdcPD0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_a.begin(); iter != sbt_a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.begin(); iter != sbt_07s5w3Uqr6rduO7qvYhricRyu5WqvgmrpuQst.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_o2fQv0E1teA4PJ2EmUSNtlc9a>::Type sbt_o2fQv0E1teA4PJ2EmUSNtlc9aArray;

