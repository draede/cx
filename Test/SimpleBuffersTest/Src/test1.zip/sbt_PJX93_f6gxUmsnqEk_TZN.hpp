
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8rfMtEg.hpp"


class sbt_PJX93_f6gxUmsnqEk_TZN : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI;
	CX::Double sbt_0QmJvl4mS_ATAXp;
	CX::IO::SimpleBuffers::UInt64Array sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q;
	CX::IO::SimpleBuffers::UInt32Array sbt_htTlQMreBs3JwIa;
	CX::IO::SimpleBuffers::UInt16Array sbt_7LuoIJa83;
	CX::IO::SimpleBuffers::WStringArray sbt_zIoQIeog2OYz7Gv0ofSUF4v;
	CX::Int16 sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS;
	sbt_8rfMtEg sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ;

	virtual void Reset()
	{
		sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI = 0;
		sbt_0QmJvl4mS_ATAXp = 0.0;
		sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.clear();
		sbt_htTlQMreBs3JwIa.clear();
		sbt_7LuoIJa83.clear();
		sbt_zIoQIeog2OYz7Gv0ofSUF4v.clear();
		sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS = 0;
		sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI = 13184;
		sbt_0QmJvl4mS_ATAXp = 0.329666;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.push_back(10882408204055666414);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_htTlQMreBs3JwIa.push_back(476263971);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_7LuoIJa83.push_back(16711);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_zIoQIeog2OYz7Gv0ofSUF4v.push_back(L"3^kw[E'*W5a8l{NEO/*X:2<x8");
		}
		sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS = 22500;
		sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PJX93_f6gxUmsnqEk_TZN *pObject = dynamic_cast<const sbt_PJX93_f6gxUmsnqEk_TZN *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI != pObject->sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI)
		{
			return false;
		}
		if (sbt_0QmJvl4mS_ATAXp != pObject->sbt_0QmJvl4mS_ATAXp)
		{
			return false;
		}
		if (sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.size() != pObject->sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.size(); i++)
		{
			if (sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q[i] != pObject->sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q[i])
			{
				return false;
			}
		}
		if (sbt_htTlQMreBs3JwIa.size() != pObject->sbt_htTlQMreBs3JwIa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_htTlQMreBs3JwIa.size(); i++)
		{
			if (sbt_htTlQMreBs3JwIa[i] != pObject->sbt_htTlQMreBs3JwIa[i])
			{
				return false;
			}
		}
		if (sbt_7LuoIJa83.size() != pObject->sbt_7LuoIJa83.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7LuoIJa83.size(); i++)
		{
			if (sbt_7LuoIJa83[i] != pObject->sbt_7LuoIJa83[i])
			{
				return false;
			}
		}
		if (sbt_zIoQIeog2OYz7Gv0ofSUF4v.size() != pObject->sbt_zIoQIeog2OYz7Gv0ofSUF4v.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zIoQIeog2OYz7Gv0ofSUF4v.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_zIoQIeog2OYz7Gv0ofSUF4v[i].c_str(), pObject->sbt_zIoQIeog2OYz7Gv0ofSUF4v[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS != pObject->sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS)
		{
			return false;
		}
		if (!sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ.Compare(&pObject->sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_0QmJvl4mS_ATAXp", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_0QmJvl4mS_ATAXp = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_htTlQMreBs3JwIa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_htTlQMreBs3JwIa.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7LuoIJa83")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7LuoIJa83.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zIoQIeog2OYz7Gv0ofSUF4v")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zIoQIeog2OYz7Gv0ofSUF4v.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI", (CX::Int64)sbt_JWrW8xppkHBpVZ0HQlxoR8fqJ5obuitJIOuwI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_0QmJvl4mS_ATAXp", (CX::Double)sbt_0QmJvl4mS_ATAXp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.begin(); iter != sbt_d0tzIu2a9699lm7X_r3ouY8hJvL0fOnDceHRdmJOuxAiGG6BA1DMWVBZ58q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_htTlQMreBs3JwIa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_htTlQMreBs3JwIa.begin(); iter != sbt_htTlQMreBs3JwIa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7LuoIJa83")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_7LuoIJa83.begin(); iter != sbt_7LuoIJa83.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zIoQIeog2OYz7Gv0ofSUF4v")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_zIoQIeog2OYz7Gv0ofSUF4v.begin(); iter != sbt_zIoQIeog2OYz7Gv0ofSUF4v.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS", (CX::Int64)sbt_KkJbd2INpapkkf0498My9y7N6zYKR_LjJPcYzJqXGpMG94XuqgS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TZxWw71j487Tnjc0xpxEAFV78zxCjivIpPJ.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_PJX93_f6gxUmsnqEk_TZN>::Type sbt_PJX93_f6gxUmsnqEk_TZNArray;

