
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_chS2XwPcNdHG4 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_m8Nbi9F8k;
	CX::IO::SimpleBuffers::Int32Array sbt_9PDdnLQ8Ys0V8AV;
	CX::IO::SimpleBuffers::UInt32Array sbt_fREPpUrdmviThWmK8eWs1;
	CX::Int16 sbt_z6eImnKKLIx;
	CX::Int16 sbt_4TC_BBF;
	CX::UInt32 sbt_WWe1j6FaQugOl9rztzq;
	CX::Bool sbt_93j5SAkfwkEkhQAcu2nOizNvY8s;
	CX::Int32 sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3;
	CX::IO::SimpleBuffers::BoolArray sbt_hEM;
	CX::IO::SimpleBuffers::UInt64Array sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx;
	CX::IO::SimpleBuffers::UInt8Array sbt_0N6P8NmybxOrX;
	CX::Int16 sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU;
	CX::IO::SimpleBuffers::Int8Array sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa;
	CX::IO::SimpleBuffers::BoolArray sbt_DPAdSzZVxUabk3L;
	CX::IO::SimpleBuffers::UInt64Array sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc;

	virtual void Reset()
	{
		sbt_m8Nbi9F8k = false;
		sbt_9PDdnLQ8Ys0V8AV.clear();
		sbt_fREPpUrdmviThWmK8eWs1.clear();
		sbt_z6eImnKKLIx = 0;
		sbt_4TC_BBF = 0;
		sbt_WWe1j6FaQugOl9rztzq = 0;
		sbt_93j5SAkfwkEkhQAcu2nOizNvY8s = false;
		sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3 = 0;
		sbt_hEM.clear();
		sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.clear();
		sbt_0N6P8NmybxOrX.clear();
		sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU = 0;
		sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.clear();
		sbt_DPAdSzZVxUabk3L.clear();
		sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_m8Nbi9F8k = false;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_9PDdnLQ8Ys0V8AV.push_back(1631591020);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_fREPpUrdmviThWmK8eWs1.push_back(991058237);
		}
		sbt_z6eImnKKLIx = -19794;
		sbt_4TC_BBF = -32674;
		sbt_WWe1j6FaQugOl9rztzq = 689824647;
		sbt_93j5SAkfwkEkhQAcu2nOizNvY8s = true;
		sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3 = 129434975;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_hEM.push_back(true);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.push_back(5147724539133615970);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_0N6P8NmybxOrX.push_back(38);
		}
		sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU = -12751;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.push_back(-87);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_DPAdSzZVxUabk3L.push_back(false);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.push_back(3908718882932832626);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_chS2XwPcNdHG4 *pObject = dynamic_cast<const sbt_chS2XwPcNdHG4 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_m8Nbi9F8k != pObject->sbt_m8Nbi9F8k)
		{
			return false;
		}
		if (sbt_9PDdnLQ8Ys0V8AV.size() != pObject->sbt_9PDdnLQ8Ys0V8AV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9PDdnLQ8Ys0V8AV.size(); i++)
		{
			if (sbt_9PDdnLQ8Ys0V8AV[i] != pObject->sbt_9PDdnLQ8Ys0V8AV[i])
			{
				return false;
			}
		}
		if (sbt_fREPpUrdmviThWmK8eWs1.size() != pObject->sbt_fREPpUrdmviThWmK8eWs1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fREPpUrdmviThWmK8eWs1.size(); i++)
		{
			if (sbt_fREPpUrdmviThWmK8eWs1[i] != pObject->sbt_fREPpUrdmviThWmK8eWs1[i])
			{
				return false;
			}
		}
		if (sbt_z6eImnKKLIx != pObject->sbt_z6eImnKKLIx)
		{
			return false;
		}
		if (sbt_4TC_BBF != pObject->sbt_4TC_BBF)
		{
			return false;
		}
		if (sbt_WWe1j6FaQugOl9rztzq != pObject->sbt_WWe1j6FaQugOl9rztzq)
		{
			return false;
		}
		if (sbt_93j5SAkfwkEkhQAcu2nOizNvY8s != pObject->sbt_93j5SAkfwkEkhQAcu2nOizNvY8s)
		{
			return false;
		}
		if (sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3 != pObject->sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3)
		{
			return false;
		}
		if (sbt_hEM.size() != pObject->sbt_hEM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hEM.size(); i++)
		{
			if (sbt_hEM[i] != pObject->sbt_hEM[i])
			{
				return false;
			}
		}
		if (sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.size() != pObject->sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.size(); i++)
		{
			if (sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx[i] != pObject->sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx[i])
			{
				return false;
			}
		}
		if (sbt_0N6P8NmybxOrX.size() != pObject->sbt_0N6P8NmybxOrX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0N6P8NmybxOrX.size(); i++)
		{
			if (sbt_0N6P8NmybxOrX[i] != pObject->sbt_0N6P8NmybxOrX[i])
			{
				return false;
			}
		}
		if (sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU != pObject->sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU)
		{
			return false;
		}
		if (sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.size() != pObject->sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.size(); i++)
		{
			if (sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa[i] != pObject->sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa[i])
			{
				return false;
			}
		}
		if (sbt_DPAdSzZVxUabk3L.size() != pObject->sbt_DPAdSzZVxUabk3L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DPAdSzZVxUabk3L.size(); i++)
		{
			if (sbt_DPAdSzZVxUabk3L[i] != pObject->sbt_DPAdSzZVxUabk3L[i])
			{
				return false;
			}
		}
		if (sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.size() != pObject->sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.size(); i++)
		{
			if (sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc[i] != pObject->sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_m8Nbi9F8k", &sbt_m8Nbi9F8k)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9PDdnLQ8Ys0V8AV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9PDdnLQ8Ys0V8AV.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fREPpUrdmviThWmK8eWs1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fREPpUrdmviThWmK8eWs1.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_z6eImnKKLIx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_z6eImnKKLIx = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_4TC_BBF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4TC_BBF = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WWe1j6FaQugOl9rztzq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WWe1j6FaQugOl9rztzq = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_93j5SAkfwkEkhQAcu2nOizNvY8s", &sbt_93j5SAkfwkEkhQAcu2nOizNvY8s)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hEM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hEM.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0N6P8NmybxOrX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0N6P8NmybxOrX.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DPAdSzZVxUabk3L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DPAdSzZVxUabk3L.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_m8Nbi9F8k", sbt_m8Nbi9F8k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9PDdnLQ8Ys0V8AV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_9PDdnLQ8Ys0V8AV.begin(); iter != sbt_9PDdnLQ8Ys0V8AV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fREPpUrdmviThWmK8eWs1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_fREPpUrdmviThWmK8eWs1.begin(); iter != sbt_fREPpUrdmviThWmK8eWs1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_z6eImnKKLIx", (CX::Int64)sbt_z6eImnKKLIx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4TC_BBF", (CX::Int64)sbt_4TC_BBF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WWe1j6FaQugOl9rztzq", (CX::Int64)sbt_WWe1j6FaQugOl9rztzq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_93j5SAkfwkEkhQAcu2nOizNvY8s", sbt_93j5SAkfwkEkhQAcu2nOizNvY8s)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3", (CX::Int64)sbt_2IDY6A3sIDww6gGR4d2kjCvcXxiBFPazZ1tMOmnI4wkDK3cX3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hEM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_hEM.begin(); iter != sbt_hEM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.begin(); iter != sbt_DG761AwMfXzjQcBPlUhvVFoBhKmOQosJnrx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0N6P8NmybxOrX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_0N6P8NmybxOrX.begin(); iter != sbt_0N6P8NmybxOrX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU", (CX::Int64)sbt_sQb4DGA4mC8TGcmDN6bo7HdnfmQ0DHn1Y4WuU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.begin(); iter != sbt_tjAR4h08T0VkiydGMHPurXamvz1vJPIPLE6sQLLfa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DPAdSzZVxUabk3L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_DPAdSzZVxUabk3L.begin(); iter != sbt_DPAdSzZVxUabk3L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.begin(); iter != sbt_Fu0XJkTE3fRaOXdJp3eeOmhJILnW6KJZ3Rzk0ajucd4lDSQqqcRrNN5gN_GIASc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_chS2XwPcNdHG4>::Type sbt_chS2XwPcNdHG4Array;

