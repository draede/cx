
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_yjnlVxwXS3ejxjxjiuOVP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_dLYEwy5aGlhM0sJIdfkW7IkO6;
	CX::IO::SimpleBuffers::UInt8Array sbt_WJjaGwpZ0rpci;
	CX::IO::SimpleBuffers::BoolArray sbt_RnLd4Gd8OKbbI_0x32x42xYO_;
	CX::IO::SimpleBuffers::Int16Array sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE;
	CX::IO::SimpleBuffers::UInt32Array sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp;
	CX::String sbt_EcTHcLdq5zeQOa0kXgZHc;
	CX::UInt8 sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK;
	CX::IO::SimpleBuffers::UInt8Array sbt_uZd8zxMHMAKDzLkF9Rwid;
	CX::IO::SimpleBuffers::UInt16Array sbt_cs2AH9poLvFtjaa7N;
	CX::IO::SimpleBuffers::UInt16Array sbt__9rbudWW4C7hlNctPMgycxHca;
	CX::Int32 sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE;
	CX::Int8 sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc;
	CX::UInt16 sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon;
	CX::UInt32 sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz;
	CX::String sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO;

	virtual void Reset()
	{
		sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.clear();
		sbt_WJjaGwpZ0rpci.clear();
		sbt_RnLd4Gd8OKbbI_0x32x42xYO_.clear();
		sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.clear();
		sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.clear();
		sbt_EcTHcLdq5zeQOa0kXgZHc.clear();
		sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK = 0;
		sbt_uZd8zxMHMAKDzLkF9Rwid.clear();
		sbt_cs2AH9poLvFtjaa7N.clear();
		sbt__9rbudWW4C7hlNctPMgycxHca.clear();
		sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE = 0;
		sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc = 0;
		sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon = 0;
		sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz = 0;
		sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.push_back(2141881744);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_RnLd4Gd8OKbbI_0x32x42xYO_.push_back(false);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.push_back(263554087);
		}
		sbt_EcTHcLdq5zeQOa0kXgZHc = "q)W[Vk1'THPD8WOt8=udU9>}RXZqbZ/zX7~rpbq8W{pj:Z>=oqgsj:U;B`";
		sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK = 45;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_uZd8zxMHMAKDzLkF9Rwid.push_back(233);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_cs2AH9poLvFtjaa7N.push_back(7196);
		}
		sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE = 1859491949;
		sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc = 62;
		sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon = 20141;
		sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz = 3970870640;
		sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO = "5<9^_kL";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_yjnlVxwXS3ejxjxjiuOVP *pObject = dynamic_cast<const sbt_yjnlVxwXS3ejxjxjiuOVP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.size() != pObject->sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.size(); i++)
		{
			if (sbt_dLYEwy5aGlhM0sJIdfkW7IkO6[i] != pObject->sbt_dLYEwy5aGlhM0sJIdfkW7IkO6[i])
			{
				return false;
			}
		}
		if (sbt_WJjaGwpZ0rpci.size() != pObject->sbt_WJjaGwpZ0rpci.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WJjaGwpZ0rpci.size(); i++)
		{
			if (sbt_WJjaGwpZ0rpci[i] != pObject->sbt_WJjaGwpZ0rpci[i])
			{
				return false;
			}
		}
		if (sbt_RnLd4Gd8OKbbI_0x32x42xYO_.size() != pObject->sbt_RnLd4Gd8OKbbI_0x32x42xYO_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RnLd4Gd8OKbbI_0x32x42xYO_.size(); i++)
		{
			if (sbt_RnLd4Gd8OKbbI_0x32x42xYO_[i] != pObject->sbt_RnLd4Gd8OKbbI_0x32x42xYO_[i])
			{
				return false;
			}
		}
		if (sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.size() != pObject->sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.size(); i++)
		{
			if (sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE[i] != pObject->sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE[i])
			{
				return false;
			}
		}
		if (sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.size() != pObject->sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.size(); i++)
		{
			if (sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp[i] != pObject->sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_EcTHcLdq5zeQOa0kXgZHc.c_str(), pObject->sbt_EcTHcLdq5zeQOa0kXgZHc.c_str()))
		{
			return false;
		}
		if (sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK != pObject->sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK)
		{
			return false;
		}
		if (sbt_uZd8zxMHMAKDzLkF9Rwid.size() != pObject->sbt_uZd8zxMHMAKDzLkF9Rwid.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uZd8zxMHMAKDzLkF9Rwid.size(); i++)
		{
			if (sbt_uZd8zxMHMAKDzLkF9Rwid[i] != pObject->sbt_uZd8zxMHMAKDzLkF9Rwid[i])
			{
				return false;
			}
		}
		if (sbt_cs2AH9poLvFtjaa7N.size() != pObject->sbt_cs2AH9poLvFtjaa7N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cs2AH9poLvFtjaa7N.size(); i++)
		{
			if (sbt_cs2AH9poLvFtjaa7N[i] != pObject->sbt_cs2AH9poLvFtjaa7N[i])
			{
				return false;
			}
		}
		if (sbt__9rbudWW4C7hlNctPMgycxHca.size() != pObject->sbt__9rbudWW4C7hlNctPMgycxHca.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__9rbudWW4C7hlNctPMgycxHca.size(); i++)
		{
			if (sbt__9rbudWW4C7hlNctPMgycxHca[i] != pObject->sbt__9rbudWW4C7hlNctPMgycxHca[i])
			{
				return false;
			}
		}
		if (sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE != pObject->sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE)
		{
			return false;
		}
		if (sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc != pObject->sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc)
		{
			return false;
		}
		if (sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon != pObject->sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon)
		{
			return false;
		}
		if (sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz != pObject->sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO.c_str(), pObject->sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_dLYEwy5aGlhM0sJIdfkW7IkO6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WJjaGwpZ0rpci")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WJjaGwpZ0rpci.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RnLd4Gd8OKbbI_0x32x42xYO_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RnLd4Gd8OKbbI_0x32x42xYO_.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_EcTHcLdq5zeQOa0kXgZHc", &sbt_EcTHcLdq5zeQOa0kXgZHc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uZd8zxMHMAKDzLkF9Rwid")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uZd8zxMHMAKDzLkF9Rwid.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cs2AH9poLvFtjaa7N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cs2AH9poLvFtjaa7N.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__9rbudWW4C7hlNctPMgycxHca")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__9rbudWW4C7hlNctPMgycxHca.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO", &sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_dLYEwy5aGlhM0sJIdfkW7IkO6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.begin(); iter != sbt_dLYEwy5aGlhM0sJIdfkW7IkO6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WJjaGwpZ0rpci")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_WJjaGwpZ0rpci.begin(); iter != sbt_WJjaGwpZ0rpci.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RnLd4Gd8OKbbI_0x32x42xYO_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_RnLd4Gd8OKbbI_0x32x42xYO_.begin(); iter != sbt_RnLd4Gd8OKbbI_0x32x42xYO_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.begin(); iter != sbt_L2NK9mCIe4HWR55N4pZe9IO6hyyfHQObVrsgn0odE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.begin(); iter != sbt_QcUvuddUecRLBilT3SNGj7fWUznWDM3fhu2Bp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_EcTHcLdq5zeQOa0kXgZHc", sbt_EcTHcLdq5zeQOa0kXgZHc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK", (CX::Int64)sbt_HkBoB0Fw5CC3_Hb5hnS6qhl8WYplMyah773XzZzyxmpYrWjwniK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uZd8zxMHMAKDzLkF9Rwid")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_uZd8zxMHMAKDzLkF9Rwid.begin(); iter != sbt_uZd8zxMHMAKDzLkF9Rwid.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cs2AH9poLvFtjaa7N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_cs2AH9poLvFtjaa7N.begin(); iter != sbt_cs2AH9poLvFtjaa7N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__9rbudWW4C7hlNctPMgycxHca")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt__9rbudWW4C7hlNctPMgycxHca.begin(); iter != sbt__9rbudWW4C7hlNctPMgycxHca.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE", (CX::Int64)sbt_5SjsGBPusFgp3WUmsgnIFe0Wx6FCqWnLE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc", (CX::Int64)sbt_CAthtRWPjk5L7kOk8gbQU1YLmqxyTASWST7Ta4KGJXGUl8PTxBVhn4Vzc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon", (CX::Int64)sbt_lQviLz6gyOw6zsFCKcrO7sB2mKd1ZamX8avyR7wAwi36zC9ryAkx1VPKUon)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz", (CX::Int64)sbt_HWn_Agi0aSg3pnEMyto5sQP7hRN2yZaeN90ZGh6LPBhXk9Lwtqz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO", sbt_z9yhW8wDYYX8wAp10Kwmp8M6vDRjrhy5L6bAO.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_yjnlVxwXS3ejxjxjiuOVP>::Type sbt_yjnlVxwXS3ejxjxjiuOVPArray;

