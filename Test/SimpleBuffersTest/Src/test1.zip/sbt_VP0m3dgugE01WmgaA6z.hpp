
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_VP0m3dgugE01WmgaA6z : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt__tlfD;
	CX::Int8 sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l;
	CX::UInt64 sbt_ltj39;
	CX::IO::SimpleBuffers::BoolArray sbt_hsri_vV9hYmU5kN8Ln5RbLmRw;
	CX::IO::SimpleBuffers::Int16Array sbt_DoxjRiyjn1OynlbQ6;
	CX::IO::SimpleBuffers::BoolArray sbt_QI23l20PDgju4kDlQ1mDE4axZElbk;
	CX::Int8 sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy;
	CX::IO::SimpleBuffers::UInt32Array sbt_FDslkUkOtOLdKkTuGAF;
	CX::IO::SimpleBuffers::UInt16Array sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_;
	CX::UInt8 sbt_StwMdFH;
	CX::Int8 sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa;
	CX::Int8 sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM;
	CX::Int32 sbt_zjMhhYi;
	CX::IO::SimpleBuffers::UInt32Array sbt_6LMbQNWpx1C;
	CX::IO::SimpleBuffers::UInt64Array sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6;
	CX::IO::SimpleBuffers::UInt32Array sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq;

	virtual void Reset()
	{
		sbt__tlfD.clear();
		sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l = 0;
		sbt_ltj39 = 0;
		sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.clear();
		sbt_DoxjRiyjn1OynlbQ6.clear();
		sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.clear();
		sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy = 0;
		sbt_FDslkUkOtOLdKkTuGAF.clear();
		sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.clear();
		sbt_StwMdFH = 0;
		sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa = 0;
		sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM = 0;
		sbt_zjMhhYi = 0;
		sbt_6LMbQNWpx1C.clear();
		sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.clear();
		sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt__tlfD.push_back(1374721397);
		}
		sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l = 25;
		sbt_ltj39 = 16766891925290741776;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.push_back(true);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_DoxjRiyjn1OynlbQ6.push_back(-4095);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.push_back(false);
		}
		sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy = 46;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_FDslkUkOtOLdKkTuGAF.push_back(1810613317);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.push_back(31220);
		}
		sbt_StwMdFH = 62;
		sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa = -39;
		sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM = 71;
		sbt_zjMhhYi = 2057600093;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_6LMbQNWpx1C.push_back(291691255);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.push_back(14864874270824796);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.push_back(3227906781);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_VP0m3dgugE01WmgaA6z *pObject = dynamic_cast<const sbt_VP0m3dgugE01WmgaA6z *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt__tlfD.size() != pObject->sbt__tlfD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__tlfD.size(); i++)
		{
			if (sbt__tlfD[i] != pObject->sbt__tlfD[i])
			{
				return false;
			}
		}
		if (sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l != pObject->sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l)
		{
			return false;
		}
		if (sbt_ltj39 != pObject->sbt_ltj39)
		{
			return false;
		}
		if (sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.size() != pObject->sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.size(); i++)
		{
			if (sbt_hsri_vV9hYmU5kN8Ln5RbLmRw[i] != pObject->sbt_hsri_vV9hYmU5kN8Ln5RbLmRw[i])
			{
				return false;
			}
		}
		if (sbt_DoxjRiyjn1OynlbQ6.size() != pObject->sbt_DoxjRiyjn1OynlbQ6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DoxjRiyjn1OynlbQ6.size(); i++)
		{
			if (sbt_DoxjRiyjn1OynlbQ6[i] != pObject->sbt_DoxjRiyjn1OynlbQ6[i])
			{
				return false;
			}
		}
		if (sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.size() != pObject->sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.size(); i++)
		{
			if (sbt_QI23l20PDgju4kDlQ1mDE4axZElbk[i] != pObject->sbt_QI23l20PDgju4kDlQ1mDE4axZElbk[i])
			{
				return false;
			}
		}
		if (sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy != pObject->sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy)
		{
			return false;
		}
		if (sbt_FDslkUkOtOLdKkTuGAF.size() != pObject->sbt_FDslkUkOtOLdKkTuGAF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FDslkUkOtOLdKkTuGAF.size(); i++)
		{
			if (sbt_FDslkUkOtOLdKkTuGAF[i] != pObject->sbt_FDslkUkOtOLdKkTuGAF[i])
			{
				return false;
			}
		}
		if (sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.size() != pObject->sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.size(); i++)
		{
			if (sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_[i] != pObject->sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_[i])
			{
				return false;
			}
		}
		if (sbt_StwMdFH != pObject->sbt_StwMdFH)
		{
			return false;
		}
		if (sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa != pObject->sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa)
		{
			return false;
		}
		if (sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM != pObject->sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM)
		{
			return false;
		}
		if (sbt_zjMhhYi != pObject->sbt_zjMhhYi)
		{
			return false;
		}
		if (sbt_6LMbQNWpx1C.size() != pObject->sbt_6LMbQNWpx1C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6LMbQNWpx1C.size(); i++)
		{
			if (sbt_6LMbQNWpx1C[i] != pObject->sbt_6LMbQNWpx1C[i])
			{
				return false;
			}
		}
		if (sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.size() != pObject->sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.size(); i++)
		{
			if (sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6[i] != pObject->sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6[i])
			{
				return false;
			}
		}
		if (sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.size() != pObject->sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.size(); i++)
		{
			if (sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq[i] != pObject->sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt__tlfD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__tlfD.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ltj39", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ltj39 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hsri_vV9hYmU5kN8Ln5RbLmRw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DoxjRiyjn1OynlbQ6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DoxjRiyjn1OynlbQ6.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QI23l20PDgju4kDlQ1mDE4axZElbk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FDslkUkOtOLdKkTuGAF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FDslkUkOtOLdKkTuGAF.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_StwMdFH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_StwMdFH = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zjMhhYi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zjMhhYi = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6LMbQNWpx1C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6LMbQNWpx1C.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt__tlfD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt__tlfD.begin(); iter != sbt__tlfD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l", (CX::Int64)sbt_VgdFNwDxe5m0WZYu8ASYh5bxbv6_dwXkwF46oOABeRTl9345l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ltj39", (CX::Int64)sbt_ltj39)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hsri_vV9hYmU5kN8Ln5RbLmRw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.begin(); iter != sbt_hsri_vV9hYmU5kN8Ln5RbLmRw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DoxjRiyjn1OynlbQ6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_DoxjRiyjn1OynlbQ6.begin(); iter != sbt_DoxjRiyjn1OynlbQ6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QI23l20PDgju4kDlQ1mDE4axZElbk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.begin(); iter != sbt_QI23l20PDgju4kDlQ1mDE4axZElbk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy", (CX::Int64)sbt_TjMT2Z6gQ5nrFx2fmWzDuzQvOTHM803hEj6DzbwnYAVw8VOOc1i6Czeppjy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FDslkUkOtOLdKkTuGAF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FDslkUkOtOLdKkTuGAF.begin(); iter != sbt_FDslkUkOtOLdKkTuGAF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.begin(); iter != sbt_LfTzDZ3sgmjwKbNgA5KwIqDi2eWoBjv5cBJNfYs9n9tb4LfuVIndK59kNZeC7O_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_StwMdFH", (CX::Int64)sbt_StwMdFH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa", (CX::Int64)sbt_hgFsiCgDAM6ZRoEf0sQI2ijhfSa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM", (CX::Int64)sbt_sZhQlrlH3Vle7FWjmpUAsdF5I8SlMgKni3UBHKREbp2QM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zjMhhYi", (CX::Int64)sbt_zjMhhYi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6LMbQNWpx1C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_6LMbQNWpx1C.begin(); iter != sbt_6LMbQNWpx1C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.begin(); iter != sbt_4Ksi7GDy_0kCO_beZ1kj_7Kodg6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.begin(); iter != sbt_mgWdoTHnPFVkdSvoQI1VM4TOVh2ABgm5PB1QUL4cq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_VP0m3dgugE01WmgaA6z>::Type sbt_VP0m3dgugE01WmgaA6zArray;

