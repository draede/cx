
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_mpTru : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp;
	CX::IO::SimpleBuffers::UInt8Array sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo;
	CX::Int8 sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG;
	CX::String sbt_vxTfYUcCW3UHwRqjolm;
	CX::IO::SimpleBuffers::UInt64Array sbt_fSikY;
	CX::IO::SimpleBuffers::UInt64Array sbt_tXaXp6JfhJerQUEmD4M7X;
	CX::IO::SimpleBuffers::Int32Array sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi;
	CX::IO::SimpleBuffers::UInt32Array sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG;
	CX::Int64 sbt_nMnD7GXO9fHQX_n;
	CX::IO::SimpleBuffers::BoolArray sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC;
	CX::UInt32 sbt_MSVhmMKsuad;
	CX::IO::SimpleBuffers::UInt32Array sbt_3q6cjMkyiGbxyc3S6ak;
	CX::UInt64 sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX;
	CX::UInt8 sbt_pZshX_KeJf6l9FWevAXe4Bx;
	CX::IO::SimpleBuffers::Int64Array sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM;
	CX::UInt64 sbt_yoRVMlEQEND3mTErj2iLh;
	CX::IO::SimpleBuffers::UInt64Array sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk;

	virtual void Reset()
	{
		sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp.clear();
		sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.clear();
		sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG = 0;
		sbt_vxTfYUcCW3UHwRqjolm.clear();
		sbt_fSikY.clear();
		sbt_tXaXp6JfhJerQUEmD4M7X.clear();
		sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.clear();
		sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.clear();
		sbt_nMnD7GXO9fHQX_n = 0;
		sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.clear();
		sbt_MSVhmMKsuad = 0;
		sbt_3q6cjMkyiGbxyc3S6ak.clear();
		sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX = 0;
		sbt_pZshX_KeJf6l9FWevAXe4Bx = 0;
		sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.clear();
		sbt_yoRVMlEQEND3mTErj2iLh = 0;
		sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp = "Xa.fy5*;o";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.push_back(188);
		}
		sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG = -6;
		sbt_vxTfYUcCW3UHwRqjolm = "A$9v.x\\A)Xn:9UoC>|9`Y7A):ts1^Xf&h4";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_fSikY.push_back(13802692680278194642);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_tXaXp6JfhJerQUEmD4M7X.push_back(373871125703101278);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.push_back(1349953905);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.push_back(789232757);
		}
		sbt_nMnD7GXO9fHQX_n = 6743411926147964320;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.push_back(false);
		}
		sbt_MSVhmMKsuad = 1158805974;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_3q6cjMkyiGbxyc3S6ak.push_back(531926797);
		}
		sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX = 14295168691952032;
		sbt_pZshX_KeJf6l9FWevAXe4Bx = 220;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.push_back(8574871145367338244);
		}
		sbt_yoRVMlEQEND3mTErj2iLh = 1298075592631272474;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_mpTru *pObject = dynamic_cast<const sbt_mpTru *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp.c_str(), pObject->sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp.c_str()))
		{
			return false;
		}
		if (sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.size() != pObject->sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.size(); i++)
		{
			if (sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo[i] != pObject->sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo[i])
			{
				return false;
			}
		}
		if (sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG != pObject->sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_vxTfYUcCW3UHwRqjolm.c_str(), pObject->sbt_vxTfYUcCW3UHwRqjolm.c_str()))
		{
			return false;
		}
		if (sbt_fSikY.size() != pObject->sbt_fSikY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fSikY.size(); i++)
		{
			if (sbt_fSikY[i] != pObject->sbt_fSikY[i])
			{
				return false;
			}
		}
		if (sbt_tXaXp6JfhJerQUEmD4M7X.size() != pObject->sbt_tXaXp6JfhJerQUEmD4M7X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tXaXp6JfhJerQUEmD4M7X.size(); i++)
		{
			if (sbt_tXaXp6JfhJerQUEmD4M7X[i] != pObject->sbt_tXaXp6JfhJerQUEmD4M7X[i])
			{
				return false;
			}
		}
		if (sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.size() != pObject->sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.size(); i++)
		{
			if (sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi[i] != pObject->sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi[i])
			{
				return false;
			}
		}
		if (sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.size() != pObject->sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.size(); i++)
		{
			if (sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG[i] != pObject->sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG[i])
			{
				return false;
			}
		}
		if (sbt_nMnD7GXO9fHQX_n != pObject->sbt_nMnD7GXO9fHQX_n)
		{
			return false;
		}
		if (sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.size() != pObject->sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.size(); i++)
		{
			if (sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC[i] != pObject->sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC[i])
			{
				return false;
			}
		}
		if (sbt_MSVhmMKsuad != pObject->sbt_MSVhmMKsuad)
		{
			return false;
		}
		if (sbt_3q6cjMkyiGbxyc3S6ak.size() != pObject->sbt_3q6cjMkyiGbxyc3S6ak.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3q6cjMkyiGbxyc3S6ak.size(); i++)
		{
			if (sbt_3q6cjMkyiGbxyc3S6ak[i] != pObject->sbt_3q6cjMkyiGbxyc3S6ak[i])
			{
				return false;
			}
		}
		if (sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX != pObject->sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX)
		{
			return false;
		}
		if (sbt_pZshX_KeJf6l9FWevAXe4Bx != pObject->sbt_pZshX_KeJf6l9FWevAXe4Bx)
		{
			return false;
		}
		if (sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.size() != pObject->sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.size(); i++)
		{
			if (sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM[i] != pObject->sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM[i])
			{
				return false;
			}
		}
		if (sbt_yoRVMlEQEND3mTErj2iLh != pObject->sbt_yoRVMlEQEND3mTErj2iLh)
		{
			return false;
		}
		if (sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.size() != pObject->sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.size(); i++)
		{
			if (sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk[i] != pObject->sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp", &sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_vxTfYUcCW3UHwRqjolm", &sbt_vxTfYUcCW3UHwRqjolm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fSikY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fSikY.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tXaXp6JfhJerQUEmD4M7X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tXaXp6JfhJerQUEmD4M7X.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nMnD7GXO9fHQX_n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nMnD7GXO9fHQX_n = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MSVhmMKsuad", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MSVhmMKsuad = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3q6cjMkyiGbxyc3S6ak")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3q6cjMkyiGbxyc3S6ak.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pZshX_KeJf6l9FWevAXe4Bx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pZshX_KeJf6l9FWevAXe4Bx = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yoRVMlEQEND3mTErj2iLh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yoRVMlEQEND3mTErj2iLh = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp", sbt_apw8Qv_1L7ekLvk0mFbV93Jp2jTAp.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.begin(); iter != sbt_86VcdgeVJXG228_4eiFZ4kNR0AZvKZCkoZbiUsH5AvjEBLh691qMmzBHVqkRo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG", (CX::Int64)sbt_80EZVwSg5OQqvvf1Wjuig5Yr2nG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_vxTfYUcCW3UHwRqjolm", sbt_vxTfYUcCW3UHwRqjolm.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fSikY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_fSikY.begin(); iter != sbt_fSikY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tXaXp6JfhJerQUEmD4M7X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_tXaXp6JfhJerQUEmD4M7X.begin(); iter != sbt_tXaXp6JfhJerQUEmD4M7X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.begin(); iter != sbt_oNSpSPwre7OwfBZ7eOIuzpDdrWu4_zYXi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.begin(); iter != sbt_wLTlAFrU6USncUhs88BF1a0rFBzL_XttITl1WXpGG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nMnD7GXO9fHQX_n", (CX::Int64)sbt_nMnD7GXO9fHQX_n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.begin(); iter != sbt_ulW_3Q4hfGZpcDOeTCqij_z0e9bdb2Y1qZb99Q94lehW6UE2RJJVsPjfnYC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MSVhmMKsuad", (CX::Int64)sbt_MSVhmMKsuad)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3q6cjMkyiGbxyc3S6ak")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_3q6cjMkyiGbxyc3S6ak.begin(); iter != sbt_3q6cjMkyiGbxyc3S6ak.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX", (CX::Int64)sbt_cqAgMd55g_kNGibEuLLbWACZvowX5NtUbXYlZsi6qsUpB9O0E6FHX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pZshX_KeJf6l9FWevAXe4Bx", (CX::Int64)sbt_pZshX_KeJf6l9FWevAXe4Bx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.begin(); iter != sbt_qPkaWFb0trHTWXze3arw2mAi4svK7PtyoaYFvZA5kfRkSCisXFk8oNM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yoRVMlEQEND3mTErj2iLh", (CX::Int64)sbt_yoRVMlEQEND3mTErj2iLh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.begin(); iter != sbt_yJb28l_9mhnS8cvA13en30uqbqvOeoaGk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_mpTru>::Type sbt_mpTruArray;

