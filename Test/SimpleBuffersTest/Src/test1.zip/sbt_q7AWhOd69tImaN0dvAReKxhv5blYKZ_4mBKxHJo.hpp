
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_;
	CX::UInt64 sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x;
	CX::UInt16 sbt_XG5;
	CX::String sbt_jxUksc3;
	CX::UInt32 sbt_xqhhE217cFO;

	virtual void Reset()
	{
		sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.clear();
		sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x = 0;
		sbt_XG5 = 0;
		sbt_jxUksc3.clear();
		sbt_xqhhE217cFO = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.push_back(25);
		}
		sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x = 3420327338643851132;
		sbt_XG5 = 59570;
		sbt_jxUksc3 = "eThf{6]gY>m33=Yx9-&][7n'SK\"RC>sUN&Ykc!,";
		sbt_xqhhE217cFO = 1043882024;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo *pObject = dynamic_cast<const sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.size() != pObject->sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.size(); i++)
		{
			if (sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_[i] != pObject->sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_[i])
			{
				return false;
			}
		}
		if (sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x != pObject->sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x)
		{
			return false;
		}
		if (sbt_XG5 != pObject->sbt_XG5)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_jxUksc3.c_str(), pObject->sbt_jxUksc3.c_str()))
		{
			return false;
		}
		if (sbt_xqhhE217cFO != pObject->sbt_xqhhE217cFO)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XG5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XG5 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_jxUksc3", &sbt_jxUksc3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xqhhE217cFO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xqhhE217cFO = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.begin(); iter != sbt_b7BQlXZkclljWlC5sRgbw7Xo2m9zxUJ7dAhn9zKwc8YA_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x", (CX::Int64)sbt_0xchrqamXuOh5y7uBbUO36nVZhpJ4su1WL2zCI9cBm2Tlo66Ub9pnYZJZggx29x)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XG5", (CX::Int64)sbt_XG5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_jxUksc3", sbt_jxUksc3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xqhhE217cFO", (CX::Int64)sbt_xqhhE217cFO)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo>::Type sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJoArray;

