
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6.hpp"


class sbt_DaYnmt3HzS2qSsGL_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8;
	CX::UInt16 sbt_XI3;
	CX::IO::SimpleBuffers::FloatArray sbt_TSO;
	CX::UInt16 sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ;
	CX::UInt64 sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_;
	CX::IO::SimpleBuffers::StringArray sbt_jw5OeRj;
	CX::IO::SimpleBuffers::FloatArray sbt_EMPJoVQ2X;
	CX::IO::SimpleBuffers::DoubleArray sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0;
	CX::IO::SimpleBuffers::UInt32Array sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6;
	CX::IO::SimpleBuffers::StringArray sbt_f;
	CX::IO::SimpleBuffers::UInt32Array sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l;
	CX::Double sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a;
	CX::Double sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H;
	CX::Double sbt_eNx31EI5mdQ;
	CX::IO::SimpleBuffers::BoolArray sbt_ZBw6QSuv6yppZOJcMjK1aINPbir;
	CX::IO::SimpleBuffers::Int32Array sbt_H5HJDdseajL9_;
	sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6Array sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna;

	virtual void Reset()
	{
		sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8 = 0;
		sbt_XI3 = 0;
		sbt_TSO.clear();
		sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ = 0;
		sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_ = 0;
		sbt_jw5OeRj.clear();
		sbt_EMPJoVQ2X.clear();
		sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.clear();
		sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.clear();
		sbt_f.clear();
		sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.clear();
		sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a = 0.0;
		sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H = 0.0;
		sbt_eNx31EI5mdQ = 0.0;
		sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.clear();
		sbt_H5HJDdseajL9_.clear();
		sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8 = 15980462313524442796;
		sbt_XI3 = 30715;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_TSO.push_back(0.978198f);
		}
		sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ = 49207;
		sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_ = 2904124272265193104;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_jw5OeRj.push_back(">Tq&T@Pm:/#Q}<,SHYD=nXpY-Gnz");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_EMPJoVQ2X.push_back(0.984133f);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.push_back(0.766180);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.push_back(1318307064);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_f.push_back("|!XoX*6#~1iuv9~jVHCfR");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.push_back(922979221);
		}
		sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a = 0.018386;
		sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H = 0.372043;
		sbt_eNx31EI5mdQ = 0.079630;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.push_back(true);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_H5HJDdseajL9_.push_back(-826604060);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 v;

			v.SetupWithSomeValues();
			sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_DaYnmt3HzS2qSsGL_ *pObject = dynamic_cast<const sbt_DaYnmt3HzS2qSsGL_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8 != pObject->sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8)
		{
			return false;
		}
		if (sbt_XI3 != pObject->sbt_XI3)
		{
			return false;
		}
		if (sbt_TSO.size() != pObject->sbt_TSO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TSO.size(); i++)
		{
			if (sbt_TSO[i] != pObject->sbt_TSO[i])
			{
				return false;
			}
		}
		if (sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ != pObject->sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ)
		{
			return false;
		}
		if (sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_ != pObject->sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_)
		{
			return false;
		}
		if (sbt_jw5OeRj.size() != pObject->sbt_jw5OeRj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jw5OeRj.size(); i++)
		{
			if (0 != cx_strcmp(sbt_jw5OeRj[i].c_str(), pObject->sbt_jw5OeRj[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_EMPJoVQ2X.size() != pObject->sbt_EMPJoVQ2X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EMPJoVQ2X.size(); i++)
		{
			if (sbt_EMPJoVQ2X[i] != pObject->sbt_EMPJoVQ2X[i])
			{
				return false;
			}
		}
		if (sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.size() != pObject->sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.size(); i++)
		{
			if (sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0[i] != pObject->sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0[i])
			{
				return false;
			}
		}
		if (sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.size() != pObject->sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.size(); i++)
		{
			if (sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6[i] != pObject->sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6[i])
			{
				return false;
			}
		}
		if (sbt_f.size() != pObject->sbt_f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f.size(); i++)
		{
			if (0 != cx_strcmp(sbt_f[i].c_str(), pObject->sbt_f[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.size() != pObject->sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.size(); i++)
		{
			if (sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l[i] != pObject->sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l[i])
			{
				return false;
			}
		}
		if (sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a != pObject->sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a)
		{
			return false;
		}
		if (sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H != pObject->sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H)
		{
			return false;
		}
		if (sbt_eNx31EI5mdQ != pObject->sbt_eNx31EI5mdQ)
		{
			return false;
		}
		if (sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.size() != pObject->sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.size(); i++)
		{
			if (sbt_ZBw6QSuv6yppZOJcMjK1aINPbir[i] != pObject->sbt_ZBw6QSuv6yppZOJcMjK1aINPbir[i])
			{
				return false;
			}
		}
		if (sbt_H5HJDdseajL9_.size() != pObject->sbt_H5HJDdseajL9_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H5HJDdseajL9_.size(); i++)
		{
			if (sbt_H5HJDdseajL9_[i] != pObject->sbt_H5HJDdseajL9_[i])
			{
				return false;
			}
		}
		if (sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.size() != pObject->sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.size(); i++)
		{
			if (!sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna[i].Compare(&pObject->sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XI3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XI3 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TSO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TSO.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jw5OeRj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jw5OeRj.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EMPJoVQ2X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EMPJoVQ2X.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_eNx31EI5mdQ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_eNx31EI5mdQ = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_ZBw6QSuv6yppZOJcMjK1aINPbir")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H5HJDdseajL9_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H5HJDdseajL9_.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8", (CX::Int64)sbt_2grrgfw3GpZpfmzvTh4aj56VczAkctc8LOtd7c8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XI3", (CX::Int64)sbt_XI3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TSO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_TSO.begin(); iter != sbt_TSO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ", (CX::Int64)sbt_qz_UFEHMnm5wMCW2giSlZi1Iw73nriQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_", (CX::Int64)sbt_9LnVzAE4IirRzPaYpn1M9cgqM61YEuEhB0nb1ZBGGzad7aHYOcfYb8RFUo3C9s_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jw5OeRj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_jw5OeRj.begin(); iter != sbt_jw5OeRj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EMPJoVQ2X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_EMPJoVQ2X.begin(); iter != sbt_EMPJoVQ2X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.begin(); iter != sbt_n0TLxy1u10_IPVk5jamEdihG8ammjO_WTtQajiB0cxjyLlKxOYVPFD0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.begin(); iter != sbt_9bKv2wtX3iUzkqmJXQkgXrSaM3y8PEvOSyaA9AoymN6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_f.begin(); iter != sbt_f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.begin(); iter != sbt_QZAhS34_jYDaHtb_hExjd3AmObeY1RZrujhPDkvkk23cm9l.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a", (CX::Double)sbt_s_2PpDF7zL1DvCyDqitlAnI3jVP8rjmhs4kJwKmDRppHbvRbWeiXATwCa1a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H", (CX::Double)sbt_4FulcCu_g3gM6DmvniDu1SHTCNvCHPfvjKsn66H)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_eNx31EI5mdQ", (CX::Double)sbt_eNx31EI5mdQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZBw6QSuv6yppZOJcMjK1aINPbir")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.begin(); iter != sbt_ZBw6QSuv6yppZOJcMjK1aINPbir.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H5HJDdseajL9_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_H5HJDdseajL9_.begin(); iter != sbt_H5HJDdseajL9_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna")).IsNOK())
		{
			return status;
		}
		for (sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6Array::const_iterator iter = sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.begin(); iter != sbt_zdT7Wjkaekg5VhP2ROqsB8xNTE0QTPZna.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_DaYnmt3HzS2qSsGL_>::Type sbt_DaYnmt3HzS2qSsGL_Array;

