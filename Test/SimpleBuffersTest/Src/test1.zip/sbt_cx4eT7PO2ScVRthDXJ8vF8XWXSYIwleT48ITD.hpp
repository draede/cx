
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Pl1G7KOQyDq0chahR.hpp"


class sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK;
	CX::UInt64 sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb;
	CX::Double sbt_P4h_A2E;
	sbt_Pl1G7KOQyDq0chahR sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7;

	virtual void Reset()
	{
		sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK = 0;
		sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb = 0;
		sbt_P4h_A2E = 0.0;
		sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK = 8464;
		sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb = 2192435038225872242;
		sbt_P4h_A2E = 0.692238;
		sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD *pObject = dynamic_cast<const sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK != pObject->sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK)
		{
			return false;
		}
		if (sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb != pObject->sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb)
		{
			return false;
		}
		if (sbt_P4h_A2E != pObject->sbt_P4h_A2E)
		{
			return false;
		}
		if (!sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7.Compare(&pObject->sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_P4h_A2E", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_P4h_A2E = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectObject("sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK", (CX::Int64)sbt__XotrNO1RGzVqd2eTWNwXQSTqTtISaOXtPOkhDd3zNlzyc4EOwpoBU5zK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb", (CX::Int64)sbt_jj3EnqgFUIyIb95pJDL2LgyggtLFn0jxtc0GIPoAgzUGX5cArhdcKbRZGSVaSHb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_P4h_A2E", (CX::Double)sbt_P4h_A2E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_KWUJgUsDL1gfGQs7i63nnEgpS6FS3WmS8gf3b1fg1fjBzWCVItQf6OTLgleu7.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD>::Type sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITDArray;

