
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_v8y.hpp"


class sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_v8yArray sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_;

	virtual void Reset()
	{
		sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_v8y v;

			v.SetupWithSomeValues();
			sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E *pObject = dynamic_cast<const sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.size() != pObject->sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.size(); i++)
		{
			if (!sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_[i].Compare(&pObject->sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_v8y tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_")).IsNOK())
		{
			return status;
		}
		for (sbt_v8yArray::const_iterator iter = sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.begin(); iter != sbt_fNuoCxt8TmJCWvOqZNfo0NcDxa3biONlo30DWhnloNHa5P2p3bY8gzjJ_.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E>::Type sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7EArray;

