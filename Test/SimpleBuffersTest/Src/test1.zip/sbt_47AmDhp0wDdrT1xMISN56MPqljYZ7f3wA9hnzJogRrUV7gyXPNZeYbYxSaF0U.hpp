
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_FBJGedd.hpp"


class sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_Lz5lT;
	CX::UInt16 sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI;
	CX::Bool sbt_H793aWGm3q8Pm2aVOmVEGVv;
	CX::Float sbt_hwx;
	CX::IO::SimpleBuffers::Int32Array sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ;
	CX::UInt64 sbt_b56gQqJ;
	CX::IO::SimpleBuffers::StringArray sbt_W_1R7Ty4FAOEAVmgN;
	CX::WString sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm;
	CX::Int32 sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk;
	CX::IO::SimpleBuffers::Int64Array sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3;
	CX::WString sbt_Mi1;
	CX::IO::SimpleBuffers::UInt32Array sbt_qPmgZ;
	CX::IO::SimpleBuffers::StringArray sbt_TsA;
	CX::IO::SimpleBuffers::UInt8Array sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md;
	CX::Int8 sbt_jgpwuUkjyFwopdoOX;
	CX::WString sbt_KeBmIN45AHQE2SzWSuM;
	CX::Double sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv;
	CX::IO::SimpleBuffers::UInt8Array sbt_JTP;
	CX::IO::SimpleBuffers::WStringArray sbt_qG6jYn8exeCnSSVJK3iouFmLT;
	CX::IO::SimpleBuffers::UInt16Array sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6;
	CX::IO::SimpleBuffers::UInt8Array sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj;
	CX::Double sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL;
	CX::IO::SimpleBuffers::Int16Array sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd;
	CX::UInt32 sbt_VJSVlLPzu6SZBLgy3qbC57hQr;
	CX::UInt64 sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR;
	CX::UInt32 sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi;
	sbt_FBJGeddArray sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF;

	virtual void Reset()
	{
		sbt_Lz5lT.clear();
		sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI = 0;
		sbt_H793aWGm3q8Pm2aVOmVEGVv = false;
		sbt_hwx = 0.0f;
		sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.clear();
		sbt_b56gQqJ = 0;
		sbt_W_1R7Ty4FAOEAVmgN.clear();
		sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm.clear();
		sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk = 0;
		sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.clear();
		sbt_Mi1.clear();
		sbt_qPmgZ.clear();
		sbt_TsA.clear();
		sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.clear();
		sbt_jgpwuUkjyFwopdoOX = 0;
		sbt_KeBmIN45AHQE2SzWSuM.clear();
		sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv = 0.0;
		sbt_JTP.clear();
		sbt_qG6jYn8exeCnSSVJK3iouFmLT.clear();
		sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.clear();
		sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.clear();
		sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL = 0.0;
		sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.clear();
		sbt_VJSVlLPzu6SZBLgy3qbC57hQr = 0;
		sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR = 0;
		sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi = 0;
		sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Lz5lT.push_back(3560830231729286056);
		}
		sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI = 53504;
		sbt_H793aWGm3q8Pm2aVOmVEGVv = false;
		sbt_hwx = 0.828767f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.push_back(855818272);
		}
		sbt_b56gQqJ = 9840114526240907442;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_W_1R7Ty4FAOEAVmgN.push_back("!6j6#_02vfwOU+U");
		}
		sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm = L"+4mg93:q48ac].?8x5DIg?j\"{,ji3PE";
		sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk = 206129717;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.push_back(-5652071042204678208);
		}
		sbt_Mi1 = L"fhaFRJy651%bA*@NpW";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_qPmgZ.push_back(3394340274);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.push_back(140);
		}
		sbt_jgpwuUkjyFwopdoOX = 22;
		sbt_KeBmIN45AHQE2SzWSuM = L"}l\\4x=?(pRcH.if;n:&g$;{U-K~[tB^!5DY`/}3@g6V?C286Dt2C";
		sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv = 0.601343;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_JTP.push_back(123);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_qG6jYn8exeCnSSVJK3iouFmLT.push_back(L"%Mt\\>=vH)3e;*FS_bx.IZQ*EC.!#Ah8q:x/4[T)2");
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.push_back(30748);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.push_back(41);
		}
		sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL = 0.543630;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.push_back(25154);
		}
		sbt_VJSVlLPzu6SZBLgy3qbC57hQr = 3034633621;
		sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR = 3537631554598100574;
		sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi = 4288436013;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_FBJGedd v;

			v.SetupWithSomeValues();
			sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U *pObject = dynamic_cast<const sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Lz5lT.size() != pObject->sbt_Lz5lT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Lz5lT.size(); i++)
		{
			if (sbt_Lz5lT[i] != pObject->sbt_Lz5lT[i])
			{
				return false;
			}
		}
		if (sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI != pObject->sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI)
		{
			return false;
		}
		if (sbt_H793aWGm3q8Pm2aVOmVEGVv != pObject->sbt_H793aWGm3q8Pm2aVOmVEGVv)
		{
			return false;
		}
		if (sbt_hwx != pObject->sbt_hwx)
		{
			return false;
		}
		if (sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.size() != pObject->sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.size(); i++)
		{
			if (sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ[i] != pObject->sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ[i])
			{
				return false;
			}
		}
		if (sbt_b56gQqJ != pObject->sbt_b56gQqJ)
		{
			return false;
		}
		if (sbt_W_1R7Ty4FAOEAVmgN.size() != pObject->sbt_W_1R7Ty4FAOEAVmgN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W_1R7Ty4FAOEAVmgN.size(); i++)
		{
			if (0 != cx_strcmp(sbt_W_1R7Ty4FAOEAVmgN[i].c_str(), pObject->sbt_W_1R7Ty4FAOEAVmgN[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm.c_str(), pObject->sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm.c_str()))
		{
			return false;
		}
		if (sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk != pObject->sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk)
		{
			return false;
		}
		if (sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.size() != pObject->sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.size(); i++)
		{
			if (sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3[i] != pObject->sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_Mi1.c_str(), pObject->sbt_Mi1.c_str()))
		{
			return false;
		}
		if (sbt_qPmgZ.size() != pObject->sbt_qPmgZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qPmgZ.size(); i++)
		{
			if (sbt_qPmgZ[i] != pObject->sbt_qPmgZ[i])
			{
				return false;
			}
		}
		if (sbt_TsA.size() != pObject->sbt_TsA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TsA.size(); i++)
		{
			if (0 != cx_strcmp(sbt_TsA[i].c_str(), pObject->sbt_TsA[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.size() != pObject->sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.size(); i++)
		{
			if (sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md[i] != pObject->sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md[i])
			{
				return false;
			}
		}
		if (sbt_jgpwuUkjyFwopdoOX != pObject->sbt_jgpwuUkjyFwopdoOX)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_KeBmIN45AHQE2SzWSuM.c_str(), pObject->sbt_KeBmIN45AHQE2SzWSuM.c_str()))
		{
			return false;
		}
		if (sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv != pObject->sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv)
		{
			return false;
		}
		if (sbt_JTP.size() != pObject->sbt_JTP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JTP.size(); i++)
		{
			if (sbt_JTP[i] != pObject->sbt_JTP[i])
			{
				return false;
			}
		}
		if (sbt_qG6jYn8exeCnSSVJK3iouFmLT.size() != pObject->sbt_qG6jYn8exeCnSSVJK3iouFmLT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qG6jYn8exeCnSSVJK3iouFmLT.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_qG6jYn8exeCnSSVJK3iouFmLT[i].c_str(), pObject->sbt_qG6jYn8exeCnSSVJK3iouFmLT[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.size() != pObject->sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.size(); i++)
		{
			if (sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6[i] != pObject->sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6[i])
			{
				return false;
			}
		}
		if (sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.size() != pObject->sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.size(); i++)
		{
			if (sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj[i] != pObject->sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj[i])
			{
				return false;
			}
		}
		if (sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL != pObject->sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL)
		{
			return false;
		}
		if (sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.size() != pObject->sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.size(); i++)
		{
			if (sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd[i] != pObject->sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd[i])
			{
				return false;
			}
		}
		if (sbt_VJSVlLPzu6SZBLgy3qbC57hQr != pObject->sbt_VJSVlLPzu6SZBLgy3qbC57hQr)
		{
			return false;
		}
		if (sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR != pObject->sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR)
		{
			return false;
		}
		if (sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi != pObject->sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi)
		{
			return false;
		}
		if (sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.size() != pObject->sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.size(); i++)
		{
			if (!sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF[i].Compare(&pObject->sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Lz5lT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Lz5lT.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_H793aWGm3q8Pm2aVOmVEGVv", &sbt_H793aWGm3q8Pm2aVOmVEGVv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_hwx", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_hwx = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_b56gQqJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b56gQqJ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_W_1R7Ty4FAOEAVmgN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W_1R7Ty4FAOEAVmgN.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm", &sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_Mi1", &sbt_Mi1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qPmgZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qPmgZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TsA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TsA.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jgpwuUkjyFwopdoOX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jgpwuUkjyFwopdoOX = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_KeBmIN45AHQE2SzWSuM", &sbt_KeBmIN45AHQE2SzWSuM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_JTP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JTP.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qG6jYn8exeCnSSVJK3iouFmLT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qG6jYn8exeCnSSVJK3iouFmLT.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VJSVlLPzu6SZBLgy3qbC57hQr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VJSVlLPzu6SZBLgy3qbC57hQr = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_FBJGedd tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Lz5lT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Lz5lT.begin(); iter != sbt_Lz5lT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI", (CX::Int64)sbt_LAdo5tFaoC6R6VktCmoogURYSq_9OgI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_H793aWGm3q8Pm2aVOmVEGVv", sbt_H793aWGm3q8Pm2aVOmVEGVv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_hwx", (CX::Double)sbt_hwx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.begin(); iter != sbt_o39LXyy4rHUdA1ndMaKXL72o2WBDZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b56gQqJ", (CX::Int64)sbt_b56gQqJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W_1R7Ty4FAOEAVmgN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_W_1R7Ty4FAOEAVmgN.begin(); iter != sbt_W_1R7Ty4FAOEAVmgN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm", sbt_8Wo8PiQHK8S4sMBwKYPAvX2BDO9Sbx5qzJdDda2HfGyMlaEHm.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk", (CX::Int64)sbt_gABG5eY0BseqA_PMsQEqdcvk9B7Z0SioWAk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.begin(); iter != sbt_wK3ZcSis2d81TZMdkBhxqc0C5337QyBx1WbUKmFuw6vS3g1gvnmWJChO3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_Mi1", sbt_Mi1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qPmgZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_qPmgZ.begin(); iter != sbt_qPmgZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TsA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_TsA.begin(); iter != sbt_TsA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.begin(); iter != sbt_9wBsQLJk02WL3cleFIjwuZv2Kf9Md.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jgpwuUkjyFwopdoOX", (CX::Int64)sbt_jgpwuUkjyFwopdoOX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_KeBmIN45AHQE2SzWSuM", sbt_KeBmIN45AHQE2SzWSuM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv", (CX::Double)sbt_cjAwZ6f8paYhgQ3k3QVglJoGZ76fv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JTP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_JTP.begin(); iter != sbt_JTP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qG6jYn8exeCnSSVJK3iouFmLT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_qG6jYn8exeCnSSVJK3iouFmLT.begin(); iter != sbt_qG6jYn8exeCnSSVJK3iouFmLT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.begin(); iter != sbt_mdHQ2aCREPpouHPjlZQG__nQiS950APwnpcAwrI19uatAZVQdkUfLFOVEeVMDk6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.begin(); iter != sbt_v4Au4CxgCuqOqEjZy7AtQHq52GdvwWH7z2NClDk4iXjqj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL", (CX::Double)sbt_I1JcbqyJjuTqzHMWfDjh3Sym3tTZE__scNTvL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.begin(); iter != sbt_aoBP6fQfPIeqKQLW6131XMo5TeKBihvfiHf1yRFKd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VJSVlLPzu6SZBLgy3qbC57hQr", (CX::Int64)sbt_VJSVlLPzu6SZBLgy3qbC57hQr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR", (CX::Int64)sbt_LpOVoBMkB1ktGnA7QzRgLPhRpEWGxSvQIg_2v0_IT2tW3hcZR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi", (CX::Int64)sbt_2jLHmqoSjWod61TrKPJf3qzItNBKsECaaLY9oUi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF")).IsNOK())
		{
			return status;
		}
		for (sbt_FBJGeddArray::const_iterator iter = sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.begin(); iter != sbt_BIKfBllVQOmSaPOJbohoEwcmoEPSyWtPimF.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U>::Type sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0UArray;

