
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4;
	CX::Int32 sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u;
	CX::UInt32 sbt_QR99dyuBpEeMbkDY4LyTj;
	CX::UInt64 sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY;
	CX::IO::SimpleBuffers::StringArray sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq;
	CX::IO::SimpleBuffers::UInt32Array sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv;
	CX::Int16 sbt_piW5ztB6R_nut5WMl;
	CX::UInt32 sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv;
	CX::IO::SimpleBuffers::Int8Array sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m;
	CX::UInt8 sbt_XyANLDzmC;
	CX::Int32 sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m;

	virtual void Reset()
	{
		sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.clear();
		sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u = 0;
		sbt_QR99dyuBpEeMbkDY4LyTj = 0;
		sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY = 0;
		sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.clear();
		sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.clear();
		sbt_piW5ztB6R_nut5WMl = 0;
		sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv = 0;
		sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.clear();
		sbt_XyANLDzmC = 0;
		sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.push_back(227);
		}
		sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u = 961254191;
		sbt_QR99dyuBpEeMbkDY4LyTj = 1054737972;
		sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY = 6085990055260801460;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.push_back("4JYu@t%jE~$8&v?\"zO:#mxJePiu");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.push_back(2898300051);
		}
		sbt_piW5ztB6R_nut5WMl = 31093;
		sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv = 2188674968;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.push_back(10);
		}
		sbt_XyANLDzmC = 216;
		sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m = 223988384;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i *pObject = dynamic_cast<const sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.size() != pObject->sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.size(); i++)
		{
			if (sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4[i] != pObject->sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4[i])
			{
				return false;
			}
		}
		if (sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u != pObject->sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u)
		{
			return false;
		}
		if (sbt_QR99dyuBpEeMbkDY4LyTj != pObject->sbt_QR99dyuBpEeMbkDY4LyTj)
		{
			return false;
		}
		if (sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY != pObject->sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY)
		{
			return false;
		}
		if (sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.size() != pObject->sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq[i].c_str(), pObject->sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.size() != pObject->sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.size(); i++)
		{
			if (sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv[i] != pObject->sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv[i])
			{
				return false;
			}
		}
		if (sbt_piW5ztB6R_nut5WMl != pObject->sbt_piW5ztB6R_nut5WMl)
		{
			return false;
		}
		if (sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv != pObject->sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv)
		{
			return false;
		}
		if (sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.size() != pObject->sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.size(); i++)
		{
			if (sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m[i] != pObject->sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m[i])
			{
				return false;
			}
		}
		if (sbt_XyANLDzmC != pObject->sbt_XyANLDzmC)
		{
			return false;
		}
		if (sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m != pObject->sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QR99dyuBpEeMbkDY4LyTj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QR99dyuBpEeMbkDY4LyTj = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_piW5ztB6R_nut5WMl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_piW5ztB6R_nut5WMl = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XyANLDzmC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XyANLDzmC = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.begin(); iter != sbt_rZ8ivd9zZvACRNMIlbXX1EtwIGuaMbTtBm05_bf5tsRNUhEJIm4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u", (CX::Int64)sbt_zpz56JeU4OH6Yz3cYrdQZ7BV0Gs77tAPI8u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QR99dyuBpEeMbkDY4LyTj", (CX::Int64)sbt_QR99dyuBpEeMbkDY4LyTj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY", (CX::Int64)sbt_91D3mZ6gs6kz8AtRW7m5Y2_13yGXpLY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.begin(); iter != sbt_fa3NTgwhrMcvTs4LSaEZMADmGdkCLKuWaotlwLpc5Xi6pmcKnLi9o0Nd4ykVq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.begin(); iter != sbt_Q7XNzf4Q4xZlNJXlX7F5OSGLkGNtptTJQV9RthIkseyISH_V9yoHv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_piW5ztB6R_nut5WMl", (CX::Int64)sbt_piW5ztB6R_nut5WMl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv", (CX::Int64)sbt_QCxqcCFecxpNm54mvKt_5TLvgt1aMD7eo1kTv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.begin(); iter != sbt_iC4osFETztq9gbFVnbOidSHOUsY4fWguqpJqZ_tuDCwFEZlp2jaXm8ysd8m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XyANLDzmC", (CX::Int64)sbt_XyANLDzmC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m", (CX::Int64)sbt_VY5jCJewpflAAlCbAOPaHEsQ6dVJ4K7D8cn4m)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i>::Type sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4iArray;

