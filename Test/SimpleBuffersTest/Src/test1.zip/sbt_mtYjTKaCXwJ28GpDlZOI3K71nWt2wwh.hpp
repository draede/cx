
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib.hpp"


class sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_;
	CX::IO::SimpleBuffers::BoolArray sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn;
	CX::Float sbt_nIm26;
	CX::String sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb;
	CX::IO::SimpleBuffers::DoubleArray sbt_Amd_DllCJP_;
	CX::IO::SimpleBuffers::StringArray sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS;
	CX::IO::SimpleBuffers::Int16Array sbt_D;
	CX::WString sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM;
	CX::WString sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB;
	CX::UInt64 sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6;
	CX::Int64 sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG;
	CX::Double sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk;
	CX::Int16 sbt_iDKlzstra;
	CX::Float sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt;
	CX::Float sbt_ShN;
	sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib sbt_uZE;

	virtual void Reset()
	{
		sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_ = 0;
		sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.clear();
		sbt_nIm26 = 0.0f;
		sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb.clear();
		sbt_Amd_DllCJP_.clear();
		sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.clear();
		sbt_D.clear();
		sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM.clear();
		sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB.clear();
		sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6 = 0;
		sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG = 0;
		sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk = 0.0;
		sbt_iDKlzstra = 0;
		sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt = 0.0f;
		sbt_ShN = 0.0f;
		sbt_uZE.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_ = 2948537692;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.push_back(true);
		}
		sbt_nIm26 = 0.197874f;
		sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb = "[oI2YGDg&>y$o]w#[I3=zzj!1.>OFHH8";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Amd_DllCJP_.push_back(0.003811);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.push_back(":1eO?m[uO-9l095N^j1A\"t\\J_a%$0zSe7_lrhAPPGme.-g-NFr6@?RHI1kZ]bN");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_D.push_back(-2335);
		}
		sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM = L"Y";
		sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB = L"3gS2X5-B7uceV__5yF";
		sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6 = 2395282223622501722;
		sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG = 1323508838139269304;
		sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk = 0.917086;
		sbt_iDKlzstra = 11962;
		sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt = 0.835534f;
		sbt_ShN = 0.135161f;
		sbt_uZE.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh *pObject = dynamic_cast<const sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_ != pObject->sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_)
		{
			return false;
		}
		if (sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.size() != pObject->sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.size(); i++)
		{
			if (sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn[i] != pObject->sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn[i])
			{
				return false;
			}
		}
		if (sbt_nIm26 != pObject->sbt_nIm26)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb.c_str(), pObject->sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb.c_str()))
		{
			return false;
		}
		if (sbt_Amd_DllCJP_.size() != pObject->sbt_Amd_DllCJP_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Amd_DllCJP_.size(); i++)
		{
			if (sbt_Amd_DllCJP_[i] != pObject->sbt_Amd_DllCJP_[i])
			{
				return false;
			}
		}
		if (sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.size() != pObject->sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.size(); i++)
		{
			if (0 != cx_strcmp(sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS[i].c_str(), pObject->sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_D.size() != pObject->sbt_D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D.size(); i++)
		{
			if (sbt_D[i] != pObject->sbt_D[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM.c_str(), pObject->sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM.c_str()))
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB.c_str(), pObject->sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB.c_str()))
		{
			return false;
		}
		if (sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6 != pObject->sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6)
		{
			return false;
		}
		if (sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG != pObject->sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG)
		{
			return false;
		}
		if (sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk != pObject->sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk)
		{
			return false;
		}
		if (sbt_iDKlzstra != pObject->sbt_iDKlzstra)
		{
			return false;
		}
		if (sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt != pObject->sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt)
		{
			return false;
		}
		if (sbt_ShN != pObject->sbt_ShN)
		{
			return false;
		}
		if (!sbt_uZE.Compare(&pObject->sbt_uZE))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_nIm26", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_nIm26 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectString("sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb", &sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Amd_DllCJP_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Amd_DllCJP_.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM", &sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB", &sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_iDKlzstra", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iDKlzstra = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_ShN", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ShN = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectObject("sbt_uZE")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_uZE.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_", (CX::Int64)sbt_NnCsDeU4sjJg8QeRlRKknlON8BiJI7Kbd4N2iWxXhYdaWkzeeV7y2mqDxgc5sn_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.begin(); iter != sbt_7BS5GzsDg27FuxsWldOXToDrR61OOFFTt0pLcRgGAUnrVj8jn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_nIm26", (CX::Double)sbt_nIm26)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb", sbt_e1twTBQjPF0lHwIfp2FXjmryV4ngCHSI6EeZADPlFSq2LF0PL3lJb.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Amd_DllCJP_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Amd_DllCJP_.begin(); iter != sbt_Amd_DllCJP_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.begin(); iter != sbt_kpHTz5DydimzrXMNtwlbevIulBZgFyS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_D.begin(); iter != sbt_D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM", sbt_8cBvkuTxDUbBsU5Nz2MzxwxKM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB", sbt_LHoRjIg9mLaox_zsFW7zx6L9OiEpW_EFqXBfB.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6", (CX::Int64)sbt_jbEcMud3vaMo7jpMwu15uEkf25D5LOWPNAekzN6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG", (CX::Int64)sbt_tAdIsKOPR37z65Nx9wirB8iMhtYdtQSG9QdAufYiqcG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk", (CX::Double)sbt_TfbZKeFSzFd57SYfetdT8obCGiPUtSUkkdztbXsQruonwBHlcLk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iDKlzstra", (CX::Int64)sbt_iDKlzstra)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt", (CX::Double)sbt_Q4x6i5_IeCLsyD2cuw9KoqKAje9hZCOx0wt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ShN", (CX::Double)sbt_ShN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_uZE")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_uZE.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh>::Type sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwhArray;

