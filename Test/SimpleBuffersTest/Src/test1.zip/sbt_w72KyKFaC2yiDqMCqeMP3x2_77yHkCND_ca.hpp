
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_AZSNy86NBL6dpGjwY;

	virtual void Reset()
	{
		sbt_AZSNy86NBL6dpGjwY = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_AZSNy86NBL6dpGjwY = 50141;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca *pObject = dynamic_cast<const sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_AZSNy86NBL6dpGjwY != pObject->sbt_AZSNy86NBL6dpGjwY)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_AZSNy86NBL6dpGjwY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AZSNy86NBL6dpGjwY = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_AZSNy86NBL6dpGjwY", (CX::Int64)sbt_AZSNy86NBL6dpGjwY)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca>::Type sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_caArray;

