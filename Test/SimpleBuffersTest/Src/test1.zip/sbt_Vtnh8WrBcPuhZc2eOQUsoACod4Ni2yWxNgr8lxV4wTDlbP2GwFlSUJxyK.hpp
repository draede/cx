
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_F37TR5tQnzaqiIY.hpp"


class sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0;
	CX::Int16 sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0;
	CX::UInt64 sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA;
	CX::IO::SimpleBuffers::UInt32Array sbt_Q;
	CX::IO::SimpleBuffers::UInt32Array sbt_q2OkhAVaPNazg;
	CX::IO::SimpleBuffers::Int16Array sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc;
	CX::UInt32 sbt_JWKTCKQKHOHCoTN;
	CX::IO::SimpleBuffers::UInt16Array sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO;
	CX::IO::SimpleBuffers::WStringArray sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV;
	CX::IO::SimpleBuffers::FloatArray sbt_ZknfN5vgUT85Zda;
	CX::Int32 sbt_X3cET0zLy6f9o_X;
	CX::Double sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH;
	CX::IO::SimpleBuffers::BoolArray sbt_KvcPgfCzH8wDXus;
	CX::UInt16 sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr;
	CX::UInt16 sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC;
	CX::IO::SimpleBuffers::FloatArray sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz;
	CX::IO::SimpleBuffers::BoolArray sbt_pUI;
	CX::WString sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl;
	CX::IO::SimpleBuffers::UInt64Array sbt_7w92zMP3yYIgBtLFgyPnKoMsD;
	CX::Int32 sbt_30GynOBycyzmgtfhu;
	CX::Bool sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6;
	CX::IO::SimpleBuffers::StringArray sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo;
	CX::IO::SimpleBuffers::Int8Array sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0;
	CX::IO::SimpleBuffers::Int8Array sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_;
	CX::Int8 sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi;
	CX::UInt8 sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH;
	CX::Double sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0;
	CX::IO::SimpleBuffers::WStringArray sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB;
	sbt_F37TR5tQnzaqiIYArray sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922;

	virtual void Reset()
	{
		sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.clear();
		sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0 = 0;
		sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA = 0;
		sbt_Q.clear();
		sbt_q2OkhAVaPNazg.clear();
		sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.clear();
		sbt_JWKTCKQKHOHCoTN = 0;
		sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.clear();
		sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.clear();
		sbt_ZknfN5vgUT85Zda.clear();
		sbt_X3cET0zLy6f9o_X = 0;
		sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH = 0.0;
		sbt_KvcPgfCzH8wDXus.clear();
		sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr = 0;
		sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC = 0;
		sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.clear();
		sbt_pUI.clear();
		sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl.clear();
		sbt_7w92zMP3yYIgBtLFgyPnKoMsD.clear();
		sbt_30GynOBycyzmgtfhu = 0;
		sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6 = false;
		sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.clear();
		sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.clear();
		sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.clear();
		sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi = 0;
		sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH = 0;
		sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0 = 0.0;
		sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.clear();
		sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.push_back(17962575661795080134);
		}
		sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0 = -9781;
		sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA = 11761981699564317726;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Q.push_back(3064865893);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_q2OkhAVaPNazg.push_back(2228800910);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.push_back(30683);
		}
		sbt_JWKTCKQKHOHCoTN = 1433670787;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.push_back(30138);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.push_back(L"@!+9(d$<S8k;g[/b");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ZknfN5vgUT85Zda.push_back(0.095229f);
		}
		sbt_X3cET0zLy6f9o_X = -655831345;
		sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH = 0.637912;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_KvcPgfCzH8wDXus.push_back(true);
		}
		sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr = 50486;
		sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC = 30920;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.push_back(0.487007f);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_pUI.push_back(true);
		}
		sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl = L"kv+#fB.H^gF\\=?L\\*31cA>UC{*]?xty}e";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_7w92zMP3yYIgBtLFgyPnKoMsD.push_back(3956837877831418652);
		}
		sbt_30GynOBycyzmgtfhu = 190839449;
		sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6 = true;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.push_back("8?cGZbDL+~]6~h[Qe;>KATOnBYyQWH\"W}N=7Tf}zi)s");
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.push_back(-111);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.push_back(-104);
		}
		sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi = 40;
		sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH = 40;
		sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0 = 0.342242;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.push_back(L"%NWO6j]&.]w4I7^a&JjoNL?CY0_p<DO>ZmF;Hz\\'Kxo*|qTr?");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_F37TR5tQnzaqiIY v;

			v.SetupWithSomeValues();
			sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK *pObject = dynamic_cast<const sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.size() != pObject->sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.size(); i++)
		{
			if (sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0[i] != pObject->sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0[i])
			{
				return false;
			}
		}
		if (sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0 != pObject->sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0)
		{
			return false;
		}
		if (sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA != pObject->sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA)
		{
			return false;
		}
		if (sbt_Q.size() != pObject->sbt_Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q.size(); i++)
		{
			if (sbt_Q[i] != pObject->sbt_Q[i])
			{
				return false;
			}
		}
		if (sbt_q2OkhAVaPNazg.size() != pObject->sbt_q2OkhAVaPNazg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q2OkhAVaPNazg.size(); i++)
		{
			if (sbt_q2OkhAVaPNazg[i] != pObject->sbt_q2OkhAVaPNazg[i])
			{
				return false;
			}
		}
		if (sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.size() != pObject->sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.size(); i++)
		{
			if (sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc[i] != pObject->sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc[i])
			{
				return false;
			}
		}
		if (sbt_JWKTCKQKHOHCoTN != pObject->sbt_JWKTCKQKHOHCoTN)
		{
			return false;
		}
		if (sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.size() != pObject->sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.size(); i++)
		{
			if (sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO[i] != pObject->sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO[i])
			{
				return false;
			}
		}
		if (sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.size() != pObject->sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV[i].c_str(), pObject->sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ZknfN5vgUT85Zda.size() != pObject->sbt_ZknfN5vgUT85Zda.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZknfN5vgUT85Zda.size(); i++)
		{
			if (sbt_ZknfN5vgUT85Zda[i] != pObject->sbt_ZknfN5vgUT85Zda[i])
			{
				return false;
			}
		}
		if (sbt_X3cET0zLy6f9o_X != pObject->sbt_X3cET0zLy6f9o_X)
		{
			return false;
		}
		if (sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH != pObject->sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH)
		{
			return false;
		}
		if (sbt_KvcPgfCzH8wDXus.size() != pObject->sbt_KvcPgfCzH8wDXus.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KvcPgfCzH8wDXus.size(); i++)
		{
			if (sbt_KvcPgfCzH8wDXus[i] != pObject->sbt_KvcPgfCzH8wDXus[i])
			{
				return false;
			}
		}
		if (sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr != pObject->sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr)
		{
			return false;
		}
		if (sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC != pObject->sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC)
		{
			return false;
		}
		if (sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.size() != pObject->sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.size(); i++)
		{
			if (sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz[i] != pObject->sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz[i])
			{
				return false;
			}
		}
		if (sbt_pUI.size() != pObject->sbt_pUI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pUI.size(); i++)
		{
			if (sbt_pUI[i] != pObject->sbt_pUI[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl.c_str(), pObject->sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl.c_str()))
		{
			return false;
		}
		if (sbt_7w92zMP3yYIgBtLFgyPnKoMsD.size() != pObject->sbt_7w92zMP3yYIgBtLFgyPnKoMsD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7w92zMP3yYIgBtLFgyPnKoMsD.size(); i++)
		{
			if (sbt_7w92zMP3yYIgBtLFgyPnKoMsD[i] != pObject->sbt_7w92zMP3yYIgBtLFgyPnKoMsD[i])
			{
				return false;
			}
		}
		if (sbt_30GynOBycyzmgtfhu != pObject->sbt_30GynOBycyzmgtfhu)
		{
			return false;
		}
		if (sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6 != pObject->sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6)
		{
			return false;
		}
		if (sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.size() != pObject->sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.size(); i++)
		{
			if (0 != cx_strcmp(sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo[i].c_str(), pObject->sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo[i].c_str()))
			{
				return false;
			}
		}
		if (sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.size() != pObject->sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.size(); i++)
		{
			if (sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0[i] != pObject->sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0[i])
			{
				return false;
			}
		}
		if (sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.size() != pObject->sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.size(); i++)
		{
			if (sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_[i] != pObject->sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_[i])
			{
				return false;
			}
		}
		if (sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi != pObject->sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi)
		{
			return false;
		}
		if (sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH != pObject->sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH)
		{
			return false;
		}
		if (sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0 != pObject->sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0)
		{
			return false;
		}
		if (sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.size() != pObject->sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB[i].c_str(), pObject->sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.size() != pObject->sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.size(); i++)
		{
			if (!sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922[i].Compare(&pObject->sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_q2OkhAVaPNazg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q2OkhAVaPNazg.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JWKTCKQKHOHCoTN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JWKTCKQKHOHCoTN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZknfN5vgUT85Zda")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZknfN5vgUT85Zda.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_X3cET0zLy6f9o_X", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_X3cET0zLy6f9o_X = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_KvcPgfCzH8wDXus")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KvcPgfCzH8wDXus.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pUI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pUI.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl", &sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7w92zMP3yYIgBtLFgyPnKoMsD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7w92zMP3yYIgBtLFgyPnKoMsD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_30GynOBycyzmgtfhu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_30GynOBycyzmgtfhu = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6", &sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_F37TR5tQnzaqiIY tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.begin(); iter != sbt_uJYUmwXv9qiSW5LoufHWog8iExo63Yp6GKaqiGMqHIBZ0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0", (CX::Int64)sbt_bJ0ynAdVJ4hWxy4qbZ9j5XTN_Sow9B0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA", (CX::Int64)sbt_17KCU6zdWoyyD1Mw6REivdwEs_NCateDA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Q.begin(); iter != sbt_Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q2OkhAVaPNazg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_q2OkhAVaPNazg.begin(); iter != sbt_q2OkhAVaPNazg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.begin(); iter != sbt_z9Hys7ilT9vMHi62f489pICzhLRGmmfCvKjB1Qnm1e4x_sXXSYJsc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JWKTCKQKHOHCoTN", (CX::Int64)sbt_JWKTCKQKHOHCoTN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.begin(); iter != sbt_yVtHu4BczJ8dkaojL4Mj42TGheE1jBcVxPO6PvcLO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.begin(); iter != sbt_wcLHcXBEL3O7Ehqm9o7b8bUwR0T4cuV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZknfN5vgUT85Zda")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_ZknfN5vgUT85Zda.begin(); iter != sbt_ZknfN5vgUT85Zda.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_X3cET0zLy6f9o_X", (CX::Int64)sbt_X3cET0zLy6f9o_X)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH", (CX::Double)sbt_CZONeKJQWybcQeRZhx_cU12Q6Jsm4ks4Z30EOSDgZ_vUTpZZ_AwdH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KvcPgfCzH8wDXus")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_KvcPgfCzH8wDXus.begin(); iter != sbt_KvcPgfCzH8wDXus.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr", (CX::Int64)sbt_tXnKFA00ADBIVeowFbcJuwaJ0YqfddeLe6KPEIGWOB4Kvxh3zln_BZMIKC7Nr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC", (CX::Int64)sbt_hhGOhk31NQyW_GfHOD4U96upxpS9oXOvK3Ao0mC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.begin(); iter != sbt_HbYiN7sZkvT4CmR_rc3fxRTmd2Ebd5RjsPTgZGt1rfFIz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pUI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_pUI.begin(); iter != sbt_pUI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl", sbt_8Tc_njc03sPI4uMv6d7ZH2QCWNl.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7w92zMP3yYIgBtLFgyPnKoMsD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_7w92zMP3yYIgBtLFgyPnKoMsD.begin(); iter != sbt_7w92zMP3yYIgBtLFgyPnKoMsD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_30GynOBycyzmgtfhu", (CX::Int64)sbt_30GynOBycyzmgtfhu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6", sbt_GhZVAuJ3dTisJx3AFxrBEWuZ6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.begin(); iter != sbt_4zAIlM8FJ8X_EOYb_z_1qDMDntsdFX0H9avbBADc2zQEo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.begin(); iter != sbt__76xiwMaRZzjL7NYJ8SMDansHuEfLYJydDzYCHRNfBlcGHCan3c_bEpJ9JiT0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.begin(); iter != sbt_rJz8gJD2n7q1xq9StF9jOlTimX5kqAGTFe_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi", (CX::Int64)sbt_2LEDuHrTMp2L0a4vopjAFkRPm9UXTWzCc2kYzQ8oaEgzQMi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH", (CX::Int64)sbt_K0blpkPIvK_5VRCiIAYADHPSs4pSMhI_kfrCEwHmEfH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0", (CX::Double)sbt_0RG_5KXaKuqAvj_ho0zXOuS2arirvkvqbpip5GnUEK0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.begin(); iter != sbt_NrLWdgQKEHC5TRnOgVdnYOyC2Ua74eiEFJGlB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922")).IsNOK())
		{
			return status;
		}
		for (sbt_F37TR5tQnzaqiIYArray::const_iterator iter = sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.begin(); iter != sbt_GQaDFUlKvKZtxYkdvm7bFWV9qYpp6BXosCq5drBrmQkytRET1bul922.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK>::Type sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyKArray;

