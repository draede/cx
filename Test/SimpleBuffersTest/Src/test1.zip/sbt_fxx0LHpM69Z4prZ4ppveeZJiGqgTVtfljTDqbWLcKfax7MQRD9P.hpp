
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_KMMmg;
	CX::Int64 sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ;
	CX::UInt64 sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g;
	CX::IO::SimpleBuffers::UInt8Array sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374;
	CX::IO::SimpleBuffers::BoolArray sbt_X;
	CX::IO::SimpleBuffers::Int32Array sbt_y;

	virtual void Reset()
	{
		sbt_KMMmg = 0;
		sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ = 0;
		sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g = 0;
		sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.clear();
		sbt_X.clear();
		sbt_y.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_KMMmg = 2985006986;
		sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ = -1364727119662195892;
		sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g = 16155856365044310438;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.push_back(58);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_X.push_back(true);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_y.push_back(-735485502);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P *pObject = dynamic_cast<const sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_KMMmg != pObject->sbt_KMMmg)
		{
			return false;
		}
		if (sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ != pObject->sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ)
		{
			return false;
		}
		if (sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g != pObject->sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g)
		{
			return false;
		}
		if (sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.size() != pObject->sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.size(); i++)
		{
			if (sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374[i] != pObject->sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374[i])
			{
				return false;
			}
		}
		if (sbt_X.size() != pObject->sbt_X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X.size(); i++)
		{
			if (sbt_X[i] != pObject->sbt_X[i])
			{
				return false;
			}
		}
		if (sbt_y.size() != pObject->sbt_y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y.size(); i++)
		{
			if (sbt_y[i] != pObject->sbt_y[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_KMMmg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KMMmg = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_KMMmg", (CX::Int64)sbt_KMMmg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ", (CX::Int64)sbt_XJpWcSc8yMpSMMi3p3T_7_5aMbYYCd9bcEdfsEyL9GZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g", (CX::Int64)sbt_llOw9lT_6y810oH5OnrODtXkRvXnjzeRfaEmBQJdFbGO_5UQe0b1umF5g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.begin(); iter != sbt_2qAs7gQaF5aWzp6cxwBPdCqLy46JesTt9PNyRJnbUE4j6bqoc7hiR2374.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_X.begin(); iter != sbt_X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_y.begin(); iter != sbt_y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P>::Type sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9PArray;

