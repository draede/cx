
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI : public CX::IO::SimpleBuffers::IObject
{
public:


	virtual void Reset()
	{
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI *pObject = dynamic_cast<const sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;


		return CX::Status();
	}

};

typedef CX::Vector<sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI>::Type sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goIArray;

