
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ.hpp"


class sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_QM8TDHG3oCOUas6QDO6;
	CX::Int16 sbt_IEIbkDvNMQyUDBtACKB4W;
	CX::Int64 sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM;
	CX::Int64 sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD;
	CX::IO::SimpleBuffers::Int32Array sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH;
	CX::IO::SimpleBuffers::UInt64Array sbt_UlVD405AmuF8CHHwkYXpT;
	CX::IO::SimpleBuffers::UInt16Array sbt_HZM7oG1wxHqrzDY4jAn;
	CX::IO::SimpleBuffers::FloatArray sbt_9JpgCa50up1QNOiwblf;
	CX::IO::SimpleBuffers::Int32Array sbt_H4MDQENVwLlQO;
	CX::IO::SimpleBuffers::UInt64Array sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_;
	CX::IO::SimpleBuffers::WStringArray sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN;
	CX::IO::SimpleBuffers::Int16Array sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM;
	CX::Float sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4;
	CX::IO::SimpleBuffers::UInt8Array sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ;
	CX::UInt16 sbt_xR6m2NqiOfpTs;
	sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZArray sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz;

	virtual void Reset()
	{
		sbt_QM8TDHG3oCOUas6QDO6 = 0.0f;
		sbt_IEIbkDvNMQyUDBtACKB4W = 0;
		sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM = 0;
		sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD = 0;
		sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.clear();
		sbt_UlVD405AmuF8CHHwkYXpT.clear();
		sbt_HZM7oG1wxHqrzDY4jAn.clear();
		sbt_9JpgCa50up1QNOiwblf.clear();
		sbt_H4MDQENVwLlQO.clear();
		sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.clear();
		sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.clear();
		sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.clear();
		sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4 = 0.0f;
		sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.clear();
		sbt_xR6m2NqiOfpTs = 0;
		sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_QM8TDHG3oCOUas6QDO6 = 0.812369f;
		sbt_IEIbkDvNMQyUDBtACKB4W = 15703;
		sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM = -4972020004849782448;
		sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD = 5265613287080980058;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_UlVD405AmuF8CHHwkYXpT.push_back(1439854492031851000);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_HZM7oG1wxHqrzDY4jAn.push_back(19817);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_9JpgCa50up1QNOiwblf.push_back(0.318896f);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_H4MDQENVwLlQO.push_back(1296093293);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.push_back(10902848178888263884);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.push_back(L"kiY9M\"%R_Q/*J|(*eGRXY_k;,]L=-CT9TmIL{RWZ?\"D");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.push_back(-21705);
		}
		sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4 = 0.186158f;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.push_back(80);
		}
		sbt_xR6m2NqiOfpTs = 63276;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ v;

			v.SetupWithSomeValues();
			sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R *pObject = dynamic_cast<const sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_QM8TDHG3oCOUas6QDO6 != pObject->sbt_QM8TDHG3oCOUas6QDO6)
		{
			return false;
		}
		if (sbt_IEIbkDvNMQyUDBtACKB4W != pObject->sbt_IEIbkDvNMQyUDBtACKB4W)
		{
			return false;
		}
		if (sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM != pObject->sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM)
		{
			return false;
		}
		if (sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD != pObject->sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD)
		{
			return false;
		}
		if (sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.size() != pObject->sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.size(); i++)
		{
			if (sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH[i] != pObject->sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH[i])
			{
				return false;
			}
		}
		if (sbt_UlVD405AmuF8CHHwkYXpT.size() != pObject->sbt_UlVD405AmuF8CHHwkYXpT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UlVD405AmuF8CHHwkYXpT.size(); i++)
		{
			if (sbt_UlVD405AmuF8CHHwkYXpT[i] != pObject->sbt_UlVD405AmuF8CHHwkYXpT[i])
			{
				return false;
			}
		}
		if (sbt_HZM7oG1wxHqrzDY4jAn.size() != pObject->sbt_HZM7oG1wxHqrzDY4jAn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HZM7oG1wxHqrzDY4jAn.size(); i++)
		{
			if (sbt_HZM7oG1wxHqrzDY4jAn[i] != pObject->sbt_HZM7oG1wxHqrzDY4jAn[i])
			{
				return false;
			}
		}
		if (sbt_9JpgCa50up1QNOiwblf.size() != pObject->sbt_9JpgCa50up1QNOiwblf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9JpgCa50up1QNOiwblf.size(); i++)
		{
			if (sbt_9JpgCa50up1QNOiwblf[i] != pObject->sbt_9JpgCa50up1QNOiwblf[i])
			{
				return false;
			}
		}
		if (sbt_H4MDQENVwLlQO.size() != pObject->sbt_H4MDQENVwLlQO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H4MDQENVwLlQO.size(); i++)
		{
			if (sbt_H4MDQENVwLlQO[i] != pObject->sbt_H4MDQENVwLlQO[i])
			{
				return false;
			}
		}
		if (sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.size() != pObject->sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.size(); i++)
		{
			if (sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_[i] != pObject->sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_[i])
			{
				return false;
			}
		}
		if (sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.size() != pObject->sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN[i].c_str(), pObject->sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.size() != pObject->sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.size(); i++)
		{
			if (sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM[i] != pObject->sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM[i])
			{
				return false;
			}
		}
		if (sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4 != pObject->sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4)
		{
			return false;
		}
		if (sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.size() != pObject->sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.size(); i++)
		{
			if (sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ[i] != pObject->sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ[i])
			{
				return false;
			}
		}
		if (sbt_xR6m2NqiOfpTs != pObject->sbt_xR6m2NqiOfpTs)
		{
			return false;
		}
		if (sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.size() != pObject->sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.size(); i++)
		{
			if (!sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz[i].Compare(&pObject->sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_QM8TDHG3oCOUas6QDO6", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_QM8TDHG3oCOUas6QDO6 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_IEIbkDvNMQyUDBtACKB4W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IEIbkDvNMQyUDBtACKB4W = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UlVD405AmuF8CHHwkYXpT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UlVD405AmuF8CHHwkYXpT.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HZM7oG1wxHqrzDY4jAn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HZM7oG1wxHqrzDY4jAn.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9JpgCa50up1QNOiwblf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9JpgCa50up1QNOiwblf.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H4MDQENVwLlQO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H4MDQENVwLlQO.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xR6m2NqiOfpTs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xR6m2NqiOfpTs = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_QM8TDHG3oCOUas6QDO6", (CX::Double)sbt_QM8TDHG3oCOUas6QDO6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IEIbkDvNMQyUDBtACKB4W", (CX::Int64)sbt_IEIbkDvNMQyUDBtACKB4W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM", (CX::Int64)sbt_gnwmTa6Za0UDxaxzpx47591qLtC6ZPCNM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD", (CX::Int64)sbt_E9FxhxLhkpXYeP3lzthVTIjvq8Kw8EDwYsxrHn5aUWJBsbcazL6cWz0rNWD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.begin(); iter != sbt_kEaalf1bdvEuLamBO8882x4AOy6BAqipaNoWSrH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UlVD405AmuF8CHHwkYXpT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_UlVD405AmuF8CHHwkYXpT.begin(); iter != sbt_UlVD405AmuF8CHHwkYXpT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HZM7oG1wxHqrzDY4jAn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_HZM7oG1wxHqrzDY4jAn.begin(); iter != sbt_HZM7oG1wxHqrzDY4jAn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9JpgCa50up1QNOiwblf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_9JpgCa50up1QNOiwblf.begin(); iter != sbt_9JpgCa50up1QNOiwblf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H4MDQENVwLlQO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_H4MDQENVwLlQO.begin(); iter != sbt_H4MDQENVwLlQO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.begin(); iter != sbt_VtBUVAyyqK9EO4auCZ8P730T7NPeViRfULrydq_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.begin(); iter != sbt_LOFdIA3SAiwEZmFsDSpO8e6fg3BmggBylvpIfTmhAOHsS8cMzjbPsE3nN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.begin(); iter != sbt_t1E7fPiSaD1PEek8l5w9bP9XqWLvM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4", (CX::Double)sbt_fqtxcF0EZlZcUfFJ1jBw85Q8sE6jJ8B4zr7U4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.begin(); iter != sbt_C6LFeqAaSBHPLiWKmLefBRqfyn7nRDewPcpMKoNQ2x5Dt9USZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xR6m2NqiOfpTs", (CX::Int64)sbt_xR6m2NqiOfpTs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz")).IsNOK())
		{
			return status;
		}
		for (sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZArray::const_iterator iter = sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.begin(); iter != sbt_xcBeqXdYUd7VSO7aXr0g_GzEs60IwXg_asWipGkCRxz.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R>::Type sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1RArray;

