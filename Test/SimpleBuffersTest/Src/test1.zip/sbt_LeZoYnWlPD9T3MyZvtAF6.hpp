
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_LeZoYnWlPD9T3MyZvtAF6 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_Yvk;
	CX::IO::SimpleBuffers::Int8Array sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw;
	CX::Bool sbt_VHft_dofuGHqUXsjj;
	CX::IO::SimpleBuffers::Int8Array sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5;
	CX::String sbt_zCOrk_x;
	CX::IO::SimpleBuffers::StringArray sbt_oKN0YZvPOoUmQNtPsLfWxLT;
	CX::Int8 sbt_0NFfifRQIThTd;
	CX::Int16 sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh;
	CX::IO::SimpleBuffers::UInt8Array sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS;
	CX::Int32 sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y;
	CX::String sbt_enYnJHxn8g2UOD0;
	CX::UInt32 sbt_dYKRNkzSxgUm6dBZbbb6IShg3;
	CX::Int8 sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq;
	CX::IO::SimpleBuffers::Int8Array sbt_u0eTBolohF7c6vUgCaP;
	CX::IO::SimpleBuffers::BoolArray sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh;
	CX::IO::SimpleBuffers::UInt64Array sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM;
	CX::IO::SimpleBuffers::Int8Array sbt_bkTmpns3M;
	CX::Int32 sbt_Xg2GfVCYKWF3h;
	CX::Int16 sbt_nfJuhf6qD8hQXRJ1K;
	CX::IO::SimpleBuffers::UInt64Array sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q;
	CX::IO::SimpleBuffers::StringArray sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw;
	CX::IO::SimpleBuffers::Int64Array sbt_DPI;
	CX::IO::SimpleBuffers::UInt32Array sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA;
	CX::IO::SimpleBuffers::BoolArray sbt_y;
	CX::UInt8 sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82;
	CX::UInt64 sbt_VjKHnZbMR;
	CX::IO::SimpleBuffers::Int64Array sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi;
	CX::UInt32 sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu;

	virtual void Reset()
	{
		sbt_Yvk.clear();
		sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.clear();
		sbt_VHft_dofuGHqUXsjj = false;
		sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.clear();
		sbt_zCOrk_x.clear();
		sbt_oKN0YZvPOoUmQNtPsLfWxLT.clear();
		sbt_0NFfifRQIThTd = 0;
		sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh = 0;
		sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.clear();
		sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y = 0;
		sbt_enYnJHxn8g2UOD0.clear();
		sbt_dYKRNkzSxgUm6dBZbbb6IShg3 = 0;
		sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq = 0;
		sbt_u0eTBolohF7c6vUgCaP.clear();
		sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.clear();
		sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.clear();
		sbt_bkTmpns3M.clear();
		sbt_Xg2GfVCYKWF3h = 0;
		sbt_nfJuhf6qD8hQXRJ1K = 0;
		sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.clear();
		sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.clear();
		sbt_DPI.clear();
		sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.clear();
		sbt_y.clear();
		sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82 = 0;
		sbt_VjKHnZbMR = 0;
		sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.clear();
		sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Yvk.push_back(3702411150);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.push_back(-7);
		}
		sbt_VHft_dofuGHqUXsjj = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.push_back(46);
		}
		sbt_zCOrk_x = "kQ~6q0C.*o3zgn@1juXz?31o3ZADT}";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_oKN0YZvPOoUmQNtPsLfWxLT.push_back("D&wOKgl-ubYl0h)&AL`%)@]mt\"v2=Cd");
		}
		sbt_0NFfifRQIThTd = -123;
		sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh = -18490;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.push_back(45);
		}
		sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y = -521588239;
		sbt_enYnJHxn8g2UOD0 = "PLb$%<qpu+P9FWm2`LhrI!k-9o2z>m5K=a6sfi,^@T28:BR%rZ`VPfS~";
		sbt_dYKRNkzSxgUm6dBZbbb6IShg3 = 1478852514;
		sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq = -2;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_u0eTBolohF7c6vUgCaP.push_back(-60);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.push_back(false);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.push_back(8440306296479365908);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_bkTmpns3M.push_back(92);
		}
		sbt_Xg2GfVCYKWF3h = 942477330;
		sbt_nfJuhf6qD8hQXRJ1K = 6982;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.push_back(6361615056813549308);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.push_back("ckozibNnWOML#P}\"e}S/umceCWr4x]192L/WJ$~f\\tg+}&lXmSL$anl@");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_DPI.push_back(5531036661012595088);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.push_back(2544994095);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_y.push_back(false);
		}
		sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82 = 0;
		sbt_VjKHnZbMR = 6930739056436750448;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.push_back(2973807777849606722);
		}
		sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu = 3289596777;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_LeZoYnWlPD9T3MyZvtAF6 *pObject = dynamic_cast<const sbt_LeZoYnWlPD9T3MyZvtAF6 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Yvk.size() != pObject->sbt_Yvk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Yvk.size(); i++)
		{
			if (sbt_Yvk[i] != pObject->sbt_Yvk[i])
			{
				return false;
			}
		}
		if (sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.size() != pObject->sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.size(); i++)
		{
			if (sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw[i] != pObject->sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw[i])
			{
				return false;
			}
		}
		if (sbt_VHft_dofuGHqUXsjj != pObject->sbt_VHft_dofuGHqUXsjj)
		{
			return false;
		}
		if (sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.size() != pObject->sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.size(); i++)
		{
			if (sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5[i] != pObject->sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_zCOrk_x.c_str(), pObject->sbt_zCOrk_x.c_str()))
		{
			return false;
		}
		if (sbt_oKN0YZvPOoUmQNtPsLfWxLT.size() != pObject->sbt_oKN0YZvPOoUmQNtPsLfWxLT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oKN0YZvPOoUmQNtPsLfWxLT.size(); i++)
		{
			if (0 != cx_strcmp(sbt_oKN0YZvPOoUmQNtPsLfWxLT[i].c_str(), pObject->sbt_oKN0YZvPOoUmQNtPsLfWxLT[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_0NFfifRQIThTd != pObject->sbt_0NFfifRQIThTd)
		{
			return false;
		}
		if (sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh != pObject->sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh)
		{
			return false;
		}
		if (sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.size() != pObject->sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.size(); i++)
		{
			if (sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS[i] != pObject->sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS[i])
			{
				return false;
			}
		}
		if (sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y != pObject->sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_enYnJHxn8g2UOD0.c_str(), pObject->sbt_enYnJHxn8g2UOD0.c_str()))
		{
			return false;
		}
		if (sbt_dYKRNkzSxgUm6dBZbbb6IShg3 != pObject->sbt_dYKRNkzSxgUm6dBZbbb6IShg3)
		{
			return false;
		}
		if (sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq != pObject->sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq)
		{
			return false;
		}
		if (sbt_u0eTBolohF7c6vUgCaP.size() != pObject->sbt_u0eTBolohF7c6vUgCaP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u0eTBolohF7c6vUgCaP.size(); i++)
		{
			if (sbt_u0eTBolohF7c6vUgCaP[i] != pObject->sbt_u0eTBolohF7c6vUgCaP[i])
			{
				return false;
			}
		}
		if (sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.size() != pObject->sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.size(); i++)
		{
			if (sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh[i] != pObject->sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh[i])
			{
				return false;
			}
		}
		if (sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.size() != pObject->sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.size(); i++)
		{
			if (sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM[i] != pObject->sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM[i])
			{
				return false;
			}
		}
		if (sbt_bkTmpns3M.size() != pObject->sbt_bkTmpns3M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bkTmpns3M.size(); i++)
		{
			if (sbt_bkTmpns3M[i] != pObject->sbt_bkTmpns3M[i])
			{
				return false;
			}
		}
		if (sbt_Xg2GfVCYKWF3h != pObject->sbt_Xg2GfVCYKWF3h)
		{
			return false;
		}
		if (sbt_nfJuhf6qD8hQXRJ1K != pObject->sbt_nfJuhf6qD8hQXRJ1K)
		{
			return false;
		}
		if (sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.size() != pObject->sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.size(); i++)
		{
			if (sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q[i] != pObject->sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q[i])
			{
				return false;
			}
		}
		if (sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.size() != pObject->sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.size(); i++)
		{
			if (0 != cx_strcmp(sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw[i].c_str(), pObject->sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_DPI.size() != pObject->sbt_DPI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DPI.size(); i++)
		{
			if (sbt_DPI[i] != pObject->sbt_DPI[i])
			{
				return false;
			}
		}
		if (sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.size() != pObject->sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.size(); i++)
		{
			if (sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA[i] != pObject->sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA[i])
			{
				return false;
			}
		}
		if (sbt_y.size() != pObject->sbt_y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y.size(); i++)
		{
			if (sbt_y[i] != pObject->sbt_y[i])
			{
				return false;
			}
		}
		if (sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82 != pObject->sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82)
		{
			return false;
		}
		if (sbt_VjKHnZbMR != pObject->sbt_VjKHnZbMR)
		{
			return false;
		}
		if (sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.size() != pObject->sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.size(); i++)
		{
			if (sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi[i] != pObject->sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi[i])
			{
				return false;
			}
		}
		if (sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu != pObject->sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Yvk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Yvk.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_VHft_dofuGHqUXsjj", &sbt_VHft_dofuGHqUXsjj)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_zCOrk_x", &sbt_zCOrk_x)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oKN0YZvPOoUmQNtPsLfWxLT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oKN0YZvPOoUmQNtPsLfWxLT.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0NFfifRQIThTd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0NFfifRQIThTd = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_enYnJHxn8g2UOD0", &sbt_enYnJHxn8g2UOD0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dYKRNkzSxgUm6dBZbbb6IShg3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dYKRNkzSxgUm6dBZbbb6IShg3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_u0eTBolohF7c6vUgCaP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u0eTBolohF7c6vUgCaP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bkTmpns3M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bkTmpns3M.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Xg2GfVCYKWF3h", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Xg2GfVCYKWF3h = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nfJuhf6qD8hQXRJ1K", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nfJuhf6qD8hQXRJ1K = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DPI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DPI.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VjKHnZbMR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VjKHnZbMR = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Yvk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Yvk.begin(); iter != sbt_Yvk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.begin(); iter != sbt_AmBP97q3Wpcm7sLVFfXK6s9q__4fXLHIZDEI9IfPJAGyMK1TRKrkZcw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_VHft_dofuGHqUXsjj", sbt_VHft_dofuGHqUXsjj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.begin(); iter != sbt_PhLrBiglQz7LAap0jC_oFmEY_L3rLggB76zULGDU5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_zCOrk_x", sbt_zCOrk_x.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oKN0YZvPOoUmQNtPsLfWxLT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_oKN0YZvPOoUmQNtPsLfWxLT.begin(); iter != sbt_oKN0YZvPOoUmQNtPsLfWxLT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0NFfifRQIThTd", (CX::Int64)sbt_0NFfifRQIThTd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh", (CX::Int64)sbt_IOylOl6bmYl_hGbLJ1qIVuQqFMVDe5lqEi1JZRwARFprQGXolmh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.begin(); iter != sbt_OGW2tOpObw7mnPUTwyx_7RsotEuOULS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y", (CX::Int64)sbt_a4bkXMWIpXBCmU00tyMRgYddlec7cHXbxUpak8y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_enYnJHxn8g2UOD0", sbt_enYnJHxn8g2UOD0.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dYKRNkzSxgUm6dBZbbb6IShg3", (CX::Int64)sbt_dYKRNkzSxgUm6dBZbbb6IShg3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq", (CX::Int64)sbt_VPermTibm1g13l5o4xeSnRE031r5hyJWWjvbllT33CczsKAAOeq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u0eTBolohF7c6vUgCaP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_u0eTBolohF7c6vUgCaP.begin(); iter != sbt_u0eTBolohF7c6vUgCaP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.begin(); iter != sbt_2AOaaGLnHRuLdmLLLpqKeaPhO5EgnmIdqj2aMRh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.begin(); iter != sbt_ESu1aNXV_TjGdR2FMSrITwF69YvOMDAxvkHdxMyLnvM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bkTmpns3M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_bkTmpns3M.begin(); iter != sbt_bkTmpns3M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Xg2GfVCYKWF3h", (CX::Int64)sbt_Xg2GfVCYKWF3h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nfJuhf6qD8hQXRJ1K", (CX::Int64)sbt_nfJuhf6qD8hQXRJ1K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.begin(); iter != sbt_XuCez7iQGMHByjV4Vs2OA5ajdkmClvJ9Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.begin(); iter != sbt_USLnnCw0ygPfiUJ6GrtlkNqfZlw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DPI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_DPI.begin(); iter != sbt_DPI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.begin(); iter != sbt_Oh0bQ4kABJgwAxglJuBkfrh6i0HyfYfPelkaAwOFzEZ21mFdkKA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_y.begin(); iter != sbt_y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82", (CX::Int64)sbt_yazofZJO1bm0rBr9mGVLciKbWcoWx82)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VjKHnZbMR", (CX::Int64)sbt_VjKHnZbMR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.begin(); iter != sbt_vYILrPrY2rl7z5JPDP5TvPgguTXmat1I7px10ZWbwkZ5yHJJi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu", (CX::Int64)sbt_Zwi70cGdum23rqCNgD8RpYUGmIJT_nQSkjMuOp4Z7e_iu)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_LeZoYnWlPD9T3MyZvtAF6>::Type sbt_LeZoYnWlPD9T3MyZvtAF6Array;

