
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o.hpp"


class sbt_a0uNasF2Sm0nnVey5DvZq : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_Nw0H14xvUOeKx;
	CX::Int32 sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb;
	CX::UInt8 sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q;
	CX::UInt16 sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa;
	CX::IO::SimpleBuffers::WStringArray sbt_YTECw9H4Xc0vqn_Pig4dqTVTm;
	CX::UInt32 sbt_8oSFTPa55NSIoxFy_u7UjmfN_;
	CX::Int8 sbt_QYA;
	CX::IO::SimpleBuffers::StringArray sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg;
	CX::IO::SimpleBuffers::StringArray sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ;
	CX::IO::SimpleBuffers::StringArray sbt_FkWUh58jgexfwEe_DspRxXi;
	CX::IO::SimpleBuffers::Int64Array sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v;
	CX::IO::SimpleBuffers::WStringArray sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp;
	CX::Bool sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR;
	CX::String sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo;
	CX::Int16 sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3;
	CX::Int16 sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz;
	CX::IO::SimpleBuffers::DoubleArray sbt_Q3ndKrpzWh8qlxo9h8C;
	CX::IO::SimpleBuffers::UInt8Array sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3;
	CX::IO::SimpleBuffers::UInt32Array sbt_AsxTxAsxYkINslZt_TAXnsH;
	CX::String sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z;
	sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz;

	virtual void Reset()
	{
		sbt_Nw0H14xvUOeKx.clear();
		sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb = 0;
		sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q = 0;
		sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa = 0;
		sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.clear();
		sbt_8oSFTPa55NSIoxFy_u7UjmfN_ = 0;
		sbt_QYA = 0;
		sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.clear();
		sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.clear();
		sbt_FkWUh58jgexfwEe_DspRxXi.clear();
		sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.clear();
		sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.clear();
		sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR = false;
		sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo.clear();
		sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3 = 0;
		sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz = 0;
		sbt_Q3ndKrpzWh8qlxo9h8C.clear();
		sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.clear();
		sbt_AsxTxAsxYkINslZt_TAXnsH.clear();
		sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z.clear();
		sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Nw0H14xvUOeKx.push_back(3766111413);
		}
		sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb = -201111687;
		sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q = 128;
		sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa = 50301;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.push_back(L"wHufIU~>\\9KZevSY~`-fsC\"s[[62!n;P([P\"!CT6ol+4I^?N>4?S|+1GB)B)");
		}
		sbt_8oSFTPa55NSIoxFy_u7UjmfN_ = 365303070;
		sbt_QYA = 2;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.push_back("_<w|T\"eA@Q42>wa})X{)X>7G!k%}JE1XP\\KE%`'bGzV(D2Q/cC<_+W-H7Lp%");
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_FkWUh58jgexfwEe_DspRxXi.push_back("L-MaxJ<})3=rIZ-`IR09M'K1IzdA1(?\\.ku4z5z_6&,msT5CznBG20g@i6b");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.push_back(3670228880437429492);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.push_back(L"}yPcK`r_CW(%2");
		}
		sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR = true;
		sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo = ".(!3nK,v8%_9NG9O";
		sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3 = 29499;
		sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz = -16296;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Q3ndKrpzWh8qlxo9h8C.push_back(0.648738);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.push_back(40);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_AsxTxAsxYkINslZt_TAXnsH.push_back(2469488775);
		}
		sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z = "bhyK_eyX]+FpQK$`6qIj";
		sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_a0uNasF2Sm0nnVey5DvZq *pObject = dynamic_cast<const sbt_a0uNasF2Sm0nnVey5DvZq *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Nw0H14xvUOeKx.size() != pObject->sbt_Nw0H14xvUOeKx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Nw0H14xvUOeKx.size(); i++)
		{
			if (sbt_Nw0H14xvUOeKx[i] != pObject->sbt_Nw0H14xvUOeKx[i])
			{
				return false;
			}
		}
		if (sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb != pObject->sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb)
		{
			return false;
		}
		if (sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q != pObject->sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q)
		{
			return false;
		}
		if (sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa != pObject->sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa)
		{
			return false;
		}
		if (sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.size() != pObject->sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_YTECw9H4Xc0vqn_Pig4dqTVTm[i].c_str(), pObject->sbt_YTECw9H4Xc0vqn_Pig4dqTVTm[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_8oSFTPa55NSIoxFy_u7UjmfN_ != pObject->sbt_8oSFTPa55NSIoxFy_u7UjmfN_)
		{
			return false;
		}
		if (sbt_QYA != pObject->sbt_QYA)
		{
			return false;
		}
		if (sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.size() != pObject->sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.size(); i++)
		{
			if (0 != cx_strcmp(sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg[i].c_str(), pObject->sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.size() != pObject->sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ[i].c_str(), pObject->sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_FkWUh58jgexfwEe_DspRxXi.size() != pObject->sbt_FkWUh58jgexfwEe_DspRxXi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FkWUh58jgexfwEe_DspRxXi.size(); i++)
		{
			if (0 != cx_strcmp(sbt_FkWUh58jgexfwEe_DspRxXi[i].c_str(), pObject->sbt_FkWUh58jgexfwEe_DspRxXi[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.size() != pObject->sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.size(); i++)
		{
			if (sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v[i] != pObject->sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v[i])
			{
				return false;
			}
		}
		if (sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.size() != pObject->sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp[i].c_str(), pObject->sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR != pObject->sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo.c_str(), pObject->sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo.c_str()))
		{
			return false;
		}
		if (sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3 != pObject->sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3)
		{
			return false;
		}
		if (sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz != pObject->sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz)
		{
			return false;
		}
		if (sbt_Q3ndKrpzWh8qlxo9h8C.size() != pObject->sbt_Q3ndKrpzWh8qlxo9h8C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q3ndKrpzWh8qlxo9h8C.size(); i++)
		{
			if (sbt_Q3ndKrpzWh8qlxo9h8C[i] != pObject->sbt_Q3ndKrpzWh8qlxo9h8C[i])
			{
				return false;
			}
		}
		if (sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.size() != pObject->sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.size(); i++)
		{
			if (sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3[i] != pObject->sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3[i])
			{
				return false;
			}
		}
		if (sbt_AsxTxAsxYkINslZt_TAXnsH.size() != pObject->sbt_AsxTxAsxYkINslZt_TAXnsH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AsxTxAsxYkINslZt_TAXnsH.size(); i++)
		{
			if (sbt_AsxTxAsxYkINslZt_TAXnsH[i] != pObject->sbt_AsxTxAsxYkINslZt_TAXnsH[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z.c_str(), pObject->sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z.c_str()))
		{
			return false;
		}
		if (!sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz.Compare(&pObject->sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Nw0H14xvUOeKx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Nw0H14xvUOeKx.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YTECw9H4Xc0vqn_Pig4dqTVTm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8oSFTPa55NSIoxFy_u7UjmfN_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8oSFTPa55NSIoxFy_u7UjmfN_ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QYA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QYA = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FkWUh58jgexfwEe_DspRxXi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FkWUh58jgexfwEe_DspRxXi.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR", &sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo", &sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Q3ndKrpzWh8qlxo9h8C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q3ndKrpzWh8qlxo9h8C.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AsxTxAsxYkINslZt_TAXnsH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AsxTxAsxYkINslZt_TAXnsH.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z", &sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Nw0H14xvUOeKx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Nw0H14xvUOeKx.begin(); iter != sbt_Nw0H14xvUOeKx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb", (CX::Int64)sbt_SlIjTWA8qLSuV2_pS5fAoikCOCb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q", (CX::Int64)sbt_zwfGaUuQH30MZs5zs7CcvYPKRcS2GcFz6E83EFfWNzQP8jo5Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa", (CX::Int64)sbt_8WbpGgTnuGtKQE47zo_ZAGxNSjptw5CriyjDaH_0EHTdvTSNk5ACs_8UtuBQa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YTECw9H4Xc0vqn_Pig4dqTVTm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.begin(); iter != sbt_YTECw9H4Xc0vqn_Pig4dqTVTm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8oSFTPa55NSIoxFy_u7UjmfN_", (CX::Int64)sbt_8oSFTPa55NSIoxFy_u7UjmfN_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QYA", (CX::Int64)sbt_QYA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.begin(); iter != sbt_cCEDj6nGkxPm8iYzCSo6tvpM0e33b0K1J1UIaEryjV4aJ4mVTWjcYi1Vg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.begin(); iter != sbt_qOx6v1nsxlsURpWuAPN1NyLpnXvrSFAxo8VOgYJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FkWUh58jgexfwEe_DspRxXi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_FkWUh58jgexfwEe_DspRxXi.begin(); iter != sbt_FkWUh58jgexfwEe_DspRxXi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.begin(); iter != sbt_anpwjg7xPSZ2C64OcJ7UJBgX_WFgjHv5x8DrVpc2v.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.begin(); iter != sbt_57YPeGv2SYfqP1m2r5AKG48YBPSI3UgJ5aiDEpYvdWHtp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR", sbt_9yZnDe3_eLZ0HxwQKfxGGVEgxvsbR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo", sbt_vtdq7KyJkroQUfM4_1prmaLg2MkWHBNvqRj_UlGUv4SwJKASQoTFBtlETgo.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3", (CX::Int64)sbt_gni95hJTEILHz_VPlouvy5SPa48wYQaxIEUEFuhPx09KXYPA1rcu3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz", (CX::Int64)sbt_Q_Bz5HeCiS8chxSxgdTyuHwBf0iqtVBQnapPh7ri4jz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q3ndKrpzWh8qlxo9h8C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Q3ndKrpzWh8qlxo9h8C.begin(); iter != sbt_Q3ndKrpzWh8qlxo9h8C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.begin(); iter != sbt_ONmVELXSmPTMuTIw4RhnxpHQeB7s_1nCl25gpiMP3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AsxTxAsxYkINslZt_TAXnsH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_AsxTxAsxYkINslZt_TAXnsH.begin(); iter != sbt_AsxTxAsxYkINslZt_TAXnsH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z", sbt_9nkYOFLpbD_1r_KgWZFN_Cl1dTOtZ9Z.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_t9Cto7JqCJbMrzNujzgQioQHw8v2vfB_BsJ5XOJJr5tIK206SbOkNMOb0nz.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_a0uNasF2Sm0nnVey5DvZq>::Type sbt_a0uNasF2Sm0nnVey5DvZqArray;

