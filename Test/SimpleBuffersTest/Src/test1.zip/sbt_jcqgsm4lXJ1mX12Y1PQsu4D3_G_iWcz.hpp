
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW.hpp"


class sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_Yslod4q;
	CX::IO::SimpleBuffers::StringArray sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz;
	CX::Int32 sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB;
	CX::UInt16 sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF;
	CX::UInt64 sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN;
	CX::WString sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS;
	CX::IO::SimpleBuffers::Int16Array sbt_AFg6Vme;
	CX::String sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7;
	CX::UInt64 sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26;
	CX::IO::SimpleBuffers::Int64Array sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen;
	sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrWArray sbt_jqZ09cWBmEG4CzrLt;

	virtual void Reset()
	{
		sbt_Yslod4q.clear();
		sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.clear();
		sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB = 0;
		sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF = 0;
		sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN = 0;
		sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS.clear();
		sbt_AFg6Vme.clear();
		sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7.clear();
		sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26 = 0;
		sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.clear();
		sbt_jqZ09cWBmEG4CzrLt.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Yslod4q = L"a=0B>6JFryQn>Ef";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.push_back("P\"f2mfmno7ZF`h4DDc!U.(");
		}
		sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB = -1683964672;
		sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF = 10564;
		sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN = 16523682125735345060;
		sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS = L"|^J=RM8@6FN5P~Q4[u(RVkRiel)pO7>+RI)F'E+^@V<Yxi!c\"]\\D4Fr'";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_AFg6Vme.push_back(-1936);
		}
		sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7 = "R,\"]D/0y(v0R4Sc~ZPq)}L;d>lVO:IgUsA.1MUV{r},";
		sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26 = 10197537672144862546;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.push_back(-896604629976255108);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW v;

			v.SetupWithSomeValues();
			sbt_jqZ09cWBmEG4CzrLt.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz *pObject = dynamic_cast<const sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_Yslod4q.c_str(), pObject->sbt_Yslod4q.c_str()))
		{
			return false;
		}
		if (sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.size() != pObject->sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.size(); i++)
		{
			if (0 != cx_strcmp(sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz[i].c_str(), pObject->sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB != pObject->sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB)
		{
			return false;
		}
		if (sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF != pObject->sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF)
		{
			return false;
		}
		if (sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN != pObject->sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS.c_str(), pObject->sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS.c_str()))
		{
			return false;
		}
		if (sbt_AFg6Vme.size() != pObject->sbt_AFg6Vme.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AFg6Vme.size(); i++)
		{
			if (sbt_AFg6Vme[i] != pObject->sbt_AFg6Vme[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7.c_str(), pObject->sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7.c_str()))
		{
			return false;
		}
		if (sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26 != pObject->sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26)
		{
			return false;
		}
		if (sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.size() != pObject->sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.size(); i++)
		{
			if (sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen[i] != pObject->sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen[i])
			{
				return false;
			}
		}
		if (sbt_jqZ09cWBmEG4CzrLt.size() != pObject->sbt_jqZ09cWBmEG4CzrLt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jqZ09cWBmEG4CzrLt.size(); i++)
		{
			if (!sbt_jqZ09cWBmEG4CzrLt[i].Compare(&pObject->sbt_jqZ09cWBmEG4CzrLt[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_Yslod4q", &sbt_Yslod4q)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS", &sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AFg6Vme")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AFg6Vme.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7", &sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jqZ09cWBmEG4CzrLt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_jqZ09cWBmEG4CzrLt.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_Yslod4q", sbt_Yslod4q.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.begin(); iter != sbt_y22jMBQEhRZmmDFzkNAsECP6zx5baRv2XKt4IYNfQVK1fnPPLJioFzz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB", (CX::Int64)sbt_T_v8iyBHtXK5_2GmQZBjq44BqPE_CNtD1njyjmgAN3xiHsRV9LfXjaRx1lhJ2xB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF", (CX::Int64)sbt_b5Qm3drYwLh8Pgbpy4b7EvjfF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN", (CX::Int64)sbt_VJ9Sul33BYMqQZepTK2X27nzl1ldBH4AlOHsN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS", sbt_c8mt2fw6W_Q1gjwlLKVGfbQFEms8QQS.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AFg6Vme")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_AFg6Vme.begin(); iter != sbt_AFg6Vme.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7", sbt_rg8K1xYu4sRbsIKwdjj5nWEcMlCs2_ZuBauGKFFcKaGYqLFrzgR9GgZWMk5H7.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26", (CX::Int64)sbt_3adLaTjF99fkbx3qp8EwAkqFRONFgR5UKDcZ7jy26)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.begin(); iter != sbt_yB8GC3LfIi3qDigqTr7X9nu47nuIrMHI1WZ0ZTYE_3fylhJmlen.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jqZ09cWBmEG4CzrLt")).IsNOK())
		{
			return status;
		}
		for (sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrWArray::const_iterator iter = sbt_jqZ09cWBmEG4CzrLt.begin(); iter != sbt_jqZ09cWBmEG4CzrLt.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz>::Type sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWczArray;

