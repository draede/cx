
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_6mSKrq1ZBtodU8N.hpp"


class sbt_9BLgCl9IRtR : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_6mSKrq1ZBtodU8N sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh;

	virtual void Reset()
	{
		sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_9BLgCl9IRtR *pObject = dynamic_cast<const sbt_9BLgCl9IRtR *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (!sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh.Compare(&pObject->sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectObject("sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectObject("sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Q_k0rLnq1ok0VxrsUvqwMl6hdkOf25KQh.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_9BLgCl9IRtR>::Type sbt_9BLgCl9IRtRArray;

