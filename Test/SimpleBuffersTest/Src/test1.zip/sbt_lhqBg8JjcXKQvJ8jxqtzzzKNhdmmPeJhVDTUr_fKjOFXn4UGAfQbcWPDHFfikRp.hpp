
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r.hpp"


class sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc;
	CX::IO::SimpleBuffers::WStringArray sbt_EoAOHKCuarq6EbQrfYqCj;
	CX::IO::SimpleBuffers::Int8Array sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP;
	CX::IO::SimpleBuffers::UInt16Array sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv;
	CX::IO::SimpleBuffers::UInt8Array sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_;
	CX::UInt8 sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW;
	CX::UInt8 sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK;
	sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX;

	virtual void Reset()
	{
		sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc = 0.0;
		sbt_EoAOHKCuarq6EbQrfYqCj.clear();
		sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.clear();
		sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.clear();
		sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.clear();
		sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW = 0;
		sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK = 0;
		sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc = 0.448702;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_EoAOHKCuarq6EbQrfYqCj.push_back(L"\\_l@8>OwU%t/2??|O");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.push_back(29);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.push_back(22543);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.push_back(112);
		}
		sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW = 102;
		sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK = 30;
		sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp *pObject = dynamic_cast<const sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc != pObject->sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc)
		{
			return false;
		}
		if (sbt_EoAOHKCuarq6EbQrfYqCj.size() != pObject->sbt_EoAOHKCuarq6EbQrfYqCj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EoAOHKCuarq6EbQrfYqCj.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_EoAOHKCuarq6EbQrfYqCj[i].c_str(), pObject->sbt_EoAOHKCuarq6EbQrfYqCj[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.size() != pObject->sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.size(); i++)
		{
			if (sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP[i] != pObject->sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP[i])
			{
				return false;
			}
		}
		if (sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.size() != pObject->sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.size(); i++)
		{
			if (sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv[i] != pObject->sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv[i])
			{
				return false;
			}
		}
		if (sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.size() != pObject->sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.size(); i++)
		{
			if (sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_[i] != pObject->sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_[i])
			{
				return false;
			}
		}
		if (sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW != pObject->sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW)
		{
			return false;
		}
		if (sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK != pObject->sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK)
		{
			return false;
		}
		if (!sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX.Compare(&pObject->sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_EoAOHKCuarq6EbQrfYqCj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EoAOHKCuarq6EbQrfYqCj.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc", (CX::Double)sbt_F_cnbL3oCp5haJ5lU1w3kLPdkNw5nbc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EoAOHKCuarq6EbQrfYqCj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_EoAOHKCuarq6EbQrfYqCj.begin(); iter != sbt_EoAOHKCuarq6EbQrfYqCj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.begin(); iter != sbt_z_F7SJlA4pk0NLJzBwYk0uUOvDF3k5yqBFJzyHMv4eaojpZz12A4Ijs5gpP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.begin(); iter != sbt_7U02s0U7wo6WjXcq6lhjay909MJqeEMJBVtbqa_I1GL2Ua6zRr8Fv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.begin(); iter != sbt_W_MfMV28D6kZrzXtwg1ERVjLHtkVjA_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW", (CX::Int64)sbt_FqVQagv_yLYShEcRsHdFe6FCWq75FJeNW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK", (CX::Int64)sbt_0HjKOd9PQNK6P632djERoZnmA5ZxKBMG1e85X5PqUpAV4Vheby8CNZ10j2FQKXK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_mNWfLfRv1NCUDq0NMmOWbo7MgJ5D7V4iXcQRSM2BzrE7e8QJX.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp>::Type sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRpArray;

