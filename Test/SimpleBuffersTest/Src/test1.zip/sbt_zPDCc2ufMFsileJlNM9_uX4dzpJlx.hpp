
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_rHak30F5CXp.hpp"


class sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54;
	CX::IO::SimpleBuffers::UInt64Array sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB;
	CX::Int32 sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu;
	CX::IO::SimpleBuffers::StringArray sbt_eJ52N5TCOXDa7P9_CW2mDOd;
	CX::UInt16 sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p;
	CX::Int32 sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47;
	CX::IO::SimpleBuffers::BoolArray sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1;
	CX::IO::SimpleBuffers::UInt16Array sbt_ynEkIYd;
	CX::Int32 sbt_1Ya8mNNrPUml7V6PNEndqq5;
	CX::IO::SimpleBuffers::DoubleArray sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp;
	CX::IO::SimpleBuffers::Int8Array sbt_CGpVeJ7LdTvdQXENntSCwIS7n;
	CX::IO::SimpleBuffers::DoubleArray sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq;
	CX::Int64 sbt_5;
	CX::IO::SimpleBuffers::Int16Array sbt_cTDcZqOF4w4MsOQtx;
	CX::IO::SimpleBuffers::UInt8Array sbt_H;
	CX::IO::SimpleBuffers::Int32Array sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0;
	CX::IO::SimpleBuffers::BoolArray sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM;
	CX::Bool sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1;
	CX::Int64 sbt_o8En2mSXndTQFswnosd7PETruVE;
	CX::Double sbt__ajKeTWYnbLXLamylKfLJo6hdWm;
	CX::IO::SimpleBuffers::FloatArray sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro;
	CX::IO::SimpleBuffers::StringArray sbt_c8npTEDufzE4I;
	CX::IO::SimpleBuffers::FloatArray sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5;
	CX::Bool sbt_OXVYdkA8i_uTD6xVZm2DV;
	CX::UInt8 sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D;
	sbt_rHak30F5CXp sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_;

	virtual void Reset()
	{
		sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54 = 0.0;
		sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.clear();
		sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu = 0;
		sbt_eJ52N5TCOXDa7P9_CW2mDOd.clear();
		sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p = 0;
		sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47 = 0;
		sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.clear();
		sbt_ynEkIYd.clear();
		sbt_1Ya8mNNrPUml7V6PNEndqq5 = 0;
		sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.clear();
		sbt_CGpVeJ7LdTvdQXENntSCwIS7n.clear();
		sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.clear();
		sbt_5 = 0;
		sbt_cTDcZqOF4w4MsOQtx.clear();
		sbt_H.clear();
		sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.clear();
		sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.clear();
		sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1 = false;
		sbt_o8En2mSXndTQFswnosd7PETruVE = 0;
		sbt__ajKeTWYnbLXLamylKfLJo6hdWm = 0.0;
		sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.clear();
		sbt_c8npTEDufzE4I.clear();
		sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.clear();
		sbt_OXVYdkA8i_uTD6xVZm2DV = false;
		sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D = 0;
		sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54 = 0.578585;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.push_back(9963592785665130024);
		}
		sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu = -90410850;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_eJ52N5TCOXDa7P9_CW2mDOd.push_back("p?s\"tb*Qqz5\\z\"{=(fk\\1RNBXx>'rZ9");
		}
		sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p = 41093;
		sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47 = 1129180524;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.push_back(false);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_ynEkIYd.push_back(29110);
		}
		sbt_1Ya8mNNrPUml7V6PNEndqq5 = 1129724290;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.push_back(0.389969);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_CGpVeJ7LdTvdQXENntSCwIS7n.push_back(-73);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.push_back(0.028501);
		}
		sbt_5 = -8418051849054814738;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_cTDcZqOF4w4MsOQtx.push_back(-11051);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_H.push_back(94);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.push_back(1524485570);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.push_back(false);
		}
		sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1 = true;
		sbt_o8En2mSXndTQFswnosd7PETruVE = 2286911205845623604;
		sbt__ajKeTWYnbLXLamylKfLJo6hdWm = 0.210972;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.push_back(0.059115f);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_c8npTEDufzE4I.push_back("k|Eg0xLM?B1&@se-2m");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.push_back(0.860811f);
		}
		sbt_OXVYdkA8i_uTD6xVZm2DV = true;
		sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D = 105;
		sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx *pObject = dynamic_cast<const sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54 != pObject->sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54)
		{
			return false;
		}
		if (sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.size() != pObject->sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.size(); i++)
		{
			if (sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB[i] != pObject->sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB[i])
			{
				return false;
			}
		}
		if (sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu != pObject->sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu)
		{
			return false;
		}
		if (sbt_eJ52N5TCOXDa7P9_CW2mDOd.size() != pObject->sbt_eJ52N5TCOXDa7P9_CW2mDOd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eJ52N5TCOXDa7P9_CW2mDOd.size(); i++)
		{
			if (0 != cx_strcmp(sbt_eJ52N5TCOXDa7P9_CW2mDOd[i].c_str(), pObject->sbt_eJ52N5TCOXDa7P9_CW2mDOd[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p != pObject->sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p)
		{
			return false;
		}
		if (sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47 != pObject->sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47)
		{
			return false;
		}
		if (sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.size() != pObject->sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.size(); i++)
		{
			if (sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1[i] != pObject->sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1[i])
			{
				return false;
			}
		}
		if (sbt_ynEkIYd.size() != pObject->sbt_ynEkIYd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ynEkIYd.size(); i++)
		{
			if (sbt_ynEkIYd[i] != pObject->sbt_ynEkIYd[i])
			{
				return false;
			}
		}
		if (sbt_1Ya8mNNrPUml7V6PNEndqq5 != pObject->sbt_1Ya8mNNrPUml7V6PNEndqq5)
		{
			return false;
		}
		if (sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.size() != pObject->sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.size(); i++)
		{
			if (sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp[i] != pObject->sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp[i])
			{
				return false;
			}
		}
		if (sbt_CGpVeJ7LdTvdQXENntSCwIS7n.size() != pObject->sbt_CGpVeJ7LdTvdQXENntSCwIS7n.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CGpVeJ7LdTvdQXENntSCwIS7n.size(); i++)
		{
			if (sbt_CGpVeJ7LdTvdQXENntSCwIS7n[i] != pObject->sbt_CGpVeJ7LdTvdQXENntSCwIS7n[i])
			{
				return false;
			}
		}
		if (sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.size() != pObject->sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.size(); i++)
		{
			if (sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq[i] != pObject->sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq[i])
			{
				return false;
			}
		}
		if (sbt_5 != pObject->sbt_5)
		{
			return false;
		}
		if (sbt_cTDcZqOF4w4MsOQtx.size() != pObject->sbt_cTDcZqOF4w4MsOQtx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cTDcZqOF4w4MsOQtx.size(); i++)
		{
			if (sbt_cTDcZqOF4w4MsOQtx[i] != pObject->sbt_cTDcZqOF4w4MsOQtx[i])
			{
				return false;
			}
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.size() != pObject->sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.size(); i++)
		{
			if (sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0[i] != pObject->sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0[i])
			{
				return false;
			}
		}
		if (sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.size() != pObject->sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.size(); i++)
		{
			if (sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM[i] != pObject->sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM[i])
			{
				return false;
			}
		}
		if (sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1 != pObject->sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1)
		{
			return false;
		}
		if (sbt_o8En2mSXndTQFswnosd7PETruVE != pObject->sbt_o8En2mSXndTQFswnosd7PETruVE)
		{
			return false;
		}
		if (sbt__ajKeTWYnbLXLamylKfLJo6hdWm != pObject->sbt__ajKeTWYnbLXLamylKfLJo6hdWm)
		{
			return false;
		}
		if (sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.size() != pObject->sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.size(); i++)
		{
			if (sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro[i] != pObject->sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro[i])
			{
				return false;
			}
		}
		if (sbt_c8npTEDufzE4I.size() != pObject->sbt_c8npTEDufzE4I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c8npTEDufzE4I.size(); i++)
		{
			if (0 != cx_strcmp(sbt_c8npTEDufzE4I[i].c_str(), pObject->sbt_c8npTEDufzE4I[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.size() != pObject->sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.size(); i++)
		{
			if (sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5[i] != pObject->sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5[i])
			{
				return false;
			}
		}
		if (sbt_OXVYdkA8i_uTD6xVZm2DV != pObject->sbt_OXVYdkA8i_uTD6xVZm2DV)
		{
			return false;
		}
		if (sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D != pObject->sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D)
		{
			return false;
		}
		if (!sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_.Compare(&pObject->sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eJ52N5TCOXDa7P9_CW2mDOd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eJ52N5TCOXDa7P9_CW2mDOd.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ynEkIYd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ynEkIYd.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1Ya8mNNrPUml7V6PNEndqq5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1Ya8mNNrPUml7V6PNEndqq5 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CGpVeJ7LdTvdQXENntSCwIS7n")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CGpVeJ7LdTvdQXENntSCwIS7n.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cTDcZqOF4w4MsOQtx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cTDcZqOF4w4MsOQtx.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1", &sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_o8En2mSXndTQFswnosd7PETruVE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_o8En2mSXndTQFswnosd7PETruVE = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt__ajKeTWYnbLXLamylKfLJo6hdWm", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__ajKeTWYnbLXLamylKfLJo6hdWm = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_c8npTEDufzE4I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c8npTEDufzE4I.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_OXVYdkA8i_uTD6xVZm2DV", &sbt_OXVYdkA8i_uTD6xVZm2DV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54", (CX::Double)sbt_J_zZnoOt4MO0r7GfhjC9ZRPLF1umqFJs_nmMJBdsTj5chBjowUhbDRrpfKLzp54)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.begin(); iter != sbt_jWnj0MyaPy2IIitzWUERWPTavjruttJlYvrCWsWGYo6fP0rtPIKUod1d2s1ZB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu", (CX::Int64)sbt_vOP9jWNi_uV49iE89UbKcQugpZ6pcPetu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eJ52N5TCOXDa7P9_CW2mDOd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_eJ52N5TCOXDa7P9_CW2mDOd.begin(); iter != sbt_eJ52N5TCOXDa7P9_CW2mDOd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p", (CX::Int64)sbt_8NBGFyKQzNgeaUiEtyCrYgh0SLwKn6Tuv8i1rBn0mQ5ACqulg0p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47", (CX::Int64)sbt_LsIKoRnXlhKPqNGaXoW5JUMgWE7xoewnzP01sGwBkW1lSiu47)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.begin(); iter != sbt_n0lWzocbvOSUIHNTTn9vpMW7UYfNnHStA5GbMUT8se01Lx1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ynEkIYd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_ynEkIYd.begin(); iter != sbt_ynEkIYd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1Ya8mNNrPUml7V6PNEndqq5", (CX::Int64)sbt_1Ya8mNNrPUml7V6PNEndqq5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.begin(); iter != sbt_vAwj5lhsn9ok7qpYadONKAy3XSNVJCq376SAJ7ALp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CGpVeJ7LdTvdQXENntSCwIS7n")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_CGpVeJ7LdTvdQXENntSCwIS7n.begin(); iter != sbt_CGpVeJ7LdTvdQXENntSCwIS7n.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.begin(); iter != sbt_lhHIvBnxrnwX2DB3KcKxjxq6az7W_dCg0OwrAWdhqLJfsLq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5", (CX::Int64)sbt_5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cTDcZqOF4w4MsOQtx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_cTDcZqOF4w4MsOQtx.begin(); iter != sbt_cTDcZqOF4w4MsOQtx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.begin(); iter != sbt_9t97XIQFortp2Npf2kJs4X5wY1AlWGvrvtf6TMnWQeNDxr9gF64f8c0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.begin(); iter != sbt_Fs5LNbVshpU4ppcBjSanMwbaRX15f5bHgh2GdHmP7qGbmiycLUM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1", sbt_IESwgRczgzOInIq6QqVCxsUHXdyaLeIWF_kvgwGo1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_o8En2mSXndTQFswnosd7PETruVE", (CX::Int64)sbt_o8En2mSXndTQFswnosd7PETruVE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__ajKeTWYnbLXLamylKfLJo6hdWm", (CX::Double)sbt__ajKeTWYnbLXLamylKfLJo6hdWm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.begin(); iter != sbt_a7wXMjO2PhxQhzNvshrNstqlrKpUGffMTP6F3GDflvWYGCswNJxMbOXAdro.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c8npTEDufzE4I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_c8npTEDufzE4I.begin(); iter != sbt_c8npTEDufzE4I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.begin(); iter != sbt_QzR2WcoK_B3EB65MMh3jMrFhdOwzEuL8Xf5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_OXVYdkA8i_uTD6xVZm2DV", sbt_OXVYdkA8i_uTD6xVZm2DV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D", (CX::Int64)sbt_TnfXlRYjpNBNMDExAfG_GaoM0QPUnz33nDQsAcer6_5tNuHS88D)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_IyOnFj6eCie_N25hfcsh7nDacIlOrzz8UW7OcXkVveM3Ir1QbCjxlOSEzBvm0J_.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx>::Type sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlxArray;

