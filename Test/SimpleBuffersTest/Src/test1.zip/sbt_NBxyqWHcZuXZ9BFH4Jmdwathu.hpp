
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_NBxyqWHcZuXZ9BFH4Jmdwathu : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_wHe8rTPaajbAA9jJeBVWE;
	CX::UInt32 sbt_SXswOx85VLBLE0Zi_;
	CX::UInt64 sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk;
	CX::IO::SimpleBuffers::UInt64Array sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ;
	CX::Int64 sbt_DjA75mp;
	CX::UInt64 sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH;
	CX::Int64 sbt_xjh;
	CX::Int8 sbt_fhh4A31adLPKg7qAdjoei;
	CX::IO::SimpleBuffers::Int64Array sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh;
	CX::Int8 sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq;
	CX::Int16 sbt_YeJVt;
	CX::UInt32 sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ;
	CX::IO::SimpleBuffers::Int32Array sbt_bWSfatKGJh6;
	CX::UInt64 sbt_q;
	CX::UInt32 sbt_G;
	CX::IO::SimpleBuffers::UInt32Array sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD;
	CX::Int64 sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7;
	CX::IO::SimpleBuffers::Int32Array sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro;
	CX::Int64 sbt_M_OES;
	CX::IO::SimpleBuffers::Int8Array sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o;
	CX::UInt8 sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP;
	CX::UInt64 sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ;
	CX::IO::SimpleBuffers::UInt16Array sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb;
	CX::UInt16 sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2;
	CX::IO::SimpleBuffers::Int32Array sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK;
	CX::Int32 sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI;

	virtual void Reset()
	{
		sbt_wHe8rTPaajbAA9jJeBVWE = 0;
		sbt_SXswOx85VLBLE0Zi_ = 0;
		sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk = 0;
		sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.clear();
		sbt_DjA75mp = 0;
		sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH = 0;
		sbt_xjh = 0;
		sbt_fhh4A31adLPKg7qAdjoei = 0;
		sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.clear();
		sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq = 0;
		sbt_YeJVt = 0;
		sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ = 0;
		sbt_bWSfatKGJh6.clear();
		sbt_q = 0;
		sbt_G = 0;
		sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.clear();
		sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7 = 0;
		sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.clear();
		sbt_M_OES = 0;
		sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.clear();
		sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP = 0;
		sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ = 0;
		sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.clear();
		sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2 = 0;
		sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.clear();
		sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_wHe8rTPaajbAA9jJeBVWE = 98;
		sbt_SXswOx85VLBLE0Zi_ = 262955317;
		sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk = 1060492997356025748;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.push_back(17454847587254119812);
		}
		sbt_DjA75mp = -8638028617204892166;
		sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH = 1520941199515691350;
		sbt_xjh = 3923539050439879920;
		sbt_fhh4A31adLPKg7qAdjoei = 80;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.push_back(-2461348062363047282);
		}
		sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq = 64;
		sbt_YeJVt = -19096;
		sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ = 3731951185;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_bWSfatKGJh6.push_back(1000733426);
		}
		sbt_q = 14002567787379105082;
		sbt_G = 575440256;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.push_back(1874678429);
		}
		sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7 = 2840833854799859242;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.push_back(-416953753);
		}
		sbt_M_OES = 625587921610264308;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.push_back(75);
		}
		sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP = 220;
		sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ = 17679213500687606458;
		sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2 = 22285;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.push_back(710155345);
		}
		sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI = 396177292;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_NBxyqWHcZuXZ9BFH4Jmdwathu *pObject = dynamic_cast<const sbt_NBxyqWHcZuXZ9BFH4Jmdwathu *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wHe8rTPaajbAA9jJeBVWE != pObject->sbt_wHe8rTPaajbAA9jJeBVWE)
		{
			return false;
		}
		if (sbt_SXswOx85VLBLE0Zi_ != pObject->sbt_SXswOx85VLBLE0Zi_)
		{
			return false;
		}
		if (sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk != pObject->sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk)
		{
			return false;
		}
		if (sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.size() != pObject->sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.size(); i++)
		{
			if (sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ[i] != pObject->sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ[i])
			{
				return false;
			}
		}
		if (sbt_DjA75mp != pObject->sbt_DjA75mp)
		{
			return false;
		}
		if (sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH != pObject->sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH)
		{
			return false;
		}
		if (sbt_xjh != pObject->sbt_xjh)
		{
			return false;
		}
		if (sbt_fhh4A31adLPKg7qAdjoei != pObject->sbt_fhh4A31adLPKg7qAdjoei)
		{
			return false;
		}
		if (sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.size() != pObject->sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.size(); i++)
		{
			if (sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh[i] != pObject->sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh[i])
			{
				return false;
			}
		}
		if (sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq != pObject->sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq)
		{
			return false;
		}
		if (sbt_YeJVt != pObject->sbt_YeJVt)
		{
			return false;
		}
		if (sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ != pObject->sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ)
		{
			return false;
		}
		if (sbt_bWSfatKGJh6.size() != pObject->sbt_bWSfatKGJh6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bWSfatKGJh6.size(); i++)
		{
			if (sbt_bWSfatKGJh6[i] != pObject->sbt_bWSfatKGJh6[i])
			{
				return false;
			}
		}
		if (sbt_q != pObject->sbt_q)
		{
			return false;
		}
		if (sbt_G != pObject->sbt_G)
		{
			return false;
		}
		if (sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.size() != pObject->sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.size(); i++)
		{
			if (sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD[i] != pObject->sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD[i])
			{
				return false;
			}
		}
		if (sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7 != pObject->sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7)
		{
			return false;
		}
		if (sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.size() != pObject->sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.size(); i++)
		{
			if (sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro[i] != pObject->sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro[i])
			{
				return false;
			}
		}
		if (sbt_M_OES != pObject->sbt_M_OES)
		{
			return false;
		}
		if (sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.size() != pObject->sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.size(); i++)
		{
			if (sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o[i] != pObject->sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o[i])
			{
				return false;
			}
		}
		if (sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP != pObject->sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP)
		{
			return false;
		}
		if (sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ != pObject->sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ)
		{
			return false;
		}
		if (sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.size() != pObject->sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.size(); i++)
		{
			if (sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb[i] != pObject->sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb[i])
			{
				return false;
			}
		}
		if (sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2 != pObject->sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2)
		{
			return false;
		}
		if (sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.size() != pObject->sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.size(); i++)
		{
			if (sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK[i] != pObject->sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK[i])
			{
				return false;
			}
		}
		if (sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI != pObject->sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_wHe8rTPaajbAA9jJeBVWE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wHe8rTPaajbAA9jJeBVWE = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SXswOx85VLBLE0Zi_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SXswOx85VLBLE0Zi_ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DjA75mp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DjA75mp = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_xjh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xjh = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fhh4A31adLPKg7qAdjoei", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fhh4A31adLPKg7qAdjoei = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YeJVt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YeJVt = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bWSfatKGJh6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bWSfatKGJh6.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_q = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_M_OES", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M_OES = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_wHe8rTPaajbAA9jJeBVWE", (CX::Int64)sbt_wHe8rTPaajbAA9jJeBVWE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SXswOx85VLBLE0Zi_", (CX::Int64)sbt_SXswOx85VLBLE0Zi_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk", (CX::Int64)sbt_kAFGP52UbtxJRwCXXuKMdKhwEvZPgy25O1Nbs1RB5XpIlEk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.begin(); iter != sbt_a4DLySFrQB3e7SQvDdXf7UBiMhQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DjA75mp", (CX::Int64)sbt_DjA75mp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH", (CX::Int64)sbt_SHXkZRRXZd55Zo8VJBg48z14e2OVWycrFHHf2S0695ZnUuSevJmNLgH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xjh", (CX::Int64)sbt_xjh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fhh4A31adLPKg7qAdjoei", (CX::Int64)sbt_fhh4A31adLPKg7qAdjoei)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.begin(); iter != sbt_CuKUfNmfqWTjYJk8glDW0UCyRVG1Ttt8tdnkuBsfh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq", (CX::Int64)sbt_dH5KqBnX2v6lJVkInayEap4tzRo4oGqVWRHIMocuZJetrHNHClyvpVkEq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YeJVt", (CX::Int64)sbt_YeJVt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ", (CX::Int64)sbt_Ouei2pKHig6jTgYl4W5cCrlnJh51qprVrwwfH22N7Y_vACPyJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bWSfatKGJh6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_bWSfatKGJh6.begin(); iter != sbt_bWSfatKGJh6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_q", (CX::Int64)sbt_q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G", (CX::Int64)sbt_G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.begin(); iter != sbt_KhN7IWnqvKIeDScG6hpLeU79shX_qrD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7", (CX::Int64)sbt_bbVDsch05jjaVvjIkb6He2Ue8NCS6M1rH2q6Od3K648EcHQFKLTEUdZQam7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.begin(); iter != sbt_ynBOT4n5aDbQ5N9MVnFDyd_ro.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M_OES", (CX::Int64)sbt_M_OES)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.begin(); iter != sbt_wtyEUZvApRnXcTx1vbrrBrjndaJuKnyxmNTN_51iCVbrXsv9o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP", (CX::Int64)sbt_P0VF0Q9Ixs0Zq8PSVFQzn8x93MSt0OlueRCUEVAZ7yDrySIzVUBQP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ", (CX::Int64)sbt_iqt8ijSoh_CroMKLTUDqUyB4Sb9PQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.begin(); iter != sbt_Fc5nGY0N9k_sBbNcJ7Gh3Eb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2", (CX::Int64)sbt_9qjfJaBACdDTM155W3Z3T8NfYGq6hmNMoFV4N6xV46G6hZ1ibxXBvuPT2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.begin(); iter != sbt_EpjnUGirXOxeT9eUb2NVNaUsN9Gm7vdcGl3vmaEQjd2xK_IDVA8CKzK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI", (CX::Int64)sbt_6TrYqWvs1yr1iU7hlpYpd2MElrNtC220Zc9_KrbmKJGqI)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_NBxyqWHcZuXZ9BFH4Jmdwathu>::Type sbt_NBxyqWHcZuXZ9BFH4JmdwathuArray;

