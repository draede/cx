
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_nckrD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3;
	CX::UInt64 sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky;
	CX::UInt16 sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt;
	CX::IO::SimpleBuffers::StringArray sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ;
	CX::Int32 sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5;
	CX::UInt64 sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we;
	CX::Int64 sbt_sS2p5Mjso;
	CX::IO::SimpleBuffers::UInt64Array sbt_bfw2te7POqjcmR5hF8Wxuvutv;
	CX::UInt64 sbt_YU427O8iGy9if;
	CX::Bool sbt_v6a5_kipq0JW9xlZizllS7i;

	virtual void Reset()
	{
		sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3 = 0;
		sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky = 0;
		sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt = 0;
		sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.clear();
		sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5 = 0;
		sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we = 0;
		sbt_sS2p5Mjso = 0;
		sbt_bfw2te7POqjcmR5hF8Wxuvutv.clear();
		sbt_YU427O8iGy9if = 0;
		sbt_v6a5_kipq0JW9xlZizllS7i = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3 = -7;
		sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky = 4183822725632909318;
		sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt = 40105;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.push_back("7zW*+};Z]6=BL0DR9j{`OG|[Z99D#]VmM00f7");
		}
		sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5 = -1202734495;
		sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we = 14066638423964914834;
		sbt_sS2p5Mjso = 7017930085363047478;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_bfw2te7POqjcmR5hF8Wxuvutv.push_back(2883977303664212476);
		}
		sbt_YU427O8iGy9if = 4120028612184739294;
		sbt_v6a5_kipq0JW9xlZizllS7i = true;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_nckrD *pObject = dynamic_cast<const sbt_nckrD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3 != pObject->sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3)
		{
			return false;
		}
		if (sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky != pObject->sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky)
		{
			return false;
		}
		if (sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt != pObject->sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt)
		{
			return false;
		}
		if (sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.size() != pObject->sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ[i].c_str(), pObject->sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5 != pObject->sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5)
		{
			return false;
		}
		if (sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we != pObject->sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we)
		{
			return false;
		}
		if (sbt_sS2p5Mjso != pObject->sbt_sS2p5Mjso)
		{
			return false;
		}
		if (sbt_bfw2te7POqjcmR5hF8Wxuvutv.size() != pObject->sbt_bfw2te7POqjcmR5hF8Wxuvutv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bfw2te7POqjcmR5hF8Wxuvutv.size(); i++)
		{
			if (sbt_bfw2te7POqjcmR5hF8Wxuvutv[i] != pObject->sbt_bfw2te7POqjcmR5hF8Wxuvutv[i])
			{
				return false;
			}
		}
		if (sbt_YU427O8iGy9if != pObject->sbt_YU427O8iGy9if)
		{
			return false;
		}
		if (sbt_v6a5_kipq0JW9xlZizllS7i != pObject->sbt_v6a5_kipq0JW9xlZizllS7i)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sS2p5Mjso", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sS2p5Mjso = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bfw2te7POqjcmR5hF8Wxuvutv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bfw2te7POqjcmR5hF8Wxuvutv.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YU427O8iGy9if", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YU427O8iGy9if = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_v6a5_kipq0JW9xlZizllS7i", &sbt_v6a5_kipq0JW9xlZizllS7i)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3", (CX::Int64)sbt_5eNMglrjsW1lDN0yNBkgKBdftipGWkd2QtcxWccbpZTnUPzdCsTU2l3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky", (CX::Int64)sbt_2Byyjhkah0gltbptcN7vnlmnmi7nIFuywaHD2fj0415NmTpMQjGdhb0Ky)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt", (CX::Int64)sbt_WoXyMGVgSGbDD54qufcx_dbUY1TL_1ZY8JSKB7Yy8aw4YAJK6kt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.begin(); iter != sbt_9rVp1PC27oeJrW59BhSDVe9vm07dxVVyqfvDUuzbyNPGMGOrLzfvQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5", (CX::Int64)sbt_yVRABqrc6ts5SKRC0ZSWNPwpLrVXgrvzxZMC5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we", (CX::Int64)sbt__PqoGYG3Yj6sYqNoCvx6zhuZ2O0we)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sS2p5Mjso", (CX::Int64)sbt_sS2p5Mjso)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bfw2te7POqjcmR5hF8Wxuvutv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_bfw2te7POqjcmR5hF8Wxuvutv.begin(); iter != sbt_bfw2te7POqjcmR5hF8Wxuvutv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YU427O8iGy9if", (CX::Int64)sbt_YU427O8iGy9if)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_v6a5_kipq0JW9xlZizllS7i", sbt_v6a5_kipq0JW9xlZizllS7i)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_nckrD>::Type sbt_nckrDArray;

