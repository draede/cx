
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V.hpp"


class sbt_331VBWiLJQSGaFc5Vf1qIWKbE : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::DoubleArray sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV;
	CX::UInt8 sbt_J2g4EeAJKYLmScmFV0dr_wv6N;
	CX::IO::SimpleBuffers::BoolArray sbt_hH7Id_E6EuVWrlrky;
	CX::UInt64 sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK;
	CX::IO::SimpleBuffers::Int16Array sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4;
	CX::IO::SimpleBuffers::Int32Array sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ;
	CX::IO::SimpleBuffers::WStringArray sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM;
	CX::IO::SimpleBuffers::UInt8Array sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS;
	CX::IO::SimpleBuffers::Int64Array sbt_JY0ZOMR;
	CX::Int8 sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd;
	CX::Int16 sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3;
	CX::Bool sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv;
	CX::UInt64 sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS;
	CX::IO::SimpleBuffers::BoolArray sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs;
	CX::String sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk;
	CX::UInt32 sbt_VLy0yq7l_nzjZU9CtNDDFkKwp;
	CX::Int16 sbt_swz6vMQ;
	CX::UInt32 sbt_Fv5MsVp0brFmAULQEOD3PXricZL;
	sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0;

	virtual void Reset()
	{
		sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.clear();
		sbt_J2g4EeAJKYLmScmFV0dr_wv6N = 0;
		sbt_hH7Id_E6EuVWrlrky.clear();
		sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK = 0;
		sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.clear();
		sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.clear();
		sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.clear();
		sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.clear();
		sbt_JY0ZOMR.clear();
		sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd = 0;
		sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3 = 0;
		sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv = false;
		sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS = 0;
		sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.clear();
		sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk.clear();
		sbt_VLy0yq7l_nzjZU9CtNDDFkKwp = 0;
		sbt_swz6vMQ = 0;
		sbt_Fv5MsVp0brFmAULQEOD3PXricZL = 0;
		sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.push_back(0.311776);
		}
		sbt_J2g4EeAJKYLmScmFV0dr_wv6N = 131;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_hH7Id_E6EuVWrlrky.push_back(true);
		}
		sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK = 239179599251990392;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.push_back(-32346);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.push_back(-1790771409);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.push_back(L"H-^3y|x|1X7K82<HT~5J'E:]1j<j<w3H*RD7m+G6Sf}/uwElj9gevTMC-`d");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.push_back(100);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_JY0ZOMR.push_back(5070797392903399520);
		}
		sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd = 86;
		sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3 = 10459;
		sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv = true;
		sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS = 3573844445745684076;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.push_back(false);
		}
		sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk = "iA?vz;8HkLM1r$HL;K$o&pT\\H$V";
		sbt_VLy0yq7l_nzjZU9CtNDDFkKwp = 201143145;
		sbt_swz6vMQ = -7037;
		sbt_Fv5MsVp0brFmAULQEOD3PXricZL = 1191766098;
		sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_331VBWiLJQSGaFc5Vf1qIWKbE *pObject = dynamic_cast<const sbt_331VBWiLJQSGaFc5Vf1qIWKbE *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.size() != pObject->sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.size(); i++)
		{
			if (sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV[i] != pObject->sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV[i])
			{
				return false;
			}
		}
		if (sbt_J2g4EeAJKYLmScmFV0dr_wv6N != pObject->sbt_J2g4EeAJKYLmScmFV0dr_wv6N)
		{
			return false;
		}
		if (sbt_hH7Id_E6EuVWrlrky.size() != pObject->sbt_hH7Id_E6EuVWrlrky.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hH7Id_E6EuVWrlrky.size(); i++)
		{
			if (sbt_hH7Id_E6EuVWrlrky[i] != pObject->sbt_hH7Id_E6EuVWrlrky[i])
			{
				return false;
			}
		}
		if (sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK != pObject->sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK)
		{
			return false;
		}
		if (sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.size() != pObject->sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.size(); i++)
		{
			if (sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4[i] != pObject->sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4[i])
			{
				return false;
			}
		}
		if (sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.size() != pObject->sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.size(); i++)
		{
			if (sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ[i] != pObject->sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ[i])
			{
				return false;
			}
		}
		if (sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.size() != pObject->sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM[i].c_str(), pObject->sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.size() != pObject->sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.size(); i++)
		{
			if (sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS[i] != pObject->sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS[i])
			{
				return false;
			}
		}
		if (sbt_JY0ZOMR.size() != pObject->sbt_JY0ZOMR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JY0ZOMR.size(); i++)
		{
			if (sbt_JY0ZOMR[i] != pObject->sbt_JY0ZOMR[i])
			{
				return false;
			}
		}
		if (sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd != pObject->sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd)
		{
			return false;
		}
		if (sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3 != pObject->sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3)
		{
			return false;
		}
		if (sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv != pObject->sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv)
		{
			return false;
		}
		if (sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS != pObject->sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS)
		{
			return false;
		}
		if (sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.size() != pObject->sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.size(); i++)
		{
			if (sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs[i] != pObject->sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk.c_str(), pObject->sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk.c_str()))
		{
			return false;
		}
		if (sbt_VLy0yq7l_nzjZU9CtNDDFkKwp != pObject->sbt_VLy0yq7l_nzjZU9CtNDDFkKwp)
		{
			return false;
		}
		if (sbt_swz6vMQ != pObject->sbt_swz6vMQ)
		{
			return false;
		}
		if (sbt_Fv5MsVp0brFmAULQEOD3PXricZL != pObject->sbt_Fv5MsVp0brFmAULQEOD3PXricZL)
		{
			return false;
		}
		if (!sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0.Compare(&pObject->sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J2g4EeAJKYLmScmFV0dr_wv6N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J2g4EeAJKYLmScmFV0dr_wv6N = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hH7Id_E6EuVWrlrky")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hH7Id_E6EuVWrlrky.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JY0ZOMR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JY0ZOMR.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv", &sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk", &sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VLy0yq7l_nzjZU9CtNDDFkKwp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VLy0yq7l_nzjZU9CtNDDFkKwp = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_swz6vMQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_swz6vMQ = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Fv5MsVp0brFmAULQEOD3PXricZL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Fv5MsVp0brFmAULQEOD3PXricZL = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.begin(); iter != sbt_PsDo4j6GJlhsw8fksgNZRaf9QhV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J2g4EeAJKYLmScmFV0dr_wv6N", (CX::Int64)sbt_J2g4EeAJKYLmScmFV0dr_wv6N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hH7Id_E6EuVWrlrky")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_hH7Id_E6EuVWrlrky.begin(); iter != sbt_hH7Id_E6EuVWrlrky.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK", (CX::Int64)sbt_7fJkLIGbnqoEzXCgvr0IWPyob1cbMKJvPiRK8t9uqWCVOHU_DG_ZK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.begin(); iter != sbt_O0FIsX946qhVw8aQl7DJ2mPjP6mCryUbJHvIQfjNuDoVJqiIyksqzRypB0WwFS4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.begin(); iter != sbt_hKtYa4rTDn5tniO_YiI3mys12QbTgud4iykg3tgJ_l6pIA67ExL5j3cz_vQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.begin(); iter != sbt_SQhkBhkeD3q826R_qKzjV9hWNozjJ88_uNGmeLgbM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.begin(); iter != sbt_Baug1ZLlWpINbRqs_1X8slSH39ZkC06_xsASgTPPpkS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JY0ZOMR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_JY0ZOMR.begin(); iter != sbt_JY0ZOMR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd", (CX::Int64)sbt_NDtrtNui5Kwl_KfT9QWuS_RefCPJeVd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3", (CX::Int64)sbt_5XltqL8gjkPpupLyBk9VyL8ObMtNU_CcQX3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv", sbt_fXgpxGTTUj_vAgBCUQKoxjVingzH1PmSv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS", (CX::Int64)sbt_XsEOjfQ7yyjteR8Spx38aJbr4xzvBvGAjIKAbUHIPziyTM4jS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.begin(); iter != sbt_bdzmFtPp9Ids_BDOsOcuAcpKFO5cuIyWXMwY_pFSs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk", sbt_8N0MV3TLiiPhT63iFZiJiV2XhaU9LRZUZGxbQX3lWBWS6kd7LWJQOSk.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VLy0yq7l_nzjZU9CtNDDFkKwp", (CX::Int64)sbt_VLy0yq7l_nzjZU9CtNDDFkKwp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_swz6vMQ", (CX::Int64)sbt_swz6vMQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Fv5MsVp0brFmAULQEOD3PXricZL", (CX::Int64)sbt_Fv5MsVp0brFmAULQEOD3PXricZL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_9nKW2zgYL9thNdJJzc5N_HO6iwnHFo0g70Aw2icJQpTPITqSS1MgVGgY0.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_331VBWiLJQSGaFc5Vf1qIWKbE>::Type sbt_331VBWiLJQSGaFc5Vf1qIWKbEArray;

