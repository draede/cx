
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_XlfNKHcqKz_hmeH3R5P8l.hpp"


class sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz;
	CX::UInt16 sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2;
	CX::IO::SimpleBuffers::StringArray sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU;
	CX::Int8 sbt_sT1;
	CX::Bool sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t;
	CX::Int16 sbt_KQHGf43qJ;
	CX::Int64 sbt_2Cmwx;
	CX::Int8 sbt_sZkDcnSEM_nvpxF1swdvlELC2;
	CX::IO::SimpleBuffers::UInt32Array sbt_hqb5gnZ;
	CX::IO::SimpleBuffers::StringArray sbt_VT5;
	CX::IO::SimpleBuffers::WStringArray sbt_LRsa0;
	CX::IO::SimpleBuffers::FloatArray sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_;
	CX::IO::SimpleBuffers::WStringArray sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4;
	CX::Float sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301;
	CX::Int8 sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK;
	CX::UInt64 sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd;
	CX::WString sbt_QpFhXamfx_G;
	CX::String sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG;
	CX::IO::SimpleBuffers::Int64Array sbt_vUP4l087vFus5zbZZpZupGlhyYz04je;
	CX::String sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE;
	CX::UInt32 sbt_MzH;
	sbt_XlfNKHcqKz_hmeH3R5P8lArray sbt_eZw5EiVHBMtmfvBwP;

	virtual void Reset()
	{
		sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz = 0.0f;
		sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2 = 0;
		sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.clear();
		sbt_sT1 = 0;
		sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t = false;
		sbt_KQHGf43qJ = 0;
		sbt_2Cmwx = 0;
		sbt_sZkDcnSEM_nvpxF1swdvlELC2 = 0;
		sbt_hqb5gnZ.clear();
		sbt_VT5.clear();
		sbt_LRsa0.clear();
		sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.clear();
		sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.clear();
		sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301 = 0.0f;
		sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK = 0;
		sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd = 0;
		sbt_QpFhXamfx_G.clear();
		sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG.clear();
		sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.clear();
		sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE.clear();
		sbt_MzH = 0;
		sbt_eZw5EiVHBMtmfvBwP.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz = 0.672010f;
		sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2 = 36178;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.push_back(".I?Ciyt%6FJ,d|=_LPgS?!$T(i<yJZ?W/w]T_U'.`c.8>w");
		}
		sbt_sT1 = -51;
		sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t = true;
		sbt_KQHGf43qJ = 9759;
		sbt_2Cmwx = -7019506682608984954;
		sbt_sZkDcnSEM_nvpxF1swdvlELC2 = -3;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_hqb5gnZ.push_back(1876326754);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_VT5.push_back("!BnxTzXIXj5d");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_LRsa0.push_back(L"");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.push_back(0.964896f);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.push_back(L"TIc6P<jkIx-:5|h]!9-h+R<3fL{");
		}
		sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301 = 0.170283f;
		sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK = 114;
		sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd = 1853708517001071182;
		sbt_QpFhXamfx_G = L">bFrkPpgG]b72U_AsC6I|AMVX7IxXO1Z/])o*DDI31j=s(2yRy._4";
		sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG = "}}M";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.push_back(8674594462784206562);
		}
		sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE = "tW6Pq:n)\"#<";
		sbt_MzH = 958194690;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_XlfNKHcqKz_hmeH3R5P8l v;

			v.SetupWithSomeValues();
			sbt_eZw5EiVHBMtmfvBwP.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj *pObject = dynamic_cast<const sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz != pObject->sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz)
		{
			return false;
		}
		if (sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2 != pObject->sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2)
		{
			return false;
		}
		if (sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.size() != pObject->sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.size(); i++)
		{
			if (0 != cx_strcmp(sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU[i].c_str(), pObject->sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_sT1 != pObject->sbt_sT1)
		{
			return false;
		}
		if (sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t != pObject->sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t)
		{
			return false;
		}
		if (sbt_KQHGf43qJ != pObject->sbt_KQHGf43qJ)
		{
			return false;
		}
		if (sbt_2Cmwx != pObject->sbt_2Cmwx)
		{
			return false;
		}
		if (sbt_sZkDcnSEM_nvpxF1swdvlELC2 != pObject->sbt_sZkDcnSEM_nvpxF1swdvlELC2)
		{
			return false;
		}
		if (sbt_hqb5gnZ.size() != pObject->sbt_hqb5gnZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hqb5gnZ.size(); i++)
		{
			if (sbt_hqb5gnZ[i] != pObject->sbt_hqb5gnZ[i])
			{
				return false;
			}
		}
		if (sbt_VT5.size() != pObject->sbt_VT5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VT5.size(); i++)
		{
			if (0 != cx_strcmp(sbt_VT5[i].c_str(), pObject->sbt_VT5[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_LRsa0.size() != pObject->sbt_LRsa0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LRsa0.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_LRsa0[i].c_str(), pObject->sbt_LRsa0[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.size() != pObject->sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.size(); i++)
		{
			if (sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_[i] != pObject->sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_[i])
			{
				return false;
			}
		}
		if (sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.size() != pObject->sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4[i].c_str(), pObject->sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301 != pObject->sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301)
		{
			return false;
		}
		if (sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK != pObject->sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK)
		{
			return false;
		}
		if (sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd != pObject->sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_QpFhXamfx_G.c_str(), pObject->sbt_QpFhXamfx_G.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG.c_str(), pObject->sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG.c_str()))
		{
			return false;
		}
		if (sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.size() != pObject->sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.size(); i++)
		{
			if (sbt_vUP4l087vFus5zbZZpZupGlhyYz04je[i] != pObject->sbt_vUP4l087vFus5zbZZpZupGlhyYz04je[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE.c_str(), pObject->sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE.c_str()))
		{
			return false;
		}
		if (sbt_MzH != pObject->sbt_MzH)
		{
			return false;
		}
		if (sbt_eZw5EiVHBMtmfvBwP.size() != pObject->sbt_eZw5EiVHBMtmfvBwP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eZw5EiVHBMtmfvBwP.size(); i++)
		{
			if (!sbt_eZw5EiVHBMtmfvBwP[i].Compare(&pObject->sbt_eZw5EiVHBMtmfvBwP[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sT1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sT1 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t", &sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KQHGf43qJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KQHGf43qJ = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2Cmwx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2Cmwx = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sZkDcnSEM_nvpxF1swdvlELC2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sZkDcnSEM_nvpxF1swdvlELC2 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hqb5gnZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hqb5gnZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VT5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VT5.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LRsa0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LRsa0.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_QpFhXamfx_G", &sbt_QpFhXamfx_G)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG", &sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vUP4l087vFus5zbZZpZupGlhyYz04je")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE", &sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MzH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MzH = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eZw5EiVHBMtmfvBwP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_XlfNKHcqKz_hmeH3R5P8l tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_eZw5EiVHBMtmfvBwP.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz", (CX::Double)sbt_BbDD5WXZMd9xNFNw8hUswNzkBXaUQV2QfpkdTCEjNdsw3_Yb6K7OERET5MJeANz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2", (CX::Int64)sbt_8T6xo0oSFJLTCiws_T7OOzXLWZK38Y6jTwDKr9YQdgB6TYfn2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.begin(); iter != sbt_XiaTfaD7tLWcew38rGUcz2hFNVD1CCdcGffxz18vuaaEoJXxU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sT1", (CX::Int64)sbt_sT1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t", sbt_qxSYmt8GkSOnhuvInqYrQMfRP2VlK3Y_PsKay1TFP4ZDPKKsi8t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KQHGf43qJ", (CX::Int64)sbt_KQHGf43qJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2Cmwx", (CX::Int64)sbt_2Cmwx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sZkDcnSEM_nvpxF1swdvlELC2", (CX::Int64)sbt_sZkDcnSEM_nvpxF1swdvlELC2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hqb5gnZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_hqb5gnZ.begin(); iter != sbt_hqb5gnZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VT5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_VT5.begin(); iter != sbt_VT5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LRsa0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_LRsa0.begin(); iter != sbt_LRsa0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.begin(); iter != sbt_7BtiTz2YVHwso_mjgFbupCTQDVT2btW9Ey00T1n13rIa2xHnGt_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.begin(); iter != sbt_llNF888HsmOYNrNEHOV6ckRMS7GpeLcPorPg9z5WkKtP4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301", (CX::Double)sbt_N5ezzgsVVwE8MDZm6p1X4A0SMfFt301)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK", (CX::Int64)sbt_7v1Mf7T8ML6hqowaiOQ4Yx95EFf8yXP_i8lI5cyvSQnzK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd", (CX::Int64)sbt_Wq2I2Bo2n4t2lRwTdQqAmEQPg7dkl_wSWJbXuYSvd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_QpFhXamfx_G", sbt_QpFhXamfx_G.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG", sbt_yYn4UeRRC9NmMUyT6GylcsAaJifoT3oztI9IDmcDzEsh1eRwQBPAJiau8bG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vUP4l087vFus5zbZZpZupGlhyYz04je")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.begin(); iter != sbt_vUP4l087vFus5zbZZpZupGlhyYz04je.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE", sbt_0xBxxSB2MMqCi6SGyWjpfeynwxpBzton_reelNpqOphxxFEcMXFdCXE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MzH", (CX::Int64)sbt_MzH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eZw5EiVHBMtmfvBwP")).IsNOK())
		{
			return status;
		}
		for (sbt_XlfNKHcqKz_hmeH3R5P8lArray::const_iterator iter = sbt_eZw5EiVHBMtmfvBwP.begin(); iter != sbt_eZw5EiVHBMtmfvBwP.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj>::Type sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqjArray;

