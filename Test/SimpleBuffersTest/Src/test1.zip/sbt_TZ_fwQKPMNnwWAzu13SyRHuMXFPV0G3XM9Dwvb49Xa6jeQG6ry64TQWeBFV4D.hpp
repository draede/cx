
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj;
	CX::IO::SimpleBuffers::Int64Array sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to;

	virtual void Reset()
	{
		sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.clear();
		sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.push_back(4926084757809932406);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.push_back(-7001855251271267854);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D *pObject = dynamic_cast<const sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.size() != pObject->sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.size(); i++)
		{
			if (sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj[i] != pObject->sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj[i])
			{
				return false;
			}
		}
		if (sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.size() != pObject->sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.size(); i++)
		{
			if (sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to[i] != pObject->sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.begin(); iter != sbt_riNaoA4CrJuANkJVC8gPCW_7wMBBdmj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.begin(); iter != sbt_WkNubVwIhUDub4xYv1M39aW9chrLhy8QOj9Ao9Bseps73K0to.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D>::Type sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4DArray;

