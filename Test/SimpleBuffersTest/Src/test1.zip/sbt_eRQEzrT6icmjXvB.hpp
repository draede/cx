
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_eRQEzrT6icmjXvB : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m;
	CX::UInt64 sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR;
	CX::IO::SimpleBuffers::UInt8Array sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz;
	CX::UInt16 sbt_oRSHT4i2fZIPwISb2;
	CX::Int64 sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5;
	CX::IO::SimpleBuffers::BoolArray sbt_RcKSOw0wfhT;
	CX::String sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC;
	CX::UInt16 sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR;
	CX::IO::SimpleBuffers::StringArray sbt_quAYuIe;
	CX::String sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e;
	CX::IO::SimpleBuffers::UInt32Array sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2;
	CX::UInt16 sbt_xUT8vRq47p8epH4;

	virtual void Reset()
	{
		sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m = 0;
		sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR = 0;
		sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.clear();
		sbt_oRSHT4i2fZIPwISb2 = 0;
		sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5 = 0;
		sbt_RcKSOw0wfhT.clear();
		sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC.clear();
		sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR = 0;
		sbt_quAYuIe.clear();
		sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e.clear();
		sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.clear();
		sbt_xUT8vRq47p8epH4 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m = 16;
		sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR = 2491583574102053084;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.push_back(221);
		}
		sbt_oRSHT4i2fZIPwISb2 = 47805;
		sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5 = 1851068312961924212;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_RcKSOw0wfhT.push_back(false);
		}
		sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC = "T;t7!!%JKC|uW\"?b*\\[@r9|{J-_eSI/TQp2(]4%\\QPcHBRUy3b(CVEu}hZ";
		sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR = 49297;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_quAYuIe.push_back("LB@/?XJbK`\\0~O0{=r4Bkg#=!p{_,s-+vXQz|Xs%&n1F}[Upx4n");
		}
		sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e = "O%FgOV[@4d6M3'=;jf_zwxIps\"y";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.push_back(1291841538);
		}
		sbt_xUT8vRq47p8epH4 = 57299;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_eRQEzrT6icmjXvB *pObject = dynamic_cast<const sbt_eRQEzrT6icmjXvB *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m != pObject->sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m)
		{
			return false;
		}
		if (sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR != pObject->sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR)
		{
			return false;
		}
		if (sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.size() != pObject->sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.size(); i++)
		{
			if (sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz[i] != pObject->sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz[i])
			{
				return false;
			}
		}
		if (sbt_oRSHT4i2fZIPwISb2 != pObject->sbt_oRSHT4i2fZIPwISb2)
		{
			return false;
		}
		if (sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5 != pObject->sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5)
		{
			return false;
		}
		if (sbt_RcKSOw0wfhT.size() != pObject->sbt_RcKSOw0wfhT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RcKSOw0wfhT.size(); i++)
		{
			if (sbt_RcKSOw0wfhT[i] != pObject->sbt_RcKSOw0wfhT[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC.c_str(), pObject->sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC.c_str()))
		{
			return false;
		}
		if (sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR != pObject->sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR)
		{
			return false;
		}
		if (sbt_quAYuIe.size() != pObject->sbt_quAYuIe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_quAYuIe.size(); i++)
		{
			if (0 != cx_strcmp(sbt_quAYuIe[i].c_str(), pObject->sbt_quAYuIe[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e.c_str(), pObject->sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e.c_str()))
		{
			return false;
		}
		if (sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.size() != pObject->sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.size(); i++)
		{
			if (sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2[i] != pObject->sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2[i])
			{
				return false;
			}
		}
		if (sbt_xUT8vRq47p8epH4 != pObject->sbt_xUT8vRq47p8epH4)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oRSHT4i2fZIPwISb2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oRSHT4i2fZIPwISb2 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RcKSOw0wfhT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RcKSOw0wfhT.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC", &sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_quAYuIe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_quAYuIe.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e", &sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xUT8vRq47p8epH4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xUT8vRq47p8epH4 = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m", (CX::Int64)sbt_VJNtMRBpzsVJqWfYjxpQPhhyxP7Ikhl6v_FdA4zQ869_QKiHzDyc1mPRM6m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR", (CX::Int64)sbt_tW4aS8DA47WOOcZGh9kKNOqYUZq7hiI0eoJVoj5NtwSvOzR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.begin(); iter != sbt_flb29241Ib3incgJEU2kWKjn8PbOj4FYjSo870RufmH3kNWvVJ1rGzzPTzaXz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oRSHT4i2fZIPwISb2", (CX::Int64)sbt_oRSHT4i2fZIPwISb2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5", (CX::Int64)sbt_hYhUxnLGo4tjRL2bYny_KxOgoZHS5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RcKSOw0wfhT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_RcKSOw0wfhT.begin(); iter != sbt_RcKSOw0wfhT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC", sbt_MBP9_itvLKX99L9NomozlXmZxKQHIbXYMNnDilEM1xCVH1zmjeIrfcpb6sTXC.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR", (CX::Int64)sbt_FxS6qLVoQzE700042b81zsHQaqgKpvScjKYLvD5dEmVLnz5IyXqtLqmXR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_quAYuIe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_quAYuIe.begin(); iter != sbt_quAYuIe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e", sbt_gmSCl25MHFLrL5Uv6JDVv8RypVDZgtQzFm122RL675cX7AKkofAE8Lm3e.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.begin(); iter != sbt_HE4M8GTks2VuIwxvUUhiyMuDvYCwUMelwNyRE38sNBRHmbVG_QicbmSrJEIHOW2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xUT8vRq47p8epH4", (CX::Int64)sbt_xUT8vRq47p8epH4)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_eRQEzrT6icmjXvB>::Type sbt_eRQEzrT6icmjXvBArray;

