
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_XKW;
	CX::IO::SimpleBuffers::StringArray sbt_f1OO3OFvMmU;
	CX::UInt16 sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4;
	CX::IO::SimpleBuffers::UInt16Array sbt_kYNZqltbOcTind2_b2AZYlb;
	CX::IO::SimpleBuffers::BoolArray sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf;
	CX::UInt64 sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf;
	CX::String sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6;
	CX::UInt64 sbt_EWiHcvkqvGBzX;
	CX::IO::SimpleBuffers::UInt64Array sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx;
	CX::Int16 sbt_dkg;
	CX::UInt64 sbt_FWCqZ2Z6CIRDzjv;
	CX::IO::SimpleBuffers::UInt16Array sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p;

	virtual void Reset()
	{
		sbt_XKW.clear();
		sbt_f1OO3OFvMmU.clear();
		sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4 = 0;
		sbt_kYNZqltbOcTind2_b2AZYlb.clear();
		sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.clear();
		sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf = 0;
		sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6.clear();
		sbt_EWiHcvkqvGBzX = 0;
		sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.clear();
		sbt_dkg = 0;
		sbt_FWCqZ2Z6CIRDzjv = 0;
		sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_XKW.push_back(-16);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_f1OO3OFvMmU.push_back("dwuGn)~\\yi53vWW,]my-y");
		}
		sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4 = 53847;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_kYNZqltbOcTind2_b2AZYlb.push_back(2506);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.push_back(false);
		}
		sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf = 10785991237114917378;
		sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6 = "'oF%6Ydkqmr!TCvR,D!A+Re}n>x$+H`1#_]dZz:fPdD2>?";
		sbt_EWiHcvkqvGBzX = 6799879173156831598;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.push_back(9361458941498348276);
		}
		sbt_dkg = 2790;
		sbt_FWCqZ2Z6CIRDzjv = 11444515817369020328;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.push_back(45441);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD *pObject = dynamic_cast<const sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_XKW.size() != pObject->sbt_XKW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XKW.size(); i++)
		{
			if (sbt_XKW[i] != pObject->sbt_XKW[i])
			{
				return false;
			}
		}
		if (sbt_f1OO3OFvMmU.size() != pObject->sbt_f1OO3OFvMmU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f1OO3OFvMmU.size(); i++)
		{
			if (0 != cx_strcmp(sbt_f1OO3OFvMmU[i].c_str(), pObject->sbt_f1OO3OFvMmU[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4 != pObject->sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4)
		{
			return false;
		}
		if (sbt_kYNZqltbOcTind2_b2AZYlb.size() != pObject->sbt_kYNZqltbOcTind2_b2AZYlb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kYNZqltbOcTind2_b2AZYlb.size(); i++)
		{
			if (sbt_kYNZqltbOcTind2_b2AZYlb[i] != pObject->sbt_kYNZqltbOcTind2_b2AZYlb[i])
			{
				return false;
			}
		}
		if (sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.size() != pObject->sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.size(); i++)
		{
			if (sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf[i] != pObject->sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf[i])
			{
				return false;
			}
		}
		if (sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf != pObject->sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6.c_str(), pObject->sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6.c_str()))
		{
			return false;
		}
		if (sbt_EWiHcvkqvGBzX != pObject->sbt_EWiHcvkqvGBzX)
		{
			return false;
		}
		if (sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.size() != pObject->sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.size(); i++)
		{
			if (sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx[i] != pObject->sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx[i])
			{
				return false;
			}
		}
		if (sbt_dkg != pObject->sbt_dkg)
		{
			return false;
		}
		if (sbt_FWCqZ2Z6CIRDzjv != pObject->sbt_FWCqZ2Z6CIRDzjv)
		{
			return false;
		}
		if (sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.size() != pObject->sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.size(); i++)
		{
			if (sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p[i] != pObject->sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_XKW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XKW.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f1OO3OFvMmU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f1OO3OFvMmU.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kYNZqltbOcTind2_b2AZYlb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kYNZqltbOcTind2_b2AZYlb.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6", &sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EWiHcvkqvGBzX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EWiHcvkqvGBzX = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dkg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dkg = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_FWCqZ2Z6CIRDzjv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FWCqZ2Z6CIRDzjv = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_XKW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_XKW.begin(); iter != sbt_XKW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f1OO3OFvMmU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_f1OO3OFvMmU.begin(); iter != sbt_f1OO3OFvMmU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4", (CX::Int64)sbt_zaOhPCcAJ0rPJItAcRdLhqqB0AeGo8ERCRZUg5ghEt8QV6cd4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kYNZqltbOcTind2_b2AZYlb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_kYNZqltbOcTind2_b2AZYlb.begin(); iter != sbt_kYNZqltbOcTind2_b2AZYlb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.begin(); iter != sbt_eLwMnwluPIjsSUbO8emzyPqK4yzYXJ5rFycAk1dWQ_AwBXk5nh88mSeHm9DNf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf", (CX::Int64)sbt_FIptgI9C7_M8B8SXR29VIF39niY_Rjt8uI56bx3xKop5iKf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6", sbt_84O6P9BEiy2kR0RL85BQv97Ud89A9RW0cal6vt4a1IK42LdtWLsgl6gz0_6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EWiHcvkqvGBzX", (CX::Int64)sbt_EWiHcvkqvGBzX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.begin(); iter != sbt_Jhz9ne2CSS4Z6wKaP2cBbyma9LArYcEkKFZhFmKYVsC7znx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dkg", (CX::Int64)sbt_dkg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FWCqZ2Z6CIRDzjv", (CX::Int64)sbt_FWCqZ2Z6CIRDzjv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.begin(); iter != sbt_beW8Y4GEfSD6tExycCeBgKURsuZTFfPu9F5ytqmyLfWyeh5SaVR2p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD>::Type sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfDArray;

