
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_ejqhe;
	CX::UInt16 sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_;
	CX::Int16 sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al;
	CX::IO::SimpleBuffers::Int8Array sbt_iiY3Cbw33kPX4UiVPBU;
	CX::IO::SimpleBuffers::Int64Array sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g;

	virtual void Reset()
	{
		sbt_ejqhe = 0;
		sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_ = 0;
		sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al = 0;
		sbt_iiY3Cbw33kPX4UiVPBU.clear();
		sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ejqhe = 737931441;
		sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_ = 2298;
		sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al = -14690;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_iiY3Cbw33kPX4UiVPBU.push_back(112);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.push_back(-4071763794870877676);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy *pObject = dynamic_cast<const sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ejqhe != pObject->sbt_ejqhe)
		{
			return false;
		}
		if (sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_ != pObject->sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_)
		{
			return false;
		}
		if (sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al != pObject->sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al)
		{
			return false;
		}
		if (sbt_iiY3Cbw33kPX4UiVPBU.size() != pObject->sbt_iiY3Cbw33kPX4UiVPBU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iiY3Cbw33kPX4UiVPBU.size(); i++)
		{
			if (sbt_iiY3Cbw33kPX4UiVPBU[i] != pObject->sbt_iiY3Cbw33kPX4UiVPBU[i])
			{
				return false;
			}
		}
		if (sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.size() != pObject->sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.size(); i++)
		{
			if (sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g[i] != pObject->sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_ejqhe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ejqhe = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_ = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iiY3Cbw33kPX4UiVPBU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iiY3Cbw33kPX4UiVPBU.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_ejqhe", (CX::Int64)sbt_ejqhe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_", (CX::Int64)sbt_lkNFJgDqoSppttsrT_0fbpq7UZrpSylNIDKIAZQEDl86F202TYtK_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al", (CX::Int64)sbt_da58HnjcHLnbTlirKRa_oMbNrxqUl5jwbUdtBOhJQwlyEuhZT50Y8al)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iiY3Cbw33kPX4UiVPBU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_iiY3Cbw33kPX4UiVPBU.begin(); iter != sbt_iiY3Cbw33kPX4UiVPBU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.begin(); iter != sbt_YBs_6VkMGqioLaXCyGJKYVHpO6l6DJLiFqfDAKQbUoLJUyXVyM43g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy>::Type sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdyArray;

