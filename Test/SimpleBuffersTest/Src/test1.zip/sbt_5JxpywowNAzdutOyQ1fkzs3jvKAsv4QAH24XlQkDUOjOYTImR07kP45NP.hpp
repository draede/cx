
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC.hpp"


class sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_8Cr6Hb_2DINis9c;
	CX::String sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN;
	CX::WString sbt_vsYl29S0btxv2RI2OGVGxTGlcYW;
	CX::Int16 sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ;
	CX::IO::SimpleBuffers::Int8Array sbt_FCKfZ2DBl;
	CX::Int8 sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v;
	CX::Bool sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb;
	CX::Int8 sbt_UC7rR_oG_60Nz7lA9;
	CX::IO::SimpleBuffers::DoubleArray sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q;
	CX::IO::SimpleBuffers::UInt16Array sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe;
	sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp;

	virtual void Reset()
	{
		sbt_8Cr6Hb_2DINis9c = 0;
		sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN.clear();
		sbt_vsYl29S0btxv2RI2OGVGxTGlcYW.clear();
		sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ = 0;
		sbt_FCKfZ2DBl.clear();
		sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v = 0;
		sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb = false;
		sbt_UC7rR_oG_60Nz7lA9 = 0;
		sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.clear();
		sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.clear();
		sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_8Cr6Hb_2DINis9c = 91;
		sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN = "'pqoZ\\Wg(1YAew:";
		sbt_vsYl29S0btxv2RI2OGVGxTGlcYW = L"\\<Xkh/S`8;n*vu-7";
		sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ = -27595;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_FCKfZ2DBl.push_back(3);
		}
		sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v = 46;
		sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb = true;
		sbt_UC7rR_oG_60Nz7lA9 = -100;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.push_back(0.199613);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.push_back(53303);
		}
		sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP *pObject = dynamic_cast<const sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_8Cr6Hb_2DINis9c != pObject->sbt_8Cr6Hb_2DINis9c)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN.c_str(), pObject->sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN.c_str()))
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_vsYl29S0btxv2RI2OGVGxTGlcYW.c_str(), pObject->sbt_vsYl29S0btxv2RI2OGVGxTGlcYW.c_str()))
		{
			return false;
		}
		if (sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ != pObject->sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ)
		{
			return false;
		}
		if (sbt_FCKfZ2DBl.size() != pObject->sbt_FCKfZ2DBl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FCKfZ2DBl.size(); i++)
		{
			if (sbt_FCKfZ2DBl[i] != pObject->sbt_FCKfZ2DBl[i])
			{
				return false;
			}
		}
		if (sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v != pObject->sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v)
		{
			return false;
		}
		if (sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb != pObject->sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb)
		{
			return false;
		}
		if (sbt_UC7rR_oG_60Nz7lA9 != pObject->sbt_UC7rR_oG_60Nz7lA9)
		{
			return false;
		}
		if (sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.size() != pObject->sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.size(); i++)
		{
			if (sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q[i] != pObject->sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q[i])
			{
				return false;
			}
		}
		if (sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.size() != pObject->sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.size(); i++)
		{
			if (sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe[i] != pObject->sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe[i])
			{
				return false;
			}
		}
		if (!sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp.Compare(&pObject->sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_8Cr6Hb_2DINis9c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8Cr6Hb_2DINis9c = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN", &sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_vsYl29S0btxv2RI2OGVGxTGlcYW", &sbt_vsYl29S0btxv2RI2OGVGxTGlcYW)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FCKfZ2DBl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FCKfZ2DBl.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb", &sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UC7rR_oG_60Nz7lA9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UC7rR_oG_60Nz7lA9 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_8Cr6Hb_2DINis9c", (CX::Int64)sbt_8Cr6Hb_2DINis9c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN", sbt_69t6ukRchtOgMR2plhXqEV0wKAFRmeGkKI3L7uYaZCKio3NAVbhSIIBl36MqN.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_vsYl29S0btxv2RI2OGVGxTGlcYW", sbt_vsYl29S0btxv2RI2OGVGxTGlcYW.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ", (CX::Int64)sbt_wOP6mzym2ZToOTk7n40oF4E1s77rG_PWxVaK4c4tCIFmEKtg_HFy16btiHUmVhQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FCKfZ2DBl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_FCKfZ2DBl.begin(); iter != sbt_FCKfZ2DBl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v", (CX::Int64)sbt_hcPjNkqgBUuMptcXZmjk0wg8nrLyCLodMHZ7v)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb", sbt_vr15GpanwbvnMYOmKrZGRhDiAh6jFYrnWsfjYjb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UC7rR_oG_60Nz7lA9", (CX::Int64)sbt_UC7rR_oG_60Nz7lA9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.begin(); iter != sbt_aSDDbLNGvlTKmkrYKn9014xYVBJS7pwuB1jUtrVVwx9TPAb_gMdXOXX0ExwL_7Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.begin(); iter != sbt_VeuS3iOEcz2C5gbR5OeupeHQhm2a3nv_x7orm57Z07n7Acj3XeOq30LQe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Z5LOiqCRSBHyZvgVPuure6K4zR_bwKzFWMjoxVZHkw6st6VV9EvsHfndNlp.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP>::Type sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NPArray;

