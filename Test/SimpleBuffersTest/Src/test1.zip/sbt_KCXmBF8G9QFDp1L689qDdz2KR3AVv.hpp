
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN;
	CX::Int16 sbt_Dir3YbCzlOfjFeLQPos;
	CX::UInt16 sbt_hYUeaE9Tr;
	CX::Int64 sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0;
	CX::UInt32 sbt_v96;
	CX::IO::SimpleBuffers::UInt16Array sbt_pWxuyS5n4ojHDmenu;
	CX::String sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14;
	CX::IO::SimpleBuffers::Int16Array sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY;
	CX::Bool sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU;
	CX::Bool sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o;
	CX::IO::SimpleBuffers::UInt64Array sbt_E2SkdB42HP5Sa7b;
	CX::Int64 sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK;

	virtual void Reset()
	{
		sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.clear();
		sbt_Dir3YbCzlOfjFeLQPos = 0;
		sbt_hYUeaE9Tr = 0;
		sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0 = 0;
		sbt_v96 = 0;
		sbt_pWxuyS5n4ojHDmenu.clear();
		sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14.clear();
		sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.clear();
		sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU = false;
		sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o = false;
		sbt_E2SkdB42HP5Sa7b.clear();
		sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.push_back(17764921081387290670);
		}
		sbt_Dir3YbCzlOfjFeLQPos = 32626;
		sbt_hYUeaE9Tr = 4132;
		sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0 = 2730536155637482232;
		sbt_v96 = 450156234;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_pWxuyS5n4ojHDmenu.push_back(23767);
		}
		sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14 = "";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.push_back(10539);
		}
		sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU = true;
		sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o = true;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_E2SkdB42HP5Sa7b.push_back(5774688751049110974);
		}
		sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK = 8596332281858104294;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv *pObject = dynamic_cast<const sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.size() != pObject->sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.size(); i++)
		{
			if (sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN[i] != pObject->sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN[i])
			{
				return false;
			}
		}
		if (sbt_Dir3YbCzlOfjFeLQPos != pObject->sbt_Dir3YbCzlOfjFeLQPos)
		{
			return false;
		}
		if (sbt_hYUeaE9Tr != pObject->sbt_hYUeaE9Tr)
		{
			return false;
		}
		if (sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0 != pObject->sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0)
		{
			return false;
		}
		if (sbt_v96 != pObject->sbt_v96)
		{
			return false;
		}
		if (sbt_pWxuyS5n4ojHDmenu.size() != pObject->sbt_pWxuyS5n4ojHDmenu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pWxuyS5n4ojHDmenu.size(); i++)
		{
			if (sbt_pWxuyS5n4ojHDmenu[i] != pObject->sbt_pWxuyS5n4ojHDmenu[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14.c_str(), pObject->sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14.c_str()))
		{
			return false;
		}
		if (sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.size() != pObject->sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.size(); i++)
		{
			if (sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY[i] != pObject->sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY[i])
			{
				return false;
			}
		}
		if (sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU != pObject->sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU)
		{
			return false;
		}
		if (sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o != pObject->sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o)
		{
			return false;
		}
		if (sbt_E2SkdB42HP5Sa7b.size() != pObject->sbt_E2SkdB42HP5Sa7b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E2SkdB42HP5Sa7b.size(); i++)
		{
			if (sbt_E2SkdB42HP5Sa7b[i] != pObject->sbt_E2SkdB42HP5Sa7b[i])
			{
				return false;
			}
		}
		if (sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK != pObject->sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Dir3YbCzlOfjFeLQPos", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Dir3YbCzlOfjFeLQPos = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hYUeaE9Tr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hYUeaE9Tr = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_v96", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v96 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pWxuyS5n4ojHDmenu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pWxuyS5n4ojHDmenu.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14", &sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU", &sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o", &sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E2SkdB42HP5Sa7b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E2SkdB42HP5Sa7b.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK = (CX::Int64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.begin(); iter != sbt_xvX_GLgTAw1Rj7oq9OQP6k6cVEsEMQ_uIVX_6SqNN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Dir3YbCzlOfjFeLQPos", (CX::Int64)sbt_Dir3YbCzlOfjFeLQPos)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hYUeaE9Tr", (CX::Int64)sbt_hYUeaE9Tr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0", (CX::Int64)sbt_Y1aoQw8Wy5NF7ZbXCuh2FM0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v96", (CX::Int64)sbt_v96)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pWxuyS5n4ojHDmenu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_pWxuyS5n4ojHDmenu.begin(); iter != sbt_pWxuyS5n4ojHDmenu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14", sbt__aOcPDn7j295zDN7QDf2anfrauQOhdtLzmlKmbucCIi14.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.begin(); iter != sbt_X86RJAnv71LC1EsJ3HN2Iqw2Q627QiOof43PDmZ4Ercmxj_tY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU", sbt_UhthSogOqzcnthkBk8dAdM6Mq1IS4ZU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o", sbt_9V25XwKo3S3DDv3QeHLXtAou6PbOxC_NpWhTRCe6o)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E2SkdB42HP5Sa7b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_E2SkdB42HP5Sa7b.begin(); iter != sbt_E2SkdB42HP5Sa7b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK", (CX::Int64)sbt_7HgkESrIgImjzl9wQ1tBuXZdgaGgQIoaOY2bTugk68tkYgQQ8NQKK)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv>::Type sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVvArray;

