
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1;
	CX::IO::SimpleBuffers::UInt64Array sbt_PXwD0rm8eEzP0lTOmVx5HWKi1;
	CX::UInt64 sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF;
	CX::IO::SimpleBuffers::UInt16Array sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt;
	CX::Int8 sbt_EQGC8fSPe91;
	CX::Bool sbt_RZS;
	CX::Bool sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh;
	CX::IO::SimpleBuffers::UInt64Array sbt_X;
	CX::String sbt_zDQ__EhwrotpwmB;
	CX::IO::SimpleBuffers::StringArray sbt_uq2_X;
	CX::String sbt_QYPj8t3_qud5lAROz3w0I;
	CX::Int64 sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA;
	CX::IO::SimpleBuffers::Int32Array sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC;
	CX::UInt16 sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC;
	CX::IO::SimpleBuffers::UInt64Array sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2;
	CX::IO::SimpleBuffers::UInt64Array sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ;
	CX::IO::SimpleBuffers::Int16Array sbt_B6_iO8j44qvyUXdOQ6XIl;
	CX::UInt64 sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj;
	CX::IO::SimpleBuffers::UInt64Array sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84;
	CX::String sbt_V18bF8TzwcruQIJES5f3xMRCS;
	CX::IO::SimpleBuffers::UInt64Array sbt_5dkD5;
	CX::Bool sbt_9ztkj6v;
	CX::IO::SimpleBuffers::UInt64Array sbt_2YatPvvIPh26ICBX7;
	CX::IO::SimpleBuffers::BoolArray sbt_qbBBKYoeewSgGZ0l5Wv6vXc;

	virtual void Reset()
	{
		sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1.clear();
		sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.clear();
		sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF = 0;
		sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.clear();
		sbt_EQGC8fSPe91 = 0;
		sbt_RZS = false;
		sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh = false;
		sbt_X.clear();
		sbt_zDQ__EhwrotpwmB.clear();
		sbt_uq2_X.clear();
		sbt_QYPj8t3_qud5lAROz3w0I.clear();
		sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA = 0;
		sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.clear();
		sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC = 0;
		sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.clear();
		sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.clear();
		sbt_B6_iO8j44qvyUXdOQ6XIl.clear();
		sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj = 0;
		sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.clear();
		sbt_V18bF8TzwcruQIJES5f3xMRCS.clear();
		sbt_5dkD5.clear();
		sbt_9ztkj6v = false;
		sbt_2YatPvvIPh26ICBX7.clear();
		sbt_qbBBKYoeewSgGZ0l5Wv6vXc.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1 = "-g|rswRzvrH{G^G|8$\"X\"tB~qF'Yj#+\\L)Ggz";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.push_back(14501117366759797340);
		}
		sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF = 15332217717414653890;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.push_back(4242);
		}
		sbt_EQGC8fSPe91 = -63;
		sbt_RZS = true;
		sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_X.push_back(17635521826217878138);
		}
		sbt_zDQ__EhwrotpwmB = "*@t.7>VQ+q$rd`eeDaXCWn,]-GbaUwn";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_uq2_X.push_back("MwrA(oMjt:Xf\"pG`Lk]AJ7$]n@+0lEy");
		}
		sbt_QYPj8t3_qud5lAROz3w0I = "fW|CW%(.HD.X@H<;2\"=K,W#6&Dv\\sv+_816S4b;9Yu";
		sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA = -2197261736063518658;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.push_back(732433517);
		}
		sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC = 19573;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.push_back(8790226558031929660);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.push_back(57579837494539270);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_B6_iO8j44qvyUXdOQ6XIl.push_back(-30642);
		}
		sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj = 7029813598034018930;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.push_back(6565737163205352046);
		}
		sbt_V18bF8TzwcruQIJES5f3xMRCS = "?tk<;^!&(#+SO&Q]!{EAzbo-I`mct'k>E,";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_5dkD5.push_back(9017626393595153638);
		}
		sbt_9ztkj6v = true;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_2YatPvvIPh26ICBX7.push_back(2505975282695596056);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_qbBBKYoeewSgGZ0l5Wv6vXc.push_back(true);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9 *pObject = dynamic_cast<const sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1.c_str(), pObject->sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1.c_str()))
		{
			return false;
		}
		if (sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.size() != pObject->sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.size(); i++)
		{
			if (sbt_PXwD0rm8eEzP0lTOmVx5HWKi1[i] != pObject->sbt_PXwD0rm8eEzP0lTOmVx5HWKi1[i])
			{
				return false;
			}
		}
		if (sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF != pObject->sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF)
		{
			return false;
		}
		if (sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.size() != pObject->sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.size(); i++)
		{
			if (sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt[i] != pObject->sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt[i])
			{
				return false;
			}
		}
		if (sbt_EQGC8fSPe91 != pObject->sbt_EQGC8fSPe91)
		{
			return false;
		}
		if (sbt_RZS != pObject->sbt_RZS)
		{
			return false;
		}
		if (sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh != pObject->sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh)
		{
			return false;
		}
		if (sbt_X.size() != pObject->sbt_X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X.size(); i++)
		{
			if (sbt_X[i] != pObject->sbt_X[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_zDQ__EhwrotpwmB.c_str(), pObject->sbt_zDQ__EhwrotpwmB.c_str()))
		{
			return false;
		}
		if (sbt_uq2_X.size() != pObject->sbt_uq2_X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uq2_X.size(); i++)
		{
			if (0 != cx_strcmp(sbt_uq2_X[i].c_str(), pObject->sbt_uq2_X[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_QYPj8t3_qud5lAROz3w0I.c_str(), pObject->sbt_QYPj8t3_qud5lAROz3w0I.c_str()))
		{
			return false;
		}
		if (sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA != pObject->sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA)
		{
			return false;
		}
		if (sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.size() != pObject->sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.size(); i++)
		{
			if (sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC[i] != pObject->sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC[i])
			{
				return false;
			}
		}
		if (sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC != pObject->sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC)
		{
			return false;
		}
		if (sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.size() != pObject->sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.size(); i++)
		{
			if (sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2[i] != pObject->sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2[i])
			{
				return false;
			}
		}
		if (sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.size() != pObject->sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.size(); i++)
		{
			if (sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ[i] != pObject->sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ[i])
			{
				return false;
			}
		}
		if (sbt_B6_iO8j44qvyUXdOQ6XIl.size() != pObject->sbt_B6_iO8j44qvyUXdOQ6XIl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B6_iO8j44qvyUXdOQ6XIl.size(); i++)
		{
			if (sbt_B6_iO8j44qvyUXdOQ6XIl[i] != pObject->sbt_B6_iO8j44qvyUXdOQ6XIl[i])
			{
				return false;
			}
		}
		if (sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj != pObject->sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj)
		{
			return false;
		}
		if (sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.size() != pObject->sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.size(); i++)
		{
			if (sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84[i] != pObject->sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_V18bF8TzwcruQIJES5f3xMRCS.c_str(), pObject->sbt_V18bF8TzwcruQIJES5f3xMRCS.c_str()))
		{
			return false;
		}
		if (sbt_5dkD5.size() != pObject->sbt_5dkD5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5dkD5.size(); i++)
		{
			if (sbt_5dkD5[i] != pObject->sbt_5dkD5[i])
			{
				return false;
			}
		}
		if (sbt_9ztkj6v != pObject->sbt_9ztkj6v)
		{
			return false;
		}
		if (sbt_2YatPvvIPh26ICBX7.size() != pObject->sbt_2YatPvvIPh26ICBX7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2YatPvvIPh26ICBX7.size(); i++)
		{
			if (sbt_2YatPvvIPh26ICBX7[i] != pObject->sbt_2YatPvvIPh26ICBX7[i])
			{
				return false;
			}
		}
		if (sbt_qbBBKYoeewSgGZ0l5Wv6vXc.size() != pObject->sbt_qbBBKYoeewSgGZ0l5Wv6vXc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qbBBKYoeewSgGZ0l5Wv6vXc.size(); i++)
		{
			if (sbt_qbBBKYoeewSgGZ0l5Wv6vXc[i] != pObject->sbt_qbBBKYoeewSgGZ0l5Wv6vXc[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1", &sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PXwD0rm8eEzP0lTOmVx5HWKi1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EQGC8fSPe91", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EQGC8fSPe91 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_RZS", &sbt_RZS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh", &sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_zDQ__EhwrotpwmB", &sbt_zDQ__EhwrotpwmB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uq2_X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uq2_X.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_QYPj8t3_qud5lAROz3w0I", &sbt_QYPj8t3_qud5lAROz3w0I)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_B6_iO8j44qvyUXdOQ6XIl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B6_iO8j44qvyUXdOQ6XIl.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_V18bF8TzwcruQIJES5f3xMRCS", &sbt_V18bF8TzwcruQIJES5f3xMRCS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5dkD5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5dkD5.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_9ztkj6v", &sbt_9ztkj6v)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2YatPvvIPh26ICBX7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2YatPvvIPh26ICBX7.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qbBBKYoeewSgGZ0l5Wv6vXc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qbBBKYoeewSgGZ0l5Wv6vXc.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1", sbt_LttURHeYmumijxMV3Umo_Urv5dcmmi1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PXwD0rm8eEzP0lTOmVx5HWKi1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.begin(); iter != sbt_PXwD0rm8eEzP0lTOmVx5HWKi1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF", (CX::Int64)sbt_0PQ6Y94O5qW1fyW9kHnkaL7M_8nlHwBODKTbZyMXHrOxRhF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.begin(); iter != sbt_pXVuRmsL_IJRgFFk4drWc3txwrI58ChOu7h7jcbaSuJGwvHeBo8Lj7DAt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EQGC8fSPe91", (CX::Int64)sbt_EQGC8fSPe91)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_RZS", sbt_RZS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh", sbt_oXZVzr9_BmWtqyJbWfQmyFnKeGMSvt9rh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_X.begin(); iter != sbt_X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_zDQ__EhwrotpwmB", sbt_zDQ__EhwrotpwmB.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uq2_X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_uq2_X.begin(); iter != sbt_uq2_X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_QYPj8t3_qud5lAROz3w0I", sbt_QYPj8t3_qud5lAROz3w0I.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA", (CX::Int64)sbt_UQ81oyy1c9Iyjhcbv0gIvw_xlA9f3uxQJ48HMrA0RZZFghHSbZAkA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.begin(); iter != sbt_8ftP_fb73shuDdh4XKz54yRlUF111H9U2aC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC", (CX::Int64)sbt_wIXarBm1c48SZr6ouMudlJ7W6eJqMh5uC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.begin(); iter != sbt_22z0lleWGAc_AkCjBzttvA2spwh4ouUVWRmtUOdA2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.begin(); iter != sbt_WciLKKjOrtluEMzCDhXBGHjwp0ecpL9BYbrLV25lAHQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B6_iO8j44qvyUXdOQ6XIl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_B6_iO8j44qvyUXdOQ6XIl.begin(); iter != sbt_B6_iO8j44qvyUXdOQ6XIl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj", (CX::Int64)sbt_G7BY94wC8bFEHM9oOBUWSqcIAra5VDtkmGvgZ6dKDI6pUxE5SyvAv4EUnFj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.begin(); iter != sbt_6TU3488SonjblNVr8uL02umcoECRXgyHndTwLztoog4PnbU9d84.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_V18bF8TzwcruQIJES5f3xMRCS", sbt_V18bF8TzwcruQIJES5f3xMRCS.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5dkD5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5dkD5.begin(); iter != sbt_5dkD5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_9ztkj6v", sbt_9ztkj6v)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2YatPvvIPh26ICBX7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_2YatPvvIPh26ICBX7.begin(); iter != sbt_2YatPvvIPh26ICBX7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qbBBKYoeewSgGZ0l5Wv6vXc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_qbBBKYoeewSgGZ0l5Wv6vXc.begin(); iter != sbt_qbBBKYoeewSgGZ0l5Wv6vXc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9>::Type sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9Array;

