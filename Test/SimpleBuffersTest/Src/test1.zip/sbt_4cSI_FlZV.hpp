
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_yjnlVxwXS3ejxjxjiuOVP.hpp"


class sbt_4cSI_FlZV : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun;
	CX::IO::SimpleBuffers::Int32Array sbt_q2qywLRkSaEh7;
	CX::IO::SimpleBuffers::FloatArray sbt_DsDyuu3aufWsV12GvT3Cc;
	CX::Int64 sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry;
	sbt_yjnlVxwXS3ejxjxjiuOVP sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k;

	virtual void Reset()
	{
		sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.clear();
		sbt_q2qywLRkSaEh7.clear();
		sbt_DsDyuu3aufWsV12GvT3Cc.clear();
		sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry = 0;
		sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_q2qywLRkSaEh7.push_back(11232998);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_DsDyuu3aufWsV12GvT3Cc.push_back(0.714234f);
		}
		sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry = -7736644435769033936;
		sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4cSI_FlZV *pObject = dynamic_cast<const sbt_4cSI_FlZV *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.size() != pObject->sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.size(); i++)
		{
			if (sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun[i] != pObject->sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun[i])
			{
				return false;
			}
		}
		if (sbt_q2qywLRkSaEh7.size() != pObject->sbt_q2qywLRkSaEh7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q2qywLRkSaEh7.size(); i++)
		{
			if (sbt_q2qywLRkSaEh7[i] != pObject->sbt_q2qywLRkSaEh7[i])
			{
				return false;
			}
		}
		if (sbt_DsDyuu3aufWsV12GvT3Cc.size() != pObject->sbt_DsDyuu3aufWsV12GvT3Cc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DsDyuu3aufWsV12GvT3Cc.size(); i++)
		{
			if (sbt_DsDyuu3aufWsV12GvT3Cc[i] != pObject->sbt_DsDyuu3aufWsV12GvT3Cc[i])
			{
				return false;
			}
		}
		if (sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry != pObject->sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry)
		{
			return false;
		}
		if (!sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k.Compare(&pObject->sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_q2qywLRkSaEh7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q2qywLRkSaEh7.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DsDyuu3aufWsV12GvT3Cc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DsDyuu3aufWsV12GvT3Cc.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectObject("sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.begin(); iter != sbt_m4R817Y6BQ80BF4iLR7CeOzumCTucmD6dw94__x3lcmO84LW0oGOcmshkun.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q2qywLRkSaEh7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_q2qywLRkSaEh7.begin(); iter != sbt_q2qywLRkSaEh7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DsDyuu3aufWsV12GvT3Cc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_DsDyuu3aufWsV12GvT3Cc.begin(); iter != sbt_DsDyuu3aufWsV12GvT3Cc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry", (CX::Int64)sbt_vYhVp33QbgIUP6auiwtdTrKrNIK8nxqZhTnQ99hplRIvGJdpOK0i8BTqtJb03ry)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_RVUe2TD7d3u_pYWxbE86qBr6xoGJXRhVyqwFz7k.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4cSI_FlZV>::Type sbt_4cSI_FlZVArray;

