
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc;
	CX::IO::SimpleBuffers::Int8Array sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl;
	CX::UInt64 sbt_4;
	CX::Int32 sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU;
	CX::UInt32 sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN;
	CX::UInt64 sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024;
	CX::IO::SimpleBuffers::UInt16Array sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi;
	CX::IO::SimpleBuffers::Int32Array sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH;
	CX::IO::SimpleBuffers::BoolArray sbt_6;
	CX::UInt16 sbt_ZnUJRfv3IU_gLNDm8Z2PsGC;
	CX::IO::SimpleBuffers::UInt64Array sbt_VtH;
	CX::IO::SimpleBuffers::UInt64Array sbt_DFiBScMjo6IK9izRVMZx1;
	CX::Int8 sbt_zenUpU5KzbO;
	CX::IO::SimpleBuffers::UInt16Array sbt_X1YOwiH40jlZ8MnthlUlRf7;
	CX::UInt32 sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE;
	CX::IO::SimpleBuffers::UInt64Array sbt_kaENraqVKkuwJLHQL06oef3MN;
	CX::Int16 sbt_hvlJTj2s5Rpls;
	CX::IO::SimpleBuffers::UInt64Array sbt_03tre;

	virtual void Reset()
	{
		sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc = 0;
		sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.clear();
		sbt_4 = 0;
		sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU = 0;
		sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN = 0;
		sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024 = 0;
		sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.clear();
		sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.clear();
		sbt_6.clear();
		sbt_ZnUJRfv3IU_gLNDm8Z2PsGC = 0;
		sbt_VtH.clear();
		sbt_DFiBScMjo6IK9izRVMZx1.clear();
		sbt_zenUpU5KzbO = 0;
		sbt_X1YOwiH40jlZ8MnthlUlRf7.clear();
		sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE = 0;
		sbt_kaENraqVKkuwJLHQL06oef3MN.clear();
		sbt_hvlJTj2s5Rpls = 0;
		sbt_03tre.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc = 10469;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.push_back(79);
		}
		sbt_4 = 4785261111827874816;
		sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU = -346613073;
		sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN = 1789218044;
		sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024 = 6557861714468245950;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.push_back(41626);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.push_back(1382543206);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_6.push_back(false);
		}
		sbt_ZnUJRfv3IU_gLNDm8Z2PsGC = 30648;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_VtH.push_back(15361909203730506992);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_DFiBScMjo6IK9izRVMZx1.push_back(7239892457030352112);
		}
		sbt_zenUpU5KzbO = 14;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_X1YOwiH40jlZ8MnthlUlRf7.push_back(60613);
		}
		sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE = 1966194048;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_kaENraqVKkuwJLHQL06oef3MN.push_back(15564723147589125220);
		}
		sbt_hvlJTj2s5Rpls = 29118;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib *pObject = dynamic_cast<const sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc != pObject->sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc)
		{
			return false;
		}
		if (sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.size() != pObject->sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.size(); i++)
		{
			if (sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl[i] != pObject->sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl[i])
			{
				return false;
			}
		}
		if (sbt_4 != pObject->sbt_4)
		{
			return false;
		}
		if (sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU != pObject->sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU)
		{
			return false;
		}
		if (sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN != pObject->sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN)
		{
			return false;
		}
		if (sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024 != pObject->sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024)
		{
			return false;
		}
		if (sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.size() != pObject->sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.size(); i++)
		{
			if (sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi[i] != pObject->sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi[i])
			{
				return false;
			}
		}
		if (sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.size() != pObject->sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.size(); i++)
		{
			if (sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH[i] != pObject->sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH[i])
			{
				return false;
			}
		}
		if (sbt_6.size() != pObject->sbt_6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6.size(); i++)
		{
			if (sbt_6[i] != pObject->sbt_6[i])
			{
				return false;
			}
		}
		if (sbt_ZnUJRfv3IU_gLNDm8Z2PsGC != pObject->sbt_ZnUJRfv3IU_gLNDm8Z2PsGC)
		{
			return false;
		}
		if (sbt_VtH.size() != pObject->sbt_VtH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VtH.size(); i++)
		{
			if (sbt_VtH[i] != pObject->sbt_VtH[i])
			{
				return false;
			}
		}
		if (sbt_DFiBScMjo6IK9izRVMZx1.size() != pObject->sbt_DFiBScMjo6IK9izRVMZx1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DFiBScMjo6IK9izRVMZx1.size(); i++)
		{
			if (sbt_DFiBScMjo6IK9izRVMZx1[i] != pObject->sbt_DFiBScMjo6IK9izRVMZx1[i])
			{
				return false;
			}
		}
		if (sbt_zenUpU5KzbO != pObject->sbt_zenUpU5KzbO)
		{
			return false;
		}
		if (sbt_X1YOwiH40jlZ8MnthlUlRf7.size() != pObject->sbt_X1YOwiH40jlZ8MnthlUlRf7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X1YOwiH40jlZ8MnthlUlRf7.size(); i++)
		{
			if (sbt_X1YOwiH40jlZ8MnthlUlRf7[i] != pObject->sbt_X1YOwiH40jlZ8MnthlUlRf7[i])
			{
				return false;
			}
		}
		if (sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE != pObject->sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE)
		{
			return false;
		}
		if (sbt_kaENraqVKkuwJLHQL06oef3MN.size() != pObject->sbt_kaENraqVKkuwJLHQL06oef3MN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kaENraqVKkuwJLHQL06oef3MN.size(); i++)
		{
			if (sbt_kaENraqVKkuwJLHQL06oef3MN[i] != pObject->sbt_kaENraqVKkuwJLHQL06oef3MN[i])
			{
				return false;
			}
		}
		if (sbt_hvlJTj2s5Rpls != pObject->sbt_hvlJTj2s5Rpls)
		{
			return false;
		}
		if (sbt_03tre.size() != pObject->sbt_03tre.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_03tre.size(); i++)
		{
			if (sbt_03tre[i] != pObject->sbt_03tre[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZnUJRfv3IU_gLNDm8Z2PsGC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZnUJRfv3IU_gLNDm8Z2PsGC = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VtH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VtH.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DFiBScMjo6IK9izRVMZx1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DFiBScMjo6IK9izRVMZx1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zenUpU5KzbO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zenUpU5KzbO = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_X1YOwiH40jlZ8MnthlUlRf7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X1YOwiH40jlZ8MnthlUlRf7.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kaENraqVKkuwJLHQL06oef3MN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kaENraqVKkuwJLHQL06oef3MN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hvlJTj2s5Rpls", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hvlJTj2s5Rpls = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_03tre")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_03tre.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc", (CX::Int64)sbt_40o1RWKQmDIqEYAA0zaORshFoGzcrwTAobc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.begin(); iter != sbt_9jU4W3Q0YSD46GAU9tQiRnMFxc3Pz3r0iTxNZxQZ0lF65P7v3aO5vqvBevl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4", (CX::Int64)sbt_4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU", (CX::Int64)sbt_na7XugTP3ImrBm64kIsV_IYghVtAqhU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN", (CX::Int64)sbt_46NUwbvgHvY2qkHgRdBV5_0CD8idzagP_8jZsk9UmagFwYyhKcSjN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024", (CX::Int64)sbt_eos9CZLmK3yvT2BStYtLXil3Fspe4BIAg69q2a3Fp9PP09YrEjt4fh2E0B024)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.begin(); iter != sbt_bo1IH7ulksoYNLALuaBzb42v_bVDdQGceZbxtR2yr5UFi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.begin(); iter != sbt_Zc1Vaq36E8tyQwO5nbFjgJgOxbL8wtjoyS8SnglFOXH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_6.begin(); iter != sbt_6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZnUJRfv3IU_gLNDm8Z2PsGC", (CX::Int64)sbt_ZnUJRfv3IU_gLNDm8Z2PsGC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VtH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_VtH.begin(); iter != sbt_VtH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DFiBScMjo6IK9izRVMZx1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_DFiBScMjo6IK9izRVMZx1.begin(); iter != sbt_DFiBScMjo6IK9izRVMZx1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zenUpU5KzbO", (CX::Int64)sbt_zenUpU5KzbO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X1YOwiH40jlZ8MnthlUlRf7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_X1YOwiH40jlZ8MnthlUlRf7.begin(); iter != sbt_X1YOwiH40jlZ8MnthlUlRf7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE", (CX::Int64)sbt_3v18A2Bh18kNRcIstn05DHdqWwKqFgE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kaENraqVKkuwJLHQL06oef3MN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_kaENraqVKkuwJLHQL06oef3MN.begin(); iter != sbt_kaENraqVKkuwJLHQL06oef3MN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hvlJTj2s5Rpls", (CX::Int64)sbt_hvlJTj2s5Rpls)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_03tre")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_03tre.begin(); iter != sbt_03tre.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib>::Type sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8IbArray;

