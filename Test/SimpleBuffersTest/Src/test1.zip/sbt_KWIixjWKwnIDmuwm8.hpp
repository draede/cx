
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_KWIixjWKwnIDmuwm8 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_cQThbNT2Zi6gfe78Ont5WMc;
	CX::UInt64 sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe;

	virtual void Reset()
	{
		sbt_cQThbNT2Zi6gfe78Ont5WMc.clear();
		sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe = 9205614950458592222;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KWIixjWKwnIDmuwm8 *pObject = dynamic_cast<const sbt_KWIixjWKwnIDmuwm8 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_cQThbNT2Zi6gfe78Ont5WMc.size() != pObject->sbt_cQThbNT2Zi6gfe78Ont5WMc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cQThbNT2Zi6gfe78Ont5WMc.size(); i++)
		{
			if (sbt_cQThbNT2Zi6gfe78Ont5WMc[i] != pObject->sbt_cQThbNT2Zi6gfe78Ont5WMc[i])
			{
				return false;
			}
		}
		if (sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe != pObject->sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_cQThbNT2Zi6gfe78Ont5WMc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cQThbNT2Zi6gfe78Ont5WMc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_cQThbNT2Zi6gfe78Ont5WMc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_cQThbNT2Zi6gfe78Ont5WMc.begin(); iter != sbt_cQThbNT2Zi6gfe78Ont5WMc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe", (CX::Int64)sbt_ecVLHLDlVQy53Wv0DJSWB9KRwLCQC56VCyTv8nwCL7ocVkhrtVe)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KWIixjWKwnIDmuwm8>::Type sbt_KWIixjWKwnIDmuwm8Array;

