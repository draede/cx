
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp;
	CX::IO::SimpleBuffers::Int64Array sbt_KIGfDwVfuyol9mzW7Re;
	CX::Bool sbt_wwkWKwqnv;
	CX::IO::SimpleBuffers::Int32Array sbt_E56eWA5HUxSWFTS;
	CX::Bool sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C;
	CX::Int64 sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9;
	CX::Int16 sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF;

	virtual void Reset()
	{
		sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp.clear();
		sbt_KIGfDwVfuyol9mzW7Re.clear();
		sbt_wwkWKwqnv = false;
		sbt_E56eWA5HUxSWFTS.clear();
		sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C = false;
		sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9 = 0;
		sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp = "W(<>$S/~U@4aESYce/~28>@-iX9lsxs$q>=^3\"tK";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_KIGfDwVfuyol9mzW7Re.push_back(-6403179100129951216);
		}
		sbt_wwkWKwqnv = false;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_E56eWA5HUxSWFTS.push_back(-1501932246);
		}
		sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C = true;
		sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9 = -5122478374103180680;
		sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF = 23762;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig *pObject = dynamic_cast<const sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp.c_str(), pObject->sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp.c_str()))
		{
			return false;
		}
		if (sbt_KIGfDwVfuyol9mzW7Re.size() != pObject->sbt_KIGfDwVfuyol9mzW7Re.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KIGfDwVfuyol9mzW7Re.size(); i++)
		{
			if (sbt_KIGfDwVfuyol9mzW7Re[i] != pObject->sbt_KIGfDwVfuyol9mzW7Re[i])
			{
				return false;
			}
		}
		if (sbt_wwkWKwqnv != pObject->sbt_wwkWKwqnv)
		{
			return false;
		}
		if (sbt_E56eWA5HUxSWFTS.size() != pObject->sbt_E56eWA5HUxSWFTS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E56eWA5HUxSWFTS.size(); i++)
		{
			if (sbt_E56eWA5HUxSWFTS[i] != pObject->sbt_E56eWA5HUxSWFTS[i])
			{
				return false;
			}
		}
		if (sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C != pObject->sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C)
		{
			return false;
		}
		if (sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9 != pObject->sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9)
		{
			return false;
		}
		if (sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF != pObject->sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp", &sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KIGfDwVfuyol9mzW7Re")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KIGfDwVfuyol9mzW7Re.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_wwkWKwqnv", &sbt_wwkWKwqnv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E56eWA5HUxSWFTS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E56eWA5HUxSWFTS.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C", &sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF = (CX::Int16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp", sbt_OLW6970AtYyRlH9rBMl7KDTnPB_XdVgEIZh2sAWJTxgbQmnhWL5w_IVJHeF7iJp.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KIGfDwVfuyol9mzW7Re")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_KIGfDwVfuyol9mzW7Re.begin(); iter != sbt_KIGfDwVfuyol9mzW7Re.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_wwkWKwqnv", sbt_wwkWKwqnv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E56eWA5HUxSWFTS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_E56eWA5HUxSWFTS.begin(); iter != sbt_E56eWA5HUxSWFTS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C", sbt_AMziUI2Vw92XQbKA2KXei3wk7beeZFT3zLE0jar2Y7jBVx_u4i12C)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9", (CX::Int64)sbt_aPpHPpI32rY8WPzF6x1LBvBJaPYuLdmP4B9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF", (CX::Int64)sbt_LH7CLhj6t_oo2HTBV3aCz_LpADBZF)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig>::Type sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4igArray;

