
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz;

	virtual void Reset()
	{
		sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.push_back(1666332634);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9 *pObject = dynamic_cast<const sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.size() != pObject->sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.size(); i++)
		{
			if (sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz[i] != pObject->sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.begin(); iter != sbt_Sfne8xqWIIhad6HzaMpnRULgXjXe6oo6Nfz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9>::Type sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9Array;

