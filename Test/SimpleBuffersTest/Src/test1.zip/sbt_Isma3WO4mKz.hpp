
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Isma3WO4mKz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_;
	CX::UInt64 sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z;
	CX::Bool sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw;
	CX::Bool sbt_zUSLERGXUUX;
	CX::IO::SimpleBuffers::Int64Array sbt_osPZVhkfxysIChrzADsWUHs;

	virtual void Reset()
	{
		sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.clear();
		sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z = 0;
		sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw = false;
		sbt_zUSLERGXUUX = false;
		sbt_osPZVhkfxysIChrzADsWUHs.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.push_back(1320892405);
		}
		sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z = 212894986287672142;
		sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw = false;
		sbt_zUSLERGXUUX = true;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_osPZVhkfxysIChrzADsWUHs.push_back(7190405236566689712);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Isma3WO4mKz *pObject = dynamic_cast<const sbt_Isma3WO4mKz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.size() != pObject->sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.size(); i++)
		{
			if (sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_[i] != pObject->sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_[i])
			{
				return false;
			}
		}
		if (sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z != pObject->sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z)
		{
			return false;
		}
		if (sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw != pObject->sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw)
		{
			return false;
		}
		if (sbt_zUSLERGXUUX != pObject->sbt_zUSLERGXUUX)
		{
			return false;
		}
		if (sbt_osPZVhkfxysIChrzADsWUHs.size() != pObject->sbt_osPZVhkfxysIChrzADsWUHs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_osPZVhkfxysIChrzADsWUHs.size(); i++)
		{
			if (sbt_osPZVhkfxysIChrzADsWUHs[i] != pObject->sbt_osPZVhkfxysIChrzADsWUHs[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw", &sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_zUSLERGXUUX", &sbt_zUSLERGXUUX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_osPZVhkfxysIChrzADsWUHs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_osPZVhkfxysIChrzADsWUHs.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.begin(); iter != sbt_lxeYjeuRkKQSh2RovmtqXYo3HFs5SHPEpt_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z", (CX::Int64)sbt_phwY9kX7EzfiRsdQv4gvvtLE5vh7Ux99Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw", sbt_jnYAtix2sc0v7_gsD2JlmaTXBRyLmAOtBdzou1Cb9ljV17_ohsDaw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_zUSLERGXUUX", sbt_zUSLERGXUUX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_osPZVhkfxysIChrzADsWUHs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_osPZVhkfxysIChrzADsWUHs.begin(); iter != sbt_osPZVhkfxysIChrzADsWUHs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Isma3WO4mKz>::Type sbt_Isma3WO4mKzArray;

