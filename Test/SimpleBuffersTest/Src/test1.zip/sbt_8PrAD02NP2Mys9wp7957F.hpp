
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_8PrAD02NP2Mys9wp7957F : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M;
	CX::UInt64 sbt_bgBQLUH2Rntlg33H5L9panGkDzX;
	CX::IO::SimpleBuffers::UInt32Array sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ;
	CX::IO::SimpleBuffers::UInt8Array sbt_NaPvlpS;
	CX::UInt64 sbt_LNMJY2dKX8CdWIlku;
	CX::IO::SimpleBuffers::Int32Array sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5;
	CX::UInt32 sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP;
	CX::Bool sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe;
	CX::IO::SimpleBuffers::UInt8Array sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D;
	CX::IO::SimpleBuffers::StringArray sbt_TMK2YcA56LV8o2a1pNjHYbsWP;
	CX::Int8 sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef;
	CX::IO::SimpleBuffers::UInt32Array sbt_i3iSPldo0;
	CX::IO::SimpleBuffers::UInt8Array sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy;
	CX::UInt16 sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ;
	CX::IO::SimpleBuffers::Int16Array sbt_elopsgZFjezef34mg0xUPPfAC8xle;
	CX::Int16 sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo;
	CX::Int16 sbt_S_TYk6zGpgI4KI8zvpUp1xn;
	CX::Bool sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG;
	CX::IO::SimpleBuffers::UInt32Array sbt_LgVccTUhr0Dk2_c;
	CX::UInt8 sbt_VVPrAh1aYZA6_7UOP5M7u;
	CX::IO::SimpleBuffers::UInt64Array sbt_O2r;
	CX::IO::SimpleBuffers::UInt8Array sbt_MtOo09qss52CrlpPp;
	CX::IO::SimpleBuffers::UInt32Array sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan;
	CX::Int16 sbt_GFVOYjXXZdD7SJjtN;
	CX::UInt32 sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu;
	CX::IO::SimpleBuffers::Int8Array sbt_A;
	CX::UInt32 sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph;

	virtual void Reset()
	{
		sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.clear();
		sbt_bgBQLUH2Rntlg33H5L9panGkDzX = 0;
		sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.clear();
		sbt_NaPvlpS.clear();
		sbt_LNMJY2dKX8CdWIlku = 0;
		sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.clear();
		sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP = 0;
		sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe = false;
		sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.clear();
		sbt_TMK2YcA56LV8o2a1pNjHYbsWP.clear();
		sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef = 0;
		sbt_i3iSPldo0.clear();
		sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.clear();
		sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ = 0;
		sbt_elopsgZFjezef34mg0xUPPfAC8xle.clear();
		sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo = 0;
		sbt_S_TYk6zGpgI4KI8zvpUp1xn = 0;
		sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG = false;
		sbt_LgVccTUhr0Dk2_c.clear();
		sbt_VVPrAh1aYZA6_7UOP5M7u = 0;
		sbt_O2r.clear();
		sbt_MtOo09qss52CrlpPp.clear();
		sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.clear();
		sbt_GFVOYjXXZdD7SJjtN = 0;
		sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu = 0;
		sbt_A.clear();
		sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.push_back(true);
		}
		sbt_bgBQLUH2Rntlg33H5L9panGkDzX = 4156754117690799634;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.push_back(2535161222);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_NaPvlpS.push_back(123);
		}
		sbt_LNMJY2dKX8CdWIlku = 7054839453381199338;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.push_back(1410686726);
		}
		sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP = 3741938958;
		sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe = true;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.push_back(142);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_TMK2YcA56LV8o2a1pNjHYbsWP.push_back("6uDml]CB:t*Ns5jik^P?,p=T~X'W?I>364l|`OvMTI9m0fNkq#*");
		}
		sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef = 19;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_i3iSPldo0.push_back(1853590084);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.push_back(51);
		}
		sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ = 9300;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_elopsgZFjezef34mg0xUPPfAC8xle.push_back(-8163);
		}
		sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo = 7779;
		sbt_S_TYk6zGpgI4KI8zvpUp1xn = 24870;
		sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG = true;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_LgVccTUhr0Dk2_c.push_back(3277388622);
		}
		sbt_VVPrAh1aYZA6_7UOP5M7u = 106;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_O2r.push_back(4029194900380517786);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_MtOo09qss52CrlpPp.push_back(141);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.push_back(1275259869);
		}
		sbt_GFVOYjXXZdD7SJjtN = -22379;
		sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu = 2285453876;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_A.push_back(87);
		}
		sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph = 1651508787;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8PrAD02NP2Mys9wp7957F *pObject = dynamic_cast<const sbt_8PrAD02NP2Mys9wp7957F *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.size() != pObject->sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.size(); i++)
		{
			if (sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M[i] != pObject->sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M[i])
			{
				return false;
			}
		}
		if (sbt_bgBQLUH2Rntlg33H5L9panGkDzX != pObject->sbt_bgBQLUH2Rntlg33H5L9panGkDzX)
		{
			return false;
		}
		if (sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.size() != pObject->sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.size(); i++)
		{
			if (sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ[i] != pObject->sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ[i])
			{
				return false;
			}
		}
		if (sbt_NaPvlpS.size() != pObject->sbt_NaPvlpS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NaPvlpS.size(); i++)
		{
			if (sbt_NaPvlpS[i] != pObject->sbt_NaPvlpS[i])
			{
				return false;
			}
		}
		if (sbt_LNMJY2dKX8CdWIlku != pObject->sbt_LNMJY2dKX8CdWIlku)
		{
			return false;
		}
		if (sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.size() != pObject->sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.size(); i++)
		{
			if (sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5[i] != pObject->sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5[i])
			{
				return false;
			}
		}
		if (sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP != pObject->sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP)
		{
			return false;
		}
		if (sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe != pObject->sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe)
		{
			return false;
		}
		if (sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.size() != pObject->sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.size(); i++)
		{
			if (sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D[i] != pObject->sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D[i])
			{
				return false;
			}
		}
		if (sbt_TMK2YcA56LV8o2a1pNjHYbsWP.size() != pObject->sbt_TMK2YcA56LV8o2a1pNjHYbsWP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TMK2YcA56LV8o2a1pNjHYbsWP.size(); i++)
		{
			if (0 != cx_strcmp(sbt_TMK2YcA56LV8o2a1pNjHYbsWP[i].c_str(), pObject->sbt_TMK2YcA56LV8o2a1pNjHYbsWP[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef != pObject->sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef)
		{
			return false;
		}
		if (sbt_i3iSPldo0.size() != pObject->sbt_i3iSPldo0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i3iSPldo0.size(); i++)
		{
			if (sbt_i3iSPldo0[i] != pObject->sbt_i3iSPldo0[i])
			{
				return false;
			}
		}
		if (sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.size() != pObject->sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.size(); i++)
		{
			if (sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy[i] != pObject->sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy[i])
			{
				return false;
			}
		}
		if (sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ != pObject->sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ)
		{
			return false;
		}
		if (sbt_elopsgZFjezef34mg0xUPPfAC8xle.size() != pObject->sbt_elopsgZFjezef34mg0xUPPfAC8xle.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_elopsgZFjezef34mg0xUPPfAC8xle.size(); i++)
		{
			if (sbt_elopsgZFjezef34mg0xUPPfAC8xle[i] != pObject->sbt_elopsgZFjezef34mg0xUPPfAC8xle[i])
			{
				return false;
			}
		}
		if (sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo != pObject->sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo)
		{
			return false;
		}
		if (sbt_S_TYk6zGpgI4KI8zvpUp1xn != pObject->sbt_S_TYk6zGpgI4KI8zvpUp1xn)
		{
			return false;
		}
		if (sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG != pObject->sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG)
		{
			return false;
		}
		if (sbt_LgVccTUhr0Dk2_c.size() != pObject->sbt_LgVccTUhr0Dk2_c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LgVccTUhr0Dk2_c.size(); i++)
		{
			if (sbt_LgVccTUhr0Dk2_c[i] != pObject->sbt_LgVccTUhr0Dk2_c[i])
			{
				return false;
			}
		}
		if (sbt_VVPrAh1aYZA6_7UOP5M7u != pObject->sbt_VVPrAh1aYZA6_7UOP5M7u)
		{
			return false;
		}
		if (sbt_O2r.size() != pObject->sbt_O2r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O2r.size(); i++)
		{
			if (sbt_O2r[i] != pObject->sbt_O2r[i])
			{
				return false;
			}
		}
		if (sbt_MtOo09qss52CrlpPp.size() != pObject->sbt_MtOo09qss52CrlpPp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MtOo09qss52CrlpPp.size(); i++)
		{
			if (sbt_MtOo09qss52CrlpPp[i] != pObject->sbt_MtOo09qss52CrlpPp[i])
			{
				return false;
			}
		}
		if (sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.size() != pObject->sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.size(); i++)
		{
			if (sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan[i] != pObject->sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan[i])
			{
				return false;
			}
		}
		if (sbt_GFVOYjXXZdD7SJjtN != pObject->sbt_GFVOYjXXZdD7SJjtN)
		{
			return false;
		}
		if (sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu != pObject->sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu)
		{
			return false;
		}
		if (sbt_A.size() != pObject->sbt_A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A.size(); i++)
		{
			if (sbt_A[i] != pObject->sbt_A[i])
			{
				return false;
			}
		}
		if (sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph != pObject->sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bgBQLUH2Rntlg33H5L9panGkDzX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bgBQLUH2Rntlg33H5L9panGkDzX = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NaPvlpS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NaPvlpS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LNMJY2dKX8CdWIlku", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LNMJY2dKX8CdWIlku = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe", &sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TMK2YcA56LV8o2a1pNjHYbsWP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TMK2YcA56LV8o2a1pNjHYbsWP.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_i3iSPldo0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i3iSPldo0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_elopsgZFjezef34mg0xUPPfAC8xle")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_elopsgZFjezef34mg0xUPPfAC8xle.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_S_TYk6zGpgI4KI8zvpUp1xn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S_TYk6zGpgI4KI8zvpUp1xn = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG", &sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LgVccTUhr0Dk2_c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LgVccTUhr0Dk2_c.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VVPrAh1aYZA6_7UOP5M7u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VVPrAh1aYZA6_7UOP5M7u = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_O2r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O2r.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MtOo09qss52CrlpPp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MtOo09qss52CrlpPp.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GFVOYjXXZdD7SJjtN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GFVOYjXXZdD7SJjtN = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.begin(); iter != sbt_J_HUDTLTPX6LJzXNaRZn3XaXGIatsW5qDdQavwx9koebh8TGw2M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bgBQLUH2Rntlg33H5L9panGkDzX", (CX::Int64)sbt_bgBQLUH2Rntlg33H5L9panGkDzX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.begin(); iter != sbt_Nsq9ZUNh94NPdb_TuHAI5UR0k5zccHk6nU6JZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NaPvlpS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_NaPvlpS.begin(); iter != sbt_NaPvlpS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LNMJY2dKX8CdWIlku", (CX::Int64)sbt_LNMJY2dKX8CdWIlku)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.begin(); iter != sbt_qAUeNd2HNlgqWQ4rBjc19gKhrQOJpWt6GZEyK0uSHg5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP", (CX::Int64)sbt_pW9D4GdmTrAHOSFKaMRYE4e6HuxOSalgv207LPWUMaNFAICGP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe", sbt_vGD97LWyImkmRGZL2dzQ3wRt8cVyPk2r02ZzFLqZdHe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.begin(); iter != sbt_Yre79qULBFHwPtmt4OUolQX3lXZ67W3ZduzKoYETv21GDD7zECV7D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TMK2YcA56LV8o2a1pNjHYbsWP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_TMK2YcA56LV8o2a1pNjHYbsWP.begin(); iter != sbt_TMK2YcA56LV8o2a1pNjHYbsWP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef", (CX::Int64)sbt_Rlg8EY0ggKNbpfAr0O9xsxdTLRjdTbPDZmoSt4IrmgoKYtYpZw2RURJef)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i3iSPldo0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_i3iSPldo0.begin(); iter != sbt_i3iSPldo0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.begin(); iter != sbt_kp9BjJjFufyOkAo1zt0L6Ovxc0VwcDhZZTy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ", (CX::Int64)sbt_mLY69IesYWDzNpXBoX4kOxy8ZApnqZQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_elopsgZFjezef34mg0xUPPfAC8xle")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_elopsgZFjezef34mg0xUPPfAC8xle.begin(); iter != sbt_elopsgZFjezef34mg0xUPPfAC8xle.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo", (CX::Int64)sbt_sCaMLJ2rz1ywNRVByB7D5ANS5WkLSMguN9HRwu5rOak3T7rcxEmNu_MR86gXo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S_TYk6zGpgI4KI8zvpUp1xn", (CX::Int64)sbt_S_TYk6zGpgI4KI8zvpUp1xn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG", sbt_f7oiFPpbS8NJugWmYkiO82LtYIonk4y408aSbVaW4DUZpKFWvEIKoCuwG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LgVccTUhr0Dk2_c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_LgVccTUhr0Dk2_c.begin(); iter != sbt_LgVccTUhr0Dk2_c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VVPrAh1aYZA6_7UOP5M7u", (CX::Int64)sbt_VVPrAh1aYZA6_7UOP5M7u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O2r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_O2r.begin(); iter != sbt_O2r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MtOo09qss52CrlpPp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_MtOo09qss52CrlpPp.begin(); iter != sbt_MtOo09qss52CrlpPp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.begin(); iter != sbt_ywapNfPLQgxvj5419e6XD4Du3MwkyKc_xefP6zW7Jd5Tj75FGHMUCOEIlRpan.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GFVOYjXXZdD7SJjtN", (CX::Int64)sbt_GFVOYjXXZdD7SJjtN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu", (CX::Int64)sbt_xZ55nyjYmiy66yewkLMPO55GcePTWzfHStu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_A.begin(); iter != sbt_A.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph", (CX::Int64)sbt_zImpm363Hci0X0_DwgdBBeGY9PCLsMd3cgfL0gIph)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8PrAD02NP2Mys9wp7957F>::Type sbt_8PrAD02NP2Mys9wp7957FArray;

