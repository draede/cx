
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_YC56TP18W.hpp"


class sbt_EZ9 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa;
	CX::Int32 sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t;
	CX::Int8 sbt_OjuStIJ;
	CX::String sbt_rwloqPztVj33pD9ruXM;
	CX::IO::SimpleBuffers::Int32Array sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I;
	CX::String sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr;
	CX::IO::SimpleBuffers::DoubleArray sbt_VpM3DJrQB0AG6T_;
	CX::IO::SimpleBuffers::UInt64Array sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa;
	CX::Int64 sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4;
	CX::IO::SimpleBuffers::WStringArray sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI;
	CX::IO::SimpleBuffers::Int32Array sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo;
	sbt_YC56TP18WArray sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3;

	virtual void Reset()
	{
		sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa = 0;
		sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t = 0;
		sbt_OjuStIJ = 0;
		sbt_rwloqPztVj33pD9ruXM.clear();
		sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.clear();
		sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr.clear();
		sbt_VpM3DJrQB0AG6T_.clear();
		sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.clear();
		sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4 = 0;
		sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.clear();
		sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.clear();
		sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa = 645949159;
		sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t = 392587748;
		sbt_OjuStIJ = -60;
		sbt_rwloqPztVj33pD9ruXM = "D}OEGZ!;wMy\"^LM~";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.push_back(-1191524361);
		}
		sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr = "DkglZJr&tQ8Mq2Uzp`%";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_VpM3DJrQB0AG6T_.push_back(0.166581);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.push_back(4913359271656785642);
		}
		sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4 = -6320894000000781558;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.push_back(-1231036396);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_YC56TP18W v;

			v.SetupWithSomeValues();
			sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_EZ9 *pObject = dynamic_cast<const sbt_EZ9 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa != pObject->sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa)
		{
			return false;
		}
		if (sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t != pObject->sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t)
		{
			return false;
		}
		if (sbt_OjuStIJ != pObject->sbt_OjuStIJ)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_rwloqPztVj33pD9ruXM.c_str(), pObject->sbt_rwloqPztVj33pD9ruXM.c_str()))
		{
			return false;
		}
		if (sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.size() != pObject->sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.size(); i++)
		{
			if (sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I[i] != pObject->sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr.c_str(), pObject->sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr.c_str()))
		{
			return false;
		}
		if (sbt_VpM3DJrQB0AG6T_.size() != pObject->sbt_VpM3DJrQB0AG6T_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VpM3DJrQB0AG6T_.size(); i++)
		{
			if (sbt_VpM3DJrQB0AG6T_[i] != pObject->sbt_VpM3DJrQB0AG6T_[i])
			{
				return false;
			}
		}
		if (sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.size() != pObject->sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.size(); i++)
		{
			if (sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa[i] != pObject->sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa[i])
			{
				return false;
			}
		}
		if (sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4 != pObject->sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4)
		{
			return false;
		}
		if (sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.size() != pObject->sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI[i].c_str(), pObject->sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.size() != pObject->sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.size(); i++)
		{
			if (sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo[i] != pObject->sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo[i])
			{
				return false;
			}
		}
		if (sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.size() != pObject->sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.size(); i++)
		{
			if (!sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3[i].Compare(&pObject->sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_OjuStIJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OjuStIJ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_rwloqPztVj33pD9ruXM", &sbt_rwloqPztVj33pD9ruXM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr", &sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VpM3DJrQB0AG6T_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VpM3DJrQB0AG6T_.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_YC56TP18W tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa", (CX::Int64)sbt_I6qxfKohTkBfQIkjbgzbM8kZLMa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t", (CX::Int64)sbt_3ILXYjN9cU3s1eY_LtnvyyvxcyylUuCJjKNaizy0t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OjuStIJ", (CX::Int64)sbt_OjuStIJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_rwloqPztVj33pD9ruXM", sbt_rwloqPztVj33pD9ruXM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.begin(); iter != sbt_PLYyWAmoJihrQNER0IuIzOnlYeZ3jF_JnCRJzAlVApoeLOEpsRChza72k2I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr", sbt_gkMnqEFIv_72S6sWzNUOFcLOWWDLUY_lcmtOKLpZjAJ_zaEmr.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VpM3DJrQB0AG6T_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_VpM3DJrQB0AG6T_.begin(); iter != sbt_VpM3DJrQB0AG6T_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.begin(); iter != sbt__uRHEc2R1BopKWoZyfoq4vpl1asPigIz_zYHrlcHk0Hr0e9cMCaXbcomXXCfa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4", (CX::Int64)sbt_gvpOauQumu38Bh6LLxyCAY6HDIkVK5g5gCHSmuwS4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.begin(); iter != sbt_BiAmjaZnuWkV_FBCkJncO7DVIpe9r6ty8mypmu5u_4iJiCI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.begin(); iter != sbt_WvXfUXoXjIEAsDxqoR8ZtBSkeUYOvgTV94Dn57zK_LUjEAo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3")).IsNOK())
		{
			return status;
		}
		for (sbt_YC56TP18WArray::const_iterator iter = sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.begin(); iter != sbt_IDNpkNqzmRHjAKwz5SrMKMbVj0LpEDOiijs3sq8IcfBIQJ3.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_EZ9>::Type sbt_EZ9Array;

