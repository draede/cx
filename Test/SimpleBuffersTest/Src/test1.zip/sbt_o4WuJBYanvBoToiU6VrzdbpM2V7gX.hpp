
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX;
	CX::UInt64 sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl;
	CX::IO::SimpleBuffers::UInt32Array sbt_lD6jNOUNsfzpXDZ9GezJ1;
	CX::String sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p;
	CX::IO::SimpleBuffers::Int32Array sbt_P;
	CX::IO::SimpleBuffers::Int16Array sbt_2EycPrutGdO;
	CX::Int32 sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM;
	CX::Int32 sbt_1i1xUjoXOuozw6HcW861el9vP4xyM;
	CX::IO::SimpleBuffers::UInt16Array sbt_howPwOtFVJu53rpkuENRe;
	CX::IO::SimpleBuffers::StringArray sbt_tq7_SXD1L7yCRPJIb;
	CX::Int16 sbt_IURre7VtNqBi5jRgUH2mnsY;
	CX::IO::SimpleBuffers::Int16Array sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT;
	CX::Int64 sbt_pry;
	CX::IO::SimpleBuffers::Int64Array sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp;
	CX::IO::SimpleBuffers::Int8Array sbt_R;
	CX::UInt32 sbt_77bFYyD;
	CX::UInt32 sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_;
	CX::String sbt_t9aWJ1AkwLThfY5WAe7gHD5;
	CX::String sbt_xlz4L;
	CX::IO::SimpleBuffers::StringArray sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH;

	virtual void Reset()
	{
		sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX = 0;
		sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl = 0;
		sbt_lD6jNOUNsfzpXDZ9GezJ1.clear();
		sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p.clear();
		sbt_P.clear();
		sbt_2EycPrutGdO.clear();
		sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM = 0;
		sbt_1i1xUjoXOuozw6HcW861el9vP4xyM = 0;
		sbt_howPwOtFVJu53rpkuENRe.clear();
		sbt_tq7_SXD1L7yCRPJIb.clear();
		sbt_IURre7VtNqBi5jRgUH2mnsY = 0;
		sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.clear();
		sbt_pry = 0;
		sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.clear();
		sbt_R.clear();
		sbt_77bFYyD = 0;
		sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_ = 0;
		sbt_t9aWJ1AkwLThfY5WAe7gHD5.clear();
		sbt_xlz4L.clear();
		sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX = 962289249212047800;
		sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl = 16477593014402917822;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lD6jNOUNsfzpXDZ9GezJ1.push_back(3739506508);
		}
		sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p = "kZUIbp75ZL-3H2`R+]o1C?u.^G.n";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_P.push_back(-369704057);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_2EycPrutGdO.push_back(-14131);
		}
		sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM = 1316622095;
		sbt_1i1xUjoXOuozw6HcW861el9vP4xyM = -1677086110;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_howPwOtFVJu53rpkuENRe.push_back(61058);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_tq7_SXD1L7yCRPJIb.push_back("M%R0=;'7&B]ir{^6'oxh!Gc4\\i-0");
		}
		sbt_IURre7VtNqBi5jRgUH2mnsY = 9993;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.push_back(-8976);
		}
		sbt_pry = -8816806145137397760;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_R.push_back(38);
		}
		sbt_77bFYyD = 289931876;
		sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_ = 1671925231;
		sbt_t9aWJ1AkwLThfY5WAe7gHD5 = "9.`/q-,F`*";
		sbt_xlz4L = "~f/xZ,6$HbPJslCK'm.9@tyvrasH;i_U+3iI?b0&eqEv\\>";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.push_back(">281BOqm)bcOD7m1\"s-y!P8daVP|vS4t#vC4tX.Gt}&;B>");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX *pObject = dynamic_cast<const sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX != pObject->sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX)
		{
			return false;
		}
		if (sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl != pObject->sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl)
		{
			return false;
		}
		if (sbt_lD6jNOUNsfzpXDZ9GezJ1.size() != pObject->sbt_lD6jNOUNsfzpXDZ9GezJ1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lD6jNOUNsfzpXDZ9GezJ1.size(); i++)
		{
			if (sbt_lD6jNOUNsfzpXDZ9GezJ1[i] != pObject->sbt_lD6jNOUNsfzpXDZ9GezJ1[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p.c_str(), pObject->sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p.c_str()))
		{
			return false;
		}
		if (sbt_P.size() != pObject->sbt_P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P.size(); i++)
		{
			if (sbt_P[i] != pObject->sbt_P[i])
			{
				return false;
			}
		}
		if (sbt_2EycPrutGdO.size() != pObject->sbt_2EycPrutGdO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2EycPrutGdO.size(); i++)
		{
			if (sbt_2EycPrutGdO[i] != pObject->sbt_2EycPrutGdO[i])
			{
				return false;
			}
		}
		if (sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM != pObject->sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM)
		{
			return false;
		}
		if (sbt_1i1xUjoXOuozw6HcW861el9vP4xyM != pObject->sbt_1i1xUjoXOuozw6HcW861el9vP4xyM)
		{
			return false;
		}
		if (sbt_howPwOtFVJu53rpkuENRe.size() != pObject->sbt_howPwOtFVJu53rpkuENRe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_howPwOtFVJu53rpkuENRe.size(); i++)
		{
			if (sbt_howPwOtFVJu53rpkuENRe[i] != pObject->sbt_howPwOtFVJu53rpkuENRe[i])
			{
				return false;
			}
		}
		if (sbt_tq7_SXD1L7yCRPJIb.size() != pObject->sbt_tq7_SXD1L7yCRPJIb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tq7_SXD1L7yCRPJIb.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tq7_SXD1L7yCRPJIb[i].c_str(), pObject->sbt_tq7_SXD1L7yCRPJIb[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_IURre7VtNqBi5jRgUH2mnsY != pObject->sbt_IURre7VtNqBi5jRgUH2mnsY)
		{
			return false;
		}
		if (sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.size() != pObject->sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.size(); i++)
		{
			if (sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT[i] != pObject->sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT[i])
			{
				return false;
			}
		}
		if (sbt_pry != pObject->sbt_pry)
		{
			return false;
		}
		if (sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.size() != pObject->sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.size(); i++)
		{
			if (sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp[i] != pObject->sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp[i])
			{
				return false;
			}
		}
		if (sbt_R.size() != pObject->sbt_R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R.size(); i++)
		{
			if (sbt_R[i] != pObject->sbt_R[i])
			{
				return false;
			}
		}
		if (sbt_77bFYyD != pObject->sbt_77bFYyD)
		{
			return false;
		}
		if (sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_ != pObject->sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_t9aWJ1AkwLThfY5WAe7gHD5.c_str(), pObject->sbt_t9aWJ1AkwLThfY5WAe7gHD5.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_xlz4L.c_str(), pObject->sbt_xlz4L.c_str()))
		{
			return false;
		}
		if (sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.size() != pObject->sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.size(); i++)
		{
			if (0 != cx_strcmp(sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH[i].c_str(), pObject->sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lD6jNOUNsfzpXDZ9GezJ1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lD6jNOUNsfzpXDZ9GezJ1.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p", &sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2EycPrutGdO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2EycPrutGdO.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1i1xUjoXOuozw6HcW861el9vP4xyM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1i1xUjoXOuozw6HcW861el9vP4xyM = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_howPwOtFVJu53rpkuENRe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_howPwOtFVJu53rpkuENRe.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tq7_SXD1L7yCRPJIb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tq7_SXD1L7yCRPJIb.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IURre7VtNqBi5jRgUH2mnsY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IURre7VtNqBi5jRgUH2mnsY = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pry", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pry = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_77bFYyD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_77bFYyD = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_t9aWJ1AkwLThfY5WAe7gHD5", &sbt_t9aWJ1AkwLThfY5WAe7gHD5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_xlz4L", &sbt_xlz4L)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX", (CX::Int64)sbt_UpvWCaHoZi6TdXSh5QFhI3RmMdX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl", (CX::Int64)sbt_6X7smG0Q20xiYc8eroUyxanwBy92mIRmSHvH66xJ3E6rKT_4cTs91ck4nUNHl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lD6jNOUNsfzpXDZ9GezJ1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lD6jNOUNsfzpXDZ9GezJ1.begin(); iter != sbt_lD6jNOUNsfzpXDZ9GezJ1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p", sbt_iP02QOiiS3JVSMmKrk7llZob8Ip5wGRIr3p.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_P.begin(); iter != sbt_P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2EycPrutGdO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_2EycPrutGdO.begin(); iter != sbt_2EycPrutGdO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM", (CX::Int64)sbt_nyXefq3PIs4NnPWl84bVUJO4CKxPHL0myZLJSZkG20ctgvM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1i1xUjoXOuozw6HcW861el9vP4xyM", (CX::Int64)sbt_1i1xUjoXOuozw6HcW861el9vP4xyM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_howPwOtFVJu53rpkuENRe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_howPwOtFVJu53rpkuENRe.begin(); iter != sbt_howPwOtFVJu53rpkuENRe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tq7_SXD1L7yCRPJIb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tq7_SXD1L7yCRPJIb.begin(); iter != sbt_tq7_SXD1L7yCRPJIb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IURre7VtNqBi5jRgUH2mnsY", (CX::Int64)sbt_IURre7VtNqBi5jRgUH2mnsY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.begin(); iter != sbt_ivGpZCj9_W58Lc6tAvpRuZc9oHT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pry", (CX::Int64)sbt_pry)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.begin(); iter != sbt_WE31n9LTGXTNbj2nE5JznJogllkiCpklSP0jrBwxTXwG6PzOJxnjvgPy_NrN0Rp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_R.begin(); iter != sbt_R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_77bFYyD", (CX::Int64)sbt_77bFYyD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_", (CX::Int64)sbt_QuqhukjFwBmwDV5MUw15jFSyEfYy01aVWOFrvXqeiT_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_t9aWJ1AkwLThfY5WAe7gHD5", sbt_t9aWJ1AkwLThfY5WAe7gHD5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_xlz4L", sbt_xlz4L.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.begin(); iter != sbt_28KASqbzIXwNEIUZ64W5YvxXwp8ocw39WfQu05aCH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX>::Type sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gXArray;

