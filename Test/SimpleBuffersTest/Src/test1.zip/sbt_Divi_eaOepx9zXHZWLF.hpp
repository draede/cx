
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U.hpp"


class sbt_Divi_eaOepx9zXHZWLF : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk;
	CX::IO::SimpleBuffers::UInt64Array sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38;
	CX::UInt16 sbt_rDxgs3pNOSECdWOdOj5Kb;
	CX::IO::SimpleBuffers::UInt64Array sbt_XPSlWabBM;
	CX::Float sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk;
	CX::String sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw;
	CX::IO::SimpleBuffers::Int8Array sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk;
	CX::WString sbt_2la67mJ91;
	CX::IO::SimpleBuffers::Int32Array sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr;
	CX::Int8 sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO;
	sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U sbt_ENwmCiWtD;

	virtual void Reset()
	{
		sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk = 0;
		sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.clear();
		sbt_rDxgs3pNOSECdWOdOj5Kb = 0;
		sbt_XPSlWabBM.clear();
		sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk = 0.0f;
		sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw.clear();
		sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.clear();
		sbt_2la67mJ91.clear();
		sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.clear();
		sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO = 0;
		sbt_ENwmCiWtD.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk = -30860;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.push_back(14847323553516091814);
		}
		sbt_rDxgs3pNOSECdWOdOj5Kb = 8531;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_XPSlWabBM.push_back(498832736412253712);
		}
		sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk = 0.046819f;
		sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw = "dI(5<87+y|l$,5/An~!LMR'`au]k_/RZd*6IiSKRyjo9L+A%s@@JF\"4k}`=..t{o";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.push_back(-14);
		}
		sbt_2la67mJ91 = L"d{\"qa}8U@*$O(LaT@^('jG^|u-@&XL+bIep";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.push_back(1284053216);
		}
		sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO = -57;
		sbt_ENwmCiWtD.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Divi_eaOepx9zXHZWLF *pObject = dynamic_cast<const sbt_Divi_eaOepx9zXHZWLF *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk != pObject->sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk)
		{
			return false;
		}
		if (sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.size() != pObject->sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.size(); i++)
		{
			if (sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38[i] != pObject->sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38[i])
			{
				return false;
			}
		}
		if (sbt_rDxgs3pNOSECdWOdOj5Kb != pObject->sbt_rDxgs3pNOSECdWOdOj5Kb)
		{
			return false;
		}
		if (sbt_XPSlWabBM.size() != pObject->sbt_XPSlWabBM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XPSlWabBM.size(); i++)
		{
			if (sbt_XPSlWabBM[i] != pObject->sbt_XPSlWabBM[i])
			{
				return false;
			}
		}
		if (sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk != pObject->sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw.c_str(), pObject->sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw.c_str()))
		{
			return false;
		}
		if (sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.size() != pObject->sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.size(); i++)
		{
			if (sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk[i] != pObject->sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_2la67mJ91.c_str(), pObject->sbt_2la67mJ91.c_str()))
		{
			return false;
		}
		if (sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.size() != pObject->sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.size(); i++)
		{
			if (sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr[i] != pObject->sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr[i])
			{
				return false;
			}
		}
		if (sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO != pObject->sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO)
		{
			return false;
		}
		if (!sbt_ENwmCiWtD.Compare(&pObject->sbt_ENwmCiWtD))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rDxgs3pNOSECdWOdOj5Kb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rDxgs3pNOSECdWOdOj5Kb = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XPSlWabBM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XPSlWabBM.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectString("sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw", &sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_2la67mJ91", &sbt_2la67mJ91)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_ENwmCiWtD")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ENwmCiWtD.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk", (CX::Int64)sbt_RV_n4MwyjSx9ivuhowF_FYGYHYxTLLkfn8lvQUEgghvws3jrk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.begin(); iter != sbt_NmnSmEYXlXRmyLytKf5AIc0eknu38.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rDxgs3pNOSECdWOdOj5Kb", (CX::Int64)sbt_rDxgs3pNOSECdWOdOj5Kb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XPSlWabBM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_XPSlWabBM.begin(); iter != sbt_XPSlWabBM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk", (CX::Double)sbt_5F2QLPrrb3HSq0byUta7HPaN9gK5PlUBGQohTvkizBJnk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw", sbt_Tuh6NJ9nSUnbR_dgaISLn2FfaJLpw.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.begin(); iter != sbt_ti9Fn7XkJ86ZusWBJgASQLf2QTnFvi255DpfS8l8tPvcm91h3po0dAopk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_2la67mJ91", sbt_2la67mJ91.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.begin(); iter != sbt_VfDSrwHC8dfZgQNvc1y_XbGUlUTLXHCE4SopzufaIykLjTr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO", (CX::Int64)sbt_SF6iDgYXdsRYBnc0KHwhnU8BYnRDwIsoOpsAqIRRaYIRtJV9cCO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_ENwmCiWtD")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ENwmCiWtD.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Divi_eaOepx9zXHZWLF>::Type sbt_Divi_eaOepx9zXHZWLFArray;

