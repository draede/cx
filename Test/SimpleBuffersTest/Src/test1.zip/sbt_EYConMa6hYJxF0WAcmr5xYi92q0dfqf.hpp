
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8;
	CX::IO::SimpleBuffers::BoolArray sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV;
	CX::Int32 sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj;
	CX::IO::SimpleBuffers::UInt64Array sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC;
	CX::UInt8 sbt_refGYxlDHdCx7zkDTNVQ_;
	CX::UInt64 sbt_02qsgrQbtxD9giYl9Z5;
	CX::IO::SimpleBuffers::UInt8Array sbt_LG8hpaFBWlcjjWyMe2QbbrHfu;
	CX::IO::SimpleBuffers::UInt32Array sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy;
	CX::IO::SimpleBuffers::Int32Array sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ;
	CX::IO::SimpleBuffers::Int8Array sbt_TUu;
	CX::String sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D;
	CX::IO::SimpleBuffers::Int32Array sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg;
	CX::UInt32 sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW;
	CX::IO::SimpleBuffers::StringArray sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7;
	CX::IO::SimpleBuffers::UInt16Array sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe;

	virtual void Reset()
	{
		sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.clear();
		sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.clear();
		sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj = 0;
		sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.clear();
		sbt_refGYxlDHdCx7zkDTNVQ_ = 0;
		sbt_02qsgrQbtxD9giYl9Z5 = 0;
		sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.clear();
		sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.clear();
		sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.clear();
		sbt_TUu.clear();
		sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D.clear();
		sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.clear();
		sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW = 0;
		sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.clear();
		sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.push_back(true);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.push_back(true);
		}
		sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj = 292197950;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.push_back(3555127397617827796);
		}
		sbt_refGYxlDHdCx7zkDTNVQ_ = 14;
		sbt_02qsgrQbtxD9giYl9Z5 = 2933035548084379026;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.push_back(140);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.push_back(2346105029);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.push_back(1505727995);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_TUu.push_back(-43);
		}
		sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D = "fk'_|N=\"IBVpLVp4eeXhO";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.push_back(1230855020);
		}
		sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW = 174591626;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.push_back("6qZ");
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.push_back(25543);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf *pObject = dynamic_cast<const sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.size() != pObject->sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.size(); i++)
		{
			if (sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8[i] != pObject->sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8[i])
			{
				return false;
			}
		}
		if (sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.size() != pObject->sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.size(); i++)
		{
			if (sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV[i] != pObject->sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV[i])
			{
				return false;
			}
		}
		if (sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj != pObject->sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj)
		{
			return false;
		}
		if (sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.size() != pObject->sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.size(); i++)
		{
			if (sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC[i] != pObject->sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC[i])
			{
				return false;
			}
		}
		if (sbt_refGYxlDHdCx7zkDTNVQ_ != pObject->sbt_refGYxlDHdCx7zkDTNVQ_)
		{
			return false;
		}
		if (sbt_02qsgrQbtxD9giYl9Z5 != pObject->sbt_02qsgrQbtxD9giYl9Z5)
		{
			return false;
		}
		if (sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.size() != pObject->sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.size(); i++)
		{
			if (sbt_LG8hpaFBWlcjjWyMe2QbbrHfu[i] != pObject->sbt_LG8hpaFBWlcjjWyMe2QbbrHfu[i])
			{
				return false;
			}
		}
		if (sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.size() != pObject->sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.size(); i++)
		{
			if (sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy[i] != pObject->sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy[i])
			{
				return false;
			}
		}
		if (sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.size() != pObject->sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.size(); i++)
		{
			if (sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ[i] != pObject->sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ[i])
			{
				return false;
			}
		}
		if (sbt_TUu.size() != pObject->sbt_TUu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TUu.size(); i++)
		{
			if (sbt_TUu[i] != pObject->sbt_TUu[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D.c_str(), pObject->sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D.c_str()))
		{
			return false;
		}
		if (sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.size() != pObject->sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.size(); i++)
		{
			if (sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg[i] != pObject->sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg[i])
			{
				return false;
			}
		}
		if (sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW != pObject->sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW)
		{
			return false;
		}
		if (sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.size() != pObject->sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7[i].c_str(), pObject->sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.size() != pObject->sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.size(); i++)
		{
			if (sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe[i] != pObject->sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_refGYxlDHdCx7zkDTNVQ_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_refGYxlDHdCx7zkDTNVQ_ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_02qsgrQbtxD9giYl9Z5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_02qsgrQbtxD9giYl9Z5 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LG8hpaFBWlcjjWyMe2QbbrHfu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TUu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TUu.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D", &sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.begin(); iter != sbt_Yg5hS7O9gQi1jL7TjNl_oxB28RN0pfgjpkjzXXcdME8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.begin(); iter != sbt_Y6J7iQbfILaRwxiJCDkwbn5GH4L_ukYCOcZ57LFnz91MDsS6oYjzV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj", (CX::Int64)sbt_1QH5ujpvqSAvI3hJ3OG8C0sbj7iu98xuClUao9zqI7JAzZMUYtBrbm_AyC_uj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.begin(); iter != sbt_6137mSOxp0G3ALObap2leuY72HvwmqI5XUHzT29PQ1zR8C5UC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_refGYxlDHdCx7zkDTNVQ_", (CX::Int64)sbt_refGYxlDHdCx7zkDTNVQ_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_02qsgrQbtxD9giYl9Z5", (CX::Int64)sbt_02qsgrQbtxD9giYl9Z5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LG8hpaFBWlcjjWyMe2QbbrHfu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.begin(); iter != sbt_LG8hpaFBWlcjjWyMe2QbbrHfu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.begin(); iter != sbt_lhS1LlZLQh1uUNWNyDQL_cjOyzfxQJNMwfGAkQARmpEm77qPfpo6MdB0i3WNy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.begin(); iter != sbt_6OTDM9ISETWN23V0ecgY4sxhrkTfrKTyQuqhzMVVWHvbrs_2Pe1Fla1GQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TUu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_TUu.begin(); iter != sbt_TUu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D", sbt_PL9phB_NeKDYbfxGSoNyHBhz4a82O0lvIeYhBXOLh9N7D.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.begin(); iter != sbt_hh8d77dZva0DkW174HKHxhlHZYqKdRg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW", (CX::Int64)sbt_fHGHVUKvbVDDrEkdL87nOLfA3gLLBT02dOuy4WiX9G_w2PSnveKodYVUW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.begin(); iter != sbt_fXrsc4cDP1S4uJOfuOGEf4eX8GG0dOk3b2FA7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.begin(); iter != sbt_bSYT2cz_n_Vn1_PJvioQCLVxbqtpLUBWEk_ezsW3u8G9TZeTfCzMe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf>::Type sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqfArray;

