
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_TxwjA;
	CX::Int8 sbt_wViJU9SBdaFdKwDVRG5_R;
	CX::IO::SimpleBuffers::UInt8Array sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu;

	virtual void Reset()
	{
		sbt_TxwjA = 0;
		sbt_wViJU9SBdaFdKwDVRG5_R = 0;
		sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TxwjA = 1383516888;
		sbt_wViJU9SBdaFdKwDVRG5_R = 9;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.push_back(185);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r *pObject = dynamic_cast<const sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_TxwjA != pObject->sbt_TxwjA)
		{
			return false;
		}
		if (sbt_wViJU9SBdaFdKwDVRG5_R != pObject->sbt_wViJU9SBdaFdKwDVRG5_R)
		{
			return false;
		}
		if (sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.size() != pObject->sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.size(); i++)
		{
			if (sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu[i] != pObject->sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_TxwjA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TxwjA = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wViJU9SBdaFdKwDVRG5_R", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wViJU9SBdaFdKwDVRG5_R = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_TxwjA", (CX::Int64)sbt_TxwjA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wViJU9SBdaFdKwDVRG5_R", (CX::Int64)sbt_wViJU9SBdaFdKwDVRG5_R)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.begin(); iter != sbt_1fjU9rNkcmasn4wwbBaOMVHxnqP7X9enVzwutjyqu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r>::Type sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972rArray;

