
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_DYiGJ.hpp"


class sbt_oc_ySyrOZajC8Hz27rA : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_8JqOJ;
	CX::IO::SimpleBuffers::Int16Array sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth;
	CX::UInt64 sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_;
	CX::Int16 sbt_WaFwCaMI0_MxgRSNCaBbmT8;
	CX::IO::SimpleBuffers::WStringArray sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk;
	CX::IO::SimpleBuffers::UInt16Array sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP;
	CX::UInt8 sbt_2Df3r3_JzjzosQWwWjvLG;
	CX::UInt32 sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl;
	CX::String sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv;
	CX::WString sbt_ArGeiNtPrCc;
	CX::IO::SimpleBuffers::UInt16Array sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx;
	CX::WString sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo;
	CX::IO::SimpleBuffers::UInt8Array sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd;
	CX::IO::SimpleBuffers::FloatArray sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W;
	CX::Double sbt_YVZW9y3KGsPQ9DL;
	CX::IO::SimpleBuffers::DoubleArray sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE;
	CX::IO::SimpleBuffers::Int64Array sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu;
	CX::Double sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m;
	CX::IO::SimpleBuffers::Int8Array sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62;
	CX::Double sbt_4cTHAEFH3Fqrjfehxjf;
	CX::UInt16 sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv;
	CX::String sbt_3ZiN0gBfaCt;
	CX::IO::SimpleBuffers::Int16Array sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO;
	CX::UInt8 sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC;
	CX::UInt16 sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf;
	CX::IO::SimpleBuffers::DoubleArray sbt_E4GMJWT6Z;
	CX::IO::SimpleBuffers::FloatArray sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia;
	sbt_DYiGJArray sbt_P;

	virtual void Reset()
	{
		sbt_8JqOJ = 0;
		sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.clear();
		sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_ = 0;
		sbt_WaFwCaMI0_MxgRSNCaBbmT8 = 0;
		sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.clear();
		sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.clear();
		sbt_2Df3r3_JzjzosQWwWjvLG = 0;
		sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl = 0;
		sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv.clear();
		sbt_ArGeiNtPrCc.clear();
		sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.clear();
		sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo.clear();
		sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.clear();
		sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.clear();
		sbt_YVZW9y3KGsPQ9DL = 0.0;
		sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.clear();
		sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.clear();
		sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m = 0.0;
		sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.clear();
		sbt_4cTHAEFH3Fqrjfehxjf = 0.0;
		sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv = 0;
		sbt_3ZiN0gBfaCt.clear();
		sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.clear();
		sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC = 0;
		sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf = 0;
		sbt_E4GMJWT6Z.clear();
		sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.clear();
		sbt_P.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_8JqOJ = 34235;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.push_back(-3751);
		}
		sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_ = 738947684580603870;
		sbt_WaFwCaMI0_MxgRSNCaBbmT8 = 1534;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.push_back(L"1S_z{9=nM+aCoxX3**@");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.push_back(41206);
		}
		sbt_2Df3r3_JzjzosQWwWjvLG = 125;
		sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl = 1115145423;
		sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv = "";
		sbt_ArGeiNtPrCc = L"rq|+RNTLW!PlE=BKfZ2>V1YpFRUHXO|_S[+)Qc2O{5Cp/^U-jwU`8{DD1$%";
		sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo = L"/<\"j^tgV}hg-*3gBvBHR(ZCFj=/b=5VwGjW&JeUnHkoPU1K~m*+0lP.czk|0Qs";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.push_back(59);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.push_back(0.816707f);
		}
		sbt_YVZW9y3KGsPQ9DL = 0.028338;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.push_back(0.017811);
		}
		sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m = 0.308850;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.push_back(76);
		}
		sbt_4cTHAEFH3Fqrjfehxjf = 0.868466;
		sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv = 38549;
		sbt_3ZiN0gBfaCt = "k2L$/~s5T&:4ME%[+_3j$SblJ?'n0ozykH;7UI%+Y%fV/L:aj(%6Jc0m@P]zIWn";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.push_back(8355);
		}
		sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC = 6;
		sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf = 55119;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_E4GMJWT6Z.push_back(0.402146);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.push_back(0.526089f);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_DYiGJ v;

			v.SetupWithSomeValues();
			sbt_P.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_oc_ySyrOZajC8Hz27rA *pObject = dynamic_cast<const sbt_oc_ySyrOZajC8Hz27rA *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_8JqOJ != pObject->sbt_8JqOJ)
		{
			return false;
		}
		if (sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.size() != pObject->sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.size(); i++)
		{
			if (sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth[i] != pObject->sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth[i])
			{
				return false;
			}
		}
		if (sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_ != pObject->sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_)
		{
			return false;
		}
		if (sbt_WaFwCaMI0_MxgRSNCaBbmT8 != pObject->sbt_WaFwCaMI0_MxgRSNCaBbmT8)
		{
			return false;
		}
		if (sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.size() != pObject->sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk[i].c_str(), pObject->sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.size() != pObject->sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.size(); i++)
		{
			if (sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP[i] != pObject->sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP[i])
			{
				return false;
			}
		}
		if (sbt_2Df3r3_JzjzosQWwWjvLG != pObject->sbt_2Df3r3_JzjzosQWwWjvLG)
		{
			return false;
		}
		if (sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl != pObject->sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv.c_str(), pObject->sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv.c_str()))
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_ArGeiNtPrCc.c_str(), pObject->sbt_ArGeiNtPrCc.c_str()))
		{
			return false;
		}
		if (sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.size() != pObject->sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.size(); i++)
		{
			if (sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx[i] != pObject->sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo.c_str(), pObject->sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo.c_str()))
		{
			return false;
		}
		if (sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.size() != pObject->sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.size(); i++)
		{
			if (sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd[i] != pObject->sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd[i])
			{
				return false;
			}
		}
		if (sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.size() != pObject->sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.size(); i++)
		{
			if (sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W[i] != pObject->sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W[i])
			{
				return false;
			}
		}
		if (sbt_YVZW9y3KGsPQ9DL != pObject->sbt_YVZW9y3KGsPQ9DL)
		{
			return false;
		}
		if (sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.size() != pObject->sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.size(); i++)
		{
			if (sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE[i] != pObject->sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE[i])
			{
				return false;
			}
		}
		if (sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.size() != pObject->sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.size(); i++)
		{
			if (sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu[i] != pObject->sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu[i])
			{
				return false;
			}
		}
		if (sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m != pObject->sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m)
		{
			return false;
		}
		if (sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.size() != pObject->sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.size(); i++)
		{
			if (sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62[i] != pObject->sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62[i])
			{
				return false;
			}
		}
		if (sbt_4cTHAEFH3Fqrjfehxjf != pObject->sbt_4cTHAEFH3Fqrjfehxjf)
		{
			return false;
		}
		if (sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv != pObject->sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_3ZiN0gBfaCt.c_str(), pObject->sbt_3ZiN0gBfaCt.c_str()))
		{
			return false;
		}
		if (sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.size() != pObject->sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.size(); i++)
		{
			if (sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO[i] != pObject->sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO[i])
			{
				return false;
			}
		}
		if (sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC != pObject->sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC)
		{
			return false;
		}
		if (sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf != pObject->sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf)
		{
			return false;
		}
		if (sbt_E4GMJWT6Z.size() != pObject->sbt_E4GMJWT6Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E4GMJWT6Z.size(); i++)
		{
			if (sbt_E4GMJWT6Z[i] != pObject->sbt_E4GMJWT6Z[i])
			{
				return false;
			}
		}
		if (sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.size() != pObject->sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.size(); i++)
		{
			if (sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia[i] != pObject->sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia[i])
			{
				return false;
			}
		}
		if (sbt_P.size() != pObject->sbt_P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P.size(); i++)
		{
			if (!sbt_P[i].Compare(&pObject->sbt_P[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_8JqOJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8JqOJ = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WaFwCaMI0_MxgRSNCaBbmT8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WaFwCaMI0_MxgRSNCaBbmT8 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2Df3r3_JzjzosQWwWjvLG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2Df3r3_JzjzosQWwWjvLG = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv", &sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_ArGeiNtPrCc", &sbt_ArGeiNtPrCc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo", &sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_YVZW9y3KGsPQ9DL", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_YVZW9y3KGsPQ9DL = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_4cTHAEFH3Fqrjfehxjf", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_4cTHAEFH3Fqrjfehxjf = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_3ZiN0gBfaCt", &sbt_3ZiN0gBfaCt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_E4GMJWT6Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E4GMJWT6Z.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_DYiGJ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_P.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_8JqOJ", (CX::Int64)sbt_8JqOJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.begin(); iter != sbt_VhczdgfDJRtZ81DGrC_rpx8u0yKCwsdW8ytFoJ_GCsV7Qth.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_", (CX::Int64)sbt_exHx37jCfnDmbfrqBeFsPcypWOYuPgOQ9RxxkoKzMBJoiLtNldl2_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WaFwCaMI0_MxgRSNCaBbmT8", (CX::Int64)sbt_WaFwCaMI0_MxgRSNCaBbmT8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.begin(); iter != sbt_kj2moVwaDBRn33TvEWCjJBG9Mlojk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.begin(); iter != sbt_tWYk9CSYHRAYMNVJ2FC9Ef63HmBz8bMvKF4P3OWfMbsXVmMyP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2Df3r3_JzjzosQWwWjvLG", (CX::Int64)sbt_2Df3r3_JzjzosQWwWjvLG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl", (CX::Int64)sbt_9PuKMLUvw8zFlb9ypIP5ipgJWWCP_hG6LRv6YoaEbjqu2NmD1KXhLQ1Oljl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv", sbt_zZbmDTi47El2RLO7ZVYyXXb5GNv.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_ArGeiNtPrCc", sbt_ArGeiNtPrCc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.begin(); iter != sbt_Kd9SNPZwkxnOe50b85NP5TzaZwoJUDNRaph3N7lr8NyaaYx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo", sbt_L9lFKHIZwvTVzF74jkEy3j1i5_sKo.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.begin(); iter != sbt_BevVWuJgVMbY_g20qGXbCf4HuTAJY0fhde6tPp_SVZcNs5Sf4HSOVwTI7Q7Hd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.begin(); iter != sbt_VivLcmUu6H0HoSccbSLumIPIKH4EgDEsfisAznZUetBkDCMI9ZPKjz9dINjbK7W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_YVZW9y3KGsPQ9DL", (CX::Double)sbt_YVZW9y3KGsPQ9DL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.begin(); iter != sbt_Y0wcYJYMVrQmR_aractK12i_duQI8qAo7hmloV40l6q6zHGwtUu2e17WE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.begin(); iter != sbt_mZDTRMDA7s3CV8De0241_5lbXjIcu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m", (CX::Double)sbt_4KUscEeJolYfQ7v9Hj8vAw8pG_c6phO5j7cQcIsFWx6I5DO40KzvoYAbacKZB1m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.begin(); iter != sbt_vVng6YLpcYMFKEeQFQIsgWNdopfob62.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_4cTHAEFH3Fqrjfehxjf", (CX::Double)sbt_4cTHAEFH3Fqrjfehxjf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv", (CX::Int64)sbt_CYoiZD2HC_pLueJqEGGwQqV4uIZMD1KRVfySZx1UeBqc9BBPFwVmXhUgv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_3ZiN0gBfaCt", sbt_3ZiN0gBfaCt.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.begin(); iter != sbt_9f9JsfDjYMkES5fQfLHTgifUKGMa_mZZMHO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC", (CX::Int64)sbt_XnheYpxP65kP0NbpPI6FRfo_uo_T0mC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf", (CX::Int64)sbt_c62CjKr6K3SheFxCHrS7VHxRcS68ATCM90jjIuYBbGf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E4GMJWT6Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_E4GMJWT6Z.begin(); iter != sbt_E4GMJWT6Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.begin(); iter != sbt_yetW3cLne54sPP1OAVr9v3fAmALy4Peia.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (sbt_DYiGJArray::const_iterator iter = sbt_P.begin(); iter != sbt_P.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_oc_ySyrOZajC8Hz27rA>::Type sbt_oc_ySyrOZajC8Hz27rAArray;

