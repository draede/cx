
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6;
	CX::IO::SimpleBuffers::UInt64Array sbt_79J898XoONYOPTP3S70xinAaacW6c;
	CX::Int16 sbt_J5cNe;
	CX::Int32 sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_;
	CX::Int8 sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv;
	CX::String sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ;
	CX::IO::SimpleBuffers::UInt64Array sbt_8Pd3BbJ7Bg6rDKC;
	CX::IO::SimpleBuffers::Int8Array sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa;
	CX::IO::SimpleBuffers::Int8Array sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D;
	CX::IO::SimpleBuffers::Int16Array sbt_8YJzTuW2oQpmoRIjj51qNkLg6;
	CX::Bool sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS;
	CX::String sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC;
	CX::UInt32 sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph;
	CX::IO::SimpleBuffers::Int32Array sbt_BPLWNGdWLUcH1Ltd9ng3k;
	CX::Int32 sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b;
	CX::IO::SimpleBuffers::UInt16Array sbt_6An;
	CX::IO::SimpleBuffers::Int32Array sbt_m_7;
	CX::IO::SimpleBuffers::Int64Array sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf;
	CX::IO::SimpleBuffers::StringArray sbt_IncZs5kADkEEMz_fTPG;
	CX::Bool sbt_ONEUJAG;
	CX::Int16 sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ;
	CX::IO::SimpleBuffers::StringArray sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG;
	CX::IO::SimpleBuffers::UInt16Array sbt_SX8g6_xSuQI6C8Rx9;
	CX::IO::SimpleBuffers::UInt64Array sbt_QIvykoS0TViDg_4;
	CX::IO::SimpleBuffers::Int16Array sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB;

	virtual void Reset()
	{
		sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.clear();
		sbt_79J898XoONYOPTP3S70xinAaacW6c.clear();
		sbt_J5cNe = 0;
		sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_ = 0;
		sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv = 0;
		sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ.clear();
		sbt_8Pd3BbJ7Bg6rDKC.clear();
		sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.clear();
		sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.clear();
		sbt_8YJzTuW2oQpmoRIjj51qNkLg6.clear();
		sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS = false;
		sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC.clear();
		sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph = 0;
		sbt_BPLWNGdWLUcH1Ltd9ng3k.clear();
		sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b = 0;
		sbt_6An.clear();
		sbt_m_7.clear();
		sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.clear();
		sbt_IncZs5kADkEEMz_fTPG.clear();
		sbt_ONEUJAG = false;
		sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ = 0;
		sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.clear();
		sbt_SX8g6_xSuQI6C8Rx9.clear();
		sbt_QIvykoS0TViDg_4.clear();
		sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.push_back("\"5C&26}FE6.87eZ*QA2@G}7");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_79J898XoONYOPTP3S70xinAaacW6c.push_back(10642967452218991396);
		}
		sbt_J5cNe = 9340;
		sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_ = 1057785167;
		sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv = 64;
		sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ = "__Skpn?'pX'=\"[#WJK~u@|uWSL-i)[<:";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_8Pd3BbJ7Bg6rDKC.push_back(6645668576467253514);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.push_back(24);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.push_back(-123);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_8YJzTuW2oQpmoRIjj51qNkLg6.push_back(-18313);
		}
		sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS = false;
		sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC = "";
		sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph = 1891295380;
		sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b = -1059757404;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_6An.push_back(3516);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_m_7.push_back(-2139716483);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.push_back(-4631043577337208926);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_IncZs5kADkEEMz_fTPG.push_back("-s>/rCi7FN5H),<41:Kf(VIS9vAQdTWPu,+cL2G\\+]2HxiflNr/");
		}
		sbt_ONEUJAG = false;
		sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ = 29718;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.push_back(">eQ=-");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_SX8g6_xSuQI6C8Rx9.push_back(53351);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_QIvykoS0TViDg_4.push_back(14612251935563197376);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.push_back(-59);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq *pObject = dynamic_cast<const sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.size() != pObject->sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.size(); i++)
		{
			if (0 != cx_strcmp(sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6[i].c_str(), pObject->sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_79J898XoONYOPTP3S70xinAaacW6c.size() != pObject->sbt_79J898XoONYOPTP3S70xinAaacW6c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_79J898XoONYOPTP3S70xinAaacW6c.size(); i++)
		{
			if (sbt_79J898XoONYOPTP3S70xinAaacW6c[i] != pObject->sbt_79J898XoONYOPTP3S70xinAaacW6c[i])
			{
				return false;
			}
		}
		if (sbt_J5cNe != pObject->sbt_J5cNe)
		{
			return false;
		}
		if (sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_ != pObject->sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_)
		{
			return false;
		}
		if (sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv != pObject->sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ.c_str(), pObject->sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ.c_str()))
		{
			return false;
		}
		if (sbt_8Pd3BbJ7Bg6rDKC.size() != pObject->sbt_8Pd3BbJ7Bg6rDKC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8Pd3BbJ7Bg6rDKC.size(); i++)
		{
			if (sbt_8Pd3BbJ7Bg6rDKC[i] != pObject->sbt_8Pd3BbJ7Bg6rDKC[i])
			{
				return false;
			}
		}
		if (sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.size() != pObject->sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.size(); i++)
		{
			if (sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa[i] != pObject->sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa[i])
			{
				return false;
			}
		}
		if (sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.size() != pObject->sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.size(); i++)
		{
			if (sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D[i] != pObject->sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D[i])
			{
				return false;
			}
		}
		if (sbt_8YJzTuW2oQpmoRIjj51qNkLg6.size() != pObject->sbt_8YJzTuW2oQpmoRIjj51qNkLg6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8YJzTuW2oQpmoRIjj51qNkLg6.size(); i++)
		{
			if (sbt_8YJzTuW2oQpmoRIjj51qNkLg6[i] != pObject->sbt_8YJzTuW2oQpmoRIjj51qNkLg6[i])
			{
				return false;
			}
		}
		if (sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS != pObject->sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC.c_str(), pObject->sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC.c_str()))
		{
			return false;
		}
		if (sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph != pObject->sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph)
		{
			return false;
		}
		if (sbt_BPLWNGdWLUcH1Ltd9ng3k.size() != pObject->sbt_BPLWNGdWLUcH1Ltd9ng3k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BPLWNGdWLUcH1Ltd9ng3k.size(); i++)
		{
			if (sbt_BPLWNGdWLUcH1Ltd9ng3k[i] != pObject->sbt_BPLWNGdWLUcH1Ltd9ng3k[i])
			{
				return false;
			}
		}
		if (sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b != pObject->sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b)
		{
			return false;
		}
		if (sbt_6An.size() != pObject->sbt_6An.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6An.size(); i++)
		{
			if (sbt_6An[i] != pObject->sbt_6An[i])
			{
				return false;
			}
		}
		if (sbt_m_7.size() != pObject->sbt_m_7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m_7.size(); i++)
		{
			if (sbt_m_7[i] != pObject->sbt_m_7[i])
			{
				return false;
			}
		}
		if (sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.size() != pObject->sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.size(); i++)
		{
			if (sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf[i] != pObject->sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf[i])
			{
				return false;
			}
		}
		if (sbt_IncZs5kADkEEMz_fTPG.size() != pObject->sbt_IncZs5kADkEEMz_fTPG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IncZs5kADkEEMz_fTPG.size(); i++)
		{
			if (0 != cx_strcmp(sbt_IncZs5kADkEEMz_fTPG[i].c_str(), pObject->sbt_IncZs5kADkEEMz_fTPG[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ONEUJAG != pObject->sbt_ONEUJAG)
		{
			return false;
		}
		if (sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ != pObject->sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ)
		{
			return false;
		}
		if (sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.size() != pObject->sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.size(); i++)
		{
			if (0 != cx_strcmp(sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG[i].c_str(), pObject->sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_SX8g6_xSuQI6C8Rx9.size() != pObject->sbt_SX8g6_xSuQI6C8Rx9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SX8g6_xSuQI6C8Rx9.size(); i++)
		{
			if (sbt_SX8g6_xSuQI6C8Rx9[i] != pObject->sbt_SX8g6_xSuQI6C8Rx9[i])
			{
				return false;
			}
		}
		if (sbt_QIvykoS0TViDg_4.size() != pObject->sbt_QIvykoS0TViDg_4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QIvykoS0TViDg_4.size(); i++)
		{
			if (sbt_QIvykoS0TViDg_4[i] != pObject->sbt_QIvykoS0TViDg_4[i])
			{
				return false;
			}
		}
		if (sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.size() != pObject->sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.size(); i++)
		{
			if (sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB[i] != pObject->sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_79J898XoONYOPTP3S70xinAaacW6c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_79J898XoONYOPTP3S70xinAaacW6c.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J5cNe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J5cNe = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_ = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ", &sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8Pd3BbJ7Bg6rDKC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8Pd3BbJ7Bg6rDKC.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8YJzTuW2oQpmoRIjj51qNkLg6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8YJzTuW2oQpmoRIjj51qNkLg6.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS", &sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC", &sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BPLWNGdWLUcH1Ltd9ng3k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BPLWNGdWLUcH1Ltd9ng3k.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6An")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6An.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_m_7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m_7.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IncZs5kADkEEMz_fTPG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IncZs5kADkEEMz_fTPG.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_ONEUJAG", &sbt_ONEUJAG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SX8g6_xSuQI6C8Rx9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SX8g6_xSuQI6C8Rx9.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QIvykoS0TViDg_4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QIvykoS0TViDg_4.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.begin(); iter != sbt_AErII966twXcR2Hm74OJABFMxtJdT9yhiFFUrWqIQ8zqCkDZjj6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_79J898XoONYOPTP3S70xinAaacW6c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_79J898XoONYOPTP3S70xinAaacW6c.begin(); iter != sbt_79J898XoONYOPTP3S70xinAaacW6c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J5cNe", (CX::Int64)sbt_J5cNe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_", (CX::Int64)sbt_lIKKKLxHGYyD5Z9_HDc_PvtBlPmDoLRxk5rXeu_pZjzBPP_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv", (CX::Int64)sbt_p_v9DJFdPFfymdzKgPeZYKZDMvpKHXrQEb8hjlzyvI3wiQv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ", sbt_w9zuXqvp8BGlKT4FhJoFxOJtPhvT3uMDd7zvfpLjKyQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8Pd3BbJ7Bg6rDKC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_8Pd3BbJ7Bg6rDKC.begin(); iter != sbt_8Pd3BbJ7Bg6rDKC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.begin(); iter != sbt_3WqnNPIj7Dnj9TdPbazXXF8i2KMEqETBxMqqGuLdPJdbnTa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.begin(); iter != sbt_ELjw_3KkVxwg8ebWSHsXa2NXVc0n0eyAJkawn7fSIBb8VXdIT0vH7u12D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8YJzTuW2oQpmoRIjj51qNkLg6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_8YJzTuW2oQpmoRIjj51qNkLg6.begin(); iter != sbt_8YJzTuW2oQpmoRIjj51qNkLg6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS", sbt_V1qzakOBaOCiJcOvNN3U1Nyj16jMoN6UdhhDS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC", sbt_39FgvfOV4pRc8UzMF9kAnA75q4DkLGEEXw40NU_rC.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph", (CX::Int64)sbt_RraZMwElYcpQBUPbbzBlyjcy85KjIpJqwZgXqtZnYw5LazG35Ph)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BPLWNGdWLUcH1Ltd9ng3k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_BPLWNGdWLUcH1Ltd9ng3k.begin(); iter != sbt_BPLWNGdWLUcH1Ltd9ng3k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b", (CX::Int64)sbt_Vm9sukbRIg_ZSV52inYVpKHNjHmso0b)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6An")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_6An.begin(); iter != sbt_6An.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_m_7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_m_7.begin(); iter != sbt_m_7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.begin(); iter != sbt_OelRx6K18v5h6bMbAZZc7CIqyxngDGO3tm7dHgZRPZsLgfHqVWO6vxt8AaPtqKf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IncZs5kADkEEMz_fTPG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_IncZs5kADkEEMz_fTPG.begin(); iter != sbt_IncZs5kADkEEMz_fTPG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ONEUJAG", sbt_ONEUJAG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ", (CX::Int64)sbt_rjNKDS4hdON25plIYnSP_Obj2U5v6yBjXbXdpFHlAooxrpkePYhfsyrXDN1S8RQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.begin(); iter != sbt_p4uuvvsk5GanTgam_MvhXyz0XxD2JUt6KGr7e5NQmy3Vzfby_csR4FG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SX8g6_xSuQI6C8Rx9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_SX8g6_xSuQI6C8Rx9.begin(); iter != sbt_SX8g6_xSuQI6C8Rx9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QIvykoS0TViDg_4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_QIvykoS0TViDg_4.begin(); iter != sbt_QIvykoS0TViDg_4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.begin(); iter != sbt_Z11meadmDfN4dGxfJhAAkATVLitMUYzZe1AqdyohqRxXKAtUaXn9wvB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq>::Type sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojqArray;

