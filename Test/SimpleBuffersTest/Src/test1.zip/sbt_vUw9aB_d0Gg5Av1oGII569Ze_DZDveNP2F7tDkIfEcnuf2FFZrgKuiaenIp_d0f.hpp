
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_N_n0Grp5_2dTTTlFuVjOezBdT.hpp"


class sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_9;
	CX::UInt64 sbt_x70;
	CX::Int16 sbt_LIjUbJTMcxU_5rMzS8i2rFV;
	CX::IO::SimpleBuffers::DoubleArray sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe;
	CX::IO::SimpleBuffers::StringArray sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ;
	CX::IO::SimpleBuffers::Int64Array sbt__MXFamFlAtfW2Az1zBkPY;
	CX::IO::SimpleBuffers::Int32Array sbt_lDgQKmHgU;
	CX::IO::SimpleBuffers::UInt32Array sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk;
	CX::UInt32 sbt_Ice2LpfDHg7kLy2;
	CX::IO::SimpleBuffers::StringArray sbt_4oXtsP6kwrTo8XEJqIzvmFb;
	CX::Float sbt_oW7ME;
	CX::IO::SimpleBuffers::FloatArray sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ;
	CX::IO::SimpleBuffers::StringArray sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP;
	CX::Int32 sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8;
	CX::Int8 sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9;
	sbt_N_n0Grp5_2dTTTlFuVjOezBdTArray sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0;

	virtual void Reset()
	{
		sbt_9.clear();
		sbt_x70 = 0;
		sbt_LIjUbJTMcxU_5rMzS8i2rFV = 0;
		sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.clear();
		sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.clear();
		sbt__MXFamFlAtfW2Az1zBkPY.clear();
		sbt_lDgQKmHgU.clear();
		sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.clear();
		sbt_Ice2LpfDHg7kLy2 = 0;
		sbt_4oXtsP6kwrTo8XEJqIzvmFb.clear();
		sbt_oW7ME = 0.0f;
		sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.clear();
		sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.clear();
		sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8 = 0;
		sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9 = 0;
		sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_x70 = 4358213887483328952;
		sbt_LIjUbJTMcxU_5rMzS8i2rFV = -5280;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.push_back(0.428436);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.push_back("\\|0IN;SD>F1k8dW/c+l?>'n;&Og+2b5!#_X2teJh2n0duw{hR1");
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt__MXFamFlAtfW2Az1zBkPY.push_back(-6217708987081005298);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_lDgQKmHgU.push_back(-1475293153);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.push_back(1112380636);
		}
		sbt_Ice2LpfDHg7kLy2 = 335632994;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_4oXtsP6kwrTo8XEJqIzvmFb.push_back("wCF\\P!#@Ph<1w\\xI,(%6:b`@r:$r#80NP%DXyV;,6n:(HY/");
		}
		sbt_oW7ME = 0.379478f;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.push_back(0.790597f);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.push_back(".#j#eL&m)|RQH\"~UKE7%H5ZK,5$hu|^-umZHP");
		}
		sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8 = 1568057467;
		sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9 = -14;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_N_n0Grp5_2dTTTlFuVjOezBdT v;

			v.SetupWithSomeValues();
			sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f *pObject = dynamic_cast<const sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9.size() != pObject->sbt_9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9.size(); i++)
		{
			if (sbt_9[i] != pObject->sbt_9[i])
			{
				return false;
			}
		}
		if (sbt_x70 != pObject->sbt_x70)
		{
			return false;
		}
		if (sbt_LIjUbJTMcxU_5rMzS8i2rFV != pObject->sbt_LIjUbJTMcxU_5rMzS8i2rFV)
		{
			return false;
		}
		if (sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.size() != pObject->sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.size(); i++)
		{
			if (sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe[i] != pObject->sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe[i])
			{
				return false;
			}
		}
		if (sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.size() != pObject->sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ[i].c_str(), pObject->sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt__MXFamFlAtfW2Az1zBkPY.size() != pObject->sbt__MXFamFlAtfW2Az1zBkPY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__MXFamFlAtfW2Az1zBkPY.size(); i++)
		{
			if (sbt__MXFamFlAtfW2Az1zBkPY[i] != pObject->sbt__MXFamFlAtfW2Az1zBkPY[i])
			{
				return false;
			}
		}
		if (sbt_lDgQKmHgU.size() != pObject->sbt_lDgQKmHgU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lDgQKmHgU.size(); i++)
		{
			if (sbt_lDgQKmHgU[i] != pObject->sbt_lDgQKmHgU[i])
			{
				return false;
			}
		}
		if (sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.size() != pObject->sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.size(); i++)
		{
			if (sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk[i] != pObject->sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk[i])
			{
				return false;
			}
		}
		if (sbt_Ice2LpfDHg7kLy2 != pObject->sbt_Ice2LpfDHg7kLy2)
		{
			return false;
		}
		if (sbt_4oXtsP6kwrTo8XEJqIzvmFb.size() != pObject->sbt_4oXtsP6kwrTo8XEJqIzvmFb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4oXtsP6kwrTo8XEJqIzvmFb.size(); i++)
		{
			if (0 != cx_strcmp(sbt_4oXtsP6kwrTo8XEJqIzvmFb[i].c_str(), pObject->sbt_4oXtsP6kwrTo8XEJqIzvmFb[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_oW7ME != pObject->sbt_oW7ME)
		{
			return false;
		}
		if (sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.size() != pObject->sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.size(); i++)
		{
			if (sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ[i] != pObject->sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ[i])
			{
				return false;
			}
		}
		if (sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.size() != pObject->sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.size(); i++)
		{
			if (0 != cx_strcmp(sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP[i].c_str(), pObject->sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8 != pObject->sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8)
		{
			return false;
		}
		if (sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9 != pObject->sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9)
		{
			return false;
		}
		if (sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.size() != pObject->sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.size(); i++)
		{
			if (!sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0[i].Compare(&pObject->sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_x70", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_x70 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LIjUbJTMcxU_5rMzS8i2rFV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LIjUbJTMcxU_5rMzS8i2rFV = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__MXFamFlAtfW2Az1zBkPY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__MXFamFlAtfW2Az1zBkPY.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lDgQKmHgU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lDgQKmHgU.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Ice2LpfDHg7kLy2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ice2LpfDHg7kLy2 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4oXtsP6kwrTo8XEJqIzvmFb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4oXtsP6kwrTo8XEJqIzvmFb.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_oW7ME", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_oW7ME = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_N_n0Grp5_2dTTTlFuVjOezBdT tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_9.begin(); iter != sbt_9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_x70", (CX::Int64)sbt_x70)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LIjUbJTMcxU_5rMzS8i2rFV", (CX::Int64)sbt_LIjUbJTMcxU_5rMzS8i2rFV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.begin(); iter != sbt_OotnZgIgXDhe36_oYu5IK2yTVT92hf0ryjsMe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.begin(); iter != sbt_QgRBHolQIKpu_43yW2J8v9Zwl5Urg5Hl9bqxMZ1os_xJJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__MXFamFlAtfW2Az1zBkPY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt__MXFamFlAtfW2Az1zBkPY.begin(); iter != sbt__MXFamFlAtfW2Az1zBkPY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lDgQKmHgU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_lDgQKmHgU.begin(); iter != sbt_lDgQKmHgU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.begin(); iter != sbt_XGZidtKtE3uWnJvBmvvwpB2N5rxMVwvrgIXt_buwxHk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ice2LpfDHg7kLy2", (CX::Int64)sbt_Ice2LpfDHg7kLy2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4oXtsP6kwrTo8XEJqIzvmFb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_4oXtsP6kwrTo8XEJqIzvmFb.begin(); iter != sbt_4oXtsP6kwrTo8XEJqIzvmFb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_oW7ME", (CX::Double)sbt_oW7ME)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.begin(); iter != sbt_JZt_ah3e4ke7S1sLFFLyC4PpsZWh0kZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.begin(); iter != sbt_DmtRkKJI4FqCL8dFy25H4RMjHuOWP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8", (CX::Int64)sbt_CXUT1IeeRFdKCB5WdxbAPVvq78l51lrH8F6WstdW8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9", (CX::Int64)sbt_Sp8E7LjxLxwSO_wPtaJqM4aoKfQwlONA5hQz9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0")).IsNOK())
		{
			return status;
		}
		for (sbt_N_n0Grp5_2dTTTlFuVjOezBdTArray::const_iterator iter = sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.begin(); iter != sbt_aPR6WGOL6o5TWgDythcg8QpI4gpC0.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f>::Type sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0fArray;

