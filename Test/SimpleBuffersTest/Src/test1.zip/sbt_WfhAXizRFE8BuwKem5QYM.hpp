
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_d7J.hpp"


class sbt_WfhAXizRFE8BuwKem5QYM : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz;
	CX::Int64 sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ;
	CX::IO::SimpleBuffers::StringArray sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0;
	CX::IO::SimpleBuffers::FloatArray sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j;
	CX::IO::SimpleBuffers::BoolArray sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q;
	CX::UInt64 sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI;
	CX::IO::SimpleBuffers::FloatArray sbt_z2TzISm_S;
	CX::IO::SimpleBuffers::Int64Array sbt_01esbUiMRwi;
	CX::UInt16 sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV;
	CX::IO::SimpleBuffers::DoubleArray sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH;
	CX::Double sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP;
	CX::Int32 sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK;
	CX::UInt64 sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd;
	CX::IO::SimpleBuffers::UInt16Array sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr;
	CX::UInt32 sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85;
	CX::IO::SimpleBuffers::UInt8Array sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4;
	CX::Float sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k;
	CX::Float sbt_cEvL2ov9DcSJZKuSk86;
	CX::IO::SimpleBuffers::WStringArray sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o;
	CX::IO::SimpleBuffers::UInt16Array sbt_td7x64gqbx66OyqgasBcR0F;
	CX::String sbt_2;
	CX::IO::SimpleBuffers::UInt16Array sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi;
	sbt_d7J sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC;

	virtual void Reset()
	{
		sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.clear();
		sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ = 0;
		sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.clear();
		sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.clear();
		sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.clear();
		sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI = 0;
		sbt_z2TzISm_S.clear();
		sbt_01esbUiMRwi.clear();
		sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV = 0;
		sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.clear();
		sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP = 0.0;
		sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK = 0;
		sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd = 0;
		sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.clear();
		sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85 = 0;
		sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.clear();
		sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k = 0.0f;
		sbt_cEvL2ov9DcSJZKuSk86 = 0.0f;
		sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.clear();
		sbt_td7x64gqbx66OyqgasBcR0F.clear();
		sbt_2.clear();
		sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.clear();
		sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.push_back(true);
		}
		sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ = -8258137303828793762;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.push_back("<z5\\pzt050$Tot8g|VGq:Z$\"=@'67>|O8x@(kW!02A}a");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.push_back(0.142318f);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.push_back(false);
		}
		sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI = 12409043650234289144;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_z2TzISm_S.push_back(0.594913f);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_01esbUiMRwi.push_back(4736430096714600866);
		}
		sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV = 6458;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.push_back(0.564880);
		}
		sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP = 0.683546;
		sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK = 795272317;
		sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd = 13085449228087837056;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.push_back(4511);
		}
		sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85 = 726530304;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.push_back(166);
		}
		sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k = 0.312689f;
		sbt_cEvL2ov9DcSJZKuSk86 = 0.003668f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.push_back(L"qO2<r|=&UN$");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_td7x64gqbx66OyqgasBcR0F.push_back(1599);
		}
		sbt_2 = "pB&y\\qV*6";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.push_back(2325);
		}
		sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_WfhAXizRFE8BuwKem5QYM *pObject = dynamic_cast<const sbt_WfhAXizRFE8BuwKem5QYM *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.size() != pObject->sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.size(); i++)
		{
			if (sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz[i] != pObject->sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz[i])
			{
				return false;
			}
		}
		if (sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ != pObject->sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ)
		{
			return false;
		}
		if (sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.size() != pObject->sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.size(); i++)
		{
			if (0 != cx_strcmp(sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0[i].c_str(), pObject->sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.size() != pObject->sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.size(); i++)
		{
			if (sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j[i] != pObject->sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j[i])
			{
				return false;
			}
		}
		if (sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.size() != pObject->sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.size(); i++)
		{
			if (sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q[i] != pObject->sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q[i])
			{
				return false;
			}
		}
		if (sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI != pObject->sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI)
		{
			return false;
		}
		if (sbt_z2TzISm_S.size() != pObject->sbt_z2TzISm_S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_z2TzISm_S.size(); i++)
		{
			if (sbt_z2TzISm_S[i] != pObject->sbt_z2TzISm_S[i])
			{
				return false;
			}
		}
		if (sbt_01esbUiMRwi.size() != pObject->sbt_01esbUiMRwi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_01esbUiMRwi.size(); i++)
		{
			if (sbt_01esbUiMRwi[i] != pObject->sbt_01esbUiMRwi[i])
			{
				return false;
			}
		}
		if (sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV != pObject->sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV)
		{
			return false;
		}
		if (sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.size() != pObject->sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.size(); i++)
		{
			if (sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH[i] != pObject->sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH[i])
			{
				return false;
			}
		}
		if (sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP != pObject->sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP)
		{
			return false;
		}
		if (sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK != pObject->sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK)
		{
			return false;
		}
		if (sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd != pObject->sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd)
		{
			return false;
		}
		if (sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.size() != pObject->sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.size(); i++)
		{
			if (sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr[i] != pObject->sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr[i])
			{
				return false;
			}
		}
		if (sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85 != pObject->sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85)
		{
			return false;
		}
		if (sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.size() != pObject->sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.size(); i++)
		{
			if (sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4[i] != pObject->sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4[i])
			{
				return false;
			}
		}
		if (sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k != pObject->sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k)
		{
			return false;
		}
		if (sbt_cEvL2ov9DcSJZKuSk86 != pObject->sbt_cEvL2ov9DcSJZKuSk86)
		{
			return false;
		}
		if (sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.size() != pObject->sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.size(); i++)
		{
			if (0 != cxw_strcmp(sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o[i].c_str(), pObject->sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_td7x64gqbx66OyqgasBcR0F.size() != pObject->sbt_td7x64gqbx66OyqgasBcR0F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_td7x64gqbx66OyqgasBcR0F.size(); i++)
		{
			if (sbt_td7x64gqbx66OyqgasBcR0F[i] != pObject->sbt_td7x64gqbx66OyqgasBcR0F[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_2.c_str(), pObject->sbt_2.c_str()))
		{
			return false;
		}
		if (sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.size() != pObject->sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.size(); i++)
		{
			if (sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi[i] != pObject->sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi[i])
			{
				return false;
			}
		}
		if (!sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC.Compare(&pObject->sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_z2TzISm_S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_z2TzISm_S.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_01esbUiMRwi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_01esbUiMRwi.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_cEvL2ov9DcSJZKuSk86", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_cEvL2ov9DcSJZKuSk86 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_td7x64gqbx66OyqgasBcR0F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_td7x64gqbx66OyqgasBcR0F.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_2", &sbt_2)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.begin(); iter != sbt_mEC0FsFbqW4dnKSZktDZfWTNKRlaikQnfo6lqiiHuAy9ZATdinbCz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ", (CX::Int64)sbt_j7USj_ZJPzkCmq2gWHrRVHwIlNt84iiuUKOcz2fvT905VOQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.begin(); iter != sbt_B0iNVt05euHcTmdCUM9Iy3q3YuZ488KARo4QagkSeTsQA8z_0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.begin(); iter != sbt_0SOPoMpCdHNqrpGYwrGOwwmzFUGsDesiYjvyrqcLl2Xy61j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.begin(); iter != sbt_r5Mmu3VUtmUBbEz_rmj0Q8lEx0yGW1UfC9HN7LOAlOOQLIAn9BcYc8w3q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI", (CX::Int64)sbt_kWTvRmBMj_qnAycuq8GAfqhT_E7hM2vKGRoPLCr40zxqUN_hyO88TCI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_z2TzISm_S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_z2TzISm_S.begin(); iter != sbt_z2TzISm_S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_01esbUiMRwi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_01esbUiMRwi.begin(); iter != sbt_01esbUiMRwi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV", (CX::Int64)sbt_t2FkeK8SloPC5dt0fQRcH2UR5YavV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.begin(); iter != sbt_T9vHAv899upVxs3TPYC2vm83knl3vK3_egYp7oBduJg9uSD4ZAH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP", (CX::Double)sbt_OiaQu85eebfzzKVT4JSmWFpuiFQahoqkDDAkIkgGamWm5sB9vxoDsOP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK", (CX::Int64)sbt_W9OXitPlsCSwL8HDAx924xqNfpZkhYVaK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd", (CX::Int64)sbt_kJOcGMzcYE8RwBRLvSP0FDmk0iZD6qbqu8zcstEmi0SjlFAptAKJLmVH0Knx_Vd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.begin(); iter != sbt_UUsM4_g_OKWXWosuLigtJoehcphL2PPpVZTtEZKeTNr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85", (CX::Int64)sbt_29kgra2JWvfNZV7EI5Pn1N7DtcdSe57C949DiHTzyFlMn85)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.begin(); iter != sbt_nhivOm0CF2L1E2qibRyp13jjyjKxGjmd5cx9kJJzcD51d3ke4fQX6vJkivIp4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k", (CX::Double)sbt_h5ESe9eimaaYkPgEyivtANJb09zKRjFks6k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_cEvL2ov9DcSJZKuSk86", (CX::Double)sbt_cEvL2ov9DcSJZKuSk86)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.begin(); iter != sbt__2Y_JWQwxHgN1W_MPpL9QWtv8MNqVgBz0wsXs0rjMI40fTEJZ0o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_td7x64gqbx66OyqgasBcR0F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_td7x64gqbx66OyqgasBcR0F.begin(); iter != sbt_td7x64gqbx66OyqgasBcR0F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_2", sbt_2.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.begin(); iter != sbt_QBhpBwujd2_QmCypKTq8fAHcw_6OuDu_iYfc8ySWB_Q0IIAWOQi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_HTkM53TFXha4evm93cRw3P6I7IIGZ2amZwvgk0EqKQznHvabFoC.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_WfhAXizRFE8BuwKem5QYM>::Type sbt_WfhAXizRFE8BuwKem5QYMArray;

