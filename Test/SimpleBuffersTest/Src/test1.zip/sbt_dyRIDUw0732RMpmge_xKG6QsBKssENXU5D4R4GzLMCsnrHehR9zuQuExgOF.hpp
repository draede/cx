
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_KWIixjWKwnIDmuwm8.hpp"


class sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_KWIixjWKwnIDmuwm8 sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY;

	virtual void Reset()
	{
		sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF *pObject = dynamic_cast<const sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (!sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY.Compare(&pObject->sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectObject("sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectObject("sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_PdDhq8RYhuvyK95psgWnRU06nXUgznjcd_lfRcqSTyfs9nbkoIe8K8DxBMluY.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF>::Type sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOFArray;

