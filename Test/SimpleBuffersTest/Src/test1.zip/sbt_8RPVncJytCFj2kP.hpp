
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_F37TR5tQnzaqiIY.hpp"


class sbt_8RPVncJytCFj2kP : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_ZOH;
	CX::IO::SimpleBuffers::BoolArray sbt_25i;
	CX::Int8 sbt_xg2QDDi4JrS3Pm1NQpI;
	CX::IO::SimpleBuffers::DoubleArray sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B;
	CX::UInt64 sbt_rkHwukS;
	CX::Bool sbt_1iq3g;
	CX::UInt32 sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW;
	CX::IO::SimpleBuffers::UInt32Array sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy;
	CX::IO::SimpleBuffers::Int64Array sbt_VpnX8xv0ZBdrSSBtH;
	CX::Double sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih;
	CX::IO::SimpleBuffers::Int32Array sbt_U;
	CX::Int64 sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM;
	CX::UInt16 sbt_yPTv8hMhp4M0i;
	CX::Int16 sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw;
	CX::UInt8 sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV;
	CX::IO::SimpleBuffers::UInt32Array sbt_LWUxfQEi_ZYZFJsvFsIUb0F66;
	CX::IO::SimpleBuffers::Int8Array sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu;
	CX::Int8 sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH;
	CX::IO::SimpleBuffers::Int16Array sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem;
	CX::Int32 sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx;
	CX::IO::SimpleBuffers::WStringArray sbt_ZNArPXIgt24ehsHDJ;
	CX::IO::SimpleBuffers::Int64Array sbt_xsMvIt7nS905iZpYT;
	CX::IO::SimpleBuffers::DoubleArray sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB;
	CX::IO::SimpleBuffers::Int64Array sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af;
	sbt_F37TR5tQnzaqiIY sbt_jNvv_9qas2jz2vItmlEwIwjXJ;

	virtual void Reset()
	{
		sbt_ZOH.clear();
		sbt_25i.clear();
		sbt_xg2QDDi4JrS3Pm1NQpI = 0;
		sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.clear();
		sbt_rkHwukS = 0;
		sbt_1iq3g = false;
		sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW = 0;
		sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.clear();
		sbt_VpnX8xv0ZBdrSSBtH.clear();
		sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih = 0.0;
		sbt_U.clear();
		sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM = 0;
		sbt_yPTv8hMhp4M0i = 0;
		sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw = 0;
		sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV = 0;
		sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.clear();
		sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.clear();
		sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH = 0;
		sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.clear();
		sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx = 0;
		sbt_ZNArPXIgt24ehsHDJ.clear();
		sbt_xsMvIt7nS905iZpYT.clear();
		sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.clear();
		sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.clear();
		sbt_jNvv_9qas2jz2vItmlEwIwjXJ.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_ZOH.push_back(77);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_25i.push_back(false);
		}
		sbt_xg2QDDi4JrS3Pm1NQpI = -53;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.push_back(0.500097);
		}
		sbt_rkHwukS = 410465431246207550;
		sbt_1iq3g = true;
		sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW = 1877729104;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.push_back(1216899529);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_VpnX8xv0ZBdrSSBtH.push_back(5680394323078347912);
		}
		sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih = 0.181667;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_U.push_back(96827670);
		}
		sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM = 8233776392794322148;
		sbt_yPTv8hMhp4M0i = 48929;
		sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw = -3289;
		sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV = 105;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.push_back(953951450);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.push_back(-16);
		}
		sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH = 73;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.push_back(-6427);
		}
		sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx = -1914028417;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ZNArPXIgt24ehsHDJ.push_back(L">bE18&2uvl55<n0qE}'x?IT&H&z^V`M'bOTBf9]#O5D>CMOfX");
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_xsMvIt7nS905iZpYT.push_back(-4360417971349577924);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.push_back(0.291593);
		}
		sbt_jNvv_9qas2jz2vItmlEwIwjXJ.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8RPVncJytCFj2kP *pObject = dynamic_cast<const sbt_8RPVncJytCFj2kP *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ZOH.size() != pObject->sbt_ZOH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZOH.size(); i++)
		{
			if (sbt_ZOH[i] != pObject->sbt_ZOH[i])
			{
				return false;
			}
		}
		if (sbt_25i.size() != pObject->sbt_25i.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_25i.size(); i++)
		{
			if (sbt_25i[i] != pObject->sbt_25i[i])
			{
				return false;
			}
		}
		if (sbt_xg2QDDi4JrS3Pm1NQpI != pObject->sbt_xg2QDDi4JrS3Pm1NQpI)
		{
			return false;
		}
		if (sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.size() != pObject->sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.size(); i++)
		{
			if (sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B[i] != pObject->sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B[i])
			{
				return false;
			}
		}
		if (sbt_rkHwukS != pObject->sbt_rkHwukS)
		{
			return false;
		}
		if (sbt_1iq3g != pObject->sbt_1iq3g)
		{
			return false;
		}
		if (sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW != pObject->sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW)
		{
			return false;
		}
		if (sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.size() != pObject->sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.size(); i++)
		{
			if (sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy[i] != pObject->sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy[i])
			{
				return false;
			}
		}
		if (sbt_VpnX8xv0ZBdrSSBtH.size() != pObject->sbt_VpnX8xv0ZBdrSSBtH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VpnX8xv0ZBdrSSBtH.size(); i++)
		{
			if (sbt_VpnX8xv0ZBdrSSBtH[i] != pObject->sbt_VpnX8xv0ZBdrSSBtH[i])
			{
				return false;
			}
		}
		if (sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih != pObject->sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih)
		{
			return false;
		}
		if (sbt_U.size() != pObject->sbt_U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U.size(); i++)
		{
			if (sbt_U[i] != pObject->sbt_U[i])
			{
				return false;
			}
		}
		if (sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM != pObject->sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM)
		{
			return false;
		}
		if (sbt_yPTv8hMhp4M0i != pObject->sbt_yPTv8hMhp4M0i)
		{
			return false;
		}
		if (sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw != pObject->sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw)
		{
			return false;
		}
		if (sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV != pObject->sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV)
		{
			return false;
		}
		if (sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.size() != pObject->sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.size(); i++)
		{
			if (sbt_LWUxfQEi_ZYZFJsvFsIUb0F66[i] != pObject->sbt_LWUxfQEi_ZYZFJsvFsIUb0F66[i])
			{
				return false;
			}
		}
		if (sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.size() != pObject->sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.size(); i++)
		{
			if (sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu[i] != pObject->sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu[i])
			{
				return false;
			}
		}
		if (sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH != pObject->sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH)
		{
			return false;
		}
		if (sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.size() != pObject->sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.size(); i++)
		{
			if (sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem[i] != pObject->sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem[i])
			{
				return false;
			}
		}
		if (sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx != pObject->sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx)
		{
			return false;
		}
		if (sbt_ZNArPXIgt24ehsHDJ.size() != pObject->sbt_ZNArPXIgt24ehsHDJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZNArPXIgt24ehsHDJ.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_ZNArPXIgt24ehsHDJ[i].c_str(), pObject->sbt_ZNArPXIgt24ehsHDJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_xsMvIt7nS905iZpYT.size() != pObject->sbt_xsMvIt7nS905iZpYT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xsMvIt7nS905iZpYT.size(); i++)
		{
			if (sbt_xsMvIt7nS905iZpYT[i] != pObject->sbt_xsMvIt7nS905iZpYT[i])
			{
				return false;
			}
		}
		if (sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.size() != pObject->sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.size(); i++)
		{
			if (sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB[i] != pObject->sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB[i])
			{
				return false;
			}
		}
		if (sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.size() != pObject->sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.size(); i++)
		{
			if (sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af[i] != pObject->sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af[i])
			{
				return false;
			}
		}
		if (!sbt_jNvv_9qas2jz2vItmlEwIwjXJ.Compare(&pObject->sbt_jNvv_9qas2jz2vItmlEwIwjXJ))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_ZOH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZOH.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_25i")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_25i.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xg2QDDi4JrS3Pm1NQpI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xg2QDDi4JrS3Pm1NQpI = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rkHwukS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rkHwukS = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_1iq3g", &sbt_1iq3g)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VpnX8xv0ZBdrSSBtH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VpnX8xv0ZBdrSSBtH.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_yPTv8hMhp4M0i", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yPTv8hMhp4M0i = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LWUxfQEi_ZYZFJsvFsIUb0F66")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZNArPXIgt24ehsHDJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZNArPXIgt24ehsHDJ.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xsMvIt7nS905iZpYT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xsMvIt7nS905iZpYT.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_jNvv_9qas2jz2vItmlEwIwjXJ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_jNvv_9qas2jz2vItmlEwIwjXJ.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_ZOH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ZOH.begin(); iter != sbt_ZOH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_25i")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_25i.begin(); iter != sbt_25i.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xg2QDDi4JrS3Pm1NQpI", (CX::Int64)sbt_xg2QDDi4JrS3Pm1NQpI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.begin(); iter != sbt_zWyiQdmKfw2YwJrTcYXKlxP21JLPP5B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rkHwukS", (CX::Int64)sbt_rkHwukS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_1iq3g", sbt_1iq3g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW", (CX::Int64)sbt_Qdhcr6fskZDQRWz9h9OPY39PISoeXvh77GpLGI3CbMpee7St87Iwse4cNv0iW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.begin(); iter != sbt_MAYkggHkKohnkugMRM0vVHMeZNeIrGV4hyt65S8OnclvnOaICmeoJrxpy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VpnX8xv0ZBdrSSBtH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_VpnX8xv0ZBdrSSBtH.begin(); iter != sbt_VpnX8xv0ZBdrSSBtH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih", (CX::Double)sbt_fSxwlYwmlXj_Aq8nZxeddabGbyYj4upXs6ey5Ih)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_U.begin(); iter != sbt_U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM", (CX::Int64)sbt_SDYUlDNmsFNKheGhs_2cfyHVFBDUB0EjIrZ6SexOaI7uElMRo1gsM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yPTv8hMhp4M0i", (CX::Int64)sbt_yPTv8hMhp4M0i)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw", (CX::Int64)sbt_fVjWBiu4mQ0ePDea3Hbhjju7EZdZC6Kzymw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV", (CX::Int64)sbt_bqZjfGm6GPlNF2UPrq1SUR8YOloLVG_XqIPgZWoAV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LWUxfQEi_ZYZFJsvFsIUb0F66")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.begin(); iter != sbt_LWUxfQEi_ZYZFJsvFsIUb0F66.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.begin(); iter != sbt_EWzrM9nnvDGmSEkEFy_RoT5L_w93M14sThaI3NPcu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH", (CX::Int64)sbt_SsmjCeRwuo_dUkI54c1d9xB1B8pP9qETV4d4o6YXxXaf05ea_HxdHZMni2IpptH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.begin(); iter != sbt_axzJipdz0qy0WUjQsZoDQQHPQFpOjaCXfem.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx", (CX::Int64)sbt_KHx5gxvguELtmBRNjNmSob02dLBPtJEEYMXMmoOxfhNxbFlbwF7gRFbEJbFI6Vx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZNArPXIgt24ehsHDJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_ZNArPXIgt24ehsHDJ.begin(); iter != sbt_ZNArPXIgt24ehsHDJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xsMvIt7nS905iZpYT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_xsMvIt7nS905iZpYT.begin(); iter != sbt_xsMvIt7nS905iZpYT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.begin(); iter != sbt_OGhr0AyiVdVsGHogbe7PzlAwXQT3V4kpmXqMuJoqg56pbkCnAaB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.begin(); iter != sbt_TGFXWmwZtxpX0U24SKJg1kHIcDQ62YmWBZqUgsQipWeVaCJFYPGR8Af.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_jNvv_9qas2jz2vItmlEwIwjXJ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_jNvv_9qas2jz2vItmlEwIwjXJ.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8RPVncJytCFj2kP>::Type sbt_8RPVncJytCFj2kPArray;

