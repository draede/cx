
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_IEcPBwJwXG83EtM1Q2f : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_J;
	CX::IO::SimpleBuffers::Int16Array sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z;
	CX::IO::SimpleBuffers::UInt32Array sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj;
	CX::UInt8 sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy;
	CX::UInt16 sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm;
	CX::String sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y;
	CX::UInt8 sbt__VTdveoU1_Qa7qhoNw6lPZX;
	CX::UInt32 sbt_Qxxa8vDzt;
	CX::IO::SimpleBuffers::StringArray sbt_sHn27E1WkQ819UfLhKpWVyo;
	CX::IO::SimpleBuffers::Int64Array sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX;
	CX::UInt64 sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_;

	virtual void Reset()
	{
		sbt_J.clear();
		sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.clear();
		sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.clear();
		sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy = 0;
		sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm = 0;
		sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y.clear();
		sbt__VTdveoU1_Qa7qhoNw6lPZX = 0;
		sbt_Qxxa8vDzt = 0;
		sbt_sHn27E1WkQ819UfLhKpWVyo.clear();
		sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.clear();
		sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_ = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_J.push_back(-6043723079299731976);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.push_back(28225);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.push_back(475713444);
		}
		sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy = 127;
		sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm = 13825;
		sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y = "Gtk0Oit`?>0-U`xb_hV";
		sbt__VTdveoU1_Qa7qhoNw6lPZX = 79;
		sbt_Qxxa8vDzt = 933943607;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_sHn27E1WkQ819UfLhKpWVyo.push_back("H]o/.[B$(E");
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.push_back(6646530641249043930);
		}
		sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_ = 17930567669672733476;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_IEcPBwJwXG83EtM1Q2f *pObject = dynamic_cast<const sbt_IEcPBwJwXG83EtM1Q2f *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_J.size() != pObject->sbt_J.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J.size(); i++)
		{
			if (sbt_J[i] != pObject->sbt_J[i])
			{
				return false;
			}
		}
		if (sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.size() != pObject->sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.size(); i++)
		{
			if (sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z[i] != pObject->sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z[i])
			{
				return false;
			}
		}
		if (sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.size() != pObject->sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.size(); i++)
		{
			if (sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj[i] != pObject->sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj[i])
			{
				return false;
			}
		}
		if (sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy != pObject->sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy)
		{
			return false;
		}
		if (sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm != pObject->sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y.c_str(), pObject->sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y.c_str()))
		{
			return false;
		}
		if (sbt__VTdveoU1_Qa7qhoNw6lPZX != pObject->sbt__VTdveoU1_Qa7qhoNw6lPZX)
		{
			return false;
		}
		if (sbt_Qxxa8vDzt != pObject->sbt_Qxxa8vDzt)
		{
			return false;
		}
		if (sbt_sHn27E1WkQ819UfLhKpWVyo.size() != pObject->sbt_sHn27E1WkQ819UfLhKpWVyo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sHn27E1WkQ819UfLhKpWVyo.size(); i++)
		{
			if (0 != cx_strcmp(sbt_sHn27E1WkQ819UfLhKpWVyo[i].c_str(), pObject->sbt_sHn27E1WkQ819UfLhKpWVyo[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.size() != pObject->sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.size(); i++)
		{
			if (sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX[i] != pObject->sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX[i])
			{
				return false;
			}
		}
		if (sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_ != pObject->sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_J")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y", &sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__VTdveoU1_Qa7qhoNw6lPZX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__VTdveoU1_Qa7qhoNw6lPZX = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Qxxa8vDzt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qxxa8vDzt = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sHn27E1WkQ819UfLhKpWVyo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sHn27E1WkQ819UfLhKpWVyo.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_ = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_J")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_J.begin(); iter != sbt_J.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.begin(); iter != sbt_VgSi6cm8JEf3JLwbnfg2C1QkdKRLwEGPy7Fzg44qHY9_Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.begin(); iter != sbt_EGxr2tDTVyKlcanxxRGKUVf6yREDr2Y6shZQcOT8AiZuMQUKnER9Ke5Qj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy", (CX::Int64)sbt_l6v60B9dotN2X0HmfdgfgeKvuAhoShtwFW0ebhQBNjgMy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm", (CX::Int64)sbt_hBjnjEIuqih9DLVyv8JarljEicF8aWn3YxMOsnrjpiGIfYm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y", sbt_VD2LMgw0_T8PN3oeGwrUELJzKc53S1Ish91BX2Y.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__VTdveoU1_Qa7qhoNw6lPZX", (CX::Int64)sbt__VTdveoU1_Qa7qhoNw6lPZX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Qxxa8vDzt", (CX::Int64)sbt_Qxxa8vDzt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sHn27E1WkQ819UfLhKpWVyo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_sHn27E1WkQ819UfLhKpWVyo.begin(); iter != sbt_sHn27E1WkQ819UfLhKpWVyo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.begin(); iter != sbt_OH6_jcuh95GiqekcQAArIr8xs6VK_1TMEXulWAZa8RRI1FX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_", (CX::Int64)sbt_fyRozLJB7GDm9Kwojlly0fpEl6wQZqWWZe6_UcvS_)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_IEcPBwJwXG83EtM1Q2f>::Type sbt_IEcPBwJwXG83EtM1Q2fArray;

