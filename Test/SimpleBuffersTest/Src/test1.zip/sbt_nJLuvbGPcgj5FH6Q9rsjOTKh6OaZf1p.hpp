
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_IEcPBwJwXG83EtM1Q2f.hpp"


class sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_yST;
	CX::Bool sbt_6VftV3F1i4yb1ShjK5yXz;
	CX::IO::SimpleBuffers::Int32Array sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp;
	CX::Int8 sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip;
	CX::UInt8 sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb;
	CX::IO::SimpleBuffers::Int64Array sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX;
	CX::IO::SimpleBuffers::UInt8Array sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N;
	CX::IO::SimpleBuffers::UInt32Array sbt_K;
	CX::UInt8 sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7;
	CX::IO::SimpleBuffers::WStringArray sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh;
	CX::Bool sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC;
	CX::IO::SimpleBuffers::WStringArray sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM;
	CX::IO::SimpleBuffers::UInt16Array sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV;
	CX::IO::SimpleBuffers::UInt8Array sbt_s2Dmk1_WPy82Gym2D0WNu;
	sbt_IEcPBwJwXG83EtM1Q2f sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa;

	virtual void Reset()
	{
		sbt_yST.clear();
		sbt_6VftV3F1i4yb1ShjK5yXz = false;
		sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.clear();
		sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip = 0;
		sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb = 0;
		sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.clear();
		sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.clear();
		sbt_K.clear();
		sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7 = 0;
		sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.clear();
		sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC = false;
		sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.clear();
		sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.clear();
		sbt_s2Dmk1_WPy82Gym2D0WNu.clear();
		sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_yST = L"Kh(|8_vHFGqMM{cRB%#PwJD&?wT0b04CbjkPeWY";
		sbt_6VftV3F1i4yb1ShjK5yXz = true;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.push_back(-229355111);
		}
		sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip = 1;
		sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb = 232;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.push_back(-1362964885628030580);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.push_back(160);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_K.push_back(3793421176);
		}
		sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7 = 137;
		sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC = true;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.push_back(L"Y*ZN\\Ug3$ZR:(C~tY!XEk&6a+gwl`9b9g(L:3N@OYkqhf");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.push_back(49280);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_s2Dmk1_WPy82Gym2D0WNu.push_back(244);
		}
		sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p *pObject = dynamic_cast<const sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_yST.c_str(), pObject->sbt_yST.c_str()))
		{
			return false;
		}
		if (sbt_6VftV3F1i4yb1ShjK5yXz != pObject->sbt_6VftV3F1i4yb1ShjK5yXz)
		{
			return false;
		}
		if (sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.size() != pObject->sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.size(); i++)
		{
			if (sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp[i] != pObject->sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp[i])
			{
				return false;
			}
		}
		if (sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip != pObject->sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip)
		{
			return false;
		}
		if (sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb != pObject->sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb)
		{
			return false;
		}
		if (sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.size() != pObject->sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.size(); i++)
		{
			if (sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX[i] != pObject->sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX[i])
			{
				return false;
			}
		}
		if (sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.size() != pObject->sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.size(); i++)
		{
			if (sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N[i] != pObject->sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N[i])
			{
				return false;
			}
		}
		if (sbt_K.size() != pObject->sbt_K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_K.size(); i++)
		{
			if (sbt_K[i] != pObject->sbt_K[i])
			{
				return false;
			}
		}
		if (sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7 != pObject->sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7)
		{
			return false;
		}
		if (sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.size() != pObject->sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh[i].c_str(), pObject->sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC != pObject->sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC)
		{
			return false;
		}
		if (sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.size() != pObject->sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM[i].c_str(), pObject->sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.size() != pObject->sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.size(); i++)
		{
			if (sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV[i] != pObject->sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV[i])
			{
				return false;
			}
		}
		if (sbt_s2Dmk1_WPy82Gym2D0WNu.size() != pObject->sbt_s2Dmk1_WPy82Gym2D0WNu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s2Dmk1_WPy82Gym2D0WNu.size(); i++)
		{
			if (sbt_s2Dmk1_WPy82Gym2D0WNu[i] != pObject->sbt_s2Dmk1_WPy82Gym2D0WNu[i])
			{
				return false;
			}
		}
		if (!sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa.Compare(&pObject->sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_yST", &sbt_yST)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_6VftV3F1i4yb1ShjK5yXz", &sbt_6VftV3F1i4yb1ShjK5yXz)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_K.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC", &sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s2Dmk1_WPy82Gym2D0WNu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s2Dmk1_WPy82Gym2D0WNu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_yST", sbt_yST.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_6VftV3F1i4yb1ShjK5yXz", sbt_6VftV3F1i4yb1ShjK5yXz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.begin(); iter != sbt_6fKkLX5W4ZXlbGBKvWE7RhmWogvt7y0wOjU_7nhikElpEJilF8qJJfd3gwp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip", (CX::Int64)sbt_G4ZeOhY27JyPoM2ZVAaZMERFh22Ip)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb", (CX::Int64)sbt_XZaXxjZnHXrL_aD43wHzbIIR855YWRL9Hvb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.begin(); iter != sbt_GeTYpQB059ELACYOxqr7w4HIlKr7iI3Acq7LP9BrqBX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.begin(); iter != sbt_itNZofq0vgzegeZ6NlGxh1BfGjmSvb20Vnmko1N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_K.begin(); iter != sbt_K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7", (CX::Int64)sbt_sfq8z0ZY03iw3tYjhE4ea9O92l7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.begin(); iter != sbt_f_esMkEHwtM4t32_TSKGrGic3jNHZyYMe3kZnYZOhRmoh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC", sbt_Pu5Jp2T9xsq0tCIHXet_RL7Siy8DDuq5w8ZXV8GSArU18keIgCC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.begin(); iter != sbt_BZl81W0dCyUOnuaQBH4Jg3jzy6AMqJmvlKY_4RV4tzzfM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.begin(); iter != sbt_Nf3Uen6qksqlvRLL1TIRS86uY1PhdGIG8Pkm_Qv1CamdRAWrAAjnX5b4jGReV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s2Dmk1_WPy82Gym2D0WNu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_s2Dmk1_WPy82Gym2D0WNu.begin(); iter != sbt_s2Dmk1_WPy82Gym2D0WNu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_j27jUea_QjxrxLj2YuZ8V2dquBLRa.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p>::Type sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1pArray;

