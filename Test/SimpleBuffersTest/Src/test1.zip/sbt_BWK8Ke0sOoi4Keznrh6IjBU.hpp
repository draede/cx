
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud.hpp"


class sbt_BWK8Ke0sOoi4Keznrh6IjBU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_rAV;
	CX::IO::SimpleBuffers::Int16Array sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D;
	CX::Bool sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a;
	CX::IO::SimpleBuffers::UInt32Array sbt_a;
	CX::Double sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma;
	CX::Bool sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo;
	CX::Int16 sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn;
	CX::UInt8 sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI;
	CX::Bool sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F;
	CX::Double sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_;
	CX::Double sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV;
	CX::Float sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr;
	CX::UInt8 sbt_U;
	CX::IO::SimpleBuffers::DoubleArray sbt_5w1FZujmSrD;
	CX::IO::SimpleBuffers::DoubleArray sbt_zmgyR02hPm_p49mx2YQ;
	CX::IO::SimpleBuffers::BoolArray sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6;
	sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6udArray sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_;

	virtual void Reset()
	{
		sbt_rAV = false;
		sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.clear();
		sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a = false;
		sbt_a.clear();
		sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma = 0.0;
		sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo = false;
		sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn = 0;
		sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI = 0;
		sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F = false;
		sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_ = 0.0;
		sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV = 0.0;
		sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr = 0.0f;
		sbt_U = 0;
		sbt_5w1FZujmSrD.clear();
		sbt_zmgyR02hPm_p49mx2YQ.clear();
		sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.clear();
		sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_rAV = false;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.push_back(-22310);
		}
		sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a = true;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_a.push_back(2854773287);
		}
		sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma = 0.381722;
		sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo = false;
		sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn = -8346;
		sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI = 132;
		sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F = false;
		sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_ = 0.213416;
		sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV = 0.995336;
		sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr = 0.230956f;
		sbt_U = 234;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_5w1FZujmSrD.push_back(0.136946);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_zmgyR02hPm_p49mx2YQ.push_back(0.545273);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.push_back(true);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud v;

			v.SetupWithSomeValues();
			sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_BWK8Ke0sOoi4Keznrh6IjBU *pObject = dynamic_cast<const sbt_BWK8Ke0sOoi4Keznrh6IjBU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_rAV != pObject->sbt_rAV)
		{
			return false;
		}
		if (sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.size() != pObject->sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.size(); i++)
		{
			if (sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D[i] != pObject->sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D[i])
			{
				return false;
			}
		}
		if (sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a != pObject->sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a)
		{
			return false;
		}
		if (sbt_a.size() != pObject->sbt_a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a.size(); i++)
		{
			if (sbt_a[i] != pObject->sbt_a[i])
			{
				return false;
			}
		}
		if (sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma != pObject->sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma)
		{
			return false;
		}
		if (sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo != pObject->sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo)
		{
			return false;
		}
		if (sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn != pObject->sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn)
		{
			return false;
		}
		if (sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI != pObject->sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI)
		{
			return false;
		}
		if (sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F != pObject->sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F)
		{
			return false;
		}
		if (sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_ != pObject->sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_)
		{
			return false;
		}
		if (sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV != pObject->sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV)
		{
			return false;
		}
		if (sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr != pObject->sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr)
		{
			return false;
		}
		if (sbt_U != pObject->sbt_U)
		{
			return false;
		}
		if (sbt_5w1FZujmSrD.size() != pObject->sbt_5w1FZujmSrD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5w1FZujmSrD.size(); i++)
		{
			if (sbt_5w1FZujmSrD[i] != pObject->sbt_5w1FZujmSrD[i])
			{
				return false;
			}
		}
		if (sbt_zmgyR02hPm_p49mx2YQ.size() != pObject->sbt_zmgyR02hPm_p49mx2YQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zmgyR02hPm_p49mx2YQ.size(); i++)
		{
			if (sbt_zmgyR02hPm_p49mx2YQ[i] != pObject->sbt_zmgyR02hPm_p49mx2YQ[i])
			{
				return false;
			}
		}
		if (sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.size() != pObject->sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.size(); i++)
		{
			if (sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6[i] != pObject->sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6[i])
			{
				return false;
			}
		}
		if (sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.size() != pObject->sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.size(); i++)
		{
			if (!sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_[i].Compare(&pObject->sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_rAV", &sbt_rAV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a", &sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo", &sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F", &sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_ = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_U", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_U = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5w1FZujmSrD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5w1FZujmSrD.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zmgyR02hPm_p49mx2YQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zmgyR02hPm_p49mx2YQ.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_rAV", sbt_rAV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.begin(); iter != sbt_HZs6mxXgjCnWtkcfDtNUeHd40TM4zGJpHe4o59D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a", sbt_XNASLGNSvCNYBQuuRzeDlEFF8qXhlPKVXHWbc0qpQDa8fb9rd1a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_a.begin(); iter != sbt_a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma", (CX::Double)sbt_DEo3UPdvN5GEuj4APij8MM5ZolEksiVf3_CZmTO8Qma)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo", sbt_yJWJGbCSCiqY2MCl35Ns2HaCqVLDNz1jHz4XvL17W5KaJbToo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn", (CX::Int64)sbt_vNJbN2a1NKRBl7eWW49u0A_Vqqq04k8C1ZOtpVtYh7iMKAQGn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI", (CX::Int64)sbt_rUtQEsFRNwtuN2Z2yt6AbGUF5lPwVCcbl5vIICjXcpI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F", sbt_A4CiY3X9FmlyiItTDTjZnEDGWJqtvYzSOQQLihuRmYM3m3074leNT1F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_", (CX::Double)sbt_WMcYHK3smFJquXDwlPgjMs28E1__2KbGbD2EzEnymLDQEWTLk8Y_jcoMgKP5_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV", (CX::Double)sbt_sZVTWYfC8W2JZjL54ey2_wD4keh7VMT_Pr7y5gabvREIV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr", (CX::Double)sbt_YXTJILhuHvnYz0QqpEba54SUcjyxp7jz0ovwb65CwaJiTR4tr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_U", (CX::Int64)sbt_U)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5w1FZujmSrD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_5w1FZujmSrD.begin(); iter != sbt_5w1FZujmSrD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zmgyR02hPm_p49mx2YQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_zmgyR02hPm_p49mx2YQ.begin(); iter != sbt_zmgyR02hPm_p49mx2YQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.begin(); iter != sbt_cvqnyQiPE2HgDduz47YR42WYwugqCJiWMw5nT7Ny6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_")).IsNOK())
		{
			return status;
		}
		for (sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6udArray::const_iterator iter = sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.begin(); iter != sbt_k2FgAmNDA3Ayi26lWIWBqI3yV7_hn95ah2uWZuUXv5G2JwwE_.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_BWK8Ke0sOoi4Keznrh6IjBU>::Type sbt_BWK8Ke0sOoi4Keznrh6IjBUArray;

