
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26.hpp"


class sbt_4fXNpeqibRq0CYZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG;
	CX::Float sbt_41o85R_c9Ntg0Rp27;
	CX::Int32 sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz;
	CX::IO::SimpleBuffers::Int64Array sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j;
	CX::String sbt_quM243VSy;
	CX::IO::SimpleBuffers::StringArray sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ;
	CX::IO::SimpleBuffers::UInt16Array sbt_P;
	CX::UInt8 sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz;
	CX::IO::SimpleBuffers::UInt8Array sbt_3sE;
	CX::Int8 sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP;
	CX::Double sbt_DRk7anqnrbKdI;
	CX::Int8 sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh;
	CX::UInt8 sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq;
	CX::UInt8 sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF;
	CX::IO::SimpleBuffers::DoubleArray sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY;
	CX::WString sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD;
	CX::IO::SimpleBuffers::DoubleArray sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj;
	CX::Double sbt_cg3d4_e;
	CX::Int16 sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf;
	CX::IO::SimpleBuffers::UInt8Array sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on;
	sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26Array sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR;

	virtual void Reset()
	{
		sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.clear();
		sbt_41o85R_c9Ntg0Rp27 = 0.0f;
		sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz = 0;
		sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.clear();
		sbt_quM243VSy.clear();
		sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.clear();
		sbt_P.clear();
		sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz = 0;
		sbt_3sE.clear();
		sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP = 0;
		sbt_DRk7anqnrbKdI = 0.0;
		sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh = 0;
		sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq = 0;
		sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF = 0;
		sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.clear();
		sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD.clear();
		sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.clear();
		sbt_cg3d4_e = 0.0;
		sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf = 0;
		sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.clear();
		sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.push_back("CVm+7B`'?Y2}kFXX~I6^RR(yyK");
		}
		sbt_41o85R_c9Ntg0Rp27 = 0.042568f;
		sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz = 332861655;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.push_back(5277149524941497914);
		}
		sbt_quM243VSy = "?<#):`q'@gK6/R:sMC0nF!B7J4e]vBVOtr;XM~domB\\WyzRllWJTX";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.push_back("?DGPE\\%ujrxG7?EY+5RN_u_Dfpw'`T=!vF");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_P.push_back(46544);
		}
		sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz = 233;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_3sE.push_back(17);
		}
		sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP = 72;
		sbt_DRk7anqnrbKdI = 0.196112;
		sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh = -82;
		sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq = 244;
		sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF = 96;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.push_back(0.567577);
		}
		sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD = L";!ZaP6)0~|efn~TW{{?0O#ZM&v+b&muz4|7GAx";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.push_back(0.988446);
		}
		sbt_cg3d4_e = 0.828635;
		sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf = -4770;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.push_back(84);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26 v;

			v.SetupWithSomeValues();
			sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4fXNpeqibRq0CYZ *pObject = dynamic_cast<const sbt_4fXNpeqibRq0CYZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.size() != pObject->sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.size(); i++)
		{
			if (0 != cx_strcmp(sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG[i].c_str(), pObject->sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_41o85R_c9Ntg0Rp27 != pObject->sbt_41o85R_c9Ntg0Rp27)
		{
			return false;
		}
		if (sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz != pObject->sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz)
		{
			return false;
		}
		if (sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.size() != pObject->sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.size(); i++)
		{
			if (sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j[i] != pObject->sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_quM243VSy.c_str(), pObject->sbt_quM243VSy.c_str()))
		{
			return false;
		}
		if (sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.size() != pObject->sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ[i].c_str(), pObject->sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_P.size() != pObject->sbt_P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P.size(); i++)
		{
			if (sbt_P[i] != pObject->sbt_P[i])
			{
				return false;
			}
		}
		if (sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz != pObject->sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz)
		{
			return false;
		}
		if (sbt_3sE.size() != pObject->sbt_3sE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3sE.size(); i++)
		{
			if (sbt_3sE[i] != pObject->sbt_3sE[i])
			{
				return false;
			}
		}
		if (sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP != pObject->sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP)
		{
			return false;
		}
		if (sbt_DRk7anqnrbKdI != pObject->sbt_DRk7anqnrbKdI)
		{
			return false;
		}
		if (sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh != pObject->sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh)
		{
			return false;
		}
		if (sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq != pObject->sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq)
		{
			return false;
		}
		if (sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF != pObject->sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF)
		{
			return false;
		}
		if (sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.size() != pObject->sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.size(); i++)
		{
			if (sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY[i] != pObject->sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD.c_str(), pObject->sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD.c_str()))
		{
			return false;
		}
		if (sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.size() != pObject->sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.size(); i++)
		{
			if (sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj[i] != pObject->sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj[i])
			{
				return false;
			}
		}
		if (sbt_cg3d4_e != pObject->sbt_cg3d4_e)
		{
			return false;
		}
		if (sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf != pObject->sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf)
		{
			return false;
		}
		if (sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.size() != pObject->sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.size(); i++)
		{
			if (sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on[i] != pObject->sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on[i])
			{
				return false;
			}
		}
		if (sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.size() != pObject->sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.size(); i++)
		{
			if (!sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR[i].Compare(&pObject->sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_41o85R_c9Ntg0Rp27", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_41o85R_c9Ntg0Rp27 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_quM243VSy", &sbt_quM243VSy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3sE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3sE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_DRk7anqnrbKdI", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_DRk7anqnrbKdI = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD", &sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_cg3d4_e", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_cg3d4_e = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.begin(); iter != sbt_wsJEsAo_yVvblsSwdmofi_F3DkXgah1XJSychwBkdddUMn54QyG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_41o85R_c9Ntg0Rp27", (CX::Double)sbt_41o85R_c9Ntg0Rp27)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz", (CX::Int64)sbt_vJP_NQo4hlg3TyoV905MUTkk0xlZREfkW7r3lRt0isz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.begin(); iter != sbt_wrin2SKtJQfTArvdGOKVo2CTd7v3VpjKkgh_j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_quM243VSy", sbt_quM243VSy.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.begin(); iter != sbt_tv1sMgOEoBEaJ93Gh1PcwoRimIdiDxchZeQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_P.begin(); iter != sbt_P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz", (CX::Int64)sbt_1MJs9MagQtGbVZDiPRx61i8Eic5mwHRSHrdTaar1gczbmehH8tz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3sE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_3sE.begin(); iter != sbt_3sE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP", (CX::Int64)sbt_8qeEJTX4_6wxXlSD2rCtpfcY0ySAyQeMP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_DRk7anqnrbKdI", (CX::Double)sbt_DRk7anqnrbKdI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh", (CX::Int64)sbt__IwOqztoJQwlPbANckNW_Mt2uYWo_WQp7uswh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq", (CX::Int64)sbt_Ux8Q95QXL5Q0lSU09gIqhGgLLhSMH0M0pq0ELK0RwDodEja75oAGq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF", (CX::Int64)sbt_EP3m8ZE1ZEEDbF_ACEuKAZDYnkl1y74Ad_PdvsbymupyF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.begin(); iter != sbt_7re1hqjXgMac7hZbF_TjgUxwuUyCAfGW6ygAJwDNY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD", sbt_COl1r3UvrkGG1YU1WHCwBPJqbGazD.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.begin(); iter != sbt_R5VjgfD0EHxZYurBRdtxArwhFl8uwU8PDTGAj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_cg3d4_e", (CX::Double)sbt_cg3d4_e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf", (CX::Int64)sbt_Fe6T9cXaXPAuJxVjf4ciO2Hobg8A_X5jU0Nbf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.begin(); iter != sbt_xKVUX7EL6w_9nKhNKgMPuF_QVda4Xywmcvtl7Vt3AANrBmeJlESmLFZ58F0on.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR")).IsNOK())
		{
			return status;
		}
		for (sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26Array::const_iterator iter = sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.begin(); iter != sbt_aguwMZ0wY9Pu3xgkJTo0qL_qkWJyHLr34BzLNty7tmMyEv1EIgoiR.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4fXNpeqibRq0CYZ>::Type sbt_4fXNpeqibRq0CYZArray;

