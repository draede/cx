
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph;
	CX::IO::SimpleBuffers::Int64Array sbt_2;
	CX::UInt32 sbt_A4BDyDWXCPOxG90Lr4w;
	CX::IO::SimpleBuffers::UInt8Array sbt_Ns8VRicTIiS;
	CX::IO::SimpleBuffers::StringArray sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK;
	CX::String sbt_BpAeoFf9qP1k11GAKDWhSkR;
	CX::UInt16 sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf;
	CX::Int64 sbt_G3feI5nlqg0TD9twzu0JJp1;
	CX::Int32 sbt_YvYRdTQPVZCVeX3;
	CX::IO::SimpleBuffers::UInt64Array sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l;
	CX::IO::SimpleBuffers::BoolArray sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN;
	CX::UInt32 sbt_RgJ6tgk;
	CX::UInt32 sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5;
	CX::IO::SimpleBuffers::Int32Array sbt_Vv58hiGc8MTkCr6BzXS;
	CX::IO::SimpleBuffers::UInt8Array sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c;

	virtual void Reset()
	{
		sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph = 0;
		sbt_2.clear();
		sbt_A4BDyDWXCPOxG90Lr4w = 0;
		sbt_Ns8VRicTIiS.clear();
		sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.clear();
		sbt_BpAeoFf9qP1k11GAKDWhSkR.clear();
		sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf = 0;
		sbt_G3feI5nlqg0TD9twzu0JJp1 = 0;
		sbt_YvYRdTQPVZCVeX3 = 0;
		sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.clear();
		sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.clear();
		sbt_RgJ6tgk = 0;
		sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5 = 0;
		sbt_Vv58hiGc8MTkCr6BzXS.clear();
		sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph = 5482555000872368934;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_2.push_back(-4446870930776011012);
		}
		sbt_A4BDyDWXCPOxG90Lr4w = 3598845986;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Ns8VRicTIiS.push_back(219);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.push_back("sB+-Ap=cYH5");
		}
		sbt_BpAeoFf9qP1k11GAKDWhSkR = "%df+)_1*ry#%sG4vEon^vj>";
		sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf = 5733;
		sbt_G3feI5nlqg0TD9twzu0JJp1 = 5176044033699491550;
		sbt_YvYRdTQPVZCVeX3 = -758551845;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.push_back(5041228884800843716);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.push_back(false);
		}
		sbt_RgJ6tgk = 1134720504;
		sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5 = 986221223;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Vv58hiGc8MTkCr6BzXS.push_back(1405686143);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.push_back(145);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu *pObject = dynamic_cast<const sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph != pObject->sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph)
		{
			return false;
		}
		if (sbt_2.size() != pObject->sbt_2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2.size(); i++)
		{
			if (sbt_2[i] != pObject->sbt_2[i])
			{
				return false;
			}
		}
		if (sbt_A4BDyDWXCPOxG90Lr4w != pObject->sbt_A4BDyDWXCPOxG90Lr4w)
		{
			return false;
		}
		if (sbt_Ns8VRicTIiS.size() != pObject->sbt_Ns8VRicTIiS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ns8VRicTIiS.size(); i++)
		{
			if (sbt_Ns8VRicTIiS[i] != pObject->sbt_Ns8VRicTIiS[i])
			{
				return false;
			}
		}
		if (sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.size() != pObject->sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.size(); i++)
		{
			if (0 != cx_strcmp(sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK[i].c_str(), pObject->sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_BpAeoFf9qP1k11GAKDWhSkR.c_str(), pObject->sbt_BpAeoFf9qP1k11GAKDWhSkR.c_str()))
		{
			return false;
		}
		if (sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf != pObject->sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf)
		{
			return false;
		}
		if (sbt_G3feI5nlqg0TD9twzu0JJp1 != pObject->sbt_G3feI5nlqg0TD9twzu0JJp1)
		{
			return false;
		}
		if (sbt_YvYRdTQPVZCVeX3 != pObject->sbt_YvYRdTQPVZCVeX3)
		{
			return false;
		}
		if (sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.size() != pObject->sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.size(); i++)
		{
			if (sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l[i] != pObject->sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l[i])
			{
				return false;
			}
		}
		if (sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.size() != pObject->sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.size(); i++)
		{
			if (sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN[i] != pObject->sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN[i])
			{
				return false;
			}
		}
		if (sbt_RgJ6tgk != pObject->sbt_RgJ6tgk)
		{
			return false;
		}
		if (sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5 != pObject->sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5)
		{
			return false;
		}
		if (sbt_Vv58hiGc8MTkCr6BzXS.size() != pObject->sbt_Vv58hiGc8MTkCr6BzXS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Vv58hiGc8MTkCr6BzXS.size(); i++)
		{
			if (sbt_Vv58hiGc8MTkCr6BzXS[i] != pObject->sbt_Vv58hiGc8MTkCr6BzXS[i])
			{
				return false;
			}
		}
		if (sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.size() != pObject->sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.size(); i++)
		{
			if (sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c[i] != pObject->sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A4BDyDWXCPOxG90Lr4w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A4BDyDWXCPOxG90Lr4w = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Ns8VRicTIiS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ns8VRicTIiS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_BpAeoFf9qP1k11GAKDWhSkR", &sbt_BpAeoFf9qP1k11GAKDWhSkR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_G3feI5nlqg0TD9twzu0JJp1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G3feI5nlqg0TD9twzu0JJp1 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YvYRdTQPVZCVeX3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YvYRdTQPVZCVeX3 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_RgJ6tgk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RgJ6tgk = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Vv58hiGc8MTkCr6BzXS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Vv58hiGc8MTkCr6BzXS.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph", (CX::Int64)sbt_2IiIvD15iKgCLBc4RXL4wArXenxnc9CrF35tyso4tUIuVnANdu8ph)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_2.begin(); iter != sbt_2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A4BDyDWXCPOxG90Lr4w", (CX::Int64)sbt_A4BDyDWXCPOxG90Lr4w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ns8VRicTIiS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Ns8VRicTIiS.begin(); iter != sbt_Ns8VRicTIiS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.begin(); iter != sbt_jIO5p0IfwpnvwMlUTvV7CVr45pj7zIJaSdYEnsjmhCVAyeqQRNK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_BpAeoFf9qP1k11GAKDWhSkR", sbt_BpAeoFf9qP1k11GAKDWhSkR.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf", (CX::Int64)sbt_Gecv4gRXyYxdWRTZYyaCewW597MbE2mJUNnS73XMOGBitum8MToUaczeidXdf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G3feI5nlqg0TD9twzu0JJp1", (CX::Int64)sbt_G3feI5nlqg0TD9twzu0JJp1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YvYRdTQPVZCVeX3", (CX::Int64)sbt_YvYRdTQPVZCVeX3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.begin(); iter != sbt_yroZPbUQTgUkL6Z1LrYODo4dkNA6EfcSCXfRlvqSUot6ZfR1VjgwU3l.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.begin(); iter != sbt_syUN1P_Hk0J7lk0b7fisfYbysDsujFAA1itnR12X7kcSR4XShwOXLP60KgC7daN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RgJ6tgk", (CX::Int64)sbt_RgJ6tgk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5", (CX::Int64)sbt_fUH60Vr0CCJKLzfolNl3B_OwyPErzBym5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Vv58hiGc8MTkCr6BzXS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Vv58hiGc8MTkCr6BzXS.begin(); iter != sbt_Vv58hiGc8MTkCr6BzXS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.begin(); iter != sbt_k9uNQFUS3GDI8QzpYGOBYzsbR12BcJvPXiiCQSmdCWy2c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu>::Type sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPuArray;

