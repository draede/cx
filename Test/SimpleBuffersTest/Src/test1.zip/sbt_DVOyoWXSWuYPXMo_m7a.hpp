
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK.hpp"


class sbt_DVOyoWXSWuYPXMo_m7a : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw;
	CX::String sbt_T3Snpp4kpNK;
	CX::UInt8 sbt_rxN4V;
	CX::Int8 sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ;
	CX::IO::SimpleBuffers::Int8Array sbt_Ll8QgvaNm7T7JcB;
	CX::IO::SimpleBuffers::UInt16Array sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8;
	CX::IO::SimpleBuffers::UInt8Array sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla;
	CX::Int8 sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp;
	CX::IO::SimpleBuffers::UInt8Array sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX;
	CX::String sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC;
	CX::Double sbt_BzXNE6ZUzNavXwWaMxM;
	sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTKArray sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2;

	virtual void Reset()
	{
		sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw = 0;
		sbt_T3Snpp4kpNK.clear();
		sbt_rxN4V = 0;
		sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ = 0;
		sbt_Ll8QgvaNm7T7JcB.clear();
		sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.clear();
		sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.clear();
		sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp = 0;
		sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.clear();
		sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC.clear();
		sbt_BzXNE6ZUzNavXwWaMxM = 0.0;
		sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw = 15291817460055442776;
		sbt_T3Snpp4kpNK = "c$8-u(o%7P[xrwegy{pid!=1~*DdptPVb>Q4jVS~?c~`_>R\"D*9Z5I7k8yD`[;Il";
		sbt_rxN4V = 53;
		sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ = -22;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Ll8QgvaNm7T7JcB.push_back(-81);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.push_back(106);
		}
		sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp = -20;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.push_back(60);
		}
		sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC = "[O-Kpr[]sBP#rl?^-!R";
		sbt_BzXNE6ZUzNavXwWaMxM = 0.285490;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK v;

			v.SetupWithSomeValues();
			sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_DVOyoWXSWuYPXMo_m7a *pObject = dynamic_cast<const sbt_DVOyoWXSWuYPXMo_m7a *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw != pObject->sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_T3Snpp4kpNK.c_str(), pObject->sbt_T3Snpp4kpNK.c_str()))
		{
			return false;
		}
		if (sbt_rxN4V != pObject->sbt_rxN4V)
		{
			return false;
		}
		if (sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ != pObject->sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ)
		{
			return false;
		}
		if (sbt_Ll8QgvaNm7T7JcB.size() != pObject->sbt_Ll8QgvaNm7T7JcB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ll8QgvaNm7T7JcB.size(); i++)
		{
			if (sbt_Ll8QgvaNm7T7JcB[i] != pObject->sbt_Ll8QgvaNm7T7JcB[i])
			{
				return false;
			}
		}
		if (sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.size() != pObject->sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.size(); i++)
		{
			if (sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8[i] != pObject->sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8[i])
			{
				return false;
			}
		}
		if (sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.size() != pObject->sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.size(); i++)
		{
			if (sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla[i] != pObject->sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla[i])
			{
				return false;
			}
		}
		if (sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp != pObject->sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp)
		{
			return false;
		}
		if (sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.size() != pObject->sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.size(); i++)
		{
			if (sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX[i] != pObject->sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC.c_str(), pObject->sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC.c_str()))
		{
			return false;
		}
		if (sbt_BzXNE6ZUzNavXwWaMxM != pObject->sbt_BzXNE6ZUzNavXwWaMxM)
		{
			return false;
		}
		if (sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.size() != pObject->sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.size(); i++)
		{
			if (!sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2[i].Compare(&pObject->sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_T3Snpp4kpNK", &sbt_T3Snpp4kpNK)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rxN4V", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rxN4V = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Ll8QgvaNm7T7JcB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ll8QgvaNm7T7JcB.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC", &sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_BzXNE6ZUzNavXwWaMxM", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_BzXNE6ZUzNavXwWaMxM = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw", (CX::Int64)sbt_teyfxacQFqh9zEZI60Lwtq_lgFiQw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_T3Snpp4kpNK", sbt_T3Snpp4kpNK.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rxN4V", (CX::Int64)sbt_rxN4V)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ", (CX::Int64)sbt_Lzx8Aw4K6R_q5X9v3IMNaU0GdIqaQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ll8QgvaNm7T7JcB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Ll8QgvaNm7T7JcB.begin(); iter != sbt_Ll8QgvaNm7T7JcB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.begin(); iter != sbt_xoXJGiiIFdIZUh0MXwM8cgIwcNamIn635MUu4MzIVHI662IcEbDc0S8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.begin(); iter != sbt_g50PviAOgwnhrMeQO07AdUckAkw_ZqDu7MGlAFgGzhxLFla.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp", (CX::Int64)sbt_gKZA3Scvvy1AZ5w2Y1qserdGDE4XBTJxys0kI2E_d4zlhFixQKoS2SjznvByp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.begin(); iter != sbt_BSuwQ4simMYjmn4OxmrBpmdSHajIX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC", sbt_Ff8Gb_d4pGXorW99MC_YzZDZG58xOCNZo14gBaZYgNSjC.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_BzXNE6ZUzNavXwWaMxM", (CX::Double)sbt_BzXNE6ZUzNavXwWaMxM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2")).IsNOK())
		{
			return status;
		}
		for (sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTKArray::const_iterator iter = sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.begin(); iter != sbt_miWrATW3k9Iis1HoiojwzZ82bgaU8vjBlq2f2.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_DVOyoWXSWuYPXMo_m7a>::Type sbt_DVOyoWXSWuYPXMo_m7aArray;

