
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy.hpp"


class sbt_6St : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_13EwPP97wrtDpNnjIOwdUrA8NKr;
	CX::IO::SimpleBuffers::WStringArray sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9;
	CX::IO::SimpleBuffers::UInt32Array sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8;
	CX::Int8 sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N;
	CX::IO::SimpleBuffers::Int32Array sbt_KuG;
	CX::IO::SimpleBuffers::StringArray sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ;
	CX::Double sbt_In2AmaQUIJF4Gd2L_CF;
	CX::IO::SimpleBuffers::BoolArray sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa;
	CX::IO::SimpleBuffers::WStringArray sbt_S;
	CX::String sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i;
	CX::IO::SimpleBuffers::UInt16Array sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ;
	CX::IO::SimpleBuffers::UInt32Array sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim;
	CX::Bool sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8;
	CX::IO::SimpleBuffers::DoubleArray sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95;
	CX::UInt8 sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs;
	CX::IO::SimpleBuffers::UInt8Array sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY;
	CX::IO::SimpleBuffers::UInt64Array sbt_weuJxdT96;
	sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdyArray sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4;

	virtual void Reset()
	{
		sbt_13EwPP97wrtDpNnjIOwdUrA8NKr = 0;
		sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.clear();
		sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.clear();
		sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N = 0;
		sbt_KuG.clear();
		sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.clear();
		sbt_In2AmaQUIJF4Gd2L_CF = 0.0;
		sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.clear();
		sbt_S.clear();
		sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i.clear();
		sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.clear();
		sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.clear();
		sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8 = false;
		sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.clear();
		sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs = 0;
		sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.clear();
		sbt_weuJxdT96.clear();
		sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_13EwPP97wrtDpNnjIOwdUrA8NKr = -103;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.push_back(1334208794);
		}
		sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N = -22;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_KuG.push_back(-1934097773);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.push_back("!GVk[sgaO");
		}
		sbt_In2AmaQUIJF4Gd2L_CF = 0.083877;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_S.push_back(L"e");
		}
		sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i = "i:\"2Yi@M-&\"Zlf#0|B{H$~efx#,V5orv_&]";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.push_back(1295088924);
		}
		sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8 = true;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.push_back(0.081737);
		}
		sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs = 201;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.push_back(198);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_weuJxdT96.push_back(6383112819460507864);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy v;

			v.SetupWithSomeValues();
			sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6St *pObject = dynamic_cast<const sbt_6St *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_13EwPP97wrtDpNnjIOwdUrA8NKr != pObject->sbt_13EwPP97wrtDpNnjIOwdUrA8NKr)
		{
			return false;
		}
		if (sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.size() != pObject->sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9[i].c_str(), pObject->sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.size() != pObject->sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.size(); i++)
		{
			if (sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8[i] != pObject->sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8[i])
			{
				return false;
			}
		}
		if (sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N != pObject->sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N)
		{
			return false;
		}
		if (sbt_KuG.size() != pObject->sbt_KuG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KuG.size(); i++)
		{
			if (sbt_KuG[i] != pObject->sbt_KuG[i])
			{
				return false;
			}
		}
		if (sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.size() != pObject->sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ[i].c_str(), pObject->sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_In2AmaQUIJF4Gd2L_CF != pObject->sbt_In2AmaQUIJF4Gd2L_CF)
		{
			return false;
		}
		if (sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.size() != pObject->sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.size(); i++)
		{
			if (sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa[i] != pObject->sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa[i])
			{
				return false;
			}
		}
		if (sbt_S.size() != pObject->sbt_S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_S[i].c_str(), pObject->sbt_S[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i.c_str(), pObject->sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i.c_str()))
		{
			return false;
		}
		if (sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.size() != pObject->sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.size(); i++)
		{
			if (sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ[i] != pObject->sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ[i])
			{
				return false;
			}
		}
		if (sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.size() != pObject->sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.size(); i++)
		{
			if (sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim[i] != pObject->sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim[i])
			{
				return false;
			}
		}
		if (sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8 != pObject->sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8)
		{
			return false;
		}
		if (sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.size() != pObject->sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.size(); i++)
		{
			if (sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95[i] != pObject->sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95[i])
			{
				return false;
			}
		}
		if (sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs != pObject->sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs)
		{
			return false;
		}
		if (sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.size() != pObject->sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.size(); i++)
		{
			if (sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY[i] != pObject->sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY[i])
			{
				return false;
			}
		}
		if (sbt_weuJxdT96.size() != pObject->sbt_weuJxdT96.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_weuJxdT96.size(); i++)
		{
			if (sbt_weuJxdT96[i] != pObject->sbt_weuJxdT96[i])
			{
				return false;
			}
		}
		if (sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.size() != pObject->sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.size(); i++)
		{
			if (!sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4[i].Compare(&pObject->sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_13EwPP97wrtDpNnjIOwdUrA8NKr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_13EwPP97wrtDpNnjIOwdUrA8NKr = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KuG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KuG.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_In2AmaQUIJF4Gd2L_CF", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_In2AmaQUIJF4Gd2L_CF = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i", &sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8", &sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_weuJxdT96")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_weuJxdT96.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_13EwPP97wrtDpNnjIOwdUrA8NKr", (CX::Int64)sbt_13EwPP97wrtDpNnjIOwdUrA8NKr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.begin(); iter != sbt_F96WBt3_nZsVuNRyVg9WtXVjGVdl_8LtOYKQOh9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.begin(); iter != sbt_maZ5jTYqEPgm2XeXxp3YiZfHp5eaW_NbW6Jhc3hktL8EY3ni5C8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N", (CX::Int64)sbt_LnV4N4umS3P2Bz574_pVlTtDr8L_P2N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KuG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_KuG.begin(); iter != sbt_KuG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.begin(); iter != sbt_TSWdrCNsBiN6Dvop6ghUgqZacb8fdxjY6Zl_SvEIkLM0iAJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_In2AmaQUIJF4Gd2L_CF", (CX::Double)sbt_In2AmaQUIJF4Gd2L_CF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.begin(); iter != sbt_Pn36AZDd7ijYHrhOYMBC01b2ALmhOTCHAnFuALdXVCisJzMoGoS0PCa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_S.begin(); iter != sbt_S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i", sbt_tzdRGz7BgRiLUlirfDUeqQiB7ZbObENFo3IUD6N1tERy5983oYQeYbK9i.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.begin(); iter != sbt_jUu7KGgfQ7p74DpfJto5QXCRFjMBdbFgNJ6D6ReopUBgFJafJ5nJKrxPdxaFQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.begin(); iter != sbt_fTkwqbwswsVQcNEW2sMia6uzRWzbaEoofGHtusP0Nim.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8", sbt_ZQUqNR_SEHB90NN8n4zrOqnSGsMR8Vu812jhrdONZSLwAhQ5C6PO8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.begin(); iter != sbt_xsrHu5bVoAriXpGkPPrjlFy7CsQJcIqij23KY73byQzDaLgiAH1jDGM95.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs", (CX::Int64)sbt__vW0pi_hOe1HyfK0MEyp5WABbwkWSKBKoep7FfU0SuKXpXO1xzs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.begin(); iter != sbt_oWcWqq89Ov_FSfqgyHPdWiz8gipF4iEiXnAX9ZHQ4yxhY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_weuJxdT96")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_weuJxdT96.begin(); iter != sbt_weuJxdT96.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4")).IsNOK())
		{
			return status;
		}
		for (sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdyArray::const_iterator iter = sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.begin(); iter != sbt_OrbS5rzjTEDfMd33U5jLhoGEw5JHdfSYgXubexaO7qTNS9GRxtoaDmP6tj2w4.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6St>::Type sbt_6StArray;

