
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_z7V7j2R83fWj7sZN7YRoI.hpp"


class sbt_s8Xk5_MtSOD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd;
	CX::String sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM;
	CX::IO::SimpleBuffers::StringArray sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga;
	CX::UInt16 sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W;
	CX::IO::SimpleBuffers::UInt64Array sbt_2cFVAYaoI4EdwnPWXQmogzo;
	CX::UInt64 sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S;
	CX::IO::SimpleBuffers::UInt32Array sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ;
	CX::IO::SimpleBuffers::Int64Array sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy;
	CX::Int32 sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ;
	CX::Int8 sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E;
	CX::Int8 sbt_lPRKSS4J4RNzWNF;
	CX::Float sbt_Jw9Dn_aICMkk5rWd8Eqcx0O;
	CX::IO::SimpleBuffers::UInt32Array sbt_Sue1jxgV9ibkxNz;
	CX::IO::SimpleBuffers::Int64Array sbt_Ay4pczUe7CNs3jCWpi_G2nP;
	CX::Int16 sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh;
	CX::UInt16 sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn;
	CX::IO::SimpleBuffers::WStringArray sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr;
	CX::Double sbt_Q14hYPzjKtFEEmp;
	CX::IO::SimpleBuffers::UInt16Array sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS;
	CX::IO::SimpleBuffers::Int16Array sbt_TCCDKqFVjQx;
	CX::IO::SimpleBuffers::BoolArray sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb;
	CX::Int8 sbt_iXwXTvOpEJElvF_rQhUdD;
	CX::UInt32 sbt__Y6ifESf8_Tklewlm47nD;
	CX::IO::SimpleBuffers::Int8Array sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J;
	sbt_z7V7j2R83fWj7sZN7YRoI sbt_3289AU0q2dT;

	virtual void Reset()
	{
		sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd = false;
		sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM.clear();
		sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.clear();
		sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W = 0;
		sbt_2cFVAYaoI4EdwnPWXQmogzo.clear();
		sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S = 0;
		sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.clear();
		sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.clear();
		sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ = 0;
		sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E = 0;
		sbt_lPRKSS4J4RNzWNF = 0;
		sbt_Jw9Dn_aICMkk5rWd8Eqcx0O = 0.0f;
		sbt_Sue1jxgV9ibkxNz.clear();
		sbt_Ay4pczUe7CNs3jCWpi_G2nP.clear();
		sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh = 0;
		sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn = 0;
		sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.clear();
		sbt_Q14hYPzjKtFEEmp = 0.0;
		sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.clear();
		sbt_TCCDKqFVjQx.clear();
		sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.clear();
		sbt_iXwXTvOpEJElvF_rQhUdD = 0;
		sbt__Y6ifESf8_Tklewlm47nD = 0;
		sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.clear();
		sbt_3289AU0q2dT.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd = true;
		sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM = "^v[tq]f-I[25:i;FtWz1KA}lN";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.push_back("\"");
		}
		sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W = 32685;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_2cFVAYaoI4EdwnPWXQmogzo.push_back(12166631700002789782);
		}
		sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S = 879522426689303182;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.push_back(516457621);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.push_back(-4190366742503411518);
		}
		sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ = 1687851694;
		sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E = -84;
		sbt_lPRKSS4J4RNzWNF = -95;
		sbt_Jw9Dn_aICMkk5rWd8Eqcx0O = 0.073141f;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Sue1jxgV9ibkxNz.push_back(469985081);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Ay4pczUe7CNs3jCWpi_G2nP.push_back(2964594082029186976);
		}
		sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh = 4157;
		sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn = 63884;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.push_back(L"\"`6g@KjG8F1AeewK");
		}
		sbt_Q14hYPzjKtFEEmp = 0.394171;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_TCCDKqFVjQx.push_back(-2359);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.push_back(true);
		}
		sbt_iXwXTvOpEJElvF_rQhUdD = 58;
		sbt__Y6ifESf8_Tklewlm47nD = 1702664864;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.push_back(-92);
		}
		sbt_3289AU0q2dT.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_s8Xk5_MtSOD *pObject = dynamic_cast<const sbt_s8Xk5_MtSOD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd != pObject->sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM.c_str(), pObject->sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM.c_str()))
		{
			return false;
		}
		if (sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.size() != pObject->sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.size(); i++)
		{
			if (0 != cx_strcmp(sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga[i].c_str(), pObject->sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W != pObject->sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W)
		{
			return false;
		}
		if (sbt_2cFVAYaoI4EdwnPWXQmogzo.size() != pObject->sbt_2cFVAYaoI4EdwnPWXQmogzo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2cFVAYaoI4EdwnPWXQmogzo.size(); i++)
		{
			if (sbt_2cFVAYaoI4EdwnPWXQmogzo[i] != pObject->sbt_2cFVAYaoI4EdwnPWXQmogzo[i])
			{
				return false;
			}
		}
		if (sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S != pObject->sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S)
		{
			return false;
		}
		if (sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.size() != pObject->sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.size(); i++)
		{
			if (sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ[i] != pObject->sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ[i])
			{
				return false;
			}
		}
		if (sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.size() != pObject->sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.size(); i++)
		{
			if (sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy[i] != pObject->sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy[i])
			{
				return false;
			}
		}
		if (sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ != pObject->sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ)
		{
			return false;
		}
		if (sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E != pObject->sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E)
		{
			return false;
		}
		if (sbt_lPRKSS4J4RNzWNF != pObject->sbt_lPRKSS4J4RNzWNF)
		{
			return false;
		}
		if (sbt_Jw9Dn_aICMkk5rWd8Eqcx0O != pObject->sbt_Jw9Dn_aICMkk5rWd8Eqcx0O)
		{
			return false;
		}
		if (sbt_Sue1jxgV9ibkxNz.size() != pObject->sbt_Sue1jxgV9ibkxNz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Sue1jxgV9ibkxNz.size(); i++)
		{
			if (sbt_Sue1jxgV9ibkxNz[i] != pObject->sbt_Sue1jxgV9ibkxNz[i])
			{
				return false;
			}
		}
		if (sbt_Ay4pczUe7CNs3jCWpi_G2nP.size() != pObject->sbt_Ay4pczUe7CNs3jCWpi_G2nP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ay4pczUe7CNs3jCWpi_G2nP.size(); i++)
		{
			if (sbt_Ay4pczUe7CNs3jCWpi_G2nP[i] != pObject->sbt_Ay4pczUe7CNs3jCWpi_G2nP[i])
			{
				return false;
			}
		}
		if (sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh != pObject->sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh)
		{
			return false;
		}
		if (sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn != pObject->sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn)
		{
			return false;
		}
		if (sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.size() != pObject->sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr[i].c_str(), pObject->sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Q14hYPzjKtFEEmp != pObject->sbt_Q14hYPzjKtFEEmp)
		{
			return false;
		}
		if (sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.size() != pObject->sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.size(); i++)
		{
			if (sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS[i] != pObject->sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS[i])
			{
				return false;
			}
		}
		if (sbt_TCCDKqFVjQx.size() != pObject->sbt_TCCDKqFVjQx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TCCDKqFVjQx.size(); i++)
		{
			if (sbt_TCCDKqFVjQx[i] != pObject->sbt_TCCDKqFVjQx[i])
			{
				return false;
			}
		}
		if (sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.size() != pObject->sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.size(); i++)
		{
			if (sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb[i] != pObject->sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb[i])
			{
				return false;
			}
		}
		if (sbt_iXwXTvOpEJElvF_rQhUdD != pObject->sbt_iXwXTvOpEJElvF_rQhUdD)
		{
			return false;
		}
		if (sbt__Y6ifESf8_Tklewlm47nD != pObject->sbt__Y6ifESf8_Tklewlm47nD)
		{
			return false;
		}
		if (sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.size() != pObject->sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.size(); i++)
		{
			if (sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J[i] != pObject->sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J[i])
			{
				return false;
			}
		}
		if (!sbt_3289AU0q2dT.Compare(&pObject->sbt_3289AU0q2dT))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd", &sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM", &sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2cFVAYaoI4EdwnPWXQmogzo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2cFVAYaoI4EdwnPWXQmogzo.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lPRKSS4J4RNzWNF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lPRKSS4J4RNzWNF = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_Jw9Dn_aICMkk5rWd8Eqcx0O", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Jw9Dn_aICMkk5rWd8Eqcx0O = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Sue1jxgV9ibkxNz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Sue1jxgV9ibkxNz.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ay4pczUe7CNs3jCWpi_G2nP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ay4pczUe7CNs3jCWpi_G2nP.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_Q14hYPzjKtFEEmp", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Q14hYPzjKtFEEmp = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TCCDKqFVjQx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TCCDKqFVjQx.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iXwXTvOpEJElvF_rQhUdD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iXwXTvOpEJElvF_rQhUdD = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__Y6ifESf8_Tklewlm47nD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__Y6ifESf8_Tklewlm47nD = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_3289AU0q2dT")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_3289AU0q2dT.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd", sbt_kMG9ErfRkAJlQVnL5Udu6mWy02JxvB1xPjzTH0w2ESCG0WxVsMA6MnT_oRd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM", sbt_frfjnEbDcxkbveY7npS5ZN0WgkD6PJoLUYafh1CJ6L0S23kQM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.begin(); iter != sbt_QrLPXosDQllsTakeQSiFmv52tTo6G4HSHtKga.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W", (CX::Int64)sbt_hmqaTt22KVRgkx298SuxmPe6yPRYJLY6W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2cFVAYaoI4EdwnPWXQmogzo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_2cFVAYaoI4EdwnPWXQmogzo.begin(); iter != sbt_2cFVAYaoI4EdwnPWXQmogzo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S", (CX::Int64)sbt__zs3P1d6QYsb_tKQJDZY3vcWz9bXTXipqPJ95o22hu0UaMpursAVX7S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.begin(); iter != sbt_qBKoPXlIafoR3uLQDJmbrfAA5prqucpeEQQ9rYY7FEpHiaGNQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.begin(); iter != sbt_mosxdbmfZ7Bl6s4rzphV1l37pUy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ", (CX::Int64)sbt_Cncbgqz4N3f4QfiXHvSGXOpJMnerQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E", (CX::Int64)sbt_TpNlvBt8iTcDkkjtU6i_WM7BlYQU3IdqEk6fetRISWrcQoEg0KNYjvY5gvz8E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lPRKSS4J4RNzWNF", (CX::Int64)sbt_lPRKSS4J4RNzWNF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Jw9Dn_aICMkk5rWd8Eqcx0O", (CX::Double)sbt_Jw9Dn_aICMkk5rWd8Eqcx0O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Sue1jxgV9ibkxNz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Sue1jxgV9ibkxNz.begin(); iter != sbt_Sue1jxgV9ibkxNz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ay4pczUe7CNs3jCWpi_G2nP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Ay4pczUe7CNs3jCWpi_G2nP.begin(); iter != sbt_Ay4pczUe7CNs3jCWpi_G2nP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh", (CX::Int64)sbt_liptacvOA5pVvKd53NEKc_nxfR9k2H9hohAg0oEHh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn", (CX::Int64)sbt_it0NPEldWEfcqheJgpyARi4Y0OQV6niqFsdXMnImLtH_p9nUNQhzfGn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.begin(); iter != sbt_fU61udQTSL2xCjCVdUdjvJh5LbvJiKr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Q14hYPzjKtFEEmp", (CX::Double)sbt_Q14hYPzjKtFEEmp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.begin(); iter != sbt_UgsnDFZSaP96mtRnY9ZOzqHXXCfNer8clbKknzTaZUIKiBFhElghd96qVuZylcS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TCCDKqFVjQx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_TCCDKqFVjQx.begin(); iter != sbt_TCCDKqFVjQx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.begin(); iter != sbt_k1r5x_i6oxPa19tu2E1qjR0igs5GlENZo2_frOQ0dZiyb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iXwXTvOpEJElvF_rQhUdD", (CX::Int64)sbt_iXwXTvOpEJElvF_rQhUdD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__Y6ifESf8_Tklewlm47nD", (CX::Int64)sbt__Y6ifESf8_Tklewlm47nD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.begin(); iter != sbt_qAREt82VXsFxdouXLArV6wNsLSEAJu_FvTnLZR3YtsKgxJZ7Stv6ng48J.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_3289AU0q2dT")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_3289AU0q2dT.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_s8Xk5_MtSOD>::Type sbt_s8Xk5_MtSODArray;

