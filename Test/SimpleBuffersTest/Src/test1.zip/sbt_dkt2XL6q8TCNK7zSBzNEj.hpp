
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_VNUKx.hpp"


class sbt_dkt2XL6q8TCNK7zSBzNEj : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP;
	CX::IO::SimpleBuffers::UInt16Array sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq;
	CX::Int8 sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd;
	CX::UInt8 sbt_58NLYQfHWTpyg_hsWaX;
	CX::Int32 sbt_SZcy7PgYxC30J5PbyGTZo;
	CX::UInt32 sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7;
	CX::IO::SimpleBuffers::StringArray sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA;
	CX::IO::SimpleBuffers::StringArray sbt_b;
	CX::Int16 sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS;
	CX::Int64 sbt_LR_KIHrGY;
	CX::Int64 sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5;
	CX::IO::SimpleBuffers::Int8Array sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N;
	CX::String sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ;
	CX::IO::SimpleBuffers::WStringArray sbt_qBz1r;
	CX::IO::SimpleBuffers::FloatArray sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf;
	CX::Int64 sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG;
	CX::IO::SimpleBuffers::StringArray sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8;
	CX::IO::SimpleBuffers::Int32Array sbt_fBk;
	CX::IO::SimpleBuffers::Int16Array sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2;
	CX::Int64 sbt_Ya8_tCHQ_cLOWII;
	CX::IO::SimpleBuffers::Int16Array sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN;
	sbt_VNUKxArray sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa;

	virtual void Reset()
	{
		sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP.clear();
		sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.clear();
		sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd = 0;
		sbt_58NLYQfHWTpyg_hsWaX = 0;
		sbt_SZcy7PgYxC30J5PbyGTZo = 0;
		sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7 = 0;
		sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.clear();
		sbt_b.clear();
		sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS = 0;
		sbt_LR_KIHrGY = 0;
		sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5 = 0;
		sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.clear();
		sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ.clear();
		sbt_qBz1r.clear();
		sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.clear();
		sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG = 0;
		sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.clear();
		sbt_fBk.clear();
		sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.clear();
		sbt_Ya8_tCHQ_cLOWII = 0;
		sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.clear();
		sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP = L"_c,Ah9X]IZ1x~=|.Z)'HC_:6J5Q*\\y}6A6(R`g}Y^npeZ_W>g2ODf^zKIJ~e";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.push_back(30898);
		}
		sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd = -65;
		sbt_58NLYQfHWTpyg_hsWaX = 91;
		sbt_SZcy7PgYxC30J5PbyGTZo = 883043541;
		sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7 = 621620978;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.push_back("ov}--yb_V3~rl5F#-cu#=\\'\\\\#~/I/}2'Z2e");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_b.push_back("[a&#;o9-N=70K5]#5xJNp~\\un*^E*Xrs&(Of_H4!9I1]3Puz-A3b#tzjaY`t{_%W");
		}
		sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS = 27199;
		sbt_LR_KIHrGY = -6020962070162998392;
		sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5 = 7426110481213407164;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.push_back(-99);
		}
		sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ = "_S?JQn";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_qBz1r.push_back(L"C6/!_5ntxM{HUf<jx|v?2@|nY.BYnNid:%@b?q^(");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.push_back(0.849364f);
		}
		sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG = -2464818989351188076;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.push_back("ZHQhx5hxcft4&:R4(:9RyZU\"]@PRe|}2u$3[mBBmr7+P'<\\NO]AkwZ/");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_fBk.push_back(-1896683642);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.push_back(-9009);
		}
		sbt_Ya8_tCHQ_cLOWII = -1913663835164957908;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.push_back(23666);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_VNUKx v;

			v.SetupWithSomeValues();
			sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_dkt2XL6q8TCNK7zSBzNEj *pObject = dynamic_cast<const sbt_dkt2XL6q8TCNK7zSBzNEj *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP.c_str(), pObject->sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP.c_str()))
		{
			return false;
		}
		if (sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.size() != pObject->sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.size(); i++)
		{
			if (sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq[i] != pObject->sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq[i])
			{
				return false;
			}
		}
		if (sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd != pObject->sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd)
		{
			return false;
		}
		if (sbt_58NLYQfHWTpyg_hsWaX != pObject->sbt_58NLYQfHWTpyg_hsWaX)
		{
			return false;
		}
		if (sbt_SZcy7PgYxC30J5PbyGTZo != pObject->sbt_SZcy7PgYxC30J5PbyGTZo)
		{
			return false;
		}
		if (sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7 != pObject->sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7)
		{
			return false;
		}
		if (sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.size() != pObject->sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.size(); i++)
		{
			if (0 != cx_strcmp(sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA[i].c_str(), pObject->sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_b.size() != pObject->sbt_b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b.size(); i++)
		{
			if (0 != cx_strcmp(sbt_b[i].c_str(), pObject->sbt_b[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS != pObject->sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS)
		{
			return false;
		}
		if (sbt_LR_KIHrGY != pObject->sbt_LR_KIHrGY)
		{
			return false;
		}
		if (sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5 != pObject->sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5)
		{
			return false;
		}
		if (sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.size() != pObject->sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.size(); i++)
		{
			if (sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N[i] != pObject->sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ.c_str(), pObject->sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ.c_str()))
		{
			return false;
		}
		if (sbt_qBz1r.size() != pObject->sbt_qBz1r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qBz1r.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_qBz1r[i].c_str(), pObject->sbt_qBz1r[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.size() != pObject->sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.size(); i++)
		{
			if (sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf[i] != pObject->sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf[i])
			{
				return false;
			}
		}
		if (sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG != pObject->sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG)
		{
			return false;
		}
		if (sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.size() != pObject->sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.size(); i++)
		{
			if (0 != cx_strcmp(sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8[i].c_str(), pObject->sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_fBk.size() != pObject->sbt_fBk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fBk.size(); i++)
		{
			if (sbt_fBk[i] != pObject->sbt_fBk[i])
			{
				return false;
			}
		}
		if (sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.size() != pObject->sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.size(); i++)
		{
			if (sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2[i] != pObject->sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2[i])
			{
				return false;
			}
		}
		if (sbt_Ya8_tCHQ_cLOWII != pObject->sbt_Ya8_tCHQ_cLOWII)
		{
			return false;
		}
		if (sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.size() != pObject->sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.size(); i++)
		{
			if (sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN[i] != pObject->sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN[i])
			{
				return false;
			}
		}
		if (sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.size() != pObject->sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.size(); i++)
		{
			if (!sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa[i].Compare(&pObject->sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP", &sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_58NLYQfHWTpyg_hsWaX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_58NLYQfHWTpyg_hsWaX = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SZcy7PgYxC30J5PbyGTZo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SZcy7PgYxC30J5PbyGTZo = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LR_KIHrGY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LR_KIHrGY = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ", &sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qBz1r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qBz1r.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fBk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fBk.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Ya8_tCHQ_cLOWII", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ya8_tCHQ_cLOWII = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_VNUKx tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP", sbt_FnFojyFYGeQMFSDUD6DXyWVfNHmQgqElSTzFTOjSZYP.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.begin(); iter != sbt_Zx1oWQLu3D4MqY7FXASU8CQi3dVg7KKbZVY_erq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd", (CX::Int64)sbt_23GZW_sBg0QzDv0biyiZwzgB4ZcDd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_58NLYQfHWTpyg_hsWaX", (CX::Int64)sbt_58NLYQfHWTpyg_hsWaX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SZcy7PgYxC30J5PbyGTZo", (CX::Int64)sbt_SZcy7PgYxC30J5PbyGTZo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7", (CX::Int64)sbt_Re0fC6Y4PQU8q2Lf_xAwjWtmmtF2DWmfzrKzKQ6aSevMMKGwGHbA7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.begin(); iter != sbt_WWK67LbYkx8sEDsc1cSm5y7nXaG9fK8TjwA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_b.begin(); iter != sbt_b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS", (CX::Int64)sbt_b6dHod7mrqPoIcXlsKqEJIYH_3jX5pTSamdax3QpYsS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LR_KIHrGY", (CX::Int64)sbt_LR_KIHrGY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5", (CX::Int64)sbt_uevONuA9Pw8al50ulAG48CB5aXY9S4W73n1SJufWE2_opoqLFA_X5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.begin(); iter != sbt_s3UBR4tCAbOGnWBIgaEC4JsJWd8X0rxS6YulQ11GeLLGX4ELBpB010N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ", sbt_Wg5J_LmuO0EuJwEalfPf_cqA5HzBg1kSp8dYWZab4DwRaQaNwDQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qBz1r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_qBz1r.begin(); iter != sbt_qBz1r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.begin(); iter != sbt_YLurvAa5b1DrUwKB5I0_0nLk25Z2cIZAmnFvZ95nKhagdHf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG", (CX::Int64)sbt_qoU8QVDe4XaCYav7nhII3xDxQ5WrT_g4FFVQB3mgyth9RNG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.begin(); iter != sbt_dpy9TBA4KF2F6JQtCqbV2D0GVotapNi2zcTHhu0D8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fBk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_fBk.begin(); iter != sbt_fBk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.begin(); iter != sbt_SlVpCt3KDAzY61brx72GuLhyzLku2WJdxZzBjH2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ya8_tCHQ_cLOWII", (CX::Int64)sbt_Ya8_tCHQ_cLOWII)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.begin(); iter != sbt_1tvYdccwdKI6rW3TOzUEgpEajWbUaOSruPhwY8kSXKJ0GVR_CuokN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa")).IsNOK())
		{
			return status;
		}
		for (sbt_VNUKxArray::const_iterator iter = sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.begin(); iter != sbt_TYJo4Wu96KVOaAzdXzey8sGJq9dHa.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_dkt2XL6q8TCNK7zSBzNEj>::Type sbt_dkt2XL6q8TCNK7zSBzNEjArray;

