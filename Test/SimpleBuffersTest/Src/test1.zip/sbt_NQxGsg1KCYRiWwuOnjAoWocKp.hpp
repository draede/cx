
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lAakdvN7vZFYi3BVt.hpp"


class sbt_NQxGsg1KCYRiWwuOnjAoWocKp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19;
	CX::String sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx;
	CX::IO::SimpleBuffers::UInt64Array sbt_Fi7kEpykuko;
	CX::UInt64 sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp;
	CX::IO::SimpleBuffers::Int16Array sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40;
	CX::IO::SimpleBuffers::UInt32Array sbt_KTKJZefIDjgshRNGUUk;
	CX::IO::SimpleBuffers::FloatArray sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf;
	sbt_lAakdvN7vZFYi3BVt sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc;

	virtual void Reset()
	{
		sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.clear();
		sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx.clear();
		sbt_Fi7kEpykuko.clear();
		sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp = 0;
		sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.clear();
		sbt_KTKJZefIDjgshRNGUUk.clear();
		sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.clear();
		sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.push_back(L"V50j089(\\mUy1,JLWB7-VJWiJ!rEF}Z\"S");
		}
		sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx = "PV.WRT,@-X9f.&qJ%6=C~kVYV4n\"*(l>";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Fi7kEpykuko.push_back(2826127842256493112);
		}
		sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp = 16439741486115362758;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.push_back(-23688);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.push_back(0.130677f);
		}
		sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_NQxGsg1KCYRiWwuOnjAoWocKp *pObject = dynamic_cast<const sbt_NQxGsg1KCYRiWwuOnjAoWocKp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.size() != pObject->sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19[i].c_str(), pObject->sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx.c_str(), pObject->sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx.c_str()))
		{
			return false;
		}
		if (sbt_Fi7kEpykuko.size() != pObject->sbt_Fi7kEpykuko.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fi7kEpykuko.size(); i++)
		{
			if (sbt_Fi7kEpykuko[i] != pObject->sbt_Fi7kEpykuko[i])
			{
				return false;
			}
		}
		if (sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp != pObject->sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp)
		{
			return false;
		}
		if (sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.size() != pObject->sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.size(); i++)
		{
			if (sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40[i] != pObject->sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40[i])
			{
				return false;
			}
		}
		if (sbt_KTKJZefIDjgshRNGUUk.size() != pObject->sbt_KTKJZefIDjgshRNGUUk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KTKJZefIDjgshRNGUUk.size(); i++)
		{
			if (sbt_KTKJZefIDjgshRNGUUk[i] != pObject->sbt_KTKJZefIDjgshRNGUUk[i])
			{
				return false;
			}
		}
		if (sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.size() != pObject->sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.size(); i++)
		{
			if (sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf[i] != pObject->sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf[i])
			{
				return false;
			}
		}
		if (!sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc.Compare(&pObject->sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx", &sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Fi7kEpykuko")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fi7kEpykuko.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KTKJZefIDjgshRNGUUk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KTKJZefIDjgshRNGUUk.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.begin(); iter != sbt_bCupM4Aw5aM05cEy6TBt0nA3c9aYpL8auAdfDcixEy_JteB9F86liVAIwGZ19.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx", sbt_7oxnWhLSbJs7kV6RCt4DrJtLgGPEyFx.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fi7kEpykuko")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Fi7kEpykuko.begin(); iter != sbt_Fi7kEpykuko.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp", (CX::Int64)sbt_JuekKNMbqEke9vMSOF6Hd2Mtobnkpg2sFeNVXayN8Fp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.begin(); iter != sbt_udFRfzRyQFDLIvTn4C6ImbJ1ZWt2HjC4Yc7UpBHOp40.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KTKJZefIDjgshRNGUUk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_KTKJZefIDjgshRNGUUk.begin(); iter != sbt_KTKJZefIDjgshRNGUUk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.begin(); iter != sbt_lS4m5nxlDG5op2FzNupO5LgZzjWhBMiUfEEGIJkAgkJbX8uLC8LfGBf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_e3BYb9TZ5hgSVKUIEzhOXV8aSnmnWYCoG3B1K6AFZvmNFKc.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_NQxGsg1KCYRiWwuOnjAoWocKp>::Type sbt_NQxGsg1KCYRiWwuOnjAoWocKpArray;

