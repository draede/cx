
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I.hpp"


class sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO;
	CX::IO::SimpleBuffers::Int64Array sbt_G0ylNkI0PyPZ59Y5m;
	CX::WString sbt_8tii648eC;
	CX::IO::SimpleBuffers::UInt64Array sbt_0;
	CX::UInt16 sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB;
	CX::IO::SimpleBuffers::UInt16Array sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa;
	CX::IO::SimpleBuffers::FloatArray sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P;
	CX::WString sbt_PtshQBD;
	CX::String sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly;
	CX::String sbt_LXgxJfW6fZFM5VU7skI1LmG;
	sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0IArray sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO;

	virtual void Reset()
	{
		sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.clear();
		sbt_G0ylNkI0PyPZ59Y5m.clear();
		sbt_8tii648eC.clear();
		sbt_0.clear();
		sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB = 0;
		sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.clear();
		sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.clear();
		sbt_PtshQBD.clear();
		sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly.clear();
		sbt_LXgxJfW6fZFM5VU7skI1LmG.clear();
		sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.push_back(true);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_G0ylNkI0PyPZ59Y5m.push_back(8234751603187985514);
		}
		sbt_8tii648eC = L"-N>*EIC(m";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_0.push_back(9198760894204094858);
		}
		sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB = 44602;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.push_back(54940);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.push_back(0.464730f);
		}
		sbt_PtshQBD = L",)l%HN(e=4!lHvB;wtykE06-kXSlK~NI}^g`}EJaY[z=X";
		sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly = "4fvRnBJ:,kH[zWo_?r.?";
		sbt_LXgxJfW6fZFM5VU7skI1LmG = "K=)6Cq,@TJcDgU.nPw8&>k,$5l";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I v;

			v.SetupWithSomeValues();
			sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE *pObject = dynamic_cast<const sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.size() != pObject->sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.size(); i++)
		{
			if (sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO[i] != pObject->sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO[i])
			{
				return false;
			}
		}
		if (sbt_G0ylNkI0PyPZ59Y5m.size() != pObject->sbt_G0ylNkI0PyPZ59Y5m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_G0ylNkI0PyPZ59Y5m.size(); i++)
		{
			if (sbt_G0ylNkI0PyPZ59Y5m[i] != pObject->sbt_G0ylNkI0PyPZ59Y5m[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_8tii648eC.c_str(), pObject->sbt_8tii648eC.c_str()))
		{
			return false;
		}
		if (sbt_0.size() != pObject->sbt_0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0.size(); i++)
		{
			if (sbt_0[i] != pObject->sbt_0[i])
			{
				return false;
			}
		}
		if (sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB != pObject->sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB)
		{
			return false;
		}
		if (sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.size() != pObject->sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.size(); i++)
		{
			if (sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa[i] != pObject->sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa[i])
			{
				return false;
			}
		}
		if (sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.size() != pObject->sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.size(); i++)
		{
			if (sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P[i] != pObject->sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_PtshQBD.c_str(), pObject->sbt_PtshQBD.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly.c_str(), pObject->sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_LXgxJfW6fZFM5VU7skI1LmG.c_str(), pObject->sbt_LXgxJfW6fZFM5VU7skI1LmG.c_str()))
		{
			return false;
		}
		if (sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.size() != pObject->sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.size(); i++)
		{
			if (!sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO[i].Compare(&pObject->sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_G0ylNkI0PyPZ59Y5m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_G0ylNkI0PyPZ59Y5m.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_8tii648eC", &sbt_8tii648eC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_PtshQBD", &sbt_PtshQBD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly", &sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_LXgxJfW6fZFM5VU7skI1LmG", &sbt_LXgxJfW6fZFM5VU7skI1LmG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.begin(); iter != sbt_KrA6_6F5JS3qmL2BLGznKSLoa5kFyl5qjpyVFVrTykbz37NTO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_G0ylNkI0PyPZ59Y5m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_G0ylNkI0PyPZ59Y5m.begin(); iter != sbt_G0ylNkI0PyPZ59Y5m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_8tii648eC", sbt_8tii648eC.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_0.begin(); iter != sbt_0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB", (CX::Int64)sbt_OiaGujMhEEXvJ7iB6fGEPEMrgC9n4YLSemW6LlV2vpkdB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.begin(); iter != sbt_ncIY6IfHBywLsKIfSWJlEKsihDZFjG2vRJSqVcXOVPt5ncGyLrDTqzFLa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.begin(); iter != sbt_QVs5R4n9jQTx3tqbdOPPl6g0rOs5x6wxaXGFtce4P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_PtshQBD", sbt_PtshQBD.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly", sbt_BUIuuHC6aRrnOnHU9W9HwwPzL91uyJZAE45PDeySpcQttOJNjpnfEmXpnb2Ly.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_LXgxJfW6fZFM5VU7skI1LmG", sbt_LXgxJfW6fZFM5VU7skI1LmG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO")).IsNOK())
		{
			return status;
		}
		for (sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0IArray::const_iterator iter = sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.begin(); iter != sbt_WsVm7ziw2244VcxRfbbetjZcuVrtZZU2DPPHMoO.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE>::Type sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vEArray;

