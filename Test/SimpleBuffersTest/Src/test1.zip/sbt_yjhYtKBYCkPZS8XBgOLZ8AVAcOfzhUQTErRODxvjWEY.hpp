
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_DdQ72EermjCyCVP;
	CX::IO::SimpleBuffers::BoolArray sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR;
	CX::UInt8 sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm;
	CX::UInt64 sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU;
	CX::UInt64 sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J;
	CX::IO::SimpleBuffers::UInt32Array sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN;
	CX::UInt8 sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI;
	CX::IO::SimpleBuffers::Int64Array sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj;

	virtual void Reset()
	{
		sbt_DdQ72EermjCyCVP.clear();
		sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.clear();
		sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm = 0;
		sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU = 0;
		sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J = 0;
		sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.clear();
		sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI = 0;
		sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_DdQ72EermjCyCVP.push_back(15222750433478510480);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.push_back(true);
		}
		sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm = 82;
		sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU = 7228726442723167278;
		sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J = 2015763194786678048;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.push_back(2135510682);
		}
		sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI = 34;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY *pObject = dynamic_cast<const sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_DdQ72EermjCyCVP.size() != pObject->sbt_DdQ72EermjCyCVP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DdQ72EermjCyCVP.size(); i++)
		{
			if (sbt_DdQ72EermjCyCVP[i] != pObject->sbt_DdQ72EermjCyCVP[i])
			{
				return false;
			}
		}
		if (sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.size() != pObject->sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.size(); i++)
		{
			if (sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR[i] != pObject->sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR[i])
			{
				return false;
			}
		}
		if (sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm != pObject->sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm)
		{
			return false;
		}
		if (sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU != pObject->sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU)
		{
			return false;
		}
		if (sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J != pObject->sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J)
		{
			return false;
		}
		if (sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.size() != pObject->sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.size(); i++)
		{
			if (sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN[i] != pObject->sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN[i])
			{
				return false;
			}
		}
		if (sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI != pObject->sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI)
		{
			return false;
		}
		if (sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.size() != pObject->sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.size(); i++)
		{
			if (sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj[i] != pObject->sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_DdQ72EermjCyCVP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DdQ72EermjCyCVP.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_DdQ72EermjCyCVP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_DdQ72EermjCyCVP.begin(); iter != sbt_DdQ72EermjCyCVP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.begin(); iter != sbt_W4JCODonXrMWJ_TJ3i1jNvl6SYR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm", (CX::Int64)sbt_Q0FcNwD_S2WMdb7ZKLtLXrCuO4Ad3RWxM_7fm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU", (CX::Int64)sbt_RjKP__jyHh7PWocOGaBl6lEFQHxjCbAEErDiETHnOoO5Ys8vvcU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J", (CX::Int64)sbt_9IrexPytKNbX_pLd2p1ZKhsjw4QHZ2J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.begin(); iter != sbt_a4Qf7Aler9ptJsoX9gDYJeybXIPv8jg_Lihf9kwn5rHJzZggd4V34xD36AmxN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI", (CX::Int64)sbt_5NqHR2KHuE6ioM3NE8izjgpocZPQohp690ZrW8zIiVXVJlfBI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.begin(); iter != sbt_dNWuZ_pUSJuZ6fq5LgGZc04LWdauJuj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY>::Type sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEYArray;

