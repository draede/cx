
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_FW5GTG6t9V_XSet7gY5.hpp"


class sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP;
	CX::String sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx;
	CX::IO::SimpleBuffers::StringArray sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ;
	CX::UInt16 sbt_TawsEu9o3ui;
	CX::IO::SimpleBuffers::Int64Array sbt_S;
	CX::IO::SimpleBuffers::UInt16Array sbt_FEPzLw1K3304yWPc1cO5dMg;
	CX::Int64 sbt_C_6gWEkq0;
	CX::IO::SimpleBuffers::UInt32Array sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof;
	CX::IO::SimpleBuffers::Int64Array sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc;
	CX::Int8 sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE;
	CX::Int8 sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0;
	CX::UInt64 sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug;
	CX::IO::SimpleBuffers::StringArray sbt_tG4GxsMUEQa;
	CX::Double sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG;
	CX::IO::SimpleBuffers::Int16Array sbt_m8yQf67MRl41TGw;
	CX::UInt32 sbt_ltE1U;
	CX::Int16 sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf;
	CX::WString sbt_AnPvy_vpaxkXvZuJe;
	sbt_FW5GTG6t9V_XSet7gY5Array sbt_CjXj86rrJ8D;

	virtual void Reset()
	{
		sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP = 0;
		sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx.clear();
		sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.clear();
		sbt_TawsEu9o3ui = 0;
		sbt_S.clear();
		sbt_FEPzLw1K3304yWPc1cO5dMg.clear();
		sbt_C_6gWEkq0 = 0;
		sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.clear();
		sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.clear();
		sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE = 0;
		sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0 = 0;
		sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug = 0;
		sbt_tG4GxsMUEQa.clear();
		sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG = 0.0;
		sbt_m8yQf67MRl41TGw.clear();
		sbt_ltE1U = 0;
		sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf = 0;
		sbt_AnPvy_vpaxkXvZuJe.clear();
		sbt_CjXj86rrJ8D.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP = 1191504042;
		sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx = "^wq5i[W^3P]s(n\"|>_?>7j^pY%ke1ZK#+:5e&CE#|_Gd5&Iv7>+yC\"sj{ERc";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.push_back("SbF&&Jj'\\!TrB}s9Ix+Guc6Im4P$NUwx0`gp^XZ'TjD<lo2[Iy\"SV5@8");
		}
		sbt_TawsEu9o3ui = 50332;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_S.push_back(-8403437631649193882);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_FEPzLw1K3304yWPc1cO5dMg.push_back(23047);
		}
		sbt_C_6gWEkq0 = 8051968745557104642;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.push_back(2407567879);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.push_back(-6885327244797834828);
		}
		sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE = 58;
		sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0 = 61;
		sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug = 8662312273691128336;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_tG4GxsMUEQa.push_back("F)(0~F$\\K/tqNJn(~=<b>zhV\\)/%+o1XG-KH9r<,>E:y_zY#>'3g[YO54M[}");
		}
		sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG = 0.739250;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_m8yQf67MRl41TGw.push_back(5845);
		}
		sbt_ltE1U = 488217611;
		sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf = -22164;
		sbt_AnPvy_vpaxkXvZuJe = L"7F.G6S!G1_\"8YwW6as(<|+^eX.\"'&W}ku@Z4jm~{_*[LV9";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_FW5GTG6t9V_XSet7gY5 v;

			v.SetupWithSomeValues();
			sbt_CjXj86rrJ8D.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N *pObject = dynamic_cast<const sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP != pObject->sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx.c_str(), pObject->sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx.c_str()))
		{
			return false;
		}
		if (sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.size() != pObject->sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ[i].c_str(), pObject->sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_TawsEu9o3ui != pObject->sbt_TawsEu9o3ui)
		{
			return false;
		}
		if (sbt_S.size() != pObject->sbt_S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S.size(); i++)
		{
			if (sbt_S[i] != pObject->sbt_S[i])
			{
				return false;
			}
		}
		if (sbt_FEPzLw1K3304yWPc1cO5dMg.size() != pObject->sbt_FEPzLw1K3304yWPc1cO5dMg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FEPzLw1K3304yWPc1cO5dMg.size(); i++)
		{
			if (sbt_FEPzLw1K3304yWPc1cO5dMg[i] != pObject->sbt_FEPzLw1K3304yWPc1cO5dMg[i])
			{
				return false;
			}
		}
		if (sbt_C_6gWEkq0 != pObject->sbt_C_6gWEkq0)
		{
			return false;
		}
		if (sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.size() != pObject->sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.size(); i++)
		{
			if (sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof[i] != pObject->sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof[i])
			{
				return false;
			}
		}
		if (sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.size() != pObject->sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.size(); i++)
		{
			if (sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc[i] != pObject->sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc[i])
			{
				return false;
			}
		}
		if (sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE != pObject->sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE)
		{
			return false;
		}
		if (sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0 != pObject->sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0)
		{
			return false;
		}
		if (sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug != pObject->sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug)
		{
			return false;
		}
		if (sbt_tG4GxsMUEQa.size() != pObject->sbt_tG4GxsMUEQa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tG4GxsMUEQa.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tG4GxsMUEQa[i].c_str(), pObject->sbt_tG4GxsMUEQa[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG != pObject->sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG)
		{
			return false;
		}
		if (sbt_m8yQf67MRl41TGw.size() != pObject->sbt_m8yQf67MRl41TGw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m8yQf67MRl41TGw.size(); i++)
		{
			if (sbt_m8yQf67MRl41TGw[i] != pObject->sbt_m8yQf67MRl41TGw[i])
			{
				return false;
			}
		}
		if (sbt_ltE1U != pObject->sbt_ltE1U)
		{
			return false;
		}
		if (sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf != pObject->sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_AnPvy_vpaxkXvZuJe.c_str(), pObject->sbt_AnPvy_vpaxkXvZuJe.c_str()))
		{
			return false;
		}
		if (sbt_CjXj86rrJ8D.size() != pObject->sbt_CjXj86rrJ8D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CjXj86rrJ8D.size(); i++)
		{
			if (!sbt_CjXj86rrJ8D[i].Compare(&pObject->sbt_CjXj86rrJ8D[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx", &sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TawsEu9o3ui", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TawsEu9o3ui = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FEPzLw1K3304yWPc1cO5dMg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FEPzLw1K3304yWPc1cO5dMg.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_C_6gWEkq0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_C_6gWEkq0 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tG4GxsMUEQa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tG4GxsMUEQa.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_m8yQf67MRl41TGw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m8yQf67MRl41TGw.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ltE1U", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ltE1U = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_AnPvy_vpaxkXvZuJe", &sbt_AnPvy_vpaxkXvZuJe)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CjXj86rrJ8D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_FW5GTG6t9V_XSet7gY5 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_CjXj86rrJ8D.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP", (CX::Int64)sbt_9lOnwtKlxf8ZlT9CJdEbacqsQKiW7AmkKg_X7iP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx", sbt_QP4cHaBEpNcc3kdPaUKB9n_iN57dLmaPqSFiphmq47F74DCLUDvmLqx.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.begin(); iter != sbt_J1DBeWcskESqBQXXSLESCQkkaBLiLA7268akWacrOgU43QJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TawsEu9o3ui", (CX::Int64)sbt_TawsEu9o3ui)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_S.begin(); iter != sbt_S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FEPzLw1K3304yWPc1cO5dMg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_FEPzLw1K3304yWPc1cO5dMg.begin(); iter != sbt_FEPzLw1K3304yWPc1cO5dMg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_C_6gWEkq0", (CX::Int64)sbt_C_6gWEkq0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.begin(); iter != sbt_Do6KWLLmeopJET7hEbpfGVDWovcCjLzp5phu_w66rvqUVK8vbrxcBwEof.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.begin(); iter != sbt_P2NjW4JtiNsS1W4fOQ39SULBku5fgZvc9hQiW2T7ptc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE", (CX::Int64)sbt_DCvSXniNiDlm85CvDkWr_WnvXjsxDO3jshCNFkMcnHWukQfj2W4oL9twFIuWEaE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0", (CX::Int64)sbt_y1pZmQLJBFvJYyx69uijtxgriJtLc9F_OYZgV4TZYh5E0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug", (CX::Int64)sbt_rZXlkcjw1LZKPjqg1fafwKiA_POhJ4IusvyqEixhwujC0OQyOXebe3hcdtGug)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tG4GxsMUEQa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tG4GxsMUEQa.begin(); iter != sbt_tG4GxsMUEQa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG", (CX::Double)sbt_VnwUKKOFScff3VKleztj7deWU1g9N6AlpjG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_m8yQf67MRl41TGw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_m8yQf67MRl41TGw.begin(); iter != sbt_m8yQf67MRl41TGw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ltE1U", (CX::Int64)sbt_ltE1U)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf", (CX::Int64)sbt_ZM2H3cRJt1pfHTP1YIobNbZHYr3tj7a3Z33WlbuczOzeHPldxbf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_AnPvy_vpaxkXvZuJe", sbt_AnPvy_vpaxkXvZuJe.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CjXj86rrJ8D")).IsNOK())
		{
			return status;
		}
		for (sbt_FW5GTG6t9V_XSet7gY5Array::const_iterator iter = sbt_CjXj86rrJ8D.begin(); iter != sbt_CjXj86rrJ8D.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N>::Type sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43NArray;

