
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jVSCkaD5dp1.hpp"


class sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_nFkaZtR0aNWO8to2vUOR3;
	CX::IO::SimpleBuffers::Int8Array sbt_z4oVh5ivRfONuS1miVN;
	CX::Double sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5;
	CX::IO::SimpleBuffers::BoolArray sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0;
	CX::UInt64 sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p;
	CX::IO::SimpleBuffers::UInt32Array sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI;
	CX::IO::SimpleBuffers::Int8Array sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE;
	CX::IO::SimpleBuffers::BoolArray sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb;
	CX::IO::SimpleBuffers::UInt32Array sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3;
	CX::UInt64 sbt_FO999iUs_g7d0zINZuZwTvrLit8;
	CX::IO::SimpleBuffers::UInt32Array sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ;
	CX::Int16 sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5;
	CX::IO::SimpleBuffers::UInt64Array sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6;
	CX::Double sbt_suX;
	sbt_jVSCkaD5dp1Array sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG;

	virtual void Reset()
	{
		sbt_nFkaZtR0aNWO8to2vUOR3.clear();
		sbt_z4oVh5ivRfONuS1miVN.clear();
		sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5 = 0.0;
		sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.clear();
		sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p = 0;
		sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.clear();
		sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.clear();
		sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.clear();
		sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.clear();
		sbt_FO999iUs_g7d0zINZuZwTvrLit8 = 0;
		sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.clear();
		sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5 = 0;
		sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.clear();
		sbt_suX = 0.0;
		sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_nFkaZtR0aNWO8to2vUOR3.push_back(1976670951);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_z4oVh5ivRfONuS1miVN.push_back(69);
		}
		sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5 = 0.820203;
		sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p = 13692583632089308842;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.push_back(3110848343);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.push_back(-34);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.push_back(false);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.push_back(329499846);
		}
		sbt_FO999iUs_g7d0zINZuZwTvrLit8 = 7844804846378990640;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.push_back(3416427298);
		}
		sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5 = 18611;
		sbt_suX = 0.824992;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_jVSCkaD5dp1 v;

			v.SetupWithSomeValues();
			sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY *pObject = dynamic_cast<const sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_nFkaZtR0aNWO8to2vUOR3.size() != pObject->sbt_nFkaZtR0aNWO8to2vUOR3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nFkaZtR0aNWO8to2vUOR3.size(); i++)
		{
			if (sbt_nFkaZtR0aNWO8to2vUOR3[i] != pObject->sbt_nFkaZtR0aNWO8to2vUOR3[i])
			{
				return false;
			}
		}
		if (sbt_z4oVh5ivRfONuS1miVN.size() != pObject->sbt_z4oVh5ivRfONuS1miVN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_z4oVh5ivRfONuS1miVN.size(); i++)
		{
			if (sbt_z4oVh5ivRfONuS1miVN[i] != pObject->sbt_z4oVh5ivRfONuS1miVN[i])
			{
				return false;
			}
		}
		if (sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5 != pObject->sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5)
		{
			return false;
		}
		if (sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.size() != pObject->sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.size(); i++)
		{
			if (sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0[i] != pObject->sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0[i])
			{
				return false;
			}
		}
		if (sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p != pObject->sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p)
		{
			return false;
		}
		if (sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.size() != pObject->sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.size(); i++)
		{
			if (sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI[i] != pObject->sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI[i])
			{
				return false;
			}
		}
		if (sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.size() != pObject->sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.size(); i++)
		{
			if (sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE[i] != pObject->sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE[i])
			{
				return false;
			}
		}
		if (sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.size() != pObject->sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.size(); i++)
		{
			if (sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb[i] != pObject->sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb[i])
			{
				return false;
			}
		}
		if (sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.size() != pObject->sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.size(); i++)
		{
			if (sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3[i] != pObject->sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3[i])
			{
				return false;
			}
		}
		if (sbt_FO999iUs_g7d0zINZuZwTvrLit8 != pObject->sbt_FO999iUs_g7d0zINZuZwTvrLit8)
		{
			return false;
		}
		if (sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.size() != pObject->sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.size(); i++)
		{
			if (sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ[i] != pObject->sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ[i])
			{
				return false;
			}
		}
		if (sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5 != pObject->sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5)
		{
			return false;
		}
		if (sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.size() != pObject->sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.size(); i++)
		{
			if (sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6[i] != pObject->sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6[i])
			{
				return false;
			}
		}
		if (sbt_suX != pObject->sbt_suX)
		{
			return false;
		}
		if (sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.size() != pObject->sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.size(); i++)
		{
			if (!sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG[i].Compare(&pObject->sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_nFkaZtR0aNWO8to2vUOR3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nFkaZtR0aNWO8to2vUOR3.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_z4oVh5ivRfONuS1miVN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_z4oVh5ivRfONuS1miVN.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FO999iUs_g7d0zINZuZwTvrLit8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FO999iUs_g7d0zINZuZwTvrLit8 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_suX", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_suX = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_jVSCkaD5dp1 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_nFkaZtR0aNWO8to2vUOR3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_nFkaZtR0aNWO8to2vUOR3.begin(); iter != sbt_nFkaZtR0aNWO8to2vUOR3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_z4oVh5ivRfONuS1miVN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_z4oVh5ivRfONuS1miVN.begin(); iter != sbt_z4oVh5ivRfONuS1miVN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5", (CX::Double)sbt_M1Gj3mxp44qeqULzsWxyusZacxQxPcewa4bP0hCpLBV2q_5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.begin(); iter != sbt_RPj8DYVBHWZpxQeUzbxF87zEISunNrvRvP8nsnVcwAbLCNsrE3eV6Cs4hososf0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p", (CX::Int64)sbt_Al_6DL7jZOrcQPxDXH9Htik6bzFRCsgwdjx5nno96pDcdbZIgbB8DBl2p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.begin(); iter != sbt_4uBXpyd0lMV9KH2GXkOGr3P8RGQMrbVYBkh1IdQsXf3Hl_JTIFM1_9uYtTLaI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.begin(); iter != sbt_QWHPKZcwGNTDYcU4AYokU_MA8aXzE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.begin(); iter != sbt_quT2i02sFhUaBu9aXQc4z_sZJnG8jKA9J7sCY31OW3Qsb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.begin(); iter != sbt_6rUgVab7nBhNPI5g2C4JnTcQhsuV_dFbyBhmMIpcJG_OKCzgT5hMujlpxYhbkB3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FO999iUs_g7d0zINZuZwTvrLit8", (CX::Int64)sbt_FO999iUs_g7d0zINZuZwTvrLit8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.begin(); iter != sbt_vzMQoqGP_6ixYzCLDSQCFaVUTJk64iikTkF6InadW9Au69qKk8tAW4rR1uZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5", (CX::Int64)sbt_v03FLSzdk7gMPTLgQIyKGkt0PswUrvUWKQtjhR5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.begin(); iter != sbt_SUbfhLmkFrhUdAqgJYVPI2c57h7GKHI1AH1v8yRQ8WMlklW8NtMfjIXcCu6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_suX", (CX::Double)sbt_suX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG")).IsNOK())
		{
			return status;
		}
		for (sbt_jVSCkaD5dp1Array::const_iterator iter = sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.begin(); iter != sbt_k0ZRXth_wYmJsb98zDBqiZ07eeoD3ueX_h9_EE6qrbsHOtHh4NNMG.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY>::Type sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKYArray;

