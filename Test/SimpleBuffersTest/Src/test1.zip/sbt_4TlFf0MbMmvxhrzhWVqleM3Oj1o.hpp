
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE;
	CX::UInt16 sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs;
	CX::IO::SimpleBuffers::UInt32Array sbt_SKR3KrbvlkrIf4c5n;
	CX::UInt64 sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI;
	CX::Int64 sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU;
	CX::IO::SimpleBuffers::BoolArray sbt_5pSElBSOd;
	CX::IO::SimpleBuffers::Int64Array sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L;
	CX::IO::SimpleBuffers::UInt16Array sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB;
	CX::String sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed;
	CX::UInt64 sbt_GIDM_16ta9YsewkSd;
	CX::IO::SimpleBuffers::Int32Array sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k;
	CX::UInt32 sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6;
	CX::IO::SimpleBuffers::UInt8Array sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4;
	CX::IO::SimpleBuffers::UInt64Array sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn;
	CX::Int32 sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO;
	CX::IO::SimpleBuffers::UInt64Array sbt_ylD9AiFuwj3XKzaLCYP_XXq;
	CX::String sbt_gwa2AyOpDsUBE;
	CX::IO::SimpleBuffers::UInt64Array sbt_1fshjRFctiEggvV3au7KhfwzYW1;
	CX::IO::SimpleBuffers::UInt32Array sbt_oTDRPQsjPR9fwLgXYFc;
	CX::UInt8 sbt_5i62Zz26uoy0heG;
	CX::UInt32 sbt_m5NrbI4iZn5R0s_RlLuX1;
	CX::UInt8 sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca;
	CX::IO::SimpleBuffers::UInt64Array sbt_C;
	CX::IO::SimpleBuffers::BoolArray sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ;
	CX::IO::SimpleBuffers::UInt64Array sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ;

	virtual void Reset()
	{
		sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.clear();
		sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs = 0;
		sbt_SKR3KrbvlkrIf4c5n.clear();
		sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI = 0;
		sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU = 0;
		sbt_5pSElBSOd.clear();
		sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.clear();
		sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.clear();
		sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed.clear();
		sbt_GIDM_16ta9YsewkSd = 0;
		sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.clear();
		sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6 = 0;
		sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.clear();
		sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.clear();
		sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO = 0;
		sbt_ylD9AiFuwj3XKzaLCYP_XXq.clear();
		sbt_gwa2AyOpDsUBE.clear();
		sbt_1fshjRFctiEggvV3au7KhfwzYW1.clear();
		sbt_oTDRPQsjPR9fwLgXYFc.clear();
		sbt_5i62Zz26uoy0heG = 0;
		sbt_m5NrbI4iZn5R0s_RlLuX1 = 0;
		sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca = 0;
		sbt_C.clear();
		sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.clear();
		sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.push_back(3207779983);
		}
		sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs = 48610;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_SKR3KrbvlkrIf4c5n.push_back(4139443717);
		}
		sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI = 14612442493477143274;
		sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU = 3374063972191261272;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_5pSElBSOd.push_back(false);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.push_back(-7386983300957317554);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.push_back(55892);
		}
		sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed = "15\"22/RMkWZ%PD=T.L(kPA,Qx7$U$xLMk3;67.g{^\"kaM+^vw0S#0JV~|Ym";
		sbt_GIDM_16ta9YsewkSd = 6730768927082430622;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.push_back(134722271);
		}
		sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6 = 1463253739;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.push_back(167);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.push_back(1713501959871272710);
		}
		sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO = -1015359683;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_ylD9AiFuwj3XKzaLCYP_XXq.push_back(3079122014918695186);
		}
		sbt_gwa2AyOpDsUBE = "p$Njz~:|M9?84}.N8Bh3rSq?\"Hz?,^v{WdoF]oFThQV>!";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_1fshjRFctiEggvV3au7KhfwzYW1.push_back(8586047597501452652);
		}
		sbt_5i62Zz26uoy0heG = 57;
		sbt_m5NrbI4iZn5R0s_RlLuX1 = 525403692;
		sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca = 97;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_C.push_back(3175753310908502872);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.push_back(false);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.push_back(12961535203716683282);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o *pObject = dynamic_cast<const sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.size() != pObject->sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.size(); i++)
		{
			if (sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE[i] != pObject->sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE[i])
			{
				return false;
			}
		}
		if (sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs != pObject->sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs)
		{
			return false;
		}
		if (sbt_SKR3KrbvlkrIf4c5n.size() != pObject->sbt_SKR3KrbvlkrIf4c5n.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SKR3KrbvlkrIf4c5n.size(); i++)
		{
			if (sbt_SKR3KrbvlkrIf4c5n[i] != pObject->sbt_SKR3KrbvlkrIf4c5n[i])
			{
				return false;
			}
		}
		if (sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI != pObject->sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI)
		{
			return false;
		}
		if (sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU != pObject->sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU)
		{
			return false;
		}
		if (sbt_5pSElBSOd.size() != pObject->sbt_5pSElBSOd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5pSElBSOd.size(); i++)
		{
			if (sbt_5pSElBSOd[i] != pObject->sbt_5pSElBSOd[i])
			{
				return false;
			}
		}
		if (sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.size() != pObject->sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.size(); i++)
		{
			if (sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L[i] != pObject->sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L[i])
			{
				return false;
			}
		}
		if (sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.size() != pObject->sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.size(); i++)
		{
			if (sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB[i] != pObject->sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed.c_str(), pObject->sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed.c_str()))
		{
			return false;
		}
		if (sbt_GIDM_16ta9YsewkSd != pObject->sbt_GIDM_16ta9YsewkSd)
		{
			return false;
		}
		if (sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.size() != pObject->sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.size(); i++)
		{
			if (sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k[i] != pObject->sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k[i])
			{
				return false;
			}
		}
		if (sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6 != pObject->sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6)
		{
			return false;
		}
		if (sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.size() != pObject->sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.size(); i++)
		{
			if (sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4[i] != pObject->sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4[i])
			{
				return false;
			}
		}
		if (sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.size() != pObject->sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.size(); i++)
		{
			if (sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn[i] != pObject->sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn[i])
			{
				return false;
			}
		}
		if (sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO != pObject->sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO)
		{
			return false;
		}
		if (sbt_ylD9AiFuwj3XKzaLCYP_XXq.size() != pObject->sbt_ylD9AiFuwj3XKzaLCYP_XXq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ylD9AiFuwj3XKzaLCYP_XXq.size(); i++)
		{
			if (sbt_ylD9AiFuwj3XKzaLCYP_XXq[i] != pObject->sbt_ylD9AiFuwj3XKzaLCYP_XXq[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_gwa2AyOpDsUBE.c_str(), pObject->sbt_gwa2AyOpDsUBE.c_str()))
		{
			return false;
		}
		if (sbt_1fshjRFctiEggvV3au7KhfwzYW1.size() != pObject->sbt_1fshjRFctiEggvV3au7KhfwzYW1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1fshjRFctiEggvV3au7KhfwzYW1.size(); i++)
		{
			if (sbt_1fshjRFctiEggvV3au7KhfwzYW1[i] != pObject->sbt_1fshjRFctiEggvV3au7KhfwzYW1[i])
			{
				return false;
			}
		}
		if (sbt_oTDRPQsjPR9fwLgXYFc.size() != pObject->sbt_oTDRPQsjPR9fwLgXYFc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oTDRPQsjPR9fwLgXYFc.size(); i++)
		{
			if (sbt_oTDRPQsjPR9fwLgXYFc[i] != pObject->sbt_oTDRPQsjPR9fwLgXYFc[i])
			{
				return false;
			}
		}
		if (sbt_5i62Zz26uoy0heG != pObject->sbt_5i62Zz26uoy0heG)
		{
			return false;
		}
		if (sbt_m5NrbI4iZn5R0s_RlLuX1 != pObject->sbt_m5NrbI4iZn5R0s_RlLuX1)
		{
			return false;
		}
		if (sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca != pObject->sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca)
		{
			return false;
		}
		if (sbt_C.size() != pObject->sbt_C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C.size(); i++)
		{
			if (sbt_C[i] != pObject->sbt_C[i])
			{
				return false;
			}
		}
		if (sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.size() != pObject->sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.size(); i++)
		{
			if (sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ[i] != pObject->sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ[i])
			{
				return false;
			}
		}
		if (sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.size() != pObject->sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.size(); i++)
		{
			if (sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ[i] != pObject->sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SKR3KrbvlkrIf4c5n")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SKR3KrbvlkrIf4c5n.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5pSElBSOd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5pSElBSOd.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed", &sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GIDM_16ta9YsewkSd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GIDM_16ta9YsewkSd = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ylD9AiFuwj3XKzaLCYP_XXq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ylD9AiFuwj3XKzaLCYP_XXq.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_gwa2AyOpDsUBE", &sbt_gwa2AyOpDsUBE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1fshjRFctiEggvV3au7KhfwzYW1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1fshjRFctiEggvV3au7KhfwzYW1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oTDRPQsjPR9fwLgXYFc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oTDRPQsjPR9fwLgXYFc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5i62Zz26uoy0heG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5i62Zz26uoy0heG = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_m5NrbI4iZn5R0s_RlLuX1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_m5NrbI4iZn5R0s_RlLuX1 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.begin(); iter != sbt_2JbDgxyZctPzoGoG6BrqR2s2Ppx9wNnRWff6jkE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs", (CX::Int64)sbt_2q3x0n28m3dQJv3Ej007bXou0wFDDaEQHbs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SKR3KrbvlkrIf4c5n")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_SKR3KrbvlkrIf4c5n.begin(); iter != sbt_SKR3KrbvlkrIf4c5n.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI", (CX::Int64)sbt_mNy1qbRlFeev1DVLfWkFKRsMjYI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU", (CX::Int64)sbt__ceaT0vWh2uN9AhRwTdpAXiUt5tv4DU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5pSElBSOd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_5pSElBSOd.begin(); iter != sbt_5pSElBSOd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.begin(); iter != sbt_S2JG_pUEDre0CnUAKygX9yxyBZX98Gk_kliwk6L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.begin(); iter != sbt_JR4YkGwKAWyOBJGc6bvA_dHrrPtxqFZqtYbOz15zAr0KiXS7KKnLjKH7QmXjPYB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed", sbt_ug7YTtHt1alTpAcyjSKv3Hx1_EndiRC3dNVnfZiyqPgsCB8kK6cu5Oxx9ed.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GIDM_16ta9YsewkSd", (CX::Int64)sbt_GIDM_16ta9YsewkSd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.begin(); iter != sbt_IA9O_0bdK4m4XlPSPxGXahpzu3XY2KI1k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6", (CX::Int64)sbt_bmLhuei70nVGVJbGsMxQTLUtUep7b1mxXman6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.begin(); iter != sbt_QbHwoz07Q35hjWMq2D9XoDvf9J4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.begin(); iter != sbt_CREBNEmQE_Q49ag_XMoiofXmYN2vCcCLn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO", (CX::Int64)sbt_QWu3Q8x2MvofGMttYV4_nH5oEXx9ThJMFfImO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ylD9AiFuwj3XKzaLCYP_XXq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ylD9AiFuwj3XKzaLCYP_XXq.begin(); iter != sbt_ylD9AiFuwj3XKzaLCYP_XXq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_gwa2AyOpDsUBE", sbt_gwa2AyOpDsUBE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1fshjRFctiEggvV3au7KhfwzYW1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_1fshjRFctiEggvV3au7KhfwzYW1.begin(); iter != sbt_1fshjRFctiEggvV3au7KhfwzYW1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oTDRPQsjPR9fwLgXYFc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_oTDRPQsjPR9fwLgXYFc.begin(); iter != sbt_oTDRPQsjPR9fwLgXYFc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5i62Zz26uoy0heG", (CX::Int64)sbt_5i62Zz26uoy0heG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_m5NrbI4iZn5R0s_RlLuX1", (CX::Int64)sbt_m5NrbI4iZn5R0s_RlLuX1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca", (CX::Int64)sbt_7CE_WZjNL0smb5vNpFHROv95MEZjSBfFz5vsTL4rCNA9BX1fc7EtZr6sCfvB5ca)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_C.begin(); iter != sbt_C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.begin(); iter != sbt_A0L2yawo_48oefMXA1bSV_VF6Dnl5WWDGIlMOeuFPE0Q5PRE7LQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.begin(); iter != sbt_6wygmaCJvX4B7dTVREtk1Y4VLW11I_4S5ltyIttoI0PdGlf2skxXAgK2o3dMwPJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o>::Type sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1oArray;

