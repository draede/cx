
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_0uCXiph9R2MT1pEZxqZlDVP.hpp"


class sbt_D2lgRi655HoJQnFlCbXM6T3AtbE : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu;
	CX::Int32 sbt_YgwRMBsebDV;
	CX::Bool sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1;
	CX::String sbt_OwSXYMu20acp6HW;
	CX::IO::SimpleBuffers::FloatArray sbt_C6bJxJyWbVSLhDuv0o_XFek;
	CX::IO::SimpleBuffers::BoolArray sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R;
	CX::IO::SimpleBuffers::Int32Array sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY;
	CX::IO::SimpleBuffers::UInt16Array sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd;
	CX::Bool sbt_hqGOWjc4e;
	CX::IO::SimpleBuffers::WStringArray sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx;
	CX::IO::SimpleBuffers::Int16Array sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR;
	CX::Int16 sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w;
	CX::IO::SimpleBuffers::Int32Array sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs;
	CX::IO::SimpleBuffers::DoubleArray sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_;
	CX::IO::SimpleBuffers::WStringArray sbt_tDOI2djmgzumm9PTXOPtw;
	CX::IO::SimpleBuffers::UInt64Array sbt_eE8F6vnvWMeTabi2L2SEw;
	CX::UInt8 sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0;
	CX::Int64 sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F;
	CX::IO::SimpleBuffers::UInt32Array sbt_Tj0pgGO1WG3;
	CX::IO::SimpleBuffers::UInt32Array sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc;
	CX::Double sbt_F2PxwuW;
	CX::IO::SimpleBuffers::Int8Array sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl;
	CX::UInt32 sbt_mAWoq;
	CX::IO::SimpleBuffers::UInt16Array sbt_w5pN3qyaJUGXIdYjV_6p2anbB;
	CX::UInt16 sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE;
	CX::IO::SimpleBuffers::UInt16Array sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup;
	CX::String sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb;
	CX::IO::SimpleBuffers::UInt16Array sbt_Vbek5YLUzZNSZEn84seh8;
	CX::IO::SimpleBuffers::StringArray sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM;
	sbt_0uCXiph9R2MT1pEZxqZlDVP sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ;

	virtual void Reset()
	{
		sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu.clear();
		sbt_YgwRMBsebDV = 0;
		sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1 = false;
		sbt_OwSXYMu20acp6HW.clear();
		sbt_C6bJxJyWbVSLhDuv0o_XFek.clear();
		sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.clear();
		sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.clear();
		sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.clear();
		sbt_hqGOWjc4e = false;
		sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.clear();
		sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.clear();
		sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w = 0;
		sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.clear();
		sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.clear();
		sbt_tDOI2djmgzumm9PTXOPtw.clear();
		sbt_eE8F6vnvWMeTabi2L2SEw.clear();
		sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0 = 0;
		sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F = 0;
		sbt_Tj0pgGO1WG3.clear();
		sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.clear();
		sbt_F2PxwuW = 0.0;
		sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.clear();
		sbt_mAWoq = 0;
		sbt_w5pN3qyaJUGXIdYjV_6p2anbB.clear();
		sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE = 0;
		sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.clear();
		sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb.clear();
		sbt_Vbek5YLUzZNSZEn84seh8.clear();
		sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.clear();
		sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu = L"%.:CQ&odJM=HuS)A<VV~C1h)ON-s|xsKsA8I";
		sbt_YgwRMBsebDV = 929481394;
		sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1 = false;
		sbt_OwSXYMu20acp6HW = "/!v(^4";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_C6bJxJyWbVSLhDuv0o_XFek.push_back(0.413876f);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.push_back(false);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.push_back(669720551);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.push_back(48255);
		}
		sbt_hqGOWjc4e = true;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.push_back(L"UW3(}.^!>%C[98D");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.push_back(-30992);
		}
		sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w = 5792;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.push_back(1486282087);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.push_back(0.524330);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_tDOI2djmgzumm9PTXOPtw.push_back(L"clr;xZ<y|+RD5h^VlD'TWi4~*5sQR[[0%hQ?OF");
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_eE8F6vnvWMeTabi2L2SEw.push_back(15283871251243985700);
		}
		sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0 = 19;
		sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F = 7656584667085138464;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Tj0pgGO1WG3.push_back(3414303893);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.push_back(836597075);
		}
		sbt_F2PxwuW = 0.709666;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.push_back(-117);
		}
		sbt_mAWoq = 3122407086;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_w5pN3qyaJUGXIdYjV_6p2anbB.push_back(33205);
		}
		sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE = 17025;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.push_back(52909);
		}
		sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb = "aSByw*Wm^O*0=CaGs$86e`]$/@puXXKSzA";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Vbek5YLUzZNSZEn84seh8.push_back(44409);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.push_back("zydJGPX(*7WPE?Z#;UN_&1)St$2?B<92e`tSpUez1rb[|V5)vW9s3,U@SS#^H");
		}
		sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_D2lgRi655HoJQnFlCbXM6T3AtbE *pObject = dynamic_cast<const sbt_D2lgRi655HoJQnFlCbXM6T3AtbE *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu.c_str(), pObject->sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu.c_str()))
		{
			return false;
		}
		if (sbt_YgwRMBsebDV != pObject->sbt_YgwRMBsebDV)
		{
			return false;
		}
		if (sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1 != pObject->sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_OwSXYMu20acp6HW.c_str(), pObject->sbt_OwSXYMu20acp6HW.c_str()))
		{
			return false;
		}
		if (sbt_C6bJxJyWbVSLhDuv0o_XFek.size() != pObject->sbt_C6bJxJyWbVSLhDuv0o_XFek.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C6bJxJyWbVSLhDuv0o_XFek.size(); i++)
		{
			if (sbt_C6bJxJyWbVSLhDuv0o_XFek[i] != pObject->sbt_C6bJxJyWbVSLhDuv0o_XFek[i])
			{
				return false;
			}
		}
		if (sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.size() != pObject->sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.size(); i++)
		{
			if (sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R[i] != pObject->sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R[i])
			{
				return false;
			}
		}
		if (sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.size() != pObject->sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.size(); i++)
		{
			if (sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY[i] != pObject->sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY[i])
			{
				return false;
			}
		}
		if (sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.size() != pObject->sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.size(); i++)
		{
			if (sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd[i] != pObject->sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd[i])
			{
				return false;
			}
		}
		if (sbt_hqGOWjc4e != pObject->sbt_hqGOWjc4e)
		{
			return false;
		}
		if (sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.size() != pObject->sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx[i].c_str(), pObject->sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.size() != pObject->sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.size(); i++)
		{
			if (sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR[i] != pObject->sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR[i])
			{
				return false;
			}
		}
		if (sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w != pObject->sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w)
		{
			return false;
		}
		if (sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.size() != pObject->sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.size(); i++)
		{
			if (sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs[i] != pObject->sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs[i])
			{
				return false;
			}
		}
		if (sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.size() != pObject->sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.size(); i++)
		{
			if (sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_[i] != pObject->sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_[i])
			{
				return false;
			}
		}
		if (sbt_tDOI2djmgzumm9PTXOPtw.size() != pObject->sbt_tDOI2djmgzumm9PTXOPtw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tDOI2djmgzumm9PTXOPtw.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_tDOI2djmgzumm9PTXOPtw[i].c_str(), pObject->sbt_tDOI2djmgzumm9PTXOPtw[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_eE8F6vnvWMeTabi2L2SEw.size() != pObject->sbt_eE8F6vnvWMeTabi2L2SEw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eE8F6vnvWMeTabi2L2SEw.size(); i++)
		{
			if (sbt_eE8F6vnvWMeTabi2L2SEw[i] != pObject->sbt_eE8F6vnvWMeTabi2L2SEw[i])
			{
				return false;
			}
		}
		if (sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0 != pObject->sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0)
		{
			return false;
		}
		if (sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F != pObject->sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F)
		{
			return false;
		}
		if (sbt_Tj0pgGO1WG3.size() != pObject->sbt_Tj0pgGO1WG3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Tj0pgGO1WG3.size(); i++)
		{
			if (sbt_Tj0pgGO1WG3[i] != pObject->sbt_Tj0pgGO1WG3[i])
			{
				return false;
			}
		}
		if (sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.size() != pObject->sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.size(); i++)
		{
			if (sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc[i] != pObject->sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc[i])
			{
				return false;
			}
		}
		if (sbt_F2PxwuW != pObject->sbt_F2PxwuW)
		{
			return false;
		}
		if (sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.size() != pObject->sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.size(); i++)
		{
			if (sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl[i] != pObject->sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl[i])
			{
				return false;
			}
		}
		if (sbt_mAWoq != pObject->sbt_mAWoq)
		{
			return false;
		}
		if (sbt_w5pN3qyaJUGXIdYjV_6p2anbB.size() != pObject->sbt_w5pN3qyaJUGXIdYjV_6p2anbB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_w5pN3qyaJUGXIdYjV_6p2anbB.size(); i++)
		{
			if (sbt_w5pN3qyaJUGXIdYjV_6p2anbB[i] != pObject->sbt_w5pN3qyaJUGXIdYjV_6p2anbB[i])
			{
				return false;
			}
		}
		if (sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE != pObject->sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE)
		{
			return false;
		}
		if (sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.size() != pObject->sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.size(); i++)
		{
			if (sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup[i] != pObject->sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb.c_str(), pObject->sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb.c_str()))
		{
			return false;
		}
		if (sbt_Vbek5YLUzZNSZEn84seh8.size() != pObject->sbt_Vbek5YLUzZNSZEn84seh8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Vbek5YLUzZNSZEn84seh8.size(); i++)
		{
			if (sbt_Vbek5YLUzZNSZEn84seh8[i] != pObject->sbt_Vbek5YLUzZNSZEn84seh8[i])
			{
				return false;
			}
		}
		if (sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.size() != pObject->sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.size(); i++)
		{
			if (0 != cx_strcmp(sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM[i].c_str(), pObject->sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM[i].c_str()))
			{
				return false;
			}
		}
		if (!sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ.Compare(&pObject->sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu", &sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YgwRMBsebDV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YgwRMBsebDV = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1", &sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_OwSXYMu20acp6HW", &sbt_OwSXYMu20acp6HW)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_C6bJxJyWbVSLhDuv0o_XFek")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C6bJxJyWbVSLhDuv0o_XFek.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_hqGOWjc4e", &sbt_hqGOWjc4e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tDOI2djmgzumm9PTXOPtw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tDOI2djmgzumm9PTXOPtw.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eE8F6vnvWMeTabi2L2SEw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eE8F6vnvWMeTabi2L2SEw.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Tj0pgGO1WG3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Tj0pgGO1WG3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_F2PxwuW", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_F2PxwuW = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mAWoq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mAWoq = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_w5pN3qyaJUGXIdYjV_6p2anbB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_w5pN3qyaJUGXIdYjV_6p2anbB.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb", &sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Vbek5YLUzZNSZEn84seh8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Vbek5YLUzZNSZEn84seh8.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu", sbt_2Md56fq5hRUhmmBtbZAH67PszdLKhMOilL503Pu.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YgwRMBsebDV", (CX::Int64)sbt_YgwRMBsebDV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1", sbt_Y5Ed2mTiDHfykJ6ao4EbN1t5yQt0ZOhJHI9jbGlH1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_OwSXYMu20acp6HW", sbt_OwSXYMu20acp6HW.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C6bJxJyWbVSLhDuv0o_XFek")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_C6bJxJyWbVSLhDuv0o_XFek.begin(); iter != sbt_C6bJxJyWbVSLhDuv0o_XFek.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.begin(); iter != sbt_f9qsANTM6_QXCGMbRGb_oRRNqCutoLLz0A5GEGwViqcco0R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.begin(); iter != sbt_o0GlEgVo0fHKhN0lFa1Pbb24PX2W94phZOY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.begin(); iter != sbt_cRfejpVWzKD4s1pBgauPp5TBsSuuGITBjU7yd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_hqGOWjc4e", sbt_hqGOWjc4e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.begin(); iter != sbt_Wmt1zrRKFSOOnGE4PWGwTXkBZS2tcpmC4RKz97qa2PGZ87UGkhuUh7qpx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.begin(); iter != sbt_l2vTI8SYmfK8pPMIlxxPrc2q9QqNAn315fkEZE_S9UMQ0ZKqR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w", (CX::Int64)sbt_wPjlY1MU9qbU1taqaZLtd1PP_3njd3HJoB7nXTJK8Dg0NGkGcp55LMUTwDqan1w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.begin(); iter != sbt_GHWPTBKr3lb86JXi2qD0Jqayb52cUIvf5oGjI0KljoLFs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.begin(); iter != sbt_BpDsYDkwOlKZyYBFmq9TWl0a0L869u2GLa_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tDOI2djmgzumm9PTXOPtw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_tDOI2djmgzumm9PTXOPtw.begin(); iter != sbt_tDOI2djmgzumm9PTXOPtw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eE8F6vnvWMeTabi2L2SEw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_eE8F6vnvWMeTabi2L2SEw.begin(); iter != sbt_eE8F6vnvWMeTabi2L2SEw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0", (CX::Int64)sbt_IKpdW7M3ZvNwdJBo7pgw6_X8gFvSptWYnNmv0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F", (CX::Int64)sbt_v6uVnjN31CnTpMj_PWpf8zNOODK6nZ1qlPq3F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Tj0pgGO1WG3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Tj0pgGO1WG3.begin(); iter != sbt_Tj0pgGO1WG3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.begin(); iter != sbt__IBoToYMh0EoJ6SukQfuwzI2OhFo7isGunrKCNOi9fDu6FBdc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_F2PxwuW", (CX::Double)sbt_F2PxwuW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.begin(); iter != sbt_YPUpsGzAamrkCEo9HkAMSrhF2Kowl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mAWoq", (CX::Int64)sbt_mAWoq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_w5pN3qyaJUGXIdYjV_6p2anbB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_w5pN3qyaJUGXIdYjV_6p2anbB.begin(); iter != sbt_w5pN3qyaJUGXIdYjV_6p2anbB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE", (CX::Int64)sbt_Fx7IgbqpoBks32R4tI4E6dmcRXybdPdwnyS8Y2bOjMPdPp662cQFEmjsE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.begin(); iter != sbt_48OOZpchzH_y2CCE5WDZkeCA4wdGNup.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb", sbt_rGM1O2k8WYcd_ig_a3gxVH69H88pb.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Vbek5YLUzZNSZEn84seh8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Vbek5YLUzZNSZEn84seh8.begin(); iter != sbt_Vbek5YLUzZNSZEn84seh8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.begin(); iter != sbt_s8M_vDQgg06JizyvqwgucdBgoyd8HejBoXJeve7GxfM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Z8yKTa4Cnbz9XSseyYh5l2_zlaZKt2q5wcGUs5HoLpLM0_btfZh8M7S65DAgIsZ.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_D2lgRi655HoJQnFlCbXM6T3AtbE>::Type sbt_D2lgRi655HoJQnFlCbXM6T3AtbEArray;

