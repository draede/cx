
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_4WlGd9_LehN8dLwRaQS : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG;
	CX::Bool sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm;
	CX::Int32 sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs;
	CX::IO::SimpleBuffers::BoolArray sbt_9x8cA89RSTupA21pmHstNSWCiO8iS;
	CX::IO::SimpleBuffers::StringArray sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I;
	CX::IO::SimpleBuffers::Int32Array sbt_f10PQQmF5Ns6M42Mo;
	CX::IO::SimpleBuffers::UInt32Array sbt_HNshUaiIwWNmogeL0QgAUsMQmGf;
	CX::IO::SimpleBuffers::UInt8Array sbt_4KgpOW25EJTlAJ0c11zxte8;
	CX::IO::SimpleBuffers::UInt32Array sbt_LK_T33aP84uxUbKRQ;
	CX::Int64 sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId;
	CX::UInt8 sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv;
	CX::Int32 sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg;
	CX::Bool sbt_Sqv5e8ABpx5D86g;
	CX::UInt32 sbt_OPZ;
	CX::IO::SimpleBuffers::UInt64Array sbt_04z6ctsGk9k1lWepdQVXptYoXK7;
	CX::Int8 sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ;
	CX::UInt64 sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX;
	CX::UInt32 sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW;
	CX::Int32 sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6;
	CX::UInt32 sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3;
	CX::Int64 sbt_tPrqQa79gM_0N;
	CX::Int32 sbt_XCDFAwmIeSiDIoCWoVMyl;
	CX::String sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J;

	virtual void Reset()
	{
		sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.clear();
		sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm = false;
		sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs = 0;
		sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.clear();
		sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.clear();
		sbt_f10PQQmF5Ns6M42Mo.clear();
		sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.clear();
		sbt_4KgpOW25EJTlAJ0c11zxte8.clear();
		sbt_LK_T33aP84uxUbKRQ.clear();
		sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId = 0;
		sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv = 0;
		sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg = 0;
		sbt_Sqv5e8ABpx5D86g = false;
		sbt_OPZ = 0;
		sbt_04z6ctsGk9k1lWepdQVXptYoXK7.clear();
		sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ = 0;
		sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX = 0;
		sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW = 0;
		sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6 = 0;
		sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3 = 0;
		sbt_tPrqQa79gM_0N = 0;
		sbt_XCDFAwmIeSiDIoCWoVMyl = 0;
		sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.push_back(759894705);
		}
		sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm = false;
		sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs = 1656998922;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.push_back(false);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.push_back("*&K@4^oN3YsKsl(c(R>4X/i1w\\`w99|@B2jOBOaP9n");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_f10PQQmF5Ns6M42Mo.push_back(719340396);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.push_back(2895667888);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_4KgpOW25EJTlAJ0c11zxte8.push_back(67);
		}
		sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId = -4921983477486125880;
		sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv = 160;
		sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg = -443332970;
		sbt_Sqv5e8ABpx5D86g = false;
		sbt_OPZ = 2873643948;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_04z6ctsGk9k1lWepdQVXptYoXK7.push_back(4863317242733514874);
		}
		sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ = 37;
		sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX = 13474738278674784032;
		sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW = 3610299892;
		sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6 = 1118903696;
		sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3 = 578005611;
		sbt_tPrqQa79gM_0N = -8890667285513805412;
		sbt_XCDFAwmIeSiDIoCWoVMyl = 1411583630;
		sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J = "*nU8hOY(";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4WlGd9_LehN8dLwRaQS *pObject = dynamic_cast<const sbt_4WlGd9_LehN8dLwRaQS *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.size() != pObject->sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.size(); i++)
		{
			if (sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG[i] != pObject->sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG[i])
			{
				return false;
			}
		}
		if (sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm != pObject->sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm)
		{
			return false;
		}
		if (sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs != pObject->sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs)
		{
			return false;
		}
		if (sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.size() != pObject->sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.size(); i++)
		{
			if (sbt_9x8cA89RSTupA21pmHstNSWCiO8iS[i] != pObject->sbt_9x8cA89RSTupA21pmHstNSWCiO8iS[i])
			{
				return false;
			}
		}
		if (sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.size() != pObject->sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.size(); i++)
		{
			if (0 != cx_strcmp(sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I[i].c_str(), pObject->sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_f10PQQmF5Ns6M42Mo.size() != pObject->sbt_f10PQQmF5Ns6M42Mo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f10PQQmF5Ns6M42Mo.size(); i++)
		{
			if (sbt_f10PQQmF5Ns6M42Mo[i] != pObject->sbt_f10PQQmF5Ns6M42Mo[i])
			{
				return false;
			}
		}
		if (sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.size() != pObject->sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.size(); i++)
		{
			if (sbt_HNshUaiIwWNmogeL0QgAUsMQmGf[i] != pObject->sbt_HNshUaiIwWNmogeL0QgAUsMQmGf[i])
			{
				return false;
			}
		}
		if (sbt_4KgpOW25EJTlAJ0c11zxte8.size() != pObject->sbt_4KgpOW25EJTlAJ0c11zxte8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4KgpOW25EJTlAJ0c11zxte8.size(); i++)
		{
			if (sbt_4KgpOW25EJTlAJ0c11zxte8[i] != pObject->sbt_4KgpOW25EJTlAJ0c11zxte8[i])
			{
				return false;
			}
		}
		if (sbt_LK_T33aP84uxUbKRQ.size() != pObject->sbt_LK_T33aP84uxUbKRQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LK_T33aP84uxUbKRQ.size(); i++)
		{
			if (sbt_LK_T33aP84uxUbKRQ[i] != pObject->sbt_LK_T33aP84uxUbKRQ[i])
			{
				return false;
			}
		}
		if (sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId != pObject->sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId)
		{
			return false;
		}
		if (sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv != pObject->sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv)
		{
			return false;
		}
		if (sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg != pObject->sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg)
		{
			return false;
		}
		if (sbt_Sqv5e8ABpx5D86g != pObject->sbt_Sqv5e8ABpx5D86g)
		{
			return false;
		}
		if (sbt_OPZ != pObject->sbt_OPZ)
		{
			return false;
		}
		if (sbt_04z6ctsGk9k1lWepdQVXptYoXK7.size() != pObject->sbt_04z6ctsGk9k1lWepdQVXptYoXK7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_04z6ctsGk9k1lWepdQVXptYoXK7.size(); i++)
		{
			if (sbt_04z6ctsGk9k1lWepdQVXptYoXK7[i] != pObject->sbt_04z6ctsGk9k1lWepdQVXptYoXK7[i])
			{
				return false;
			}
		}
		if (sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ != pObject->sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ)
		{
			return false;
		}
		if (sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX != pObject->sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX)
		{
			return false;
		}
		if (sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW != pObject->sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW)
		{
			return false;
		}
		if (sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6 != pObject->sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6)
		{
			return false;
		}
		if (sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3 != pObject->sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3)
		{
			return false;
		}
		if (sbt_tPrqQa79gM_0N != pObject->sbt_tPrqQa79gM_0N)
		{
			return false;
		}
		if (sbt_XCDFAwmIeSiDIoCWoVMyl != pObject->sbt_XCDFAwmIeSiDIoCWoVMyl)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J.c_str(), pObject->sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm", &sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9x8cA89RSTupA21pmHstNSWCiO8iS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f10PQQmF5Ns6M42Mo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f10PQQmF5Ns6M42Mo.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HNshUaiIwWNmogeL0QgAUsMQmGf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4KgpOW25EJTlAJ0c11zxte8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4KgpOW25EJTlAJ0c11zxte8.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LK_T33aP84uxUbKRQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LK_T33aP84uxUbKRQ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_Sqv5e8ABpx5D86g", &sbt_Sqv5e8ABpx5D86g)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OPZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OPZ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_04z6ctsGk9k1lWepdQVXptYoXK7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_04z6ctsGk9k1lWepdQVXptYoXK7.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_tPrqQa79gM_0N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tPrqQa79gM_0N = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XCDFAwmIeSiDIoCWoVMyl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XCDFAwmIeSiDIoCWoVMyl = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J", &sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.begin(); iter != sbt_NbvrgO5o0SFzfd0Q2Qd4YrqlOTbB0bLQz_oAJPbWx_2L5DSw4TuYG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm", sbt_Q0AFxLPAQQCuJtytvHSrklKC6KFWggm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs", (CX::Int64)sbt_Apw_lkVygBlbdleUM6BeW17Bc3EvPlBF9JsLrlSC4ApdtBNl8pgfs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9x8cA89RSTupA21pmHstNSWCiO8iS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.begin(); iter != sbt_9x8cA89RSTupA21pmHstNSWCiO8iS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.begin(); iter != sbt_9YorzfGmflf7IT38G1d6vY8ASBI0I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f10PQQmF5Ns6M42Mo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_f10PQQmF5Ns6M42Mo.begin(); iter != sbt_f10PQQmF5Ns6M42Mo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HNshUaiIwWNmogeL0QgAUsMQmGf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.begin(); iter != sbt_HNshUaiIwWNmogeL0QgAUsMQmGf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4KgpOW25EJTlAJ0c11zxte8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_4KgpOW25EJTlAJ0c11zxte8.begin(); iter != sbt_4KgpOW25EJTlAJ0c11zxte8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LK_T33aP84uxUbKRQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_LK_T33aP84uxUbKRQ.begin(); iter != sbt_LK_T33aP84uxUbKRQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId", (CX::Int64)sbt_AOlBwNulcWl2twVMJgKIpC0l6LZv20aIhuK2BFXZh_L7bbTBP6DZrdpId)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv", (CX::Int64)sbt_55m7qnsFh9qiOVKUDQlDyQ5it2iC9hmpRCLvv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg", (CX::Int64)sbt_VNSgzUpFGKwIJ1EDyCjMGeMDAd5nLxcUWzhodOhTwhAIg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Sqv5e8ABpx5D86g", sbt_Sqv5e8ABpx5D86g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OPZ", (CX::Int64)sbt_OPZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_04z6ctsGk9k1lWepdQVXptYoXK7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_04z6ctsGk9k1lWepdQVXptYoXK7.begin(); iter != sbt_04z6ctsGk9k1lWepdQVXptYoXK7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ", (CX::Int64)sbt_c9d9hn30ZvZSnEX1qoaKQxLHfDMIG8z0rezkDNxjVyQ4TPpNPeRquQWu1rF6rlQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX", (CX::Int64)sbt_gnMe3IvXYmOsuktFWkbJnPD88k9c7ZHxodcr3m3UCEZsX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW", (CX::Int64)sbt_AkZcaXP2E980zOVoPLHTkadilHsRcOi8djFp7vMeW1KRiqHAh65LdnZ6DfTzW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6", (CX::Int64)sbt_s0PHdUv8R22JPp1xe0u5Rbamw_ZQpxIVUt7XgCgGCCxheJwvK1GC6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3", (CX::Int64)sbt_z4rO8pDgQtPG7_ZmiO85AuUPxnlsv9M_RN3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tPrqQa79gM_0N", (CX::Int64)sbt_tPrqQa79gM_0N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XCDFAwmIeSiDIoCWoVMyl", (CX::Int64)sbt_XCDFAwmIeSiDIoCWoVMyl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J", sbt_DKAygrAVXTsrA6k9AWG3vtSE00HAgNINLkOGP1rx7R94s1J.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4WlGd9_LehN8dLwRaQS>::Type sbt_4WlGd9_LehN8dLwRaQSArray;

