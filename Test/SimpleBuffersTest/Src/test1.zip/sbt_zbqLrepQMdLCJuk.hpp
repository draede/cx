
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_zbqLrepQMdLCJuk : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_HGJSdvY7wmBSEJWg3F8;
	CX::Int64 sbt_0P5pPKEqq9O8sFXF8;
	CX::IO::SimpleBuffers::Int32Array sbt_fO9dOcdPbL8dBtv;
	CX::UInt8 sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e;
	CX::IO::SimpleBuffers::StringArray sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6;
	CX::UInt64 sbt_ZYK_3ue;
	CX::IO::SimpleBuffers::UInt32Array sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU;
	CX::IO::SimpleBuffers::Int8Array sbt_hU0wSdi;
	CX::Int8 sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF;
	CX::UInt16 sbt__OpUovQSpEUhHxdu_;
	CX::Int16 sbt_uyBn1C567;
	CX::UInt32 sbt_u;
	CX::Int16 sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T;
	CX::IO::SimpleBuffers::UInt64Array sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP;
	CX::UInt32 sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru;
	CX::IO::SimpleBuffers::UInt64Array sbt_Svbm2idaCIOovVYLhG1;
	CX::Int32 sbt_zszk1YEKYIi;
	CX::IO::SimpleBuffers::UInt16Array sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL;
	CX::IO::SimpleBuffers::UInt8Array sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3;
	CX::IO::SimpleBuffers::StringArray sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM;
	CX::IO::SimpleBuffers::UInt8Array sbt_eExnhPbr_lX;
	CX::IO::SimpleBuffers::BoolArray sbt_vIatHV0inJWOGIsE0Iz;

	virtual void Reset()
	{
		sbt_HGJSdvY7wmBSEJWg3F8.clear();
		sbt_0P5pPKEqq9O8sFXF8 = 0;
		sbt_fO9dOcdPbL8dBtv.clear();
		sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e = 0;
		sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.clear();
		sbt_ZYK_3ue = 0;
		sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.clear();
		sbt_hU0wSdi.clear();
		sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF = 0;
		sbt__OpUovQSpEUhHxdu_ = 0;
		sbt_uyBn1C567 = 0;
		sbt_u = 0;
		sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T = 0;
		sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.clear();
		sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru = 0;
		sbt_Svbm2idaCIOovVYLhG1.clear();
		sbt_zszk1YEKYIi = 0;
		sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.clear();
		sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.clear();
		sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.clear();
		sbt_eExnhPbr_lX.clear();
		sbt_vIatHV0inJWOGIsE0Iz.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_HGJSdvY7wmBSEJWg3F8.push_back("~N|g*xI\\0[?");
		}
		sbt_0P5pPKEqq9O8sFXF8 = 2834085242463508518;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_fO9dOcdPbL8dBtv.push_back(916722541);
		}
		sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e = 108;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.push_back("|X$<>7\\oA)_)6H#c4+w0TeslIL?~a1d\"2z$x7y;1QoNu}193[u.dg2iN3a8PPwyM");
		}
		sbt_ZYK_3ue = 4887516797871785918;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.push_back(3443834854);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_hU0wSdi.push_back(-18);
		}
		sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF = -41;
		sbt__OpUovQSpEUhHxdu_ = 24816;
		sbt_uyBn1C567 = 18549;
		sbt_u = 160672368;
		sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T = -19468;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.push_back(5396405886635404168);
		}
		sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru = 3969868742;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Svbm2idaCIOovVYLhG1.push_back(132239579000407226);
		}
		sbt_zszk1YEKYIi = 267106816;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.push_back(41329);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.push_back(11);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.push_back("j}0c%auJqQXf^hJ[Ky7=6;69[BmmSm##B(RS\\]H}<Y!7OB{`u1c},A.U");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_eExnhPbr_lX.push_back(65);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_vIatHV0inJWOGIsE0Iz.push_back(false);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_zbqLrepQMdLCJuk *pObject = dynamic_cast<const sbt_zbqLrepQMdLCJuk *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_HGJSdvY7wmBSEJWg3F8.size() != pObject->sbt_HGJSdvY7wmBSEJWg3F8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HGJSdvY7wmBSEJWg3F8.size(); i++)
		{
			if (0 != cx_strcmp(sbt_HGJSdvY7wmBSEJWg3F8[i].c_str(), pObject->sbt_HGJSdvY7wmBSEJWg3F8[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_0P5pPKEqq9O8sFXF8 != pObject->sbt_0P5pPKEqq9O8sFXF8)
		{
			return false;
		}
		if (sbt_fO9dOcdPbL8dBtv.size() != pObject->sbt_fO9dOcdPbL8dBtv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fO9dOcdPbL8dBtv.size(); i++)
		{
			if (sbt_fO9dOcdPbL8dBtv[i] != pObject->sbt_fO9dOcdPbL8dBtv[i])
			{
				return false;
			}
		}
		if (sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e != pObject->sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e)
		{
			return false;
		}
		if (sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.size() != pObject->sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6[i].c_str(), pObject->sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ZYK_3ue != pObject->sbt_ZYK_3ue)
		{
			return false;
		}
		if (sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.size() != pObject->sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.size(); i++)
		{
			if (sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU[i] != pObject->sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU[i])
			{
				return false;
			}
		}
		if (sbt_hU0wSdi.size() != pObject->sbt_hU0wSdi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hU0wSdi.size(); i++)
		{
			if (sbt_hU0wSdi[i] != pObject->sbt_hU0wSdi[i])
			{
				return false;
			}
		}
		if (sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF != pObject->sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF)
		{
			return false;
		}
		if (sbt__OpUovQSpEUhHxdu_ != pObject->sbt__OpUovQSpEUhHxdu_)
		{
			return false;
		}
		if (sbt_uyBn1C567 != pObject->sbt_uyBn1C567)
		{
			return false;
		}
		if (sbt_u != pObject->sbt_u)
		{
			return false;
		}
		if (sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T != pObject->sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T)
		{
			return false;
		}
		if (sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.size() != pObject->sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.size(); i++)
		{
			if (sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP[i] != pObject->sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP[i])
			{
				return false;
			}
		}
		if (sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru != pObject->sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru)
		{
			return false;
		}
		if (sbt_Svbm2idaCIOovVYLhG1.size() != pObject->sbt_Svbm2idaCIOovVYLhG1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Svbm2idaCIOovVYLhG1.size(); i++)
		{
			if (sbt_Svbm2idaCIOovVYLhG1[i] != pObject->sbt_Svbm2idaCIOovVYLhG1[i])
			{
				return false;
			}
		}
		if (sbt_zszk1YEKYIi != pObject->sbt_zszk1YEKYIi)
		{
			return false;
		}
		if (sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.size() != pObject->sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.size(); i++)
		{
			if (sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL[i] != pObject->sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL[i])
			{
				return false;
			}
		}
		if (sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.size() != pObject->sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.size(); i++)
		{
			if (sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3[i] != pObject->sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3[i])
			{
				return false;
			}
		}
		if (sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.size() != pObject->sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.size(); i++)
		{
			if (0 != cx_strcmp(sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM[i].c_str(), pObject->sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_eExnhPbr_lX.size() != pObject->sbt_eExnhPbr_lX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eExnhPbr_lX.size(); i++)
		{
			if (sbt_eExnhPbr_lX[i] != pObject->sbt_eExnhPbr_lX[i])
			{
				return false;
			}
		}
		if (sbt_vIatHV0inJWOGIsE0Iz.size() != pObject->sbt_vIatHV0inJWOGIsE0Iz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vIatHV0inJWOGIsE0Iz.size(); i++)
		{
			if (sbt_vIatHV0inJWOGIsE0Iz[i] != pObject->sbt_vIatHV0inJWOGIsE0Iz[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_HGJSdvY7wmBSEJWg3F8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HGJSdvY7wmBSEJWg3F8.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0P5pPKEqq9O8sFXF8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0P5pPKEqq9O8sFXF8 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fO9dOcdPbL8dBtv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fO9dOcdPbL8dBtv.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZYK_3ue", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZYK_3ue = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hU0wSdi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hU0wSdi.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__OpUovQSpEUhHxdu_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__OpUovQSpEUhHxdu_ = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_uyBn1C567", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uyBn1C567 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Svbm2idaCIOovVYLhG1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Svbm2idaCIOovVYLhG1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zszk1YEKYIi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zszk1YEKYIi = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eExnhPbr_lX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eExnhPbr_lX.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vIatHV0inJWOGIsE0Iz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vIatHV0inJWOGIsE0Iz.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_HGJSdvY7wmBSEJWg3F8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_HGJSdvY7wmBSEJWg3F8.begin(); iter != sbt_HGJSdvY7wmBSEJWg3F8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0P5pPKEqq9O8sFXF8", (CX::Int64)sbt_0P5pPKEqq9O8sFXF8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fO9dOcdPbL8dBtv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_fO9dOcdPbL8dBtv.begin(); iter != sbt_fO9dOcdPbL8dBtv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e", (CX::Int64)sbt_Rr5XKdtn0Sm5BzV7yIsuzo3GsPr5e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.begin(); iter != sbt_fhjX3B1n7RKTUkdj_sG4dSKv00Kh1c6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZYK_3ue", (CX::Int64)sbt_ZYK_3ue)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.begin(); iter != sbt_woRzmKHH4G2Hlr_gtwgyXuypUrY4Jmm_QWiMPT_CwbiO12WuZqFTey3uWpsw8EU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hU0wSdi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_hU0wSdi.begin(); iter != sbt_hU0wSdi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF", (CX::Int64)sbt_XMxqhPTcklWRnX6c_Kc5z7BpFLF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__OpUovQSpEUhHxdu_", (CX::Int64)sbt__OpUovQSpEUhHxdu_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uyBn1C567", (CX::Int64)sbt_uyBn1C567)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u", (CX::Int64)sbt_u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T", (CX::Int64)sbt_C5ji9pACoqUrpypw3CjSgJjsQ8yb6Ot43KdO0NF_ubld_O6JVwoq9O0OJ9T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.begin(); iter != sbt_lwKcLC_NhGB9AOxe2rzsHY0M7M6WAgHNM974mi05GmyCP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru", (CX::Int64)sbt_wJiS6exDTDManiI8KeUS7cELWskSXtIvExXxDru)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Svbm2idaCIOovVYLhG1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Svbm2idaCIOovVYLhG1.begin(); iter != sbt_Svbm2idaCIOovVYLhG1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zszk1YEKYIi", (CX::Int64)sbt_zszk1YEKYIi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.begin(); iter != sbt__ypka2CW_X4g5NaOcsnJCfKyzKt1V7CBuNcUh17xyiL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.begin(); iter != sbt_2bVMAt316g6mOnhTIXu_ZKncTg0fiuDZj5JuBsSU3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.begin(); iter != sbt_wigZrND_LOg_K360cCLSTA7t30MjXd9KqqWqytpw8SuEYyoeKYqp7FR4K8LqM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eExnhPbr_lX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_eExnhPbr_lX.begin(); iter != sbt_eExnhPbr_lX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vIatHV0inJWOGIsE0Iz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_vIatHV0inJWOGIsE0Iz.begin(); iter != sbt_vIatHV0inJWOGIsE0Iz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_zbqLrepQMdLCJuk>::Type sbt_zbqLrepQMdLCJukArray;

