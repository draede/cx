
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY.hpp"


class sbt_gLiumf3 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_ur906;
	CX::IO::SimpleBuffers::Int64Array sbt_xIsJ_GM;
	CX::Int16 sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq;
	CX::IO::SimpleBuffers::UInt32Array sbt_BkxFIrwPdyHIUUVhy9Qr_;
	CX::IO::SimpleBuffers::Int16Array sbt_QXro2w6yElwlmhIpnI8W8sDYg;
	CX::Double sbt_qg_xlMRtXgicQEY;
	CX::Int32 sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa;
	CX::UInt16 sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W;
	sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY sbt_Hnv2tgSUlUEWXNz;

	virtual void Reset()
	{
		sbt_ur906 = 0.0f;
		sbt_xIsJ_GM.clear();
		sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq = 0;
		sbt_BkxFIrwPdyHIUUVhy9Qr_.clear();
		sbt_QXro2w6yElwlmhIpnI8W8sDYg.clear();
		sbt_qg_xlMRtXgicQEY = 0.0;
		sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa = 0;
		sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W = 0;
		sbt_Hnv2tgSUlUEWXNz.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ur906 = 0.573478f;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_xIsJ_GM.push_back(57996445549683230);
		}
		sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq = -7174;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_BkxFIrwPdyHIUUVhy9Qr_.push_back(48075092);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_QXro2w6yElwlmhIpnI8W8sDYg.push_back(-29158);
		}
		sbt_qg_xlMRtXgicQEY = 0.739473;
		sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa = 1203544155;
		sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W = 58713;
		sbt_Hnv2tgSUlUEWXNz.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gLiumf3 *pObject = dynamic_cast<const sbt_gLiumf3 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ur906 != pObject->sbt_ur906)
		{
			return false;
		}
		if (sbt_xIsJ_GM.size() != pObject->sbt_xIsJ_GM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xIsJ_GM.size(); i++)
		{
			if (sbt_xIsJ_GM[i] != pObject->sbt_xIsJ_GM[i])
			{
				return false;
			}
		}
		if (sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq != pObject->sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq)
		{
			return false;
		}
		if (sbt_BkxFIrwPdyHIUUVhy9Qr_.size() != pObject->sbt_BkxFIrwPdyHIUUVhy9Qr_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BkxFIrwPdyHIUUVhy9Qr_.size(); i++)
		{
			if (sbt_BkxFIrwPdyHIUUVhy9Qr_[i] != pObject->sbt_BkxFIrwPdyHIUUVhy9Qr_[i])
			{
				return false;
			}
		}
		if (sbt_QXro2w6yElwlmhIpnI8W8sDYg.size() != pObject->sbt_QXro2w6yElwlmhIpnI8W8sDYg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QXro2w6yElwlmhIpnI8W8sDYg.size(); i++)
		{
			if (sbt_QXro2w6yElwlmhIpnI8W8sDYg[i] != pObject->sbt_QXro2w6yElwlmhIpnI8W8sDYg[i])
			{
				return false;
			}
		}
		if (sbt_qg_xlMRtXgicQEY != pObject->sbt_qg_xlMRtXgicQEY)
		{
			return false;
		}
		if (sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa != pObject->sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa)
		{
			return false;
		}
		if (sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W != pObject->sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W)
		{
			return false;
		}
		if (!sbt_Hnv2tgSUlUEWXNz.Compare(&pObject->sbt_Hnv2tgSUlUEWXNz))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_ur906", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ur906 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_xIsJ_GM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xIsJ_GM.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BkxFIrwPdyHIUUVhy9Qr_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BkxFIrwPdyHIUUVhy9Qr_.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QXro2w6yElwlmhIpnI8W8sDYg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QXro2w6yElwlmhIpnI8W8sDYg.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_qg_xlMRtXgicQEY", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_qg_xlMRtXgicQEY = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_Hnv2tgSUlUEWXNz")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Hnv2tgSUlUEWXNz.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_ur906", (CX::Double)sbt_ur906)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xIsJ_GM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_xIsJ_GM.begin(); iter != sbt_xIsJ_GM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq", (CX::Int64)sbt_G0KQIvi7R7SU3QqKSOKJdsEB_XanDADsKIpapiBY_xFC7g52vw4KoDP7ty9qXhq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BkxFIrwPdyHIUUVhy9Qr_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_BkxFIrwPdyHIUUVhy9Qr_.begin(); iter != sbt_BkxFIrwPdyHIUUVhy9Qr_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QXro2w6yElwlmhIpnI8W8sDYg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_QXro2w6yElwlmhIpnI8W8sDYg.begin(); iter != sbt_QXro2w6yElwlmhIpnI8W8sDYg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_qg_xlMRtXgicQEY", (CX::Double)sbt_qg_xlMRtXgicQEY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa", (CX::Int64)sbt_MKT_kh61389vwwZX0_FaqMxGvovKRGPttMLG5hjYyFon82W7jJHeJun8kajv3Sa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W", (CX::Int64)sbt_KGnF_GsLtWW3OPhEEpHCUmWKxuS2k6W)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_Hnv2tgSUlUEWXNz")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Hnv2tgSUlUEWXNz.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gLiumf3>::Type sbt_gLiumf3Array;

