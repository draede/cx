
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_P;
	CX::IO::SimpleBuffers::UInt32Array sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3;
	CX::IO::SimpleBuffers::UInt64Array sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY;
	CX::Bool sbt_f21aq6NeKfTZG4x1UyuMh;
	CX::IO::SimpleBuffers::Int32Array sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj;
	CX::UInt8 sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv;
	CX::Bool sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt;
	CX::UInt32 sbt_7N9ee;
	CX::IO::SimpleBuffers::StringArray sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k;
	CX::Int16 sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd;
	CX::UInt16 sbt_NGZR8tle9GOkZ;
	CX::Int32 sbt_LHOowYxCz;
	CX::IO::SimpleBuffers::BoolArray sbt_WQs6diaoRUeP2;
	CX::IO::SimpleBuffers::UInt8Array sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z;
	CX::Int8 sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq;
	CX::UInt16 sbt_eRj;
	CX::Int64 sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG;
	CX::UInt32 sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl;
	CX::IO::SimpleBuffers::StringArray sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi;
	CX::IO::SimpleBuffers::UInt16Array sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU;
	CX::UInt32 sbt_NyvTSm33HnJCkJr;
	CX::IO::SimpleBuffers::UInt64Array sbt_qdxhRG1dIz0m8K77oGZ0cuxWy;
	CX::IO::SimpleBuffers::UInt32Array sbt_DXUof9B0k5T;
	CX::IO::SimpleBuffers::UInt32Array sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ;
	CX::IO::SimpleBuffers::StringArray sbt_c5NEOFVLO_knE_ULuPjGgYmGI;
	CX::UInt8 sbt_TdJVF;
	CX::Int32 sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g;
	CX::Int32 sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S;
	CX::String sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM;
	CX::IO::SimpleBuffers::StringArray sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL;

	virtual void Reset()
	{
		sbt_P.clear();
		sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.clear();
		sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.clear();
		sbt_f21aq6NeKfTZG4x1UyuMh = false;
		sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.clear();
		sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv = 0;
		sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt = false;
		sbt_7N9ee = 0;
		sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.clear();
		sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd = 0;
		sbt_NGZR8tle9GOkZ = 0;
		sbt_LHOowYxCz = 0;
		sbt_WQs6diaoRUeP2.clear();
		sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.clear();
		sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq = 0;
		sbt_eRj = 0;
		sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG = 0;
		sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl = 0;
		sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.clear();
		sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.clear();
		sbt_NyvTSm33HnJCkJr = 0;
		sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.clear();
		sbt_DXUof9B0k5T.clear();
		sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.clear();
		sbt_c5NEOFVLO_knE_ULuPjGgYmGI.clear();
		sbt_TdJVF = 0;
		sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g = 0;
		sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S = 0;
		sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM.clear();
		sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_P.push_back("1u>N%|5lyF}&`@");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.push_back(3344234930);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.push_back(5000082610044227630);
		}
		sbt_f21aq6NeKfTZG4x1UyuMh = true;
		sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv = 93;
		sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt = true;
		sbt_7N9ee = 1275065358;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.push_back("Xkf6B4^Vg%?99wWa)6rE[#g/'m49@h7N'*~oOezyXTo>?lAAG5M04\"VrS7e");
		}
		sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd = 28380;
		sbt_NGZR8tle9GOkZ = 62980;
		sbt_LHOowYxCz = -1767874370;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_WQs6diaoRUeP2.push_back(true);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.push_back(16);
		}
		sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq = -44;
		sbt_eRj = 19370;
		sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG = 1620742916519915228;
		sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl = 3760146822;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.push_back("n@UH5t~qRq\"R+(*<vG76{c:Ihe8C9gp1hY)qnD");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.push_back(21359);
		}
		sbt_NyvTSm33HnJCkJr = 596608839;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.push_back(18008240500198180806);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_DXUof9B0k5T.push_back(343954915);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.push_back(476038220);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_c5NEOFVLO_knE_ULuPjGgYmGI.push_back("LoaG`/EI'qn$XZWAEXpdJw1e");
		}
		sbt_TdJVF = 230;
		sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g = -1112631962;
		sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S = -1391880153;
		sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM = "/9m2_'dM4kwAES<:q@/7J&#7KA`9)q$qVizotj,bd1=USP/Rs&uq]BB~Wx8e%}'w";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.push_back("k~\"\"F<xkZvKm?/R%`JmL^]7");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA *pObject = dynamic_cast<const sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_P.size() != pObject->sbt_P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P.size(); i++)
		{
			if (0 != cx_strcmp(sbt_P[i].c_str(), pObject->sbt_P[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.size() != pObject->sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.size(); i++)
		{
			if (sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3[i] != pObject->sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3[i])
			{
				return false;
			}
		}
		if (sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.size() != pObject->sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.size(); i++)
		{
			if (sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY[i] != pObject->sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY[i])
			{
				return false;
			}
		}
		if (sbt_f21aq6NeKfTZG4x1UyuMh != pObject->sbt_f21aq6NeKfTZG4x1UyuMh)
		{
			return false;
		}
		if (sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.size() != pObject->sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.size(); i++)
		{
			if (sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj[i] != pObject->sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj[i])
			{
				return false;
			}
		}
		if (sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv != pObject->sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv)
		{
			return false;
		}
		if (sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt != pObject->sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt)
		{
			return false;
		}
		if (sbt_7N9ee != pObject->sbt_7N9ee)
		{
			return false;
		}
		if (sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.size() != pObject->sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.size(); i++)
		{
			if (0 != cx_strcmp(sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k[i].c_str(), pObject->sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd != pObject->sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd)
		{
			return false;
		}
		if (sbt_NGZR8tle9GOkZ != pObject->sbt_NGZR8tle9GOkZ)
		{
			return false;
		}
		if (sbt_LHOowYxCz != pObject->sbt_LHOowYxCz)
		{
			return false;
		}
		if (sbt_WQs6diaoRUeP2.size() != pObject->sbt_WQs6diaoRUeP2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WQs6diaoRUeP2.size(); i++)
		{
			if (sbt_WQs6diaoRUeP2[i] != pObject->sbt_WQs6diaoRUeP2[i])
			{
				return false;
			}
		}
		if (sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.size() != pObject->sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.size(); i++)
		{
			if (sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z[i] != pObject->sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z[i])
			{
				return false;
			}
		}
		if (sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq != pObject->sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq)
		{
			return false;
		}
		if (sbt_eRj != pObject->sbt_eRj)
		{
			return false;
		}
		if (sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG != pObject->sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG)
		{
			return false;
		}
		if (sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl != pObject->sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl)
		{
			return false;
		}
		if (sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.size() != pObject->sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.size(); i++)
		{
			if (0 != cx_strcmp(sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi[i].c_str(), pObject->sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.size() != pObject->sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.size(); i++)
		{
			if (sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU[i] != pObject->sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU[i])
			{
				return false;
			}
		}
		if (sbt_NyvTSm33HnJCkJr != pObject->sbt_NyvTSm33HnJCkJr)
		{
			return false;
		}
		if (sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.size() != pObject->sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.size(); i++)
		{
			if (sbt_qdxhRG1dIz0m8K77oGZ0cuxWy[i] != pObject->sbt_qdxhRG1dIz0m8K77oGZ0cuxWy[i])
			{
				return false;
			}
		}
		if (sbt_DXUof9B0k5T.size() != pObject->sbt_DXUof9B0k5T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DXUof9B0k5T.size(); i++)
		{
			if (sbt_DXUof9B0k5T[i] != pObject->sbt_DXUof9B0k5T[i])
			{
				return false;
			}
		}
		if (sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.size() != pObject->sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.size(); i++)
		{
			if (sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ[i] != pObject->sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ[i])
			{
				return false;
			}
		}
		if (sbt_c5NEOFVLO_knE_ULuPjGgYmGI.size() != pObject->sbt_c5NEOFVLO_knE_ULuPjGgYmGI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c5NEOFVLO_knE_ULuPjGgYmGI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_c5NEOFVLO_knE_ULuPjGgYmGI[i].c_str(), pObject->sbt_c5NEOFVLO_knE_ULuPjGgYmGI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_TdJVF != pObject->sbt_TdJVF)
		{
			return false;
		}
		if (sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g != pObject->sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g)
		{
			return false;
		}
		if (sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S != pObject->sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM.c_str(), pObject->sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM.c_str()))
		{
			return false;
		}
		if (sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.size() != pObject->sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL[i].c_str(), pObject->sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_f21aq6NeKfTZG4x1UyuMh", &sbt_f21aq6NeKfTZG4x1UyuMh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt", &sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7N9ee", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7N9ee = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NGZR8tle9GOkZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NGZR8tle9GOkZ = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LHOowYxCz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LHOowYxCz = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WQs6diaoRUeP2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WQs6diaoRUeP2.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eRj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eRj = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NyvTSm33HnJCkJr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NyvTSm33HnJCkJr = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qdxhRG1dIz0m8K77oGZ0cuxWy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DXUof9B0k5T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DXUof9B0k5T.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_c5NEOFVLO_knE_ULuPjGgYmGI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c5NEOFVLO_knE_ULuPjGgYmGI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TdJVF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TdJVF = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM", &sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_P.begin(); iter != sbt_P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.begin(); iter != sbt_GT9qN8iyoes80gys1D4Qd_jUYyN_2STBjH8Tt7RSwD3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.begin(); iter != sbt_sZ9avBE2ZAUz6cVx250HcrxqoyUpa1yyGl9hLkducUBTTZuct0jlY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_f21aq6NeKfTZG4x1UyuMh", sbt_f21aq6NeKfTZG4x1UyuMh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.begin(); iter != sbt_pgJnOppoVWj2grc9Oi8GYc0q6nB8jXj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv", (CX::Int64)sbt_8NkH1k9HfWaAHp5gAs3FLk1P7PZ9fMMjvihsv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt", sbt_c84xMUVFXV3XwLkDgobNi7tKf8ardKD5zkWrKjMUc0Rxh4xRHX6vGBt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7N9ee", (CX::Int64)sbt_7N9ee)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.begin(); iter != sbt_EPMpI3pg_Dhr1nGQl7tu2K2ojGbblQi7k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd", (CX::Int64)sbt_hpcq7pirxfWH5OQz2QmdlI0GghPK7rd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NGZR8tle9GOkZ", (CX::Int64)sbt_NGZR8tle9GOkZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LHOowYxCz", (CX::Int64)sbt_LHOowYxCz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WQs6diaoRUeP2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_WQs6diaoRUeP2.begin(); iter != sbt_WQs6diaoRUeP2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.begin(); iter != sbt_i3AeqKgf3exE0e0gM_Fd4S83NBVsnwwCazMXOdoYdcSM4HEPwnrdj2h_nex4z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq", (CX::Int64)sbt_HWooDLxHQkJW38wQ6ISpneLDxAP189v7nMsr63UisetHoKq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eRj", (CX::Int64)sbt_eRj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG", (CX::Int64)sbt__3DSkk6cJsGMj1NNlA2KQVtzs0v28SMs3rxeqo5pJLG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl", (CX::Int64)sbt_mNzw1yKsPWNmwnW0HbK8hnfqs7g2lX5GoMRcqYlNF5ZEiU2z3tpt4Vl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.begin(); iter != sbt_BFgkOPxNXiWnYYfEIErFJln1dt4jEA3mrBp3dEaYlBhuXoi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.begin(); iter != sbt_VCn6Fm4xSjXKT5lBFrjWGkLhRwtJwFklN62AGxZwPbJr8Rujm9TQuxvfCOZytMU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NyvTSm33HnJCkJr", (CX::Int64)sbt_NyvTSm33HnJCkJr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qdxhRG1dIz0m8K77oGZ0cuxWy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.begin(); iter != sbt_qdxhRG1dIz0m8K77oGZ0cuxWy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DXUof9B0k5T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_DXUof9B0k5T.begin(); iter != sbt_DXUof9B0k5T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.begin(); iter != sbt_AZmxvdgdtLGlxGafx3ZE9W7DXzJMK_MUJZRuguc13R8XmwfZ2mMYnl0hJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c5NEOFVLO_knE_ULuPjGgYmGI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_c5NEOFVLO_knE_ULuPjGgYmGI.begin(); iter != sbt_c5NEOFVLO_knE_ULuPjGgYmGI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TdJVF", (CX::Int64)sbt_TdJVF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g", (CX::Int64)sbt_7gL00YfxrK3TOxRvT1v3b5MxuNZshPC1SG_jbW2pVl4dEjzWkuJ3k4U2gtLNp6g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S", (CX::Int64)sbt_En9Odn8jU2Rtu6oc0JQ8uG6iT4hYwKiGp0TbNjT_XYw0qe87Pjam2tBco9S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM", sbt_6dKBRXr4kbU1YAkRQttnBF3S1WqGOKvcodjPM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.begin(); iter != sbt_fxS7Zrm3NtAd5584bxPHAxxmbjL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA>::Type sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HAArray;

