
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_RYGgzZvIgXK8f;
	CX::UInt32 sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk;
	CX::IO::SimpleBuffers::Int32Array sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy;
	CX::IO::SimpleBuffers::UInt16Array sbt_vVtqy9ohbcrp5;
	CX::String sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5;
	CX::IO::SimpleBuffers::UInt16Array sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z;
	CX::IO::SimpleBuffers::UInt16Array sbt_Ym0BBxI3WSydCFo;
	CX::IO::SimpleBuffers::UInt16Array sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE;
	CX::Int64 sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B;
	CX::IO::SimpleBuffers::UInt32Array sbt_zBvuZdvhvN4En;
	CX::Int8 sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr;
	CX::UInt8 sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov;
	CX::IO::SimpleBuffers::UInt16Array sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C;
	CX::UInt64 sbt_VHazbe62ntf_KiMbw4P;
	CX::Bool sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7;
	CX::IO::SimpleBuffers::UInt32Array sbt_xQqKgoIqwWn3C;
	CX::UInt64 sbt_kURGNahadBEZcW_C1jeVTnY;
	CX::UInt32 sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim;
	CX::UInt64 sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3;
	CX::IO::SimpleBuffers::UInt16Array sbt_PQOoUSb4fl4C__MN4gV;
	CX::Int8 sbt_5y7lBURloCrM1JCbO;

	virtual void Reset()
	{
		sbt_RYGgzZvIgXK8f.clear();
		sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk = 0;
		sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.clear();
		sbt_vVtqy9ohbcrp5.clear();
		sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5.clear();
		sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.clear();
		sbt_Ym0BBxI3WSydCFo.clear();
		sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.clear();
		sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B = 0;
		sbt_zBvuZdvhvN4En.clear();
		sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr = 0;
		sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov = 0;
		sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.clear();
		sbt_VHazbe62ntf_KiMbw4P = 0;
		sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7 = false;
		sbt_xQqKgoIqwWn3C.clear();
		sbt_kURGNahadBEZcW_C1jeVTnY = 0;
		sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim = 0;
		sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3 = 0;
		sbt_PQOoUSb4fl4C__MN4gV.clear();
		sbt_5y7lBURloCrM1JCbO = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_RYGgzZvIgXK8f.push_back(false);
		}
		sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk = 2032387709;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.push_back(1737041592);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_vVtqy9ohbcrp5.push_back(42618);
		}
		sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5 = "i(d1`\"P|/";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.push_back(15797);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Ym0BBxI3WSydCFo.push_back(19906);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.push_back(11627);
		}
		sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B = -1393771234064011818;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_zBvuZdvhvN4En.push_back(779462941);
		}
		sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr = -49;
		sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov = 38;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.push_back(35235);
		}
		sbt_VHazbe62ntf_KiMbw4P = 12179931161567666372;
		sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7 = false;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_xQqKgoIqwWn3C.push_back(1979352278);
		}
		sbt_kURGNahadBEZcW_C1jeVTnY = 17510192031673973206;
		sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim = 1833971908;
		sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3 = 3635722983687297224;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_PQOoUSb4fl4C__MN4gV.push_back(59966);
		}
		sbt_5y7lBURloCrM1JCbO = -110;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ *pObject = dynamic_cast<const sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_RYGgzZvIgXK8f.size() != pObject->sbt_RYGgzZvIgXK8f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RYGgzZvIgXK8f.size(); i++)
		{
			if (sbt_RYGgzZvIgXK8f[i] != pObject->sbt_RYGgzZvIgXK8f[i])
			{
				return false;
			}
		}
		if (sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk != pObject->sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk)
		{
			return false;
		}
		if (sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.size() != pObject->sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.size(); i++)
		{
			if (sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy[i] != pObject->sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy[i])
			{
				return false;
			}
		}
		if (sbt_vVtqy9ohbcrp5.size() != pObject->sbt_vVtqy9ohbcrp5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vVtqy9ohbcrp5.size(); i++)
		{
			if (sbt_vVtqy9ohbcrp5[i] != pObject->sbt_vVtqy9ohbcrp5[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5.c_str(), pObject->sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5.c_str()))
		{
			return false;
		}
		if (sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.size() != pObject->sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.size(); i++)
		{
			if (sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z[i] != pObject->sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z[i])
			{
				return false;
			}
		}
		if (sbt_Ym0BBxI3WSydCFo.size() != pObject->sbt_Ym0BBxI3WSydCFo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ym0BBxI3WSydCFo.size(); i++)
		{
			if (sbt_Ym0BBxI3WSydCFo[i] != pObject->sbt_Ym0BBxI3WSydCFo[i])
			{
				return false;
			}
		}
		if (sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.size() != pObject->sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.size(); i++)
		{
			if (sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE[i] != pObject->sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE[i])
			{
				return false;
			}
		}
		if (sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B != pObject->sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B)
		{
			return false;
		}
		if (sbt_zBvuZdvhvN4En.size() != pObject->sbt_zBvuZdvhvN4En.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zBvuZdvhvN4En.size(); i++)
		{
			if (sbt_zBvuZdvhvN4En[i] != pObject->sbt_zBvuZdvhvN4En[i])
			{
				return false;
			}
		}
		if (sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr != pObject->sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr)
		{
			return false;
		}
		if (sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov != pObject->sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov)
		{
			return false;
		}
		if (sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.size() != pObject->sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.size(); i++)
		{
			if (sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C[i] != pObject->sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C[i])
			{
				return false;
			}
		}
		if (sbt_VHazbe62ntf_KiMbw4P != pObject->sbt_VHazbe62ntf_KiMbw4P)
		{
			return false;
		}
		if (sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7 != pObject->sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7)
		{
			return false;
		}
		if (sbt_xQqKgoIqwWn3C.size() != pObject->sbt_xQqKgoIqwWn3C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xQqKgoIqwWn3C.size(); i++)
		{
			if (sbt_xQqKgoIqwWn3C[i] != pObject->sbt_xQqKgoIqwWn3C[i])
			{
				return false;
			}
		}
		if (sbt_kURGNahadBEZcW_C1jeVTnY != pObject->sbt_kURGNahadBEZcW_C1jeVTnY)
		{
			return false;
		}
		if (sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim != pObject->sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim)
		{
			return false;
		}
		if (sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3 != pObject->sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3)
		{
			return false;
		}
		if (sbt_PQOoUSb4fl4C__MN4gV.size() != pObject->sbt_PQOoUSb4fl4C__MN4gV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PQOoUSb4fl4C__MN4gV.size(); i++)
		{
			if (sbt_PQOoUSb4fl4C__MN4gV[i] != pObject->sbt_PQOoUSb4fl4C__MN4gV[i])
			{
				return false;
			}
		}
		if (sbt_5y7lBURloCrM1JCbO != pObject->sbt_5y7lBURloCrM1JCbO)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_RYGgzZvIgXK8f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RYGgzZvIgXK8f.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vVtqy9ohbcrp5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vVtqy9ohbcrp5.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5", &sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ym0BBxI3WSydCFo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ym0BBxI3WSydCFo.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zBvuZdvhvN4En")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zBvuZdvhvN4En.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VHazbe62ntf_KiMbw4P", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VHazbe62ntf_KiMbw4P = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7", &sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xQqKgoIqwWn3C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xQqKgoIqwWn3C.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kURGNahadBEZcW_C1jeVTnY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kURGNahadBEZcW_C1jeVTnY = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PQOoUSb4fl4C__MN4gV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PQOoUSb4fl4C__MN4gV.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5y7lBURloCrM1JCbO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5y7lBURloCrM1JCbO = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_RYGgzZvIgXK8f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_RYGgzZvIgXK8f.begin(); iter != sbt_RYGgzZvIgXK8f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk", (CX::Int64)sbt_ciMcqqlmmsYgi9ESCTMErmH5TVg_Bnu2oJjVOnmEwNHB0s9A06376n8o3ueUk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.begin(); iter != sbt_uw4X7B0VlCPxKy3N9wwnia_juM9NxNK4GUv6Kb3qWLgYVo1Jljy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vVtqy9ohbcrp5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_vVtqy9ohbcrp5.begin(); iter != sbt_vVtqy9ohbcrp5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5", sbt_f1jgvNiXcgvFZxSOx5ZtHbBspXjX5IqqINAAMfuWFnIi5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.begin(); iter != sbt_E7vtQojNHnKWKGBKZhbM2SVBBWfmz5ljlEJpb7eXJEI6ZW5_TfW8Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ym0BBxI3WSydCFo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Ym0BBxI3WSydCFo.begin(); iter != sbt_Ym0BBxI3WSydCFo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.begin(); iter != sbt_9xW7eZ_eLblZAk_WkNpJBlcp8BcZd9sVDlE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B", (CX::Int64)sbt_KTGE5paybSP2K5P1tVeDwfO3DfkJ4ZK6B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zBvuZdvhvN4En")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_zBvuZdvhvN4En.begin(); iter != sbt_zBvuZdvhvN4En.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr", (CX::Int64)sbt_YU3NSIY1oPwEuqUdbLMg3fhgbRKUKqAQANCMfxTftI9smJxjsqVZ0Nr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov", (CX::Int64)sbt_WKOG1FHLAhGut1Ki42zzzyCLOJfZYI6wC33DMV8zM49Nlov)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.begin(); iter != sbt_1CD4kfqCV1dpQuGYkvhzq4UzzLYknTT3qSQwC8sfDsfta0Oyv04fKkYYmBA2C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VHazbe62ntf_KiMbw4P", (CX::Int64)sbt_VHazbe62ntf_KiMbw4P)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7", sbt_ql2fm_yJm5_rKN6iKkwYY8WzGhGraZEnWSOsVF41GhWg7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xQqKgoIqwWn3C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_xQqKgoIqwWn3C.begin(); iter != sbt_xQqKgoIqwWn3C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kURGNahadBEZcW_C1jeVTnY", (CX::Int64)sbt_kURGNahadBEZcW_C1jeVTnY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim", (CX::Int64)sbt_UNYAG_paH2iQCKMTxp41rYJPOGKpu9Jim)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3", (CX::Int64)sbt_fwdaeESc3tUvLDYFIvfVLOjLCX1twxG3NM6httWKYSQ9OIyhPj8ufJ_T3e3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PQOoUSb4fl4C__MN4gV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_PQOoUSb4fl4C__MN4gV.begin(); iter != sbt_PQOoUSb4fl4C__MN4gV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5y7lBURloCrM1JCbO", (CX::Int64)sbt_5y7lBURloCrM1JCbO)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ>::Type sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZArray;

