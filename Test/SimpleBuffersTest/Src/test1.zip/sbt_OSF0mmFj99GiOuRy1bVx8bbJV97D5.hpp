
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd;
	CX::Int32 sbt_FtNNP8aXuQYF2vI7eJp;
	CX::IO::SimpleBuffers::Int64Array sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0;
	CX::IO::SimpleBuffers::UInt64Array sbt_dXXz7L44ZUZVVmKYU;
	CX::UInt32 sbt_DbMdsfGWtwm3Ut2;
	CX::UInt32 sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X;
	CX::Int32 sbt_20FYjKj4L;
	CX::UInt8 sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h;
	CX::IO::SimpleBuffers::UInt8Array sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7;
	CX::IO::SimpleBuffers::Int8Array sbt_xWm;
	CX::IO::SimpleBuffers::UInt64Array sbt_7EMfS;
	CX::IO::SimpleBuffers::UInt64Array sbt_RFUHun9bjnpl4YN_G6d;
	CX::UInt64 sbt_kVAM2BdkkmoR1z3c_1t;
	CX::IO::SimpleBuffers::Int32Array sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI;
	CX::UInt32 sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO;
	CX::IO::SimpleBuffers::Int8Array sbt_EUU2hrISqV_VOAevqvs;
	CX::UInt64 sbt_MeI8NMU;

	virtual void Reset()
	{
		sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd.clear();
		sbt_FtNNP8aXuQYF2vI7eJp = 0;
		sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.clear();
		sbt_dXXz7L44ZUZVVmKYU.clear();
		sbt_DbMdsfGWtwm3Ut2 = 0;
		sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X = 0;
		sbt_20FYjKj4L = 0;
		sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h = 0;
		sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.clear();
		sbt_xWm.clear();
		sbt_7EMfS.clear();
		sbt_RFUHun9bjnpl4YN_G6d.clear();
		sbt_kVAM2BdkkmoR1z3c_1t = 0;
		sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.clear();
		sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO = 0;
		sbt_EUU2hrISqV_VOAevqvs.clear();
		sbt_MeI8NMU = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd = "XrfGSJE";
		sbt_FtNNP8aXuQYF2vI7eJp = -1830841625;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.push_back(1712792703876890926);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_dXXz7L44ZUZVVmKYU.push_back(14396933338382013714);
		}
		sbt_DbMdsfGWtwm3Ut2 = 2599420475;
		sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X = 2535197986;
		sbt_20FYjKj4L = 155702908;
		sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h = 86;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.push_back(196);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_xWm.push_back(104);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_7EMfS.push_back(11246811471942285774);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_RFUHun9bjnpl4YN_G6d.push_back(116357558232321022);
		}
		sbt_kVAM2BdkkmoR1z3c_1t = 213689293203998418;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.push_back(263272998);
		}
		sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO = 428420860;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_EUU2hrISqV_VOAevqvs.push_back(117);
		}
		sbt_MeI8NMU = 3957678556137997862;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5 *pObject = dynamic_cast<const sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd.c_str(), pObject->sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd.c_str()))
		{
			return false;
		}
		if (sbt_FtNNP8aXuQYF2vI7eJp != pObject->sbt_FtNNP8aXuQYF2vI7eJp)
		{
			return false;
		}
		if (sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.size() != pObject->sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.size(); i++)
		{
			if (sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0[i] != pObject->sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0[i])
			{
				return false;
			}
		}
		if (sbt_dXXz7L44ZUZVVmKYU.size() != pObject->sbt_dXXz7L44ZUZVVmKYU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dXXz7L44ZUZVVmKYU.size(); i++)
		{
			if (sbt_dXXz7L44ZUZVVmKYU[i] != pObject->sbt_dXXz7L44ZUZVVmKYU[i])
			{
				return false;
			}
		}
		if (sbt_DbMdsfGWtwm3Ut2 != pObject->sbt_DbMdsfGWtwm3Ut2)
		{
			return false;
		}
		if (sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X != pObject->sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X)
		{
			return false;
		}
		if (sbt_20FYjKj4L != pObject->sbt_20FYjKj4L)
		{
			return false;
		}
		if (sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h != pObject->sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h)
		{
			return false;
		}
		if (sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.size() != pObject->sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.size(); i++)
		{
			if (sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7[i] != pObject->sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7[i])
			{
				return false;
			}
		}
		if (sbt_xWm.size() != pObject->sbt_xWm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xWm.size(); i++)
		{
			if (sbt_xWm[i] != pObject->sbt_xWm[i])
			{
				return false;
			}
		}
		if (sbt_7EMfS.size() != pObject->sbt_7EMfS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7EMfS.size(); i++)
		{
			if (sbt_7EMfS[i] != pObject->sbt_7EMfS[i])
			{
				return false;
			}
		}
		if (sbt_RFUHun9bjnpl4YN_G6d.size() != pObject->sbt_RFUHun9bjnpl4YN_G6d.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RFUHun9bjnpl4YN_G6d.size(); i++)
		{
			if (sbt_RFUHun9bjnpl4YN_G6d[i] != pObject->sbt_RFUHun9bjnpl4YN_G6d[i])
			{
				return false;
			}
		}
		if (sbt_kVAM2BdkkmoR1z3c_1t != pObject->sbt_kVAM2BdkkmoR1z3c_1t)
		{
			return false;
		}
		if (sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.size() != pObject->sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.size(); i++)
		{
			if (sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI[i] != pObject->sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI[i])
			{
				return false;
			}
		}
		if (sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO != pObject->sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO)
		{
			return false;
		}
		if (sbt_EUU2hrISqV_VOAevqvs.size() != pObject->sbt_EUU2hrISqV_VOAevqvs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EUU2hrISqV_VOAevqvs.size(); i++)
		{
			if (sbt_EUU2hrISqV_VOAevqvs[i] != pObject->sbt_EUU2hrISqV_VOAevqvs[i])
			{
				return false;
			}
		}
		if (sbt_MeI8NMU != pObject->sbt_MeI8NMU)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd", &sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FtNNP8aXuQYF2vI7eJp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FtNNP8aXuQYF2vI7eJp = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dXXz7L44ZUZVVmKYU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dXXz7L44ZUZVVmKYU.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DbMdsfGWtwm3Ut2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DbMdsfGWtwm3Ut2 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_20FYjKj4L", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_20FYjKj4L = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xWm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xWm.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7EMfS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7EMfS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RFUHun9bjnpl4YN_G6d")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RFUHun9bjnpl4YN_G6d.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kVAM2BdkkmoR1z3c_1t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kVAM2BdkkmoR1z3c_1t = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EUU2hrISqV_VOAevqvs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EUU2hrISqV_VOAevqvs.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MeI8NMU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MeI8NMU = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd", sbt_BKxqchGkAH5YRP3NCR_lm5Zx_38jd.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FtNNP8aXuQYF2vI7eJp", (CX::Int64)sbt_FtNNP8aXuQYF2vI7eJp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.begin(); iter != sbt_i9HuK7YPS8y0L_FF85iaAxey2JkjJx3Y0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dXXz7L44ZUZVVmKYU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_dXXz7L44ZUZVVmKYU.begin(); iter != sbt_dXXz7L44ZUZVVmKYU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DbMdsfGWtwm3Ut2", (CX::Int64)sbt_DbMdsfGWtwm3Ut2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X", (CX::Int64)sbt_5Txid0qPy7Kgk4fCvB0E1EygYInaLllJr4OOlLmNb6abSLJsxRvaB_S_X)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_20FYjKj4L", (CX::Int64)sbt_20FYjKj4L)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h", (CX::Int64)sbt_mCCrDAMwVzn9_wqxZMdM1xsKmIk_BYljwmhp0ZKTsM8sd6h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.begin(); iter != sbt_2tEe7tSrs8miqxvioMGkj0GJp4U5xR1yz2T_ErbxbOG47sq3J5e7mVcG7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xWm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_xWm.begin(); iter != sbt_xWm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7EMfS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_7EMfS.begin(); iter != sbt_7EMfS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RFUHun9bjnpl4YN_G6d")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_RFUHun9bjnpl4YN_G6d.begin(); iter != sbt_RFUHun9bjnpl4YN_G6d.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kVAM2BdkkmoR1z3c_1t", (CX::Int64)sbt_kVAM2BdkkmoR1z3c_1t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.begin(); iter != sbt_xlxiVxQZCUpgtkW1XUQPNtJXrSl3RSIi0GbotEDCmQWXBTI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO", (CX::Int64)sbt_Lxbm_qhZgwqymuz0bS62HW5XGUsEweeIBk9pwnO5JCt7WVzKxxakVQf0TkwgDtO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EUU2hrISqV_VOAevqvs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_EUU2hrISqV_VOAevqvs.begin(); iter != sbt_EUU2hrISqV_VOAevqvs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MeI8NMU", (CX::Int64)sbt_MeI8NMU)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5>::Type sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5Array;

