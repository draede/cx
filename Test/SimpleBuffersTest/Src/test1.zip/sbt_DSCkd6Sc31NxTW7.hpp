
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_DSCkd6Sc31NxTW7 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih;
	CX::IO::SimpleBuffers::StringArray sbt_NiDdxAEJBgDEq;
	CX::Int16 sbt_zN_;
	CX::Bool sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP;
	CX::IO::SimpleBuffers::Int32Array sbt_ciwvZsmFUhkSJ;
	CX::IO::SimpleBuffers::UInt8Array sbt_6cmb_C6mP5x;
	CX::IO::SimpleBuffers::UInt64Array sbt_FrDm3qptCI_;
	CX::String sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy;
	CX::IO::SimpleBuffers::UInt32Array sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd;
	CX::IO::SimpleBuffers::UInt32Array sbt__7dq7dIiQIBqsAU;

	virtual void Reset()
	{
		sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih = 0;
		sbt_NiDdxAEJBgDEq.clear();
		sbt_zN_ = 0;
		sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP = false;
		sbt_ciwvZsmFUhkSJ.clear();
		sbt_6cmb_C6mP5x.clear();
		sbt_FrDm3qptCI_.clear();
		sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy.clear();
		sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.clear();
		sbt__7dq7dIiQIBqsAU.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih = 32658;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_NiDdxAEJBgDEq.push_back("=nC^VV-Q}$#--aNWZH#l[.H!1[FgLL,R;k\"`g[");
		}
		sbt_zN_ = 28017;
		sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP = false;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_ciwvZsmFUhkSJ.push_back(-1788546610);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_6cmb_C6mP5x.push_back(220);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_FrDm3qptCI_.push_back(13397863887504174128);
		}
		sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy = "c6IxU968@)KGMl!,r";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.push_back(3821317624);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt__7dq7dIiQIBqsAU.push_back(2863273789);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_DSCkd6Sc31NxTW7 *pObject = dynamic_cast<const sbt_DSCkd6Sc31NxTW7 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih != pObject->sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih)
		{
			return false;
		}
		if (sbt_NiDdxAEJBgDEq.size() != pObject->sbt_NiDdxAEJBgDEq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NiDdxAEJBgDEq.size(); i++)
		{
			if (0 != cx_strcmp(sbt_NiDdxAEJBgDEq[i].c_str(), pObject->sbt_NiDdxAEJBgDEq[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_zN_ != pObject->sbt_zN_)
		{
			return false;
		}
		if (sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP != pObject->sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP)
		{
			return false;
		}
		if (sbt_ciwvZsmFUhkSJ.size() != pObject->sbt_ciwvZsmFUhkSJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ciwvZsmFUhkSJ.size(); i++)
		{
			if (sbt_ciwvZsmFUhkSJ[i] != pObject->sbt_ciwvZsmFUhkSJ[i])
			{
				return false;
			}
		}
		if (sbt_6cmb_C6mP5x.size() != pObject->sbt_6cmb_C6mP5x.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6cmb_C6mP5x.size(); i++)
		{
			if (sbt_6cmb_C6mP5x[i] != pObject->sbt_6cmb_C6mP5x[i])
			{
				return false;
			}
		}
		if (sbt_FrDm3qptCI_.size() != pObject->sbt_FrDm3qptCI_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FrDm3qptCI_.size(); i++)
		{
			if (sbt_FrDm3qptCI_[i] != pObject->sbt_FrDm3qptCI_[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy.c_str(), pObject->sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy.c_str()))
		{
			return false;
		}
		if (sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.size() != pObject->sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.size(); i++)
		{
			if (sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd[i] != pObject->sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd[i])
			{
				return false;
			}
		}
		if (sbt__7dq7dIiQIBqsAU.size() != pObject->sbt__7dq7dIiQIBqsAU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__7dq7dIiQIBqsAU.size(); i++)
		{
			if (sbt__7dq7dIiQIBqsAU[i] != pObject->sbt__7dq7dIiQIBqsAU[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NiDdxAEJBgDEq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NiDdxAEJBgDEq.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zN_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zN_ = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP", &sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ciwvZsmFUhkSJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ciwvZsmFUhkSJ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6cmb_C6mP5x")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6cmb_C6mP5x.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FrDm3qptCI_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FrDm3qptCI_.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy", &sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__7dq7dIiQIBqsAU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__7dq7dIiQIBqsAU.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih", (CX::Int64)sbt_d5urvIF0ocwOWwH2vrmE2PS3SomeJUkbRv6YOluTtih)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NiDdxAEJBgDEq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_NiDdxAEJBgDEq.begin(); iter != sbt_NiDdxAEJBgDEq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zN_", (CX::Int64)sbt_zN_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP", sbt_N0I8lIBwbapXvQePrZ8t_P34YYi5J4YIiqE6TG0fP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ciwvZsmFUhkSJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ciwvZsmFUhkSJ.begin(); iter != sbt_ciwvZsmFUhkSJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6cmb_C6mP5x")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_6cmb_C6mP5x.begin(); iter != sbt_6cmb_C6mP5x.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FrDm3qptCI_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_FrDm3qptCI_.begin(); iter != sbt_FrDm3qptCI_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy", sbt_6E0r63uubiu0SD2XH6LRKmz0XVdJCzdNtKLVOzlVIBC3hmy.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.begin(); iter != sbt_8jzjrfTC2GwgMJ06K5s_qRI72vxJbITSFlRi3gUNUCLIwacegCd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__7dq7dIiQIBqsAU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt__7dq7dIiQIBqsAU.begin(); iter != sbt__7dq7dIiQIBqsAU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_DSCkd6Sc31NxTW7>::Type sbt_DSCkd6Sc31NxTW7Array;

