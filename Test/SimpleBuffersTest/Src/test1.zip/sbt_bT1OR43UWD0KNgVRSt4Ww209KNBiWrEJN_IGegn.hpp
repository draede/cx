
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR;
	CX::IO::SimpleBuffers::StringArray sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1;
	CX::IO::SimpleBuffers::Int64Array sbt_W;
	CX::UInt32 sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob;
	CX::Int64 sbt_AnW;
	CX::IO::SimpleBuffers::Int32Array sbt_j;
	CX::IO::SimpleBuffers::UInt64Array sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT;
	CX::UInt32 sbt_F9k8agCvuVruj4Z9UU3xbswiToH;
	CX::UInt64 sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD;
	CX::IO::SimpleBuffers::Int64Array sbt_dhsGFJCY2;

	virtual void Reset()
	{
		sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.clear();
		sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.clear();
		sbt_W.clear();
		sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob = 0;
		sbt_AnW = 0;
		sbt_j.clear();
		sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.clear();
		sbt_F9k8agCvuVruj4Z9UU3xbswiToH = 0;
		sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD = 0;
		sbt_dhsGFJCY2.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.push_back("~8Z(wN_t\\x,JzS%~d4PZ$ok");
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_W.push_back(3367133309770328932);
		}
		sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob = 517547704;
		sbt_AnW = -1961766781285533098;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_j.push_back(1220748610);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.push_back(11331621546478739202);
		}
		sbt_F9k8agCvuVruj4Z9UU3xbswiToH = 1212034758;
		sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD = 3776856418384995262;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_dhsGFJCY2.push_back(-8991355595647061646);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn *pObject = dynamic_cast<const sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.size() != pObject->sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.size(); i++)
		{
			if (sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR[i] != pObject->sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR[i])
			{
				return false;
			}
		}
		if (sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.size() != pObject->sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.size(); i++)
		{
			if (0 != cx_strcmp(sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1[i].c_str(), pObject->sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_W.size() != pObject->sbt_W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W.size(); i++)
		{
			if (sbt_W[i] != pObject->sbt_W[i])
			{
				return false;
			}
		}
		if (sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob != pObject->sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob)
		{
			return false;
		}
		if (sbt_AnW != pObject->sbt_AnW)
		{
			return false;
		}
		if (sbt_j.size() != pObject->sbt_j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j.size(); i++)
		{
			if (sbt_j[i] != pObject->sbt_j[i])
			{
				return false;
			}
		}
		if (sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.size() != pObject->sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.size(); i++)
		{
			if (sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT[i] != pObject->sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT[i])
			{
				return false;
			}
		}
		if (sbt_F9k8agCvuVruj4Z9UU3xbswiToH != pObject->sbt_F9k8agCvuVruj4Z9UU3xbswiToH)
		{
			return false;
		}
		if (sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD != pObject->sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD)
		{
			return false;
		}
		if (sbt_dhsGFJCY2.size() != pObject->sbt_dhsGFJCY2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dhsGFJCY2.size(); i++)
		{
			if (sbt_dhsGFJCY2[i] != pObject->sbt_dhsGFJCY2[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AnW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AnW = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_F9k8agCvuVruj4Z9UU3xbswiToH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F9k8agCvuVruj4Z9UU3xbswiToH = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dhsGFJCY2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dhsGFJCY2.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.begin(); iter != sbt_pIwLwsaQ7C6zLLYO7Qu6FoI0VMLE5uWtaoR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.begin(); iter != sbt_oVq0p96cWyvwRb8V9_N5TWEb8pLkyZ2cVm8W0YnhtB87VFBzNf7aja7CDjDs1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_W.begin(); iter != sbt_W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob", (CX::Int64)sbt_uM2kJJI5MFlRTXUrJ49F9a4QqV2jwDjqqKmmvBcLLob)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AnW", (CX::Int64)sbt_AnW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_j.begin(); iter != sbt_j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.begin(); iter != sbt_3ISAxs81MdbF22yRw7I8bPD_w0QLHjAvnu58R_uLoNLrAU0PFzkTgOUPWwT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F9k8agCvuVruj4Z9UU3xbswiToH", (CX::Int64)sbt_F9k8agCvuVruj4Z9UU3xbswiToH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD", (CX::Int64)sbt_rTfT3wQQVJKqFGgP10VimyhpZFxk0JPlELOijwiSD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dhsGFJCY2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_dhsGFJCY2.begin(); iter != sbt_dhsGFJCY2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn>::Type sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegnArray;

