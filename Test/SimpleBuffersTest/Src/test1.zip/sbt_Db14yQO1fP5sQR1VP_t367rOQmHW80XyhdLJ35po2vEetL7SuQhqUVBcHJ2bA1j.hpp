
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_oGQc9MTwA.hpp"


class sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_VNCc6fa9njCqqgDzn;
	CX::Int32 sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul;
	CX::UInt64 sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt;
	CX::UInt16 sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD;
	CX::IO::SimpleBuffers::WStringArray sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn;
	sbt_oGQc9MTwA sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY;

	virtual void Reset()
	{
		sbt_VNCc6fa9njCqqgDzn.clear();
		sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul = 0;
		sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt = 0;
		sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD = 0;
		sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.clear();
		sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_VNCc6fa9njCqqgDzn.push_back(0.461802f);
		}
		sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul = 2078605551;
		sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt = 4620894077467872852;
		sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD = 26211;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.push_back(L"yf{.'NL,R7;w(KMsEm&G@=;kFD]?qb>sp7ZURvZciP.;u)p`nxuD");
		}
		sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j *pObject = dynamic_cast<const sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VNCc6fa9njCqqgDzn.size() != pObject->sbt_VNCc6fa9njCqqgDzn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VNCc6fa9njCqqgDzn.size(); i++)
		{
			if (sbt_VNCc6fa9njCqqgDzn[i] != pObject->sbt_VNCc6fa9njCqqgDzn[i])
			{
				return false;
			}
		}
		if (sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul != pObject->sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul)
		{
			return false;
		}
		if (sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt != pObject->sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt)
		{
			return false;
		}
		if (sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD != pObject->sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD)
		{
			return false;
		}
		if (sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.size() != pObject->sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn[i].c_str(), pObject->sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn[i].c_str()))
			{
				return false;
			}
		}
		if (!sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY.Compare(&pObject->sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_VNCc6fa9njCqqgDzn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VNCc6fa9njCqqgDzn.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_VNCc6fa9njCqqgDzn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_VNCc6fa9njCqqgDzn.begin(); iter != sbt_VNCc6fa9njCqqgDzn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul", (CX::Int64)sbt_MSMgD8A_UaS0Abp6YbPPcN7t8SO_zYVKUvx3Bm5EGTYul)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt", (CX::Int64)sbt_23HSKG6THqEeAeisE58NiqAf9UoMn5pzdIneG7Gxt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD", (CX::Int64)sbt_u82r11asLxmriaV5r2HoePcgxVWCtXgZD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.begin(); iter != sbt_sADEWwjjO1c3kQbKUDQu3RaY5eXxGDGCE2Ywz8c9Puty1KkN1Zjnj5dS4a_Vn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_Sjnw0xQZtbfzD5QVMHzRYVx2ySodg3UidQbrShQAY.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j>::Type sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1jArray;

