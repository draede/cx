
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_V3O8t0hNgtWZkxOPB;
	CX::IO::SimpleBuffers::Int8Array sbt_inB3zEumjIF7O;
	CX::Bool sbt_t;
	CX::IO::SimpleBuffers::UInt64Array sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV;
	CX::IO::SimpleBuffers::Int8Array sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm;
	CX::IO::SimpleBuffers::UInt8Array sbt_PseIoHv_TXtn3;
	CX::Int32 sbt_9ObjAzbMF5MGB;
	CX::IO::SimpleBuffers::UInt8Array sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8;
	CX::Int64 sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB;
	CX::UInt8 sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_;
	CX::IO::SimpleBuffers::UInt8Array sbt_MYf;
	CX::String sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr;
	CX::UInt16 sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4;
	CX::IO::SimpleBuffers::Int8Array sbt_dOk0JLdnzly;
	CX::UInt32 sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7;
	CX::IO::SimpleBuffers::BoolArray sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o;
	CX::Int64 sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk;
	CX::IO::SimpleBuffers::UInt32Array sbt_4YSnZsxYKBtYR;
	CX::IO::SimpleBuffers::BoolArray sbt_B0WIKfF5tGyLzCxq2opmQvc;
	CX::UInt32 sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ;
	CX::UInt8 sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK;
	CX::Int32 sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz;
	CX::IO::SimpleBuffers::UInt8Array sbt_MXGomTwwYtbxnX6tX5o;
	CX::Int16 sbt_EhXezgmDs1Nhowxn6G0Ic;
	CX::IO::SimpleBuffers::UInt32Array sbt_R2kDxvgRYCv3ZqJ;
	CX::Int64 sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ;
	CX::UInt32 sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O;
	CX::Int32 sbt_4aBpJojntR60IIYxLVD;
	CX::UInt8 sbt_8gflZJb;

	virtual void Reset()
	{
		sbt_V3O8t0hNgtWZkxOPB.clear();
		sbt_inB3zEumjIF7O.clear();
		sbt_t = false;
		sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.clear();
		sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.clear();
		sbt_PseIoHv_TXtn3.clear();
		sbt_9ObjAzbMF5MGB = 0;
		sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.clear();
		sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB = 0;
		sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_ = 0;
		sbt_MYf.clear();
		sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr.clear();
		sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4 = 0;
		sbt_dOk0JLdnzly.clear();
		sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7 = 0;
		sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.clear();
		sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk = 0;
		sbt_4YSnZsxYKBtYR.clear();
		sbt_B0WIKfF5tGyLzCxq2opmQvc.clear();
		sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ = 0;
		sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK = 0;
		sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz = 0;
		sbt_MXGomTwwYtbxnX6tX5o.clear();
		sbt_EhXezgmDs1Nhowxn6G0Ic = 0;
		sbt_R2kDxvgRYCv3ZqJ.clear();
		sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ = 0;
		sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O = 0;
		sbt_4aBpJojntR60IIYxLVD = 0;
		sbt_8gflZJb = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_V3O8t0hNgtWZkxOPB.push_back(118);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_inB3zEumjIF7O.push_back(84);
		}
		sbt_t = true;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.push_back(80);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_PseIoHv_TXtn3.push_back(225);
		}
		sbt_9ObjAzbMF5MGB = 1178194760;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.push_back(62);
		}
		sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB = -2000420092504702890;
		sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_ = 75;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_MYf.push_back(97);
		}
		sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr = ",ZQ7=cF|$\"UQS6*-4N3VD]%v";
		sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4 = 51201;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_dOk0JLdnzly.push_back(-23);
		}
		sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7 = 3538779944;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.push_back(true);
		}
		sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk = -3234948330597731566;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_4YSnZsxYKBtYR.push_back(3324271886);
		}
		sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ = 2593140251;
		sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK = 38;
		sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz = -1310905312;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_MXGomTwwYtbxnX6tX5o.push_back(10);
		}
		sbt_EhXezgmDs1Nhowxn6G0Ic = 31417;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_R2kDxvgRYCv3ZqJ.push_back(4142066611);
		}
		sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ = -6517046623932757852;
		sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O = 1789975895;
		sbt_4aBpJojntR60IIYxLVD = 2122803070;
		sbt_8gflZJb = 230;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf *pObject = dynamic_cast<const sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_V3O8t0hNgtWZkxOPB.size() != pObject->sbt_V3O8t0hNgtWZkxOPB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_V3O8t0hNgtWZkxOPB.size(); i++)
		{
			if (sbt_V3O8t0hNgtWZkxOPB[i] != pObject->sbt_V3O8t0hNgtWZkxOPB[i])
			{
				return false;
			}
		}
		if (sbt_inB3zEumjIF7O.size() != pObject->sbt_inB3zEumjIF7O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_inB3zEumjIF7O.size(); i++)
		{
			if (sbt_inB3zEumjIF7O[i] != pObject->sbt_inB3zEumjIF7O[i])
			{
				return false;
			}
		}
		if (sbt_t != pObject->sbt_t)
		{
			return false;
		}
		if (sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.size() != pObject->sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.size(); i++)
		{
			if (sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV[i] != pObject->sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV[i])
			{
				return false;
			}
		}
		if (sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.size() != pObject->sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.size(); i++)
		{
			if (sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm[i] != pObject->sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm[i])
			{
				return false;
			}
		}
		if (sbt_PseIoHv_TXtn3.size() != pObject->sbt_PseIoHv_TXtn3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PseIoHv_TXtn3.size(); i++)
		{
			if (sbt_PseIoHv_TXtn3[i] != pObject->sbt_PseIoHv_TXtn3[i])
			{
				return false;
			}
		}
		if (sbt_9ObjAzbMF5MGB != pObject->sbt_9ObjAzbMF5MGB)
		{
			return false;
		}
		if (sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.size() != pObject->sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.size(); i++)
		{
			if (sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8[i] != pObject->sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8[i])
			{
				return false;
			}
		}
		if (sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB != pObject->sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB)
		{
			return false;
		}
		if (sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_ != pObject->sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_)
		{
			return false;
		}
		if (sbt_MYf.size() != pObject->sbt_MYf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MYf.size(); i++)
		{
			if (sbt_MYf[i] != pObject->sbt_MYf[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr.c_str(), pObject->sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr.c_str()))
		{
			return false;
		}
		if (sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4 != pObject->sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4)
		{
			return false;
		}
		if (sbt_dOk0JLdnzly.size() != pObject->sbt_dOk0JLdnzly.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dOk0JLdnzly.size(); i++)
		{
			if (sbt_dOk0JLdnzly[i] != pObject->sbt_dOk0JLdnzly[i])
			{
				return false;
			}
		}
		if (sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7 != pObject->sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7)
		{
			return false;
		}
		if (sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.size() != pObject->sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.size(); i++)
		{
			if (sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o[i] != pObject->sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o[i])
			{
				return false;
			}
		}
		if (sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk != pObject->sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk)
		{
			return false;
		}
		if (sbt_4YSnZsxYKBtYR.size() != pObject->sbt_4YSnZsxYKBtYR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4YSnZsxYKBtYR.size(); i++)
		{
			if (sbt_4YSnZsxYKBtYR[i] != pObject->sbt_4YSnZsxYKBtYR[i])
			{
				return false;
			}
		}
		if (sbt_B0WIKfF5tGyLzCxq2opmQvc.size() != pObject->sbt_B0WIKfF5tGyLzCxq2opmQvc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B0WIKfF5tGyLzCxq2opmQvc.size(); i++)
		{
			if (sbt_B0WIKfF5tGyLzCxq2opmQvc[i] != pObject->sbt_B0WIKfF5tGyLzCxq2opmQvc[i])
			{
				return false;
			}
		}
		if (sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ != pObject->sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ)
		{
			return false;
		}
		if (sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK != pObject->sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK)
		{
			return false;
		}
		if (sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz != pObject->sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz)
		{
			return false;
		}
		if (sbt_MXGomTwwYtbxnX6tX5o.size() != pObject->sbt_MXGomTwwYtbxnX6tX5o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MXGomTwwYtbxnX6tX5o.size(); i++)
		{
			if (sbt_MXGomTwwYtbxnX6tX5o[i] != pObject->sbt_MXGomTwwYtbxnX6tX5o[i])
			{
				return false;
			}
		}
		if (sbt_EhXezgmDs1Nhowxn6G0Ic != pObject->sbt_EhXezgmDs1Nhowxn6G0Ic)
		{
			return false;
		}
		if (sbt_R2kDxvgRYCv3ZqJ.size() != pObject->sbt_R2kDxvgRYCv3ZqJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R2kDxvgRYCv3ZqJ.size(); i++)
		{
			if (sbt_R2kDxvgRYCv3ZqJ[i] != pObject->sbt_R2kDxvgRYCv3ZqJ[i])
			{
				return false;
			}
		}
		if (sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ != pObject->sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ)
		{
			return false;
		}
		if (sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O != pObject->sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O)
		{
			return false;
		}
		if (sbt_4aBpJojntR60IIYxLVD != pObject->sbt_4aBpJojntR60IIYxLVD)
		{
			return false;
		}
		if (sbt_8gflZJb != pObject->sbt_8gflZJb)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_V3O8t0hNgtWZkxOPB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_V3O8t0hNgtWZkxOPB.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_inB3zEumjIF7O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_inB3zEumjIF7O.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_t", &sbt_t)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PseIoHv_TXtn3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PseIoHv_TXtn3.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9ObjAzbMF5MGB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9ObjAzbMF5MGB = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_ = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MYf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MYf.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr", &sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dOk0JLdnzly")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dOk0JLdnzly.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4YSnZsxYKBtYR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4YSnZsxYKBtYR.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_B0WIKfF5tGyLzCxq2opmQvc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B0WIKfF5tGyLzCxq2opmQvc.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MXGomTwwYtbxnX6tX5o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MXGomTwwYtbxnX6tX5o.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EhXezgmDs1Nhowxn6G0Ic", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EhXezgmDs1Nhowxn6G0Ic = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_R2kDxvgRYCv3ZqJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R2kDxvgRYCv3ZqJ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_4aBpJojntR60IIYxLVD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4aBpJojntR60IIYxLVD = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8gflZJb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8gflZJb = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_V3O8t0hNgtWZkxOPB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_V3O8t0hNgtWZkxOPB.begin(); iter != sbt_V3O8t0hNgtWZkxOPB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_inB3zEumjIF7O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_inB3zEumjIF7O.begin(); iter != sbt_inB3zEumjIF7O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_t", sbt_t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.begin(); iter != sbt_7rq4JVCdIdSbx37FawdeYA9VD2wSisrUllBYpkQCpReFgpHCG1rDr3jMTDkKV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.begin(); iter != sbt_YVJCdi5_g0aPYW_UCYqqcWNZ8gp9VWjAvfVpmf6stYm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PseIoHv_TXtn3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_PseIoHv_TXtn3.begin(); iter != sbt_PseIoHv_TXtn3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9ObjAzbMF5MGB", (CX::Int64)sbt_9ObjAzbMF5MGB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.begin(); iter != sbt_lAH6inz32DanBcUhQ29RGPe3rpYAqfFyuLfwnJUvpHLtJHYCXe9ccllh8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB", (CX::Int64)sbt_b0Q_a9A9bj73EsFHD3TjtCqk5FNhvgxLqoZ7mjU48hJRPQtEB7HfNGqFB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_", (CX::Int64)sbt_hrqjfYYwyCAgXjrKXuR_GxErzMlRHmDd3uwbLIrnMevj1Vn1hkFr_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MYf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_MYf.begin(); iter != sbt_MYf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr", sbt_32E1E9TK0ZlPxdPaRZab9iD0m3pOfyYcVF0fMhuE_RTfdcr.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4", (CX::Int64)sbt_HWvdZmNjXALFLe4EaKe6cQWOU1YM1gqwDbUQrS8iBM5Oj6pbZbMXQk4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dOk0JLdnzly")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_dOk0JLdnzly.begin(); iter != sbt_dOk0JLdnzly.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7", (CX::Int64)sbt_MVvDsce1yCQs3EEWAq3vWmSdRbdHC72T7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.begin(); iter != sbt_moDQN2dLFul2Mc1r6cjatffowWP_GBP0o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk", (CX::Int64)sbt_mpHLtsWiXLBpn4GqLpp5qC4Xwd1GGrTtNHHXQYfbSHYm1yqNljv0_BIEk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4YSnZsxYKBtYR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_4YSnZsxYKBtYR.begin(); iter != sbt_4YSnZsxYKBtYR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B0WIKfF5tGyLzCxq2opmQvc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_B0WIKfF5tGyLzCxq2opmQvc.begin(); iter != sbt_B0WIKfF5tGyLzCxq2opmQvc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ", (CX::Int64)sbt_JTgmjKJllNYRjeWKT8YoiKzq574VyBPHW53BelJQ7RJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK", (CX::Int64)sbt_ZnggclOGgCTkC3ramg07k84SdiYKI5mpI3b3uBNLpaDvYmnQOiojK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz", (CX::Int64)sbt_dhnNLNYYZSiwGn7wucoYVzhqhR2gHqPmhpdUEH9lz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MXGomTwwYtbxnX6tX5o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_MXGomTwwYtbxnX6tX5o.begin(); iter != sbt_MXGomTwwYtbxnX6tX5o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EhXezgmDs1Nhowxn6G0Ic", (CX::Int64)sbt_EhXezgmDs1Nhowxn6G0Ic)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R2kDxvgRYCv3ZqJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_R2kDxvgRYCv3ZqJ.begin(); iter != sbt_R2kDxvgRYCv3ZqJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ", (CX::Int64)sbt_RBfZ7UotEG0Pf6GH7kaEP4H5DKS2kmwpin6QH_dFzwnySbIUiVQkQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O", (CX::Int64)sbt_eNExIIjE5MRTFgvCrr0h86r97dZNaIi97SjZjjdPeUPCF3SE7fyGnaiVWoP_O)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4aBpJojntR60IIYxLVD", (CX::Int64)sbt_4aBpJojntR60IIYxLVD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8gflZJb", (CX::Int64)sbt_8gflZJb)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf>::Type sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rfArray;

