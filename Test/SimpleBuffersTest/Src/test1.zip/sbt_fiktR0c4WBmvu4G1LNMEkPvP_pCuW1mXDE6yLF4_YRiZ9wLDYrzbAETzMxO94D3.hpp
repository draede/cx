
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_iG1uN9iRRbskrL2rWfjX6Z5;
	CX::IO::SimpleBuffers::Int16Array sbt_POIWpTXPT6CNC;
	CX::UInt8 sbt_seREOxWh5;
	CX::Int64 sbt_1fLQcar5esh35QUAWfo3ftONBqV;
	CX::UInt32 sbt_M;
	CX::IO::SimpleBuffers::UInt16Array sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM;
	CX::IO::SimpleBuffers::UInt64Array sbt_QBFsCHpsyMnoOpj_LhxgV31;
	CX::UInt32 sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ;
	CX::UInt8 sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB;
	CX::IO::SimpleBuffers::Int32Array sbt_SWWvLtHDZw7;
	CX::UInt64 sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH;
	CX::UInt64 sbt_WLwgSuAb2q55CRC;
	CX::IO::SimpleBuffers::UInt64Array sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb;
	CX::Int16 sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc;
	CX::IO::SimpleBuffers::UInt16Array sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2;
	CX::UInt32 sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw;
	CX::IO::SimpleBuffers::UInt64Array sbt_C;
	CX::UInt64 sbt_TRoJ3FvTrUYGXdY;
	CX::IO::SimpleBuffers::UInt64Array sbt__ANyETJjcTScfJbUkYgniWXG2nY6E;

	virtual void Reset()
	{
		sbt_iG1uN9iRRbskrL2rWfjX6Z5 = 0;
		sbt_POIWpTXPT6CNC.clear();
		sbt_seREOxWh5 = 0;
		sbt_1fLQcar5esh35QUAWfo3ftONBqV = 0;
		sbt_M = 0;
		sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.clear();
		sbt_QBFsCHpsyMnoOpj_LhxgV31.clear();
		sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ = 0;
		sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB = 0;
		sbt_SWWvLtHDZw7.clear();
		sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH = 0;
		sbt_WLwgSuAb2q55CRC = 0;
		sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.clear();
		sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc = 0;
		sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.clear();
		sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw = 0;
		sbt_C.clear();
		sbt_TRoJ3FvTrUYGXdY = 0;
		sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_iG1uN9iRRbskrL2rWfjX6Z5 = 14025302113986152382;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_POIWpTXPT6CNC.push_back(31880);
		}
		sbt_seREOxWh5 = 150;
		sbt_1fLQcar5esh35QUAWfo3ftONBqV = -8760563475471550096;
		sbt_M = 36575147;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.push_back(25140);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_QBFsCHpsyMnoOpj_LhxgV31.push_back(10255199829206978164);
		}
		sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ = 2580688924;
		sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB = 26;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_SWWvLtHDZw7.push_back(868339951);
		}
		sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH = 6961091132255387826;
		sbt_WLwgSuAb2q55CRC = 5773599773886770838;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.push_back(16214563206336230344);
		}
		sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc = 32060;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.push_back(4887);
		}
		sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw = 2800634238;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_C.push_back(17355473084293670334);
		}
		sbt_TRoJ3FvTrUYGXdY = 7957439412051646058;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.push_back(13410788009586811266);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3 *pObject = dynamic_cast<const sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_iG1uN9iRRbskrL2rWfjX6Z5 != pObject->sbt_iG1uN9iRRbskrL2rWfjX6Z5)
		{
			return false;
		}
		if (sbt_POIWpTXPT6CNC.size() != pObject->sbt_POIWpTXPT6CNC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_POIWpTXPT6CNC.size(); i++)
		{
			if (sbt_POIWpTXPT6CNC[i] != pObject->sbt_POIWpTXPT6CNC[i])
			{
				return false;
			}
		}
		if (sbt_seREOxWh5 != pObject->sbt_seREOxWh5)
		{
			return false;
		}
		if (sbt_1fLQcar5esh35QUAWfo3ftONBqV != pObject->sbt_1fLQcar5esh35QUAWfo3ftONBqV)
		{
			return false;
		}
		if (sbt_M != pObject->sbt_M)
		{
			return false;
		}
		if (sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.size() != pObject->sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.size(); i++)
		{
			if (sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM[i] != pObject->sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM[i])
			{
				return false;
			}
		}
		if (sbt_QBFsCHpsyMnoOpj_LhxgV31.size() != pObject->sbt_QBFsCHpsyMnoOpj_LhxgV31.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QBFsCHpsyMnoOpj_LhxgV31.size(); i++)
		{
			if (sbt_QBFsCHpsyMnoOpj_LhxgV31[i] != pObject->sbt_QBFsCHpsyMnoOpj_LhxgV31[i])
			{
				return false;
			}
		}
		if (sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ != pObject->sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ)
		{
			return false;
		}
		if (sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB != pObject->sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB)
		{
			return false;
		}
		if (sbt_SWWvLtHDZw7.size() != pObject->sbt_SWWvLtHDZw7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SWWvLtHDZw7.size(); i++)
		{
			if (sbt_SWWvLtHDZw7[i] != pObject->sbt_SWWvLtHDZw7[i])
			{
				return false;
			}
		}
		if (sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH != pObject->sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH)
		{
			return false;
		}
		if (sbt_WLwgSuAb2q55CRC != pObject->sbt_WLwgSuAb2q55CRC)
		{
			return false;
		}
		if (sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.size() != pObject->sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.size(); i++)
		{
			if (sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb[i] != pObject->sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb[i])
			{
				return false;
			}
		}
		if (sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc != pObject->sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc)
		{
			return false;
		}
		if (sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.size() != pObject->sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.size(); i++)
		{
			if (sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2[i] != pObject->sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2[i])
			{
				return false;
			}
		}
		if (sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw != pObject->sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw)
		{
			return false;
		}
		if (sbt_C.size() != pObject->sbt_C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C.size(); i++)
		{
			if (sbt_C[i] != pObject->sbt_C[i])
			{
				return false;
			}
		}
		if (sbt_TRoJ3FvTrUYGXdY != pObject->sbt_TRoJ3FvTrUYGXdY)
		{
			return false;
		}
		if (sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.size() != pObject->sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.size(); i++)
		{
			if (sbt__ANyETJjcTScfJbUkYgniWXG2nY6E[i] != pObject->sbt__ANyETJjcTScfJbUkYgniWXG2nY6E[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_iG1uN9iRRbskrL2rWfjX6Z5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iG1uN9iRRbskrL2rWfjX6Z5 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_POIWpTXPT6CNC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_POIWpTXPT6CNC.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_seREOxWh5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_seREOxWh5 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1fLQcar5esh35QUAWfo3ftONBqV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1fLQcar5esh35QUAWfo3ftONBqV = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_M", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QBFsCHpsyMnoOpj_LhxgV31")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QBFsCHpsyMnoOpj_LhxgV31.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SWWvLtHDZw7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SWWvLtHDZw7.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WLwgSuAb2q55CRC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WLwgSuAb2q55CRC = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TRoJ3FvTrUYGXdY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TRoJ3FvTrUYGXdY = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt__ANyETJjcTScfJbUkYgniWXG2nY6E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_iG1uN9iRRbskrL2rWfjX6Z5", (CX::Int64)sbt_iG1uN9iRRbskrL2rWfjX6Z5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_POIWpTXPT6CNC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_POIWpTXPT6CNC.begin(); iter != sbt_POIWpTXPT6CNC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_seREOxWh5", (CX::Int64)sbt_seREOxWh5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1fLQcar5esh35QUAWfo3ftONBqV", (CX::Int64)sbt_1fLQcar5esh35QUAWfo3ftONBqV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M", (CX::Int64)sbt_M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.begin(); iter != sbt_hC1Xaki90NhR6D5POH_Hc8V3IuM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QBFsCHpsyMnoOpj_LhxgV31")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_QBFsCHpsyMnoOpj_LhxgV31.begin(); iter != sbt_QBFsCHpsyMnoOpj_LhxgV31.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ", (CX::Int64)sbt_qeoBNs_8WKzfHTmC9YTXzcso1vuGKS0T1BZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB", (CX::Int64)sbt_M_tZ4vIQcHnCyPxb4M2hi0HpaAsg25QmIkTDAmN4ieB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SWWvLtHDZw7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_SWWvLtHDZw7.begin(); iter != sbt_SWWvLtHDZw7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH", (CX::Int64)sbt_NwF1MYUak8QtsHqSi0OxpYAVObPMH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WLwgSuAb2q55CRC", (CX::Int64)sbt_WLwgSuAb2q55CRC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.begin(); iter != sbt_Xe3dIsmKLkMoPeVLIItEHXLKBjXI5lKQAfb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc", (CX::Int64)sbt_wYySNy5SimcpM_qv6eTyVeTuLmLebD_s3LGgD1uzprc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.begin(); iter != sbt_JgEqWSSsho5RUzK8aikBkPlbOvlK0F73oozmJkf55pHIqMlx2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw", (CX::Int64)sbt_3xPly9eh7ezqwjrxcnyxAA66pLp4nJyWw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_C.begin(); iter != sbt_C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TRoJ3FvTrUYGXdY", (CX::Int64)sbt_TRoJ3FvTrUYGXdY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__ANyETJjcTScfJbUkYgniWXG2nY6E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.begin(); iter != sbt__ANyETJjcTScfJbUkYgniWXG2nY6E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3>::Type sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3Array;

