
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R;
	CX::IO::SimpleBuffers::UInt32Array sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ;
	CX::UInt8 sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm;
	CX::IO::SimpleBuffers::Int64Array sbt_XM11TNc80Z2Il;
	CX::UInt16 sbt_xTq;
	CX::UInt8 sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo;
	CX::IO::SimpleBuffers::UInt64Array sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk;
	CX::Int16 sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa;
	CX::UInt16 sbt_kwK;
	CX::IO::SimpleBuffers::UInt32Array sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD;
	CX::IO::SimpleBuffers::Int16Array sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors;
	CX::Int64 sbt_5bU2u;
	CX::Int16 sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev;
	CX::UInt32 sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV;
	CX::IO::SimpleBuffers::StringArray sbt_o;
	CX::IO::SimpleBuffers::Int64Array sbt_PBp4Nue;
	CX::IO::SimpleBuffers::Int64Array sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q;
	CX::IO::SimpleBuffers::UInt64Array sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm;
	CX::IO::SimpleBuffers::UInt64Array sbt_vgGUdVjoF;
	CX::IO::SimpleBuffers::UInt8Array sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c;
	CX::IO::SimpleBuffers::UInt8Array sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf;
	CX::UInt16 sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF;
	CX::IO::SimpleBuffers::Int32Array sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja;
	CX::IO::SimpleBuffers::UInt32Array sbt_ViXeiv2IlalYf;
	CX::IO::SimpleBuffers::BoolArray sbt_HVUWIpmxFbJ;
	CX::Int32 sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g;
	CX::IO::SimpleBuffers::UInt8Array sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM;
	CX::Int8 sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE;

	virtual void Reset()
	{
		sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.clear();
		sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.clear();
		sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm = 0;
		sbt_XM11TNc80Z2Il.clear();
		sbt_xTq = 0;
		sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo = 0;
		sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.clear();
		sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa = 0;
		sbt_kwK = 0;
		sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.clear();
		sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.clear();
		sbt_5bU2u = 0;
		sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev = 0;
		sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV = 0;
		sbt_o.clear();
		sbt_PBp4Nue.clear();
		sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.clear();
		sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.clear();
		sbt_vgGUdVjoF.clear();
		sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.clear();
		sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.clear();
		sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF = 0;
		sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.clear();
		sbt_ViXeiv2IlalYf.clear();
		sbt_HVUWIpmxFbJ.clear();
		sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g = 0;
		sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.clear();
		sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.push_back("WF`~_<[/_G!PW@/D.aYd%JJowb05ltRdH\"g\\\"74B`K.g=^fH~pk\\v)Q92C?J");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.push_back(793548891);
		}
		sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm = 20;
		sbt_xTq = 34586;
		sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo = 6;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.push_back(1808310149115473228);
		}
		sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa = 6934;
		sbt_kwK = 52434;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.push_back(4036403678);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.push_back(-31690);
		}
		sbt_5bU2u = -5805668912246681546;
		sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev = -28831;
		sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV = 827080208;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_o.push_back("e'!@|2x?m=F5.j~S&QW^Zr&VS");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_PBp4Nue.push_back(-1774896795393868200);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.push_back(-3794632293385302516);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.push_back(16746310457511664870);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_vgGUdVjoF.push_back(5416754855002866458);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.push_back(162);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.push_back(98);
		}
		sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF = 36723;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.push_back(262218159);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ViXeiv2IlalYf.push_back(1846519773);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_HVUWIpmxFbJ.push_back(false);
		}
		sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g = 1152540473;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.push_back(120);
		}
		sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE = -92;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d *pObject = dynamic_cast<const sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.size() != pObject->sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.size(); i++)
		{
			if (0 != cx_strcmp(sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R[i].c_str(), pObject->sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.size() != pObject->sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.size(); i++)
		{
			if (sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ[i] != pObject->sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ[i])
			{
				return false;
			}
		}
		if (sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm != pObject->sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm)
		{
			return false;
		}
		if (sbt_XM11TNc80Z2Il.size() != pObject->sbt_XM11TNc80Z2Il.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XM11TNc80Z2Il.size(); i++)
		{
			if (sbt_XM11TNc80Z2Il[i] != pObject->sbt_XM11TNc80Z2Il[i])
			{
				return false;
			}
		}
		if (sbt_xTq != pObject->sbt_xTq)
		{
			return false;
		}
		if (sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo != pObject->sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo)
		{
			return false;
		}
		if (sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.size() != pObject->sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.size(); i++)
		{
			if (sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk[i] != pObject->sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk[i])
			{
				return false;
			}
		}
		if (sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa != pObject->sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa)
		{
			return false;
		}
		if (sbt_kwK != pObject->sbt_kwK)
		{
			return false;
		}
		if (sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.size() != pObject->sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.size(); i++)
		{
			if (sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD[i] != pObject->sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD[i])
			{
				return false;
			}
		}
		if (sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.size() != pObject->sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.size(); i++)
		{
			if (sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors[i] != pObject->sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors[i])
			{
				return false;
			}
		}
		if (sbt_5bU2u != pObject->sbt_5bU2u)
		{
			return false;
		}
		if (sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev != pObject->sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev)
		{
			return false;
		}
		if (sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV != pObject->sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV)
		{
			return false;
		}
		if (sbt_o.size() != pObject->sbt_o.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o.size(); i++)
		{
			if (0 != cx_strcmp(sbt_o[i].c_str(), pObject->sbt_o[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_PBp4Nue.size() != pObject->sbt_PBp4Nue.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PBp4Nue.size(); i++)
		{
			if (sbt_PBp4Nue[i] != pObject->sbt_PBp4Nue[i])
			{
				return false;
			}
		}
		if (sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.size() != pObject->sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.size(); i++)
		{
			if (sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q[i] != pObject->sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q[i])
			{
				return false;
			}
		}
		if (sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.size() != pObject->sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.size(); i++)
		{
			if (sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm[i] != pObject->sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm[i])
			{
				return false;
			}
		}
		if (sbt_vgGUdVjoF.size() != pObject->sbt_vgGUdVjoF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vgGUdVjoF.size(); i++)
		{
			if (sbt_vgGUdVjoF[i] != pObject->sbt_vgGUdVjoF[i])
			{
				return false;
			}
		}
		if (sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.size() != pObject->sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.size(); i++)
		{
			if (sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c[i] != pObject->sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c[i])
			{
				return false;
			}
		}
		if (sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.size() != pObject->sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.size(); i++)
		{
			if (sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf[i] != pObject->sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf[i])
			{
				return false;
			}
		}
		if (sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF != pObject->sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF)
		{
			return false;
		}
		if (sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.size() != pObject->sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.size(); i++)
		{
			if (sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja[i] != pObject->sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja[i])
			{
				return false;
			}
		}
		if (sbt_ViXeiv2IlalYf.size() != pObject->sbt_ViXeiv2IlalYf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ViXeiv2IlalYf.size(); i++)
		{
			if (sbt_ViXeiv2IlalYf[i] != pObject->sbt_ViXeiv2IlalYf[i])
			{
				return false;
			}
		}
		if (sbt_HVUWIpmxFbJ.size() != pObject->sbt_HVUWIpmxFbJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HVUWIpmxFbJ.size(); i++)
		{
			if (sbt_HVUWIpmxFbJ[i] != pObject->sbt_HVUWIpmxFbJ[i])
			{
				return false;
			}
		}
		if (sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g != pObject->sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g)
		{
			return false;
		}
		if (sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.size() != pObject->sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.size(); i++)
		{
			if (sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM[i] != pObject->sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM[i])
			{
				return false;
			}
		}
		if (sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE != pObject->sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XM11TNc80Z2Il")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XM11TNc80Z2Il.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xTq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xTq = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kwK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kwK = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5bU2u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5bU2u = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_o")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PBp4Nue")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PBp4Nue.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vgGUdVjoF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vgGUdVjoF.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ViXeiv2IlalYf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ViXeiv2IlalYf.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HVUWIpmxFbJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HVUWIpmxFbJ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.begin(); iter != sbt_1yyeD9ZHI7JWgf5O1j9TJsJVkvaoqtnbr0NhhcxPvEdib2R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.begin(); iter != sbt_1PaqzF7orLOkt6UpbyYJBvZA7GrUZ6lgJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm", (CX::Int64)sbt_xqZ91k1w252OgND6gKX9IVoGmaRkFonzCiptm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XM11TNc80Z2Il")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_XM11TNc80Z2Il.begin(); iter != sbt_XM11TNc80Z2Il.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xTq", (CX::Int64)sbt_xTq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo", (CX::Int64)sbt_8_SywKhpmxDWbLGCdxucIxvzsrg5droJo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.begin(); iter != sbt_sfsPJ66JrUVe7lc2gQOAmyuyIH_dtNIoK0lDqvZEuUlCpvo_jgoKWVsPGGk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa", (CX::Int64)sbt_YZyvEBY5B9CzLiKmue9ODYdkjeZlXcYjnbaYFsa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kwK", (CX::Int64)sbt_kwK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.begin(); iter != sbt_AbLPrrdWVDPegf3w_AS4GqMQuOfeiXlpcXW12WRQpjzyAkvvxjTz7chZD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.begin(); iter != sbt_fxKw7jRpp6NNc6D8UqxPpgGO9dlP2V_PVjHCNI0wbynQ05goziPtozpyyrors.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5bU2u", (CX::Int64)sbt_5bU2u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev", (CX::Int64)sbt_79uKUvAhLfFVMRZA5OmsI6RfBhpXenxORBMidvTYf3dvRIZKMVW6MP7JN_Vev)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV", (CX::Int64)sbt_EgDMwj8tgAv9Ao9_C_lQWp1BXZ8Uc2vGYJcSbFvgcv8CE_kJo8R8xBebrYV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_o.begin(); iter != sbt_o.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PBp4Nue")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_PBp4Nue.begin(); iter != sbt_PBp4Nue.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.begin(); iter != sbt_A5yBfWIcd0Py4sdvn3dl9DanjsxxuzII48Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.begin(); iter != sbt_vWyHBP3NvsMCMieEw3SeprTAnnoeYLYCMXkP4c8jm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vgGUdVjoF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vgGUdVjoF.begin(); iter != sbt_vgGUdVjoF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.begin(); iter != sbt_jnYIHU31UX7nSbKl39vetJ3jiv2AUs3Xpr8TdhvCgSKPFAI1W6y085xMzq70c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.begin(); iter != sbt_oIMOWcrZstpPnI1ROrhmwdJ28XzxQk37cw21ylAZtraINm4pjEDjtPv1JXf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF", (CX::Int64)sbt_HGavRIwKcnWFN4GnMjULj0dRKkFNA3UA8RmoRnPVF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.begin(); iter != sbt_waeILbSD2MZQjEKklAt5LsrtsAbZKxBPL0Nyg6jGpuCR5HjxBGF6Oja.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ViXeiv2IlalYf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ViXeiv2IlalYf.begin(); iter != sbt_ViXeiv2IlalYf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HVUWIpmxFbJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_HVUWIpmxFbJ.begin(); iter != sbt_HVUWIpmxFbJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g", (CX::Int64)sbt_P3t4L0wSX1PV_j4PqhNrrQXC1_g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.begin(); iter != sbt_4txuuv5HlSKwuKPW39BFwhBhXeYHM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE", (CX::Int64)sbt_uJZmuit5QAud60nrLgSNhw0HaVswHGQVJCPVomzsjezZC9wWLuKMl4IZE)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d>::Type sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0dArray;

