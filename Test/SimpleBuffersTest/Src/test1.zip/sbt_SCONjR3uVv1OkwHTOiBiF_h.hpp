
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_SCONjR3uVv1OkwHTOiBiF_h : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo;
	CX::UInt64 sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz;
	CX::Int8 sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn;
	CX::IO::SimpleBuffers::Int8Array sbt_KpnE1OjZCa6WH2YNjU8;
	CX::Int32 sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1;
	CX::Bool sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5;
	CX::IO::SimpleBuffers::UInt32Array sbt_y7rhSxKMeQu0r;
	CX::UInt32 sbt_oLpW8qcVxEo;
	CX::UInt32 sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU;

	virtual void Reset()
	{
		sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo = 0;
		sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz = 0;
		sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn = 0;
		sbt_KpnE1OjZCa6WH2YNjU8.clear();
		sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1 = 0;
		sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5 = false;
		sbt_y7rhSxKMeQu0r.clear();
		sbt_oLpW8qcVxEo = 0;
		sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo = 3662207547;
		sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz = 7256049726723338714;
		sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn = -69;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_KpnE1OjZCa6WH2YNjU8.push_back(-17);
		}
		sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1 = -1774841793;
		sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5 = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_y7rhSxKMeQu0r.push_back(1152261066);
		}
		sbt_oLpW8qcVxEo = 518795713;
		sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU = 50994230;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_SCONjR3uVv1OkwHTOiBiF_h *pObject = dynamic_cast<const sbt_SCONjR3uVv1OkwHTOiBiF_h *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo != pObject->sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo)
		{
			return false;
		}
		if (sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz != pObject->sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz)
		{
			return false;
		}
		if (sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn != pObject->sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn)
		{
			return false;
		}
		if (sbt_KpnE1OjZCa6WH2YNjU8.size() != pObject->sbt_KpnE1OjZCa6WH2YNjU8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KpnE1OjZCa6WH2YNjU8.size(); i++)
		{
			if (sbt_KpnE1OjZCa6WH2YNjU8[i] != pObject->sbt_KpnE1OjZCa6WH2YNjU8[i])
			{
				return false;
			}
		}
		if (sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1 != pObject->sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1)
		{
			return false;
		}
		if (sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5 != pObject->sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5)
		{
			return false;
		}
		if (sbt_y7rhSxKMeQu0r.size() != pObject->sbt_y7rhSxKMeQu0r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_y7rhSxKMeQu0r.size(); i++)
		{
			if (sbt_y7rhSxKMeQu0r[i] != pObject->sbt_y7rhSxKMeQu0r[i])
			{
				return false;
			}
		}
		if (sbt_oLpW8qcVxEo != pObject->sbt_oLpW8qcVxEo)
		{
			return false;
		}
		if (sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU != pObject->sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KpnE1OjZCa6WH2YNjU8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KpnE1OjZCa6WH2YNjU8.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5", &sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_y7rhSxKMeQu0r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_y7rhSxKMeQu0r.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oLpW8qcVxEo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oLpW8qcVxEo = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo", (CX::Int64)sbt_S3ax4MfI25Z_L7QiJiva0A0QhzGpYhz0BOHuo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz", (CX::Int64)sbt_9eeC25QBRcuuvAIeDSjoHbPsiRz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn", (CX::Int64)sbt_kuSsFfchWCoADkGAl9ve0DL1DJiD7hKmIS_PNR85Mf5dn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KpnE1OjZCa6WH2YNjU8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_KpnE1OjZCa6WH2YNjU8.begin(); iter != sbt_KpnE1OjZCa6WH2YNjU8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1", (CX::Int64)sbt__JNAMFwn3lPZJOLMxc8qgCXAWNcOkmXlFC6Yjv0GdY1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5", sbt_iUHn3nJFcvPdan1TCHAgFpQD3ivD9k7Giv3dqjB3c4IrLbNK8O1ONJxq5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_y7rhSxKMeQu0r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_y7rhSxKMeQu0r.begin(); iter != sbt_y7rhSxKMeQu0r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oLpW8qcVxEo", (CX::Int64)sbt_oLpW8qcVxEo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU", (CX::Int64)sbt_NvGpfWkFuNWaKJXXo7hU3pZ6lZ5FiLFP6nO6oQZdiBcbU)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_SCONjR3uVv1OkwHTOiBiF_h>::Type sbt_SCONjR3uVv1OkwHTOiBiF_hArray;

