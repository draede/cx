
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0;
	CX::IO::SimpleBuffers::UInt8Array sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI;
	CX::UInt32 sbt_fmCHSUYBLhUVLND;
	CX::IO::SimpleBuffers::UInt32Array sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P;
	CX::Int32 sbt_6f29B_IrK;
	CX::IO::SimpleBuffers::UInt16Array sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX;
	CX::IO::SimpleBuffers::Int64Array sbt_lCh2wuSHl6nXiMB64;
	CX::UInt32 sbt_BGYth;
	CX::UInt32 sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_;
	CX::Int8 sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7;
	CX::IO::SimpleBuffers::Int16Array sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt;
	CX::UInt32 sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq;
	CX::String sbt_q2MIWyD;
	CX::UInt8 sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5;
	CX::Bool sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT;
	CX::IO::SimpleBuffers::UInt64Array sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx;

	virtual void Reset()
	{
		sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0 = 0;
		sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.clear();
		sbt_fmCHSUYBLhUVLND = 0;
		sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.clear();
		sbt_6f29B_IrK = 0;
		sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.clear();
		sbt_lCh2wuSHl6nXiMB64.clear();
		sbt_BGYth = 0;
		sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_ = 0;
		sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7 = 0;
		sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.clear();
		sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq = 0;
		sbt_q2MIWyD.clear();
		sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5 = 0;
		sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT = false;
		sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0 = 189;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.push_back(94);
		}
		sbt_fmCHSUYBLhUVLND = 3906176436;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.push_back(2686795679);
		}
		sbt_6f29B_IrK = -247128148;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.push_back(51024);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_lCh2wuSHl6nXiMB64.push_back(-9202710002817398766);
		}
		sbt_BGYth = 707941910;
		sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_ = 1778438685;
		sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7 = 48;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.push_back(-22836);
		}
		sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq = 730113951;
		sbt_q2MIWyD = "*m5cFov'C~gM&DLo(&GAz{H";
		sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5 = 29;
		sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT = false;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.push_back(2115843527220020990);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW *pObject = dynamic_cast<const sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0 != pObject->sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0)
		{
			return false;
		}
		if (sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.size() != pObject->sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.size(); i++)
		{
			if (sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI[i] != pObject->sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI[i])
			{
				return false;
			}
		}
		if (sbt_fmCHSUYBLhUVLND != pObject->sbt_fmCHSUYBLhUVLND)
		{
			return false;
		}
		if (sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.size() != pObject->sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.size(); i++)
		{
			if (sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P[i] != pObject->sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P[i])
			{
				return false;
			}
		}
		if (sbt_6f29B_IrK != pObject->sbt_6f29B_IrK)
		{
			return false;
		}
		if (sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.size() != pObject->sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.size(); i++)
		{
			if (sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX[i] != pObject->sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX[i])
			{
				return false;
			}
		}
		if (sbt_lCh2wuSHl6nXiMB64.size() != pObject->sbt_lCh2wuSHl6nXiMB64.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lCh2wuSHl6nXiMB64.size(); i++)
		{
			if (sbt_lCh2wuSHl6nXiMB64[i] != pObject->sbt_lCh2wuSHl6nXiMB64[i])
			{
				return false;
			}
		}
		if (sbt_BGYth != pObject->sbt_BGYth)
		{
			return false;
		}
		if (sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_ != pObject->sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_)
		{
			return false;
		}
		if (sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7 != pObject->sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7)
		{
			return false;
		}
		if (sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.size() != pObject->sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.size(); i++)
		{
			if (sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt[i] != pObject->sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt[i])
			{
				return false;
			}
		}
		if (sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq != pObject->sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_q2MIWyD.c_str(), pObject->sbt_q2MIWyD.c_str()))
		{
			return false;
		}
		if (sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5 != pObject->sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5)
		{
			return false;
		}
		if (sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT != pObject->sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT)
		{
			return false;
		}
		if (sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.size() != pObject->sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.size(); i++)
		{
			if (sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx[i] != pObject->sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fmCHSUYBLhUVLND", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fmCHSUYBLhUVLND = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6f29B_IrK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6f29B_IrK = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lCh2wuSHl6nXiMB64")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lCh2wuSHl6nXiMB64.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BGYth", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BGYth = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_q2MIWyD", &sbt_q2MIWyD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT", &sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0", (CX::Int64)sbt_bS9opnn6j6esmmva8rJDzXQD7R3nrQa6oO379UakLKuwQi0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.begin(); iter != sbt_II1rME_jElHRrekrNc2r1O2dY6IpE8MwfyjrI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fmCHSUYBLhUVLND", (CX::Int64)sbt_fmCHSUYBLhUVLND)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.begin(); iter != sbt_fMIyB3rhwwyfMG7wKsOZGpH_bqZPzD1KD4MNkUYXN9nyRa4tXwDzu8P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6f29B_IrK", (CX::Int64)sbt_6f29B_IrK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.begin(); iter != sbt_L2oNFPnoR5WpnigHDtE2MNPS5kqJHwW0NfnGX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lCh2wuSHl6nXiMB64")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_lCh2wuSHl6nXiMB64.begin(); iter != sbt_lCh2wuSHl6nXiMB64.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BGYth", (CX::Int64)sbt_BGYth)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_", (CX::Int64)sbt_VrwenPwCkzXPgW3X4rxkUZFuFc8z_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7", (CX::Int64)sbt_y0hMh3dPLxzvqhVBeMjobAcRkiR7fDgB06Zz7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.begin(); iter != sbt_qdsamZiImyD8jWlTKmGD7ab6KcYhnWrAt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq", (CX::Int64)sbt_EMKeFoSRt5vpvGX8_OXEnCQSkGFzMNq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_q2MIWyD", sbt_q2MIWyD.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5", (CX::Int64)sbt_vNEGueNwQzuANAXNJDrUZ9N4D5BnD8nc00O0Ig1FuqSv5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT", sbt__jCvs1M0zZxEi1n8Q_ubGBiRF43I5YyFkO3XpeT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.begin(); iter != sbt_zxk7fw1iL9aKShL9jDARG94Jks0yZaDi1YlchhNsoWqrbHpcN4MMs280ulIGIWx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW>::Type sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsWArray;

