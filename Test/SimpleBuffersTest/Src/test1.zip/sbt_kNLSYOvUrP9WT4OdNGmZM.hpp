
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6.hpp"


class sbt_kNLSYOvUrP9WT4OdNGmZM : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN;
	CX::IO::SimpleBuffers::Int16Array sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF;
	CX::IO::SimpleBuffers::WStringArray sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR;
	CX::Int64 sbt_tW0CA_o0zaU3E6HD6;
	CX::Int32 sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv;
	CX::IO::SimpleBuffers::Int8Array sbt_k_R5nwXGLq1oLFA82;
	CX::IO::SimpleBuffers::Int32Array sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0;
	CX::IO::SimpleBuffers::UInt64Array sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX;
	CX::IO::SimpleBuffers::StringArray sbt_ES1fH18;
	CX::IO::SimpleBuffers::UInt16Array sbt_8A9Qpn4y5P1Z5;
	CX::UInt32 sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ;
	CX::Int16 sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg;
	CX::Float sbt_ZGVQ9NYHUI_BPyc900sowoj;
	CX::Bool sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW;
	CX::IO::SimpleBuffers::Int16Array sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7;
	CX::IO::SimpleBuffers::Int32Array sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs;
	CX::IO::SimpleBuffers::UInt64Array sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1;
	CX::Float sbt_edLza4w;
	CX::Float sbt_BMoz55EYo9t45;
	CX::Int64 sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN;
	CX::String sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0;
	sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6Array sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B;

	virtual void Reset()
	{
		sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.clear();
		sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.clear();
		sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.clear();
		sbt_tW0CA_o0zaU3E6HD6 = 0;
		sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv = 0;
		sbt_k_R5nwXGLq1oLFA82.clear();
		sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.clear();
		sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.clear();
		sbt_ES1fH18.clear();
		sbt_8A9Qpn4y5P1Z5.clear();
		sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ = 0;
		sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg = 0;
		sbt_ZGVQ9NYHUI_BPyc900sowoj = 0.0f;
		sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW = false;
		sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.clear();
		sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.clear();
		sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.clear();
		sbt_edLza4w = 0.0f;
		sbt_BMoz55EYo9t45 = 0.0f;
		sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN = 0;
		sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0.clear();
		sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.push_back(26);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.push_back(L"f\"?6a=EJJ>~?0p`kdp*h}r'jCqG_");
		}
		sbt_tW0CA_o0zaU3E6HD6 = -3688783836730092322;
		sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv = -688007557;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_k_R5nwXGLq1oLFA82.push_back(0);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.push_back(-43155623);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.push_back(5718076568029011264);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_ES1fH18.push_back(",R:oQ06&4[^Z^&`8uP=3TaYi3DvuwJ+0GL4zbb|{Te8ix+YRy~#sV21uw-ED");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_8A9Qpn4y5P1Z5.push_back(20539);
		}
		sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ = 4189801673;
		sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg = -20546;
		sbt_ZGVQ9NYHUI_BPyc900sowoj = 0.615229f;
		sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW = false;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.push_back(11218);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.push_back(-275361531);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.push_back(10108628661447986886);
		}
		sbt_edLza4w = 0.896780f;
		sbt_BMoz55EYo9t45 = 0.072039f;
		sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN = -3175505185064854298;
		sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0 = "m@`oz1@mR=RY>WJtDug\\cb0,3z~=";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 v;

			v.SetupWithSomeValues();
			sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_kNLSYOvUrP9WT4OdNGmZM *pObject = dynamic_cast<const sbt_kNLSYOvUrP9WT4OdNGmZM *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.size() != pObject->sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.size(); i++)
		{
			if (sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN[i] != pObject->sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN[i])
			{
				return false;
			}
		}
		if (sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.size() != pObject->sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.size(); i++)
		{
			if (sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF[i] != pObject->sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF[i])
			{
				return false;
			}
		}
		if (sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.size() != pObject->sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR[i].c_str(), pObject->sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_tW0CA_o0zaU3E6HD6 != pObject->sbt_tW0CA_o0zaU3E6HD6)
		{
			return false;
		}
		if (sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv != pObject->sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv)
		{
			return false;
		}
		if (sbt_k_R5nwXGLq1oLFA82.size() != pObject->sbt_k_R5nwXGLq1oLFA82.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k_R5nwXGLq1oLFA82.size(); i++)
		{
			if (sbt_k_R5nwXGLq1oLFA82[i] != pObject->sbt_k_R5nwXGLq1oLFA82[i])
			{
				return false;
			}
		}
		if (sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.size() != pObject->sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.size(); i++)
		{
			if (sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0[i] != pObject->sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0[i])
			{
				return false;
			}
		}
		if (sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.size() != pObject->sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.size(); i++)
		{
			if (sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX[i] != pObject->sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX[i])
			{
				return false;
			}
		}
		if (sbt_ES1fH18.size() != pObject->sbt_ES1fH18.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ES1fH18.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ES1fH18[i].c_str(), pObject->sbt_ES1fH18[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_8A9Qpn4y5P1Z5.size() != pObject->sbt_8A9Qpn4y5P1Z5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8A9Qpn4y5P1Z5.size(); i++)
		{
			if (sbt_8A9Qpn4y5P1Z5[i] != pObject->sbt_8A9Qpn4y5P1Z5[i])
			{
				return false;
			}
		}
		if (sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ != pObject->sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ)
		{
			return false;
		}
		if (sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg != pObject->sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg)
		{
			return false;
		}
		if (sbt_ZGVQ9NYHUI_BPyc900sowoj != pObject->sbt_ZGVQ9NYHUI_BPyc900sowoj)
		{
			return false;
		}
		if (sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW != pObject->sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW)
		{
			return false;
		}
		if (sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.size() != pObject->sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.size(); i++)
		{
			if (sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7[i] != pObject->sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7[i])
			{
				return false;
			}
		}
		if (sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.size() != pObject->sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.size(); i++)
		{
			if (sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs[i] != pObject->sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs[i])
			{
				return false;
			}
		}
		if (sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.size() != pObject->sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.size(); i++)
		{
			if (sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1[i] != pObject->sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1[i])
			{
				return false;
			}
		}
		if (sbt_edLza4w != pObject->sbt_edLza4w)
		{
			return false;
		}
		if (sbt_BMoz55EYo9t45 != pObject->sbt_BMoz55EYo9t45)
		{
			return false;
		}
		if (sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN != pObject->sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0.c_str(), pObject->sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0.c_str()))
		{
			return false;
		}
		if (sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.size() != pObject->sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.size(); i++)
		{
			if (!sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B[i].Compare(&pObject->sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tW0CA_o0zaU3E6HD6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tW0CA_o0zaU3E6HD6 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_k_R5nwXGLq1oLFA82")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k_R5nwXGLq1oLFA82.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ES1fH18")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ES1fH18.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8A9Qpn4y5P1Z5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8A9Qpn4y5P1Z5.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_ZGVQ9NYHUI_BPyc900sowoj", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ZGVQ9NYHUI_BPyc900sowoj = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW", &sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_edLza4w", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_edLza4w = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_BMoz55EYo9t45", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_BMoz55EYo9t45 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0", &sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.begin(); iter != sbt_fL_PIBd0IgDsxaShSPzqa72ukdKZYhbvGLN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.begin(); iter != sbt_hX55szbmGp6NgjGtb4pufvcJ3P0MyR3cDBHrF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.begin(); iter != sbt_0sPLserdz9izDvIc65NqYAGE_qp__dje_5hStJJTTLpK2jIAuW2HuZR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tW0CA_o0zaU3E6HD6", (CX::Int64)sbt_tW0CA_o0zaU3E6HD6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv", (CX::Int64)sbt_wKW6REVCVFJPBBgrKMM2MAXECPW8s3cckzfGv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k_R5nwXGLq1oLFA82")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_k_R5nwXGLq1oLFA82.begin(); iter != sbt_k_R5nwXGLq1oLFA82.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.begin(); iter != sbt_MrWPYLpWO4uBVpLyMWuVzgIKp7gulQX9CShIGlCUfvuUHQ2Q0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.begin(); iter != sbt_dAlbtXcNh9YEdsc3WkJbIYTVOabI1bV5lekEy4YAvHlZX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ES1fH18")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ES1fH18.begin(); iter != sbt_ES1fH18.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8A9Qpn4y5P1Z5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_8A9Qpn4y5P1Z5.begin(); iter != sbt_8A9Qpn4y5P1Z5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ", (CX::Int64)sbt_oLsxqHjjsVb5Nxd2C3LCRlDb_Z0La5d1U0uzpyxOQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg", (CX::Int64)sbt_WkANFAl9eK189SqyJ5Z0TUPCPeSSXrYFQRiG66vAHb7kg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ZGVQ9NYHUI_BPyc900sowoj", (CX::Double)sbt_ZGVQ9NYHUI_BPyc900sowoj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW", sbt_vnOXjLKvGd9EX8Al7kJdCa_TNqwvRQRpPfrMAjmTU7wCasJm7HD1j2fi3iRbW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.begin(); iter != sbt_FzNlibci2bZhu6OxMl96qZgqHQAW7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.begin(); iter != sbt_ZuVPtkiy7TIz9YDUB35OwAJ36S3z3OTmloHxvPgjWUTYJAZgTIDFs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.begin(); iter != sbt_HRzEGxHBDTT2zUpuo4GpHPx04KIIUMjOH1uYeqFb3w_qNx6IYNUTNDgjsF0H9j1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_edLza4w", (CX::Double)sbt_edLza4w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_BMoz55EYo9t45", (CX::Double)sbt_BMoz55EYo9t45)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN", (CX::Int64)sbt_Y5LlqmjzSNIRa3l5YS3J_i8pKMNIACwcvTjLN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0", sbt_9nYkhHyfAK6_c7BR75DoFtED9uXVHZYnTXunhz5VpWFYmTtwbN0.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B")).IsNOK())
		{
			return status;
		}
		for (sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6Array::const_iterator iter = sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.begin(); iter != sbt_v1n4EZ6EAby88E4qGOsdqHir5StdMUmLoy0f4Sp3CLSttyGpWND0B.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_kNLSYOvUrP9WT4OdNGmZM>::Type sbt_kNLSYOvUrP9WT4OdNGmZMArray;

