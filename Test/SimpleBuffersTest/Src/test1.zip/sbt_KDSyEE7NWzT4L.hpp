
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_DYiGJ.hpp"


class sbt_KDSyEE7NWzT4L : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_ep_xr7A;
	sbt_DYiGJArray sbt_8ykj45jsQfy;

	virtual void Reset()
	{
		sbt_ep_xr7A.clear();
		sbt_8ykj45jsQfy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_ep_xr7A.push_back(-28);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_DYiGJ v;

			v.SetupWithSomeValues();
			sbt_8ykj45jsQfy.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KDSyEE7NWzT4L *pObject = dynamic_cast<const sbt_KDSyEE7NWzT4L *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ep_xr7A.size() != pObject->sbt_ep_xr7A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ep_xr7A.size(); i++)
		{
			if (sbt_ep_xr7A[i] != pObject->sbt_ep_xr7A[i])
			{
				return false;
			}
		}
		if (sbt_8ykj45jsQfy.size() != pObject->sbt_8ykj45jsQfy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8ykj45jsQfy.size(); i++)
		{
			if (!sbt_8ykj45jsQfy[i].Compare(&pObject->sbt_8ykj45jsQfy[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_ep_xr7A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ep_xr7A.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8ykj45jsQfy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_DYiGJ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_8ykj45jsQfy.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_ep_xr7A")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ep_xr7A.begin(); iter != sbt_ep_xr7A.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8ykj45jsQfy")).IsNOK())
		{
			return status;
		}
		for (sbt_DYiGJArray::const_iterator iter = sbt_8ykj45jsQfy.begin(); iter != sbt_8ykj45jsQfy.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KDSyEE7NWzT4L>::Type sbt_KDSyEE7NWzT4LArray;

