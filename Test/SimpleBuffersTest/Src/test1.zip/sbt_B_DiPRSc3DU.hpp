
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB.hpp"


class sbt_B_DiPRSc3DU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_CZdPUfl4Sqyzeg9;
	CX::IO::SimpleBuffers::Int32Array sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW;
	CX::IO::SimpleBuffers::BoolArray sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4;
	CX::IO::SimpleBuffers::DoubleArray sbt_4Dc8Mp_;
	CX::WString sbt_LwpYi7uO7IsbjQ7p3gbcP;
	CX::IO::SimpleBuffers::Int16Array sbt_FwVwjrsOky7dWLWDgVObgCAgu;
	sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2;

	virtual void Reset()
	{
		sbt_CZdPUfl4Sqyzeg9.clear();
		sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.clear();
		sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.clear();
		sbt_4Dc8Mp_.clear();
		sbt_LwpYi7uO7IsbjQ7p3gbcP.clear();
		sbt_FwVwjrsOky7dWLWDgVObgCAgu.clear();
		sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_CZdPUfl4Sqyzeg9 = "yu8]';}+5f}^<>wxp3z*iLC=fc0hTCM_T$_xjxlt1h3gITV6y3a";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.push_back(-1251505599);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.push_back(false);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_4Dc8Mp_.push_back(0.778294);
		}
		sbt_LwpYi7uO7IsbjQ7p3gbcP = L";'C_zA0g94^x}i;~CL*1p4w?lo|6J\"I8)-_[P:w*vJ\\8(^Crw7/6XAcaP!";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_FwVwjrsOky7dWLWDgVObgCAgu.push_back(-18313);
		}
		sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_B_DiPRSc3DU *pObject = dynamic_cast<const sbt_B_DiPRSc3DU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_CZdPUfl4Sqyzeg9.c_str(), pObject->sbt_CZdPUfl4Sqyzeg9.c_str()))
		{
			return false;
		}
		if (sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.size() != pObject->sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.size(); i++)
		{
			if (sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW[i] != pObject->sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW[i])
			{
				return false;
			}
		}
		if (sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.size() != pObject->sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.size(); i++)
		{
			if (sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4[i] != pObject->sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4[i])
			{
				return false;
			}
		}
		if (sbt_4Dc8Mp_.size() != pObject->sbt_4Dc8Mp_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4Dc8Mp_.size(); i++)
		{
			if (sbt_4Dc8Mp_[i] != pObject->sbt_4Dc8Mp_[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_LwpYi7uO7IsbjQ7p3gbcP.c_str(), pObject->sbt_LwpYi7uO7IsbjQ7p3gbcP.c_str()))
		{
			return false;
		}
		if (sbt_FwVwjrsOky7dWLWDgVObgCAgu.size() != pObject->sbt_FwVwjrsOky7dWLWDgVObgCAgu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FwVwjrsOky7dWLWDgVObgCAgu.size(); i++)
		{
			if (sbt_FwVwjrsOky7dWLWDgVObgCAgu[i] != pObject->sbt_FwVwjrsOky7dWLWDgVObgCAgu[i])
			{
				return false;
			}
		}
		if (!sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2.Compare(&pObject->sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_CZdPUfl4Sqyzeg9", &sbt_CZdPUfl4Sqyzeg9)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4Dc8Mp_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4Dc8Mp_.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_LwpYi7uO7IsbjQ7p3gbcP", &sbt_LwpYi7uO7IsbjQ7p3gbcP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FwVwjrsOky7dWLWDgVObgCAgu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FwVwjrsOky7dWLWDgVObgCAgu.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_CZdPUfl4Sqyzeg9", sbt_CZdPUfl4Sqyzeg9.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.begin(); iter != sbt_Xro42QtbIcYumYIZPdx7Vh61ZebtsUxQQpg8wZXwW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.begin(); iter != sbt_r848OdHxGrXwuKaVeK9cQeowlDaqKp4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4Dc8Mp_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_4Dc8Mp_.begin(); iter != sbt_4Dc8Mp_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_LwpYi7uO7IsbjQ7p3gbcP", sbt_LwpYi7uO7IsbjQ7p3gbcP.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FwVwjrsOky7dWLWDgVObgCAgu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_FwVwjrsOky7dWLWDgVObgCAgu.begin(); iter != sbt_FwVwjrsOky7dWLWDgVObgCAgu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_1CIusP2SVFHZeZDCWaa9ksU_V_fR7YdoUytAodFvnp7vO3Tp2.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_B_DiPRSc3DU>::Type sbt_B_DiPRSc3DUArray;

