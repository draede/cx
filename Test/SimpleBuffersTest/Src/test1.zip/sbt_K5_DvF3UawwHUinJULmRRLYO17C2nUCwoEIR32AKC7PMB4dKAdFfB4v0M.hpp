
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_soILAEn0jpnG92sT7QTUM;
	CX::IO::SimpleBuffers::StringArray sbt_LgGmipOYtd9RiimqwKo7LVeSO;
	CX::UInt32 sbt_88Wa_35kkd1DST5Q7;
	CX::UInt16 sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll;
	CX::IO::SimpleBuffers::UInt64Array sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI;
	CX::IO::SimpleBuffers::UInt64Array sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID;
	CX::IO::SimpleBuffers::StringArray sbt_RY4LrVB65qE;
	CX::IO::SimpleBuffers::BoolArray sbt_dMAIh;
	CX::IO::SimpleBuffers::UInt8Array sbt_XUbvaH8;
	CX::IO::SimpleBuffers::UInt64Array sbt_B_UPs;
	CX::IO::SimpleBuffers::BoolArray sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U;
	CX::Bool sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm;
	CX::IO::SimpleBuffers::UInt32Array sbt_Cg8Sk2kH6;
	CX::IO::SimpleBuffers::UInt64Array sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz;

	virtual void Reset()
	{
		sbt_soILAEn0jpnG92sT7QTUM.clear();
		sbt_LgGmipOYtd9RiimqwKo7LVeSO.clear();
		sbt_88Wa_35kkd1DST5Q7 = 0;
		sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll = 0;
		sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.clear();
		sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.clear();
		sbt_RY4LrVB65qE.clear();
		sbt_dMAIh.clear();
		sbt_XUbvaH8.clear();
		sbt_B_UPs.clear();
		sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.clear();
		sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm = false;
		sbt_Cg8Sk2kH6.clear();
		sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_soILAEn0jpnG92sT7QTUM.push_back(13322781053485397718);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_LgGmipOYtd9RiimqwKo7LVeSO.push_back("lG&M*`]S*SM<2m>Ps0kkWpY;aFs,WFJQg{Jox");
		}
		sbt_88Wa_35kkd1DST5Q7 = 3510561346;
		sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll = 22599;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.push_back(11642549685030567442);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.push_back(3338671639071377576);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_RY4LrVB65qE.push_back("@xQA]svPRBupcS!KvP10]cE\\8TI<bTmAUvqe&QG");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_dMAIh.push_back(true);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_XUbvaH8.push_back(179);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_B_UPs.push_back(14329835937477717420);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.push_back(false);
		}
		sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm = false;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Cg8Sk2kH6.push_back(1083749718);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.push_back(6041980357731892702);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M *pObject = dynamic_cast<const sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_soILAEn0jpnG92sT7QTUM.size() != pObject->sbt_soILAEn0jpnG92sT7QTUM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_soILAEn0jpnG92sT7QTUM.size(); i++)
		{
			if (sbt_soILAEn0jpnG92sT7QTUM[i] != pObject->sbt_soILAEn0jpnG92sT7QTUM[i])
			{
				return false;
			}
		}
		if (sbt_LgGmipOYtd9RiimqwKo7LVeSO.size() != pObject->sbt_LgGmipOYtd9RiimqwKo7LVeSO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LgGmipOYtd9RiimqwKo7LVeSO.size(); i++)
		{
			if (0 != cx_strcmp(sbt_LgGmipOYtd9RiimqwKo7LVeSO[i].c_str(), pObject->sbt_LgGmipOYtd9RiimqwKo7LVeSO[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_88Wa_35kkd1DST5Q7 != pObject->sbt_88Wa_35kkd1DST5Q7)
		{
			return false;
		}
		if (sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll != pObject->sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll)
		{
			return false;
		}
		if (sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.size() != pObject->sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.size(); i++)
		{
			if (sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI[i] != pObject->sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI[i])
			{
				return false;
			}
		}
		if (sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.size() != pObject->sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.size(); i++)
		{
			if (sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID[i] != pObject->sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID[i])
			{
				return false;
			}
		}
		if (sbt_RY4LrVB65qE.size() != pObject->sbt_RY4LrVB65qE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RY4LrVB65qE.size(); i++)
		{
			if (0 != cx_strcmp(sbt_RY4LrVB65qE[i].c_str(), pObject->sbt_RY4LrVB65qE[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_dMAIh.size() != pObject->sbt_dMAIh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dMAIh.size(); i++)
		{
			if (sbt_dMAIh[i] != pObject->sbt_dMAIh[i])
			{
				return false;
			}
		}
		if (sbt_XUbvaH8.size() != pObject->sbt_XUbvaH8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XUbvaH8.size(); i++)
		{
			if (sbt_XUbvaH8[i] != pObject->sbt_XUbvaH8[i])
			{
				return false;
			}
		}
		if (sbt_B_UPs.size() != pObject->sbt_B_UPs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B_UPs.size(); i++)
		{
			if (sbt_B_UPs[i] != pObject->sbt_B_UPs[i])
			{
				return false;
			}
		}
		if (sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.size() != pObject->sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.size(); i++)
		{
			if (sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U[i] != pObject->sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U[i])
			{
				return false;
			}
		}
		if (sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm != pObject->sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm)
		{
			return false;
		}
		if (sbt_Cg8Sk2kH6.size() != pObject->sbt_Cg8Sk2kH6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Cg8Sk2kH6.size(); i++)
		{
			if (sbt_Cg8Sk2kH6[i] != pObject->sbt_Cg8Sk2kH6[i])
			{
				return false;
			}
		}
		if (sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.size() != pObject->sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.size(); i++)
		{
			if (sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz[i] != pObject->sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_soILAEn0jpnG92sT7QTUM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_soILAEn0jpnG92sT7QTUM.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LgGmipOYtd9RiimqwKo7LVeSO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LgGmipOYtd9RiimqwKo7LVeSO.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_88Wa_35kkd1DST5Q7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_88Wa_35kkd1DST5Q7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RY4LrVB65qE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RY4LrVB65qE.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dMAIh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dMAIh.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XUbvaH8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XUbvaH8.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_B_UPs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B_UPs.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm", &sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Cg8Sk2kH6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Cg8Sk2kH6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_soILAEn0jpnG92sT7QTUM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_soILAEn0jpnG92sT7QTUM.begin(); iter != sbt_soILAEn0jpnG92sT7QTUM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LgGmipOYtd9RiimqwKo7LVeSO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_LgGmipOYtd9RiimqwKo7LVeSO.begin(); iter != sbt_LgGmipOYtd9RiimqwKo7LVeSO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_88Wa_35kkd1DST5Q7", (CX::Int64)sbt_88Wa_35kkd1DST5Q7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll", (CX::Int64)sbt_6IAkXfQurE0hjL6gLWQy_xvaKKz6JjIr5jiUXENaEirRVggDiP1Ll)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.begin(); iter != sbt_WpDbCmJ0WQplFFp7XddhPLt24lOuXcI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.begin(); iter != sbt_DpzSKhuZKfI7SE4AS333FAyp2BOK2uZXUs4ID.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RY4LrVB65qE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_RY4LrVB65qE.begin(); iter != sbt_RY4LrVB65qE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dMAIh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_dMAIh.begin(); iter != sbt_dMAIh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XUbvaH8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XUbvaH8.begin(); iter != sbt_XUbvaH8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B_UPs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_B_UPs.begin(); iter != sbt_B_UPs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.begin(); iter != sbt_LNXlRVBhb3WjcBP9II9wOXbwGIKSL4U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm", sbt_tyT_hrJ5KYVv6eYaX3BVi7n7q3at2CHZy9Ycm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Cg8Sk2kH6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Cg8Sk2kH6.begin(); iter != sbt_Cg8Sk2kH6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.begin(); iter != sbt_c0zxpW5fZYGj40r_qS8OhIV6mNz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M>::Type sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0MArray;

