
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_A3JoH7x3TgRyKkgNsnGqASx;
	CX::IO::SimpleBuffers::UInt32Array sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM;
	CX::IO::SimpleBuffers::Int32Array sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD;
	CX::IO::SimpleBuffers::Int8Array sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr;
	CX::IO::SimpleBuffers::Int16Array sbt_pwkNmg2WO3pLWXyKM;
	CX::UInt32 sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m;
	CX::UInt32 sbt_cdswrmOGLl_IOu0mn;
	CX::IO::SimpleBuffers::Int64Array sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR;
	CX::Int32 sbt_oLkicAxofWthyszxy5WQ9sX;
	CX::UInt64 sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn;
	CX::UInt64 sbt_MgJ0hyU8Jrbkn6xcSBk9SNU;
	CX::UInt32 sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx;
	CX::String sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B;
	CX::Int8 sbt__Cp90;
	CX::Bool sbt_gjABs;

	virtual void Reset()
	{
		sbt_A3JoH7x3TgRyKkgNsnGqASx.clear();
		sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.clear();
		sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.clear();
		sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.clear();
		sbt_pwkNmg2WO3pLWXyKM.clear();
		sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m = 0;
		sbt_cdswrmOGLl_IOu0mn = 0;
		sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.clear();
		sbt_oLkicAxofWthyszxy5WQ9sX = 0;
		sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn = 0;
		sbt_MgJ0hyU8Jrbkn6xcSBk9SNU = 0;
		sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx = 0;
		sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B.clear();
		sbt__Cp90 = 0;
		sbt_gjABs = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_A3JoH7x3TgRyKkgNsnGqASx.push_back(205);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.push_back(692035682);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.push_back(-78);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_pwkNmg2WO3pLWXyKM.push_back(32422);
		}
		sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m = 374117897;
		sbt_cdswrmOGLl_IOu0mn = 80794481;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.push_back(-2194046221101435936);
		}
		sbt_oLkicAxofWthyszxy5WQ9sX = 127432693;
		sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn = 12696385062543992350;
		sbt_MgJ0hyU8Jrbkn6xcSBk9SNU = 16098984447881547856;
		sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx = 2525970291;
		sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B = "dBwUg;@mUQ}BbA6=;w,\"G>+aMZw$bVrs9}s8#<z$TFJ/an%,Q~%/!:2%NZk\"";
		sbt__Cp90 = 33;
		sbt_gjABs = true;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l *pObject = dynamic_cast<const sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_A3JoH7x3TgRyKkgNsnGqASx.size() != pObject->sbt_A3JoH7x3TgRyKkgNsnGqASx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A3JoH7x3TgRyKkgNsnGqASx.size(); i++)
		{
			if (sbt_A3JoH7x3TgRyKkgNsnGqASx[i] != pObject->sbt_A3JoH7x3TgRyKkgNsnGqASx[i])
			{
				return false;
			}
		}
		if (sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.size() != pObject->sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.size(); i++)
		{
			if (sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM[i] != pObject->sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM[i])
			{
				return false;
			}
		}
		if (sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.size() != pObject->sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.size(); i++)
		{
			if (sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD[i] != pObject->sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD[i])
			{
				return false;
			}
		}
		if (sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.size() != pObject->sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.size(); i++)
		{
			if (sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr[i] != pObject->sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr[i])
			{
				return false;
			}
		}
		if (sbt_pwkNmg2WO3pLWXyKM.size() != pObject->sbt_pwkNmg2WO3pLWXyKM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pwkNmg2WO3pLWXyKM.size(); i++)
		{
			if (sbt_pwkNmg2WO3pLWXyKM[i] != pObject->sbt_pwkNmg2WO3pLWXyKM[i])
			{
				return false;
			}
		}
		if (sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m != pObject->sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m)
		{
			return false;
		}
		if (sbt_cdswrmOGLl_IOu0mn != pObject->sbt_cdswrmOGLl_IOu0mn)
		{
			return false;
		}
		if (sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.size() != pObject->sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.size(); i++)
		{
			if (sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR[i] != pObject->sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR[i])
			{
				return false;
			}
		}
		if (sbt_oLkicAxofWthyszxy5WQ9sX != pObject->sbt_oLkicAxofWthyszxy5WQ9sX)
		{
			return false;
		}
		if (sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn != pObject->sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn)
		{
			return false;
		}
		if (sbt_MgJ0hyU8Jrbkn6xcSBk9SNU != pObject->sbt_MgJ0hyU8Jrbkn6xcSBk9SNU)
		{
			return false;
		}
		if (sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx != pObject->sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B.c_str(), pObject->sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B.c_str()))
		{
			return false;
		}
		if (sbt__Cp90 != pObject->sbt__Cp90)
		{
			return false;
		}
		if (sbt_gjABs != pObject->sbt_gjABs)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_A3JoH7x3TgRyKkgNsnGqASx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A3JoH7x3TgRyKkgNsnGqASx.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pwkNmg2WO3pLWXyKM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pwkNmg2WO3pLWXyKM.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_cdswrmOGLl_IOu0mn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cdswrmOGLl_IOu0mn = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oLkicAxofWthyszxy5WQ9sX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oLkicAxofWthyszxy5WQ9sX = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MgJ0hyU8Jrbkn6xcSBk9SNU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MgJ0hyU8Jrbkn6xcSBk9SNU = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B", &sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__Cp90", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__Cp90 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_gjABs", &sbt_gjABs)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_A3JoH7x3TgRyKkgNsnGqASx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_A3JoH7x3TgRyKkgNsnGqASx.begin(); iter != sbt_A3JoH7x3TgRyKkgNsnGqASx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.begin(); iter != sbt_VzhhQrTUZEhPtmNADRZ6MpNWXo3ORqI2g4teYSBsAWcuzI_C5nfsCZMHogxFdxM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.begin(); iter != sbt_gNp2Ox2cL0PRHM7QthsgdaDAMZI4wkeNfQ1oaWcEn7pgT4jPD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.begin(); iter != sbt_lsN8ognjtHkdrgTEm95etGaqXfYlRAFN2wgNDOqgIOqKZf6KO9f_Vy8tHz4GNWr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pwkNmg2WO3pLWXyKM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_pwkNmg2WO3pLWXyKM.begin(); iter != sbt_pwkNmg2WO3pLWXyKM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m", (CX::Int64)sbt_jkd8EcWjqM3a3YrEz5TyrdOU9WHUXXI0m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cdswrmOGLl_IOu0mn", (CX::Int64)sbt_cdswrmOGLl_IOu0mn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.begin(); iter != sbt_i2eGKo7jCfa90ZSZtChTjmL_PCFsN03rzgthmso88pXHJRZnl8Goio1G2DULR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oLkicAxofWthyszxy5WQ9sX", (CX::Int64)sbt_oLkicAxofWthyszxy5WQ9sX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn", (CX::Int64)sbt_jtNUTRS9ZQrIkOAS6HtWF82Fn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MgJ0hyU8Jrbkn6xcSBk9SNU", (CX::Int64)sbt_MgJ0hyU8Jrbkn6xcSBk9SNU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx", (CX::Int64)sbt_mfppFKnLLrsTpfDvs4p1DE1WGSx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B", sbt_GgXq6OGUb4V9UDQwCkxok5N9hHl9r64N7qw4yP0sKTPABkx1KHg3fNzqDU8_B.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__Cp90", (CX::Int64)sbt__Cp90)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_gjABs", sbt_gjABs)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l>::Type sbt_CT4pPG5SwdsVYjc5aOThZKC1v0lArray;

