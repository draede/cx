
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt__O0rzbe7K5DbY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt__kZyQkV4udsknbJRiSNBD;
	CX::IO::SimpleBuffers::UInt32Array sbt_BWswbzUrW37qSRM;
	CX::UInt16 sbt_dw9qyJHNXhuwP;
	CX::Int64 sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk;
	CX::UInt64 sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm;
	CX::IO::SimpleBuffers::UInt64Array sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC;
	CX::IO::SimpleBuffers::UInt8Array sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h;
	CX::IO::SimpleBuffers::Int16Array sbt_LKW;
	CX::IO::SimpleBuffers::UInt8Array sbt_cbw9X5WP6;
	CX::String sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS;

	virtual void Reset()
	{
		sbt__kZyQkV4udsknbJRiSNBD.clear();
		sbt_BWswbzUrW37qSRM.clear();
		sbt_dw9qyJHNXhuwP = 0;
		sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk = 0;
		sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm = 0;
		sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.clear();
		sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.clear();
		sbt_LKW.clear();
		sbt_cbw9X5WP6.clear();
		sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt__kZyQkV4udsknbJRiSNBD.push_back(15460854105601033552);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_BWswbzUrW37qSRM.push_back(1871122860);
		}
		sbt_dw9qyJHNXhuwP = 51984;
		sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk = 4131557075976704338;
		sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm = 1109114255931199782;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.push_back(11104425685695325038);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.push_back(49);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_LKW.push_back(-25555);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_cbw9X5WP6.push_back(118);
		}
		sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS = "-2EK<Z}381^uScJE+BlF'csiD\"$IZ}t`<gFC\\GdfS9Dlz]Uilg[wc+!w$a7O/ii";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__O0rzbe7K5DbY *pObject = dynamic_cast<const sbt__O0rzbe7K5DbY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt__kZyQkV4udsknbJRiSNBD.size() != pObject->sbt__kZyQkV4udsknbJRiSNBD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__kZyQkV4udsknbJRiSNBD.size(); i++)
		{
			if (sbt__kZyQkV4udsknbJRiSNBD[i] != pObject->sbt__kZyQkV4udsknbJRiSNBD[i])
			{
				return false;
			}
		}
		if (sbt_BWswbzUrW37qSRM.size() != pObject->sbt_BWswbzUrW37qSRM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BWswbzUrW37qSRM.size(); i++)
		{
			if (sbt_BWswbzUrW37qSRM[i] != pObject->sbt_BWswbzUrW37qSRM[i])
			{
				return false;
			}
		}
		if (sbt_dw9qyJHNXhuwP != pObject->sbt_dw9qyJHNXhuwP)
		{
			return false;
		}
		if (sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk != pObject->sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk)
		{
			return false;
		}
		if (sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm != pObject->sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm)
		{
			return false;
		}
		if (sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.size() != pObject->sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.size(); i++)
		{
			if (sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC[i] != pObject->sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC[i])
			{
				return false;
			}
		}
		if (sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.size() != pObject->sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.size(); i++)
		{
			if (sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h[i] != pObject->sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h[i])
			{
				return false;
			}
		}
		if (sbt_LKW.size() != pObject->sbt_LKW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LKW.size(); i++)
		{
			if (sbt_LKW[i] != pObject->sbt_LKW[i])
			{
				return false;
			}
		}
		if (sbt_cbw9X5WP6.size() != pObject->sbt_cbw9X5WP6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cbw9X5WP6.size(); i++)
		{
			if (sbt_cbw9X5WP6[i] != pObject->sbt_cbw9X5WP6[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS.c_str(), pObject->sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt__kZyQkV4udsknbJRiSNBD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__kZyQkV4udsknbJRiSNBD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BWswbzUrW37qSRM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BWswbzUrW37qSRM.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dw9qyJHNXhuwP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dw9qyJHNXhuwP = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LKW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LKW.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cbw9X5WP6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cbw9X5WP6.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS", &sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt__kZyQkV4udsknbJRiSNBD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt__kZyQkV4udsknbJRiSNBD.begin(); iter != sbt__kZyQkV4udsknbJRiSNBD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BWswbzUrW37qSRM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_BWswbzUrW37qSRM.begin(); iter != sbt_BWswbzUrW37qSRM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dw9qyJHNXhuwP", (CX::Int64)sbt_dw9qyJHNXhuwP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk", (CX::Int64)sbt_1zVoeaABhiMM_THUHd3935aM7GvVzdyEDxlteNAzm9N_qeB_nvIl6dARk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm", (CX::Int64)sbt_qsL71elEsdkoaY9Nd4BiuAuXW8eNurRbYs9dm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.begin(); iter != sbt_PhOhcVa1TxslQqXpSuoK3yesgxQNf_6EQuC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.begin(); iter != sbt_1u4ykss6xOXsbjIJXAFm5lvGPUEGQ3bOMA53lm9uvBCpY9h.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LKW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_LKW.begin(); iter != sbt_LKW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cbw9X5WP6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_cbw9X5WP6.begin(); iter != sbt_cbw9X5WP6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS", sbt_Se_IAUUcQ0mefM2Gnp4ITLFA2Y02suKYSk2bwkxfywZVVgS.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__O0rzbe7K5DbY>::Type sbt__O0rzbe7K5DbYArray;

