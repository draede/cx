
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE.hpp"


class sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk;
	CX::Double sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6;
	CX::IO::SimpleBuffers::UInt16Array sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc;
	CX::UInt64 sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh;
	CX::Bool sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_;
	CX::IO::SimpleBuffers::Int16Array sbt_QCRogykRQlu65we2pfS;
	CX::WString sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw;
	CX::UInt64 sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a;
	sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYEArray sbt_kL_tWjTCwWS69FwrC2nlk6pHu;

	virtual void Reset()
	{
		sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk = 0;
		sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6 = 0.0;
		sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.clear();
		sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh = 0;
		sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_ = false;
		sbt_QCRogykRQlu65we2pfS.clear();
		sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw.clear();
		sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a = 0;
		sbt_kL_tWjTCwWS69FwrC2nlk6pHu.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk = -418177034;
		sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6 = 0.010357;
		sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh = 1516447715658976960;
		sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_ = false;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_QCRogykRQlu65we2pfS.push_back(12587);
		}
		sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw = L"s$!U]oBRNp,UoV87E>U|7$?";
		sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a = 9804542031798928314;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE v;

			v.SetupWithSomeValues();
			sbt_kL_tWjTCwWS69FwrC2nlk6pHu.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka *pObject = dynamic_cast<const sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk != pObject->sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk)
		{
			return false;
		}
		if (sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6 != pObject->sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6)
		{
			return false;
		}
		if (sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.size() != pObject->sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.size(); i++)
		{
			if (sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc[i] != pObject->sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc[i])
			{
				return false;
			}
		}
		if (sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh != pObject->sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh)
		{
			return false;
		}
		if (sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_ != pObject->sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_)
		{
			return false;
		}
		if (sbt_QCRogykRQlu65we2pfS.size() != pObject->sbt_QCRogykRQlu65we2pfS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QCRogykRQlu65we2pfS.size(); i++)
		{
			if (sbt_QCRogykRQlu65we2pfS[i] != pObject->sbt_QCRogykRQlu65we2pfS[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw.c_str(), pObject->sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw.c_str()))
		{
			return false;
		}
		if (sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a != pObject->sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a)
		{
			return false;
		}
		if (sbt_kL_tWjTCwWS69FwrC2nlk6pHu.size() != pObject->sbt_kL_tWjTCwWS69FwrC2nlk6pHu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kL_tWjTCwWS69FwrC2nlk6pHu.size(); i++)
		{
			if (!sbt_kL_tWjTCwWS69FwrC2nlk6pHu[i].Compare(&pObject->sbt_kL_tWjTCwWS69FwrC2nlk6pHu[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_", &sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QCRogykRQlu65we2pfS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QCRogykRQlu65we2pfS.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw", &sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kL_tWjTCwWS69FwrC2nlk6pHu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_kL_tWjTCwWS69FwrC2nlk6pHu.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk", (CX::Int64)sbt_5c3zDU0sFF0Qcbl9w3zq5kooJfZuBLWhTyCosPf970eJ6pHq0OWWk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6", (CX::Double)sbt_jF8EieTUuuoEwwSBuGeHQt3CV0MJ8g5SE2p7rsoQNGkblGGCn4bW6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.begin(); iter != sbt_vem_MT9JCe7nPHdmtxpxMgkuWr7vreVOha9jM0U4pORoqqP4L65Tc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh", (CX::Int64)sbt_gkhgHIwCmC7bBIw7XJtvyxizc5LFW9HYGbtE8vxW1xh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_", sbt_3wVwq0fRlNaL0Jpgg5cieMdik4OEJ2sLvmnpbGN3_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QCRogykRQlu65we2pfS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_QCRogykRQlu65we2pfS.begin(); iter != sbt_QCRogykRQlu65we2pfS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw", sbt_cXMStCHtR3gDhVX2MMhtPDDEPB9MtZr9M_PYw.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a", (CX::Int64)sbt_orgnExHwj6smjIIke95ZboY1Xia5QGH3LAMV41ASA5PZsljOd9Q7WgdSd7a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kL_tWjTCwWS69FwrC2nlk6pHu")).IsNOK())
		{
			return status;
		}
		for (sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYEArray::const_iterator iter = sbt_kL_tWjTCwWS69FwrC2nlk6pHu.begin(); iter != sbt_kL_tWjTCwWS69FwrC2nlk6pHu.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka>::Type sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVkaArray;

