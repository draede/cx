
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_bltZyIWaKHLtLThcOgbXS7A.hpp"


class sbt_2hPj9wyuJ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_VRX;
	CX::IO::SimpleBuffers::DoubleArray sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv;
	CX::UInt32 sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I;
	CX::Int32 sbt_HmsWuU39dTcaWrr;
	CX::UInt16 sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp;
	CX::IO::SimpleBuffers::BoolArray sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit;
	CX::IO::SimpleBuffers::UInt16Array sbt_Kon_x;
	CX::UInt8 sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t;
	CX::UInt32 sbt_TVkbt24y9KULovYQKWLJ3;
	CX::IO::SimpleBuffers::Int32Array sbt_2Y40SnnZYOnImudI7JM;
	CX::WString sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3;
	CX::WString sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI;
	CX::IO::SimpleBuffers::Int8Array sbt_weFOo1PXD7b67gK6q4o3P;
	CX::Bool sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq;
	CX::IO::SimpleBuffers::UInt64Array sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR;
	CX::String sbt_FMGp2zpuyP0qd;
	CX::Double sbt_ncju6qr1Gly;
	CX::UInt8 sbt_qepKCYJ5oLV;
	CX::UInt8 sbt_0aWkCBmkM2BfXKnHC0qIPmv;
	CX::IO::SimpleBuffers::Int8Array sbt_E;
	CX::IO::SimpleBuffers::Int32Array sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg;
	CX::UInt64 sbt_uCXx9fHnn;
	CX::IO::SimpleBuffers::StringArray sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K;
	CX::Bool sbt_DYXMlKlTn_Xb5;
	sbt_bltZyIWaKHLtLThcOgbXS7A sbt_x4GgQeC;

	virtual void Reset()
	{
		sbt_VRX = 0;
		sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.clear();
		sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I = 0;
		sbt_HmsWuU39dTcaWrr = 0;
		sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp = 0;
		sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.clear();
		sbt_Kon_x.clear();
		sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t = 0;
		sbt_TVkbt24y9KULovYQKWLJ3 = 0;
		sbt_2Y40SnnZYOnImudI7JM.clear();
		sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3.clear();
		sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI.clear();
		sbt_weFOo1PXD7b67gK6q4o3P.clear();
		sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq = false;
		sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.clear();
		sbt_FMGp2zpuyP0qd.clear();
		sbt_ncju6qr1Gly = 0.0;
		sbt_qepKCYJ5oLV = 0;
		sbt_0aWkCBmkM2BfXKnHC0qIPmv = 0;
		sbt_E.clear();
		sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.clear();
		sbt_uCXx9fHnn = 0;
		sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.clear();
		sbt_DYXMlKlTn_Xb5 = false;
		sbt_x4GgQeC.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_VRX = 1549628454;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.push_back(0.782225);
		}
		sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I = 3577994612;
		sbt_HmsWuU39dTcaWrr = 1152086336;
		sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp = 37598;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.push_back(true);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Kon_x.push_back(57751);
		}
		sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t = 2;
		sbt_TVkbt24y9KULovYQKWLJ3 = 2421552203;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_2Y40SnnZYOnImudI7JM.push_back(-1696870599);
		}
		sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3 = L"U@";
		sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI = L"qX0IZ(qfe4g!<~W1'\\c)i\"e5Y@OnsCqn";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_weFOo1PXD7b67gK6q4o3P.push_back(-124);
		}
		sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq = true;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.push_back(17942540551273436506);
		}
		sbt_FMGp2zpuyP0qd = "$!;~\"mcMCtPV0/,(%zH|O`,fQ(}O<Mfr.e1lYuK@s<C=PyP3:]xnap,ZFz2jxe@c";
		sbt_ncju6qr1Gly = 0.932062;
		sbt_qepKCYJ5oLV = 134;
		sbt_0aWkCBmkM2BfXKnHC0qIPmv = 135;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_E.push_back(2);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.push_back(-1834881079);
		}
		sbt_uCXx9fHnn = 9965428681487089614;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.push_back("/f6%t-]1o.;~9[k.");
		}
		sbt_DYXMlKlTn_Xb5 = false;
		sbt_x4GgQeC.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2hPj9wyuJ *pObject = dynamic_cast<const sbt_2hPj9wyuJ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VRX != pObject->sbt_VRX)
		{
			return false;
		}
		if (sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.size() != pObject->sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.size(); i++)
		{
			if (sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv[i] != pObject->sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv[i])
			{
				return false;
			}
		}
		if (sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I != pObject->sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I)
		{
			return false;
		}
		if (sbt_HmsWuU39dTcaWrr != pObject->sbt_HmsWuU39dTcaWrr)
		{
			return false;
		}
		if (sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp != pObject->sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp)
		{
			return false;
		}
		if (sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.size() != pObject->sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.size(); i++)
		{
			if (sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit[i] != pObject->sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit[i])
			{
				return false;
			}
		}
		if (sbt_Kon_x.size() != pObject->sbt_Kon_x.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Kon_x.size(); i++)
		{
			if (sbt_Kon_x[i] != pObject->sbt_Kon_x[i])
			{
				return false;
			}
		}
		if (sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t != pObject->sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t)
		{
			return false;
		}
		if (sbt_TVkbt24y9KULovYQKWLJ3 != pObject->sbt_TVkbt24y9KULovYQKWLJ3)
		{
			return false;
		}
		if (sbt_2Y40SnnZYOnImudI7JM.size() != pObject->sbt_2Y40SnnZYOnImudI7JM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2Y40SnnZYOnImudI7JM.size(); i++)
		{
			if (sbt_2Y40SnnZYOnImudI7JM[i] != pObject->sbt_2Y40SnnZYOnImudI7JM[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3.c_str(), pObject->sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3.c_str()))
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI.c_str(), pObject->sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI.c_str()))
		{
			return false;
		}
		if (sbt_weFOo1PXD7b67gK6q4o3P.size() != pObject->sbt_weFOo1PXD7b67gK6q4o3P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_weFOo1PXD7b67gK6q4o3P.size(); i++)
		{
			if (sbt_weFOo1PXD7b67gK6q4o3P[i] != pObject->sbt_weFOo1PXD7b67gK6q4o3P[i])
			{
				return false;
			}
		}
		if (sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq != pObject->sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq)
		{
			return false;
		}
		if (sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.size() != pObject->sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.size(); i++)
		{
			if (sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR[i] != pObject->sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_FMGp2zpuyP0qd.c_str(), pObject->sbt_FMGp2zpuyP0qd.c_str()))
		{
			return false;
		}
		if (sbt_ncju6qr1Gly != pObject->sbt_ncju6qr1Gly)
		{
			return false;
		}
		if (sbt_qepKCYJ5oLV != pObject->sbt_qepKCYJ5oLV)
		{
			return false;
		}
		if (sbt_0aWkCBmkM2BfXKnHC0qIPmv != pObject->sbt_0aWkCBmkM2BfXKnHC0qIPmv)
		{
			return false;
		}
		if (sbt_E.size() != pObject->sbt_E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E.size(); i++)
		{
			if (sbt_E[i] != pObject->sbt_E[i])
			{
				return false;
			}
		}
		if (sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.size() != pObject->sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.size(); i++)
		{
			if (sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg[i] != pObject->sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg[i])
			{
				return false;
			}
		}
		if (sbt_uCXx9fHnn != pObject->sbt_uCXx9fHnn)
		{
			return false;
		}
		if (sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.size() != pObject->sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.size(); i++)
		{
			if (0 != cx_strcmp(sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K[i].c_str(), pObject->sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_DYXMlKlTn_Xb5 != pObject->sbt_DYXMlKlTn_Xb5)
		{
			return false;
		}
		if (!sbt_x4GgQeC.Compare(&pObject->sbt_x4GgQeC))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_VRX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VRX = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HmsWuU39dTcaWrr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HmsWuU39dTcaWrr = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Kon_x")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Kon_x.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TVkbt24y9KULovYQKWLJ3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TVkbt24y9KULovYQKWLJ3 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2Y40SnnZYOnImudI7JM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2Y40SnnZYOnImudI7JM.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3", &sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI", &sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_weFOo1PXD7b67gK6q4o3P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_weFOo1PXD7b67gK6q4o3P.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq", &sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_FMGp2zpuyP0qd", &sbt_FMGp2zpuyP0qd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_ncju6qr1Gly", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ncju6qr1Gly = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_qepKCYJ5oLV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qepKCYJ5oLV = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0aWkCBmkM2BfXKnHC0qIPmv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0aWkCBmkM2BfXKnHC0qIPmv = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_uCXx9fHnn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uCXx9fHnn = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_DYXMlKlTn_Xb5", &sbt_DYXMlKlTn_Xb5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_x4GgQeC")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_x4GgQeC.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_VRX", (CX::Int64)sbt_VRX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.begin(); iter != sbt_xTYtzA0SreWI0N6CjUO7W_Erkiv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I", (CX::Int64)sbt_fT6mvz21zX2GuCPstyBGyI2gOpBxOkn1pq52_utvMof1I)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HmsWuU39dTcaWrr", (CX::Int64)sbt_HmsWuU39dTcaWrr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp", (CX::Int64)sbt_gv6OjoAdheeuAxRW0z9dRJxVDCi43hMQcYgnHi3X0Vs1o1UM2n6Kp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.begin(); iter != sbt__49TlRkvGBISCvwuGIocSU_Xz2AhOWW_iR0YNi2zIGnjvmNyIKHryV2QEit.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Kon_x")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Kon_x.begin(); iter != sbt_Kon_x.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t", (CX::Int64)sbt_DnRwEfcQpv2fMvTPCFa8el6MO16alcUhq7t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TVkbt24y9KULovYQKWLJ3", (CX::Int64)sbt_TVkbt24y9KULovYQKWLJ3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2Y40SnnZYOnImudI7JM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_2Y40SnnZYOnImudI7JM.begin(); iter != sbt_2Y40SnnZYOnImudI7JM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3", sbt_mCOEt3fjd8lTbiUWvyNC3HXteP3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI", sbt_uyRHzGiSYpT1zmxpLvAcLLBoQsDMoS1ApV3ZbdYaCvNXydI2moI.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_weFOo1PXD7b67gK6q4o3P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_weFOo1PXD7b67gK6q4o3P.begin(); iter != sbt_weFOo1PXD7b67gK6q4o3P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq", sbt_t6wTZMct_aSDO8_2wn6ma_FYHmMjuJaRq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.begin(); iter != sbt_b_xyLJsaJPiRlPyP1k_xqZJe3SU1WMyL6ZQuB2ybWUMpcAbTR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_FMGp2zpuyP0qd", sbt_FMGp2zpuyP0qd.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ncju6qr1Gly", (CX::Double)sbt_ncju6qr1Gly)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qepKCYJ5oLV", (CX::Int64)sbt_qepKCYJ5oLV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0aWkCBmkM2BfXKnHC0qIPmv", (CX::Int64)sbt_0aWkCBmkM2BfXKnHC0qIPmv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_E.begin(); iter != sbt_E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.begin(); iter != sbt__Kb7AxPQtbAK3Z49ODwuR0XsMlqoKJZmu9QInAEFg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uCXx9fHnn", (CX::Int64)sbt_uCXx9fHnn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.begin(); iter != sbt_OjY_1RH6cNON9UTC9SNY0wINsOwkLtstn4MQY1K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_DYXMlKlTn_Xb5", sbt_DYXMlKlTn_Xb5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_x4GgQeC")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_x4GgQeC.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2hPj9wyuJ>::Type sbt_2hPj9wyuJArray;

