
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_N_n0Grp5_2dTTTlFuVjOezBdT : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ;
	CX::IO::SimpleBuffers::Int64Array sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK;
	CX::UInt64 sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6;
	CX::IO::SimpleBuffers::UInt64Array sbt_QIiMmNV8k1VvuoijvtFkcJHSJ;
	CX::IO::SimpleBuffers::UInt32Array sbt_qrk5cSHFNLZM4nVbjCJ;
	CX::IO::SimpleBuffers::UInt16Array sbt_JxcKynd9aUiefCSHSWYPzSZ1h;
	CX::IO::SimpleBuffers::UInt32Array sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs;
	CX::IO::SimpleBuffers::UInt16Array sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U;
	CX::IO::SimpleBuffers::UInt32Array sbt_QK6ZPu1SDjxK50g;
	CX::IO::SimpleBuffers::UInt32Array sbt_eYFyxd0GDRRflq_;
	CX::UInt8 sbt_mjoHce_x4BQhvOX;
	CX::UInt64 sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7;
	CX::Int16 sbt_rYeWTxbS1_KxQ40b_D2fmYR;
	CX::IO::SimpleBuffers::UInt8Array sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz;
	CX::UInt32 sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH;
	CX::IO::SimpleBuffers::StringArray sbt_LPLN__z;
	CX::IO::SimpleBuffers::Int16Array sbt_apY;

	virtual void Reset()
	{
		sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ = 0;
		sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.clear();
		sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6 = 0;
		sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.clear();
		sbt_qrk5cSHFNLZM4nVbjCJ.clear();
		sbt_JxcKynd9aUiefCSHSWYPzSZ1h.clear();
		sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.clear();
		sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.clear();
		sbt_QK6ZPu1SDjxK50g.clear();
		sbt_eYFyxd0GDRRflq_.clear();
		sbt_mjoHce_x4BQhvOX = 0;
		sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7 = 0;
		sbt_rYeWTxbS1_KxQ40b_D2fmYR = 0;
		sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.clear();
		sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH = 0;
		sbt_LPLN__z.clear();
		sbt_apY.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ = -19;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.push_back(6167663296184247702);
		}
		sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6 = 3210036889774445892;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.push_back(13022818792511761900);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_qrk5cSHFNLZM4nVbjCJ.push_back(3845571939);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_JxcKynd9aUiefCSHSWYPzSZ1h.push_back(32788);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.push_back(3497996039);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.push_back(59606);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_QK6ZPu1SDjxK50g.push_back(1483832155);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_eYFyxd0GDRRflq_.push_back(854891798);
		}
		sbt_mjoHce_x4BQhvOX = 207;
		sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7 = 8572961953658523806;
		sbt_rYeWTxbS1_KxQ40b_D2fmYR = -24292;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.push_back(170);
		}
		sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH = 1262689538;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LPLN__z.push_back("d^]MR9Fuv^Oc\\08xoQM:lZY$E&=Kn2T");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_apY.push_back(-27909);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_N_n0Grp5_2dTTTlFuVjOezBdT *pObject = dynamic_cast<const sbt_N_n0Grp5_2dTTTlFuVjOezBdT *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ != pObject->sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ)
		{
			return false;
		}
		if (sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.size() != pObject->sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.size(); i++)
		{
			if (sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK[i] != pObject->sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK[i])
			{
				return false;
			}
		}
		if (sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6 != pObject->sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6)
		{
			return false;
		}
		if (sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.size() != pObject->sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.size(); i++)
		{
			if (sbt_QIiMmNV8k1VvuoijvtFkcJHSJ[i] != pObject->sbt_QIiMmNV8k1VvuoijvtFkcJHSJ[i])
			{
				return false;
			}
		}
		if (sbt_qrk5cSHFNLZM4nVbjCJ.size() != pObject->sbt_qrk5cSHFNLZM4nVbjCJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qrk5cSHFNLZM4nVbjCJ.size(); i++)
		{
			if (sbt_qrk5cSHFNLZM4nVbjCJ[i] != pObject->sbt_qrk5cSHFNLZM4nVbjCJ[i])
			{
				return false;
			}
		}
		if (sbt_JxcKynd9aUiefCSHSWYPzSZ1h.size() != pObject->sbt_JxcKynd9aUiefCSHSWYPzSZ1h.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JxcKynd9aUiefCSHSWYPzSZ1h.size(); i++)
		{
			if (sbt_JxcKynd9aUiefCSHSWYPzSZ1h[i] != pObject->sbt_JxcKynd9aUiefCSHSWYPzSZ1h[i])
			{
				return false;
			}
		}
		if (sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.size() != pObject->sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.size(); i++)
		{
			if (sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs[i] != pObject->sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs[i])
			{
				return false;
			}
		}
		if (sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.size() != pObject->sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.size(); i++)
		{
			if (sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U[i] != pObject->sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U[i])
			{
				return false;
			}
		}
		if (sbt_QK6ZPu1SDjxK50g.size() != pObject->sbt_QK6ZPu1SDjxK50g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QK6ZPu1SDjxK50g.size(); i++)
		{
			if (sbt_QK6ZPu1SDjxK50g[i] != pObject->sbt_QK6ZPu1SDjxK50g[i])
			{
				return false;
			}
		}
		if (sbt_eYFyxd0GDRRflq_.size() != pObject->sbt_eYFyxd0GDRRflq_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eYFyxd0GDRRflq_.size(); i++)
		{
			if (sbt_eYFyxd0GDRRflq_[i] != pObject->sbt_eYFyxd0GDRRflq_[i])
			{
				return false;
			}
		}
		if (sbt_mjoHce_x4BQhvOX != pObject->sbt_mjoHce_x4BQhvOX)
		{
			return false;
		}
		if (sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7 != pObject->sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7)
		{
			return false;
		}
		if (sbt_rYeWTxbS1_KxQ40b_D2fmYR != pObject->sbt_rYeWTxbS1_KxQ40b_D2fmYR)
		{
			return false;
		}
		if (sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.size() != pObject->sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.size(); i++)
		{
			if (sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz[i] != pObject->sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz[i])
			{
				return false;
			}
		}
		if (sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH != pObject->sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH)
		{
			return false;
		}
		if (sbt_LPLN__z.size() != pObject->sbt_LPLN__z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LPLN__z.size(); i++)
		{
			if (0 != cx_strcmp(sbt_LPLN__z[i].c_str(), pObject->sbt_LPLN__z[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_apY.size() != pObject->sbt_apY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_apY.size(); i++)
		{
			if (sbt_apY[i] != pObject->sbt_apY[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_QIiMmNV8k1VvuoijvtFkcJHSJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qrk5cSHFNLZM4nVbjCJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qrk5cSHFNLZM4nVbjCJ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JxcKynd9aUiefCSHSWYPzSZ1h")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JxcKynd9aUiefCSHSWYPzSZ1h.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QK6ZPu1SDjxK50g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QK6ZPu1SDjxK50g.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eYFyxd0GDRRflq_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eYFyxd0GDRRflq_.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mjoHce_x4BQhvOX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mjoHce_x4BQhvOX = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rYeWTxbS1_KxQ40b_D2fmYR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rYeWTxbS1_KxQ40b_D2fmYR = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LPLN__z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LPLN__z.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_apY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_apY.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ", (CX::Int64)sbt_tg8RGzjSM34pfKHTZr0jNP3WCnZ7fyL7zmJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.begin(); iter != sbt_Xm0nom4IIJfDx_yuyuZo7DXnxCGnm1p08v3uf00o3dO7zYUYJWTqPpZq79YrSCK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6", (CX::Int64)sbt_wMjJgcfpgGBvG4HJ0cc8EIyx6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QIiMmNV8k1VvuoijvtFkcJHSJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.begin(); iter != sbt_QIiMmNV8k1VvuoijvtFkcJHSJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qrk5cSHFNLZM4nVbjCJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_qrk5cSHFNLZM4nVbjCJ.begin(); iter != sbt_qrk5cSHFNLZM4nVbjCJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JxcKynd9aUiefCSHSWYPzSZ1h")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_JxcKynd9aUiefCSHSWYPzSZ1h.begin(); iter != sbt_JxcKynd9aUiefCSHSWYPzSZ1h.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.begin(); iter != sbt_0OXL8_JGPMYPfwcoUxfdH9aWrXNa5JoChsEjBO_z2WhGZrg4q2fkNJs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.begin(); iter != sbt_6wtBmhnNUXPiz6TNx2WCBUR5EDXwPRiSR6U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QK6ZPu1SDjxK50g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QK6ZPu1SDjxK50g.begin(); iter != sbt_QK6ZPu1SDjxK50g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eYFyxd0GDRRflq_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_eYFyxd0GDRRflq_.begin(); iter != sbt_eYFyxd0GDRRflq_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mjoHce_x4BQhvOX", (CX::Int64)sbt_mjoHce_x4BQhvOX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7", (CX::Int64)sbt_fOed7Bu_ufxPRaL0pRpkwzpMdwULbZ41HN1p7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rYeWTxbS1_KxQ40b_D2fmYR", (CX::Int64)sbt_rYeWTxbS1_KxQ40b_D2fmYR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.begin(); iter != sbt_hKSbcnV6KhyiGgHR_Ng9rZShFLvmQuLHyIOS9Gz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH", (CX::Int64)sbt_IzZKN6vIAJ7ArnMmbFSwqaj_uaH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LPLN__z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_LPLN__z.begin(); iter != sbt_LPLN__z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_apY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_apY.begin(); iter != sbt_apY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_N_n0Grp5_2dTTTlFuVjOezBdT>::Type sbt_N_n0Grp5_2dTTTlFuVjOezBdTArray;

