
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js.hpp"


class sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js sbt_RJ8UVLIsGYlhLDh6BRNr9ig;

	virtual void Reset()
	{
		sbt_RJ8UVLIsGYlhLDh6BRNr9ig.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_RJ8UVLIsGYlhLDh6BRNr9ig.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf *pObject = dynamic_cast<const sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (!sbt_RJ8UVLIsGYlhLDh6BRNr9ig.Compare(&pObject->sbt_RJ8UVLIsGYlhLDh6BRNr9ig))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectObject("sbt_RJ8UVLIsGYlhLDh6BRNr9ig")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_RJ8UVLIsGYlhLDh6BRNr9ig.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectObject("sbt_RJ8UVLIsGYlhLDh6BRNr9ig")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_RJ8UVLIsGYlhLDh6BRNr9ig.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf>::Type sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytfArray;

