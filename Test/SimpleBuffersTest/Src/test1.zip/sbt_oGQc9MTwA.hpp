
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_oGQc9MTwA : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA;
	CX::String sbt_ut9JuJakNtWc1XcbH8e;
	CX::UInt32 sbt_dG3RN5cwN9Fk4jeWmZ7;
	CX::IO::SimpleBuffers::StringArray sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5;
	CX::UInt64 sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h;
	CX::IO::SimpleBuffers::UInt64Array sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD;
	CX::UInt32 sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN;
	CX::IO::SimpleBuffers::BoolArray sbt_W7_S6OZSxP27c4tNp;
	CX::IO::SimpleBuffers::BoolArray sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X;
	CX::Int32 sbt_ljyDK9nz38rpkSSOgNc8g;
	CX::IO::SimpleBuffers::UInt16Array sbt_G;
	CX::IO::SimpleBuffers::Int8Array sbt_h7T;
	CX::IO::SimpleBuffers::UInt8Array sbt_5;
	CX::IO::SimpleBuffers::UInt8Array sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6;
	CX::UInt32 sbt_OlKAOvAZkAJRhyh4lsX;
	CX::Int8 sbt_1UwG3JD59r7WkcI0Vdr_x7F;
	CX::IO::SimpleBuffers::Int64Array sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1;
	CX::IO::SimpleBuffers::UInt64Array sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl;
	CX::Int64 sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D;
	CX::IO::SimpleBuffers::UInt32Array sbt_UnvjFjY5SwYtVXw92xz25hr;
	CX::IO::SimpleBuffers::UInt64Array sbt_zkP5aO0XiUglrdNQlodtUwSNb;
	CX::UInt32 sbt_n1gHmtXeD;
	CX::IO::SimpleBuffers::Int16Array sbt_myaKKB_Eq4P0PQa;
	CX::UInt64 sbt_cyhCL3H;
	CX::UInt32 sbt_hUnv4RApM;
	CX::String sbt__o0cel5vNSfrP5dmb;
	CX::IO::SimpleBuffers::StringArray sbt_t8U1O;
	CX::UInt32 sbt_dUkJXdzbYVFMc07_fN0R75N;
	CX::Int32 sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN;

	virtual void Reset()
	{
		sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.clear();
		sbt_ut9JuJakNtWc1XcbH8e.clear();
		sbt_dG3RN5cwN9Fk4jeWmZ7 = 0;
		sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.clear();
		sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h = 0;
		sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.clear();
		sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN = 0;
		sbt_W7_S6OZSxP27c4tNp.clear();
		sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.clear();
		sbt_ljyDK9nz38rpkSSOgNc8g = 0;
		sbt_G.clear();
		sbt_h7T.clear();
		sbt_5.clear();
		sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.clear();
		sbt_OlKAOvAZkAJRhyh4lsX = 0;
		sbt_1UwG3JD59r7WkcI0Vdr_x7F = 0;
		sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.clear();
		sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.clear();
		sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D = 0;
		sbt_UnvjFjY5SwYtVXw92xz25hr.clear();
		sbt_zkP5aO0XiUglrdNQlodtUwSNb.clear();
		sbt_n1gHmtXeD = 0;
		sbt_myaKKB_Eq4P0PQa.clear();
		sbt_cyhCL3H = 0;
		sbt_hUnv4RApM = 0;
		sbt__o0cel5vNSfrP5dmb.clear();
		sbt_t8U1O.clear();
		sbt_dUkJXdzbYVFMc07_fN0R75N = 0;
		sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.push_back(2405186990971475454);
		}
		sbt_ut9JuJakNtWc1XcbH8e = "?sVq@NH-r:Z";
		sbt_dG3RN5cwN9Fk4jeWmZ7 = 3784774827;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.push_back("4-,_\\;s7oja<,@P4Pu:Ifee1U($4zfu_2&I-;;O0OolN~uYF\\f^Tll+");
		}
		sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h = 16834585668057171414;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.push_back(18278022688513553654);
		}
		sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN = 1308336553;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_W7_S6OZSxP27c4tNp.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.push_back(false);
		}
		sbt_ljyDK9nz38rpkSSOgNc8g = -254276110;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_G.push_back(58748);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.push_back(230);
		}
		sbt_OlKAOvAZkAJRhyh4lsX = 609021919;
		sbt_1UwG3JD59r7WkcI0Vdr_x7F = -84;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.push_back(-8000309197887649226);
		}
		sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D = 5634637634699034858;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_UnvjFjY5SwYtVXw92xz25hr.push_back(1817732291);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_zkP5aO0XiUglrdNQlodtUwSNb.push_back(2615395021324302500);
		}
		sbt_n1gHmtXeD = 2091632535;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_myaKKB_Eq4P0PQa.push_back(-1499);
		}
		sbt_cyhCL3H = 14696829237637056706;
		sbt_hUnv4RApM = 1155969115;
		sbt__o0cel5vNSfrP5dmb = "i`?-MzI4i3C8.D8ZvO[Z7e";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_t8U1O.push_back("7A_PZZo]lX&N%A7,K^zCg/Xm2CpW:e2{KJ=k/;h^");
		}
		sbt_dUkJXdzbYVFMc07_fN0R75N = 258071052;
		sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN = 1910367317;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_oGQc9MTwA *pObject = dynamic_cast<const sbt_oGQc9MTwA *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.size() != pObject->sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.size(); i++)
		{
			if (sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA[i] != pObject->sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_ut9JuJakNtWc1XcbH8e.c_str(), pObject->sbt_ut9JuJakNtWc1XcbH8e.c_str()))
		{
			return false;
		}
		if (sbt_dG3RN5cwN9Fk4jeWmZ7 != pObject->sbt_dG3RN5cwN9Fk4jeWmZ7)
		{
			return false;
		}
		if (sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.size() != pObject->sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.size(); i++)
		{
			if (0 != cx_strcmp(sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5[i].c_str(), pObject->sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h != pObject->sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h)
		{
			return false;
		}
		if (sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.size() != pObject->sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.size(); i++)
		{
			if (sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD[i] != pObject->sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD[i])
			{
				return false;
			}
		}
		if (sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN != pObject->sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN)
		{
			return false;
		}
		if (sbt_W7_S6OZSxP27c4tNp.size() != pObject->sbt_W7_S6OZSxP27c4tNp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W7_S6OZSxP27c4tNp.size(); i++)
		{
			if (sbt_W7_S6OZSxP27c4tNp[i] != pObject->sbt_W7_S6OZSxP27c4tNp[i])
			{
				return false;
			}
		}
		if (sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.size() != pObject->sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.size(); i++)
		{
			if (sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X[i] != pObject->sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X[i])
			{
				return false;
			}
		}
		if (sbt_ljyDK9nz38rpkSSOgNc8g != pObject->sbt_ljyDK9nz38rpkSSOgNc8g)
		{
			return false;
		}
		if (sbt_G.size() != pObject->sbt_G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_G.size(); i++)
		{
			if (sbt_G[i] != pObject->sbt_G[i])
			{
				return false;
			}
		}
		if (sbt_h7T.size() != pObject->sbt_h7T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h7T.size(); i++)
		{
			if (sbt_h7T[i] != pObject->sbt_h7T[i])
			{
				return false;
			}
		}
		if (sbt_5.size() != pObject->sbt_5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5.size(); i++)
		{
			if (sbt_5[i] != pObject->sbt_5[i])
			{
				return false;
			}
		}
		if (sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.size() != pObject->sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.size(); i++)
		{
			if (sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6[i] != pObject->sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6[i])
			{
				return false;
			}
		}
		if (sbt_OlKAOvAZkAJRhyh4lsX != pObject->sbt_OlKAOvAZkAJRhyh4lsX)
		{
			return false;
		}
		if (sbt_1UwG3JD59r7WkcI0Vdr_x7F != pObject->sbt_1UwG3JD59r7WkcI0Vdr_x7F)
		{
			return false;
		}
		if (sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.size() != pObject->sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.size(); i++)
		{
			if (sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1[i] != pObject->sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1[i])
			{
				return false;
			}
		}
		if (sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.size() != pObject->sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.size(); i++)
		{
			if (sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl[i] != pObject->sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl[i])
			{
				return false;
			}
		}
		if (sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D != pObject->sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D)
		{
			return false;
		}
		if (sbt_UnvjFjY5SwYtVXw92xz25hr.size() != pObject->sbt_UnvjFjY5SwYtVXw92xz25hr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UnvjFjY5SwYtVXw92xz25hr.size(); i++)
		{
			if (sbt_UnvjFjY5SwYtVXw92xz25hr[i] != pObject->sbt_UnvjFjY5SwYtVXw92xz25hr[i])
			{
				return false;
			}
		}
		if (sbt_zkP5aO0XiUglrdNQlodtUwSNb.size() != pObject->sbt_zkP5aO0XiUglrdNQlodtUwSNb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zkP5aO0XiUglrdNQlodtUwSNb.size(); i++)
		{
			if (sbt_zkP5aO0XiUglrdNQlodtUwSNb[i] != pObject->sbt_zkP5aO0XiUglrdNQlodtUwSNb[i])
			{
				return false;
			}
		}
		if (sbt_n1gHmtXeD != pObject->sbt_n1gHmtXeD)
		{
			return false;
		}
		if (sbt_myaKKB_Eq4P0PQa.size() != pObject->sbt_myaKKB_Eq4P0PQa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_myaKKB_Eq4P0PQa.size(); i++)
		{
			if (sbt_myaKKB_Eq4P0PQa[i] != pObject->sbt_myaKKB_Eq4P0PQa[i])
			{
				return false;
			}
		}
		if (sbt_cyhCL3H != pObject->sbt_cyhCL3H)
		{
			return false;
		}
		if (sbt_hUnv4RApM != pObject->sbt_hUnv4RApM)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt__o0cel5vNSfrP5dmb.c_str(), pObject->sbt__o0cel5vNSfrP5dmb.c_str()))
		{
			return false;
		}
		if (sbt_t8U1O.size() != pObject->sbt_t8U1O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t8U1O.size(); i++)
		{
			if (0 != cx_strcmp(sbt_t8U1O[i].c_str(), pObject->sbt_t8U1O[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_dUkJXdzbYVFMc07_fN0R75N != pObject->sbt_dUkJXdzbYVFMc07_fN0R75N)
		{
			return false;
		}
		if (sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN != pObject->sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_ut9JuJakNtWc1XcbH8e", &sbt_ut9JuJakNtWc1XcbH8e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dG3RN5cwN9Fk4jeWmZ7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dG3RN5cwN9Fk4jeWmZ7 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_W7_S6OZSxP27c4tNp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W7_S6OZSxP27c4tNp.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ljyDK9nz38rpkSSOgNc8g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ljyDK9nz38rpkSSOgNc8g = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_G.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h7T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h7T.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OlKAOvAZkAJRhyh4lsX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OlKAOvAZkAJRhyh4lsX = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1UwG3JD59r7WkcI0Vdr_x7F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1UwG3JD59r7WkcI0Vdr_x7F = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UnvjFjY5SwYtVXw92xz25hr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UnvjFjY5SwYtVXw92xz25hr.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zkP5aO0XiUglrdNQlodtUwSNb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zkP5aO0XiUglrdNQlodtUwSNb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n1gHmtXeD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n1gHmtXeD = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_myaKKB_Eq4P0PQa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_myaKKB_Eq4P0PQa.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cyhCL3H", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cyhCL3H = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hUnv4RApM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hUnv4RApM = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt__o0cel5vNSfrP5dmb", &sbt__o0cel5vNSfrP5dmb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_t8U1O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t8U1O.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dUkJXdzbYVFMc07_fN0R75N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dUkJXdzbYVFMc07_fN0R75N = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.begin(); iter != sbt_ph7mJdFWgY4bT3_doXaeX1KZeWcsSFkvQhs4ooryMjftbKA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ut9JuJakNtWc1XcbH8e", sbt_ut9JuJakNtWc1XcbH8e.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dG3RN5cwN9Fk4jeWmZ7", (CX::Int64)sbt_dG3RN5cwN9Fk4jeWmZ7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.begin(); iter != sbt_FLCHI6Z9nYyz5ONwJ6Y7nVnfdxCtAqeUBMiZJkZdgZhEIaW9Zca5EK5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h", (CX::Int64)sbt_nJ3cA4YEBSmKaJktfwxDYBOVdQq5IXA1EOklLRGF2RG_KdsWdjZkb1tRBX0505h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.begin(); iter != sbt_fNuE0UVfCOuQ9Eu68PorQuTGTw6yZSrcw4RXKoJJERvyGJtJBTD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN", (CX::Int64)sbt_GYEwN6KtQ3FIRSHt06XEr93APkhzxVnEaOSmG62SnSWIlWRCfxNlN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W7_S6OZSxP27c4tNp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_W7_S6OZSxP27c4tNp.begin(); iter != sbt_W7_S6OZSxP27c4tNp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.begin(); iter != sbt_CuIJJ6e6Xyj5ABX8_vkIh9e9wLOyB3Ina4kHSWRCoI9uJxnLD9oDAxWl22X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ljyDK9nz38rpkSSOgNc8g", (CX::Int64)sbt_ljyDK9nz38rpkSSOgNc8g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_G.begin(); iter != sbt_G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h7T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_h7T.begin(); iter != sbt_h7T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_5.begin(); iter != sbt_5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.begin(); iter != sbt_RC226KjN8twu_RKECHKLODe7uK5pB_rBDwmZt6aq76VkBhqd6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OlKAOvAZkAJRhyh4lsX", (CX::Int64)sbt_OlKAOvAZkAJRhyh4lsX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1UwG3JD59r7WkcI0Vdr_x7F", (CX::Int64)sbt_1UwG3JD59r7WkcI0Vdr_x7F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.begin(); iter != sbt_9dJN56ZezCauRBkFkiQwN_nAbNK0OGAaARYfYpPz81RwG9pkoFE1Lg1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.begin(); iter != sbt_N9OSRo5PTbix56FtJMgqsLPs7lPOAqExeYF59Fl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D", (CX::Int64)sbt_y99oCKIrUITvwkO_vJ0SV0UJsmrf056qq4Y5h_D)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UnvjFjY5SwYtVXw92xz25hr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_UnvjFjY5SwYtVXw92xz25hr.begin(); iter != sbt_UnvjFjY5SwYtVXw92xz25hr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zkP5aO0XiUglrdNQlodtUwSNb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_zkP5aO0XiUglrdNQlodtUwSNb.begin(); iter != sbt_zkP5aO0XiUglrdNQlodtUwSNb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n1gHmtXeD", (CX::Int64)sbt_n1gHmtXeD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_myaKKB_Eq4P0PQa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_myaKKB_Eq4P0PQa.begin(); iter != sbt_myaKKB_Eq4P0PQa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cyhCL3H", (CX::Int64)sbt_cyhCL3H)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hUnv4RApM", (CX::Int64)sbt_hUnv4RApM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt__o0cel5vNSfrP5dmb", sbt__o0cel5vNSfrP5dmb.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t8U1O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_t8U1O.begin(); iter != sbt_t8U1O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dUkJXdzbYVFMc07_fN0R75N", (CX::Int64)sbt_dUkJXdzbYVFMc07_fN0R75N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN", (CX::Int64)sbt_YAAYhMrxh3EgLo2YV0X3inQBFQCQZwPq8GN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_oGQc9MTwA>::Type sbt_oGQc9MTwAArray;

