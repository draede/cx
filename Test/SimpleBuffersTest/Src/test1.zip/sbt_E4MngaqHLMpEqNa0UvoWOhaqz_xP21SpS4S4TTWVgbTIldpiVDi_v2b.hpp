
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_x4z6ig2yC79RxLGj0l0IS;
	CX::IO::SimpleBuffers::BoolArray sbt_p;
	CX::IO::SimpleBuffers::StringArray sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm;
	CX::UInt16 sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh;
	CX::IO::SimpleBuffers::Int64Array sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX;
	CX::IO::SimpleBuffers::UInt32Array sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz;
	CX::UInt16 sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0;
	CX::Int8 sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK;
	CX::IO::SimpleBuffers::Int64Array sbt_bvnYsRK;
	CX::IO::SimpleBuffers::UInt64Array sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D;
	CX::IO::SimpleBuffers::UInt32Array sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi;
	CX::Int8 sbt_5;
	CX::UInt32 sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV;
	CX::IO::SimpleBuffers::Int64Array sbt_r;
	CX::IO::SimpleBuffers::Int16Array sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF;
	CX::IO::SimpleBuffers::BoolArray sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO;
	CX::UInt32 sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3;
	CX::Int16 sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V;
	CX::UInt64 sbt_Ds0;
	CX::String sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg;
	CX::IO::SimpleBuffers::StringArray sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO;
	CX::UInt16 sbt_k;

	virtual void Reset()
	{
		sbt_x4z6ig2yC79RxLGj0l0IS.clear();
		sbt_p.clear();
		sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.clear();
		sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh = 0;
		sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.clear();
		sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.clear();
		sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0 = 0;
		sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK = 0;
		sbt_bvnYsRK.clear();
		sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.clear();
		sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.clear();
		sbt_5 = 0;
		sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV = 0;
		sbt_r.clear();
		sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.clear();
		sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.clear();
		sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3 = 0;
		sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V = 0;
		sbt_Ds0 = 0;
		sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg.clear();
		sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.clear();
		sbt_k = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_x4z6ig2yC79RxLGj0l0IS.push_back(20474);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_p.push_back(false);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.push_back("02]^y1i");
		}
		sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh = 45683;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.push_back(-2499291334239372682);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.push_back(2877012803);
		}
		sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0 = 29948;
		sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK = 11;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_bvnYsRK.push_back(3063629810844121624);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.push_back(16584649579058797178);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.push_back(1207615861);
		}
		sbt_5 = -43;
		sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV = 3758727437;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_r.push_back(1329454986301333862);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.push_back(25193);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.push_back(true);
		}
		sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3 = 1351723235;
		sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V = 27317;
		sbt_Ds0 = 5657011825780298206;
		sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg = "(8.{";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.push_back("8F,\\c#mp^.DW4P*t{3uQYV>+ak>J;$??Q05vvKupT@/u-lM2:+,T\\q+B?$:tH");
		}
		sbt_k = 32249;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b *pObject = dynamic_cast<const sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_x4z6ig2yC79RxLGj0l0IS.size() != pObject->sbt_x4z6ig2yC79RxLGj0l0IS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x4z6ig2yC79RxLGj0l0IS.size(); i++)
		{
			if (sbt_x4z6ig2yC79RxLGj0l0IS[i] != pObject->sbt_x4z6ig2yC79RxLGj0l0IS[i])
			{
				return false;
			}
		}
		if (sbt_p.size() != pObject->sbt_p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p.size(); i++)
		{
			if (sbt_p[i] != pObject->sbt_p[i])
			{
				return false;
			}
		}
		if (sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.size() != pObject->sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.size(); i++)
		{
			if (0 != cx_strcmp(sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm[i].c_str(), pObject->sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh != pObject->sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh)
		{
			return false;
		}
		if (sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.size() != pObject->sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.size(); i++)
		{
			if (sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX[i] != pObject->sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX[i])
			{
				return false;
			}
		}
		if (sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.size() != pObject->sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.size(); i++)
		{
			if (sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz[i] != pObject->sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz[i])
			{
				return false;
			}
		}
		if (sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0 != pObject->sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0)
		{
			return false;
		}
		if (sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK != pObject->sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK)
		{
			return false;
		}
		if (sbt_bvnYsRK.size() != pObject->sbt_bvnYsRK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bvnYsRK.size(); i++)
		{
			if (sbt_bvnYsRK[i] != pObject->sbt_bvnYsRK[i])
			{
				return false;
			}
		}
		if (sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.size() != pObject->sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.size(); i++)
		{
			if (sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D[i] != pObject->sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D[i])
			{
				return false;
			}
		}
		if (sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.size() != pObject->sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.size(); i++)
		{
			if (sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi[i] != pObject->sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi[i])
			{
				return false;
			}
		}
		if (sbt_5 != pObject->sbt_5)
		{
			return false;
		}
		if (sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV != pObject->sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV)
		{
			return false;
		}
		if (sbt_r.size() != pObject->sbt_r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r.size(); i++)
		{
			if (sbt_r[i] != pObject->sbt_r[i])
			{
				return false;
			}
		}
		if (sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.size() != pObject->sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.size(); i++)
		{
			if (sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF[i] != pObject->sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF[i])
			{
				return false;
			}
		}
		if (sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.size() != pObject->sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.size(); i++)
		{
			if (sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO[i] != pObject->sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO[i])
			{
				return false;
			}
		}
		if (sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3 != pObject->sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3)
		{
			return false;
		}
		if (sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V != pObject->sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V)
		{
			return false;
		}
		if (sbt_Ds0 != pObject->sbt_Ds0)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg.c_str(), pObject->sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg.c_str()))
		{
			return false;
		}
		if (sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.size() != pObject->sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.size(); i++)
		{
			if (0 != cx_strcmp(sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO[i].c_str(), pObject->sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_k != pObject->sbt_k)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_x4z6ig2yC79RxLGj0l0IS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x4z6ig2yC79RxLGj0l0IS.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bvnYsRK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bvnYsRK.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Ds0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ds0 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg", &sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_x4z6ig2yC79RxLGj0l0IS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_x4z6ig2yC79RxLGj0l0IS.begin(); iter != sbt_x4z6ig2yC79RxLGj0l0IS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_p.begin(); iter != sbt_p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.begin(); iter != sbt_JFekDMhupvAR72q0nm0Wj5cn_TcWpobXicm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh", (CX::Int64)sbt_OOW91opiSeWpwl0DS0U4NjYb7JBjZA3xcM13OCh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.begin(); iter != sbt_EMlUsO_3UtKilBUP4Ii6wSRriErQgN2FOVpoLMAzU3Fvgz6LWle64zNfybX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.begin(); iter != sbt_gq2dZQ6X5FcSVnr4WEJv4i7RTdxmwxz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0", (CX::Int64)sbt_sDX0YsMztxvJqjXzWK741Qb4D8ry7ETmtyFjJ4uXPUBF0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK", (CX::Int64)sbt_0IslD5zO6dZIjiiiHvEnFo0iFXKSwdNZK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bvnYsRK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_bvnYsRK.begin(); iter != sbt_bvnYsRK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.begin(); iter != sbt_FxH1d9E8aUzOAR0asDNAcEoYngot74dQ66D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.begin(); iter != sbt_Ubk40IBLTLqFYbIJpoWbCOVIdcXrZNhXnVi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5", (CX::Int64)sbt_5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV", (CX::Int64)sbt_P8Xi3T9begSE95ttlcxTea1PwOxmiTrlwHFfV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_r.begin(); iter != sbt_r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.begin(); iter != sbt_A38fyCl4wAENBgDxA9WTHlYyThJUa5IUD1ovM5kCveeXF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.begin(); iter != sbt_H3g5dvsyZxuZW69PgzVPMHkPGYDEBiSk1j4xxmyF9D9KL7I2aOkmxVF5L6HJO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3", (CX::Int64)sbt_mV7ojmmrxAIr6YpAbNyCNgxRVOToI2u8ImYmoe3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V", (CX::Int64)sbt_7r8meES3UI26DEm1PXhkxztTsWORjTh_xHvB1QNNIy_qnEzjk8V)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ds0", (CX::Int64)sbt_Ds0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg", sbt_Tb5OeM0v3p_Zjrbcaxx_mxFHg.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.begin(); iter != sbt_5k8Ekw5XOOovOpE7rNVnSyh183bxDJRAzsXprkm5lN7qrrO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k", (CX::Int64)sbt_k)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b>::Type sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2bArray;

