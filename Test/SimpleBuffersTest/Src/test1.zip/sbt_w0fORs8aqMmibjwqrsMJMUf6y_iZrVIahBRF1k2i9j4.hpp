
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i;
	CX::UInt64 sbt_NtDldYnPG3kMUmX6Qq1tCzk;
	CX::IO::SimpleBuffers::Int8Array sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU;
	CX::IO::SimpleBuffers::Int32Array sbt_NJfndLRTdc3DlsQHWz1YDAxvH;
	CX::IO::SimpleBuffers::Int64Array sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj;
	CX::UInt64 sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4;
	CX::Int8 sbt_qpJ8VAwYd2_YJ;
	CX::IO::SimpleBuffers::UInt32Array sbt_FIMbywmCnYsvvsjcvn0;
	CX::IO::SimpleBuffers::Int64Array sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG;
	CX::IO::SimpleBuffers::Int8Array sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0;
	CX::IO::SimpleBuffers::BoolArray sbt_L9G;
	CX::UInt8 sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4;
	CX::IO::SimpleBuffers::Int16Array sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9;
	CX::IO::SimpleBuffers::Int16Array sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe;
	CX::UInt32 sbt_uXNDrwOvy;
	CX::IO::SimpleBuffers::Int8Array sbt_KZCzlV5bA5BR7P5Ggb9;
	CX::Bool sbt_rWGzofsdRgClaH1JzDVersjVs;
	CX::String sbt_ch7kZ;
	CX::UInt64 sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i;
	CX::IO::SimpleBuffers::UInt8Array sbt_wEHWdj8R0v09_0WczQkUW;
	CX::IO::SimpleBuffers::Int8Array sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L;
	CX::IO::SimpleBuffers::UInt32Array sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394;
	CX::UInt32 sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT;
	CX::IO::SimpleBuffers::UInt32Array sbt_MKrVKbXnbvB05qqoc;

	virtual void Reset()
	{
		sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i = 0;
		sbt_NtDldYnPG3kMUmX6Qq1tCzk = 0;
		sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.clear();
		sbt_NJfndLRTdc3DlsQHWz1YDAxvH.clear();
		sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.clear();
		sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4 = 0;
		sbt_qpJ8VAwYd2_YJ = 0;
		sbt_FIMbywmCnYsvvsjcvn0.clear();
		sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.clear();
		sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.clear();
		sbt_L9G.clear();
		sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4 = 0;
		sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.clear();
		sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.clear();
		sbt_uXNDrwOvy = 0;
		sbt_KZCzlV5bA5BR7P5Ggb9.clear();
		sbt_rWGzofsdRgClaH1JzDVersjVs = false;
		sbt_ch7kZ.clear();
		sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i = 0;
		sbt_wEHWdj8R0v09_0WczQkUW.clear();
		sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.clear();
		sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.clear();
		sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT = 0;
		sbt_MKrVKbXnbvB05qqoc.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i = 48435;
		sbt_NtDldYnPG3kMUmX6Qq1tCzk = 9718942094265635592;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.push_back(-118);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_NJfndLRTdc3DlsQHWz1YDAxvH.push_back(-2003604009);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.push_back(2387328659698910188);
		}
		sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4 = 13096374506629785868;
		sbt_qpJ8VAwYd2_YJ = 97;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_FIMbywmCnYsvvsjcvn0.push_back(1477874726);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.push_back(-7178129704187383142);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.push_back(51);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_L9G.push_back(false);
		}
		sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4 = 147;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.push_back(-4099);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.push_back(18753);
		}
		sbt_uXNDrwOvy = 3351172109;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_KZCzlV5bA5BR7P5Ggb9.push_back(-113);
		}
		sbt_rWGzofsdRgClaH1JzDVersjVs = false;
		sbt_ch7kZ = "7Gv0S~_EO6Ny+G}#op8|b$[_'HS1";
		sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i = 10122771114497893660;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_wEHWdj8R0v09_0WczQkUW.push_back(140);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.push_back(76);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.push_back(670332331);
		}
		sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT = 3279227766;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4 *pObject = dynamic_cast<const sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i != pObject->sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i)
		{
			return false;
		}
		if (sbt_NtDldYnPG3kMUmX6Qq1tCzk != pObject->sbt_NtDldYnPG3kMUmX6Qq1tCzk)
		{
			return false;
		}
		if (sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.size() != pObject->sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.size(); i++)
		{
			if (sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU[i] != pObject->sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU[i])
			{
				return false;
			}
		}
		if (sbt_NJfndLRTdc3DlsQHWz1YDAxvH.size() != pObject->sbt_NJfndLRTdc3DlsQHWz1YDAxvH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NJfndLRTdc3DlsQHWz1YDAxvH.size(); i++)
		{
			if (sbt_NJfndLRTdc3DlsQHWz1YDAxvH[i] != pObject->sbt_NJfndLRTdc3DlsQHWz1YDAxvH[i])
			{
				return false;
			}
		}
		if (sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.size() != pObject->sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.size(); i++)
		{
			if (sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj[i] != pObject->sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj[i])
			{
				return false;
			}
		}
		if (sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4 != pObject->sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4)
		{
			return false;
		}
		if (sbt_qpJ8VAwYd2_YJ != pObject->sbt_qpJ8VAwYd2_YJ)
		{
			return false;
		}
		if (sbt_FIMbywmCnYsvvsjcvn0.size() != pObject->sbt_FIMbywmCnYsvvsjcvn0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FIMbywmCnYsvvsjcvn0.size(); i++)
		{
			if (sbt_FIMbywmCnYsvvsjcvn0[i] != pObject->sbt_FIMbywmCnYsvvsjcvn0[i])
			{
				return false;
			}
		}
		if (sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.size() != pObject->sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.size(); i++)
		{
			if (sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG[i] != pObject->sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG[i])
			{
				return false;
			}
		}
		if (sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.size() != pObject->sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.size(); i++)
		{
			if (sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0[i] != pObject->sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0[i])
			{
				return false;
			}
		}
		if (sbt_L9G.size() != pObject->sbt_L9G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L9G.size(); i++)
		{
			if (sbt_L9G[i] != pObject->sbt_L9G[i])
			{
				return false;
			}
		}
		if (sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4 != pObject->sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4)
		{
			return false;
		}
		if (sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.size() != pObject->sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.size(); i++)
		{
			if (sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9[i] != pObject->sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9[i])
			{
				return false;
			}
		}
		if (sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.size() != pObject->sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.size(); i++)
		{
			if (sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe[i] != pObject->sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe[i])
			{
				return false;
			}
		}
		if (sbt_uXNDrwOvy != pObject->sbt_uXNDrwOvy)
		{
			return false;
		}
		if (sbt_KZCzlV5bA5BR7P5Ggb9.size() != pObject->sbt_KZCzlV5bA5BR7P5Ggb9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KZCzlV5bA5BR7P5Ggb9.size(); i++)
		{
			if (sbt_KZCzlV5bA5BR7P5Ggb9[i] != pObject->sbt_KZCzlV5bA5BR7P5Ggb9[i])
			{
				return false;
			}
		}
		if (sbt_rWGzofsdRgClaH1JzDVersjVs != pObject->sbt_rWGzofsdRgClaH1JzDVersjVs)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_ch7kZ.c_str(), pObject->sbt_ch7kZ.c_str()))
		{
			return false;
		}
		if (sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i != pObject->sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i)
		{
			return false;
		}
		if (sbt_wEHWdj8R0v09_0WczQkUW.size() != pObject->sbt_wEHWdj8R0v09_0WczQkUW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wEHWdj8R0v09_0WczQkUW.size(); i++)
		{
			if (sbt_wEHWdj8R0v09_0WczQkUW[i] != pObject->sbt_wEHWdj8R0v09_0WczQkUW[i])
			{
				return false;
			}
		}
		if (sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.size() != pObject->sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.size(); i++)
		{
			if (sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L[i] != pObject->sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L[i])
			{
				return false;
			}
		}
		if (sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.size() != pObject->sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.size(); i++)
		{
			if (sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394[i] != pObject->sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394[i])
			{
				return false;
			}
		}
		if (sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT != pObject->sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT)
		{
			return false;
		}
		if (sbt_MKrVKbXnbvB05qqoc.size() != pObject->sbt_MKrVKbXnbvB05qqoc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MKrVKbXnbvB05qqoc.size(); i++)
		{
			if (sbt_MKrVKbXnbvB05qqoc[i] != pObject->sbt_MKrVKbXnbvB05qqoc[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NtDldYnPG3kMUmX6Qq1tCzk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NtDldYnPG3kMUmX6Qq1tCzk = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NJfndLRTdc3DlsQHWz1YDAxvH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NJfndLRTdc3DlsQHWz1YDAxvH.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qpJ8VAwYd2_YJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qpJ8VAwYd2_YJ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FIMbywmCnYsvvsjcvn0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FIMbywmCnYsvvsjcvn0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L9G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L9G.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_uXNDrwOvy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uXNDrwOvy = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KZCzlV5bA5BR7P5Ggb9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KZCzlV5bA5BR7P5Ggb9.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_rWGzofsdRgClaH1JzDVersjVs", &sbt_rWGzofsdRgClaH1JzDVersjVs)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_ch7kZ", &sbt_ch7kZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wEHWdj8R0v09_0WczQkUW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wEHWdj8R0v09_0WczQkUW.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MKrVKbXnbvB05qqoc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MKrVKbXnbvB05qqoc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i", (CX::Int64)sbt_r9WVh7w68bxYWCgo_NZ4SSdexFnoy0i)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NtDldYnPG3kMUmX6Qq1tCzk", (CX::Int64)sbt_NtDldYnPG3kMUmX6Qq1tCzk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.begin(); iter != sbt_Dw7L4MZV8_VfmZGuhYCWEuuwBhFfXfKmBlRmr0gkeX6JnCrmU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NJfndLRTdc3DlsQHWz1YDAxvH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_NJfndLRTdc3DlsQHWz1YDAxvH.begin(); iter != sbt_NJfndLRTdc3DlsQHWz1YDAxvH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.begin(); iter != sbt_RvdLgJAAZwDQZsOVAgmWiqL9AB5ZCVHkgbjAKEj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4", (CX::Int64)sbt_9DLtuIyv3uDJuvw2vYGdkc1lWJvC6seYGDOBfk6HEESaSRJxsMj6DK4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qpJ8VAwYd2_YJ", (CX::Int64)sbt_qpJ8VAwYd2_YJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FIMbywmCnYsvvsjcvn0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FIMbywmCnYsvvsjcvn0.begin(); iter != sbt_FIMbywmCnYsvvsjcvn0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.begin(); iter != sbt_3q3vaj8cz6WdjNPho_QoMC0zcFzwxK0OG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.begin(); iter != sbt_3ZrUBjTPMBfbA_FQM7ciAor0Bm6JEtStLWDP0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L9G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_L9G.begin(); iter != sbt_L9G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4", (CX::Int64)sbt_TY1GiT2tvwV_ezr212dmgKtP662ZGhjgFh1h8hjlJmFjVDF1LJ3OGm4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.begin(); iter != sbt_hHJiZXLU5e68uiT9Rc6hVmoBB3DGAetqz5Ox4KkUXJGEvazQNfooSusR9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.begin(); iter != sbt_jglhV4PI2CwzRVrZdokSA0W8aYr7s_mhtYexe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uXNDrwOvy", (CX::Int64)sbt_uXNDrwOvy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KZCzlV5bA5BR7P5Ggb9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_KZCzlV5bA5BR7P5Ggb9.begin(); iter != sbt_KZCzlV5bA5BR7P5Ggb9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_rWGzofsdRgClaH1JzDVersjVs", sbt_rWGzofsdRgClaH1JzDVersjVs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ch7kZ", sbt_ch7kZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i", (CX::Int64)sbt_qvY2glWoZa4pTElQ5ATUxRDbI1XFYxbuR6q_OtVvmLVl8RSVPgoAApZyR5i)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wEHWdj8R0v09_0WczQkUW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_wEHWdj8R0v09_0WczQkUW.begin(); iter != sbt_wEHWdj8R0v09_0WczQkUW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.begin(); iter != sbt_u7MmfNja536KJ0ZSyrbH45dPVCh9Uu3d9akGsZvEU4L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.begin(); iter != sbt_HxCO_coGWWUQ_lWOUOUrZOmXbd394.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT", (CX::Int64)sbt_R5sIJ_BuFTT1pzDTMXSYBIxHjVk2k2OI3akLOjRMXshOKLXaxi6b2wFcdinuT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MKrVKbXnbvB05qqoc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_MKrVKbXnbvB05qqoc.begin(); iter != sbt_MKrVKbXnbvB05qqoc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4>::Type sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4Array;

