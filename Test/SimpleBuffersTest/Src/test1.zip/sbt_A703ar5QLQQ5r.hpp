
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_s8Xk5_MtSOD.hpp"


class sbt_A703ar5QLQQ5r : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf;
	CX::IO::SimpleBuffers::BoolArray sbt_nmKwV81Whh7zid3Z5nEXbwU2V;
	sbt_s8Xk5_MtSODArray sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW;

	virtual void Reset()
	{
		sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf = 0;
		sbt_nmKwV81Whh7zid3Z5nEXbwU2V.clear();
		sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf = 1337641682;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_nmKwV81Whh7zid3Z5nEXbwU2V.push_back(false);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_A703ar5QLQQ5r *pObject = dynamic_cast<const sbt_A703ar5QLQQ5r *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf != pObject->sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf)
		{
			return false;
		}
		if (sbt_nmKwV81Whh7zid3Z5nEXbwU2V.size() != pObject->sbt_nmKwV81Whh7zid3Z5nEXbwU2V.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nmKwV81Whh7zid3Z5nEXbwU2V.size(); i++)
		{
			if (sbt_nmKwV81Whh7zid3Z5nEXbwU2V[i] != pObject->sbt_nmKwV81Whh7zid3Z5nEXbwU2V[i])
			{
				return false;
			}
		}
		if (sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.size() != pObject->sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.size(); i++)
		{
			if (!sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW[i].Compare(&pObject->sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_nmKwV81Whh7zid3Z5nEXbwU2V")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nmKwV81Whh7zid3Z5nEXbwU2V.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_s8Xk5_MtSOD tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf", (CX::Int64)sbt_84JvdIzueA81RZ6Rrsb8aDcTWP4y2GmaLfmmMDPCNAmFyDgvGHBKiYtmwHf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nmKwV81Whh7zid3Z5nEXbwU2V")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_nmKwV81Whh7zid3Z5nEXbwU2V.begin(); iter != sbt_nmKwV81Whh7zid3Z5nEXbwU2V.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW")).IsNOK())
		{
			return status;
		}
		for (sbt_s8Xk5_MtSODArray::const_iterator iter = sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.begin(); iter != sbt__y0Iwn42ophPB38711XYoqv9wXlqRHiiDmY8o7owNz1BMCspm7xSdvQ8EgWiTWW.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_A703ar5QLQQ5r>::Type sbt_A703ar5QLQQ5rArray;

