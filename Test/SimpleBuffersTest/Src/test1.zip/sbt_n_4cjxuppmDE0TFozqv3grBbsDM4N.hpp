
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80;
	CX::IO::SimpleBuffers::Int32Array sbt_QAjBtHkTt86_hpvdqSsLe;
	CX::IO::SimpleBuffers::Int64Array sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru;
	CX::Int64 sbt_t7ctkaphtoraGeewOml0jTX84clwMKu;

	virtual void Reset()
	{
		sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.clear();
		sbt_QAjBtHkTt86_hpvdqSsLe.clear();
		sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.clear();
		sbt_t7ctkaphtoraGeewOml0jTX84clwMKu = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.push_back(1511957030);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_QAjBtHkTt86_hpvdqSsLe.push_back(990477570);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.push_back(3703207543275532950);
		}
		sbt_t7ctkaphtoraGeewOml0jTX84clwMKu = -103068129934536474;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N *pObject = dynamic_cast<const sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.size() != pObject->sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.size(); i++)
		{
			if (sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80[i] != pObject->sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80[i])
			{
				return false;
			}
		}
		if (sbt_QAjBtHkTt86_hpvdqSsLe.size() != pObject->sbt_QAjBtHkTt86_hpvdqSsLe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QAjBtHkTt86_hpvdqSsLe.size(); i++)
		{
			if (sbt_QAjBtHkTt86_hpvdqSsLe[i] != pObject->sbt_QAjBtHkTt86_hpvdqSsLe[i])
			{
				return false;
			}
		}
		if (sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.size() != pObject->sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.size(); i++)
		{
			if (sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru[i] != pObject->sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru[i])
			{
				return false;
			}
		}
		if (sbt_t7ctkaphtoraGeewOml0jTX84clwMKu != pObject->sbt_t7ctkaphtoraGeewOml0jTX84clwMKu)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QAjBtHkTt86_hpvdqSsLe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QAjBtHkTt86_hpvdqSsLe.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t7ctkaphtoraGeewOml0jTX84clwMKu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t7ctkaphtoraGeewOml0jTX84clwMKu = (CX::Int64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.begin(); iter != sbt_D3erns7wJE_tmJ4igdG9X0YJ9eKV8sdk396k2P_skykU2bzWA80.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QAjBtHkTt86_hpvdqSsLe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_QAjBtHkTt86_hpvdqSsLe.begin(); iter != sbt_QAjBtHkTt86_hpvdqSsLe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.begin(); iter != sbt_PqyZM3Skt23GPGuWBJntTJuprUqJ75q0NSRzHR235roHJv0JaEMnAru.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t7ctkaphtoraGeewOml0jTX84clwMKu", (CX::Int64)sbt_t7ctkaphtoraGeewOml0jTX84clwMKu)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N>::Type sbt_n_4cjxuppmDE0TFozqv3grBbsDM4NArray;

