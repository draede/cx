
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW.hpp"


class sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7;
	CX::UInt32 sbt_3wn7XI7HY;
	CX::IO::SimpleBuffers::UInt64Array sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F;
	CX::UInt64 sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a;
	CX::IO::SimpleBuffers::Int16Array sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb;
	CX::IO::SimpleBuffers::Int32Array sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB;
	sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsWArray sbt_u3d1PnrZ1zyqbrv;

	virtual void Reset()
	{
		sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7 = 0;
		sbt_3wn7XI7HY = 0;
		sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.clear();
		sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a = 0;
		sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.clear();
		sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.clear();
		sbt_u3d1PnrZ1zyqbrv.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7 = -15;
		sbt_3wn7XI7HY = 3457157887;
		sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a = 11053364344707748282;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.push_back(-13509);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.push_back(-1180143986);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8 *pObject = dynamic_cast<const sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7 != pObject->sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7)
		{
			return false;
		}
		if (sbt_3wn7XI7HY != pObject->sbt_3wn7XI7HY)
		{
			return false;
		}
		if (sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.size() != pObject->sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.size(); i++)
		{
			if (sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F[i] != pObject->sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F[i])
			{
				return false;
			}
		}
		if (sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a != pObject->sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a)
		{
			return false;
		}
		if (sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.size() != pObject->sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.size(); i++)
		{
			if (sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb[i] != pObject->sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb[i])
			{
				return false;
			}
		}
		if (sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.size() != pObject->sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.size(); i++)
		{
			if (sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB[i] != pObject->sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB[i])
			{
				return false;
			}
		}
		if (sbt_u3d1PnrZ1zyqbrv.size() != pObject->sbt_u3d1PnrZ1zyqbrv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u3d1PnrZ1zyqbrv.size(); i++)
		{
			if (!sbt_u3d1PnrZ1zyqbrv[i].Compare(&pObject->sbt_u3d1PnrZ1zyqbrv[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3wn7XI7HY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3wn7XI7HY = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_u3d1PnrZ1zyqbrv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_u3d1PnrZ1zyqbrv.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7", (CX::Int64)sbt_yRaB7TxA0Qgunp71JhKYBozEIwOpfbCOt_uomul7QK3DCEScovBH9PXRVS7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3wn7XI7HY", (CX::Int64)sbt_3wn7XI7HY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.begin(); iter != sbt_GRAy9cNDr7LJaEjzXsibhfrUSeSXr_EgwrdkWXT1F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a", (CX::Int64)sbt_y3U1C9ArMbiYLlFWy4uiVL8C2CvWaLyDLWP5a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.begin(); iter != sbt_Q_Kw8fNCcHdaAtJHSTnIGQUZ_t5Yb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.begin(); iter != sbt_ddoIiInJeBahnaGA3QKDUUJu04POeXB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u3d1PnrZ1zyqbrv")).IsNOK())
		{
			return status;
		}
		for (sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsWArray::const_iterator iter = sbt_u3d1PnrZ1zyqbrv.begin(); iter != sbt_u3d1PnrZ1zyqbrv.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8>::Type sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8Array;

