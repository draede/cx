
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7.hpp"


class sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx;
	CX::IO::SimpleBuffers::UInt64Array sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K;
	CX::IO::SimpleBuffers::UInt8Array sbt_Gkgb3rJ5Jjx2E;
	CX::IO::SimpleBuffers::Int8Array sbt_M4GZGKLDJI0lTnoFH41;
	CX::IO::SimpleBuffers::UInt8Array sbt_XBg4hvjqwod;
	CX::Int32 sbt_6L_q2FYSzIuHt;
	CX::IO::SimpleBuffers::FloatArray sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e;
	CX::IO::SimpleBuffers::Int64Array sbt_cUOFA;
	CX::IO::SimpleBuffers::BoolArray sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN;
	CX::Int16 sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV;
	CX::UInt64 sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu;
	CX::IO::SimpleBuffers::WStringArray sbt_73W2POk_LVPBvuSM8oSTy;
	CX::Int8 sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ;
	CX::IO::SimpleBuffers::StringArray sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK;
	CX::IO::SimpleBuffers::Int8Array sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C;
	CX::IO::SimpleBuffers::BoolArray sbt_NXycrWR;
	CX::IO::SimpleBuffers::Int32Array sbt_yUghpWPOroJ;
	CX::Double sbt_ExENCkYEa6lI_fRHo;
	CX::Int16 sbt_HcVKIIl9b1ew3vulcpNfT;
	CX::WString sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk;
	CX::UInt32 sbt_7YqsI;
	CX::WString sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda;
	CX::Int32 sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F;
	CX::Double sbt_6eOlxX3n3;
	CX::IO::SimpleBuffers::Int64Array sbt_R_83Y05YowNRM;
	CX::UInt32 sbt_BdErqsEIOTcwTHpA_41bu0l;
	CX::Int64 sbt_gPjVE;
	CX::Int32 sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ;
	CX::IO::SimpleBuffers::Int8Array sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny;
	sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7Array sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY;

	virtual void Reset()
	{
		sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.clear();
		sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.clear();
		sbt_Gkgb3rJ5Jjx2E.clear();
		sbt_M4GZGKLDJI0lTnoFH41.clear();
		sbt_XBg4hvjqwod.clear();
		sbt_6L_q2FYSzIuHt = 0;
		sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.clear();
		sbt_cUOFA.clear();
		sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.clear();
		sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV = 0;
		sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu = 0;
		sbt_73W2POk_LVPBvuSM8oSTy.clear();
		sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ = 0;
		sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.clear();
		sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.clear();
		sbt_NXycrWR.clear();
		sbt_yUghpWPOroJ.clear();
		sbt_ExENCkYEa6lI_fRHo = 0.0;
		sbt_HcVKIIl9b1ew3vulcpNfT = 0;
		sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk.clear();
		sbt_7YqsI = 0;
		sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda.clear();
		sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F = 0;
		sbt_6eOlxX3n3 = 0.0;
		sbt_R_83Y05YowNRM.clear();
		sbt_BdErqsEIOTcwTHpA_41bu0l = 0;
		sbt_gPjVE = 0;
		sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ = 0;
		sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.clear();
		sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.push_back(0.923118f);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.push_back(5403899379224992366);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Gkgb3rJ5Jjx2E.push_back(143);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_M4GZGKLDJI0lTnoFH41.push_back(79);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_XBg4hvjqwod.push_back(178);
		}
		sbt_6L_q2FYSzIuHt = -1401614440;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_cUOFA.push_back(-1520686744783020746);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.push_back(true);
		}
		sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV = -3181;
		sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu = 2459251142359465528;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_73W2POk_LVPBvuSM8oSTy.push_back(L"_CHYNTo,(M^pxFk4vO&i6'NRX8=,Y$IH@D.k_C`YF)hf\"u:Y|31g$69a");
		}
		sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ = -104;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.push_back("v/'Aq8.\\%XO&y8J/AqcNFUnKG/RUK/h;3ZCD>uiTqd9)9uPl/\"n.");
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.push_back(-109);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_NXycrWR.push_back(false);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_yUghpWPOroJ.push_back(-913649775);
		}
		sbt_ExENCkYEa6lI_fRHo = 0.960488;
		sbt_HcVKIIl9b1ew3vulcpNfT = 8427;
		sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk = L"sSo3xdRecA!!MNpFAiL-Vx,Ga8S=+icz'U3W.e+DNU";
		sbt_7YqsI = 3594667812;
		sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda = L"v;G\\BZA:ET~(e!^P%<gi";
		sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F = 257768205;
		sbt_6eOlxX3n3 = 0.472084;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_R_83Y05YowNRM.push_back(-3166016946763837990);
		}
		sbt_BdErqsEIOTcwTHpA_41bu0l = 3027031199;
		sbt_gPjVE = -7513682621690567296;
		sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ = -730542468;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.push_back(-88);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7 v;

			v.SetupWithSomeValues();
			sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp *pObject = dynamic_cast<const sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.size() != pObject->sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.size(); i++)
		{
			if (sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx[i] != pObject->sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx[i])
			{
				return false;
			}
		}
		if (sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.size() != pObject->sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.size(); i++)
		{
			if (sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K[i] != pObject->sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K[i])
			{
				return false;
			}
		}
		if (sbt_Gkgb3rJ5Jjx2E.size() != pObject->sbt_Gkgb3rJ5Jjx2E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Gkgb3rJ5Jjx2E.size(); i++)
		{
			if (sbt_Gkgb3rJ5Jjx2E[i] != pObject->sbt_Gkgb3rJ5Jjx2E[i])
			{
				return false;
			}
		}
		if (sbt_M4GZGKLDJI0lTnoFH41.size() != pObject->sbt_M4GZGKLDJI0lTnoFH41.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M4GZGKLDJI0lTnoFH41.size(); i++)
		{
			if (sbt_M4GZGKLDJI0lTnoFH41[i] != pObject->sbt_M4GZGKLDJI0lTnoFH41[i])
			{
				return false;
			}
		}
		if (sbt_XBg4hvjqwod.size() != pObject->sbt_XBg4hvjqwod.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XBg4hvjqwod.size(); i++)
		{
			if (sbt_XBg4hvjqwod[i] != pObject->sbt_XBg4hvjqwod[i])
			{
				return false;
			}
		}
		if (sbt_6L_q2FYSzIuHt != pObject->sbt_6L_q2FYSzIuHt)
		{
			return false;
		}
		if (sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.size() != pObject->sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.size(); i++)
		{
			if (sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e[i] != pObject->sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e[i])
			{
				return false;
			}
		}
		if (sbt_cUOFA.size() != pObject->sbt_cUOFA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cUOFA.size(); i++)
		{
			if (sbt_cUOFA[i] != pObject->sbt_cUOFA[i])
			{
				return false;
			}
		}
		if (sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.size() != pObject->sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.size(); i++)
		{
			if (sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN[i] != pObject->sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN[i])
			{
				return false;
			}
		}
		if (sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV != pObject->sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV)
		{
			return false;
		}
		if (sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu != pObject->sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu)
		{
			return false;
		}
		if (sbt_73W2POk_LVPBvuSM8oSTy.size() != pObject->sbt_73W2POk_LVPBvuSM8oSTy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_73W2POk_LVPBvuSM8oSTy.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_73W2POk_LVPBvuSM8oSTy[i].c_str(), pObject->sbt_73W2POk_LVPBvuSM8oSTy[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ != pObject->sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ)
		{
			return false;
		}
		if (sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.size() != pObject->sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.size(); i++)
		{
			if (0 != cx_strcmp(sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK[i].c_str(), pObject->sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.size() != pObject->sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.size(); i++)
		{
			if (sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C[i] != pObject->sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C[i])
			{
				return false;
			}
		}
		if (sbt_NXycrWR.size() != pObject->sbt_NXycrWR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NXycrWR.size(); i++)
		{
			if (sbt_NXycrWR[i] != pObject->sbt_NXycrWR[i])
			{
				return false;
			}
		}
		if (sbt_yUghpWPOroJ.size() != pObject->sbt_yUghpWPOroJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yUghpWPOroJ.size(); i++)
		{
			if (sbt_yUghpWPOroJ[i] != pObject->sbt_yUghpWPOroJ[i])
			{
				return false;
			}
		}
		if (sbt_ExENCkYEa6lI_fRHo != pObject->sbt_ExENCkYEa6lI_fRHo)
		{
			return false;
		}
		if (sbt_HcVKIIl9b1ew3vulcpNfT != pObject->sbt_HcVKIIl9b1ew3vulcpNfT)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk.c_str(), pObject->sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk.c_str()))
		{
			return false;
		}
		if (sbt_7YqsI != pObject->sbt_7YqsI)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda.c_str(), pObject->sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda.c_str()))
		{
			return false;
		}
		if (sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F != pObject->sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F)
		{
			return false;
		}
		if (sbt_6eOlxX3n3 != pObject->sbt_6eOlxX3n3)
		{
			return false;
		}
		if (sbt_R_83Y05YowNRM.size() != pObject->sbt_R_83Y05YowNRM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R_83Y05YowNRM.size(); i++)
		{
			if (sbt_R_83Y05YowNRM[i] != pObject->sbt_R_83Y05YowNRM[i])
			{
				return false;
			}
		}
		if (sbt_BdErqsEIOTcwTHpA_41bu0l != pObject->sbt_BdErqsEIOTcwTHpA_41bu0l)
		{
			return false;
		}
		if (sbt_gPjVE != pObject->sbt_gPjVE)
		{
			return false;
		}
		if (sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ != pObject->sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ)
		{
			return false;
		}
		if (sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.size() != pObject->sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.size(); i++)
		{
			if (sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny[i] != pObject->sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny[i])
			{
				return false;
			}
		}
		if (sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.size() != pObject->sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.size(); i++)
		{
			if (!sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY[i].Compare(&pObject->sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Gkgb3rJ5Jjx2E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Gkgb3rJ5Jjx2E.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M4GZGKLDJI0lTnoFH41")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M4GZGKLDJI0lTnoFH41.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XBg4hvjqwod")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XBg4hvjqwod.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6L_q2FYSzIuHt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6L_q2FYSzIuHt = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cUOFA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cUOFA.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_73W2POk_LVPBvuSM8oSTy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_73W2POk_LVPBvuSM8oSTy.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NXycrWR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NXycrWR.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yUghpWPOroJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yUghpWPOroJ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_ExENCkYEa6lI_fRHo", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ExENCkYEa6lI_fRHo = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_HcVKIIl9b1ew3vulcpNfT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HcVKIIl9b1ew3vulcpNfT = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk", &sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7YqsI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7YqsI = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectWString("sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda", &sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_6eOlxX3n3", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_6eOlxX3n3 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_R_83Y05YowNRM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R_83Y05YowNRM.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BdErqsEIOTcwTHpA_41bu0l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BdErqsEIOTcwTHpA_41bu0l = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gPjVE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gPjVE = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.begin(); iter != sbt_Z7auzrbR3XNeqEb4WJMbDCeCAdoTrT3YK_YMcvhTQ9R2_cZhS03NMWX3vtx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.begin(); iter != sbt_a7GPr7sPL0y_LDWyqmIIVVKmaAegVgsmTPmi1I7eu_K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Gkgb3rJ5Jjx2E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Gkgb3rJ5Jjx2E.begin(); iter != sbt_Gkgb3rJ5Jjx2E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M4GZGKLDJI0lTnoFH41")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_M4GZGKLDJI0lTnoFH41.begin(); iter != sbt_M4GZGKLDJI0lTnoFH41.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XBg4hvjqwod")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XBg4hvjqwod.begin(); iter != sbt_XBg4hvjqwod.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6L_q2FYSzIuHt", (CX::Int64)sbt_6L_q2FYSzIuHt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.begin(); iter != sbt_VfaW8nNmyfvPYlQN74HM23I_ovWGSo8GftEJh8MsAqczMvhAroM1YpDOvjJOq5e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cUOFA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_cUOFA.begin(); iter != sbt_cUOFA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.begin(); iter != sbt_WbesUfn3cztlcIcXLJOQ2IvHjDBB06tFIdG5z41dsOBBUs5GO7V8ebN1s5Bc6kN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV", (CX::Int64)sbt_2Gxq4rg6Fhm2ARo9msFjr2ZzjiJXGpwAzJuD4nry1GjvZDj9eQvKylWN6sEEV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu", (CX::Int64)sbt_jXvbNjBZ0f1vlvZ7tLy8wh1FLPDDL6sFr8M_gFRWH2VvwgyqHcRs0upRETu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_73W2POk_LVPBvuSM8oSTy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_73W2POk_LVPBvuSM8oSTy.begin(); iter != sbt_73W2POk_LVPBvuSM8oSTy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ", (CX::Int64)sbt_pHHP41jokKuwgFbRjRTxA5oS3pNvZppP5ew55xwD794srHZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.begin(); iter != sbt__rZKJty0HNrhIgd_KDpw2o2PHhY0OHMW715UK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.begin(); iter != sbt_uoBbfPYMrHTELpbve4Biv7r_z6GMPQuxihEUIPHWlGsEBP8Si0JNzVV6C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NXycrWR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_NXycrWR.begin(); iter != sbt_NXycrWR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yUghpWPOroJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_yUghpWPOroJ.begin(); iter != sbt_yUghpWPOroJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ExENCkYEa6lI_fRHo", (CX::Double)sbt_ExENCkYEa6lI_fRHo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HcVKIIl9b1ew3vulcpNfT", (CX::Int64)sbt_HcVKIIl9b1ew3vulcpNfT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk", sbt_nPjyDkCgf5RWcHofBuYY6fKKQAUkO_uo0UzZk.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7YqsI", (CX::Int64)sbt_7YqsI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda", sbt_Sz0hlgrBLXX9JNZ9C_FQOouIqezVkypl6fnLkm4jeda.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F", (CX::Int64)sbt_z02qhUhdX64l08fuFHDqbGjlO3tlTMkvZweyJs3hhN8Hesae5TKWQ6F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_6eOlxX3n3", (CX::Double)sbt_6eOlxX3n3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R_83Y05YowNRM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_R_83Y05YowNRM.begin(); iter != sbt_R_83Y05YowNRM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BdErqsEIOTcwTHpA_41bu0l", (CX::Int64)sbt_BdErqsEIOTcwTHpA_41bu0l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gPjVE", (CX::Int64)sbt_gPjVE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ", (CX::Int64)sbt_YOZNtWeyKuPBPs1tQgs63IbQErkz4PbArybJUvktT0fuIA2osUUMWk5aQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.begin(); iter != sbt_4rMO5BzRF3wIvw45tuWlP2kVfBLny.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY")).IsNOK())
		{
			return status;
		}
		for (sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7Array::const_iterator iter = sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.begin(); iter != sbt_BlX5dXQj6lpHTLCmH48KZ5QUUXfqY.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp>::Type sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3RpArray;

