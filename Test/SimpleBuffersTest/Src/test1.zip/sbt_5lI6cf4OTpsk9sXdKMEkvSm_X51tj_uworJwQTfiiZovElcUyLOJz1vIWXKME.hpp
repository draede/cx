
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_d7J.hpp"


class sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_6fS7cs50ggi;
	CX::IO::SimpleBuffers::UInt8Array sbt_P0rqZJjAa4T6u5JwP9hQu;
	CX::UInt16 sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3;
	CX::Int64 sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl;
	CX::IO::SimpleBuffers::DoubleArray sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq;
	CX::IO::SimpleBuffers::Int16Array sbt_M5m6jdiGEDeHB;
	CX::IO::SimpleBuffers::UInt64Array sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U;
	CX::IO::SimpleBuffers::UInt8Array sbt_GfcvXsW_HFqeFyicLnDGam1;
	CX::IO::SimpleBuffers::UInt16Array sbt_flYhS7uyN30CrqNFB;
	CX::UInt32 sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML;
	sbt_d7JArray sbt_o7xPAwZl3;

	virtual void Reset()
	{
		sbt_6fS7cs50ggi.clear();
		sbt_P0rqZJjAa4T6u5JwP9hQu.clear();
		sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3 = 0;
		sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl = 0;
		sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.clear();
		sbt_M5m6jdiGEDeHB.clear();
		sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.clear();
		sbt_GfcvXsW_HFqeFyicLnDGam1.clear();
		sbt_flYhS7uyN30CrqNFB.clear();
		sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML = 0;
		sbt_o7xPAwZl3.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_6fS7cs50ggi.push_back(2952042298);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_P0rqZJjAa4T6u5JwP9hQu.push_back(150);
		}
		sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3 = 38130;
		sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl = -1794142275682980620;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.push_back(0.880600);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_M5m6jdiGEDeHB.push_back(19807);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.push_back(14184553938455339478);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_GfcvXsW_HFqeFyicLnDGam1.push_back(193);
		}
		sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML = 2202092741;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_d7J v;

			v.SetupWithSomeValues();
			sbt_o7xPAwZl3.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME *pObject = dynamic_cast<const sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_6fS7cs50ggi.size() != pObject->sbt_6fS7cs50ggi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6fS7cs50ggi.size(); i++)
		{
			if (sbt_6fS7cs50ggi[i] != pObject->sbt_6fS7cs50ggi[i])
			{
				return false;
			}
		}
		if (sbt_P0rqZJjAa4T6u5JwP9hQu.size() != pObject->sbt_P0rqZJjAa4T6u5JwP9hQu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P0rqZJjAa4T6u5JwP9hQu.size(); i++)
		{
			if (sbt_P0rqZJjAa4T6u5JwP9hQu[i] != pObject->sbt_P0rqZJjAa4T6u5JwP9hQu[i])
			{
				return false;
			}
		}
		if (sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3 != pObject->sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3)
		{
			return false;
		}
		if (sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl != pObject->sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl)
		{
			return false;
		}
		if (sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.size() != pObject->sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.size(); i++)
		{
			if (sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq[i] != pObject->sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq[i])
			{
				return false;
			}
		}
		if (sbt_M5m6jdiGEDeHB.size() != pObject->sbt_M5m6jdiGEDeHB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M5m6jdiGEDeHB.size(); i++)
		{
			if (sbt_M5m6jdiGEDeHB[i] != pObject->sbt_M5m6jdiGEDeHB[i])
			{
				return false;
			}
		}
		if (sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.size() != pObject->sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.size(); i++)
		{
			if (sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U[i] != pObject->sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U[i])
			{
				return false;
			}
		}
		if (sbt_GfcvXsW_HFqeFyicLnDGam1.size() != pObject->sbt_GfcvXsW_HFqeFyicLnDGam1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GfcvXsW_HFqeFyicLnDGam1.size(); i++)
		{
			if (sbt_GfcvXsW_HFqeFyicLnDGam1[i] != pObject->sbt_GfcvXsW_HFqeFyicLnDGam1[i])
			{
				return false;
			}
		}
		if (sbt_flYhS7uyN30CrqNFB.size() != pObject->sbt_flYhS7uyN30CrqNFB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_flYhS7uyN30CrqNFB.size(); i++)
		{
			if (sbt_flYhS7uyN30CrqNFB[i] != pObject->sbt_flYhS7uyN30CrqNFB[i])
			{
				return false;
			}
		}
		if (sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML != pObject->sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML)
		{
			return false;
		}
		if (sbt_o7xPAwZl3.size() != pObject->sbt_o7xPAwZl3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o7xPAwZl3.size(); i++)
		{
			if (!sbt_o7xPAwZl3[i].Compare(&pObject->sbt_o7xPAwZl3[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_6fS7cs50ggi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6fS7cs50ggi.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P0rqZJjAa4T6u5JwP9hQu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P0rqZJjAa4T6u5JwP9hQu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M5m6jdiGEDeHB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M5m6jdiGEDeHB.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GfcvXsW_HFqeFyicLnDGam1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GfcvXsW_HFqeFyicLnDGam1.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_flYhS7uyN30CrqNFB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_flYhS7uyN30CrqNFB.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_o7xPAwZl3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_d7J tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_o7xPAwZl3.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_6fS7cs50ggi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_6fS7cs50ggi.begin(); iter != sbt_6fS7cs50ggi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P0rqZJjAa4T6u5JwP9hQu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_P0rqZJjAa4T6u5JwP9hQu.begin(); iter != sbt_P0rqZJjAa4T6u5JwP9hQu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3", (CX::Int64)sbt_XEqws7sawVUQWw7x0YwULNYqTSflUWWSTDXFsDqJRm3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl", (CX::Int64)sbt_0Uq9eZzh9uVKgQunktTBABx_GefmEzdGRzB1PxiCGSzr0COANr2ewEqZBGMzFGl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.begin(); iter != sbt_AzJTMCWfT4ot6Fq3h0AjM6H5GgXJYd2M5JShq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M5m6jdiGEDeHB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_M5m6jdiGEDeHB.begin(); iter != sbt_M5m6jdiGEDeHB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.begin(); iter != sbt_cC_8pxb8BL8jGp11MgpzFsbVgjZrcRqzARDQjSTtf1U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GfcvXsW_HFqeFyicLnDGam1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_GfcvXsW_HFqeFyicLnDGam1.begin(); iter != sbt_GfcvXsW_HFqeFyicLnDGam1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_flYhS7uyN30CrqNFB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_flYhS7uyN30CrqNFB.begin(); iter != sbt_flYhS7uyN30CrqNFB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML", (CX::Int64)sbt_3_DV8QjQXZr3oG8bThBwQ7cG_XTj8dc975fVeI_fepkmPzSIkML)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o7xPAwZl3")).IsNOK())
		{
			return status;
		}
		for (sbt_d7JArray::const_iterator iter = sbt_o7xPAwZl3.begin(); iter != sbt_o7xPAwZl3.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME>::Type sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKMEArray;

