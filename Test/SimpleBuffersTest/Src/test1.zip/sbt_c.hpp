
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX.hpp"


class sbt_C : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_feU5VGqbhc5b_ZuPWK1;
	CX::UInt32 sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws;
	CX::IO::SimpleBuffers::Int16Array sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O;
	CX::WString sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl;
	CX::UInt64 sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO;
	CX::IO::SimpleBuffers::UInt32Array sbt_V9fMv8WyFHr5o3w54;
	CX::Int64 sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5;
	CX::IO::SimpleBuffers::BoolArray sbt_5aRrB845GgzmF5NklRV;
	CX::UInt64 sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G;
	CX::IO::SimpleBuffers::WStringArray sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd;
	CX::IO::SimpleBuffers::Int64Array sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX;
	CX::UInt16 sbt_XjA6hKJn5x4;
	CX::Bool sbt__cDrJ1d;
	CX::IO::SimpleBuffers::UInt8Array sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1;
	CX::String sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc;
	sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilXArray sbt_PbPKqtHjyms3SbV;

	virtual void Reset()
	{
		sbt_feU5VGqbhc5b_ZuPWK1 = 0.0f;
		sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws = 0;
		sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.clear();
		sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl.clear();
		sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO = 0;
		sbt_V9fMv8WyFHr5o3w54.clear();
		sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5 = 0;
		sbt_5aRrB845GgzmF5NklRV.clear();
		sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G = 0;
		sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.clear();
		sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.clear();
		sbt_XjA6hKJn5x4 = 0;
		sbt__cDrJ1d = false;
		sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.clear();
		sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc.clear();
		sbt_PbPKqtHjyms3SbV.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_feU5VGqbhc5b_ZuPWK1 = 0.769821f;
		sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws = 217230559;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.push_back(-10199);
		}
		sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl = L"'Rt}oQf#Qc6av=vjeGG!oi/_K|Ir1#4v0~1r";
		sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO = 11005120311751452442;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_V9fMv8WyFHr5o3w54.push_back(1162996082);
		}
		sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5 = -2002834289941551310;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_5aRrB845GgzmF5NklRV.push_back(false);
		}
		sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G = 3527261807572063068;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.push_back(L"J\\S3a|rtUEo+yf>+>VI+GXMN=H!h;v+OxdG.#dZRC,4[KA~2(I");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.push_back(-3585465102398247268);
		}
		sbt_XjA6hKJn5x4 = 52710;
		sbt__cDrJ1d = false;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.push_back(223);
		}
		sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc = "sIZw)_=ws@ghmgst+J9x,ffN!7hdT";
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX v;

			v.SetupWithSomeValues();
			sbt_PbPKqtHjyms3SbV.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_C *pObject = dynamic_cast<const sbt_C *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_feU5VGqbhc5b_ZuPWK1 != pObject->sbt_feU5VGqbhc5b_ZuPWK1)
		{
			return false;
		}
		if (sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws != pObject->sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws)
		{
			return false;
		}
		if (sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.size() != pObject->sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.size(); i++)
		{
			if (sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O[i] != pObject->sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl.c_str(), pObject->sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl.c_str()))
		{
			return false;
		}
		if (sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO != pObject->sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO)
		{
			return false;
		}
		if (sbt_V9fMv8WyFHr5o3w54.size() != pObject->sbt_V9fMv8WyFHr5o3w54.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_V9fMv8WyFHr5o3w54.size(); i++)
		{
			if (sbt_V9fMv8WyFHr5o3w54[i] != pObject->sbt_V9fMv8WyFHr5o3w54[i])
			{
				return false;
			}
		}
		if (sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5 != pObject->sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5)
		{
			return false;
		}
		if (sbt_5aRrB845GgzmF5NklRV.size() != pObject->sbt_5aRrB845GgzmF5NklRV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5aRrB845GgzmF5NklRV.size(); i++)
		{
			if (sbt_5aRrB845GgzmF5NklRV[i] != pObject->sbt_5aRrB845GgzmF5NklRV[i])
			{
				return false;
			}
		}
		if (sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G != pObject->sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G)
		{
			return false;
		}
		if (sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.size() != pObject->sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd[i].c_str(), pObject->sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.size() != pObject->sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.size(); i++)
		{
			if (sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX[i] != pObject->sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX[i])
			{
				return false;
			}
		}
		if (sbt_XjA6hKJn5x4 != pObject->sbt_XjA6hKJn5x4)
		{
			return false;
		}
		if (sbt__cDrJ1d != pObject->sbt__cDrJ1d)
		{
			return false;
		}
		if (sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.size() != pObject->sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.size(); i++)
		{
			if (sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1[i] != pObject->sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc.c_str(), pObject->sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc.c_str()))
		{
			return false;
		}
		if (sbt_PbPKqtHjyms3SbV.size() != pObject->sbt_PbPKqtHjyms3SbV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PbPKqtHjyms3SbV.size(); i++)
		{
			if (!sbt_PbPKqtHjyms3SbV[i].Compare(&pObject->sbt_PbPKqtHjyms3SbV[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_feU5VGqbhc5b_ZuPWK1", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_feU5VGqbhc5b_ZuPWK1 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl", &sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_V9fMv8WyFHr5o3w54")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_V9fMv8WyFHr5o3w54.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5aRrB845GgzmF5NklRV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5aRrB845GgzmF5NklRV.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XjA6hKJn5x4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XjA6hKJn5x4 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt__cDrJ1d", &sbt__cDrJ1d)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc", &sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PbPKqtHjyms3SbV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_PbPKqtHjyms3SbV.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_feU5VGqbhc5b_ZuPWK1", (CX::Double)sbt_feU5VGqbhc5b_ZuPWK1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws", (CX::Int64)sbt_ruouPaLh2gwk7CM58F189Ehjd_r77K_3vIhQ4ws)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.begin(); iter != sbt_bzjDybEGjvUjSEjHrQuv9r8P_1O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl", sbt_TeCj3iS5mKvf8VwZmE4wjhfhLFt1RR1xf95HGgSHAnq4fiRBvdSYl.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO", (CX::Int64)sbt_6_IqTmaba1e4uyZkmnd4YsKeI7jsO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_V9fMv8WyFHr5o3w54")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_V9fMv8WyFHr5o3w54.begin(); iter != sbt_V9fMv8WyFHr5o3w54.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5", (CX::Int64)sbt_5x21IW8PQb0upV85sRDPwppCIhA_keaq5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5aRrB845GgzmF5NklRV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_5aRrB845GgzmF5NklRV.begin(); iter != sbt_5aRrB845GgzmF5NklRV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G", (CX::Int64)sbt_yo2OQGXainfHEWzjnwvQYJMD5pDPpnmz7_VCGDUiaxG76hKDD1G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.begin(); iter != sbt_yPjPps2WKDVKpBXveZBDNxtGDko3yfpSCsmw9kagFF6kL3wOd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.begin(); iter != sbt_fADdMWbREebqIKZ9zmru6cfdxZ81ebrMH3hI0Gy86veTYsQ3GibrVNtboAsPxMX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XjA6hKJn5x4", (CX::Int64)sbt_XjA6hKJn5x4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt__cDrJ1d", sbt__cDrJ1d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.begin(); iter != sbt_eRcmGF9xxfCv2cS8GxzgGut8viKed3O5VhW_34BlIqSGUf7Nw7RmDe1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc", sbt_GugoK6K4juH2hBi_Fo054SeWBU60NHfu_bUe2nyhhxDWc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PbPKqtHjyms3SbV")).IsNOK())
		{
			return status;
		}
		for (sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilXArray::const_iterator iter = sbt_PbPKqtHjyms3SbV.begin(); iter != sbt_PbPKqtHjyms3SbV.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_C>::Type sbt_CArray;

