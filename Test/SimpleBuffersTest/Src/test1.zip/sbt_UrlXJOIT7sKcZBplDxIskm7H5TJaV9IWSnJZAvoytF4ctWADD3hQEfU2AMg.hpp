
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj;
	CX::IO::SimpleBuffers::UInt8Array sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f;

	virtual void Reset()
	{
		sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.clear();
		sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.push_back(8147179500590208088);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.push_back(175);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg *pObject = dynamic_cast<const sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.size() != pObject->sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.size(); i++)
		{
			if (sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj[i] != pObject->sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj[i])
			{
				return false;
			}
		}
		if (sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.size() != pObject->sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.size(); i++)
		{
			if (sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f[i] != pObject->sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.begin(); iter != sbt_5YvaJMsldB3yyuwnFbrgsuuNXuK6qDT8CLtacVnLWTog4uj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.begin(); iter != sbt_krCFkcJzScavXEyqmt8NxDBfzaoNjWenZqwIFK36N6f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg>::Type sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMgArray;

