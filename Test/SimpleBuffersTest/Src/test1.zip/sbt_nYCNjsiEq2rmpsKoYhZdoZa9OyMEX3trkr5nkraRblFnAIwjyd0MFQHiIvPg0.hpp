
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8rfMtEg.hpp"


class sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_v7nhbZP;
	CX::Int64 sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8;
	CX::WString sbt_L;
	CX::Float sbt_Nk2DIzA3C52u1EWOzbjxKrw;
	CX::IO::SimpleBuffers::StringArray sbt_u_eEsFJ15G02IPbB0w1;
	CX::UInt8 sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p;
	CX::Int8 sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV;
	CX::UInt32 sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB;
	CX::Int64 sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C;
	CX::Int64 sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u;
	CX::IO::SimpleBuffers::UInt8Array sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm;
	CX::IO::SimpleBuffers::FloatArray sbt_H;
	CX::IO::SimpleBuffers::UInt32Array sbt_Usl58uk6YqOG6JCUYHWTkus;
	CX::UInt8 sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f;
	CX::IO::SimpleBuffers::UInt16Array sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY;
	CX::UInt16 sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX;
	CX::Int16 sbt_iQEsx;
	CX::String sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I;
	CX::Int16 sbt_kRqM5rNgJNjrLEFlKWsvzxb;
	sbt_8rfMtEg sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH;

	virtual void Reset()
	{
		sbt_v7nhbZP.clear();
		sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8 = 0;
		sbt_L.clear();
		sbt_Nk2DIzA3C52u1EWOzbjxKrw = 0.0f;
		sbt_u_eEsFJ15G02IPbB0w1.clear();
		sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p = 0;
		sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV = 0;
		sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB = 0;
		sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C = 0;
		sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u = 0;
		sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.clear();
		sbt_H.clear();
		sbt_Usl58uk6YqOG6JCUYHWTkus.clear();
		sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f = 0;
		sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.clear();
		sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX = 0;
		sbt_iQEsx = 0;
		sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I.clear();
		sbt_kRqM5rNgJNjrLEFlKWsvzxb = 0;
		sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_v7nhbZP.push_back(57);
		}
		sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8 = 7960523290431640392;
		sbt_L = L"t0/~9SS)aQN%\\.^s";
		sbt_Nk2DIzA3C52u1EWOzbjxKrw = 0.044056f;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_u_eEsFJ15G02IPbB0w1.push_back("+~@gX/2qX3Rf'I_)^p=/q13t9RYFx:cXO7Pz',3qDc,7#z}<c\"5,[m1\\fR3&");
		}
		sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p = 147;
		sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV = 82;
		sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB = 520871790;
		sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C = -3871209330877797316;
		sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u = 1207139670084933000;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.push_back(129);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_H.push_back(0.968423f);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Usl58uk6YqOG6JCUYHWTkus.push_back(3409364299);
		}
		sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f = 113;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.push_back(59474);
		}
		sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX = 53927;
		sbt_iQEsx = 26900;
		sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I = "ZMZ$,dg4d'm+";
		sbt_kRqM5rNgJNjrLEFlKWsvzxb = -32191;
		sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0 *pObject = dynamic_cast<const sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_v7nhbZP.size() != pObject->sbt_v7nhbZP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v7nhbZP.size(); i++)
		{
			if (sbt_v7nhbZP[i] != pObject->sbt_v7nhbZP[i])
			{
				return false;
			}
		}
		if (sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8 != pObject->sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_L.c_str(), pObject->sbt_L.c_str()))
		{
			return false;
		}
		if (sbt_Nk2DIzA3C52u1EWOzbjxKrw != pObject->sbt_Nk2DIzA3C52u1EWOzbjxKrw)
		{
			return false;
		}
		if (sbt_u_eEsFJ15G02IPbB0w1.size() != pObject->sbt_u_eEsFJ15G02IPbB0w1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u_eEsFJ15G02IPbB0w1.size(); i++)
		{
			if (0 != cx_strcmp(sbt_u_eEsFJ15G02IPbB0w1[i].c_str(), pObject->sbt_u_eEsFJ15G02IPbB0w1[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p != pObject->sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p)
		{
			return false;
		}
		if (sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV != pObject->sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV)
		{
			return false;
		}
		if (sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB != pObject->sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB)
		{
			return false;
		}
		if (sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C != pObject->sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C)
		{
			return false;
		}
		if (sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u != pObject->sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u)
		{
			return false;
		}
		if (sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.size() != pObject->sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.size(); i++)
		{
			if (sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm[i] != pObject->sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm[i])
			{
				return false;
			}
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_Usl58uk6YqOG6JCUYHWTkus.size() != pObject->sbt_Usl58uk6YqOG6JCUYHWTkus.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Usl58uk6YqOG6JCUYHWTkus.size(); i++)
		{
			if (sbt_Usl58uk6YqOG6JCUYHWTkus[i] != pObject->sbt_Usl58uk6YqOG6JCUYHWTkus[i])
			{
				return false;
			}
		}
		if (sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f != pObject->sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f)
		{
			return false;
		}
		if (sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.size() != pObject->sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.size(); i++)
		{
			if (sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY[i] != pObject->sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY[i])
			{
				return false;
			}
		}
		if (sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX != pObject->sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX)
		{
			return false;
		}
		if (sbt_iQEsx != pObject->sbt_iQEsx)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I.c_str(), pObject->sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I.c_str()))
		{
			return false;
		}
		if (sbt_kRqM5rNgJNjrLEFlKWsvzxb != pObject->sbt_kRqM5rNgJNjrLEFlKWsvzxb)
		{
			return false;
		}
		if (!sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH.Compare(&pObject->sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_v7nhbZP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_v7nhbZP.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_L", &sbt_L)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_Nk2DIzA3C52u1EWOzbjxKrw", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Nk2DIzA3C52u1EWOzbjxKrw = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_u_eEsFJ15G02IPbB0w1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u_eEsFJ15G02IPbB0w1.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Usl58uk6YqOG6JCUYHWTkus")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Usl58uk6YqOG6JCUYHWTkus.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_iQEsx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iQEsx = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I", &sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kRqM5rNgJNjrLEFlKWsvzxb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kRqM5rNgJNjrLEFlKWsvzxb = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_v7nhbZP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_v7nhbZP.begin(); iter != sbt_v7nhbZP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8", (CX::Int64)sbt_qPoX2HPC5UASSdN5dVwpFyZPUgC7I7Uq9h88WFu3mUEWLG8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_L", sbt_L.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Nk2DIzA3C52u1EWOzbjxKrw", (CX::Double)sbt_Nk2DIzA3C52u1EWOzbjxKrw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u_eEsFJ15G02IPbB0w1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_u_eEsFJ15G02IPbB0w1.begin(); iter != sbt_u_eEsFJ15G02IPbB0w1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p", (CX::Int64)sbt_I2LhRvw8EnDfJqNX_yuShsemMP0c0ETXnrWQiR8pZHBGJKR4T9p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV", (CX::Int64)sbt_mOtkpeDmjPjJohdCP6aHdbK3NY98NA7l8zA5ExLqV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB", (CX::Int64)sbt_bRjjd9JM9WclWfZg58IgrZVMzdtYFGYiB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C", (CX::Int64)sbt_gJZYtl00xyZPVk8ncVbia_IHuTfzDpt7szg8C)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u", (CX::Int64)sbt_IB_R5gk83gSjlVHXC9kYXGA6EjHMdDbGWfxYlhJu11u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.begin(); iter != sbt_Wouu9q5Zj4YPX7NQqrxLcBlLm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Usl58uk6YqOG6JCUYHWTkus")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Usl58uk6YqOG6JCUYHWTkus.begin(); iter != sbt_Usl58uk6YqOG6JCUYHWTkus.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f", (CX::Int64)sbt_69HIAhVo9nrV0WcXeeUuRpc5SlVJHgHMbabdtzTs0cZAY7EeNcRjt0t3f)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.begin(); iter != sbt_bD2zMa8eH8r1KmJLavZYCLZItOssbh0rofhej0M5anjk1vwFkfY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX", (CX::Int64)sbt_kdarEu1L347usmDJuKjL5pUIf3wR5onG6aX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iQEsx", (CX::Int64)sbt_iQEsx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I", sbt_6QJ1G0JoOAFxzDf85GcUuHQ467iSH0VO4GSWJMGV7uxcqYfoceqBL1Q7I.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kRqM5rNgJNjrLEFlKWsvzxb", (CX::Int64)sbt_kRqM5rNgJNjrLEFlKWsvzxb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_OTVs_kJSPmM3LNC7xc0tKtX1z41r1jcGAkLKHBqWEFbjH.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0>::Type sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0Array;

