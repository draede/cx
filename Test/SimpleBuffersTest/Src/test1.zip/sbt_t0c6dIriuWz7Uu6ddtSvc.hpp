
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_l.hpp"


class sbt_t0c6dIriuWz7Uu6ddtSvc : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_LQqdfSkjvI1lVHqXnruYMqFjz;
	CX::IO::SimpleBuffers::Int16Array sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2;
	CX::Double sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3;
	CX::WString sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC;
	sbt_lArray sbt_ZKr;

	virtual void Reset()
	{
		sbt_LQqdfSkjvI1lVHqXnruYMqFjz.clear();
		sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.clear();
		sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3 = 0.0;
		sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC.clear();
		sbt_ZKr.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_LQqdfSkjvI1lVHqXnruYMqFjz.push_back(false);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.push_back(-21815);
		}
		sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3 = 0.531044;
		sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC = L"NXa<,/A>4A]np";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_l v;

			v.SetupWithSomeValues();
			sbt_ZKr.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_t0c6dIriuWz7Uu6ddtSvc *pObject = dynamic_cast<const sbt_t0c6dIriuWz7Uu6ddtSvc *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_LQqdfSkjvI1lVHqXnruYMqFjz.size() != pObject->sbt_LQqdfSkjvI1lVHqXnruYMqFjz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LQqdfSkjvI1lVHqXnruYMqFjz.size(); i++)
		{
			if (sbt_LQqdfSkjvI1lVHqXnruYMqFjz[i] != pObject->sbt_LQqdfSkjvI1lVHqXnruYMqFjz[i])
			{
				return false;
			}
		}
		if (sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.size() != pObject->sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.size(); i++)
		{
			if (sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2[i] != pObject->sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2[i])
			{
				return false;
			}
		}
		if (sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3 != pObject->sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC.c_str(), pObject->sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC.c_str()))
		{
			return false;
		}
		if (sbt_ZKr.size() != pObject->sbt_ZKr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZKr.size(); i++)
		{
			if (!sbt_ZKr[i].Compare(&pObject->sbt_ZKr[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_LQqdfSkjvI1lVHqXnruYMqFjz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LQqdfSkjvI1lVHqXnruYMqFjz.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3 = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC", &sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZKr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_l tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_ZKr.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_LQqdfSkjvI1lVHqXnruYMqFjz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_LQqdfSkjvI1lVHqXnruYMqFjz.begin(); iter != sbt_LQqdfSkjvI1lVHqXnruYMqFjz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.begin(); iter != sbt_hutwqYgYdr1_RgaqvI5hEdEGREFOtXXmBneMTb2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3", (CX::Double)sbt_ENSajsoQzf8NNLtDTGcgzVlRZbOl_N_iHqQUVlwFEz3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC", sbt_u45UH8Bf4DddHkqjpAnrHedtCCh5diRmJND5IhZDtQKOQ69MC.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZKr")).IsNOK())
		{
			return status;
		}
		for (sbt_lArray::const_iterator iter = sbt_ZKr.begin(); iter != sbt_ZKr.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_t0c6dIriuWz7Uu6ddtSvc>::Type sbt_t0c6dIriuWz7Uu6ddtSvcArray;

