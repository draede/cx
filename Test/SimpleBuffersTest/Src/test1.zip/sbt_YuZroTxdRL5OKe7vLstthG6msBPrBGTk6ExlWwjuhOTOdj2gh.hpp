
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8RPVncJytCFj2kP.hpp"


class sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6;
	CX::IO::SimpleBuffers::Int32Array sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ;
	CX::Int8 sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT;
	CX::IO::SimpleBuffers::DoubleArray sbt_OxkYYuix4owx1WjGD;
	CX::IO::SimpleBuffers::Int16Array sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r;
	CX::IO::SimpleBuffers::Int64Array sbt_L5JKtFj;
	CX::Float sbt_Vm3P6;
	CX::IO::SimpleBuffers::BoolArray sbt_JCc8T;
	CX::UInt64 sbt__qOXHzhNC6LBYTO06;
	CX::Int16 sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf;
	CX::UInt64 sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl;
	CX::IO::SimpleBuffers::UInt8Array sbt_h2Ku6vRglZC;
	CX::IO::SimpleBuffers::StringArray sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv;
	CX::IO::SimpleBuffers::StringArray sbt_hqFGLJM;
	CX::Bool sbt_acGuleDtmn5U7VNgq5Q;
	CX::Int8 sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh;
	CX::WString sbt_CYicwXkZIZn;
	CX::IO::SimpleBuffers::UInt8Array sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC;
	CX::UInt8 sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9;
	CX::IO::SimpleBuffers::BoolArray sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf;
	CX::IO::SimpleBuffers::BoolArray sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC;
	CX::Int64 sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb;
	CX::IO::SimpleBuffers::WStringArray sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY;
	CX::IO::SimpleBuffers::DoubleArray sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm;
	sbt_8RPVncJytCFj2kP sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R;

	virtual void Reset()
	{
		sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.clear();
		sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.clear();
		sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT = 0;
		sbt_OxkYYuix4owx1WjGD.clear();
		sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.clear();
		sbt_L5JKtFj.clear();
		sbt_Vm3P6 = 0.0f;
		sbt_JCc8T.clear();
		sbt__qOXHzhNC6LBYTO06 = 0;
		sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf = 0;
		sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl = 0;
		sbt_h2Ku6vRglZC.clear();
		sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.clear();
		sbt_hqFGLJM.clear();
		sbt_acGuleDtmn5U7VNgq5Q = false;
		sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh = 0;
		sbt_CYicwXkZIZn.clear();
		sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.clear();
		sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9 = 0;
		sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.clear();
		sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.clear();
		sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb = 0;
		sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.clear();
		sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.clear();
		sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.push_back(0.812676f);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.push_back(-716764778);
		}
		sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT = 91;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_OxkYYuix4owx1WjGD.push_back(0.837009);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.push_back(-13347);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_L5JKtFj.push_back(1212947139061032460);
		}
		sbt_Vm3P6 = 0.837457f;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_JCc8T.push_back(false);
		}
		sbt__qOXHzhNC6LBYTO06 = 3254046367417200266;
		sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf = -21541;
		sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl = 12079499739972051782;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_h2Ku6vRglZC.push_back(177);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.push_back("ZS*Ehj");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_hqFGLJM.push_back("]aK>#AsU>}n$MH<~DjtzjlQpUn8rRHbOs^tpFJkf*h\\6,36T+l8y,Qd*l,)j)n82");
		}
		sbt_acGuleDtmn5U7VNgq5Q = true;
		sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh = 115;
		sbt_CYicwXkZIZn = L"Kr4'5n>6*@tBqV[9!D;X]`*9:k.mb";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.push_back(251);
		}
		sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9 = 17;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.push_back(false);
		}
		sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb = 7584461967561093356;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.push_back(L"~L]a'd^aRTF6<z_Ry#Jy=;R|Wg}}8jeR2|45cA");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.push_back(0.752492);
		}
		sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh *pObject = dynamic_cast<const sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.size() != pObject->sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.size(); i++)
		{
			if (sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6[i] != pObject->sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6[i])
			{
				return false;
			}
		}
		if (sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.size() != pObject->sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.size(); i++)
		{
			if (sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ[i] != pObject->sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ[i])
			{
				return false;
			}
		}
		if (sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT != pObject->sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT)
		{
			return false;
		}
		if (sbt_OxkYYuix4owx1WjGD.size() != pObject->sbt_OxkYYuix4owx1WjGD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OxkYYuix4owx1WjGD.size(); i++)
		{
			if (sbt_OxkYYuix4owx1WjGD[i] != pObject->sbt_OxkYYuix4owx1WjGD[i])
			{
				return false;
			}
		}
		if (sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.size() != pObject->sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.size(); i++)
		{
			if (sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r[i] != pObject->sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r[i])
			{
				return false;
			}
		}
		if (sbt_L5JKtFj.size() != pObject->sbt_L5JKtFj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L5JKtFj.size(); i++)
		{
			if (sbt_L5JKtFj[i] != pObject->sbt_L5JKtFj[i])
			{
				return false;
			}
		}
		if (sbt_Vm3P6 != pObject->sbt_Vm3P6)
		{
			return false;
		}
		if (sbt_JCc8T.size() != pObject->sbt_JCc8T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JCc8T.size(); i++)
		{
			if (sbt_JCc8T[i] != pObject->sbt_JCc8T[i])
			{
				return false;
			}
		}
		if (sbt__qOXHzhNC6LBYTO06 != pObject->sbt__qOXHzhNC6LBYTO06)
		{
			return false;
		}
		if (sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf != pObject->sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf)
		{
			return false;
		}
		if (sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl != pObject->sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl)
		{
			return false;
		}
		if (sbt_h2Ku6vRglZC.size() != pObject->sbt_h2Ku6vRglZC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h2Ku6vRglZC.size(); i++)
		{
			if (sbt_h2Ku6vRglZC[i] != pObject->sbt_h2Ku6vRglZC[i])
			{
				return false;
			}
		}
		if (sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.size() != pObject->sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv[i].c_str(), pObject->sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_hqFGLJM.size() != pObject->sbt_hqFGLJM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hqFGLJM.size(); i++)
		{
			if (0 != cx_strcmp(sbt_hqFGLJM[i].c_str(), pObject->sbt_hqFGLJM[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_acGuleDtmn5U7VNgq5Q != pObject->sbt_acGuleDtmn5U7VNgq5Q)
		{
			return false;
		}
		if (sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh != pObject->sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_CYicwXkZIZn.c_str(), pObject->sbt_CYicwXkZIZn.c_str()))
		{
			return false;
		}
		if (sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.size() != pObject->sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.size(); i++)
		{
			if (sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC[i] != pObject->sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC[i])
			{
				return false;
			}
		}
		if (sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9 != pObject->sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9)
		{
			return false;
		}
		if (sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.size() != pObject->sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.size(); i++)
		{
			if (sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf[i] != pObject->sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf[i])
			{
				return false;
			}
		}
		if (sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.size() != pObject->sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.size(); i++)
		{
			if (sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC[i] != pObject->sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC[i])
			{
				return false;
			}
		}
		if (sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb != pObject->sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb)
		{
			return false;
		}
		if (sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.size() != pObject->sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY[i].c_str(), pObject->sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.size() != pObject->sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.size(); i++)
		{
			if (sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm[i] != pObject->sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm[i])
			{
				return false;
			}
		}
		if (!sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R.Compare(&pObject->sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_OxkYYuix4owx1WjGD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OxkYYuix4owx1WjGD.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L5JKtFj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L5JKtFj.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_Vm3P6", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Vm3P6 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_JCc8T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JCc8T.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__qOXHzhNC6LBYTO06", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__qOXHzhNC6LBYTO06 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_h2Ku6vRglZC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h2Ku6vRglZC.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hqFGLJM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hqFGLJM.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_acGuleDtmn5U7VNgq5Q", &sbt_acGuleDtmn5U7VNgq5Q)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectWString("sbt_CYicwXkZIZn", &sbt_CYicwXkZIZn)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.begin(); iter != sbt_KuA4DLQv5a5OuBWI6riBQFM5pdrGFcZpRhGesrXH5S6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.begin(); iter != sbt_S4w3YT95dSjk0LJpsfeUjrUYR5dJeA8GSWyyw_gcLOQpLBYDa5P3aeZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT", (CX::Int64)sbt_ZBPLoJ7RiSp5j3nDRU9w2vc88PjGzdhZvaZKpndvryq3dsCbT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OxkYYuix4owx1WjGD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_OxkYYuix4owx1WjGD.begin(); iter != sbt_OxkYYuix4owx1WjGD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.begin(); iter != sbt_ISR0BdOcYSZnh8dwm18KaVO903sySKFWipsXGInsC02Kh6rH0stfx9r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L5JKtFj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_L5JKtFj.begin(); iter != sbt_L5JKtFj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Vm3P6", (CX::Double)sbt_Vm3P6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JCc8T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_JCc8T.begin(); iter != sbt_JCc8T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__qOXHzhNC6LBYTO06", (CX::Int64)sbt__qOXHzhNC6LBYTO06)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf", (CX::Int64)sbt_ttbdqLINxuNpvTz48BByVu3R9WVBfdvMs20J3dftwrKmK80EcBNeqYQTf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl", (CX::Int64)sbt_JSalN2zEHd9WGf_4salp1GyKEbbQH22ONtsucA8tGrFvFTlm_Y0OjFEwl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h2Ku6vRglZC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_h2Ku6vRglZC.begin(); iter != sbt_h2Ku6vRglZC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.begin(); iter != sbt_tZbJ4H62xr0WWzZr6kt39ZsWewjH71Lcv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hqFGLJM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_hqFGLJM.begin(); iter != sbt_hqFGLJM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_acGuleDtmn5U7VNgq5Q", sbt_acGuleDtmn5U7VNgq5Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh", (CX::Int64)sbt_MLCkvZ0u1LEyDDS0y0D0n9HdOXUjOPA0sNAjdJhWcZhGDn0kZmlNLXmFRzh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_CYicwXkZIZn", sbt_CYicwXkZIZn.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.begin(); iter != sbt_R7ufSMdJaTzCZB9Jv_K3eumSWDftuw6V6VRAf5tCWoScN05WhmgEUsEoeQC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9", (CX::Int64)sbt_Mhp4cKvLeBIIGyo1c1thUbKY83hOk69Rx6mVXgCSt764cy9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.begin(); iter != sbt_LE8RwcWg8UJQ5R0CMcrds_9g1XIOar8jnAalyIMwrf88ikjnpAf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.begin(); iter != sbt_fDW8cDoj22x1MQiEZh14LCcTH2syZkrY_OKIVyC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb", (CX::Int64)sbt_yD5k0IuPy0oMaMYzQkWwVIvWuPhwUx5dcC1jxXnLpObz0pygb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.begin(); iter != sbt_UGVINxsZZkLWj_WzVE9ciJ9sM54LHoOk4NtdlfacG89LJhaC_Rl7pFY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.begin(); iter != sbt_LB82Ylwq00wlZhQzK79HI6sgCsjNqbga10NTnVgcgDck7KWLqSFILUrX9cm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_39q1JwqStdbo3FXe497poa3w4riU6WOLApAcNEJi0kf8R.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh>::Type sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2ghArray;

