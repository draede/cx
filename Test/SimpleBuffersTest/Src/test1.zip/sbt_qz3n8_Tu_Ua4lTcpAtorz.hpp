
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE.hpp"


class sbt_qz3n8_Tu_Ua4lTcpAtorz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb;
	CX::IO::SimpleBuffers::WStringArray sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2;
	CX::IO::SimpleBuffers::WStringArray sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH;
	CX::Int8 sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT;
	CX::Int16 sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1;
	CX::WString sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S;
	CX::WString sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR;
	CX::IO::SimpleBuffers::StringArray sbt_auS;
	CX::Float sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1;
	CX::IO::SimpleBuffers::StringArray sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa;
	CX::IO::SimpleBuffers::WStringArray sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68;
	CX::Int16 sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg;
	CX::IO::SimpleBuffers::DoubleArray sbt_G7qv3257Dq_xq;
	CX::UInt64 sbt_Aljk0qQ7tTUEdOs6i84F94w99;
	CX::UInt32 sbt_KPbWDbsLdtIP7PrMbJi;
	CX::Int32 sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7;
	CX::IO::SimpleBuffers::Int32Array sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3;
	CX::IO::SimpleBuffers::Int32Array sbt_6UGjXd1Mp38WWmabK23Wo3T;
	CX::WString sbt_kT1;
	CX::IO::SimpleBuffers::Int8Array sbt_jtRiVjjdDS2;
	sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE sbt_eCFFIbCa6Gx2xdfVyHG0tJ_;

	virtual void Reset()
	{
		sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb.clear();
		sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.clear();
		sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.clear();
		sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT = 0;
		sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1 = 0;
		sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S.clear();
		sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR.clear();
		sbt_auS.clear();
		sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1 = 0.0f;
		sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.clear();
		sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.clear();
		sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg = 0;
		sbt_G7qv3257Dq_xq.clear();
		sbt_Aljk0qQ7tTUEdOs6i84F94w99 = 0;
		sbt_KPbWDbsLdtIP7PrMbJi = 0;
		sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7 = 0;
		sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.clear();
		sbt_6UGjXd1Mp38WWmabK23Wo3T.clear();
		sbt_kT1.clear();
		sbt_jtRiVjjdDS2.clear();
		sbt_eCFFIbCa6Gx2xdfVyHG0tJ_.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb = L"\"A,QzgJuWN4!GDW*Y:F#l-OY((TI@sC&`@(6#xP8U<!:)kn";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.push_back(L"khp\"");
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.push_back(L"X):iK`*='pb6aWd>V\\PG[3JiVl)E\"=B-n\"[HF*%m\"k2yN1U&6+#AIbyFsbXRp~");
		}
		sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT = 8;
		sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1 = 17597;
		sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S = L"A)<HA";
		sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR = L"Z<qCfgvlrj)1=\\bxLS|y~9V%oP9Hbp{d#%^@72>An0W6H3";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_auS.push_back("7QX:@lRj\"K2f$()");
		}
		sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1 = 0.513725f;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.push_back("E}%SS}|XF+S,\"x6.]%");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.push_back(L"N)ZP-Zt}Yp~YTdip{6.Aa%BH");
		}
		sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg = -31384;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_G7qv3257Dq_xq.push_back(0.293686);
		}
		sbt_Aljk0qQ7tTUEdOs6i84F94w99 = 8721655966296780386;
		sbt_KPbWDbsLdtIP7PrMbJi = 2243470495;
		sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7 = -1170169856;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.push_back(675193339);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_6UGjXd1Mp38WWmabK23Wo3T.push_back(-681635423);
		}
		sbt_kT1 = L"s2)/W%o8Mb1G;>DC][-[E'&`pfOZD~LZ-|c6,xlq";
		sbt_eCFFIbCa6Gx2xdfVyHG0tJ_.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_qz3n8_Tu_Ua4lTcpAtorz *pObject = dynamic_cast<const sbt_qz3n8_Tu_Ua4lTcpAtorz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb.c_str(), pObject->sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb.c_str()))
		{
			return false;
		}
		if (sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.size() != pObject->sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2[i].c_str(), pObject->sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.size() != pObject->sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH[i].c_str(), pObject->sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT != pObject->sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT)
		{
			return false;
		}
		if (sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1 != pObject->sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S.c_str(), pObject->sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S.c_str()))
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR.c_str(), pObject->sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR.c_str()))
		{
			return false;
		}
		if (sbt_auS.size() != pObject->sbt_auS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_auS.size(); i++)
		{
			if (0 != cx_strcmp(sbt_auS[i].c_str(), pObject->sbt_auS[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1 != pObject->sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1)
		{
			return false;
		}
		if (sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.size() != pObject->sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.size(); i++)
		{
			if (0 != cx_strcmp(sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa[i].c_str(), pObject->sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.size() != pObject->sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68[i].c_str(), pObject->sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg != pObject->sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg)
		{
			return false;
		}
		if (sbt_G7qv3257Dq_xq.size() != pObject->sbt_G7qv3257Dq_xq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_G7qv3257Dq_xq.size(); i++)
		{
			if (sbt_G7qv3257Dq_xq[i] != pObject->sbt_G7qv3257Dq_xq[i])
			{
				return false;
			}
		}
		if (sbt_Aljk0qQ7tTUEdOs6i84F94w99 != pObject->sbt_Aljk0qQ7tTUEdOs6i84F94w99)
		{
			return false;
		}
		if (sbt_KPbWDbsLdtIP7PrMbJi != pObject->sbt_KPbWDbsLdtIP7PrMbJi)
		{
			return false;
		}
		if (sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7 != pObject->sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7)
		{
			return false;
		}
		if (sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.size() != pObject->sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.size(); i++)
		{
			if (sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3[i] != pObject->sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3[i])
			{
				return false;
			}
		}
		if (sbt_6UGjXd1Mp38WWmabK23Wo3T.size() != pObject->sbt_6UGjXd1Mp38WWmabK23Wo3T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6UGjXd1Mp38WWmabK23Wo3T.size(); i++)
		{
			if (sbt_6UGjXd1Mp38WWmabK23Wo3T[i] != pObject->sbt_6UGjXd1Mp38WWmabK23Wo3T[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_kT1.c_str(), pObject->sbt_kT1.c_str()))
		{
			return false;
		}
		if (sbt_jtRiVjjdDS2.size() != pObject->sbt_jtRiVjjdDS2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jtRiVjjdDS2.size(); i++)
		{
			if (sbt_jtRiVjjdDS2[i] != pObject->sbt_jtRiVjjdDS2[i])
			{
				return false;
			}
		}
		if (!sbt_eCFFIbCa6Gx2xdfVyHG0tJ_.Compare(&pObject->sbt_eCFFIbCa6Gx2xdfVyHG0tJ_))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb", &sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S", &sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR", &sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_auS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_auS.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_G7qv3257Dq_xq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_G7qv3257Dq_xq.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Aljk0qQ7tTUEdOs6i84F94w99", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Aljk0qQ7tTUEdOs6i84F94w99 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KPbWDbsLdtIP7PrMbJi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KPbWDbsLdtIP7PrMbJi = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6UGjXd1Mp38WWmabK23Wo3T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6UGjXd1Mp38WWmabK23Wo3T.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_kT1", &sbt_kT1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jtRiVjjdDS2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jtRiVjjdDS2.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_eCFFIbCa6Gx2xdfVyHG0tJ_")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_eCFFIbCa6Gx2xdfVyHG0tJ_.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb", sbt_ePr1ko1ve6ddhR47YzhXAy49tcadQi5N4n2ehbb.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.begin(); iter != sbt_uE39faM1G81Kl0GdwQTeheUErLllvUNRdqHIDJqQwzBFe1Ed6ntFnz2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.begin(); iter != sbt_XGIanWIidb514NfBYgKiNEQigQVoSZWNJLgQ2DRdvfHpCqoSdwpkX5jlIgKKtjH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT", (CX::Int64)sbt_s5rMC0hZ3ocm_4b2fNqm4tFfjGXWw7SodeSF0omZTTBKT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1", (CX::Int64)sbt_3Q7vGCSN4sRfKn_gOtRCoiG86qJ8PUQDtdBrYr4EG4NO_FAzBLEU7gxp1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S", sbt_FZxdSc6PDFbRDl5zrvlscikiz52hg2ACb7wh58mJZq9uGfkcj5qd3GDvjUG4U8S.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR", sbt__OVGHJdwVEKQVQd5bP1U29dOl2xOBaBfR.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_auS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_auS.begin(); iter != sbt_auS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1", (CX::Double)sbt_AWi8qiUxzgUhhqGLxk_4hu3y_pFO5rN5kxebW5r6cUuB3EBs8JsI1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.begin(); iter != sbt_iSKFY8kK3JOQmYFgjUkW0VSSnPIsIry2lpoA3Yq5i3iwQFBVbCXzDFrAa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.begin(); iter != sbt_HRPO2YhLNNAmrOU5HOhZi8ynAdf6WRx68.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg", (CX::Int64)sbt_7_M0HdNIofLy9RU73S8zSNlH3HVOoWU4Bjg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_G7qv3257Dq_xq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_G7qv3257Dq_xq.begin(); iter != sbt_G7qv3257Dq_xq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Aljk0qQ7tTUEdOs6i84F94w99", (CX::Int64)sbt_Aljk0qQ7tTUEdOs6i84F94w99)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KPbWDbsLdtIP7PrMbJi", (CX::Int64)sbt_KPbWDbsLdtIP7PrMbJi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7", (CX::Int64)sbt_eaOglXZquHflYQZdRZQky40V6Hndbr8flAJVqFnxIw869C8MoW9sO2Lf7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.begin(); iter != sbt_BxDa0EtQSokzUZuT7txKfAImvieh5YoAxRT3RV2yq7NfTngiJaL4ZCDr7ZGT3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6UGjXd1Mp38WWmabK23Wo3T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_6UGjXd1Mp38WWmabK23Wo3T.begin(); iter != sbt_6UGjXd1Mp38WWmabK23Wo3T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_kT1", sbt_kT1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jtRiVjjdDS2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_jtRiVjjdDS2.begin(); iter != sbt_jtRiVjjdDS2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_eCFFIbCa6Gx2xdfVyHG0tJ_")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_eCFFIbCa6Gx2xdfVyHG0tJ_.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_qz3n8_Tu_Ua4lTcpAtorz>::Type sbt_qz3n8_Tu_Ua4lTcpAtorzArray;

