
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve;
	CX::IO::SimpleBuffers::Int8Array sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc;
	CX::UInt64 sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf;
	CX::IO::SimpleBuffers::UInt64Array sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV;
	CX::Int16 sbt_vHtlqDVhq3s2GAA;
	CX::IO::SimpleBuffers::Int16Array sbt_suBVvNO6o8UF86Lbj;
	CX::IO::SimpleBuffers::Int64Array sbt_b2UEWYx9B7RSx7stUPT7j8Jcm;
	CX::UInt32 sbt_o6kmENML08qitOnzdLTfrFDE4St;
	CX::String sbt_4ptsYCLZuZa7LRDEy;
	CX::Int32 sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5;
	CX::IO::SimpleBuffers::Int16Array sbt_Q;
	CX::IO::SimpleBuffers::UInt8Array sbt_kGp;
	CX::Bool sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q;

	virtual void Reset()
	{
		sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve = 0;
		sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.clear();
		sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf = 0;
		sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.clear();
		sbt_vHtlqDVhq3s2GAA = 0;
		sbt_suBVvNO6o8UF86Lbj.clear();
		sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.clear();
		sbt_o6kmENML08qitOnzdLTfrFDE4St = 0;
		sbt_4ptsYCLZuZa7LRDEy.clear();
		sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5 = 0;
		sbt_Q.clear();
		sbt_kGp.clear();
		sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve = 5451036792889519806;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.push_back(-45);
		}
		sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf = 4302509368664659288;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.push_back(3169237809523475920);
		}
		sbt_vHtlqDVhq3s2GAA = -2771;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_suBVvNO6o8UF86Lbj.push_back(7607);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.push_back(-7633553287720719366);
		}
		sbt_o6kmENML08qitOnzdLTfrFDE4St = 899845443;
		sbt_4ptsYCLZuZa7LRDEy = "[?CTup%^A#lX?+EKEpWP&S:N";
		sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5 = -965169802;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_kGp.push_back(152);
		}
		sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q = true;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s *pObject = dynamic_cast<const sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve != pObject->sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve)
		{
			return false;
		}
		if (sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.size() != pObject->sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.size(); i++)
		{
			if (sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc[i] != pObject->sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc[i])
			{
				return false;
			}
		}
		if (sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf != pObject->sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf)
		{
			return false;
		}
		if (sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.size() != pObject->sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.size(); i++)
		{
			if (sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV[i] != pObject->sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV[i])
			{
				return false;
			}
		}
		if (sbt_vHtlqDVhq3s2GAA != pObject->sbt_vHtlqDVhq3s2GAA)
		{
			return false;
		}
		if (sbt_suBVvNO6o8UF86Lbj.size() != pObject->sbt_suBVvNO6o8UF86Lbj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_suBVvNO6o8UF86Lbj.size(); i++)
		{
			if (sbt_suBVvNO6o8UF86Lbj[i] != pObject->sbt_suBVvNO6o8UF86Lbj[i])
			{
				return false;
			}
		}
		if (sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.size() != pObject->sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.size(); i++)
		{
			if (sbt_b2UEWYx9B7RSx7stUPT7j8Jcm[i] != pObject->sbt_b2UEWYx9B7RSx7stUPT7j8Jcm[i])
			{
				return false;
			}
		}
		if (sbt_o6kmENML08qitOnzdLTfrFDE4St != pObject->sbt_o6kmENML08qitOnzdLTfrFDE4St)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_4ptsYCLZuZa7LRDEy.c_str(), pObject->sbt_4ptsYCLZuZa7LRDEy.c_str()))
		{
			return false;
		}
		if (sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5 != pObject->sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5)
		{
			return false;
		}
		if (sbt_Q.size() != pObject->sbt_Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q.size(); i++)
		{
			if (sbt_Q[i] != pObject->sbt_Q[i])
			{
				return false;
			}
		}
		if (sbt_kGp.size() != pObject->sbt_kGp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kGp.size(); i++)
		{
			if (sbt_kGp[i] != pObject->sbt_kGp[i])
			{
				return false;
			}
		}
		if (sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q != pObject->sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vHtlqDVhq3s2GAA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vHtlqDVhq3s2GAA = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_suBVvNO6o8UF86Lbj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_suBVvNO6o8UF86Lbj.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_b2UEWYx9B7RSx7stUPT7j8Jcm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_o6kmENML08qitOnzdLTfrFDE4St", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_o6kmENML08qitOnzdLTfrFDE4St = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_4ptsYCLZuZa7LRDEy", &sbt_4ptsYCLZuZa7LRDEy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kGp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kGp.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q", &sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve", (CX::Int64)sbt_gHxSQkLlHRRoExuAdKt5Hpuc_ve)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.begin(); iter != sbt_8uCwMorTj6XKgY68xhF4tqKbcGZ8jKocf0vYLjc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf", (CX::Int64)sbt_kaJuT0IXPCgIqwSbrfBrLIbU4TizVW0fyU3Zh3YwaghTjoMryp1x6824v4LJf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.begin(); iter != sbt_14u6CYTrOv3zLdEMdY6EuSJNl892j5hCdiVRyzV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vHtlqDVhq3s2GAA", (CX::Int64)sbt_vHtlqDVhq3s2GAA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_suBVvNO6o8UF86Lbj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_suBVvNO6o8UF86Lbj.begin(); iter != sbt_suBVvNO6o8UF86Lbj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b2UEWYx9B7RSx7stUPT7j8Jcm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.begin(); iter != sbt_b2UEWYx9B7RSx7stUPT7j8Jcm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_o6kmENML08qitOnzdLTfrFDE4St", (CX::Int64)sbt_o6kmENML08qitOnzdLTfrFDE4St)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_4ptsYCLZuZa7LRDEy", sbt_4ptsYCLZuZa7LRDEy.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5", (CX::Int64)sbt_TuUi4m16OTnQew8ycmp712ZCslpnqiMA4h8jqpUFCdezVz5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Q.begin(); iter != sbt_Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kGp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_kGp.begin(); iter != sbt_kGp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q", sbt_SoX2pYTnCVKOI6XwJL8UXiRB2Vm2diPolRGmXfUfbp5wDaS7Q)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s>::Type sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9sArray;

