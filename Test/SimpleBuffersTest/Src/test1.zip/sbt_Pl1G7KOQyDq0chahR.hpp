
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Pl1G7KOQyDq0chahR : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E;
	CX::String sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm;
	CX::IO::SimpleBuffers::Int32Array sbt_m;
	CX::String sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3;
	CX::String sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln;
	CX::UInt64 sbt_1_M;
	CX::Int8 sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy;
	CX::Int16 sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao;
	CX::Int32 sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ;
	CX::UInt64 sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj;
	CX::Int8 sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv;
	CX::Int32 sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3;
	CX::Int8 sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR;
	CX::IO::SimpleBuffers::UInt64Array sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S;
	CX::String sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM;
	CX::Bool sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR;
	CX::UInt32 sbt_JqWnC;
	CX::UInt32 sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe;
	CX::IO::SimpleBuffers::Int32Array sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5;
	CX::UInt8 sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw;
	CX::UInt64 sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM;
	CX::IO::SimpleBuffers::UInt32Array sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo;
	CX::UInt16 sbt_t6DPldrGcSL0nmqMypu;
	CX::IO::SimpleBuffers::Int16Array sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg;
	CX::UInt32 sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu;
	CX::IO::SimpleBuffers::UInt32Array sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB;
	CX::IO::SimpleBuffers::Int32Array sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj;
	CX::UInt8 sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0;
	CX::IO::SimpleBuffers::UInt16Array sbt_tBE8n8Wg6yGJYOK;

	virtual void Reset()
	{
		sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.clear();
		sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm.clear();
		sbt_m.clear();
		sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3.clear();
		sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln.clear();
		sbt_1_M = 0;
		sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy = 0;
		sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao = 0;
		sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ = 0;
		sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj = 0;
		sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv = 0;
		sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3 = 0;
		sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR = 0;
		sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.clear();
		sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM.clear();
		sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR = false;
		sbt_JqWnC = 0;
		sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe = 0;
		sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.clear();
		sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw = 0;
		sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM = 0;
		sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.clear();
		sbt_t6DPldrGcSL0nmqMypu = 0;
		sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.clear();
		sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu = 0;
		sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.clear();
		sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.clear();
		sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0 = 0;
		sbt_tBE8n8Wg6yGJYOK.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.push_back(1082858699);
		}
		sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm = "(o'NwmN{QI?GV#R&l{d2'y}\")7ma_VOM&J";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_m.push_back(181987727);
		}
		sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3 = "cX{\"IJ`Y?KqLAEpQ#M|g`4SR!n:AWbtJXz[>$FX6{oxy?Yi[:OQXN,Vh8";
		sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln = "q|kU3<ye1sOHCKeMZ!*CbA2]&HZZ5'!1AD}!-LtK%}vk6_Qdg6\"*\\N<8$$5";
		sbt_1_M = 13445962688683331952;
		sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy = 33;
		sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao = 31505;
		sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ = 302900166;
		sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj = 14430862546450547382;
		sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv = 94;
		sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3 = 1228514647;
		sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR = -110;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.push_back(6984166712703048214);
		}
		sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM = "Eyw(`9kNJ#^OsMN`|.#{B,D)DgiCr<w]dlKV~f;@u;2S";
		sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR = false;
		sbt_JqWnC = 2959192094;
		sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe = 3697791941;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.push_back(344858243);
		}
		sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw = 37;
		sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM = 15663328869411721224;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.push_back(2739031959);
		}
		sbt_t6DPldrGcSL0nmqMypu = 58906;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.push_back(2678);
		}
		sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu = 660771241;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.push_back(892236110);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.push_back(-1536559272);
		}
		sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0 = 254;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Pl1G7KOQyDq0chahR *pObject = dynamic_cast<const sbt_Pl1G7KOQyDq0chahR *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.size() != pObject->sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.size(); i++)
		{
			if (sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E[i] != pObject->sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm.c_str(), pObject->sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm.c_str()))
		{
			return false;
		}
		if (sbt_m.size() != pObject->sbt_m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m.size(); i++)
		{
			if (sbt_m[i] != pObject->sbt_m[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3.c_str(), pObject->sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln.c_str(), pObject->sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln.c_str()))
		{
			return false;
		}
		if (sbt_1_M != pObject->sbt_1_M)
		{
			return false;
		}
		if (sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy != pObject->sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy)
		{
			return false;
		}
		if (sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao != pObject->sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao)
		{
			return false;
		}
		if (sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ != pObject->sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ)
		{
			return false;
		}
		if (sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj != pObject->sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj)
		{
			return false;
		}
		if (sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv != pObject->sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv)
		{
			return false;
		}
		if (sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3 != pObject->sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3)
		{
			return false;
		}
		if (sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR != pObject->sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR)
		{
			return false;
		}
		if (sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.size() != pObject->sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.size(); i++)
		{
			if (sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S[i] != pObject->sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM.c_str(), pObject->sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM.c_str()))
		{
			return false;
		}
		if (sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR != pObject->sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR)
		{
			return false;
		}
		if (sbt_JqWnC != pObject->sbt_JqWnC)
		{
			return false;
		}
		if (sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe != pObject->sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe)
		{
			return false;
		}
		if (sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.size() != pObject->sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.size(); i++)
		{
			if (sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5[i] != pObject->sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5[i])
			{
				return false;
			}
		}
		if (sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw != pObject->sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw)
		{
			return false;
		}
		if (sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM != pObject->sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM)
		{
			return false;
		}
		if (sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.size() != pObject->sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.size(); i++)
		{
			if (sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo[i] != pObject->sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo[i])
			{
				return false;
			}
		}
		if (sbt_t6DPldrGcSL0nmqMypu != pObject->sbt_t6DPldrGcSL0nmqMypu)
		{
			return false;
		}
		if (sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.size() != pObject->sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.size(); i++)
		{
			if (sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg[i] != pObject->sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg[i])
			{
				return false;
			}
		}
		if (sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu != pObject->sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu)
		{
			return false;
		}
		if (sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.size() != pObject->sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.size(); i++)
		{
			if (sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB[i] != pObject->sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB[i])
			{
				return false;
			}
		}
		if (sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.size() != pObject->sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.size(); i++)
		{
			if (sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj[i] != pObject->sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj[i])
			{
				return false;
			}
		}
		if (sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0 != pObject->sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0)
		{
			return false;
		}
		if (sbt_tBE8n8Wg6yGJYOK.size() != pObject->sbt_tBE8n8Wg6yGJYOK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tBE8n8Wg6yGJYOK.size(); i++)
		{
			if (sbt_tBE8n8Wg6yGJYOK[i] != pObject->sbt_tBE8n8Wg6yGJYOK[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm", &sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3", &sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln", &sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1_M", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1_M = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM", &sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR", &sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JqWnC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JqWnC = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t6DPldrGcSL0nmqMypu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t6DPldrGcSL0nmqMypu = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tBE8n8Wg6yGJYOK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tBE8n8Wg6yGJYOK.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.begin(); iter != sbt_prO5q2u7W4zzYW2h5r8csLT6nfvSEQQ4_hL5g_wwq96XLW6zVe78E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm", sbt_TZrsJBvDxUeVJ2oMxJzZcizUr5vsN50LTNVnFRcFm.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_m.begin(); iter != sbt_m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3", sbt_S8VwobMCtVbPHtVlqkf1gvp9v4N1aIrxjp6S3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln", sbt_CTRsKPez2OQitk9gPwHvimtwaLwakuTc_1Y96bf292a2mMujgln.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1_M", (CX::Int64)sbt_1_M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy", (CX::Int64)sbt_Oaahy5iEaiKp5yjewP01EgpJ715f1KTbJaFkaA1wweTB7Xy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao", (CX::Int64)sbt_RWZEw50iMns7t9U9H_eo2bya7DglUDeQasRWhN3EunB5MSs_mPbLdXGtNgCao)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ", (CX::Int64)sbt_ZvzUE3oKT0dV4STSE6VqIY8EMqnmInhXYIllWrdAaIYsQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj", (CX::Int64)sbt_VmaRPqr11sadaLyZkQMRER6P3R1IRwj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv", (CX::Int64)sbt_2lcSNUo0e3ViSnbSdM69q2MDqnD_NJOW3kPfyhqi6vBdtSth6eH4O2VOkOv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3", (CX::Int64)sbt_KGTwgdYGHzSG_EMZwymRibhRfvBEHBdF8I3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR", (CX::Int64)sbt_ULhhkqBHdAs_fwvmUpTGuakMRZrcsHzFZ9PJR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.begin(); iter != sbt_ChQKZtA8fnRjOlRxhAz7uDxAM287s5W3S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM", sbt_yK56lwd8exzvIB_7lBF6jOhgBlS3bCM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR", sbt_oDQ0p5jW_LIRlpf5TPhV_2UM4YGmiNhzZkw0yupd_9_Yzc6wR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JqWnC", (CX::Int64)sbt_JqWnC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe", (CX::Int64)sbt_GwUqpAOLdbe7pP1gSIRnboWBP4bZe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.begin(); iter != sbt_wCRd66hE9Pw1T1yavb08rPBBtQUNi62qf2L_HvIrv39P13jnDOOX5PjxdUUMsd5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw", (CX::Int64)sbt_JgbZQXzYErMcYYv6CvowmKZNGp5ynSSIRUHV1kfUS07AwvVEw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM", (CX::Int64)sbt_V8H1qAfid3qjCE2007_KC_6kReIvb_p7RhNAva_pelVYgjBPSoM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.begin(); iter != sbt_iwq1JCtGIFjBkaWPLGTmCVSsAUg08qv4nDzJKN7YFQqdXP27HGqE2yseeDo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t6DPldrGcSL0nmqMypu", (CX::Int64)sbt_t6DPldrGcSL0nmqMypu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.begin(); iter != sbt_kJi2q_cMrW_SieUU0RY0ZkNhC17ErSKVfUi8l5evn0pik2qXuvg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu", (CX::Int64)sbt_n9zWu4lmrc79TOi0vFeCRk_k9vHAaCtO1r5xWVdGu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.begin(); iter != sbt_yVRsnRNqYboGyRM0r4oPP59VfmXHTiuYl7SqMQpv4N2KB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.begin(); iter != sbt_sm8SGbKyJPYzmNq8_ro2SnLokVj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0", (CX::Int64)sbt_mQt1IV2Pp7tCk2pwhWAsFNqjKGj6LebH1FVBoC0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tBE8n8Wg6yGJYOK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_tBE8n8Wg6yGJYOK.begin(); iter != sbt_tBE8n8Wg6yGJYOK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Pl1G7KOQyDq0chahR>::Type sbt_Pl1G7KOQyDq0chahRArray;

