
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jVSCkaD5dp1.hpp"


class sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS;
	CX::Float sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30;
	CX::WString sbt_u;
	CX::IO::SimpleBuffers::WStringArray sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ;
	CX::Int16 sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3;
	CX::IO::SimpleBuffers::Int8Array sbt_xQ7ev;
	CX::String sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA;
	CX::UInt8 sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt;
	CX::IO::SimpleBuffers::FloatArray sbt_2yTjHYp;
	sbt_jVSCkaD5dp1 sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu;

	virtual void Reset()
	{
		sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.clear();
		sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30 = 0.0f;
		sbt_u.clear();
		sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.clear();
		sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3 = 0;
		sbt_xQ7ev.clear();
		sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA.clear();
		sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt = 0;
		sbt_2yTjHYp.clear();
		sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.push_back(12462443636579560496);
		}
		sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30 = 0.517984f;
		sbt_u = L"HoyjG)5jbmF6NaQ`a-_~KTGc)";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.push_back(L"hZYbDVMdW95t#wutGEZ.X2.br[JhxAx");
		}
		sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3 = -19421;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_xQ7ev.push_back(-99);
		}
		sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA = ">+D,!/d?>F=D0i\\Rs|ISr}p)gGzrEaVqJn@If[?V6K";
		sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt = 55;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_2yTjHYp.push_back(0.633165f);
		}
		sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B *pObject = dynamic_cast<const sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.size() != pObject->sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.size(); i++)
		{
			if (sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS[i] != pObject->sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS[i])
			{
				return false;
			}
		}
		if (sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30 != pObject->sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_u.c_str(), pObject->sbt_u.c_str()))
		{
			return false;
		}
		if (sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.size() != pObject->sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ[i].c_str(), pObject->sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3 != pObject->sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3)
		{
			return false;
		}
		if (sbt_xQ7ev.size() != pObject->sbt_xQ7ev.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xQ7ev.size(); i++)
		{
			if (sbt_xQ7ev[i] != pObject->sbt_xQ7ev[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA.c_str(), pObject->sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA.c_str()))
		{
			return false;
		}
		if (sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt != pObject->sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt)
		{
			return false;
		}
		if (sbt_2yTjHYp.size() != pObject->sbt_2yTjHYp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2yTjHYp.size(); i++)
		{
			if (sbt_2yTjHYp[i] != pObject->sbt_2yTjHYp[i])
			{
				return false;
			}
		}
		if (!sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu.Compare(&pObject->sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_u", &sbt_u)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xQ7ev")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xQ7ev.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA", &sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2yTjHYp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2yTjHYp.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu")).IsNOK())
		{
			return status;
		}
		if ((status = sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.begin(); iter != sbt_wfeWOQqTsNlcQMWTpDPRDV9DBEIx1fxacLS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30", (CX::Double)sbt_QESOPo32NhA_U3VyVsUJHO6F629DY_pft3nYmzVQGe_xBeG30)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_u", sbt_u.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.begin(); iter != sbt_hL1yLY_T0sXn9IWWhiBgqqYpnGKqaLtYqjq2J0q_erdjlWdn2VQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3", (CX::Int64)sbt_ggGDmsTIjZwq73eLrZ3QxjJrhA6vngDXMwHmeDewIQVai02hoURP3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xQ7ev")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_xQ7ev.begin(); iter != sbt_xQ7ev.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA", sbt_MlJNjtdkxV27ADk6Nbtnhj_uHuxlDMNj_8XS4dnf_OCTPzsjOQz0TjBXOOpwUYA.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt", (CX::Int64)sbt_XwyK11ZACUrWw78oNBvY3FeuyQmQj69UrRsOt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2yTjHYp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_2yTjHYp.begin(); iter != sbt_2yTjHYp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu")).IsNOK())
		{
			return status;
		}
		if ((status = sbt__9PuqWwfd2MelX2a9jCVXXIfRNpPvgvmxtSumSfrwtQGMd8XsF0a_Z_NhRBuLUu.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B>::Type sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_BArray;

