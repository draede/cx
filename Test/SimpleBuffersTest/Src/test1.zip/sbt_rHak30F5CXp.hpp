
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1.hpp"


class sbt_rHak30F5CXp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_35uPRVKXyrT;
	CX::IO::SimpleBuffers::BoolArray sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J;
	CX::IO::SimpleBuffers::FloatArray sbt_hV3nO;
	CX::Int32 sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe;
	CX::Float sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc;
	CX::IO::SimpleBuffers::UInt8Array sbt_lbDIw;
	CX::Int8 sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi;
	CX::Double sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU;
	CX::WString sbt_Q3Oj5RdXWx3CfWvmqDk;
	CX::IO::SimpleBuffers::UInt16Array sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7;
	CX::String sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p;
	CX::IO::SimpleBuffers::UInt64Array sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS;
	sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1 sbt_EPtfKwLKrNgaKlqrf;

	virtual void Reset()
	{
		sbt_35uPRVKXyrT.clear();
		sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.clear();
		sbt_hV3nO.clear();
		sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe = 0;
		sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc = 0.0f;
		sbt_lbDIw.clear();
		sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi = 0;
		sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU = 0.0;
		sbt_Q3Oj5RdXWx3CfWvmqDk.clear();
		sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.clear();
		sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p.clear();
		sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.clear();
		sbt_EPtfKwLKrNgaKlqrf.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_35uPRVKXyrT.push_back(false);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.push_back(true);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_hV3nO.push_back(0.786877f);
		}
		sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe = 958958149;
		sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc = 0.016504f;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_lbDIw.push_back(101);
		}
		sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi = -32;
		sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU = 0.512819;
		sbt_Q3Oj5RdXWx3CfWvmqDk = L"$qFq:>\\~S}w#xWe=\"/yL2K~}$l;aTi_`@";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.push_back(64948);
		}
		sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p = "G__M#=KuUBM1u&,2Uj(#s!pG~T1kN1U?+3Du;rt0Le{dZ})7|97";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.push_back(6677078126708581476);
		}
		sbt_EPtfKwLKrNgaKlqrf.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_rHak30F5CXp *pObject = dynamic_cast<const sbt_rHak30F5CXp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_35uPRVKXyrT.size() != pObject->sbt_35uPRVKXyrT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_35uPRVKXyrT.size(); i++)
		{
			if (sbt_35uPRVKXyrT[i] != pObject->sbt_35uPRVKXyrT[i])
			{
				return false;
			}
		}
		if (sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.size() != pObject->sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.size(); i++)
		{
			if (sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J[i] != pObject->sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J[i])
			{
				return false;
			}
		}
		if (sbt_hV3nO.size() != pObject->sbt_hV3nO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hV3nO.size(); i++)
		{
			if (sbt_hV3nO[i] != pObject->sbt_hV3nO[i])
			{
				return false;
			}
		}
		if (sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe != pObject->sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe)
		{
			return false;
		}
		if (sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc != pObject->sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc)
		{
			return false;
		}
		if (sbt_lbDIw.size() != pObject->sbt_lbDIw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lbDIw.size(); i++)
		{
			if (sbt_lbDIw[i] != pObject->sbt_lbDIw[i])
			{
				return false;
			}
		}
		if (sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi != pObject->sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi)
		{
			return false;
		}
		if (sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU != pObject->sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_Q3Oj5RdXWx3CfWvmqDk.c_str(), pObject->sbt_Q3Oj5RdXWx3CfWvmqDk.c_str()))
		{
			return false;
		}
		if (sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.size() != pObject->sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.size(); i++)
		{
			if (sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7[i] != pObject->sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p.c_str(), pObject->sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p.c_str()))
		{
			return false;
		}
		if (sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.size() != pObject->sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.size(); i++)
		{
			if (sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS[i] != pObject->sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS[i])
			{
				return false;
			}
		}
		if (!sbt_EPtfKwLKrNgaKlqrf.Compare(&pObject->sbt_EPtfKwLKrNgaKlqrf))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_35uPRVKXyrT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_35uPRVKXyrT.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hV3nO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hV3nO.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_lbDIw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lbDIw.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_Q3Oj5RdXWx3CfWvmqDk", &sbt_Q3Oj5RdXWx3CfWvmqDk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p", &sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_EPtfKwLKrNgaKlqrf")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_EPtfKwLKrNgaKlqrf.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_35uPRVKXyrT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_35uPRVKXyrT.begin(); iter != sbt_35uPRVKXyrT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.begin(); iter != sbt_TfTTjKlqzjIcaFpAh7AF0b6fprg8J.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hV3nO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_hV3nO.begin(); iter != sbt_hV3nO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe", (CX::Int64)sbt_0jr8aA1uNCLABlIpa6yixppmo6YUHd1yCYe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc", (CX::Double)sbt_HrNkQlA4rvbvTSE6YJyO_GD9MofPpe6E3WmUoBc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lbDIw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_lbDIw.begin(); iter != sbt_lbDIw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi", (CX::Int64)sbt_dMuJyyS8ufdqSlBR0A_trkMBCLi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU", (CX::Double)sbt_8sAAIiNlWQAuXMOQdtRSYmzFnDU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_Q3Oj5RdXWx3CfWvmqDk", sbt_Q3Oj5RdXWx3CfWvmqDk.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.begin(); iter != sbt_ZwKsY62Ckv7hfRHZ0Acms5cI7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p", sbt_RHJz9HWUCNYQoKm8C2oiy1J6oqrToCJ1klU8V1UAunkuI2BAcmaFfjVRRZ_3p.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.begin(); iter != sbt_v5SBidkW9MDnzAwiYYCE_U0oCz_8QHYFzi8dMCnfPigJXFpMFKS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_EPtfKwLKrNgaKlqrf")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_EPtfKwLKrNgaKlqrf.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_rHak30F5CXp>::Type sbt_rHak30F5CXpArray;

