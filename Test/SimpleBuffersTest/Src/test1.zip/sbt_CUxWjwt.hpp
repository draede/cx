
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_CUxWjwt : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ;
	CX::IO::SimpleBuffers::Int32Array sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U;
	CX::Int8 sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF;
	CX::UInt32 sbt_KUvFjtFz3wYpgpQbxAAi8kl4u;
	CX::IO::SimpleBuffers::Int32Array sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__;
	CX::IO::SimpleBuffers::StringArray sbt_D;
	CX::IO::SimpleBuffers::StringArray sbt_PO5SGwO67;
	CX::String sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9;
	CX::UInt32 sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb;
	CX::Int64 sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO;
	CX::UInt16 sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30;
	CX::IO::SimpleBuffers::UInt16Array sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY;
	CX::Int64 sbt_fNiRoG3MhseUVyx7bOXbvyR;
	CX::IO::SimpleBuffers::StringArray sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk;
	CX::IO::SimpleBuffers::UInt64Array sbt_aRK5FZ4mk;
	CX::UInt16 sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX;
	CX::Int32 sbt_PkzdKPFc0tORHTFJ9ea5Z;
	CX::Int8 sbt_dZY;
	CX::Int8 sbt_VHerwvTEJ;
	CX::UInt8 sbt_PIaJwOgkJOH_0P3j1;
	CX::IO::SimpleBuffers::UInt16Array sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg;
	CX::UInt8 sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_;
	CX::IO::SimpleBuffers::UInt16Array sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf;
	CX::IO::SimpleBuffers::UInt32Array sbt_DCsU8KCSUGRNNNY8Q9yYd;
	CX::IO::SimpleBuffers::UInt16Array sbt_yT2;
	CX::IO::SimpleBuffers::UInt32Array sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne;

	virtual void Reset()
	{
		sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ = 0;
		sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.clear();
		sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF = 0;
		sbt_KUvFjtFz3wYpgpQbxAAi8kl4u = 0;
		sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.clear();
		sbt_D.clear();
		sbt_PO5SGwO67.clear();
		sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9.clear();
		sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb = 0;
		sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO = 0;
		sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30 = 0;
		sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.clear();
		sbt_fNiRoG3MhseUVyx7bOXbvyR = 0;
		sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.clear();
		sbt_aRK5FZ4mk.clear();
		sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX = 0;
		sbt_PkzdKPFc0tORHTFJ9ea5Z = 0;
		sbt_dZY = 0;
		sbt_VHerwvTEJ = 0;
		sbt_PIaJwOgkJOH_0P3j1 = 0;
		sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.clear();
		sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_ = 0;
		sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.clear();
		sbt_DCsU8KCSUGRNNNY8Q9yYd.clear();
		sbt_yT2.clear();
		sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ = 8062117151201320580;
		sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF = 44;
		sbt_KUvFjtFz3wYpgpQbxAAi8kl4u = 3720165537;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.push_back(792156703);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_D.push_back("%%JEOk9W<(sQP4D`8e|O06{<");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_PO5SGwO67.push_back("ZVwh9%TmEK}lBEVX^k[S`-sJFn0Ki>;`,#3;mrD9a}$p<*+gEbR.9I%}V^\\/}");
		}
		sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9 = "$5S~6Q]QyX7>Q~]\"42KA>6e-m";
		sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb = 1661143251;
		sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO = -4174094855099978928;
		sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30 = 26434;
		sbt_fNiRoG3MhseUVyx7bOXbvyR = -8543080445959017790;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.push_back("jMo<Gp");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_aRK5FZ4mk.push_back(16347129675758497382);
		}
		sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX = 65167;
		sbt_PkzdKPFc0tORHTFJ9ea5Z = 1713151728;
		sbt_dZY = -112;
		sbt_VHerwvTEJ = -85;
		sbt_PIaJwOgkJOH_0P3j1 = 173;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.push_back(64695);
		}
		sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_ = 3;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.push_back(6293);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_DCsU8KCSUGRNNNY8Q9yYd.push_back(1768350873);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_yT2.push_back(20587);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.push_back(1979233046);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_CUxWjwt *pObject = dynamic_cast<const sbt_CUxWjwt *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ != pObject->sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ)
		{
			return false;
		}
		if (sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.size() != pObject->sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.size(); i++)
		{
			if (sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U[i] != pObject->sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U[i])
			{
				return false;
			}
		}
		if (sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF != pObject->sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF)
		{
			return false;
		}
		if (sbt_KUvFjtFz3wYpgpQbxAAi8kl4u != pObject->sbt_KUvFjtFz3wYpgpQbxAAi8kl4u)
		{
			return false;
		}
		if (sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.size() != pObject->sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.size(); i++)
		{
			if (sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__[i] != pObject->sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__[i])
			{
				return false;
			}
		}
		if (sbt_D.size() != pObject->sbt_D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D.size(); i++)
		{
			if (0 != cx_strcmp(sbt_D[i].c_str(), pObject->sbt_D[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_PO5SGwO67.size() != pObject->sbt_PO5SGwO67.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PO5SGwO67.size(); i++)
		{
			if (0 != cx_strcmp(sbt_PO5SGwO67[i].c_str(), pObject->sbt_PO5SGwO67[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9.c_str(), pObject->sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9.c_str()))
		{
			return false;
		}
		if (sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb != pObject->sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb)
		{
			return false;
		}
		if (sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO != pObject->sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO)
		{
			return false;
		}
		if (sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30 != pObject->sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30)
		{
			return false;
		}
		if (sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.size() != pObject->sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.size(); i++)
		{
			if (sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY[i] != pObject->sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY[i])
			{
				return false;
			}
		}
		if (sbt_fNiRoG3MhseUVyx7bOXbvyR != pObject->sbt_fNiRoG3MhseUVyx7bOXbvyR)
		{
			return false;
		}
		if (sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.size() != pObject->sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.size(); i++)
		{
			if (0 != cx_strcmp(sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk[i].c_str(), pObject->sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_aRK5FZ4mk.size() != pObject->sbt_aRK5FZ4mk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aRK5FZ4mk.size(); i++)
		{
			if (sbt_aRK5FZ4mk[i] != pObject->sbt_aRK5FZ4mk[i])
			{
				return false;
			}
		}
		if (sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX != pObject->sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX)
		{
			return false;
		}
		if (sbt_PkzdKPFc0tORHTFJ9ea5Z != pObject->sbt_PkzdKPFc0tORHTFJ9ea5Z)
		{
			return false;
		}
		if (sbt_dZY != pObject->sbt_dZY)
		{
			return false;
		}
		if (sbt_VHerwvTEJ != pObject->sbt_VHerwvTEJ)
		{
			return false;
		}
		if (sbt_PIaJwOgkJOH_0P3j1 != pObject->sbt_PIaJwOgkJOH_0P3j1)
		{
			return false;
		}
		if (sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.size() != pObject->sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.size(); i++)
		{
			if (sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg[i] != pObject->sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg[i])
			{
				return false;
			}
		}
		if (sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_ != pObject->sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_)
		{
			return false;
		}
		if (sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.size() != pObject->sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.size(); i++)
		{
			if (sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf[i] != pObject->sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf[i])
			{
				return false;
			}
		}
		if (sbt_DCsU8KCSUGRNNNY8Q9yYd.size() != pObject->sbt_DCsU8KCSUGRNNNY8Q9yYd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DCsU8KCSUGRNNNY8Q9yYd.size(); i++)
		{
			if (sbt_DCsU8KCSUGRNNNY8Q9yYd[i] != pObject->sbt_DCsU8KCSUGRNNNY8Q9yYd[i])
			{
				return false;
			}
		}
		if (sbt_yT2.size() != pObject->sbt_yT2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yT2.size(); i++)
		{
			if (sbt_yT2[i] != pObject->sbt_yT2[i])
			{
				return false;
			}
		}
		if (sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.size() != pObject->sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.size(); i++)
		{
			if (sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne[i] != pObject->sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KUvFjtFz3wYpgpQbxAAi8kl4u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KUvFjtFz3wYpgpQbxAAi8kl4u = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PO5SGwO67")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PO5SGwO67.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9", &sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fNiRoG3MhseUVyx7bOXbvyR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fNiRoG3MhseUVyx7bOXbvyR = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aRK5FZ4mk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aRK5FZ4mk.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_PkzdKPFc0tORHTFJ9ea5Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PkzdKPFc0tORHTFJ9ea5Z = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dZY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dZY = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VHerwvTEJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VHerwvTEJ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_PIaJwOgkJOH_0P3j1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PIaJwOgkJOH_0P3j1 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_ = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DCsU8KCSUGRNNNY8Q9yYd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DCsU8KCSUGRNNNY8Q9yYd.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yT2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yT2.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ", (CX::Int64)sbt_HhWLpTtwgrFd4tufIS0u6HWCAKqKHRZWOSSDPRLQt155_8OWpIBGCUdKqcZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.begin(); iter != sbt_MSOUy7G9WJma7PnQs4Og4AXDPaL6GXQP_M16U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF", (CX::Int64)sbt_Jpg798Uns06HTZdNpoJqyxZlxkLGWqnBDXhoeqamSMD5grLPF97HhwztJb9IcvF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KUvFjtFz3wYpgpQbxAAi8kl4u", (CX::Int64)sbt_KUvFjtFz3wYpgpQbxAAi8kl4u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.begin(); iter != sbt_tc18wQF_Q83_vxgSRjYlcx0c8HF__.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_D.begin(); iter != sbt_D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PO5SGwO67")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_PO5SGwO67.begin(); iter != sbt_PO5SGwO67.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9", sbt_4CGQbScsXunzvRo7pMNkwDqsq5TkMyI0VE9.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb", (CX::Int64)sbt_ptv6MoXHWRoOLqLjZmQA5JavTNOLN57y8mi0utYt7yb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO", (CX::Int64)sbt_Tz3MhTTEVzI64qc_ZbvZZx7uxhqR85AcXltTWsCMfaFriAa40LO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30", (CX::Int64)sbt_zKVGJKh0x7ZvXT142PCkXIwnJid8J8gA3cdFooS0aZrGNzFPcWpLVdI30)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.begin(); iter != sbt_3GI0TikXhSCqL70TnDJaZN15BXv5JOoZ0XQX33NvMAgPunuRupcQJ49sY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fNiRoG3MhseUVyx7bOXbvyR", (CX::Int64)sbt_fNiRoG3MhseUVyx7bOXbvyR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.begin(); iter != sbt_A_O1l0dCs3t8h5lM1YfDBBys27yYKnunAYREXz1QPBlB_dT6PpmDk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aRK5FZ4mk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_aRK5FZ4mk.begin(); iter != sbt_aRK5FZ4mk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX", (CX::Int64)sbt_BgiGp34mWtXUDYgeOrgvYsdHW42UX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PkzdKPFc0tORHTFJ9ea5Z", (CX::Int64)sbt_PkzdKPFc0tORHTFJ9ea5Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dZY", (CX::Int64)sbt_dZY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VHerwvTEJ", (CX::Int64)sbt_VHerwvTEJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PIaJwOgkJOH_0P3j1", (CX::Int64)sbt_PIaJwOgkJOH_0P3j1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.begin(); iter != sbt_9lkrl7TG34wwF0RBXhBPOMgRjD8ZIe9ory8plgg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_", (CX::Int64)sbt_ujzNtTR_iTuXZduiHmv6hDR2DklHWXATYWM4lQAymTnw6QcFFS_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.begin(); iter != sbt_qd3ZJeKOaF_kme4WMlqvSIitLxn_HVoGqmf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DCsU8KCSUGRNNNY8Q9yYd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_DCsU8KCSUGRNNNY8Q9yYd.begin(); iter != sbt_DCsU8KCSUGRNNNY8Q9yYd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yT2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_yT2.begin(); iter != sbt_yT2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.begin(); iter != sbt_rb4UDzkgDxU3JEjec49hdAY8p2qR4Q81RCWYPcXmnG1ne.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_CUxWjwt>::Type sbt_CUxWjwtArray;

