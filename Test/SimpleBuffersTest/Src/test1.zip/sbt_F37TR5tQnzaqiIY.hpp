
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_F37TR5tQnzaqiIY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa;
	CX::Int32 sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw;
	CX::IO::SimpleBuffers::Int64Array sbt_ukRggQgK_pz;
	CX::Int16 sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv;
	CX::Int64 sbt_mEoNVhmZhmdRGH4UZ8CVrSw;
	CX::IO::SimpleBuffers::UInt64Array sbt_McEJmZbthDDkYfm0LeIDM;
	CX::IO::SimpleBuffers::StringArray sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1;
	CX::Int32 sbt_fMH4Zvlu5_Y;
	CX::UInt16 sbt_UCZIzKWvzy3CqDF;
	CX::Int16 sbt_OUJmoSVT92ojA;
	CX::Int16 sbt_T;
	CX::UInt32 sbt_SGvC_;
	CX::IO::SimpleBuffers::Int64Array sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya;
	CX::IO::SimpleBuffers::Int32Array sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU;
	CX::UInt16 sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b;
	CX::Int16 sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf;
	CX::UInt32 sbt_nfwQP;
	CX::IO::SimpleBuffers::UInt32Array sbt_3NfnSoe9MnW;
	CX::Int64 sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73;
	CX::UInt16 sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt;
	CX::IO::SimpleBuffers::UInt16Array sbt_8y8sM;
	CX::UInt64 sbt_7v1kSbAeLEm;

	virtual void Reset()
	{
		sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa = 0;
		sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw = 0;
		sbt_ukRggQgK_pz.clear();
		sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv = 0;
		sbt_mEoNVhmZhmdRGH4UZ8CVrSw = 0;
		sbt_McEJmZbthDDkYfm0LeIDM.clear();
		sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.clear();
		sbt_fMH4Zvlu5_Y = 0;
		sbt_UCZIzKWvzy3CqDF = 0;
		sbt_OUJmoSVT92ojA = 0;
		sbt_T = 0;
		sbt_SGvC_ = 0;
		sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.clear();
		sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.clear();
		sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b = 0;
		sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf = 0;
		sbt_nfwQP = 0;
		sbt_3NfnSoe9MnW.clear();
		sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73 = 0;
		sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt = 0;
		sbt_8y8sM.clear();
		sbt_7v1kSbAeLEm = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa = 46;
		sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw = -2050075848;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_ukRggQgK_pz.push_back(-1296908044918874180);
		}
		sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv = -15063;
		sbt_mEoNVhmZhmdRGH4UZ8CVrSw = -8270736686672835824;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.push_back("`|)pc_:/}rsuY0QD{5DCu}S8&~~~");
		}
		sbt_fMH4Zvlu5_Y = -1685812774;
		sbt_UCZIzKWvzy3CqDF = 53853;
		sbt_OUJmoSVT92ojA = 12255;
		sbt_T = -11371;
		sbt_SGvC_ = 3380783274;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.push_back(-1109292746705383704);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.push_back(1215868758);
		}
		sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b = 15890;
		sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf = -950;
		sbt_nfwQP = 2179143069;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_3NfnSoe9MnW.push_back(1271917701);
		}
		sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73 = -283623409379029450;
		sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt = 44157;
		sbt_7v1kSbAeLEm = 1333921442013703648;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_F37TR5tQnzaqiIY *pObject = dynamic_cast<const sbt_F37TR5tQnzaqiIY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa != pObject->sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa)
		{
			return false;
		}
		if (sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw != pObject->sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw)
		{
			return false;
		}
		if (sbt_ukRggQgK_pz.size() != pObject->sbt_ukRggQgK_pz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ukRggQgK_pz.size(); i++)
		{
			if (sbt_ukRggQgK_pz[i] != pObject->sbt_ukRggQgK_pz[i])
			{
				return false;
			}
		}
		if (sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv != pObject->sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv)
		{
			return false;
		}
		if (sbt_mEoNVhmZhmdRGH4UZ8CVrSw != pObject->sbt_mEoNVhmZhmdRGH4UZ8CVrSw)
		{
			return false;
		}
		if (sbt_McEJmZbthDDkYfm0LeIDM.size() != pObject->sbt_McEJmZbthDDkYfm0LeIDM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_McEJmZbthDDkYfm0LeIDM.size(); i++)
		{
			if (sbt_McEJmZbthDDkYfm0LeIDM[i] != pObject->sbt_McEJmZbthDDkYfm0LeIDM[i])
			{
				return false;
			}
		}
		if (sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.size() != pObject->sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.size(); i++)
		{
			if (0 != cx_strcmp(sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1[i].c_str(), pObject->sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_fMH4Zvlu5_Y != pObject->sbt_fMH4Zvlu5_Y)
		{
			return false;
		}
		if (sbt_UCZIzKWvzy3CqDF != pObject->sbt_UCZIzKWvzy3CqDF)
		{
			return false;
		}
		if (sbt_OUJmoSVT92ojA != pObject->sbt_OUJmoSVT92ojA)
		{
			return false;
		}
		if (sbt_T != pObject->sbt_T)
		{
			return false;
		}
		if (sbt_SGvC_ != pObject->sbt_SGvC_)
		{
			return false;
		}
		if (sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.size() != pObject->sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.size(); i++)
		{
			if (sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya[i] != pObject->sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya[i])
			{
				return false;
			}
		}
		if (sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.size() != pObject->sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.size(); i++)
		{
			if (sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU[i] != pObject->sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU[i])
			{
				return false;
			}
		}
		if (sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b != pObject->sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b)
		{
			return false;
		}
		if (sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf != pObject->sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf)
		{
			return false;
		}
		if (sbt_nfwQP != pObject->sbt_nfwQP)
		{
			return false;
		}
		if (sbt_3NfnSoe9MnW.size() != pObject->sbt_3NfnSoe9MnW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3NfnSoe9MnW.size(); i++)
		{
			if (sbt_3NfnSoe9MnW[i] != pObject->sbt_3NfnSoe9MnW[i])
			{
				return false;
			}
		}
		if (sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73 != pObject->sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73)
		{
			return false;
		}
		if (sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt != pObject->sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt)
		{
			return false;
		}
		if (sbt_8y8sM.size() != pObject->sbt_8y8sM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8y8sM.size(); i++)
		{
			if (sbt_8y8sM[i] != pObject->sbt_8y8sM[i])
			{
				return false;
			}
		}
		if (sbt_7v1kSbAeLEm != pObject->sbt_7v1kSbAeLEm)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ukRggQgK_pz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ukRggQgK_pz.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mEoNVhmZhmdRGH4UZ8CVrSw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mEoNVhmZhmdRGH4UZ8CVrSw = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_McEJmZbthDDkYfm0LeIDM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_McEJmZbthDDkYfm0LeIDM.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fMH4Zvlu5_Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fMH4Zvlu5_Y = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UCZIzKWvzy3CqDF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UCZIzKWvzy3CqDF = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_OUJmoSVT92ojA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OUJmoSVT92ojA = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SGvC_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SGvC_ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nfwQP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nfwQP = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3NfnSoe9MnW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3NfnSoe9MnW.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8y8sM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8y8sM.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7v1kSbAeLEm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7v1kSbAeLEm = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa", (CX::Int64)sbt_4pAQ2wd4LYgNtHz9BcJOU6OgZ5tmGI3rxpAHBHPsa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw", (CX::Int64)sbt__MxSSuOz3CG0AKWUAG4PSaH_RnOUc0PM5Hr0adM9mr2Tw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ukRggQgK_pz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_ukRggQgK_pz.begin(); iter != sbt_ukRggQgK_pz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv", (CX::Int64)sbt_haxy780o84A1Rx8XhELTytZAXr6AGV7K_s1knDD8RIMQCZ3QLUnqOO44jmv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mEoNVhmZhmdRGH4UZ8CVrSw", (CX::Int64)sbt_mEoNVhmZhmdRGH4UZ8CVrSw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_McEJmZbthDDkYfm0LeIDM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_McEJmZbthDDkYfm0LeIDM.begin(); iter != sbt_McEJmZbthDDkYfm0LeIDM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.begin(); iter != sbt_jvgoMZuiCpJAPZtIhxTbBIM7m_PX1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fMH4Zvlu5_Y", (CX::Int64)sbt_fMH4Zvlu5_Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UCZIzKWvzy3CqDF", (CX::Int64)sbt_UCZIzKWvzy3CqDF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OUJmoSVT92ojA", (CX::Int64)sbt_OUJmoSVT92ojA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T", (CX::Int64)sbt_T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SGvC_", (CX::Int64)sbt_SGvC_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.begin(); iter != sbt_G3fRHA3O4YM8qKAdLjsmfFOeEJ03qd1omx_Ya.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.begin(); iter != sbt_5ceyA75_0HLjZv4hch4X9tHYhYJ59wqaKlU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b", (CX::Int64)sbt_iuZDaGA65jGx60wFP4o9H9u7tl9F5z7HvXTgDJMVfgssxZBExpCkIbeLZdruc3b)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf", (CX::Int64)sbt_QItNjmwltMyhGPEfvG9UC9nIeY0HFeoDHXf0mTwCK04RXXr8JBf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nfwQP", (CX::Int64)sbt_nfwQP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3NfnSoe9MnW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_3NfnSoe9MnW.begin(); iter != sbt_3NfnSoe9MnW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73", (CX::Int64)sbt_a0aziTObYut_n2ij_Y1_RJr7JOKi2ywyrkG4HSCzElF73)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt", (CX::Int64)sbt_xQRnRENSROtS7F9ONGFS2NH2iE8eXn6XqyK4djFaRnJpg_GfBBu9WKt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8y8sM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_8y8sM.begin(); iter != sbt_8y8sM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7v1kSbAeLEm", (CX::Int64)sbt_7v1kSbAeLEm)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_F37TR5tQnzaqiIY>::Type sbt_F37TR5tQnzaqiIYArray;

