
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_AfkSTpU1y : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7;
	CX::IO::SimpleBuffers::UInt16Array sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8;
	CX::UInt64 sbt_J66bper9Az4CH;
	CX::IO::SimpleBuffers::UInt64Array sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27;
	CX::IO::SimpleBuffers::UInt64Array sbt_bTDGB;
	CX::IO::SimpleBuffers::Int32Array sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT;
	CX::UInt64 sbt_ljhcW;
	CX::IO::SimpleBuffers::UInt32Array sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ;
	CX::Int64 sbt_jlL;
	CX::UInt8 sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h;
	CX::IO::SimpleBuffers::UInt64Array sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy;
	CX::IO::SimpleBuffers::UInt8Array sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z;

	virtual void Reset()
	{
		sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7 = 0;
		sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.clear();
		sbt_J66bper9Az4CH = 0;
		sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.clear();
		sbt_bTDGB.clear();
		sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.clear();
		sbt_ljhcW = 0;
		sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.clear();
		sbt_jlL = 0;
		sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h = 0;
		sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.clear();
		sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7 = 12947;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.push_back(7814);
		}
		sbt_J66bper9Az4CH = 12089478499624287496;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.push_back(9672216144944935032);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_bTDGB.push_back(8716407806424112534);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.push_back(-1834728478);
		}
		sbt_ljhcW = 13594877090579728744;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.push_back(4187246196);
		}
		sbt_jlL = 2425345178944975246;
		sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h = 243;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.push_back(15148444525090196454);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.push_back(150);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_AfkSTpU1y *pObject = dynamic_cast<const sbt_AfkSTpU1y *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7 != pObject->sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7)
		{
			return false;
		}
		if (sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.size() != pObject->sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.size(); i++)
		{
			if (sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8[i] != pObject->sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8[i])
			{
				return false;
			}
		}
		if (sbt_J66bper9Az4CH != pObject->sbt_J66bper9Az4CH)
		{
			return false;
		}
		if (sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.size() != pObject->sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.size(); i++)
		{
			if (sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27[i] != pObject->sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27[i])
			{
				return false;
			}
		}
		if (sbt_bTDGB.size() != pObject->sbt_bTDGB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bTDGB.size(); i++)
		{
			if (sbt_bTDGB[i] != pObject->sbt_bTDGB[i])
			{
				return false;
			}
		}
		if (sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.size() != pObject->sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.size(); i++)
		{
			if (sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT[i] != pObject->sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT[i])
			{
				return false;
			}
		}
		if (sbt_ljhcW != pObject->sbt_ljhcW)
		{
			return false;
		}
		if (sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.size() != pObject->sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.size(); i++)
		{
			if (sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ[i] != pObject->sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ[i])
			{
				return false;
			}
		}
		if (sbt_jlL != pObject->sbt_jlL)
		{
			return false;
		}
		if (sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h != pObject->sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h)
		{
			return false;
		}
		if (sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.size() != pObject->sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.size(); i++)
		{
			if (sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy[i] != pObject->sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy[i])
			{
				return false;
			}
		}
		if (sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.size() != pObject->sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.size(); i++)
		{
			if (sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z[i] != pObject->sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J66bper9Az4CH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J66bper9Az4CH = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bTDGB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bTDGB.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ljhcW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ljhcW = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jlL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jlL = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7", (CX::Int64)sbt_hSxaDPCwtfvDiBvYJ6NmhAxETjy6vg3ePOrlcBl7M_vPfusNqh23FyJYfqL_7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.begin(); iter != sbt_yTQzWSL0F9b_0xJkTKYi0WpZF3OVTk7S6gz1olmxofmC9qqSOr8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J66bper9Az4CH", (CX::Int64)sbt_J66bper9Az4CH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.begin(); iter != sbt_xYzsyjWdBl0zf43vvT1ERbH_TJL27.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bTDGB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_bTDGB.begin(); iter != sbt_bTDGB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.begin(); iter != sbt_OgQN9uqx0UJ1YvVcUB83uHfN0RsfNVOepfh8vXT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ljhcW", (CX::Int64)sbt_ljhcW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.begin(); iter != sbt_sFxlOMye9sDsXsPCH0Nc5PCb7REDzeZUq0qKjCkjLbWSJ5BcsmsmQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jlL", (CX::Int64)sbt_jlL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h", (CX::Int64)sbt_AKieZoRRSmlzZZ8EBYxGmCIfst9zr6RXJ4EL5aIzsYTNmKX_lj1l_S7tgyC8h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.begin(); iter != sbt_EfgjqM4VN6kE_mwyN8OVSZKZnatDZLVT63WI4XhmiXVn6uhBy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.begin(); iter != sbt_0Pn3xxrbVPvqg_K3I7dAyCHgwFjXFk_fvxLLrnEajselsaF72Hw3k2Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_AfkSTpU1y>::Type sbt_AfkSTpU1yArray;

