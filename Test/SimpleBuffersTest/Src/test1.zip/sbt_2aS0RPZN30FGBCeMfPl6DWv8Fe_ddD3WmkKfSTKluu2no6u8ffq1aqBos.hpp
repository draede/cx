
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP;
	CX::UInt32 sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7;
	CX::IO::SimpleBuffers::Int8Array sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_;
	CX::UInt64 sbt_k;
	CX::IO::SimpleBuffers::UInt16Array sbt_uCt;
	CX::Int64 sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73;
	CX::Int16 sbt_tk6MOE2kREfuS2G5n;
	CX::IO::SimpleBuffers::UInt64Array sbt_0QlRG;
	CX::UInt32 sbt_BB0Kj0ddNAP6himHzUUfK787LIT;
	CX::IO::SimpleBuffers::UInt64Array sbt_rwfCfU74nVD;
	CX::Int64 sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b;
	CX::UInt64 sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt;
	CX::UInt16 sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22;
	CX::IO::SimpleBuffers::UInt32Array sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3;
	CX::String sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ;
	CX::IO::SimpleBuffers::UInt32Array sbt_7yOHKQHarVrqX;
	CX::IO::SimpleBuffers::StringArray sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl;
	CX::UInt64 sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya;
	CX::UInt32 sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo;
	CX::IO::SimpleBuffers::UInt32Array sbt_TOSyM0UJ18O;
	CX::IO::SimpleBuffers::UInt16Array sbt_pFozN;
	CX::Int32 sbt_k_pFvI0_knUL0;
	CX::IO::SimpleBuffers::Int64Array sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5;
	CX::UInt16 sbt_Gjd2DtmuwrmWZP_ejCEGu;

	virtual void Reset()
	{
		sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.clear();
		sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7 = 0;
		sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.clear();
		sbt_k = 0;
		sbt_uCt.clear();
		sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73 = 0;
		sbt_tk6MOE2kREfuS2G5n = 0;
		sbt_0QlRG.clear();
		sbt_BB0Kj0ddNAP6himHzUUfK787LIT = 0;
		sbt_rwfCfU74nVD.clear();
		sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b = 0;
		sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt = 0;
		sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22 = 0;
		sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.clear();
		sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ.clear();
		sbt_7yOHKQHarVrqX.clear();
		sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.clear();
		sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya = 0;
		sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo = 0;
		sbt_TOSyM0UJ18O.clear();
		sbt_pFozN.clear();
		sbt_k_pFvI0_knUL0 = 0;
		sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.clear();
		sbt_Gjd2DtmuwrmWZP_ejCEGu = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.push_back(6356143868025580186);
		}
		sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7 = 369661160;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.push_back(-104);
		}
		sbt_k = 7060450439936079698;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_uCt.push_back(4666);
		}
		sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73 = -3675052336122813260;
		sbt_tk6MOE2kREfuS2G5n = 22592;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_0QlRG.push_back(15207280526397517634);
		}
		sbt_BB0Kj0ddNAP6himHzUUfK787LIT = 2990596519;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_rwfCfU74nVD.push_back(14951764170288796088);
		}
		sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b = -5778657186340764996;
		sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt = 11816129828665967674;
		sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22 = 50200;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.push_back(473940024);
		}
		sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ = "f]_$D&3awm{K4@JHKZWTo.-|Ayi#le[}P]npq8i$b5!'j%e";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_7yOHKQHarVrqX.push_back(3613737245);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.push_back("0lT6#&#2F'9$ovF1tg{4z0g{kz1@");
		}
		sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya = 9977504203671178222;
		sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo = 1989588011;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_TOSyM0UJ18O.push_back(1131857145);
		}
		sbt_k_pFvI0_knUL0 = -1592992557;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.push_back(6057424766208319318);
		}
		sbt_Gjd2DtmuwrmWZP_ejCEGu = 64815;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos *pObject = dynamic_cast<const sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.size() != pObject->sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.size(); i++)
		{
			if (sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP[i] != pObject->sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP[i])
			{
				return false;
			}
		}
		if (sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7 != pObject->sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7)
		{
			return false;
		}
		if (sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.size() != pObject->sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.size(); i++)
		{
			if (sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_[i] != pObject->sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_[i])
			{
				return false;
			}
		}
		if (sbt_k != pObject->sbt_k)
		{
			return false;
		}
		if (sbt_uCt.size() != pObject->sbt_uCt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uCt.size(); i++)
		{
			if (sbt_uCt[i] != pObject->sbt_uCt[i])
			{
				return false;
			}
		}
		if (sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73 != pObject->sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73)
		{
			return false;
		}
		if (sbt_tk6MOE2kREfuS2G5n != pObject->sbt_tk6MOE2kREfuS2G5n)
		{
			return false;
		}
		if (sbt_0QlRG.size() != pObject->sbt_0QlRG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0QlRG.size(); i++)
		{
			if (sbt_0QlRG[i] != pObject->sbt_0QlRG[i])
			{
				return false;
			}
		}
		if (sbt_BB0Kj0ddNAP6himHzUUfK787LIT != pObject->sbt_BB0Kj0ddNAP6himHzUUfK787LIT)
		{
			return false;
		}
		if (sbt_rwfCfU74nVD.size() != pObject->sbt_rwfCfU74nVD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rwfCfU74nVD.size(); i++)
		{
			if (sbt_rwfCfU74nVD[i] != pObject->sbt_rwfCfU74nVD[i])
			{
				return false;
			}
		}
		if (sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b != pObject->sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b)
		{
			return false;
		}
		if (sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt != pObject->sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt)
		{
			return false;
		}
		if (sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22 != pObject->sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22)
		{
			return false;
		}
		if (sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.size() != pObject->sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.size(); i++)
		{
			if (sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3[i] != pObject->sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ.c_str(), pObject->sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ.c_str()))
		{
			return false;
		}
		if (sbt_7yOHKQHarVrqX.size() != pObject->sbt_7yOHKQHarVrqX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7yOHKQHarVrqX.size(); i++)
		{
			if (sbt_7yOHKQHarVrqX[i] != pObject->sbt_7yOHKQHarVrqX[i])
			{
				return false;
			}
		}
		if (sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.size() != pObject->sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.size(); i++)
		{
			if (0 != cx_strcmp(sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl[i].c_str(), pObject->sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya != pObject->sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya)
		{
			return false;
		}
		if (sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo != pObject->sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo)
		{
			return false;
		}
		if (sbt_TOSyM0UJ18O.size() != pObject->sbt_TOSyM0UJ18O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TOSyM0UJ18O.size(); i++)
		{
			if (sbt_TOSyM0UJ18O[i] != pObject->sbt_TOSyM0UJ18O[i])
			{
				return false;
			}
		}
		if (sbt_pFozN.size() != pObject->sbt_pFozN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pFozN.size(); i++)
		{
			if (sbt_pFozN[i] != pObject->sbt_pFozN[i])
			{
				return false;
			}
		}
		if (sbt_k_pFvI0_knUL0 != pObject->sbt_k_pFvI0_knUL0)
		{
			return false;
		}
		if (sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.size() != pObject->sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.size(); i++)
		{
			if (sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5[i] != pObject->sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5[i])
			{
				return false;
			}
		}
		if (sbt_Gjd2DtmuwrmWZP_ejCEGu != pObject->sbt_Gjd2DtmuwrmWZP_ejCEGu)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uCt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uCt.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_tk6MOE2kREfuS2G5n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tk6MOE2kREfuS2G5n = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0QlRG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0QlRG.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BB0Kj0ddNAP6himHzUUfK787LIT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BB0Kj0ddNAP6himHzUUfK787LIT = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rwfCfU74nVD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rwfCfU74nVD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ", &sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7yOHKQHarVrqX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7yOHKQHarVrqX.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TOSyM0UJ18O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TOSyM0UJ18O.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pFozN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pFozN.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k_pFvI0_knUL0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k_pFvI0_knUL0 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Gjd2DtmuwrmWZP_ejCEGu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Gjd2DtmuwrmWZP_ejCEGu = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.begin(); iter != sbt_LiS9iwsTDxz5_udbXue2trV5MikTY4IFsYqeP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7", (CX::Int64)sbt_zjJ6IU3zU18OT8RBETRaCt6XpedUzyHlVyn9mFG1XSz8b0ED7rp1uMahyAge7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.begin(); iter != sbt_w_1eSErTxah6TbMplcnrRbsPyHe9WgXw3HbEc0xi_UgITMkQTEgMhYCTcr_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k", (CX::Int64)sbt_k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uCt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_uCt.begin(); iter != sbt_uCt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73", (CX::Int64)sbt_kkzF9d1o0y_8qcY8qZK1xGBh0XF3dMzux73)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tk6MOE2kREfuS2G5n", (CX::Int64)sbt_tk6MOE2kREfuS2G5n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0QlRG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_0QlRG.begin(); iter != sbt_0QlRG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BB0Kj0ddNAP6himHzUUfK787LIT", (CX::Int64)sbt_BB0Kj0ddNAP6himHzUUfK787LIT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rwfCfU74nVD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_rwfCfU74nVD.begin(); iter != sbt_rwfCfU74nVD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b", (CX::Int64)sbt_Kd4vSmE6yJxu1ow6w1EpJAF5b)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt", (CX::Int64)sbt_j0jL6GTVpbAjETzsiJr5sSVGUGSFsMt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22", (CX::Int64)sbt_M35BpAgOYttfgizx3xj9w7ebuB2OXIbBY22)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.begin(); iter != sbt_sPWzZDFInAjbuqeQ7cCsu1YCP6Cz3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ", sbt_JRH1QliIhT5qx7GwT5hX14QGD3o4ey3nvHg38YVXz4VjpsgtI34naL3argZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7yOHKQHarVrqX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7yOHKQHarVrqX.begin(); iter != sbt_7yOHKQHarVrqX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.begin(); iter != sbt_myoKCQwQvgjJcR8zKmzifBMLrVd7Ew1KgyzlzGIM_q50bAj_dWat2kTmgEl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya", (CX::Int64)sbt_4aP4k9qlSIi3Wpi5Lh0NMlrbQ49qttJYcDQl9h2c6Nv1rxfya)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo", (CX::Int64)sbt_ExZ3_JuqR58TrEU5zFX_1CeTL3UTRDmNo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TOSyM0UJ18O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_TOSyM0UJ18O.begin(); iter != sbt_TOSyM0UJ18O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pFozN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_pFozN.begin(); iter != sbt_pFozN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k_pFvI0_knUL0", (CX::Int64)sbt_k_pFvI0_knUL0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.begin(); iter != sbt_fpwJFuEmYrQ6EBjQ1Zp82TID7a8NOX2RsWclTIMkcCf8PG6TyIjE4h5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Gjd2DtmuwrmWZP_ejCEGu", (CX::Int64)sbt_Gjd2DtmuwrmWZP_ejCEGu)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos>::Type sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBosArray;

