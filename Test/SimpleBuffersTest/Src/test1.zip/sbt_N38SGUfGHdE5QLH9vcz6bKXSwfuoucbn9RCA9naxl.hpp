
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o.hpp"


class sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_M5zwV8achbfUVN8mhsZ5xVT;
	CX::IO::SimpleBuffers::BoolArray sbt_dGfHbVbKHwR;
	CX::Int32 sbt_FZV4gAQKtXB;
	CX::IO::SimpleBuffers::UInt64Array sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb;
	CX::String sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr;
	CX::IO::SimpleBuffers::UInt32Array sbt_mysdTLoEC;
	CX::UInt8 sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU;
	CX::UInt64 sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N;
	CX::UInt32 sbt_aTIcI8xBU;
	CX::UInt16 sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK;
	CX::Float sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u;
	CX::IO::SimpleBuffers::Int32Array sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1;
	CX::Int8 sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI;
	CX::UInt64 sbt_eP_EKcIx1np;
	CX::IO::SimpleBuffers::UInt32Array sbt_IKTcToUzCh4D7wGQZjbi3;
	CX::IO::SimpleBuffers::UInt8Array sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr;
	CX::Int64 sbt_Ytz_4PbWAQWIj;
	CX::IO::SimpleBuffers::UInt64Array sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS;
	CX::IO::SimpleBuffers::UInt64Array sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E;
	CX::IO::SimpleBuffers::UInt32Array sbt_e;
	sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8oArray sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y;

	virtual void Reset()
	{
		sbt_M5zwV8achbfUVN8mhsZ5xVT = 0.0f;
		sbt_dGfHbVbKHwR.clear();
		sbt_FZV4gAQKtXB = 0;
		sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.clear();
		sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr.clear();
		sbt_mysdTLoEC.clear();
		sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU = 0;
		sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N = 0;
		sbt_aTIcI8xBU = 0;
		sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK = 0;
		sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u = 0.0f;
		sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.clear();
		sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI = 0;
		sbt_eP_EKcIx1np = 0;
		sbt_IKTcToUzCh4D7wGQZjbi3.clear();
		sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.clear();
		sbt_Ytz_4PbWAQWIj = 0;
		sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.clear();
		sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.clear();
		sbt_e.clear();
		sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_M5zwV8achbfUVN8mhsZ5xVT = 0.257302f;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_dGfHbVbKHwR.push_back(false);
		}
		sbt_FZV4gAQKtXB = 1690029391;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.push_back(9864911982228560832);
		}
		sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr = "";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_mysdTLoEC.push_back(112092999);
		}
		sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU = 54;
		sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N = 15894232941550860602;
		sbt_aTIcI8xBU = 3446483967;
		sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK = 2157;
		sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u = 0.113613f;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.push_back(-1427024599);
		}
		sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI = 38;
		sbt_eP_EKcIx1np = 10371150172784696548;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_IKTcToUzCh4D7wGQZjbi3.push_back(3152495084);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.push_back(182);
		}
		sbt_Ytz_4PbWAQWIj = 3634534468408196284;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.push_back(513435886683056212);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.push_back(16381757183341014938);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_e.push_back(457193230);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o v;

			v.SetupWithSomeValues();
			sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl *pObject = dynamic_cast<const sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_M5zwV8achbfUVN8mhsZ5xVT != pObject->sbt_M5zwV8achbfUVN8mhsZ5xVT)
		{
			return false;
		}
		if (sbt_dGfHbVbKHwR.size() != pObject->sbt_dGfHbVbKHwR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dGfHbVbKHwR.size(); i++)
		{
			if (sbt_dGfHbVbKHwR[i] != pObject->sbt_dGfHbVbKHwR[i])
			{
				return false;
			}
		}
		if (sbt_FZV4gAQKtXB != pObject->sbt_FZV4gAQKtXB)
		{
			return false;
		}
		if (sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.size() != pObject->sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.size(); i++)
		{
			if (sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb[i] != pObject->sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr.c_str(), pObject->sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr.c_str()))
		{
			return false;
		}
		if (sbt_mysdTLoEC.size() != pObject->sbt_mysdTLoEC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mysdTLoEC.size(); i++)
		{
			if (sbt_mysdTLoEC[i] != pObject->sbt_mysdTLoEC[i])
			{
				return false;
			}
		}
		if (sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU != pObject->sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU)
		{
			return false;
		}
		if (sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N != pObject->sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N)
		{
			return false;
		}
		if (sbt_aTIcI8xBU != pObject->sbt_aTIcI8xBU)
		{
			return false;
		}
		if (sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK != pObject->sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK)
		{
			return false;
		}
		if (sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u != pObject->sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u)
		{
			return false;
		}
		if (sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.size() != pObject->sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.size(); i++)
		{
			if (sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1[i] != pObject->sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1[i])
			{
				return false;
			}
		}
		if (sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI != pObject->sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI)
		{
			return false;
		}
		if (sbt_eP_EKcIx1np != pObject->sbt_eP_EKcIx1np)
		{
			return false;
		}
		if (sbt_IKTcToUzCh4D7wGQZjbi3.size() != pObject->sbt_IKTcToUzCh4D7wGQZjbi3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IKTcToUzCh4D7wGQZjbi3.size(); i++)
		{
			if (sbt_IKTcToUzCh4D7wGQZjbi3[i] != pObject->sbt_IKTcToUzCh4D7wGQZjbi3[i])
			{
				return false;
			}
		}
		if (sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.size() != pObject->sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.size(); i++)
		{
			if (sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr[i] != pObject->sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr[i])
			{
				return false;
			}
		}
		if (sbt_Ytz_4PbWAQWIj != pObject->sbt_Ytz_4PbWAQWIj)
		{
			return false;
		}
		if (sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.size() != pObject->sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.size(); i++)
		{
			if (sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS[i] != pObject->sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS[i])
			{
				return false;
			}
		}
		if (sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.size() != pObject->sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.size(); i++)
		{
			if (sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E[i] != pObject->sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E[i])
			{
				return false;
			}
		}
		if (sbt_e.size() != pObject->sbt_e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_e.size(); i++)
		{
			if (sbt_e[i] != pObject->sbt_e[i])
			{
				return false;
			}
		}
		if (sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.size() != pObject->sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.size(); i++)
		{
			if (!sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y[i].Compare(&pObject->sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_M5zwV8achbfUVN8mhsZ5xVT", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_M5zwV8achbfUVN8mhsZ5xVT = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_dGfHbVbKHwR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dGfHbVbKHwR.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FZV4gAQKtXB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FZV4gAQKtXB = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr", &sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mysdTLoEC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mysdTLoEC.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_aTIcI8xBU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aTIcI8xBU = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectReal("sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eP_EKcIx1np", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eP_EKcIx1np = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IKTcToUzCh4D7wGQZjbi3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IKTcToUzCh4D7wGQZjbi3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Ytz_4PbWAQWIj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ytz_4PbWAQWIj = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_e.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_M5zwV8achbfUVN8mhsZ5xVT", (CX::Double)sbt_M5zwV8achbfUVN8mhsZ5xVT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dGfHbVbKHwR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_dGfHbVbKHwR.begin(); iter != sbt_dGfHbVbKHwR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FZV4gAQKtXB", (CX::Int64)sbt_FZV4gAQKtXB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.begin(); iter != sbt_5m8CYNxgVaH2Kjmebtf0JV5Bj7gVSeb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr", sbt_P1_iWcnSzlfy0gwjL0L10wX3_a_lOdhiXPG4dcAOlONDVarxgiMPalU7PZr.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mysdTLoEC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_mysdTLoEC.begin(); iter != sbt_mysdTLoEC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU", (CX::Int64)sbt_FHxdvDlZTzzKv5KCtXs6gFQo0RzpuXoVU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N", (CX::Int64)sbt__dzktoNphtQKUODKlHPm_RYPLXelqBEGMKd3qBMyASxVztamT0S6QHMPS0N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aTIcI8xBU", (CX::Int64)sbt_aTIcI8xBU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK", (CX::Int64)sbt_YREThH_rYqUoGFuwkm2i5flCShbaYyBFCZK8bvOBK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u", (CX::Double)sbt__S9gygrPPkrMUAWDuD95OaAEWhq7cE0OcnTJ58u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.begin(); iter != sbt_LCBR3w8MU5yUP5DYFdq71g9g6x_xb5WkbAI8aZ66XYAz5OJ7scpN1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI", (CX::Int64)sbt_Rz9kcqxeVExTcHy3DAN7ztnU5dC2tes1zviQhpI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eP_EKcIx1np", (CX::Int64)sbt_eP_EKcIx1np)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IKTcToUzCh4D7wGQZjbi3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_IKTcToUzCh4D7wGQZjbi3.begin(); iter != sbt_IKTcToUzCh4D7wGQZjbi3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.begin(); iter != sbt_Z4k2znngt2SsmRP580crheZa7NjX2iB91JZDmWkENx72eX_gzjr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ytz_4PbWAQWIj", (CX::Int64)sbt_Ytz_4PbWAQWIj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.begin(); iter != sbt_EGj1u6JP1pFaIJjRwe3gjvwnZ6B47PhkYXAOefoCSDs0gJlJelCyY8RGS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.begin(); iter != sbt_o3yiRvW0pP_9dwvJSHp1423pE4FWfeJxh_E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_e.begin(); iter != sbt_e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y")).IsNOK())
		{
			return status;
		}
		for (sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8oArray::const_iterator iter = sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.begin(); iter != sbt_vX21DUH2Hq_G_Iy9ZhvpKPlWpqrDW8y.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl>::Type sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxlArray;

