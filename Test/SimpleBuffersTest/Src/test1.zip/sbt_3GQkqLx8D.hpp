
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_3GQkqLx8D : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_7BFW55rydi0OGspcRLU85JZb1;
	CX::Bool sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m;
	CX::Int8 sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67;
	CX::Int32 sbt_5t5nt6vOSHjIQOyE2;
	CX::IO::SimpleBuffers::StringArray sbt_UZNY1Md;
	CX::UInt64 sbt_mmo;
	CX::Int32 sbt_W09P3C10RF4y28EDM;
	CX::IO::SimpleBuffers::UInt32Array sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C;
	CX::UInt8 sbt_SUpcdMosTCTxPzwC3QBQ4;
	CX::Int32 sbt_TitiHw1KFhLgyzntcRO;
	CX::IO::SimpleBuffers::UInt32Array sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1;
	CX::UInt64 sbt_E5mTtrZngmrNTWmb8I2;
	CX::IO::SimpleBuffers::UInt64Array sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr;
	CX::IO::SimpleBuffers::StringArray sbt_VkqW8;
	CX::IO::SimpleBuffers::UInt16Array sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji;

	virtual void Reset()
	{
		sbt_7BFW55rydi0OGspcRLU85JZb1.clear();
		sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m = false;
		sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67 = 0;
		sbt_5t5nt6vOSHjIQOyE2 = 0;
		sbt_UZNY1Md.clear();
		sbt_mmo = 0;
		sbt_W09P3C10RF4y28EDM = 0;
		sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.clear();
		sbt_SUpcdMosTCTxPzwC3QBQ4 = 0;
		sbt_TitiHw1KFhLgyzntcRO = 0;
		sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.clear();
		sbt_E5mTtrZngmrNTWmb8I2 = 0;
		sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.clear();
		sbt_VkqW8.clear();
		sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_7BFW55rydi0OGspcRLU85JZb1 = "16jkFcvEw>+]5AO''FLP%9jK}1{'~tB6M5l1Y=,2B?4*i=\\(f,NCi)<x<t`yk";
		sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m = false;
		sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67 = -72;
		sbt_5t5nt6vOSHjIQOyE2 = -674529066;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_UZNY1Md.push_back("Kt2ArzEHWa,E@)V)vlc\"Q8J<w1#psEZ?fN5");
		}
		sbt_mmo = 2565974431875939764;
		sbt_W09P3C10RF4y28EDM = -239302060;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.push_back(3473306414);
		}
		sbt_SUpcdMosTCTxPzwC3QBQ4 = 202;
		sbt_TitiHw1KFhLgyzntcRO = 45744007;
		sbt_E5mTtrZngmrNTWmb8I2 = 11271792440455072500;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.push_back(15747629424205473722);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_VkqW8.push_back("MSE/MW`");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.push_back(18600);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3GQkqLx8D *pObject = dynamic_cast<const sbt_3GQkqLx8D *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_7BFW55rydi0OGspcRLU85JZb1.c_str(), pObject->sbt_7BFW55rydi0OGspcRLU85JZb1.c_str()))
		{
			return false;
		}
		if (sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m != pObject->sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m)
		{
			return false;
		}
		if (sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67 != pObject->sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67)
		{
			return false;
		}
		if (sbt_5t5nt6vOSHjIQOyE2 != pObject->sbt_5t5nt6vOSHjIQOyE2)
		{
			return false;
		}
		if (sbt_UZNY1Md.size() != pObject->sbt_UZNY1Md.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UZNY1Md.size(); i++)
		{
			if (0 != cx_strcmp(sbt_UZNY1Md[i].c_str(), pObject->sbt_UZNY1Md[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_mmo != pObject->sbt_mmo)
		{
			return false;
		}
		if (sbt_W09P3C10RF4y28EDM != pObject->sbt_W09P3C10RF4y28EDM)
		{
			return false;
		}
		if (sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.size() != pObject->sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.size(); i++)
		{
			if (sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C[i] != pObject->sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C[i])
			{
				return false;
			}
		}
		if (sbt_SUpcdMosTCTxPzwC3QBQ4 != pObject->sbt_SUpcdMosTCTxPzwC3QBQ4)
		{
			return false;
		}
		if (sbt_TitiHw1KFhLgyzntcRO != pObject->sbt_TitiHw1KFhLgyzntcRO)
		{
			return false;
		}
		if (sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.size() != pObject->sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.size(); i++)
		{
			if (sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1[i] != pObject->sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1[i])
			{
				return false;
			}
		}
		if (sbt_E5mTtrZngmrNTWmb8I2 != pObject->sbt_E5mTtrZngmrNTWmb8I2)
		{
			return false;
		}
		if (sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.size() != pObject->sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.size(); i++)
		{
			if (sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr[i] != pObject->sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr[i])
			{
				return false;
			}
		}
		if (sbt_VkqW8.size() != pObject->sbt_VkqW8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VkqW8.size(); i++)
		{
			if (0 != cx_strcmp(sbt_VkqW8[i].c_str(), pObject->sbt_VkqW8[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.size() != pObject->sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.size(); i++)
		{
			if (sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji[i] != pObject->sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_7BFW55rydi0OGspcRLU85JZb1", &sbt_7BFW55rydi0OGspcRLU85JZb1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m", &sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5t5nt6vOSHjIQOyE2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5t5nt6vOSHjIQOyE2 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UZNY1Md")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UZNY1Md.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mmo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mmo = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_W09P3C10RF4y28EDM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_W09P3C10RF4y28EDM = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SUpcdMosTCTxPzwC3QBQ4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SUpcdMosTCTxPzwC3QBQ4 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TitiHw1KFhLgyzntcRO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TitiHw1KFhLgyzntcRO = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_E5mTtrZngmrNTWmb8I2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E5mTtrZngmrNTWmb8I2 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VkqW8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VkqW8.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_7BFW55rydi0OGspcRLU85JZb1", sbt_7BFW55rydi0OGspcRLU85JZb1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m", sbt_R4JAtfUAJSahuNS_OpOFxSDcaPztxUI2Ei0P7cSRiBAYcKEuu8m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67", (CX::Int64)sbt_A4hOC3J8cXikWyI9JQCl2Kl_FozHztRII9QIHQ8gMRzQ9aF6sjPrMlH67)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5t5nt6vOSHjIQOyE2", (CX::Int64)sbt_5t5nt6vOSHjIQOyE2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UZNY1Md")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_UZNY1Md.begin(); iter != sbt_UZNY1Md.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mmo", (CX::Int64)sbt_mmo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_W09P3C10RF4y28EDM", (CX::Int64)sbt_W09P3C10RF4y28EDM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.begin(); iter != sbt_J_tTmYwFBa4cAU9UMXSIC2ZJ7LzurqN1C.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SUpcdMosTCTxPzwC3QBQ4", (CX::Int64)sbt_SUpcdMosTCTxPzwC3QBQ4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TitiHw1KFhLgyzntcRO", (CX::Int64)sbt_TitiHw1KFhLgyzntcRO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.begin(); iter != sbt_RGHE7IUbeLCyYGsRjREe8eGXIQGt6223UNq6oStMi9juYInMup1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_E5mTtrZngmrNTWmb8I2", (CX::Int64)sbt_E5mTtrZngmrNTWmb8I2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.begin(); iter != sbt_vFChEBEenS3haLJX6IBUc_Oofsle169Y5Pnvfkj7YXt7FluVr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VkqW8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_VkqW8.begin(); iter != sbt_VkqW8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.begin(); iter != sbt_8prOxu6rQgOYOK9pUYaa4I6Vmji.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3GQkqLx8D>::Type sbt_3GQkqLx8DArray;

