
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_EeczX;
	CX::Int64 sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx;
	CX::UInt64 sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh;

	virtual void Reset()
	{
		sbt_EeczX.clear();
		sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx = 0;
		sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_EeczX = "5Jq<>[qI3Wm,\\jU%c7rYwfmpUDws:hANNE>DF7I@BSq}\\a}(Vt(A3]g2$xq04.C";
		sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx = -2675125289790572010;
		sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh = 6467429709468494720;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL *pObject = dynamic_cast<const sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_EeczX.c_str(), pObject->sbt_EeczX.c_str()))
		{
			return false;
		}
		if (sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx != pObject->sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx)
		{
			return false;
		}
		if (sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh != pObject->sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_EeczX", &sbt_EeczX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_EeczX", sbt_EeczX.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx", (CX::Int64)sbt_kkOQBw1dpaTePITyIHCUbGS3EbLSIfbxen0YYsAfXloOqKx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh", (CX::Int64)sbt_ILfrOht62bnEpFV_z9_mxomYwJiHlo2LBfxOjCguF9BYaKBcvnoGw0ecQ5PHh)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL>::Type sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lELArray;

