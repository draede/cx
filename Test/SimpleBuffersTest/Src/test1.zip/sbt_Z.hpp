
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Z : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_etTM6S3kJL4p3KY7M;
	CX::IO::SimpleBuffers::Int32Array sbt_yjKqWxJckC8;
	CX::UInt16 sbt_FhV2I5m_l;
	CX::String sbt_AGaYx;
	CX::IO::SimpleBuffers::UInt64Array sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf;
	CX::Bool sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj;
	CX::Bool sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9;
	CX::IO::SimpleBuffers::UInt8Array sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg;
	CX::Int32 sbt_mKxNacSDSWtvshgOk;
	CX::IO::SimpleBuffers::Int64Array sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG;
	CX::Int8 sbt_ID7PQkjWknQQJ7PgwaPu1;
	CX::UInt16 sbt_GPaxhICzNkG8c0qMu;
	CX::UInt32 sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi;
	CX::IO::SimpleBuffers::UInt16Array sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO;
	CX::IO::SimpleBuffers::UInt32Array sbt_mGJiH;
	CX::IO::SimpleBuffers::BoolArray sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8;
	CX::UInt64 sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq;
	CX::Int64 sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0;
	CX::IO::SimpleBuffers::UInt32Array sbt_h3NYO3CCCANVFyeW1jf8w0q;
	CX::Int8 sbt_HrDK4vxR62ElI1sFhcdIW;
	CX::UInt64 sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x;
	CX::Int16 sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw;
	CX::UInt32 sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7;
	CX::String sbt_1oeoJoaea3fdfF3iOxWJ09j72;
	CX::IO::SimpleBuffers::UInt32Array sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ;
	CX::UInt32 sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD;
	CX::UInt64 sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq;
	CX::UInt64 sbt_k6XaTf67JbF;
	CX::UInt32 sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1;

	virtual void Reset()
	{
		sbt_etTM6S3kJL4p3KY7M = 0;
		sbt_yjKqWxJckC8.clear();
		sbt_FhV2I5m_l = 0;
		sbt_AGaYx.clear();
		sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.clear();
		sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj = false;
		sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9 = false;
		sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.clear();
		sbt_mKxNacSDSWtvshgOk = 0;
		sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.clear();
		sbt_ID7PQkjWknQQJ7PgwaPu1 = 0;
		sbt_GPaxhICzNkG8c0qMu = 0;
		sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi = 0;
		sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.clear();
		sbt_mGJiH.clear();
		sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.clear();
		sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq = 0;
		sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0 = 0;
		sbt_h3NYO3CCCANVFyeW1jf8w0q.clear();
		sbt_HrDK4vxR62ElI1sFhcdIW = 0;
		sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x = 0;
		sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw = 0;
		sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7 = 0;
		sbt_1oeoJoaea3fdfF3iOxWJ09j72.clear();
		sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.clear();
		sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD = 0;
		sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq = 0;
		sbt_k6XaTf67JbF = 0;
		sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_etTM6S3kJL4p3KY7M = 10481;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_yjKqWxJckC8.push_back(-228667962);
		}
		sbt_FhV2I5m_l = 11897;
		sbt_AGaYx = "5'Y3H\\Dt#U?-rLt_L66F/DfK:sD&+bL/4zz;Fc[dH";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.push_back(3612561647052390570);
		}
		sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj = false;
		sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9 = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.push_back(122);
		}
		sbt_mKxNacSDSWtvshgOk = -1299422720;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.push_back(-741810384498096656);
		}
		sbt_ID7PQkjWknQQJ7PgwaPu1 = -70;
		sbt_GPaxhICzNkG8c0qMu = 38188;
		sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi = 1262743211;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.push_back(8548);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_mGJiH.push_back(170939977);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.push_back(true);
		}
		sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq = 4483319841999833298;
		sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0 = -3892999262347296644;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_h3NYO3CCCANVFyeW1jf8w0q.push_back(3723505018);
		}
		sbt_HrDK4vxR62ElI1sFhcdIW = -109;
		sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x = 2861129113471114722;
		sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw = 16659;
		sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7 = 3920301047;
		sbt_1oeoJoaea3fdfF3iOxWJ09j72 = "xviIani@P\\-X(bAg-rL(n|Qo-JqRuI\"9{";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.push_back(1814698189);
		}
		sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD = 2176255627;
		sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq = 1946152995502201166;
		sbt_k6XaTf67JbF = 16225031811726579234;
		sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1 = 1940346950;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Z *pObject = dynamic_cast<const sbt_Z *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_etTM6S3kJL4p3KY7M != pObject->sbt_etTM6S3kJL4p3KY7M)
		{
			return false;
		}
		if (sbt_yjKqWxJckC8.size() != pObject->sbt_yjKqWxJckC8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yjKqWxJckC8.size(); i++)
		{
			if (sbt_yjKqWxJckC8[i] != pObject->sbt_yjKqWxJckC8[i])
			{
				return false;
			}
		}
		if (sbt_FhV2I5m_l != pObject->sbt_FhV2I5m_l)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_AGaYx.c_str(), pObject->sbt_AGaYx.c_str()))
		{
			return false;
		}
		if (sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.size() != pObject->sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.size(); i++)
		{
			if (sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf[i] != pObject->sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf[i])
			{
				return false;
			}
		}
		if (sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj != pObject->sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj)
		{
			return false;
		}
		if (sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9 != pObject->sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9)
		{
			return false;
		}
		if (sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.size() != pObject->sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.size(); i++)
		{
			if (sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg[i] != pObject->sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg[i])
			{
				return false;
			}
		}
		if (sbt_mKxNacSDSWtvshgOk != pObject->sbt_mKxNacSDSWtvshgOk)
		{
			return false;
		}
		if (sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.size() != pObject->sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.size(); i++)
		{
			if (sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG[i] != pObject->sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG[i])
			{
				return false;
			}
		}
		if (sbt_ID7PQkjWknQQJ7PgwaPu1 != pObject->sbt_ID7PQkjWknQQJ7PgwaPu1)
		{
			return false;
		}
		if (sbt_GPaxhICzNkG8c0qMu != pObject->sbt_GPaxhICzNkG8c0qMu)
		{
			return false;
		}
		if (sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi != pObject->sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi)
		{
			return false;
		}
		if (sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.size() != pObject->sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.size(); i++)
		{
			if (sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO[i] != pObject->sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO[i])
			{
				return false;
			}
		}
		if (sbt_mGJiH.size() != pObject->sbt_mGJiH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mGJiH.size(); i++)
		{
			if (sbt_mGJiH[i] != pObject->sbt_mGJiH[i])
			{
				return false;
			}
		}
		if (sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.size() != pObject->sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.size(); i++)
		{
			if (sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8[i] != pObject->sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8[i])
			{
				return false;
			}
		}
		if (sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq != pObject->sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq)
		{
			return false;
		}
		if (sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0 != pObject->sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0)
		{
			return false;
		}
		if (sbt_h3NYO3CCCANVFyeW1jf8w0q.size() != pObject->sbt_h3NYO3CCCANVFyeW1jf8w0q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h3NYO3CCCANVFyeW1jf8w0q.size(); i++)
		{
			if (sbt_h3NYO3CCCANVFyeW1jf8w0q[i] != pObject->sbt_h3NYO3CCCANVFyeW1jf8w0q[i])
			{
				return false;
			}
		}
		if (sbt_HrDK4vxR62ElI1sFhcdIW != pObject->sbt_HrDK4vxR62ElI1sFhcdIW)
		{
			return false;
		}
		if (sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x != pObject->sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x)
		{
			return false;
		}
		if (sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw != pObject->sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw)
		{
			return false;
		}
		if (sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7 != pObject->sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_1oeoJoaea3fdfF3iOxWJ09j72.c_str(), pObject->sbt_1oeoJoaea3fdfF3iOxWJ09j72.c_str()))
		{
			return false;
		}
		if (sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.size() != pObject->sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.size(); i++)
		{
			if (sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ[i] != pObject->sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ[i])
			{
				return false;
			}
		}
		if (sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD != pObject->sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD)
		{
			return false;
		}
		if (sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq != pObject->sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq)
		{
			return false;
		}
		if (sbt_k6XaTf67JbF != pObject->sbt_k6XaTf67JbF)
		{
			return false;
		}
		if (sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1 != pObject->sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_etTM6S3kJL4p3KY7M", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_etTM6S3kJL4p3KY7M = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yjKqWxJckC8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yjKqWxJckC8.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FhV2I5m_l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FhV2I5m_l = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_AGaYx", &sbt_AGaYx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj", &sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9", &sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mKxNacSDSWtvshgOk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mKxNacSDSWtvshgOk = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ID7PQkjWknQQJ7PgwaPu1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ID7PQkjWknQQJ7PgwaPu1 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GPaxhICzNkG8c0qMu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GPaxhICzNkG8c0qMu = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mGJiH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mGJiH.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_h3NYO3CCCANVFyeW1jf8w0q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h3NYO3CCCANVFyeW1jf8w0q.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HrDK4vxR62ElI1sFhcdIW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HrDK4vxR62ElI1sFhcdIW = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_1oeoJoaea3fdfF3iOxWJ09j72", &sbt_1oeoJoaea3fdfF3iOxWJ09j72)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_k6XaTf67JbF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k6XaTf67JbF = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1 = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_etTM6S3kJL4p3KY7M", (CX::Int64)sbt_etTM6S3kJL4p3KY7M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yjKqWxJckC8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_yjKqWxJckC8.begin(); iter != sbt_yjKqWxJckC8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FhV2I5m_l", (CX::Int64)sbt_FhV2I5m_l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_AGaYx", sbt_AGaYx.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.begin(); iter != sbt_nXLQ8ZEIMG8a7kRk36y7Uh6iibbEKk08NUyXr6cybHEbIr4gy3sGxGWklTz4uVf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj", sbt_nnBVSAI2wT54hHRkCHlvri5kYw5eOCvbpInLGeXKj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9", sbt_sCAIImZdAMr9_61_rihZwLtZ8oGBWur4oHlWp69LwkzQyiOCjIJ3RLVG9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.begin(); iter != sbt_ZnuCqSx8qtI56PqozEnvXWAXiD7sbcCEOCg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mKxNacSDSWtvshgOk", (CX::Int64)sbt_mKxNacSDSWtvshgOk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.begin(); iter != sbt_MPOiJpG2Bjlf6a_dSU5b4euwUz1HDNukOvn6N3diErIZrGtfEBG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ID7PQkjWknQQJ7PgwaPu1", (CX::Int64)sbt_ID7PQkjWknQQJ7PgwaPu1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GPaxhICzNkG8c0qMu", (CX::Int64)sbt_GPaxhICzNkG8c0qMu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi", (CX::Int64)sbt_znyOUa33_Lf72BmLc4ReM7G_NiKD_G9fBUVZasInOiXwhqTTi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.begin(); iter != sbt_IWvrLhAOJjwuKjRMOxkQHjduOQNaviO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mGJiH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_mGJiH.begin(); iter != sbt_mGJiH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.begin(); iter != sbt_XBm8cKPtcRPiYNOVDIKL6X07mz8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq", (CX::Int64)sbt_Y9xA4igA5dt6FsGVdG97lnZRGMj4vRSqplNMdzYh7PLwoDkzeEkF3zajUUb5zGq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0", (CX::Int64)sbt_dHZRFqDoDms2E0kBFPTylvjpgnyOb0PZjq5pZj1U_Xm81rIPL1WtRf0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h3NYO3CCCANVFyeW1jf8w0q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_h3NYO3CCCANVFyeW1jf8w0q.begin(); iter != sbt_h3NYO3CCCANVFyeW1jf8w0q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HrDK4vxR62ElI1sFhcdIW", (CX::Int64)sbt_HrDK4vxR62ElI1sFhcdIW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x", (CX::Int64)sbt_BXJdubnaVBoTFpigtpVJQL6w9KiMDOtglBpL1YSDiGTFat08O8x)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw", (CX::Int64)sbt_NK32l0uPVA7n9K3_sXX_X4Cmab0w_Mbe7clnBXI4KvJBEsQeQgdbf6rqw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7", (CX::Int64)sbt_8DYIwek8kav3adda0DXNHMggwPHtYGk4HBf5tN7SAga1093Kxc7LYcYWnT7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_1oeoJoaea3fdfF3iOxWJ09j72", sbt_1oeoJoaea3fdfF3iOxWJ09j72.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.begin(); iter != sbt_I65FlaEIaL26iEpi42ScTg22yka2Dp77MElw5Kf6Togx6tXni7N9GOZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD", (CX::Int64)sbt_32KwAD2oYDC6WKmH5CE2uYIvhVjZNKD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq", (CX::Int64)sbt_7gR6Rg_OgtpiGkUqDXiE1UlcmhNnxbQaSPWqMXGJ3r_jYulVq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k6XaTf67JbF", (CX::Int64)sbt_k6XaTf67JbF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1", (CX::Int64)sbt_k3ygdLzD2n7PEHGY1ZVDy0MvHsJ6slaKVqTx9PY0sVP6OpAB7E1)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Z>::Type sbt_ZArray;

