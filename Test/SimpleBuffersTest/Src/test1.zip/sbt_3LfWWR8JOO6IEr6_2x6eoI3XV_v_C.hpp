
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB;
	CX::IO::SimpleBuffers::UInt64Array sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8;
	CX::IO::SimpleBuffers::Int64Array sbt_J4ZJ1yvMdXbR7923H;
	CX::UInt32 sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l;
	CX::Int32 sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t;
	CX::UInt64 sbt_zcRzTHvcTUAReda8yECv6;
	CX::IO::SimpleBuffers::UInt64Array sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ;
	CX::IO::SimpleBuffers::StringArray sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr;
	CX::IO::SimpleBuffers::UInt64Array sbt_QswLoWcel7ZHSwj3cu1Ue5_8a;
	CX::UInt32 sbt_n6rYp;
	CX::UInt32 sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec;
	CX::String sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy;
	CX::IO::SimpleBuffers::UInt32Array sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L;
	CX::Int64 sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn;
	CX::IO::SimpleBuffers::UInt8Array sbt_VBjpFOWa6_R;
	CX::UInt8 sbt_gJmhrNG;
	CX::IO::SimpleBuffers::UInt64Array sbt_94vhb8T;
	CX::UInt64 sbt_MvZvGAPl9Qsw7oBnF;
	CX::IO::SimpleBuffers::Int16Array sbt_Bm3;
	CX::UInt64 sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW;
	CX::IO::SimpleBuffers::BoolArray sbt_mYmlX;
	CX::UInt32 sbt_t;
	CX::IO::SimpleBuffers::UInt32Array sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb;
	CX::UInt32 sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I;
	CX::IO::SimpleBuffers::Int64Array sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq;
	CX::Int16 sbt_CQa1YIhMJGuQBwXJM;
	CX::UInt8 sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN;

	virtual void Reset()
	{
		sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB = 0;
		sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.clear();
		sbt_J4ZJ1yvMdXbR7923H.clear();
		sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l = 0;
		sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t = 0;
		sbt_zcRzTHvcTUAReda8yECv6 = 0;
		sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.clear();
		sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.clear();
		sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.clear();
		sbt_n6rYp = 0;
		sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec = 0;
		sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy.clear();
		sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.clear();
		sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn = 0;
		sbt_VBjpFOWa6_R.clear();
		sbt_gJmhrNG = 0;
		sbt_94vhb8T.clear();
		sbt_MvZvGAPl9Qsw7oBnF = 0;
		sbt_Bm3.clear();
		sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW = 0;
		sbt_mYmlX.clear();
		sbt_t = 0;
		sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.clear();
		sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I = 0;
		sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.clear();
		sbt_CQa1YIhMJGuQBwXJM = 0;
		sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB = -29373;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.push_back(11249012893065918554);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_J4ZJ1yvMdXbR7923H.push_back(-4564081297012699958);
		}
		sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l = 3759055567;
		sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t = 289963820;
		sbt_zcRzTHvcTUAReda8yECv6 = 15362082321158833056;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.push_back(7023238269985216448);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.push_back("q3soz4l'K\\G40nngLm@L$oxZCy9=XfwnSE2ASE$w");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.push_back(12253620746745329818);
		}
		sbt_n6rYp = 1859787399;
		sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec = 2258859414;
		sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy = "$1}u`JBG\\iX_A}I\"x~G<z2Lucd+'uZaXlnNd-L,k{u_Z\\,X{.L@GZ]]WN;";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.push_back(2909416804);
		}
		sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn = -7981401765149749936;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_VBjpFOWa6_R.push_back(24);
		}
		sbt_gJmhrNG = 195;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_94vhb8T.push_back(2587141821620195566);
		}
		sbt_MvZvGAPl9Qsw7oBnF = 15829454194612187686;
		sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW = 7447475755290333932;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_mYmlX.push_back(false);
		}
		sbt_t = 1483660915;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.push_back(1059628669);
		}
		sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I = 93845675;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.push_back(2571805169417899396);
		}
		sbt_CQa1YIhMJGuQBwXJM = -30608;
		sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN = 184;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C *pObject = dynamic_cast<const sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB != pObject->sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB)
		{
			return false;
		}
		if (sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.size() != pObject->sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.size(); i++)
		{
			if (sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8[i] != pObject->sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8[i])
			{
				return false;
			}
		}
		if (sbt_J4ZJ1yvMdXbR7923H.size() != pObject->sbt_J4ZJ1yvMdXbR7923H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J4ZJ1yvMdXbR7923H.size(); i++)
		{
			if (sbt_J4ZJ1yvMdXbR7923H[i] != pObject->sbt_J4ZJ1yvMdXbR7923H[i])
			{
				return false;
			}
		}
		if (sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l != pObject->sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l)
		{
			return false;
		}
		if (sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t != pObject->sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t)
		{
			return false;
		}
		if (sbt_zcRzTHvcTUAReda8yECv6 != pObject->sbt_zcRzTHvcTUAReda8yECv6)
		{
			return false;
		}
		if (sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.size() != pObject->sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.size(); i++)
		{
			if (sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ[i] != pObject->sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ[i])
			{
				return false;
			}
		}
		if (sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.size() != pObject->sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr[i].c_str(), pObject->sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.size() != pObject->sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.size(); i++)
		{
			if (sbt_QswLoWcel7ZHSwj3cu1Ue5_8a[i] != pObject->sbt_QswLoWcel7ZHSwj3cu1Ue5_8a[i])
			{
				return false;
			}
		}
		if (sbt_n6rYp != pObject->sbt_n6rYp)
		{
			return false;
		}
		if (sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec != pObject->sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy.c_str(), pObject->sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy.c_str()))
		{
			return false;
		}
		if (sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.size() != pObject->sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.size(); i++)
		{
			if (sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L[i] != pObject->sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L[i])
			{
				return false;
			}
		}
		if (sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn != pObject->sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn)
		{
			return false;
		}
		if (sbt_VBjpFOWa6_R.size() != pObject->sbt_VBjpFOWa6_R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VBjpFOWa6_R.size(); i++)
		{
			if (sbt_VBjpFOWa6_R[i] != pObject->sbt_VBjpFOWa6_R[i])
			{
				return false;
			}
		}
		if (sbt_gJmhrNG != pObject->sbt_gJmhrNG)
		{
			return false;
		}
		if (sbt_94vhb8T.size() != pObject->sbt_94vhb8T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_94vhb8T.size(); i++)
		{
			if (sbt_94vhb8T[i] != pObject->sbt_94vhb8T[i])
			{
				return false;
			}
		}
		if (sbt_MvZvGAPl9Qsw7oBnF != pObject->sbt_MvZvGAPl9Qsw7oBnF)
		{
			return false;
		}
		if (sbt_Bm3.size() != pObject->sbt_Bm3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Bm3.size(); i++)
		{
			if (sbt_Bm3[i] != pObject->sbt_Bm3[i])
			{
				return false;
			}
		}
		if (sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW != pObject->sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW)
		{
			return false;
		}
		if (sbt_mYmlX.size() != pObject->sbt_mYmlX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mYmlX.size(); i++)
		{
			if (sbt_mYmlX[i] != pObject->sbt_mYmlX[i])
			{
				return false;
			}
		}
		if (sbt_t != pObject->sbt_t)
		{
			return false;
		}
		if (sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.size() != pObject->sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.size(); i++)
		{
			if (sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb[i] != pObject->sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb[i])
			{
				return false;
			}
		}
		if (sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I != pObject->sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I)
		{
			return false;
		}
		if (sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.size() != pObject->sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.size(); i++)
		{
			if (sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq[i] != pObject->sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq[i])
			{
				return false;
			}
		}
		if (sbt_CQa1YIhMJGuQBwXJM != pObject->sbt_CQa1YIhMJGuQBwXJM)
		{
			return false;
		}
		if (sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN != pObject->sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_J4ZJ1yvMdXbR7923H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J4ZJ1yvMdXbR7923H.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zcRzTHvcTUAReda8yECv6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zcRzTHvcTUAReda8yECv6 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QswLoWcel7ZHSwj3cu1Ue5_8a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n6rYp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n6rYp = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy", &sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VBjpFOWa6_R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VBjpFOWa6_R.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gJmhrNG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gJmhrNG = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_94vhb8T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_94vhb8T.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MvZvGAPl9Qsw7oBnF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MvZvGAPl9Qsw7oBnF = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Bm3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Bm3.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mYmlX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mYmlX.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CQa1YIhMJGuQBwXJM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CQa1YIhMJGuQBwXJM = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB", (CX::Int64)sbt_y1zuOH4nmbcG7WyisNNR8Eoe7LVpALD5wR8We7a5RP8Yxz3GofHtuk3RJHB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.begin(); iter != sbt_N70YRM1RiHwyuOojHlUoPzU27ZKUzF4uDHbLWLyb6wvd9h8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J4ZJ1yvMdXbR7923H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_J4ZJ1yvMdXbR7923H.begin(); iter != sbt_J4ZJ1yvMdXbR7923H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l", (CX::Int64)sbt_vvJN3_APn8_tbDILKaooAnfVNzVX2S1tWYaew2l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t", (CX::Int64)sbt_fMs0TfQcSNnE5tuBPaKGhTmUfQX2AC2rHSI1Uq9Hwb4Z50eguYHQqp4zjwL6t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zcRzTHvcTUAReda8yECv6", (CX::Int64)sbt_zcRzTHvcTUAReda8yECv6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.begin(); iter != sbt_93Gvsr_SyMhkS7mkGtNlYccfDBaCznoETWWaf1ag9mMugD1BdywzJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.begin(); iter != sbt_ceeSoTDBI02lONPFwWjoODuAk2YpZnqLV1NJWWPFnymAWRf1awamuUr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QswLoWcel7ZHSwj3cu1Ue5_8a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.begin(); iter != sbt_QswLoWcel7ZHSwj3cu1Ue5_8a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n6rYp", (CX::Int64)sbt_n6rYp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec", (CX::Int64)sbt_JblC_doDxcwkkjPbpAoWO_0Y34g3w84FfwwvSFWDCDyQHigDBS1slxC0mQC4fec)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy", sbt_zPfeS0NSXBUZYJW4R5xYzpDvjhKvfwRHOkWCq4xgrCFvp6LVy.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.begin(); iter != sbt_I3HBpT0KLSgBsOVmbUTOgUND4_Z4cyoRb4L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn", (CX::Int64)sbt_8LossUDN_SyLKM_JANxBH9CRbuxcn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VBjpFOWa6_R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_VBjpFOWa6_R.begin(); iter != sbt_VBjpFOWa6_R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gJmhrNG", (CX::Int64)sbt_gJmhrNG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_94vhb8T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_94vhb8T.begin(); iter != sbt_94vhb8T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MvZvGAPl9Qsw7oBnF", (CX::Int64)sbt_MvZvGAPl9Qsw7oBnF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Bm3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Bm3.begin(); iter != sbt_Bm3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW", (CX::Int64)sbt_VkYs_0hgldXfIyUzJNXN3ApwaThHSZoMJnt2a1rceGZlhvLfhogEW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mYmlX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_mYmlX.begin(); iter != sbt_mYmlX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t", (CX::Int64)sbt_t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.begin(); iter != sbt_D9m2vvaZAaJUd1ebEiCbGxDsRg2efC8czqLzHlb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I", (CX::Int64)sbt_6npLr0kqZZL7kHU2Nw989ZPKOave6J9bLeM3I)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.begin(); iter != sbt_W7PawyJ5XPFBmAYXwoIrn39XMZR6mg9mZCce3p44pt9TPxYD_Lq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CQa1YIhMJGuQBwXJM", (CX::Int64)sbt_CQa1YIhMJGuQBwXJM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN", (CX::Int64)sbt_B5gtjvIaRP7wjHIaC_IPIIEtOq0LEVepszKwSJ52sbFZ54GSy8M6f3nbgdN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C>::Type sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_CArray;

