
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV.hpp"


class sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95;
	CX::IO::SimpleBuffers::UInt8Array sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3;
	CX::UInt8 sbt_hJQQCslltnZBGVHurnP;
	CX::Int16 sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci;
	CX::IO::SimpleBuffers::UInt8Array sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY;
	CX::IO::SimpleBuffers::Int8Array sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3;
	CX::Int8 sbt_Zx7;
	CX::IO::SimpleBuffers::FloatArray sbt_7q8gYr4X7;
	CX::Bool sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ;
	CX::IO::SimpleBuffers::Int64Array sbt_PBQO6aQQVSNLwRA;
	CX::String sbt_Go7ffWbOVS2CU;
	CX::IO::SimpleBuffers::UInt64Array sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9;
	CX::IO::SimpleBuffers::Int64Array sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb;
	CX::IO::SimpleBuffers::DoubleArray sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO;
	CX::Int32 sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y;
	CX::IO::SimpleBuffers::WStringArray sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h;
	CX::UInt8 sbt_QA3LoATOWMU;
	CX::Double sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll;
	sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruVArray sbt_Cn6Vx8J5ut8js8BCjlq_T;

	virtual void Reset()
	{
		sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.clear();
		sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.clear();
		sbt_hJQQCslltnZBGVHurnP = 0;
		sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci = 0;
		sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.clear();
		sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.clear();
		sbt_Zx7 = 0;
		sbt_7q8gYr4X7.clear();
		sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ = false;
		sbt_PBQO6aQQVSNLwRA.clear();
		sbt_Go7ffWbOVS2CU.clear();
		sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.clear();
		sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.clear();
		sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.clear();
		sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y = 0;
		sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.clear();
		sbt_QA3LoATOWMU = 0;
		sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll = 0.0;
		sbt_Cn6Vx8J5ut8js8BCjlq_T.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.push_back(14441);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.push_back(88);
		}
		sbt_hJQQCslltnZBGVHurnP = 26;
		sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci = 10157;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.push_back(68);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.push_back(-61);
		}
		sbt_Zx7 = 121;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_7q8gYr4X7.push_back(0.343902f);
		}
		sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ = true;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_PBQO6aQQVSNLwRA.push_back(-8386146249486937348);
		}
		sbt_Go7ffWbOVS2CU = "o\"!'+L9&t5p#`/i3#$iHoux<h,N0Rq,DfH6";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.push_back(14765075720064575128);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.push_back(-4083700834891794254);
		}
		sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y = -1509730074;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.push_back(L"74)-6GWDe");
		}
		sbt_QA3LoATOWMU = 234;
		sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll = 0.999558;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV v;

			v.SetupWithSomeValues();
			sbt_Cn6Vx8J5ut8js8BCjlq_T.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K *pObject = dynamic_cast<const sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.size() != pObject->sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.size(); i++)
		{
			if (sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95[i] != pObject->sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95[i])
			{
				return false;
			}
		}
		if (sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.size() != pObject->sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.size(); i++)
		{
			if (sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3[i] != pObject->sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3[i])
			{
				return false;
			}
		}
		if (sbt_hJQQCslltnZBGVHurnP != pObject->sbt_hJQQCslltnZBGVHurnP)
		{
			return false;
		}
		if (sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci != pObject->sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci)
		{
			return false;
		}
		if (sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.size() != pObject->sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.size(); i++)
		{
			if (sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY[i] != pObject->sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY[i])
			{
				return false;
			}
		}
		if (sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.size() != pObject->sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.size(); i++)
		{
			if (sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3[i] != pObject->sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3[i])
			{
				return false;
			}
		}
		if (sbt_Zx7 != pObject->sbt_Zx7)
		{
			return false;
		}
		if (sbt_7q8gYr4X7.size() != pObject->sbt_7q8gYr4X7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7q8gYr4X7.size(); i++)
		{
			if (sbt_7q8gYr4X7[i] != pObject->sbt_7q8gYr4X7[i])
			{
				return false;
			}
		}
		if (sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ != pObject->sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ)
		{
			return false;
		}
		if (sbt_PBQO6aQQVSNLwRA.size() != pObject->sbt_PBQO6aQQVSNLwRA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PBQO6aQQVSNLwRA.size(); i++)
		{
			if (sbt_PBQO6aQQVSNLwRA[i] != pObject->sbt_PBQO6aQQVSNLwRA[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Go7ffWbOVS2CU.c_str(), pObject->sbt_Go7ffWbOVS2CU.c_str()))
		{
			return false;
		}
		if (sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.size() != pObject->sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.size(); i++)
		{
			if (sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9[i] != pObject->sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9[i])
			{
				return false;
			}
		}
		if (sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.size() != pObject->sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.size(); i++)
		{
			if (sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb[i] != pObject->sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb[i])
			{
				return false;
			}
		}
		if (sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.size() != pObject->sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.size(); i++)
		{
			if (sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO[i] != pObject->sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO[i])
			{
				return false;
			}
		}
		if (sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y != pObject->sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y)
		{
			return false;
		}
		if (sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.size() != pObject->sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h[i].c_str(), pObject->sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_QA3LoATOWMU != pObject->sbt_QA3LoATOWMU)
		{
			return false;
		}
		if (sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll != pObject->sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll)
		{
			return false;
		}
		if (sbt_Cn6Vx8J5ut8js8BCjlq_T.size() != pObject->sbt_Cn6Vx8J5ut8js8BCjlq_T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Cn6Vx8J5ut8js8BCjlq_T.size(); i++)
		{
			if (!sbt_Cn6Vx8J5ut8js8BCjlq_T[i].Compare(&pObject->sbt_Cn6Vx8J5ut8js8BCjlq_T[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hJQQCslltnZBGVHurnP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hJQQCslltnZBGVHurnP = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Zx7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Zx7 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7q8gYr4X7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7q8gYr4X7.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ", &sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PBQO6aQQVSNLwRA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PBQO6aQQVSNLwRA.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Go7ffWbOVS2CU", &sbt_Go7ffWbOVS2CU)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_QA3LoATOWMU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QA3LoATOWMU = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Cn6Vx8J5ut8js8BCjlq_T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_Cn6Vx8J5ut8js8BCjlq_T.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.begin(); iter != sbt_9lZDB9mJGGL1rAr_3_2bhXp8CG89B8r8Dbg8u95.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.begin(); iter != sbt_Qf5rJTJ_5pa8VlP2BqNvHiAzAJ_eyXAooK4JkugOUoyMmIJQv_iEz6F6DfEg3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hJQQCslltnZBGVHurnP", (CX::Int64)sbt_hJQQCslltnZBGVHurnP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci", (CX::Int64)sbt_5o6lmGcc4Ugw_8zcYHd5ckl49WhnqzafmAp6ddS3Vq60CcqWLBz0HYRci)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.begin(); iter != sbt_mDdBoUprPE_yrNAPxQP2VaMcx96pY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.begin(); iter != sbt_rNaQsRJUi5c3cUUeQ2oshaQwA9_iKy51E5no3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Zx7", (CX::Int64)sbt_Zx7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7q8gYr4X7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_7q8gYr4X7.begin(); iter != sbt_7q8gYr4X7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ", sbt_cSusDf4rAvR7bcovip92QVcohebdnYaxJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PBQO6aQQVSNLwRA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_PBQO6aQQVSNLwRA.begin(); iter != sbt_PBQO6aQQVSNLwRA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Go7ffWbOVS2CU", sbt_Go7ffWbOVS2CU.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.begin(); iter != sbt_aKtJgB6mFVWSPaeo7IVQ68zEIh_g4bxu9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.begin(); iter != sbt_St_NfbZBeXzwSFzGEFWh2IFQjasa703gG4CiX9WSKyS4pFb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.begin(); iter != sbt_lM0dMwNz2yn3EsH5wXNA8ATs_Vtr7qcrzXYOKNT5H3_XzVWeXCEjr97ThQO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y", (CX::Int64)sbt_k7ykJa3h_vxdIUQwdZ2hSCdvFjnQMkXBJ0gcX8gOAVD4Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.begin(); iter != sbt_kNH80AO1q5yjSmHNZtKYM2CNWc_LvYWTe63S9n5DG1h.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QA3LoATOWMU", (CX::Int64)sbt_QA3LoATOWMU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll", (CX::Double)sbt_0z0hPdGXlpVKyKyxxm8vKauBEBmphld_fll)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Cn6Vx8J5ut8js8BCjlq_T")).IsNOK())
		{
			return status;
		}
		for (sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruVArray::const_iterator iter = sbt_Cn6Vx8J5ut8js8BCjlq_T.begin(); iter != sbt_Cn6Vx8J5ut8js8BCjlq_T.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K>::Type sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59KArray;

