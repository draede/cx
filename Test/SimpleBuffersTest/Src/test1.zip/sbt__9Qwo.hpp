
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW.hpp"


class sbt__9Qwo : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX;
	CX::IO::SimpleBuffers::UInt16Array sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm;
	CX::IO::SimpleBuffers::Int32Array sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX;
	CX::Int32 sbt_AjF1sL325;
	CX::IO::SimpleBuffers::Int8Array sbt_zV32izWK0mE7NIlVaePDp4bnuky;
	CX::UInt32 sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW;
	CX::Bool sbt_p7IxID4IWEZLilk11cV;
	CX::IO::SimpleBuffers::StringArray sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL;
	CX::UInt16 sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm;
	CX::IO::SimpleBuffers::BoolArray sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7;
	CX::Int16 sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm;
	CX::Int64 sbt_Kk6;
	CX::IO::SimpleBuffers::Int64Array sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb;
	CX::IO::SimpleBuffers::UInt8Array sbt_2JAPiEQuO54AF;
	CX::IO::SimpleBuffers::StringArray sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E;
	CX::UInt16 sbt_IIf1HdbszYahn6a;
	CX::Int16 sbt_cDtVhlcxRA1foT25s3DJs91_yas;
	CX::IO::SimpleBuffers::Int16Array sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc;
	CX::IO::SimpleBuffers::Int64Array sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E;
	CX::IO::SimpleBuffers::WStringArray sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22;
	CX::UInt64 sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj;
	CX::UInt64 sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV;
	CX::UInt64 sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__;
	CX::String sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw;
	CX::IO::SimpleBuffers::Int8Array sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP;
	sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW sbt_7uYw2QK_j7MAI0D;

	virtual void Reset()
	{
		sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX.clear();
		sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.clear();
		sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.clear();
		sbt_AjF1sL325 = 0;
		sbt_zV32izWK0mE7NIlVaePDp4bnuky.clear();
		sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW = 0;
		sbt_p7IxID4IWEZLilk11cV = false;
		sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.clear();
		sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm = 0;
		sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.clear();
		sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm = 0;
		sbt_Kk6 = 0;
		sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.clear();
		sbt_2JAPiEQuO54AF.clear();
		sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.clear();
		sbt_IIf1HdbszYahn6a = 0;
		sbt_cDtVhlcxRA1foT25s3DJs91_yas = 0;
		sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.clear();
		sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.clear();
		sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.clear();
		sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj = 0;
		sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV = 0;
		sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__ = 0;
		sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw.clear();
		sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.clear();
		sbt_7uYw2QK_j7MAI0D.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX = "CBDDa#JH}DU\\8/Ws=W`8D!J~f|cp1vqzB8V?-AWI$>V(gg:4~|f{Qq/snB{-";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.push_back(51823);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.push_back(-1698180452);
		}
		sbt_AjF1sL325 = 2130588686;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_zV32izWK0mE7NIlVaePDp4bnuky.push_back(-103);
		}
		sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW = 2721461966;
		sbt_p7IxID4IWEZLilk11cV = true;
		sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm = 63244;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.push_back(false);
		}
		sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm = -27958;
		sbt_Kk6 = 6198391661848150196;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.push_back(5424560562820885512);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_2JAPiEQuO54AF.push_back(221);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.push_back("\\cM2-Vm=*RY!O7)mY@~4]9wg=.SA{lq,4Y.qt4qw^oF&'|Y;>u");
		}
		sbt_IIf1HdbszYahn6a = 47559;
		sbt_cDtVhlcxRA1foT25s3DJs91_yas = 24211;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.push_back(-22094);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.push_back(-6020068334468663734);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.push_back(L"Kx{D,anA1q(Qdf8\"_1^mXuQ[cD`~4GH82c4</.");
		}
		sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj = 10478008017032548768;
		sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV = 1704077627384203528;
		sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__ = 1430681078823988100;
		sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw = "xXOHyFpx#oxOs#.k_p].`Ph+(RRGF(pYvbCxg:&k}SPsHW|:O2{M6l?t&xcVW^*q";
		sbt_7uYw2QK_j7MAI0D.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__9Qwo *pObject = dynamic_cast<const sbt__9Qwo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX.c_str(), pObject->sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX.c_str()))
		{
			return false;
		}
		if (sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.size() != pObject->sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.size(); i++)
		{
			if (sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm[i] != pObject->sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm[i])
			{
				return false;
			}
		}
		if (sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.size() != pObject->sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.size(); i++)
		{
			if (sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX[i] != pObject->sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX[i])
			{
				return false;
			}
		}
		if (sbt_AjF1sL325 != pObject->sbt_AjF1sL325)
		{
			return false;
		}
		if (sbt_zV32izWK0mE7NIlVaePDp4bnuky.size() != pObject->sbt_zV32izWK0mE7NIlVaePDp4bnuky.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zV32izWK0mE7NIlVaePDp4bnuky.size(); i++)
		{
			if (sbt_zV32izWK0mE7NIlVaePDp4bnuky[i] != pObject->sbt_zV32izWK0mE7NIlVaePDp4bnuky[i])
			{
				return false;
			}
		}
		if (sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW != pObject->sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW)
		{
			return false;
		}
		if (sbt_p7IxID4IWEZLilk11cV != pObject->sbt_p7IxID4IWEZLilk11cV)
		{
			return false;
		}
		if (sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.size() != pObject->sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.size(); i++)
		{
			if (0 != cx_strcmp(sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL[i].c_str(), pObject->sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm != pObject->sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm)
		{
			return false;
		}
		if (sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.size() != pObject->sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.size(); i++)
		{
			if (sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7[i] != pObject->sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7[i])
			{
				return false;
			}
		}
		if (sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm != pObject->sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm)
		{
			return false;
		}
		if (sbt_Kk6 != pObject->sbt_Kk6)
		{
			return false;
		}
		if (sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.size() != pObject->sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.size(); i++)
		{
			if (sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb[i] != pObject->sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb[i])
			{
				return false;
			}
		}
		if (sbt_2JAPiEQuO54AF.size() != pObject->sbt_2JAPiEQuO54AF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2JAPiEQuO54AF.size(); i++)
		{
			if (sbt_2JAPiEQuO54AF[i] != pObject->sbt_2JAPiEQuO54AF[i])
			{
				return false;
			}
		}
		if (sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.size() != pObject->sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.size(); i++)
		{
			if (0 != cx_strcmp(sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E[i].c_str(), pObject->sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_IIf1HdbszYahn6a != pObject->sbt_IIf1HdbszYahn6a)
		{
			return false;
		}
		if (sbt_cDtVhlcxRA1foT25s3DJs91_yas != pObject->sbt_cDtVhlcxRA1foT25s3DJs91_yas)
		{
			return false;
		}
		if (sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.size() != pObject->sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.size(); i++)
		{
			if (sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc[i] != pObject->sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc[i])
			{
				return false;
			}
		}
		if (sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.size() != pObject->sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.size(); i++)
		{
			if (sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E[i] != pObject->sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E[i])
			{
				return false;
			}
		}
		if (sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.size() != pObject->sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22[i].c_str(), pObject->sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj != pObject->sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj)
		{
			return false;
		}
		if (sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV != pObject->sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV)
		{
			return false;
		}
		if (sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__ != pObject->sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw.c_str(), pObject->sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw.c_str()))
		{
			return false;
		}
		if (sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.size() != pObject->sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.size(); i++)
		{
			if (sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP[i] != pObject->sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP[i])
			{
				return false;
			}
		}
		if (!sbt_7uYw2QK_j7MAI0D.Compare(&pObject->sbt_7uYw2QK_j7MAI0D))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX", &sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AjF1sL325", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AjF1sL325 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zV32izWK0mE7NIlVaePDp4bnuky")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zV32izWK0mE7NIlVaePDp4bnuky.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_p7IxID4IWEZLilk11cV", &sbt_p7IxID4IWEZLilk11cV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Kk6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Kk6 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2JAPiEQuO54AF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2JAPiEQuO54AF.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IIf1HdbszYahn6a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IIf1HdbszYahn6a = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_cDtVhlcxRA1foT25s3DJs91_yas", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cDtVhlcxRA1foT25s3DJs91_yas = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw", &sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_7uYw2QK_j7MAI0D")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_7uYw2QK_j7MAI0D.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX", sbt_5NTIc64QotfGpGR18RxwwrN8M3ZnNDdsDhoCUybWGXJixbX.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.begin(); iter != sbt_C1QVuCbyNNQIWdD16sSCHFwLtn90srJR4f2auAZqE0ZARXW2mDsUM7Jgorm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.begin(); iter != sbt_WQZOUPMIa8vn4Hf3IzS3rMpUqH0KXdRcsEX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AjF1sL325", (CX::Int64)sbt_AjF1sL325)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zV32izWK0mE7NIlVaePDp4bnuky")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_zV32izWK0mE7NIlVaePDp4bnuky.begin(); iter != sbt_zV32izWK0mE7NIlVaePDp4bnuky.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW", (CX::Int64)sbt_Co4XmHYmIbyhi9DW4KEgpMTEvsW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_p7IxID4IWEZLilk11cV", sbt_p7IxID4IWEZLilk11cV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.begin(); iter != sbt_u0ovY5R4KIFu6UgpQAmKMO6TRJXovCNof0ekIkuABA9N5LITv9NMeR7ZLaL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm", (CX::Int64)sbt_G7mJ3m1XMNqxiaZYgv1CQA7pt78X1JpAq_ToOuTcdqQYm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.begin(); iter != sbt_mf0LVscdM5bVjZGyX4DY4_CkLysZLS7pNsofIK7qVf99NDhcVw7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm", (CX::Int64)sbt_Gzz8k1zrh1b4RcQRTNg407nVhc0bViMFgRtQnxCAFXm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Kk6", (CX::Int64)sbt_Kk6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.begin(); iter != sbt_ZWQsErGvraAp22a5RT9pvZ5u_bQWhTs2pRnwUjINfFLA8aLOpqh3ZvCNdgAS8cb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2JAPiEQuO54AF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_2JAPiEQuO54AF.begin(); iter != sbt_2JAPiEQuO54AF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.begin(); iter != sbt_JTqo570v_r_0Fj8YY50DmFYBnaiO98E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IIf1HdbszYahn6a", (CX::Int64)sbt_IIf1HdbszYahn6a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cDtVhlcxRA1foT25s3DJs91_yas", (CX::Int64)sbt_cDtVhlcxRA1foT25s3DJs91_yas)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.begin(); iter != sbt_BX5mANSGFb1VbOG63izXTCQ1YVM5UhUOfCM1Mj7Gc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.begin(); iter != sbt_pf7nZEKPXaeCkQgZTv5RBeMwb8I96tj4E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.begin(); iter != sbt_Eo7Cl6LLoSLQTUvLbhavsoVxrcW5XNk_WjSQOLioEoE_fpVdXvm_Ybnc8XJ22.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj", (CX::Int64)sbt_nLHuYlIPB5S5QXqBpbPsISiRGkhCLPENpJqy1qKKjuTAQNKWj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV", (CX::Int64)sbt_2bD6Ipap3bTeFE2RkXF8f7qm3NJhekLRzKV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__", (CX::Int64)sbt_TOn13glkwltnukJ7bdDgD2pk55zZSdF8KAQ6lpjYixZ__)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw", sbt_2xJiOJp7Tp9uLpnNxSNdIdbvC1AkSjFHFh227i4gLkuHw.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.begin(); iter != sbt_oMMjrtu8ZlYHaSwcAIAVyP8IahkaxN3EMkIBpZ89JVOetuUgtoVgdpP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_7uYw2QK_j7MAI0D")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_7uYw2QK_j7MAI0D.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__9Qwo>::Type sbt__9QwoArray;

