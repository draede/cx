
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_ifXVV77bn3iZ5FChyQgVp_6;
	CX::UInt64 sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3;
	CX::IO::SimpleBuffers::Int32Array sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE;
	CX::String sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF;
	CX::IO::SimpleBuffers::BoolArray sbt_xv6;
	CX::Int32 sbt_S_jOfGW5LTd473IlDwO35G35U7w;
	CX::IO::SimpleBuffers::UInt64Array sbt_TEnEY8zmintTL;
	CX::IO::SimpleBuffers::UInt16Array sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs;
	CX::Int32 sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7;
	CX::IO::SimpleBuffers::UInt8Array sbt_XwkYACtZusbrsb8Q2tpIkwu;
	CX::Int32 sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT;
	CX::IO::SimpleBuffers::Int32Array sbt_CRRI9XCW9E7zwHxzvVEe6nD;
	CX::Int16 sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4;

	virtual void Reset()
	{
		sbt_ifXVV77bn3iZ5FChyQgVp_6 = 0;
		sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3 = 0;
		sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.clear();
		sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF.clear();
		sbt_xv6.clear();
		sbt_S_jOfGW5LTd473IlDwO35G35U7w = 0;
		sbt_TEnEY8zmintTL.clear();
		sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.clear();
		sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7 = 0;
		sbt_XwkYACtZusbrsb8Q2tpIkwu.clear();
		sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT = 0;
		sbt_CRRI9XCW9E7zwHxzvVEe6nD.clear();
		sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ifXVV77bn3iZ5FChyQgVp_6 = 16514858435979232086;
		sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3 = 3740389615079455810;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.push_back(752920739);
		}
		sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF = "x#:2oTw<,`BcIL6?y,=ohr2byb71gv^5eM]<JDqHf:z~CDE9~V$ey";
		sbt_S_jOfGW5LTd473IlDwO35G35U7w = -1213481445;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_TEnEY8zmintTL.push_back(1180376980949119762);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.push_back(30409);
		}
		sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7 = -242105402;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_XwkYACtZusbrsb8Q2tpIkwu.push_back(95);
		}
		sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT = 2145675508;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_CRRI9XCW9E7zwHxzvVEe6nD.push_back(-1066868242);
		}
		sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4 = 3951;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_ *pObject = dynamic_cast<const sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ifXVV77bn3iZ5FChyQgVp_6 != pObject->sbt_ifXVV77bn3iZ5FChyQgVp_6)
		{
			return false;
		}
		if (sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3 != pObject->sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3)
		{
			return false;
		}
		if (sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.size() != pObject->sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.size(); i++)
		{
			if (sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE[i] != pObject->sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF.c_str(), pObject->sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF.c_str()))
		{
			return false;
		}
		if (sbt_xv6.size() != pObject->sbt_xv6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xv6.size(); i++)
		{
			if (sbt_xv6[i] != pObject->sbt_xv6[i])
			{
				return false;
			}
		}
		if (sbt_S_jOfGW5LTd473IlDwO35G35U7w != pObject->sbt_S_jOfGW5LTd473IlDwO35G35U7w)
		{
			return false;
		}
		if (sbt_TEnEY8zmintTL.size() != pObject->sbt_TEnEY8zmintTL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TEnEY8zmintTL.size(); i++)
		{
			if (sbt_TEnEY8zmintTL[i] != pObject->sbt_TEnEY8zmintTL[i])
			{
				return false;
			}
		}
		if (sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.size() != pObject->sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.size(); i++)
		{
			if (sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs[i] != pObject->sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs[i])
			{
				return false;
			}
		}
		if (sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7 != pObject->sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7)
		{
			return false;
		}
		if (sbt_XwkYACtZusbrsb8Q2tpIkwu.size() != pObject->sbt_XwkYACtZusbrsb8Q2tpIkwu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XwkYACtZusbrsb8Q2tpIkwu.size(); i++)
		{
			if (sbt_XwkYACtZusbrsb8Q2tpIkwu[i] != pObject->sbt_XwkYACtZusbrsb8Q2tpIkwu[i])
			{
				return false;
			}
		}
		if (sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT != pObject->sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT)
		{
			return false;
		}
		if (sbt_CRRI9XCW9E7zwHxzvVEe6nD.size() != pObject->sbt_CRRI9XCW9E7zwHxzvVEe6nD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CRRI9XCW9E7zwHxzvVEe6nD.size(); i++)
		{
			if (sbt_CRRI9XCW9E7zwHxzvVEe6nD[i] != pObject->sbt_CRRI9XCW9E7zwHxzvVEe6nD[i])
			{
				return false;
			}
		}
		if (sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4 != pObject->sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_ifXVV77bn3iZ5FChyQgVp_6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ifXVV77bn3iZ5FChyQgVp_6 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF", &sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xv6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xv6.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_S_jOfGW5LTd473IlDwO35G35U7w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S_jOfGW5LTd473IlDwO35G35U7w = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TEnEY8zmintTL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TEnEY8zmintTL.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XwkYACtZusbrsb8Q2tpIkwu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XwkYACtZusbrsb8Q2tpIkwu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CRRI9XCW9E7zwHxzvVEe6nD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CRRI9XCW9E7zwHxzvVEe6nD.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4 = (CX::Int16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_ifXVV77bn3iZ5FChyQgVp_6", (CX::Int64)sbt_ifXVV77bn3iZ5FChyQgVp_6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3", (CX::Int64)sbt_fAt2XgRCVKCz6SM3suUOZ2wvG4yh_CUSxKAbUHpt3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.begin(); iter != sbt_t02XSj0BaPTA5YY3nOGJgmUkJdlJcE7KFTkUC_HsE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF", sbt_rxKsltymeYyAHqUl0bt2kyoiq9DtgwbaF.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xv6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_xv6.begin(); iter != sbt_xv6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S_jOfGW5LTd473IlDwO35G35U7w", (CX::Int64)sbt_S_jOfGW5LTd473IlDwO35G35U7w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TEnEY8zmintTL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_TEnEY8zmintTL.begin(); iter != sbt_TEnEY8zmintTL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.begin(); iter != sbt_7ekXaMwmJeT_EJA9Un2yTy2vSUtMt30NfrRVb7pvs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7", (CX::Int64)sbt_mzdGqcRqOGFKojrohWDp3stVE_0OpLg931sqWz_OSWppdEduw8VZ8JeYPG5N7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XwkYACtZusbrsb8Q2tpIkwu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XwkYACtZusbrsb8Q2tpIkwu.begin(); iter != sbt_XwkYACtZusbrsb8Q2tpIkwu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT", (CX::Int64)sbt_LOBUlbttKgfbUtVD8xaNULCj678bDibBWpHkGKNxxvMBT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CRRI9XCW9E7zwHxzvVEe6nD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_CRRI9XCW9E7zwHxzvVEe6nD.begin(); iter != sbt_CRRI9XCW9E7zwHxzvVEe6nD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4", (CX::Int64)sbt_M5eQSCbVDXcUTitYl4apFajDFZqOiRWwUiN4Y3Mh4)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_>::Type sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_Array;

