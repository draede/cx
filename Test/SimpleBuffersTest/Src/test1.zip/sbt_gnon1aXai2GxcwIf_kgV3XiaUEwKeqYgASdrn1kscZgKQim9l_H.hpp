
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_EGCPz9dt_WEgeMa1SKZ.hpp"


class sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_PqQvFIqLU3DL22fdJrXnBnL;
	CX::Int64 sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf;
	CX::Int32 sbt_e;
	sbt_EGCPz9dt_WEgeMa1SKZArray sbt_gV2B3qgUdbHH92n7W;

	virtual void Reset()
	{
		sbt_PqQvFIqLU3DL22fdJrXnBnL.clear();
		sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf = 0;
		sbt_e = 0;
		sbt_gV2B3qgUdbHH92n7W.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_PqQvFIqLU3DL22fdJrXnBnL.push_back(1196853132);
		}
		sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf = -5190600085065012566;
		sbt_e = 23125064;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H *pObject = dynamic_cast<const sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_PqQvFIqLU3DL22fdJrXnBnL.size() != pObject->sbt_PqQvFIqLU3DL22fdJrXnBnL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PqQvFIqLU3DL22fdJrXnBnL.size(); i++)
		{
			if (sbt_PqQvFIqLU3DL22fdJrXnBnL[i] != pObject->sbt_PqQvFIqLU3DL22fdJrXnBnL[i])
			{
				return false;
			}
		}
		if (sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf != pObject->sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf)
		{
			return false;
		}
		if (sbt_e != pObject->sbt_e)
		{
			return false;
		}
		if (sbt_gV2B3qgUdbHH92n7W.size() != pObject->sbt_gV2B3qgUdbHH92n7W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gV2B3qgUdbHH92n7W.size(); i++)
		{
			if (!sbt_gV2B3qgUdbHH92n7W[i].Compare(&pObject->sbt_gV2B3qgUdbHH92n7W[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_PqQvFIqLU3DL22fdJrXnBnL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PqQvFIqLU3DL22fdJrXnBnL.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_e", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gV2B3qgUdbHH92n7W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_EGCPz9dt_WEgeMa1SKZ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_gV2B3qgUdbHH92n7W.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_PqQvFIqLU3DL22fdJrXnBnL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_PqQvFIqLU3DL22fdJrXnBnL.begin(); iter != sbt_PqQvFIqLU3DL22fdJrXnBnL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf", (CX::Int64)sbt_ShxXEhVd79ttdfaUsFAXURVVOOGOKK7B_ZIDpcf1NcfpyxcHzLf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_e", (CX::Int64)sbt_e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gV2B3qgUdbHH92n7W")).IsNOK())
		{
			return status;
		}
		for (sbt_EGCPz9dt_WEgeMa1SKZArray::const_iterator iter = sbt_gV2B3qgUdbHH92n7W.begin(); iter != sbt_gV2B3qgUdbHH92n7W.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H>::Type sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_HArray;

