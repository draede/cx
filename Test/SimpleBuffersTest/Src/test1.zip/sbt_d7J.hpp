
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_d7J : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf;
	CX::Int16 sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP;
	CX::UInt8 sbt_GfQRx;
	CX::UInt16 sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi;
	CX::String sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC;
	CX::UInt32 sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2;
	CX::UInt64 sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp;
	CX::IO::SimpleBuffers::UInt16Array sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2;
	CX::IO::SimpleBuffers::Int32Array sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX;
	CX::Int32 sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz;
	CX::Int32 sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3;
	CX::UInt32 sbt_J4zFQs3v6xyZbQj;
	CX::String sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd;
	CX::IO::SimpleBuffers::UInt64Array sbt_yD7lsADJ6pomIeNc12WxZ3v;
	CX::UInt32 sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP;
	CX::Int16 sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c;
	CX::IO::SimpleBuffers::UInt16Array sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw;
	CX::Int16 sbt_19XAGd8;
	CX::IO::SimpleBuffers::Int32Array sbt_LV_1msKlhqKwzrLQYeM_8;
	CX::UInt8 sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc;

	virtual void Reset()
	{
		sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.clear();
		sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP = 0;
		sbt_GfQRx = 0;
		sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi = 0;
		sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC.clear();
		sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2 = 0;
		sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp = 0;
		sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.clear();
		sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.clear();
		sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz = 0;
		sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3 = 0;
		sbt_J4zFQs3v6xyZbQj = 0;
		sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd.clear();
		sbt_yD7lsADJ6pomIeNc12WxZ3v.clear();
		sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP = 0;
		sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c = 0;
		sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.clear();
		sbt_19XAGd8 = 0;
		sbt_LV_1msKlhqKwzrLQYeM_8.clear();
		sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.push_back(5045);
		}
		sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP = -30009;
		sbt_GfQRx = 34;
		sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi = 40071;
		sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC = "{GP}l\"kr%yG]ms6Q*1EJ5TC8qT_pS9S'B-'f6p+.g+|3Buaq";
		sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2 = 1949425117;
		sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp = 17336608974891748524;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.push_back(19401);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.push_back(-122338451);
		}
		sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz = 2098346212;
		sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3 = 1195004944;
		sbt_J4zFQs3v6xyZbQj = 1796398571;
		sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd = ")uRZhlma$b!:B+~z!h|'S?gUF4Fg]@q3nb-$boWb8:2g!tIV%s[_,";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_yD7lsADJ6pomIeNc12WxZ3v.push_back(10149366732147407164);
		}
		sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP = 2001594483;
		sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c = 20593;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.push_back(63400);
		}
		sbt_19XAGd8 = -26001;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_LV_1msKlhqKwzrLQYeM_8.push_back(-795856939);
		}
		sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc = 175;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_d7J *pObject = dynamic_cast<const sbt_d7J *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.size() != pObject->sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.size(); i++)
		{
			if (sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf[i] != pObject->sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf[i])
			{
				return false;
			}
		}
		if (sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP != pObject->sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP)
		{
			return false;
		}
		if (sbt_GfQRx != pObject->sbt_GfQRx)
		{
			return false;
		}
		if (sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi != pObject->sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC.c_str(), pObject->sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC.c_str()))
		{
			return false;
		}
		if (sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2 != pObject->sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2)
		{
			return false;
		}
		if (sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp != pObject->sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp)
		{
			return false;
		}
		if (sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.size() != pObject->sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.size(); i++)
		{
			if (sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2[i] != pObject->sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2[i])
			{
				return false;
			}
		}
		if (sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.size() != pObject->sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.size(); i++)
		{
			if (sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX[i] != pObject->sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX[i])
			{
				return false;
			}
		}
		if (sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz != pObject->sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz)
		{
			return false;
		}
		if (sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3 != pObject->sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3)
		{
			return false;
		}
		if (sbt_J4zFQs3v6xyZbQj != pObject->sbt_J4zFQs3v6xyZbQj)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd.c_str(), pObject->sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd.c_str()))
		{
			return false;
		}
		if (sbt_yD7lsADJ6pomIeNc12WxZ3v.size() != pObject->sbt_yD7lsADJ6pomIeNc12WxZ3v.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yD7lsADJ6pomIeNc12WxZ3v.size(); i++)
		{
			if (sbt_yD7lsADJ6pomIeNc12WxZ3v[i] != pObject->sbt_yD7lsADJ6pomIeNc12WxZ3v[i])
			{
				return false;
			}
		}
		if (sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP != pObject->sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP)
		{
			return false;
		}
		if (sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c != pObject->sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c)
		{
			return false;
		}
		if (sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.size() != pObject->sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.size(); i++)
		{
			if (sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw[i] != pObject->sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw[i])
			{
				return false;
			}
		}
		if (sbt_19XAGd8 != pObject->sbt_19XAGd8)
		{
			return false;
		}
		if (sbt_LV_1msKlhqKwzrLQYeM_8.size() != pObject->sbt_LV_1msKlhqKwzrLQYeM_8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LV_1msKlhqKwzrLQYeM_8.size(); i++)
		{
			if (sbt_LV_1msKlhqKwzrLQYeM_8[i] != pObject->sbt_LV_1msKlhqKwzrLQYeM_8[i])
			{
				return false;
			}
		}
		if (sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc != pObject->sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_GfQRx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GfQRx = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC", &sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_J4zFQs3v6xyZbQj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J4zFQs3v6xyZbQj = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd", &sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yD7lsADJ6pomIeNc12WxZ3v")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yD7lsADJ6pomIeNc12WxZ3v.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_19XAGd8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_19XAGd8 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LV_1msKlhqKwzrLQYeM_8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LV_1msKlhqKwzrLQYeM_8.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.begin(); iter != sbt_NKErkR4hOPGRkIAKNHeZwhVVEf2MUPG7uDpgPFGWjkhIXpmxbyZFf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP", (CX::Int64)sbt__8sFsfA2W5101Oh00GnXZqygbpOvzkN6UlovP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GfQRx", (CX::Int64)sbt_GfQRx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi", (CX::Int64)sbt_SC6iMRhVOgqSqq95cIQJn8QkW1W9oZwdm4cMTGxvLdLuOMmfPBi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC", sbt_eY0lH2LU6xOeszB7Zj9Zzf2j_1fLqXJ8sE8SO8rkLR2ts3UMKBC.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2", (CX::Int64)sbt_ftQxuodu4vXWOjD4pGVaDNq8TJlXApPHD3jJSai9ZvHAVF3g0oEX2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp", (CX::Int64)sbt_eY8DHZh0NHYWeS3pEJiNNhvasF8hKWjZXLpRHGYEHBdSQ6marlp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.begin(); iter != sbt_gZWV8qjcbMX9TydSgao1fgKvtTMb2bI0FS_oE1T7AOpOqJOROpV1e8WoBb2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.begin(); iter != sbt_60B1sxUcXwwLD9kjQX5boLh21nThHCy209bD6JX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz", (CX::Int64)sbt_9fLXrbT2Kz_X5xw2JyuGOU91TcmVEFcq9YXrXQcyxJ8dCpJlyyAJUknslKz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3", (CX::Int64)sbt_VnUEz72E2uz3HN2LmfpK3QaDShMAw87uys8S8N1gat3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J4zFQs3v6xyZbQj", (CX::Int64)sbt_J4zFQs3v6xyZbQj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd", sbt_ocz4FzBWfPlvqJGU0Rr1p5Bv6fjyw5jQzEDpd.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yD7lsADJ6pomIeNc12WxZ3v")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yD7lsADJ6pomIeNc12WxZ3v.begin(); iter != sbt_yD7lsADJ6pomIeNc12WxZ3v.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP", (CX::Int64)sbt_7VdlcqNNoHzOEz9uoUU8X8ebRoDO4BklkxP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c", (CX::Int64)sbt_MhUJGqHusXRsRjRNJdp8MbGkz8c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.begin(); iter != sbt_4jc5B9RCtrn6kTABW6H59S6_UYHxf22dYAjjEg1ivn3oZMPEw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_19XAGd8", (CX::Int64)sbt_19XAGd8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LV_1msKlhqKwzrLQYeM_8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_LV_1msKlhqKwzrLQYeM_8.begin(); iter != sbt_LV_1msKlhqKwzrLQYeM_8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc", (CX::Int64)sbt_YZUKQF1sSCF_Trle2wFKLHyl7X1Joh5NxMpmFnV_V1jVx0JNAOc)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_d7J>::Type sbt_d7JArray;

