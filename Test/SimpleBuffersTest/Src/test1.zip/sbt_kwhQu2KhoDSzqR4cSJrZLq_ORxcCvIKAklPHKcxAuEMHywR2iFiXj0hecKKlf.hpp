
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_DYiGJ.hpp"


class sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_mQViW243I9j62;
	CX::IO::SimpleBuffers::Int32Array sbt_4QSLGuidYsTxFVC_bp6hO;
	CX::IO::SimpleBuffers::UInt16Array sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ;
	CX::IO::SimpleBuffers::WStringArray sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5;
	CX::IO::SimpleBuffers::Int16Array sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv;
	CX::IO::SimpleBuffers::Int64Array sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2;
	CX::Bool sbt_JlsErDfgMPelB;
	CX::IO::SimpleBuffers::Int16Array sbt_KNnqW2K9b;
	CX::IO::SimpleBuffers::FloatArray sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK;
	CX::IO::SimpleBuffers::FloatArray sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR;
	CX::UInt32 sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR;
	CX::IO::SimpleBuffers::UInt64Array sbt_4wUBgISqiDmJ2Lh;
	CX::Double sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3;
	CX::IO::SimpleBuffers::BoolArray sbt_QC_NZCRIoYkZk25;
	CX::Int8 sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj;
	CX::IO::SimpleBuffers::UInt32Array sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3;
	CX::IO::SimpleBuffers::UInt32Array sbt_TeZe6uNciHnjr;
	CX::Float sbt_68AV1afOMaKaYxiVD2PinU8;
	sbt_DYiGJArray sbt_eiGdra6BQNW1ahX;

	virtual void Reset()
	{
		sbt_mQViW243I9j62 = 0;
		sbt_4QSLGuidYsTxFVC_bp6hO.clear();
		sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.clear();
		sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.clear();
		sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.clear();
		sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.clear();
		sbt_JlsErDfgMPelB = false;
		sbt_KNnqW2K9b.clear();
		sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.clear();
		sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.clear();
		sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR = 0;
		sbt_4wUBgISqiDmJ2Lh.clear();
		sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3 = 0.0;
		sbt_QC_NZCRIoYkZk25.clear();
		sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj = 0;
		sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.clear();
		sbt_TeZe6uNciHnjr.clear();
		sbt_68AV1afOMaKaYxiVD2PinU8 = 0.0f;
		sbt_eiGdra6BQNW1ahX.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_mQViW243I9j62 = 5761;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_4QSLGuidYsTxFVC_bp6hO.push_back(1970036549);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.push_back(10804);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.push_back(L"{T&)\\k*i:<NzIKqpb/={W@VaGt+HlSfX8wQ.|Al");
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.push_back(-21168);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.push_back(-5562866389505985156);
		}
		sbt_JlsErDfgMPelB = false;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_KNnqW2K9b.push_back(-1249);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.push_back(0.410206f);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.push_back(0.308410f);
		}
		sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR = 2216611361;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_4wUBgISqiDmJ2Lh.push_back(14737912443291338912);
		}
		sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3 = 0.396589;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_QC_NZCRIoYkZk25.push_back(true);
		}
		sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj = -24;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.push_back(3147315135);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_TeZe6uNciHnjr.push_back(1880792960);
		}
		sbt_68AV1afOMaKaYxiVD2PinU8 = 0.227943f;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_DYiGJ v;

			v.SetupWithSomeValues();
			sbt_eiGdra6BQNW1ahX.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf *pObject = dynamic_cast<const sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_mQViW243I9j62 != pObject->sbt_mQViW243I9j62)
		{
			return false;
		}
		if (sbt_4QSLGuidYsTxFVC_bp6hO.size() != pObject->sbt_4QSLGuidYsTxFVC_bp6hO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4QSLGuidYsTxFVC_bp6hO.size(); i++)
		{
			if (sbt_4QSLGuidYsTxFVC_bp6hO[i] != pObject->sbt_4QSLGuidYsTxFVC_bp6hO[i])
			{
				return false;
			}
		}
		if (sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.size() != pObject->sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.size(); i++)
		{
			if (sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ[i] != pObject->sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ[i])
			{
				return false;
			}
		}
		if (sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.size() != pObject->sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5[i].c_str(), pObject->sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.size() != pObject->sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.size(); i++)
		{
			if (sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv[i] != pObject->sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv[i])
			{
				return false;
			}
		}
		if (sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.size() != pObject->sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.size(); i++)
		{
			if (sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2[i] != pObject->sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2[i])
			{
				return false;
			}
		}
		if (sbt_JlsErDfgMPelB != pObject->sbt_JlsErDfgMPelB)
		{
			return false;
		}
		if (sbt_KNnqW2K9b.size() != pObject->sbt_KNnqW2K9b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KNnqW2K9b.size(); i++)
		{
			if (sbt_KNnqW2K9b[i] != pObject->sbt_KNnqW2K9b[i])
			{
				return false;
			}
		}
		if (sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.size() != pObject->sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.size(); i++)
		{
			if (sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK[i] != pObject->sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK[i])
			{
				return false;
			}
		}
		if (sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.size() != pObject->sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.size(); i++)
		{
			if (sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR[i] != pObject->sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR[i])
			{
				return false;
			}
		}
		if (sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR != pObject->sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR)
		{
			return false;
		}
		if (sbt_4wUBgISqiDmJ2Lh.size() != pObject->sbt_4wUBgISqiDmJ2Lh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4wUBgISqiDmJ2Lh.size(); i++)
		{
			if (sbt_4wUBgISqiDmJ2Lh[i] != pObject->sbt_4wUBgISqiDmJ2Lh[i])
			{
				return false;
			}
		}
		if (sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3 != pObject->sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3)
		{
			return false;
		}
		if (sbt_QC_NZCRIoYkZk25.size() != pObject->sbt_QC_NZCRIoYkZk25.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QC_NZCRIoYkZk25.size(); i++)
		{
			if (sbt_QC_NZCRIoYkZk25[i] != pObject->sbt_QC_NZCRIoYkZk25[i])
			{
				return false;
			}
		}
		if (sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj != pObject->sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj)
		{
			return false;
		}
		if (sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.size() != pObject->sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.size(); i++)
		{
			if (sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3[i] != pObject->sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3[i])
			{
				return false;
			}
		}
		if (sbt_TeZe6uNciHnjr.size() != pObject->sbt_TeZe6uNciHnjr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TeZe6uNciHnjr.size(); i++)
		{
			if (sbt_TeZe6uNciHnjr[i] != pObject->sbt_TeZe6uNciHnjr[i])
			{
				return false;
			}
		}
		if (sbt_68AV1afOMaKaYxiVD2PinU8 != pObject->sbt_68AV1afOMaKaYxiVD2PinU8)
		{
			return false;
		}
		if (sbt_eiGdra6BQNW1ahX.size() != pObject->sbt_eiGdra6BQNW1ahX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eiGdra6BQNW1ahX.size(); i++)
		{
			if (!sbt_eiGdra6BQNW1ahX[i].Compare(&pObject->sbt_eiGdra6BQNW1ahX[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_mQViW243I9j62", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mQViW243I9j62 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4QSLGuidYsTxFVC_bp6hO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4QSLGuidYsTxFVC_bp6hO.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_JlsErDfgMPelB", &sbt_JlsErDfgMPelB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KNnqW2K9b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KNnqW2K9b.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4wUBgISqiDmJ2Lh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4wUBgISqiDmJ2Lh.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_QC_NZCRIoYkZk25")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QC_NZCRIoYkZk25.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TeZe6uNciHnjr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TeZe6uNciHnjr.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_68AV1afOMaKaYxiVD2PinU8", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_68AV1afOMaKaYxiVD2PinU8 = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_eiGdra6BQNW1ahX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_DYiGJ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_eiGdra6BQNW1ahX.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_mQViW243I9j62", (CX::Int64)sbt_mQViW243I9j62)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4QSLGuidYsTxFVC_bp6hO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_4QSLGuidYsTxFVC_bp6hO.begin(); iter != sbt_4QSLGuidYsTxFVC_bp6hO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.begin(); iter != sbt__ezhuoD4lsHXyK0TqQv__Oa1iUYtdMZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.begin(); iter != sbt_uujp37BrwljkYHYCH3L4wIgwEbbfckQfSOvES223aY5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.begin(); iter != sbt_fdRAN3feFGeCrTUeCTM7OFRRBnI1BFoZSPzSuS1rwAG7m9EyOTbcIalHv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.begin(); iter != sbt_d5qoEnfh2xHcBiXYUgtd9Qwd5jeF3JktJkeOejDd9ualRzbWz2sQBJ5f2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_JlsErDfgMPelB", sbt_JlsErDfgMPelB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KNnqW2K9b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_KNnqW2K9b.begin(); iter != sbt_KNnqW2K9b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.begin(); iter != sbt_LheKUYAq6LrU70f3826StGKTKNQBgwYSz4Xe2dU3U3PyfUK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.begin(); iter != sbt_JcCDyz3IB1jn0Kg3qjEm05TJKUF4UZoc_xxHtmH6GoJAHNOFHjBSuOR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR", (CX::Int64)sbt_zditlSReymEt1ua4X8JsAMoL8Eo6NGwbHhgxGCtjhnnXUg_KDNhxrSuUlgR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4wUBgISqiDmJ2Lh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_4wUBgISqiDmJ2Lh.begin(); iter != sbt_4wUBgISqiDmJ2Lh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3", (CX::Double)sbt_IsIdgR9Yd73mAXYrj5maW7M0AC8ybmOCsy6EA9ErP9PseAEmLwNJ6KLQSh3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QC_NZCRIoYkZk25")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_QC_NZCRIoYkZk25.begin(); iter != sbt_QC_NZCRIoYkZk25.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj", (CX::Int64)sbt_Kvkp6winy4Zl9GS8og4rC0amiBfxlPnRxdZbJZj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.begin(); iter != sbt_azms5sGlplHu27Nwtpi7MCm50WZiPi3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TeZe6uNciHnjr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_TeZe6uNciHnjr.begin(); iter != sbt_TeZe6uNciHnjr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_68AV1afOMaKaYxiVD2PinU8", (CX::Double)sbt_68AV1afOMaKaYxiVD2PinU8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eiGdra6BQNW1ahX")).IsNOK())
		{
			return status;
		}
		for (sbt_DYiGJArray::const_iterator iter = sbt_eiGdra6BQNW1ahX.begin(); iter != sbt_eiGdra6BQNW1ahX.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf>::Type sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlfArray;

