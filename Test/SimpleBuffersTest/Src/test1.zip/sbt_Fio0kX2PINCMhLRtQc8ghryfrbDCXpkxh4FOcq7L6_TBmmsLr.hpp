
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX.hpp"


class sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d;
	CX::Int8 sbt_E5P8j65a9WXHowRYqbd_rASO_545w;
	CX::IO::SimpleBuffers::DoubleArray sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg;
	CX::IO::SimpleBuffers::BoolArray sbt_iMENvfHia4Z1CxDZcwOsLEd;
	CX::Int64 sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK;
	CX::Double sbt_xjKIIKiX9xksvupb9Nsd2;
	CX::IO::SimpleBuffers::WStringArray sbt_fRPKINm9IBUcuVBiWz9;
	CX::IO::SimpleBuffers::UInt64Array sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6;
	CX::IO::SimpleBuffers::DoubleArray sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6;
	CX::IO::SimpleBuffers::Int8Array sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr;
	CX::IO::SimpleBuffers::Int64Array sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR;
	CX::IO::SimpleBuffers::UInt8Array sbt_yaw0jTDtwrfG2jcmu4U2jNV;
	CX::String sbt_IgZGqrnL7XV;
	CX::IO::SimpleBuffers::WStringArray sbt_XxK;
	CX::Int8 sbt_R3gfkU9BAzA;
	CX::IO::SimpleBuffers::WStringArray sbt_WaV242O7i;
	CX::IO::SimpleBuffers::UInt64Array sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx;
	CX::Int16 sbt_arrEBYFrip8JCRp0dxoUX_vQV;
	CX::Float sbt_4WgeVBy6J_wlvKL;
	CX::UInt32 sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma;
	CX::IO::SimpleBuffers::Int32Array sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo;
	CX::IO::SimpleBuffers::FloatArray sbt_mgHgPIYMzEcpTj4EkVYTGH5;
	CX::WString sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr;
	CX::Int32 sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3;
	CX::IO::SimpleBuffers::WStringArray sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H;
	CX::IO::SimpleBuffers::Int8Array sbt_r54CotsMF;
	CX::IO::SimpleBuffers::UInt64Array sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj;
	CX::Float sbt_bO_xEJ3s1Yt;
	CX::IO::SimpleBuffers::Int16Array sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG;
	sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX sbt_k;

	virtual void Reset()
	{
		sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d = 0;
		sbt_E5P8j65a9WXHowRYqbd_rASO_545w = 0;
		sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.clear();
		sbt_iMENvfHia4Z1CxDZcwOsLEd.clear();
		sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK = 0;
		sbt_xjKIIKiX9xksvupb9Nsd2 = 0.0;
		sbt_fRPKINm9IBUcuVBiWz9.clear();
		sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.clear();
		sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.clear();
		sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.clear();
		sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.clear();
		sbt_yaw0jTDtwrfG2jcmu4U2jNV.clear();
		sbt_IgZGqrnL7XV.clear();
		sbt_XxK.clear();
		sbt_R3gfkU9BAzA = 0;
		sbt_WaV242O7i.clear();
		sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.clear();
		sbt_arrEBYFrip8JCRp0dxoUX_vQV = 0;
		sbt_4WgeVBy6J_wlvKL = 0.0f;
		sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma = 0;
		sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.clear();
		sbt_mgHgPIYMzEcpTj4EkVYTGH5.clear();
		sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr.clear();
		sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3 = 0;
		sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.clear();
		sbt_r54CotsMF.clear();
		sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.clear();
		sbt_bO_xEJ3s1Yt = 0.0f;
		sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.clear();
		sbt_k.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d = -4186;
		sbt_E5P8j65a9WXHowRYqbd_rASO_545w = -80;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.push_back(0.275878);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_iMENvfHia4Z1CxDZcwOsLEd.push_back(false);
		}
		sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK = 2230967838999450692;
		sbt_xjKIIKiX9xksvupb9Nsd2 = 0.841181;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_fRPKINm9IBUcuVBiWz9.push_back(L"9+`<uZ\\o0!;Ej~Zh?O<gU&bX!coq_u~==QDjglf~`q|KN|?T.OL'I`y_nrFYDVVX");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.push_back(8460908380680975754);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.push_back(0.256767);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.push_back(-25);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.push_back(3759370204928892340);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_yaw0jTDtwrfG2jcmu4U2jNV.push_back(250);
		}
		sbt_IgZGqrnL7XV = "-";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_XxK.push_back(L"3'&'zz!Hv:%K:&H&=UaA9('sANS<m3RL^T{qQM+`Uh.");
		}
		sbt_R3gfkU9BAzA = -68;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_WaV242O7i.push_back(L"U~eqoA4");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.push_back(4913686432142113034);
		}
		sbt_arrEBYFrip8JCRp0dxoUX_vQV = 3754;
		sbt_4WgeVBy6J_wlvKL = 0.463502f;
		sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma = 415361532;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.push_back(1402924672);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_mgHgPIYMzEcpTj4EkVYTGH5.push_back(0.655120f);
		}
		sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr = L"6hcLMe}d^n!e'|J/9{Rg#%Uw&5%?jP:0jx4JZ2]FDPJg(R";
		sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3 = -2029454538;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.push_back(L"QTaoEA\"*Za(0]Lu?d_/Y");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_r54CotsMF.push_back(0);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.push_back(14195130487851112296);
		}
		sbt_bO_xEJ3s1Yt = 0.887943f;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.push_back(-20407);
		}
		sbt_k.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr *pObject = dynamic_cast<const sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d != pObject->sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d)
		{
			return false;
		}
		if (sbt_E5P8j65a9WXHowRYqbd_rASO_545w != pObject->sbt_E5P8j65a9WXHowRYqbd_rASO_545w)
		{
			return false;
		}
		if (sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.size() != pObject->sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.size(); i++)
		{
			if (sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg[i] != pObject->sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg[i])
			{
				return false;
			}
		}
		if (sbt_iMENvfHia4Z1CxDZcwOsLEd.size() != pObject->sbt_iMENvfHia4Z1CxDZcwOsLEd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iMENvfHia4Z1CxDZcwOsLEd.size(); i++)
		{
			if (sbt_iMENvfHia4Z1CxDZcwOsLEd[i] != pObject->sbt_iMENvfHia4Z1CxDZcwOsLEd[i])
			{
				return false;
			}
		}
		if (sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK != pObject->sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK)
		{
			return false;
		}
		if (sbt_xjKIIKiX9xksvupb9Nsd2 != pObject->sbt_xjKIIKiX9xksvupb9Nsd2)
		{
			return false;
		}
		if (sbt_fRPKINm9IBUcuVBiWz9.size() != pObject->sbt_fRPKINm9IBUcuVBiWz9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fRPKINm9IBUcuVBiWz9.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_fRPKINm9IBUcuVBiWz9[i].c_str(), pObject->sbt_fRPKINm9IBUcuVBiWz9[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.size() != pObject->sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.size(); i++)
		{
			if (sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6[i] != pObject->sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6[i])
			{
				return false;
			}
		}
		if (sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.size() != pObject->sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.size(); i++)
		{
			if (sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6[i] != pObject->sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6[i])
			{
				return false;
			}
		}
		if (sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.size() != pObject->sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.size(); i++)
		{
			if (sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr[i] != pObject->sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr[i])
			{
				return false;
			}
		}
		if (sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.size() != pObject->sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.size(); i++)
		{
			if (sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR[i] != pObject->sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR[i])
			{
				return false;
			}
		}
		if (sbt_yaw0jTDtwrfG2jcmu4U2jNV.size() != pObject->sbt_yaw0jTDtwrfG2jcmu4U2jNV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yaw0jTDtwrfG2jcmu4U2jNV.size(); i++)
		{
			if (sbt_yaw0jTDtwrfG2jcmu4U2jNV[i] != pObject->sbt_yaw0jTDtwrfG2jcmu4U2jNV[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_IgZGqrnL7XV.c_str(), pObject->sbt_IgZGqrnL7XV.c_str()))
		{
			return false;
		}
		if (sbt_XxK.size() != pObject->sbt_XxK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XxK.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_XxK[i].c_str(), pObject->sbt_XxK[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_R3gfkU9BAzA != pObject->sbt_R3gfkU9BAzA)
		{
			return false;
		}
		if (sbt_WaV242O7i.size() != pObject->sbt_WaV242O7i.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WaV242O7i.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_WaV242O7i[i].c_str(), pObject->sbt_WaV242O7i[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.size() != pObject->sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.size(); i++)
		{
			if (sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx[i] != pObject->sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx[i])
			{
				return false;
			}
		}
		if (sbt_arrEBYFrip8JCRp0dxoUX_vQV != pObject->sbt_arrEBYFrip8JCRp0dxoUX_vQV)
		{
			return false;
		}
		if (sbt_4WgeVBy6J_wlvKL != pObject->sbt_4WgeVBy6J_wlvKL)
		{
			return false;
		}
		if (sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma != pObject->sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma)
		{
			return false;
		}
		if (sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.size() != pObject->sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.size(); i++)
		{
			if (sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo[i] != pObject->sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo[i])
			{
				return false;
			}
		}
		if (sbt_mgHgPIYMzEcpTj4EkVYTGH5.size() != pObject->sbt_mgHgPIYMzEcpTj4EkVYTGH5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mgHgPIYMzEcpTj4EkVYTGH5.size(); i++)
		{
			if (sbt_mgHgPIYMzEcpTj4EkVYTGH5[i] != pObject->sbt_mgHgPIYMzEcpTj4EkVYTGH5[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr.c_str(), pObject->sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr.c_str()))
		{
			return false;
		}
		if (sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3 != pObject->sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3)
		{
			return false;
		}
		if (sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.size() != pObject->sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H[i].c_str(), pObject->sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_r54CotsMF.size() != pObject->sbt_r54CotsMF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r54CotsMF.size(); i++)
		{
			if (sbt_r54CotsMF[i] != pObject->sbt_r54CotsMF[i])
			{
				return false;
			}
		}
		if (sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.size() != pObject->sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.size(); i++)
		{
			if (sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj[i] != pObject->sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj[i])
			{
				return false;
			}
		}
		if (sbt_bO_xEJ3s1Yt != pObject->sbt_bO_xEJ3s1Yt)
		{
			return false;
		}
		if (sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.size() != pObject->sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.size(); i++)
		{
			if (sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG[i] != pObject->sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG[i])
			{
				return false;
			}
		}
		if (!sbt_k.Compare(&pObject->sbt_k))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_E5P8j65a9WXHowRYqbd_rASO_545w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E5P8j65a9WXHowRYqbd_rASO_545w = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_iMENvfHia4Z1CxDZcwOsLEd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iMENvfHia4Z1CxDZcwOsLEd.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_xjKIIKiX9xksvupb9Nsd2", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_xjKIIKiX9xksvupb9Nsd2 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_fRPKINm9IBUcuVBiWz9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fRPKINm9IBUcuVBiWz9.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yaw0jTDtwrfG2jcmu4U2jNV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yaw0jTDtwrfG2jcmu4U2jNV.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_IgZGqrnL7XV", &sbt_IgZGqrnL7XV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XxK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XxK.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_R3gfkU9BAzA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_R3gfkU9BAzA = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WaV242O7i")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WaV242O7i.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_arrEBYFrip8JCRp0dxoUX_vQV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_arrEBYFrip8JCRp0dxoUX_vQV = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_4WgeVBy6J_wlvKL", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_4WgeVBy6J_wlvKL = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mgHgPIYMzEcpTj4EkVYTGH5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mgHgPIYMzEcpTj4EkVYTGH5.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr", &sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_r54CotsMF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r54CotsMF.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_bO_xEJ3s1Yt", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_bO_xEJ3s1Yt = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_k")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_k.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d", (CX::Int64)sbt_sJKsxkz9mR8Of4zXIxFeof5kBsWjFKhQ_2mfxtjFuJjogUkUWBSqaQv7OkC9d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_E5P8j65a9WXHowRYqbd_rASO_545w", (CX::Int64)sbt_E5P8j65a9WXHowRYqbd_rASO_545w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.begin(); iter != sbt_VpZs9pK0yr3RYNkvUHVvabAHn4KzLGpToPyXgUzHuzaptB1CFotMg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iMENvfHia4Z1CxDZcwOsLEd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_iMENvfHia4Z1CxDZcwOsLEd.begin(); iter != sbt_iMENvfHia4Z1CxDZcwOsLEd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK", (CX::Int64)sbt_DEBesZG1gDA1rQeL6yVryv84vCbEK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_xjKIIKiX9xksvupb9Nsd2", (CX::Double)sbt_xjKIIKiX9xksvupb9Nsd2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fRPKINm9IBUcuVBiWz9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_fRPKINm9IBUcuVBiWz9.begin(); iter != sbt_fRPKINm9IBUcuVBiWz9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.begin(); iter != sbt_qF21vOCQnfWz_Js2O5uWkDX3Xvqt2Jq460z0Qm6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.begin(); iter != sbt_A476vdszODQglUPvQboX8GWMknt_6K5fegH90WSDPKDaBCVNHtpExS6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.begin(); iter != sbt_pEmBuopq8oyXHbk5MVmhWsec8tkmPKWLvNJK4oUKsG0yUe6RYiLQTmr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.begin(); iter != sbt_B0iqHZ8DNPjEcSYZ52PhIZsD8Fiiy4O5Q4kMAAcQXLR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yaw0jTDtwrfG2jcmu4U2jNV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_yaw0jTDtwrfG2jcmu4U2jNV.begin(); iter != sbt_yaw0jTDtwrfG2jcmu4U2jNV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_IgZGqrnL7XV", sbt_IgZGqrnL7XV.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XxK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_XxK.begin(); iter != sbt_XxK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_R3gfkU9BAzA", (CX::Int64)sbt_R3gfkU9BAzA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WaV242O7i")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_WaV242O7i.begin(); iter != sbt_WaV242O7i.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.begin(); iter != sbt_JssasA2p0OWtmEF00MmrgIHkHBE47bhTGQx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_arrEBYFrip8JCRp0dxoUX_vQV", (CX::Int64)sbt_arrEBYFrip8JCRp0dxoUX_vQV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_4WgeVBy6J_wlvKL", (CX::Double)sbt_4WgeVBy6J_wlvKL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma", (CX::Int64)sbt_H40TJ1Az3V0Hsa6zVTqr_S3K_4yZaP19aJ6IvBQ50iAO9h_PTma)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.begin(); iter != sbt_f1xg4if09BHMpUI48Mvq9rN621wTiG0yo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mgHgPIYMzEcpTj4EkVYTGH5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_mgHgPIYMzEcpTj4EkVYTGH5.begin(); iter != sbt_mgHgPIYMzEcpTj4EkVYTGH5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr", sbt_BwdaOVxOn9iC5AFUxFXbnlOZAMbElDuZWixWLLUCuB_LwplfyI2NkMr.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3", (CX::Int64)sbt_8IqtjSivKbIaf8h0qh55r1BbpzNVVjKr3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.begin(); iter != sbt_VxMNSRJszegVgwmxYMXvE4HiGONJsEx5WHLA4hwfoLouEMbq3r4MODcfIKn5S2H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_r54CotsMF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_r54CotsMF.begin(); iter != sbt_r54CotsMF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.begin(); iter != sbt_UrlHj6jRS3vkxr3E0Ou5DWxgdDifj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_bO_xEJ3s1Yt", (CX::Double)sbt_bO_xEJ3s1Yt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.begin(); iter != sbt_nIfmoBbqDBQUxK750o0GxrUgjAF3t3nUL1p8By1vjEd6RYkXziykdPJbaRG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_k")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_k.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr>::Type sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLrArray;

