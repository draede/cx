
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK;
	CX::UInt8 sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg;
	CX::IO::SimpleBuffers::Int32Array sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e;
	CX::Int32 sbt_gj10mY7NK;
	CX::IO::SimpleBuffers::StringArray sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy;
	CX::Int8 sbt_YTfJvBTKzWl1_FxWnlwYm;
	CX::UInt64 sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m;
	CX::UInt64 sbt_K62TixJNF;
	CX::IO::SimpleBuffers::UInt16Array sbt_pANUnCoQSjkuF8lOXsRu3JK111m;
	CX::Int16 sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E;
	CX::Int16 sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB;
	CX::IO::SimpleBuffers::UInt16Array sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv;
	CX::UInt32 sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z;
	CX::IO::SimpleBuffers::UInt32Array sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB;
	CX::IO::SimpleBuffers::UInt32Array sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb;
	CX::IO::SimpleBuffers::BoolArray sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU;
	CX::IO::SimpleBuffers::UInt32Array sbt_j4J2OWOO5AfGVTRWT6pSAQg;
	CX::Int32 sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S;
	CX::IO::SimpleBuffers::StringArray sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA;
	CX::IO::SimpleBuffers::BoolArray sbt_Sk3qWVl5i6jT_GtPSUj;
	CX::IO::SimpleBuffers::StringArray sbt_5_qo4TsWwTLv0;
	CX::IO::SimpleBuffers::StringArray sbt_1i9iGCzmFSD;

	virtual void Reset()
	{
		sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.clear();
		sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg = 0;
		sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.clear();
		sbt_gj10mY7NK = 0;
		sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.clear();
		sbt_YTfJvBTKzWl1_FxWnlwYm = 0;
		sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m = 0;
		sbt_K62TixJNF = 0;
		sbt_pANUnCoQSjkuF8lOXsRu3JK111m.clear();
		sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E = 0;
		sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB = 0;
		sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.clear();
		sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z = 0;
		sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.clear();
		sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.clear();
		sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.clear();
		sbt_j4J2OWOO5AfGVTRWT6pSAQg.clear();
		sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S = 0;
		sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.clear();
		sbt_Sk3qWVl5i6jT_GtPSUj.clear();
		sbt_5_qo4TsWwTLv0.clear();
		sbt_1i9iGCzmFSD.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.push_back(1064709958);
		}
		sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg = 151;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.push_back(-839422278);
		}
		sbt_gj10mY7NK = 953372769;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.push_back("#E6M7.0r2CkZxb#ZyPo_Cc+,gJOm3b_Q>P6NbB/m_s~OB");
		}
		sbt_YTfJvBTKzWl1_FxWnlwYm = -44;
		sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m = 4307984940414654418;
		sbt_K62TixJNF = 8213080722224278694;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_pANUnCoQSjkuF8lOXsRu3JK111m.push_back(50342);
		}
		sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E = 27153;
		sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB = 16102;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.push_back(15244);
		}
		sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z = 1746909645;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.push_back(735499376);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.push_back(899261426);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.push_back(false);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_j4J2OWOO5AfGVTRWT6pSAQg.push_back(287027390);
		}
		sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S = 946678484;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.push_back("+V=C4kKabEqW[A|?hw`qB;(u=4:c\\u\"J8Q):BDU0%PkPE6@NNL=Xw?)V");
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Sk3qWVl5i6jT_GtPSUj.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_5_qo4TsWwTLv0.push_back("ID?tF?a`nTk1z>0]f");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_1i9iGCzmFSD.push_back("s}Qf;R~Vp");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA *pObject = dynamic_cast<const sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.size() != pObject->sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.size(); i++)
		{
			if (sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK[i] != pObject->sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK[i])
			{
				return false;
			}
		}
		if (sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg != pObject->sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg)
		{
			return false;
		}
		if (sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.size() != pObject->sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.size(); i++)
		{
			if (sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e[i] != pObject->sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e[i])
			{
				return false;
			}
		}
		if (sbt_gj10mY7NK != pObject->sbt_gj10mY7NK)
		{
			return false;
		}
		if (sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.size() != pObject->sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.size(); i++)
		{
			if (0 != cx_strcmp(sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy[i].c_str(), pObject->sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_YTfJvBTKzWl1_FxWnlwYm != pObject->sbt_YTfJvBTKzWl1_FxWnlwYm)
		{
			return false;
		}
		if (sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m != pObject->sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m)
		{
			return false;
		}
		if (sbt_K62TixJNF != pObject->sbt_K62TixJNF)
		{
			return false;
		}
		if (sbt_pANUnCoQSjkuF8lOXsRu3JK111m.size() != pObject->sbt_pANUnCoQSjkuF8lOXsRu3JK111m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pANUnCoQSjkuF8lOXsRu3JK111m.size(); i++)
		{
			if (sbt_pANUnCoQSjkuF8lOXsRu3JK111m[i] != pObject->sbt_pANUnCoQSjkuF8lOXsRu3JK111m[i])
			{
				return false;
			}
		}
		if (sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E != pObject->sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E)
		{
			return false;
		}
		if (sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB != pObject->sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB)
		{
			return false;
		}
		if (sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.size() != pObject->sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.size(); i++)
		{
			if (sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv[i] != pObject->sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv[i])
			{
				return false;
			}
		}
		if (sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z != pObject->sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z)
		{
			return false;
		}
		if (sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.size() != pObject->sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.size(); i++)
		{
			if (sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB[i] != pObject->sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB[i])
			{
				return false;
			}
		}
		if (sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.size() != pObject->sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.size(); i++)
		{
			if (sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb[i] != pObject->sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb[i])
			{
				return false;
			}
		}
		if (sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.size() != pObject->sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.size(); i++)
		{
			if (sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU[i] != pObject->sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU[i])
			{
				return false;
			}
		}
		if (sbt_j4J2OWOO5AfGVTRWT6pSAQg.size() != pObject->sbt_j4J2OWOO5AfGVTRWT6pSAQg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j4J2OWOO5AfGVTRWT6pSAQg.size(); i++)
		{
			if (sbt_j4J2OWOO5AfGVTRWT6pSAQg[i] != pObject->sbt_j4J2OWOO5AfGVTRWT6pSAQg[i])
			{
				return false;
			}
		}
		if (sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S != pObject->sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S)
		{
			return false;
		}
		if (sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.size() != pObject->sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.size(); i++)
		{
			if (0 != cx_strcmp(sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA[i].c_str(), pObject->sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Sk3qWVl5i6jT_GtPSUj.size() != pObject->sbt_Sk3qWVl5i6jT_GtPSUj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Sk3qWVl5i6jT_GtPSUj.size(); i++)
		{
			if (sbt_Sk3qWVl5i6jT_GtPSUj[i] != pObject->sbt_Sk3qWVl5i6jT_GtPSUj[i])
			{
				return false;
			}
		}
		if (sbt_5_qo4TsWwTLv0.size() != pObject->sbt_5_qo4TsWwTLv0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5_qo4TsWwTLv0.size(); i++)
		{
			if (0 != cx_strcmp(sbt_5_qo4TsWwTLv0[i].c_str(), pObject->sbt_5_qo4TsWwTLv0[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_1i9iGCzmFSD.size() != pObject->sbt_1i9iGCzmFSD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1i9iGCzmFSD.size(); i++)
		{
			if (0 != cx_strcmp(sbt_1i9iGCzmFSD[i].c_str(), pObject->sbt_1i9iGCzmFSD[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gj10mY7NK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gj10mY7NK = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YTfJvBTKzWl1_FxWnlwYm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YTfJvBTKzWl1_FxWnlwYm = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_K62TixJNF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_K62TixJNF = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pANUnCoQSjkuF8lOXsRu3JK111m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pANUnCoQSjkuF8lOXsRu3JK111m.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j4J2OWOO5AfGVTRWT6pSAQg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j4J2OWOO5AfGVTRWT6pSAQg.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Sk3qWVl5i6jT_GtPSUj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Sk3qWVl5i6jT_GtPSUj.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5_qo4TsWwTLv0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5_qo4TsWwTLv0.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1i9iGCzmFSD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1i9iGCzmFSD.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.begin(); iter != sbt_hmRQvMSjKXqioV8J9brmIZZ7PnRaNRsypgmO8X8NKPDzfl_gK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg", (CX::Int64)sbt__VJBPcqCQMpecyU1X_eUWyMIxlTTjg5veHNB5b5j8WLCQe09QfGKWk3SRIbyg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.begin(); iter != sbt_mvL5bi2rVd3zpWD203raosvi1vZDic2QI45Hf3B5e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gj10mY7NK", (CX::Int64)sbt_gj10mY7NK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.begin(); iter != sbt_pdXzc8HNOYtYl6VoKzDaXt2Fw97WUpi9MwgcmD2fy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YTfJvBTKzWl1_FxWnlwYm", (CX::Int64)sbt_YTfJvBTKzWl1_FxWnlwYm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m", (CX::Int64)sbt_Bkf3fCYEUlgr6CShfdDebWmQUPTDVA4iDdO6wVvJuHlQPf7JMeAiA4m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_K62TixJNF", (CX::Int64)sbt_K62TixJNF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pANUnCoQSjkuF8lOXsRu3JK111m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_pANUnCoQSjkuF8lOXsRu3JK111m.begin(); iter != sbt_pANUnCoQSjkuF8lOXsRu3JK111m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E", (CX::Int64)sbt_JLy55Kk1bP_W9egmOFRacydrhYRGMLNVub5NqErCc1Bswqd12eENrTXvE8E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB", (CX::Int64)sbt_dMTvLnr9iixKeDJok3CxRqevzygnWU9O1C_jfHKNKApqcfPAscTPJtb4MGZzhJB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.begin(); iter != sbt_fuvk_kbiJt1Rgr9xEB4zTRD2hRcivTdM72uRv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z", (CX::Int64)sbt_CvYGu80L4iHc1UMBWHB588aW7IzFr8NlWZLgifg5YtkMSVxShUhPs2Qd3w1Xs8Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.begin(); iter != sbt_DcpDCgs2glrZaTFgWNjd4hkco1mdotvaB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.begin(); iter != sbt_Imphs9UZ5UcoSeNBqV0doFaxrHI8SSpNqU1pZlb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.begin(); iter != sbt_k8PFk87V4XLWtOpwgX4SQYlSSMTjYh4E1qAiksmpQlhA5ZYJ3GU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j4J2OWOO5AfGVTRWT6pSAQg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_j4J2OWOO5AfGVTRWT6pSAQg.begin(); iter != sbt_j4J2OWOO5AfGVTRWT6pSAQg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S", (CX::Int64)sbt_5J4B2kBOe7Yyvvc7nzA2oGEdxZEoZ1S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.begin(); iter != sbt_uaOjfnaUaHi0aFtXXHIJavUBGzlwU2y4FpUWA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Sk3qWVl5i6jT_GtPSUj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Sk3qWVl5i6jT_GtPSUj.begin(); iter != sbt_Sk3qWVl5i6jT_GtPSUj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5_qo4TsWwTLv0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_5_qo4TsWwTLv0.begin(); iter != sbt_5_qo4TsWwTLv0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1i9iGCzmFSD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_1i9iGCzmFSD.begin(); iter != sbt_1i9iGCzmFSD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA>::Type sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pAArray;

