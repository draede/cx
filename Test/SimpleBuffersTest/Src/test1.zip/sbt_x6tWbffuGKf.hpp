
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_x6tWbffuGKf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5;
	CX::UInt64 sbt_CspM6rrZz;
	CX::IO::SimpleBuffers::UInt16Array sbt_JmGTEsm;
	CX::Int8 sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH;
	CX::UInt32 sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN;
	CX::UInt32 sbt_HPgsl2XRLTKVLuO;
	CX::UInt32 sbt_Yayjhs0BP04;
	CX::UInt8 sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ;
	CX::UInt64 sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N;
	CX::IO::SimpleBuffers::Int8Array sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF;
	CX::IO::SimpleBuffers::StringArray sbt_olNBYsz1WySR6i90JZOGs;
	CX::IO::SimpleBuffers::UInt32Array sbt_CHKl5UczOkBrICuu_XofDNsRu;
	CX::Int32 sbt_AYD;
	CX::IO::SimpleBuffers::StringArray sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9;
	CX::IO::SimpleBuffers::BoolArray sbt_faZM_;
	CX::UInt32 sbt_4wdSGOXRhrO5a;
	CX::UInt16 sbt_n2dpUfI;
	CX::Int32 sbt_g8pfB1LhRrmFW;
	CX::Bool sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP;
	CX::IO::SimpleBuffers::UInt16Array sbt_dd1W2Ftz0Tx3u;
	CX::UInt8 sbt_zc3Sk;
	CX::UInt64 sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq;

	virtual void Reset()
	{
		sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.clear();
		sbt_CspM6rrZz = 0;
		sbt_JmGTEsm.clear();
		sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH = 0;
		sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN = 0;
		sbt_HPgsl2XRLTKVLuO = 0;
		sbt_Yayjhs0BP04 = 0;
		sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ = 0;
		sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N = 0;
		sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.clear();
		sbt_olNBYsz1WySR6i90JZOGs.clear();
		sbt_CHKl5UczOkBrICuu_XofDNsRu.clear();
		sbt_AYD = 0;
		sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.clear();
		sbt_faZM_.clear();
		sbt_4wdSGOXRhrO5a = 0;
		sbt_n2dpUfI = 0;
		sbt_g8pfB1LhRrmFW = 0;
		sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP = false;
		sbt_dd1W2Ftz0Tx3u.clear();
		sbt_zc3Sk = 0;
		sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.push_back(-19920);
		}
		sbt_CspM6rrZz = 8877464694178365332;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JmGTEsm.push_back(51997);
		}
		sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH = 4;
		sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN = 4045121644;
		sbt_HPgsl2XRLTKVLuO = 2447825214;
		sbt_Yayjhs0BP04 = 3770106564;
		sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ = 109;
		sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N = 7336670949588170400;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.push_back(-59);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_olNBYsz1WySR6i90JZOGs.push_back("FHVqX<-~$./|?P6:;!hH0srN");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_CHKl5UczOkBrICuu_XofDNsRu.push_back(3690658759);
		}
		sbt_AYD = -1978675875;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.push_back("|kJgrg/q>\\wtUzf\"H'VGViaux4ln,X/xwzB]iYk&Cf>z&OgKVN]&j^{SfC\\");
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_faZM_.push_back(false);
		}
		sbt_4wdSGOXRhrO5a = 564410229;
		sbt_n2dpUfI = 36443;
		sbt_g8pfB1LhRrmFW = -479537593;
		sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP = false;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_dd1W2Ftz0Tx3u.push_back(23288);
		}
		sbt_zc3Sk = 29;
		sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq = 13046954625532108928;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_x6tWbffuGKf *pObject = dynamic_cast<const sbt_x6tWbffuGKf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.size() != pObject->sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.size(); i++)
		{
			if (sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5[i] != pObject->sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5[i])
			{
				return false;
			}
		}
		if (sbt_CspM6rrZz != pObject->sbt_CspM6rrZz)
		{
			return false;
		}
		if (sbt_JmGTEsm.size() != pObject->sbt_JmGTEsm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JmGTEsm.size(); i++)
		{
			if (sbt_JmGTEsm[i] != pObject->sbt_JmGTEsm[i])
			{
				return false;
			}
		}
		if (sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH != pObject->sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH)
		{
			return false;
		}
		if (sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN != pObject->sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN)
		{
			return false;
		}
		if (sbt_HPgsl2XRLTKVLuO != pObject->sbt_HPgsl2XRLTKVLuO)
		{
			return false;
		}
		if (sbt_Yayjhs0BP04 != pObject->sbt_Yayjhs0BP04)
		{
			return false;
		}
		if (sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ != pObject->sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ)
		{
			return false;
		}
		if (sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N != pObject->sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N)
		{
			return false;
		}
		if (sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.size() != pObject->sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.size(); i++)
		{
			if (sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF[i] != pObject->sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF[i])
			{
				return false;
			}
		}
		if (sbt_olNBYsz1WySR6i90JZOGs.size() != pObject->sbt_olNBYsz1WySR6i90JZOGs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_olNBYsz1WySR6i90JZOGs.size(); i++)
		{
			if (0 != cx_strcmp(sbt_olNBYsz1WySR6i90JZOGs[i].c_str(), pObject->sbt_olNBYsz1WySR6i90JZOGs[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_CHKl5UczOkBrICuu_XofDNsRu.size() != pObject->sbt_CHKl5UczOkBrICuu_XofDNsRu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CHKl5UczOkBrICuu_XofDNsRu.size(); i++)
		{
			if (sbt_CHKl5UczOkBrICuu_XofDNsRu[i] != pObject->sbt_CHKl5UczOkBrICuu_XofDNsRu[i])
			{
				return false;
			}
		}
		if (sbt_AYD != pObject->sbt_AYD)
		{
			return false;
		}
		if (sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.size() != pObject->sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.size(); i++)
		{
			if (0 != cx_strcmp(sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9[i].c_str(), pObject->sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_faZM_.size() != pObject->sbt_faZM_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_faZM_.size(); i++)
		{
			if (sbt_faZM_[i] != pObject->sbt_faZM_[i])
			{
				return false;
			}
		}
		if (sbt_4wdSGOXRhrO5a != pObject->sbt_4wdSGOXRhrO5a)
		{
			return false;
		}
		if (sbt_n2dpUfI != pObject->sbt_n2dpUfI)
		{
			return false;
		}
		if (sbt_g8pfB1LhRrmFW != pObject->sbt_g8pfB1LhRrmFW)
		{
			return false;
		}
		if (sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP != pObject->sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP)
		{
			return false;
		}
		if (sbt_dd1W2Ftz0Tx3u.size() != pObject->sbt_dd1W2Ftz0Tx3u.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dd1W2Ftz0Tx3u.size(); i++)
		{
			if (sbt_dd1W2Ftz0Tx3u[i] != pObject->sbt_dd1W2Ftz0Tx3u[i])
			{
				return false;
			}
		}
		if (sbt_zc3Sk != pObject->sbt_zc3Sk)
		{
			return false;
		}
		if (sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq != pObject->sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CspM6rrZz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CspM6rrZz = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JmGTEsm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JmGTEsm.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HPgsl2XRLTKVLuO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HPgsl2XRLTKVLuO = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Yayjhs0BP04", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Yayjhs0BP04 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_olNBYsz1WySR6i90JZOGs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_olNBYsz1WySR6i90JZOGs.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CHKl5UczOkBrICuu_XofDNsRu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CHKl5UczOkBrICuu_XofDNsRu.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AYD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AYD = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_faZM_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_faZM_.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4wdSGOXRhrO5a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4wdSGOXRhrO5a = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_n2dpUfI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n2dpUfI = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_g8pfB1LhRrmFW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_g8pfB1LhRrmFW = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP", &sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dd1W2Ftz0Tx3u")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dd1W2Ftz0Tx3u.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zc3Sk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zc3Sk = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.begin(); iter != sbt_VaOKQVi_y_X4G5DtLX8wwJLdfHsgS3qmYnAtyAvT5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CspM6rrZz", (CX::Int64)sbt_CspM6rrZz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JmGTEsm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_JmGTEsm.begin(); iter != sbt_JmGTEsm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH", (CX::Int64)sbt_mw2lH2nL34BYKZW83KGaHbeCbGh_4MCSogRSDkH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN", (CX::Int64)sbt_e9EBCDjFQADm8EUqkuQFjWSLr3NNDBXNPoKZZC0rLbEbASnJf5STN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HPgsl2XRLTKVLuO", (CX::Int64)sbt_HPgsl2XRLTKVLuO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Yayjhs0BP04", (CX::Int64)sbt_Yayjhs0BP04)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ", (CX::Int64)sbt_M1WjWtN2h7Z7mdCWcWOYNcYWmhE_y5MDMmiZNvc_2xnHn7iQQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N", (CX::Int64)sbt_yWsDjxabvHj6IfqNEFXfseWPCh3mWgaR0_bLTgtqi2lHz4AJ5L_t_J0Zi_N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.begin(); iter != sbt_E1VGbla4fdKyAsQgjqwzydLimIoLF47DkqF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_olNBYsz1WySR6i90JZOGs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_olNBYsz1WySR6i90JZOGs.begin(); iter != sbt_olNBYsz1WySR6i90JZOGs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CHKl5UczOkBrICuu_XofDNsRu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_CHKl5UczOkBrICuu_XofDNsRu.begin(); iter != sbt_CHKl5UczOkBrICuu_XofDNsRu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AYD", (CX::Int64)sbt_AYD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.begin(); iter != sbt_IRudPb7PUez7vjlveitkxLcmMwVAFfZQTDOcurTQ9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_faZM_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_faZM_.begin(); iter != sbt_faZM_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4wdSGOXRhrO5a", (CX::Int64)sbt_4wdSGOXRhrO5a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n2dpUfI", (CX::Int64)sbt_n2dpUfI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_g8pfB1LhRrmFW", (CX::Int64)sbt_g8pfB1LhRrmFW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP", sbt_DhEqCWOkmKxT3wIXKnx3NDAhXnmB6VR8OCUkHVuFJtGMP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dd1W2Ftz0Tx3u")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_dd1W2Ftz0Tx3u.begin(); iter != sbt_dd1W2Ftz0Tx3u.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zc3Sk", (CX::Int64)sbt_zc3Sk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq", (CX::Int64)sbt_WyTQ6JmmNOaysx3whaZ8SyuXgbSKQSxuumalpCeEEuq)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_x6tWbffuGKf>::Type sbt_x6tWbffuGKfArray;

