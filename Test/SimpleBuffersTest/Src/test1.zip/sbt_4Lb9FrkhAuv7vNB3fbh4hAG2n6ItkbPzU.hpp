
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_hZkuPVzuXfA;
	CX::IO::SimpleBuffers::StringArray sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE;

	virtual void Reset()
	{
		sbt_hZkuPVzuXfA.clear();
		sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_hZkuPVzuXfA.push_back(-3111486778166653644);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.push_back("=,E\\`T&7AlSlM=`1K4?L>fC");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU *pObject = dynamic_cast<const sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_hZkuPVzuXfA.size() != pObject->sbt_hZkuPVzuXfA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hZkuPVzuXfA.size(); i++)
		{
			if (sbt_hZkuPVzuXfA[i] != pObject->sbt_hZkuPVzuXfA[i])
			{
				return false;
			}
		}
		if (sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.size() != pObject->sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.size(); i++)
		{
			if (0 != cx_strcmp(sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE[i].c_str(), pObject->sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_hZkuPVzuXfA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hZkuPVzuXfA.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_hZkuPVzuXfA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_hZkuPVzuXfA.begin(); iter != sbt_hZkuPVzuXfA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.begin(); iter != sbt_I7xRCvTiHq4QPsYj8ypANTnWdIndhT0GUKTDvy9uwi6WGCEyE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU>::Type sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzUArray;

