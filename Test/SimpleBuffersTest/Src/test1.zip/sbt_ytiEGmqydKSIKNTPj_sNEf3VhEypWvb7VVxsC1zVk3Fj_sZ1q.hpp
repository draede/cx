
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI;
	CX::Int64 sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx;

	virtual void Reset()
	{
		sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.clear();
		sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.push_back(13997880901366877362);
		}
		sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx = 5381329347006836384;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q *pObject = dynamic_cast<const sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.size() != pObject->sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.size(); i++)
		{
			if (sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI[i] != pObject->sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI[i])
			{
				return false;
			}
		}
		if (sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx != pObject->sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx = (CX::Int64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.begin(); iter != sbt_gMvF1eNmBS1uQjFQnj9tKZ0YwlmqDSoAI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx", (CX::Int64)sbt_nTRKVYHZbHCUgrnzNTE6ThUVt0EV_8FQk1XDouP5__Uye9sjx)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q>::Type sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1qArray;

