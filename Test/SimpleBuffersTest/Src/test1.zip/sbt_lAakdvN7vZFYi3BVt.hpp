
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_lAakdvN7vZFYi3BVt : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_Li1ewcOuOrBHk;
	CX::IO::SimpleBuffers::Int8Array sbt_FrD6kF2xQgUEF2haPBggIL5O_ie;
	CX::IO::SimpleBuffers::BoolArray sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi;
	CX::IO::SimpleBuffers::StringArray sbt_s8JHGYSlgx2jypgXSqD4r;
	CX::IO::SimpleBuffers::BoolArray sbt_8;
	CX::UInt32 sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO;
	CX::Int16 sbt_V80ik;
	CX::IO::SimpleBuffers::UInt16Array sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6;
	CX::UInt64 sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j;
	CX::Int8 sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E;
	CX::Int16 sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk;
	CX::IO::SimpleBuffers::Int32Array sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc;
	CX::IO::SimpleBuffers::UInt64Array sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ;
	CX::UInt16 sbt_tGPsT8yI9;
	CX::IO::SimpleBuffers::StringArray sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC;
	CX::UInt16 sbt_uI2OTw2;
	CX::IO::SimpleBuffers::UInt32Array sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF;
	CX::Bool sbt_n9Vfd7E;

	virtual void Reset()
	{
		sbt_Li1ewcOuOrBHk.clear();
		sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.clear();
		sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.clear();
		sbt_s8JHGYSlgx2jypgXSqD4r.clear();
		sbt_8.clear();
		sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO = 0;
		sbt_V80ik = 0;
		sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.clear();
		sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j = 0;
		sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E = 0;
		sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk = 0;
		sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.clear();
		sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.clear();
		sbt_tGPsT8yI9 = 0;
		sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.clear();
		sbt_uI2OTw2 = 0;
		sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.clear();
		sbt_n9Vfd7E = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_Li1ewcOuOrBHk.push_back(7865603427890813842);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.push_back(-65);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.push_back(false);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_8.push_back(false);
		}
		sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO = 1546070762;
		sbt_V80ik = 8128;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.push_back(3632);
		}
		sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j = 17953512910504582628;
		sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E = -114;
		sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk = 25817;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.push_back(-1928176539);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.push_back(2550732210892780588);
		}
		sbt_tGPsT8yI9 = 23827;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.push_back("lqP&$Jlrb.r>}&k@q9lD^;ql>6Kz/Vw6");
		}
		sbt_uI2OTw2 = 44270;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.push_back(1960754251);
		}
		sbt_n9Vfd7E = true;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_lAakdvN7vZFYi3BVt *pObject = dynamic_cast<const sbt_lAakdvN7vZFYi3BVt *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Li1ewcOuOrBHk.size() != pObject->sbt_Li1ewcOuOrBHk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Li1ewcOuOrBHk.size(); i++)
		{
			if (sbt_Li1ewcOuOrBHk[i] != pObject->sbt_Li1ewcOuOrBHk[i])
			{
				return false;
			}
		}
		if (sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.size() != pObject->sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.size(); i++)
		{
			if (sbt_FrD6kF2xQgUEF2haPBggIL5O_ie[i] != pObject->sbt_FrD6kF2xQgUEF2haPBggIL5O_ie[i])
			{
				return false;
			}
		}
		if (sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.size() != pObject->sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.size(); i++)
		{
			if (sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi[i] != pObject->sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi[i])
			{
				return false;
			}
		}
		if (sbt_s8JHGYSlgx2jypgXSqD4r.size() != pObject->sbt_s8JHGYSlgx2jypgXSqD4r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s8JHGYSlgx2jypgXSqD4r.size(); i++)
		{
			if (0 != cx_strcmp(sbt_s8JHGYSlgx2jypgXSqD4r[i].c_str(), pObject->sbt_s8JHGYSlgx2jypgXSqD4r[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_8.size() != pObject->sbt_8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8.size(); i++)
		{
			if (sbt_8[i] != pObject->sbt_8[i])
			{
				return false;
			}
		}
		if (sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO != pObject->sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO)
		{
			return false;
		}
		if (sbt_V80ik != pObject->sbt_V80ik)
		{
			return false;
		}
		if (sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.size() != pObject->sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.size(); i++)
		{
			if (sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6[i] != pObject->sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6[i])
			{
				return false;
			}
		}
		if (sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j != pObject->sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j)
		{
			return false;
		}
		if (sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E != pObject->sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E)
		{
			return false;
		}
		if (sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk != pObject->sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk)
		{
			return false;
		}
		if (sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.size() != pObject->sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.size(); i++)
		{
			if (sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc[i] != pObject->sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc[i])
			{
				return false;
			}
		}
		if (sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.size() != pObject->sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.size(); i++)
		{
			if (sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ[i] != pObject->sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ[i])
			{
				return false;
			}
		}
		if (sbt_tGPsT8yI9 != pObject->sbt_tGPsT8yI9)
		{
			return false;
		}
		if (sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.size() != pObject->sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.size(); i++)
		{
			if (0 != cx_strcmp(sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC[i].c_str(), pObject->sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_uI2OTw2 != pObject->sbt_uI2OTw2)
		{
			return false;
		}
		if (sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.size() != pObject->sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.size(); i++)
		{
			if (sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF[i] != pObject->sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF[i])
			{
				return false;
			}
		}
		if (sbt_n9Vfd7E != pObject->sbt_n9Vfd7E)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Li1ewcOuOrBHk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Li1ewcOuOrBHk.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FrD6kF2xQgUEF2haPBggIL5O_ie")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s8JHGYSlgx2jypgXSqD4r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s8JHGYSlgx2jypgXSqD4r.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_V80ik", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_V80ik = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tGPsT8yI9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tGPsT8yI9 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_uI2OTw2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uI2OTw2 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_n9Vfd7E", &sbt_n9Vfd7E)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Li1ewcOuOrBHk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Li1ewcOuOrBHk.begin(); iter != sbt_Li1ewcOuOrBHk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FrD6kF2xQgUEF2haPBggIL5O_ie")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.begin(); iter != sbt_FrD6kF2xQgUEF2haPBggIL5O_ie.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.begin(); iter != sbt_eOlkqsHAGiFgl5OyKBYvAa8kgSi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s8JHGYSlgx2jypgXSqD4r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_s8JHGYSlgx2jypgXSqD4r.begin(); iter != sbt_s8JHGYSlgx2jypgXSqD4r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_8.begin(); iter != sbt_8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO", (CX::Int64)sbt_pwxQlTiyDWYJih4nrrzF77eVquNGgiJOop0xLtkuJzMs4o9ZO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_V80ik", (CX::Int64)sbt_V80ik)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.begin(); iter != sbt_8srY1RpjRykkIEteGff06O7CQOsWWZmogoJsTB6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j", (CX::Int64)sbt_jbX5e6lceLsLE1racT1GMIKW7YjzpOc_N8O3VgGwBEIQ1MyvdKc9j)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E", (CX::Int64)sbt_0q15gF0i92RRr590_yO_xCMYI9GgjI6URgJASsRFotFXb6dMZpj0E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk", (CX::Int64)sbt_70avbG_Sx7lkNEKMuhxsMD6mGHk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.begin(); iter != sbt_rdUj3aceIrY7jeo7kXCvxVEFdFKpaaLGgSlHC_vA8Fdfc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.begin(); iter != sbt_LtpMQLyGyusTmCcSkM34Isk_V2kdQL50jsHz186sb5MjQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tGPsT8yI9", (CX::Int64)sbt_tGPsT8yI9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.begin(); iter != sbt_YrVeLzQCeVxjfZk2Ul5vJJwgC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uI2OTw2", (CX::Int64)sbt_uI2OTw2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.begin(); iter != sbt_E59X1rqekTan0UG0mLWAV7zQ99Ndc2ghF1vedgxuCvJeF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_n9Vfd7E", sbt_n9Vfd7E)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_lAakdvN7vZFYi3BVt>::Type sbt_lAakdvN7vZFYi3BVtArray;

