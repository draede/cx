
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_ebD2YgyqSIxzwq4eQrvNF.hpp"


class sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk;
	CX::IO::SimpleBuffers::UInt16Array sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK;
	CX::Float sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf;
	CX::IO::SimpleBuffers::StringArray sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi;
	CX::IO::SimpleBuffers::DoubleArray sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac;
	CX::IO::SimpleBuffers::UInt64Array sbt_xaqFsUw_7PHcXSJbA;
	CX::UInt8 sbt_88l;
	CX::UInt64 sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV;
	CX::Int64 sbt_9bU2wCO;
	CX::IO::SimpleBuffers::Int64Array sbt_MRQ0I;
	CX::Int8 sbt_jKa7EyWebZLJQBiXwHG;
	CX::Int32 sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go;
	sbt_ebD2YgyqSIxzwq4eQrvNFArray sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc;

	virtual void Reset()
	{
		sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk = 0;
		sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.clear();
		sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf = 0.0f;
		sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.clear();
		sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.clear();
		sbt_xaqFsUw_7PHcXSJbA.clear();
		sbt_88l = 0;
		sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV = 0;
		sbt_9bU2wCO = 0;
		sbt_MRQ0I.clear();
		sbt_jKa7EyWebZLJQBiXwHG = 0;
		sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go = 0;
		sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk = 63;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.push_back(50538);
		}
		sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf = 0.763790f;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.push_back("D1NAkW)^[>&|KPr\"#D5|av|X;J[9vfFtaU\"d{z&|tX");
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.push_back(0.943363);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_xaqFsUw_7PHcXSJbA.push_back(10086670724930177998);
		}
		sbt_88l = 169;
		sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV = 18313315192722733644;
		sbt_9bU2wCO = -5239943783690184162;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_MRQ0I.push_back(-4747506086656639530);
		}
		sbt_jKa7EyWebZLJQBiXwHG = -93;
		sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go = 1556951914;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ebD2YgyqSIxzwq4eQrvNF v;

			v.SetupWithSomeValues();
			sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv *pObject = dynamic_cast<const sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk != pObject->sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk)
		{
			return false;
		}
		if (sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.size() != pObject->sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.size(); i++)
		{
			if (sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK[i] != pObject->sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK[i])
			{
				return false;
			}
		}
		if (sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf != pObject->sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf)
		{
			return false;
		}
		if (sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.size() != pObject->sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.size(); i++)
		{
			if (0 != cx_strcmp(sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi[i].c_str(), pObject->sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.size() != pObject->sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.size(); i++)
		{
			if (sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac[i] != pObject->sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac[i])
			{
				return false;
			}
		}
		if (sbt_xaqFsUw_7PHcXSJbA.size() != pObject->sbt_xaqFsUw_7PHcXSJbA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xaqFsUw_7PHcXSJbA.size(); i++)
		{
			if (sbt_xaqFsUw_7PHcXSJbA[i] != pObject->sbt_xaqFsUw_7PHcXSJbA[i])
			{
				return false;
			}
		}
		if (sbt_88l != pObject->sbt_88l)
		{
			return false;
		}
		if (sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV != pObject->sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV)
		{
			return false;
		}
		if (sbt_9bU2wCO != pObject->sbt_9bU2wCO)
		{
			return false;
		}
		if (sbt_MRQ0I.size() != pObject->sbt_MRQ0I.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MRQ0I.size(); i++)
		{
			if (sbt_MRQ0I[i] != pObject->sbt_MRQ0I[i])
			{
				return false;
			}
		}
		if (sbt_jKa7EyWebZLJQBiXwHG != pObject->sbt_jKa7EyWebZLJQBiXwHG)
		{
			return false;
		}
		if (sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go != pObject->sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go)
		{
			return false;
		}
		if (sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.size() != pObject->sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.size(); i++)
		{
			if (!sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc[i].Compare(&pObject->sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xaqFsUw_7PHcXSJbA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xaqFsUw_7PHcXSJbA.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_88l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_88l = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9bU2wCO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9bU2wCO = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MRQ0I")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MRQ0I.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jKa7EyWebZLJQBiXwHG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jKa7EyWebZLJQBiXwHG = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_ebD2YgyqSIxzwq4eQrvNF tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk", (CX::Int64)sbt_Bp0ugzClWvRUoYOLMO7PJnmVP8f3EnsLbNBCzdqqyWWxk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.begin(); iter != sbt_AWTNa0dVdUn8RFzLrGrewDd5kNKpMu4ZX9rb4UfIBEv4t9onK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf", (CX::Double)sbt__7zq5NidQijc6JqzBjRL3i69zOD05oIjoEH9zJV5hgf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.begin(); iter != sbt_D6MHxwb8r0JoE9OGwtBpMp8Y1bePHwKU95FAyiOXi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.begin(); iter != sbt_ChoCqGAAOVzEHW7HCZ_8qMoAcMTTdz1ihpzygFLm0DSg_Sc0jCxY2rDpkgnac.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xaqFsUw_7PHcXSJbA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_xaqFsUw_7PHcXSJbA.begin(); iter != sbt_xaqFsUw_7PHcXSJbA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_88l", (CX::Int64)sbt_88l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV", (CX::Int64)sbt_m0a5j4qVMhY4mUM1l9VqdciQZNFeV9CmSpWrtxLoQyV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9bU2wCO", (CX::Int64)sbt_9bU2wCO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MRQ0I")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_MRQ0I.begin(); iter != sbt_MRQ0I.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jKa7EyWebZLJQBiXwHG", (CX::Int64)sbt_jKa7EyWebZLJQBiXwHG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go", (CX::Int64)sbt_mColLxFDJQzGXf1oM_QyR_A0idQqK4ZwMTeKrb5Go)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc")).IsNOK())
		{
			return status;
		}
		for (sbt_ebD2YgyqSIxzwq4eQrvNFArray::const_iterator iter = sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.begin(); iter != sbt_RPhhW9oMsm5vGhlC__x9ENJFOiruN8lfJ4HkdbgBPpxvpJoLdROne4UKc.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv>::Type sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzvArray;

