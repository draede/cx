
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_LOJR6JEUd.hpp"


class sbt_YQe : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_Rtn;
	CX::Int16 sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1;
	CX::Int64 sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd;
	sbt_LOJR6JEUd sbt_HpbQ1G7;

	virtual void Reset()
	{
		sbt_Rtn.clear();
		sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1 = 0;
		sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd = 0;
		sbt_HpbQ1G7.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Rtn.push_back(1256);
		}
		sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1 = 30452;
		sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd = -1227203215077741220;
		sbt_HpbQ1G7.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_YQe *pObject = dynamic_cast<const sbt_YQe *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Rtn.size() != pObject->sbt_Rtn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Rtn.size(); i++)
		{
			if (sbt_Rtn[i] != pObject->sbt_Rtn[i])
			{
				return false;
			}
		}
		if (sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1 != pObject->sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1)
		{
			return false;
		}
		if (sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd != pObject->sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd)
		{
			return false;
		}
		if (!sbt_HpbQ1G7.Compare(&pObject->sbt_HpbQ1G7))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Rtn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Rtn.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectObject("sbt_HpbQ1G7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_HpbQ1G7.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Rtn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Rtn.begin(); iter != sbt_Rtn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1", (CX::Int64)sbt_FKVmF0w2i45krnuqowGxL66iAUPKKW8ehkaf6W0tNz1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd", (CX::Int64)sbt_b9j3bTCwp1XCbhbBdDrbgrus3Gd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_HpbQ1G7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_HpbQ1G7.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_YQe>::Type sbt_YQeArray;

