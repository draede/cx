
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_D2lgRi655HoJQnFlCbXM6T3AtbE.hpp"


class sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_U2AQzgvKXyFxAlEIubCbOTQEN;
	CX::UInt64 sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L;
	CX::IO::SimpleBuffers::Int32Array sbt_7q2;
	CX::IO::SimpleBuffers::UInt64Array sbt_NutZnFiOdOvAsj5WPKKP1;
	CX::IO::SimpleBuffers::UInt32Array sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M;
	CX::UInt8 sbt__C0KhmTvOKl;
	CX::Double sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD;
	CX::String sbt_M1eFIYB1Q3AMYIthCrrLMugJf;
	CX::Int16 sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr;
	CX::Float sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5;
	CX::String sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU;
	CX::Double sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM;
	CX::IO::SimpleBuffers::Int8Array sbt_gqqgqraJ3;
	sbt_D2lgRi655HoJQnFlCbXM6T3AtbEArray sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l;

	virtual void Reset()
	{
		sbt_U2AQzgvKXyFxAlEIubCbOTQEN.clear();
		sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L = 0;
		sbt_7q2.clear();
		sbt_NutZnFiOdOvAsj5WPKKP1.clear();
		sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.clear();
		sbt__C0KhmTvOKl = 0;
		sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD = 0.0;
		sbt_M1eFIYB1Q3AMYIthCrrLMugJf.clear();
		sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr = 0;
		sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5 = 0.0f;
		sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU.clear();
		sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM = 0.0;
		sbt_gqqgqraJ3.clear();
		sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_U2AQzgvKXyFxAlEIubCbOTQEN.push_back(120);
		}
		sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L = 7754760083460897794;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_7q2.push_back(609373352);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_NutZnFiOdOvAsj5WPKKP1.push_back(8737519602620912980);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.push_back(2261446724);
		}
		sbt__C0KhmTvOKl = 166;
		sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD = 0.193000;
		sbt_M1eFIYB1Q3AMYIthCrrLMugJf = "~S.j;TvD@mRyXlelk";
		sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr = -21125;
		sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5 = 0.645405f;
		sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU = "Z)]'mv-?\"\"C8GaYG6JH=-Bi5v?qg\"4aJ)[D*CVc;Rj`HIKN0?5TjOn";
		sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM = 0.456915;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_gqqgqraJ3.push_back(26);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_D2lgRi655HoJQnFlCbXM6T3AtbE v;

			v.SetupWithSomeValues();
			sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV *pObject = dynamic_cast<const sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_U2AQzgvKXyFxAlEIubCbOTQEN.size() != pObject->sbt_U2AQzgvKXyFxAlEIubCbOTQEN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U2AQzgvKXyFxAlEIubCbOTQEN.size(); i++)
		{
			if (sbt_U2AQzgvKXyFxAlEIubCbOTQEN[i] != pObject->sbt_U2AQzgvKXyFxAlEIubCbOTQEN[i])
			{
				return false;
			}
		}
		if (sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L != pObject->sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L)
		{
			return false;
		}
		if (sbt_7q2.size() != pObject->sbt_7q2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7q2.size(); i++)
		{
			if (sbt_7q2[i] != pObject->sbt_7q2[i])
			{
				return false;
			}
		}
		if (sbt_NutZnFiOdOvAsj5WPKKP1.size() != pObject->sbt_NutZnFiOdOvAsj5WPKKP1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NutZnFiOdOvAsj5WPKKP1.size(); i++)
		{
			if (sbt_NutZnFiOdOvAsj5WPKKP1[i] != pObject->sbt_NutZnFiOdOvAsj5WPKKP1[i])
			{
				return false;
			}
		}
		if (sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.size() != pObject->sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.size(); i++)
		{
			if (sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M[i] != pObject->sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M[i])
			{
				return false;
			}
		}
		if (sbt__C0KhmTvOKl != pObject->sbt__C0KhmTvOKl)
		{
			return false;
		}
		if (sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD != pObject->sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_M1eFIYB1Q3AMYIthCrrLMugJf.c_str(), pObject->sbt_M1eFIYB1Q3AMYIthCrrLMugJf.c_str()))
		{
			return false;
		}
		if (sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr != pObject->sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr)
		{
			return false;
		}
		if (sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5 != pObject->sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU.c_str(), pObject->sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU.c_str()))
		{
			return false;
		}
		if (sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM != pObject->sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM)
		{
			return false;
		}
		if (sbt_gqqgqraJ3.size() != pObject->sbt_gqqgqraJ3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gqqgqraJ3.size(); i++)
		{
			if (sbt_gqqgqraJ3[i] != pObject->sbt_gqqgqraJ3[i])
			{
				return false;
			}
		}
		if (sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.size() != pObject->sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.size(); i++)
		{
			if (!sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l[i].Compare(&pObject->sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_U2AQzgvKXyFxAlEIubCbOTQEN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U2AQzgvKXyFxAlEIubCbOTQEN.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7q2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7q2.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NutZnFiOdOvAsj5WPKKP1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NutZnFiOdOvAsj5WPKKP1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__C0KhmTvOKl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__C0KhmTvOKl = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectString("sbt_M1eFIYB1Q3AMYIthCrrLMugJf", &sbt_M1eFIYB1Q3AMYIthCrrLMugJf)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectString("sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU", &sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_gqqgqraJ3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gqqgqraJ3.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_D2lgRi655HoJQnFlCbXM6T3AtbE tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_U2AQzgvKXyFxAlEIubCbOTQEN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_U2AQzgvKXyFxAlEIubCbOTQEN.begin(); iter != sbt_U2AQzgvKXyFxAlEIubCbOTQEN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L", (CX::Int64)sbt_CmZc1Cj2cc1S9POzisyxakSzpM3eNUOQo7L)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7q2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_7q2.begin(); iter != sbt_7q2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NutZnFiOdOvAsj5WPKKP1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_NutZnFiOdOvAsj5WPKKP1.begin(); iter != sbt_NutZnFiOdOvAsj5WPKKP1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.begin(); iter != sbt_H1eWgPwUAuIV6qYe1RXNDfyw_bpo514nS3IGJt1bGMGdGbjI7LwxXti0u2M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__C0KhmTvOKl", (CX::Int64)sbt__C0KhmTvOKl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD", (CX::Double)sbt_PdZqElzt5x_OOt_DEvmWnHz1kb6989qJUj79QLrNsDD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_M1eFIYB1Q3AMYIthCrrLMugJf", sbt_M1eFIYB1Q3AMYIthCrrLMugJf.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr", (CX::Int64)sbt_jeKTi3LuGhx4xBzXtZsC4jwckWQdfJgFBGcODos97fS0ancvP9E9rVnTvL5cr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5", (CX::Double)sbt_CGYcqvkRR8ztWfcqyPvvPYyIwn2B5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU", sbt_qwPHJtRPCqMTWmisxRujDgeBbPTI0nt1deddKS0rHFuVC30Q9MU.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM", (CX::Double)sbt_azf80cxoo7l4nO5hFMtnidmWR0ysYjYOKnw6NNJ68ABdV554VwM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gqqgqraJ3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_gqqgqraJ3.begin(); iter != sbt_gqqgqraJ3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l")).IsNOK())
		{
			return status;
		}
		for (sbt_D2lgRi655HoJQnFlCbXM6T3AtbEArray::const_iterator iter = sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.begin(); iter != sbt_pwjZa0VPJgfhN66_UEsodMI16GWeun5E9dFLyviC3rR5QM18l.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV>::Type sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYVArray;

