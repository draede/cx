
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lAakdvN7vZFYi3BVt.hpp"


class sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd;
	CX::IO::SimpleBuffers::FloatArray sbt_7nsGzdP4lAiJYfePFMQsL8O;
	CX::Int8 sbt_lEJm81fzq0R9BeuulCkDs;
	CX::Double sbt__G3XlkZ;
	CX::IO::SimpleBuffers::FloatArray sbt_mgo;
	CX::Bool sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm;
	CX::UInt32 sbt_O7mpyenWvhbeLi8LM6bZR;
	CX::IO::SimpleBuffers::WStringArray sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY;
	CX::Int8 sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l;
	sbt_lAakdvN7vZFYi3BVtArray sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF;

	virtual void Reset()
	{
		sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.clear();
		sbt_7nsGzdP4lAiJYfePFMQsL8O.clear();
		sbt_lEJm81fzq0R9BeuulCkDs = 0;
		sbt__G3XlkZ = 0.0;
		sbt_mgo.clear();
		sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm = false;
		sbt_O7mpyenWvhbeLi8LM6bZR = 0;
		sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.clear();
		sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l = 0;
		sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.push_back(43);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_7nsGzdP4lAiJYfePFMQsL8O.push_back(0.121890f);
		}
		sbt_lEJm81fzq0R9BeuulCkDs = -49;
		sbt__G3XlkZ = 0.733428;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_mgo.push_back(0.665572f);
		}
		sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm = true;
		sbt_O7mpyenWvhbeLi8LM6bZR = 2595448129;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.push_back(L"[ucY$6L(zs<MVf\\;[X:[fc7FovZn");
		}
		sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l = -60;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_lAakdvN7vZFYi3BVt v;

			v.SetupWithSomeValues();
			sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W *pObject = dynamic_cast<const sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.size() != pObject->sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.size(); i++)
		{
			if (sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd[i] != pObject->sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd[i])
			{
				return false;
			}
		}
		if (sbt_7nsGzdP4lAiJYfePFMQsL8O.size() != pObject->sbt_7nsGzdP4lAiJYfePFMQsL8O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7nsGzdP4lAiJYfePFMQsL8O.size(); i++)
		{
			if (sbt_7nsGzdP4lAiJYfePFMQsL8O[i] != pObject->sbt_7nsGzdP4lAiJYfePFMQsL8O[i])
			{
				return false;
			}
		}
		if (sbt_lEJm81fzq0R9BeuulCkDs != pObject->sbt_lEJm81fzq0R9BeuulCkDs)
		{
			return false;
		}
		if (sbt__G3XlkZ != pObject->sbt__G3XlkZ)
		{
			return false;
		}
		if (sbt_mgo.size() != pObject->sbt_mgo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mgo.size(); i++)
		{
			if (sbt_mgo[i] != pObject->sbt_mgo[i])
			{
				return false;
			}
		}
		if (sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm != pObject->sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm)
		{
			return false;
		}
		if (sbt_O7mpyenWvhbeLi8LM6bZR != pObject->sbt_O7mpyenWvhbeLi8LM6bZR)
		{
			return false;
		}
		if (sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.size() != pObject->sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY[i].c_str(), pObject->sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l != pObject->sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l)
		{
			return false;
		}
		if (sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.size() != pObject->sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.size(); i++)
		{
			if (!sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF[i].Compare(&pObject->sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7nsGzdP4lAiJYfePFMQsL8O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7nsGzdP4lAiJYfePFMQsL8O.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lEJm81fzq0R9BeuulCkDs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lEJm81fzq0R9BeuulCkDs = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt__G3XlkZ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__G3XlkZ = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_mgo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mgo.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm", &sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_O7mpyenWvhbeLi8LM6bZR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_O7mpyenWvhbeLi8LM6bZR = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_lAakdvN7vZFYi3BVt tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.begin(); iter != sbt_MyHe0TOJ4WAIxeqPvQcsa4pllMXaTBPWM3mAu4HYd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7nsGzdP4lAiJYfePFMQsL8O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_7nsGzdP4lAiJYfePFMQsL8O.begin(); iter != sbt_7nsGzdP4lAiJYfePFMQsL8O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lEJm81fzq0R9BeuulCkDs", (CX::Int64)sbt_lEJm81fzq0R9BeuulCkDs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__G3XlkZ", (CX::Double)sbt__G3XlkZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mgo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_mgo.begin(); iter != sbt_mgo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm", sbt_yCVhJo0blf0qIYmIs_DETUerjrlLHllG4k5UObATaznIA92JR7PW6gGz48N23Jm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_O7mpyenWvhbeLi8LM6bZR", (CX::Int64)sbt_O7mpyenWvhbeLi8LM6bZR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.begin(); iter != sbt_Cd4eA0OMIn14RVFUjGpduzUp2gELwrbEwSwxZfgbVEhyY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l", (CX::Int64)sbt_I8Yl3Uq6zlwJm9_aqwh1kxbODdD6QzegWba6WK4YtAC62_1WNnduF6l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF")).IsNOK())
		{
			return status;
		}
		for (sbt_lAakdvN7vZFYi3BVtArray::const_iterator iter = sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.begin(); iter != sbt_1S5vxRON0Gk1pHjrwm5lPGYace0IUyF.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W>::Type sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1WArray;

