
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_jgDm6sWUw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL;
	CX::UInt8 sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv;
	CX::String sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE;
	CX::Int32 sbt_CxFXNgo21ATPtyIMqlouQ7bwB;
	CX::UInt64 sbt_Jx60APhCuzjvUET4_8_;

	virtual void Reset()
	{
		sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.clear();
		sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv = 0;
		sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE.clear();
		sbt_CxFXNgo21ATPtyIMqlouQ7bwB = 0;
		sbt_Jx60APhCuzjvUET4_8_ = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.push_back(2062287385);
		}
		sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv = 207;
		sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE = "$61((>!#n7F7^>jH]l/uY";
		sbt_CxFXNgo21ATPtyIMqlouQ7bwB = 1335076573;
		sbt_Jx60APhCuzjvUET4_8_ = 14294910868080512538;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_jgDm6sWUw *pObject = dynamic_cast<const sbt_jgDm6sWUw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.size() != pObject->sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.size(); i++)
		{
			if (sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL[i] != pObject->sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL[i])
			{
				return false;
			}
		}
		if (sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv != pObject->sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE.c_str(), pObject->sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE.c_str()))
		{
			return false;
		}
		if (sbt_CxFXNgo21ATPtyIMqlouQ7bwB != pObject->sbt_CxFXNgo21ATPtyIMqlouQ7bwB)
		{
			return false;
		}
		if (sbt_Jx60APhCuzjvUET4_8_ != pObject->sbt_Jx60APhCuzjvUET4_8_)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectString("sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE", &sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CxFXNgo21ATPtyIMqlouQ7bwB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CxFXNgo21ATPtyIMqlouQ7bwB = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Jx60APhCuzjvUET4_8_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Jx60APhCuzjvUET4_8_ = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.begin(); iter != sbt_U1W7b1yltP_3CB9xh8SfdZS2tS3S5KESedrQqwP9fQihoZNJNMiltCjAMTL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv", (CX::Int64)sbt_29dtO3lgaEf1bejSGl_Z3W55Wzv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE", sbt_7v1Yd1bXeaiBHeHqz2iVHd0OJ2qdAkqzOKw_ZrCh1S5tBG8PE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CxFXNgo21ATPtyIMqlouQ7bwB", (CX::Int64)sbt_CxFXNgo21ATPtyIMqlouQ7bwB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Jx60APhCuzjvUET4_8_", (CX::Int64)sbt_Jx60APhCuzjvUET4_8_)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_jgDm6sWUw>::Type sbt_jgDm6sWUwArray;

