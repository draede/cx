
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem;
	CX::Int8 sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB;
	CX::Int64 sbt_KHP5_s4wvAh;
	CX::IO::SimpleBuffers::Int16Array sbt_meaeUVEqgi4Af5K;
	CX::IO::SimpleBuffers::Int16Array sbt_PtRwxwfJO5i;
	CX::IO::SimpleBuffers::UInt8Array sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr;
	CX::IO::SimpleBuffers::UInt32Array sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ;
	CX::IO::SimpleBuffers::Int16Array sbt_Fp6UP6MJA;
	CX::IO::SimpleBuffers::Int32Array sbt_tNQ4yGYHnPCDQ;
	CX::IO::SimpleBuffers::BoolArray sbt_PGz1EvE7irPAK;
	CX::Int8 sbt_6d3kl9Sou2L19uHJ5hwcYPPxM;
	CX::Int32 sbt_rUedMBTDLRmQTj5toe0XWgmFt;
	CX::UInt64 sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can;
	CX::IO::SimpleBuffers::UInt32Array sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0;
	CX::UInt8 sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY;
	CX::IO::SimpleBuffers::UInt16Array sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS;
	CX::IO::SimpleBuffers::UInt32Array sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi;
	CX::UInt32 sbt_klx;
	CX::IO::SimpleBuffers::UInt16Array sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF;
	CX::IO::SimpleBuffers::Int32Array sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ;
	CX::UInt32 sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm;

	virtual void Reset()
	{
		sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.clear();
		sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB = 0;
		sbt_KHP5_s4wvAh = 0;
		sbt_meaeUVEqgi4Af5K.clear();
		sbt_PtRwxwfJO5i.clear();
		sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.clear();
		sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.clear();
		sbt_Fp6UP6MJA.clear();
		sbt_tNQ4yGYHnPCDQ.clear();
		sbt_PGz1EvE7irPAK.clear();
		sbt_6d3kl9Sou2L19uHJ5hwcYPPxM = 0;
		sbt_rUedMBTDLRmQTj5toe0XWgmFt = 0;
		sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can = 0;
		sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.clear();
		sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY = 0;
		sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.clear();
		sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.clear();
		sbt_klx = 0;
		sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.clear();
		sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.clear();
		sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.push_back(-44);
		}
		sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB = 64;
		sbt_KHP5_s4wvAh = 1562340832972862470;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_meaeUVEqgi4Af5K.push_back(-4344);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_PtRwxwfJO5i.push_back(24639);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.push_back(252);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.push_back(660417278);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_tNQ4yGYHnPCDQ.push_back(2093774581);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_PGz1EvE7irPAK.push_back(true);
		}
		sbt_6d3kl9Sou2L19uHJ5hwcYPPxM = 70;
		sbt_rUedMBTDLRmQTj5toe0XWgmFt = 1914702292;
		sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can = 5314135720133990146;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.push_back(1661352652);
		}
		sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY = 156;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.push_back(8953);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.push_back(1763122241);
		}
		sbt_klx = 343688324;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.push_back(32135);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.push_back(512351025);
		}
		sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm = 2806390569;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 *pObject = dynamic_cast<const sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.size() != pObject->sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.size(); i++)
		{
			if (sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem[i] != pObject->sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem[i])
			{
				return false;
			}
		}
		if (sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB != pObject->sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB)
		{
			return false;
		}
		if (sbt_KHP5_s4wvAh != pObject->sbt_KHP5_s4wvAh)
		{
			return false;
		}
		if (sbt_meaeUVEqgi4Af5K.size() != pObject->sbt_meaeUVEqgi4Af5K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_meaeUVEqgi4Af5K.size(); i++)
		{
			if (sbt_meaeUVEqgi4Af5K[i] != pObject->sbt_meaeUVEqgi4Af5K[i])
			{
				return false;
			}
		}
		if (sbt_PtRwxwfJO5i.size() != pObject->sbt_PtRwxwfJO5i.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PtRwxwfJO5i.size(); i++)
		{
			if (sbt_PtRwxwfJO5i[i] != pObject->sbt_PtRwxwfJO5i[i])
			{
				return false;
			}
		}
		if (sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.size() != pObject->sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.size(); i++)
		{
			if (sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr[i] != pObject->sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr[i])
			{
				return false;
			}
		}
		if (sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.size() != pObject->sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.size(); i++)
		{
			if (sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ[i] != pObject->sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ[i])
			{
				return false;
			}
		}
		if (sbt_Fp6UP6MJA.size() != pObject->sbt_Fp6UP6MJA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fp6UP6MJA.size(); i++)
		{
			if (sbt_Fp6UP6MJA[i] != pObject->sbt_Fp6UP6MJA[i])
			{
				return false;
			}
		}
		if (sbt_tNQ4yGYHnPCDQ.size() != pObject->sbt_tNQ4yGYHnPCDQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tNQ4yGYHnPCDQ.size(); i++)
		{
			if (sbt_tNQ4yGYHnPCDQ[i] != pObject->sbt_tNQ4yGYHnPCDQ[i])
			{
				return false;
			}
		}
		if (sbt_PGz1EvE7irPAK.size() != pObject->sbt_PGz1EvE7irPAK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PGz1EvE7irPAK.size(); i++)
		{
			if (sbt_PGz1EvE7irPAK[i] != pObject->sbt_PGz1EvE7irPAK[i])
			{
				return false;
			}
		}
		if (sbt_6d3kl9Sou2L19uHJ5hwcYPPxM != pObject->sbt_6d3kl9Sou2L19uHJ5hwcYPPxM)
		{
			return false;
		}
		if (sbt_rUedMBTDLRmQTj5toe0XWgmFt != pObject->sbt_rUedMBTDLRmQTj5toe0XWgmFt)
		{
			return false;
		}
		if (sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can != pObject->sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can)
		{
			return false;
		}
		if (sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.size() != pObject->sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.size(); i++)
		{
			if (sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0[i] != pObject->sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0[i])
			{
				return false;
			}
		}
		if (sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY != pObject->sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY)
		{
			return false;
		}
		if (sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.size() != pObject->sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.size(); i++)
		{
			if (sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS[i] != pObject->sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS[i])
			{
				return false;
			}
		}
		if (sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.size() != pObject->sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.size(); i++)
		{
			if (sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi[i] != pObject->sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi[i])
			{
				return false;
			}
		}
		if (sbt_klx != pObject->sbt_klx)
		{
			return false;
		}
		if (sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.size() != pObject->sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.size(); i++)
		{
			if (sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF[i] != pObject->sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF[i])
			{
				return false;
			}
		}
		if (sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.size() != pObject->sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.size(); i++)
		{
			if (sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ[i] != pObject->sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ[i])
			{
				return false;
			}
		}
		if (sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm != pObject->sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KHP5_s4wvAh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KHP5_s4wvAh = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_meaeUVEqgi4Af5K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_meaeUVEqgi4Af5K.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PtRwxwfJO5i")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PtRwxwfJO5i.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Fp6UP6MJA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Fp6UP6MJA.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tNQ4yGYHnPCDQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tNQ4yGYHnPCDQ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PGz1EvE7irPAK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PGz1EvE7irPAK.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6d3kl9Sou2L19uHJ5hwcYPPxM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6d3kl9Sou2L19uHJ5hwcYPPxM = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rUedMBTDLRmQTj5toe0XWgmFt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rUedMBTDLRmQTj5toe0XWgmFt = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_klx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_klx = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.begin(); iter != sbt_82btj991J31RJKpc9Zva2V4vkxd1pqEMG5jWdttG9MCvXfFiEem.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB", (CX::Int64)sbt_M3UKd1N0z9X8nCpr4nvKRzicCoynj8uhx97IB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KHP5_s4wvAh", (CX::Int64)sbt_KHP5_s4wvAh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_meaeUVEqgi4Af5K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_meaeUVEqgi4Af5K.begin(); iter != sbt_meaeUVEqgi4Af5K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PtRwxwfJO5i")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_PtRwxwfJO5i.begin(); iter != sbt_PtRwxwfJO5i.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.begin(); iter != sbt_1RhNbhuXo0EnD9zgMr6qBFXvWfsR5D2SO4tfH9gY1sr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.begin(); iter != sbt_AmhclaR6XML9LxxrOV3BusS3RL63CZoG0Hxduv7SZJJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fp6UP6MJA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Fp6UP6MJA.begin(); iter != sbt_Fp6UP6MJA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tNQ4yGYHnPCDQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_tNQ4yGYHnPCDQ.begin(); iter != sbt_tNQ4yGYHnPCDQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PGz1EvE7irPAK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_PGz1EvE7irPAK.begin(); iter != sbt_PGz1EvE7irPAK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6d3kl9Sou2L19uHJ5hwcYPPxM", (CX::Int64)sbt_6d3kl9Sou2L19uHJ5hwcYPPxM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rUedMBTDLRmQTj5toe0XWgmFt", (CX::Int64)sbt_rUedMBTDLRmQTj5toe0XWgmFt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can", (CX::Int64)sbt_phJqJFsLstUNfd2X7K4ZnSYAX3can)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.begin(); iter != sbt_Zr6aaCDE7rOz6k1NaeyPRBx1MY0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY", (CX::Int64)sbt_LzAxPmjlolpQCg_hD9XFuaAd2wqBUwFtEuxpcUYIwVY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.begin(); iter != sbt_e0QF2zOtJDTvvqs9xv80pZcOLNGcVi9_zvIp6No0BgjFKWAORou2VxS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.begin(); iter != sbt_2Hy5uwkG1NxH_7FYlUzMT4Qv_5txuLMed5rOzpi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_klx", (CX::Int64)sbt_klx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.begin(); iter != sbt_CxFSS9SiWpZngjSdP5XTrulvhxolLe7JFq3yPbg3yi1K9he5piF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.begin(); iter != sbt_DfEnCc6vEhqnzqlXf8qe0nrDDdZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm", (CX::Int64)sbt_pUYuq3zEHodRjrbM2FXsgQtJ6qWKGVZyhHJrsjkbkXLjzK8nm)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2>::Type sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2Array;

