
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_4cSI_FlZV.hpp"


class sbt_8_GxxvYia : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7;
	CX::IO::SimpleBuffers::Int32Array sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s;
	CX::Int8 sbt_Qdoek6WH9JW;
	CX::IO::SimpleBuffers::StringArray sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ;
	CX::IO::SimpleBuffers::Int32Array sbt_HXpYXJD3wutHUje78NjhlW7;
	CX::Int16 sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD;
	CX::IO::SimpleBuffers::DoubleArray sbt_sA_2JezB7mV8bSZKcWijNC4LhMF;
	CX::Int32 sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA;
	CX::UInt32 sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH;
	CX::Double sbt_2FQ3NCv2RkWhfSmBq;
	CX::UInt16 sbt_zLV08GbijMrIh2FnwsmcG_R14;
	CX::String sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_;
	CX::Int8 sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi;
	CX::IO::SimpleBuffers::DoubleArray sbt_Px_GzaPSHlMF6FPwrUE3QiH;
	CX::UInt8 sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm;
	CX::String sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ;
	CX::IO::SimpleBuffers::DoubleArray sbt_qaRC7;
	CX::WString sbt_P6Wf1d9IOR0xSPmmSVf8Y;
	CX::IO::SimpleBuffers::StringArray sbt_UF1rN446M5VGt5BjoKNal2zMN;
	CX::IO::SimpleBuffers::StringArray sbt_J;
	CX::UInt32 sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS;
	CX::IO::SimpleBuffers::DoubleArray sbt_2MEIQKMCd371S;
	CX::Int64 sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ;
	CX::IO::SimpleBuffers::Int64Array sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf;
	CX::IO::SimpleBuffers::UInt16Array sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84;
	sbt_4cSI_FlZV sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx;

	virtual void Reset()
	{
		sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.clear();
		sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.clear();
		sbt_Qdoek6WH9JW = 0;
		sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.clear();
		sbt_HXpYXJD3wutHUje78NjhlW7.clear();
		sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD = 0;
		sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.clear();
		sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA = 0;
		sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH = 0;
		sbt_2FQ3NCv2RkWhfSmBq = 0.0;
		sbt_zLV08GbijMrIh2FnwsmcG_R14 = 0;
		sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_.clear();
		sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi = 0;
		sbt_Px_GzaPSHlMF6FPwrUE3QiH.clear();
		sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm = 0;
		sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ.clear();
		sbt_qaRC7.clear();
		sbt_P6Wf1d9IOR0xSPmmSVf8Y.clear();
		sbt_UF1rN446M5VGt5BjoKNal2zMN.clear();
		sbt_J.clear();
		sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS = 0;
		sbt_2MEIQKMCd371S.clear();
		sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ = 0;
		sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.clear();
		sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.clear();
		sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.push_back(-932992740);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.push_back(455340091);
		}
		sbt_Qdoek6WH9JW = 85;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.push_back("Ch:s!yW+#M>t[\\77>t[s'BQlqs(i>b8gl1&*EVL-:\\P@k`");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_HXpYXJD3wutHUje78NjhlW7.push_back(284003038);
		}
		sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD = -22626;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.push_back(0.214886);
		}
		sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA = 377422513;
		sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH = 1850490044;
		sbt_2FQ3NCv2RkWhfSmBq = 0.698055;
		sbt_zLV08GbijMrIh2FnwsmcG_R14 = 40126;
		sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_ = "AjYpLz|_7oK>hx_$iHAy||R\\{pP?f1s(vgul.;]m#FV.9Nsps-Xfbs6q2{u";
		sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi = 126;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Px_GzaPSHlMF6FPwrUE3QiH.push_back(0.941803);
		}
		sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm = 173;
		sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ = "+nqKQIREH=Zd-SkRqCl;sOg,s";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_qaRC7.push_back(0.522200);
		}
		sbt_P6Wf1d9IOR0xSPmmSVf8Y = L"Q";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_UF1rN446M5VGt5BjoKNal2zMN.push_back("~krhoV<U/YKx\"]Xh,Va1*@&!NHi(K3k0+Mb`X0R?TQY");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_J.push_back("@GP^hqAk+5CxpQ7U=B<c[.avrMF7K]'9-M%!&");
		}
		sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS = 4074849659;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_2MEIQKMCd371S.push_back(0.736337);
		}
		sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ = -8879838602398794954;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.push_back(6193482199876585504);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.push_back(4967);
		}
		sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8_GxxvYia *pObject = dynamic_cast<const sbt_8_GxxvYia *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.size() != pObject->sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.size(); i++)
		{
			if (sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7[i] != pObject->sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7[i])
			{
				return false;
			}
		}
		if (sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.size() != pObject->sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.size(); i++)
		{
			if (sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s[i] != pObject->sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s[i])
			{
				return false;
			}
		}
		if (sbt_Qdoek6WH9JW != pObject->sbt_Qdoek6WH9JW)
		{
			return false;
		}
		if (sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.size() != pObject->sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ[i].c_str(), pObject->sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_HXpYXJD3wutHUje78NjhlW7.size() != pObject->sbt_HXpYXJD3wutHUje78NjhlW7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HXpYXJD3wutHUje78NjhlW7.size(); i++)
		{
			if (sbt_HXpYXJD3wutHUje78NjhlW7[i] != pObject->sbt_HXpYXJD3wutHUje78NjhlW7[i])
			{
				return false;
			}
		}
		if (sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD != pObject->sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD)
		{
			return false;
		}
		if (sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.size() != pObject->sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.size(); i++)
		{
			if (sbt_sA_2JezB7mV8bSZKcWijNC4LhMF[i] != pObject->sbt_sA_2JezB7mV8bSZKcWijNC4LhMF[i])
			{
				return false;
			}
		}
		if (sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA != pObject->sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA)
		{
			return false;
		}
		if (sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH != pObject->sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH)
		{
			return false;
		}
		if (sbt_2FQ3NCv2RkWhfSmBq != pObject->sbt_2FQ3NCv2RkWhfSmBq)
		{
			return false;
		}
		if (sbt_zLV08GbijMrIh2FnwsmcG_R14 != pObject->sbt_zLV08GbijMrIh2FnwsmcG_R14)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_.c_str(), pObject->sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_.c_str()))
		{
			return false;
		}
		if (sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi != pObject->sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi)
		{
			return false;
		}
		if (sbt_Px_GzaPSHlMF6FPwrUE3QiH.size() != pObject->sbt_Px_GzaPSHlMF6FPwrUE3QiH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Px_GzaPSHlMF6FPwrUE3QiH.size(); i++)
		{
			if (sbt_Px_GzaPSHlMF6FPwrUE3QiH[i] != pObject->sbt_Px_GzaPSHlMF6FPwrUE3QiH[i])
			{
				return false;
			}
		}
		if (sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm != pObject->sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ.c_str(), pObject->sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ.c_str()))
		{
			return false;
		}
		if (sbt_qaRC7.size() != pObject->sbt_qaRC7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qaRC7.size(); i++)
		{
			if (sbt_qaRC7[i] != pObject->sbt_qaRC7[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_P6Wf1d9IOR0xSPmmSVf8Y.c_str(), pObject->sbt_P6Wf1d9IOR0xSPmmSVf8Y.c_str()))
		{
			return false;
		}
		if (sbt_UF1rN446M5VGt5BjoKNal2zMN.size() != pObject->sbt_UF1rN446M5VGt5BjoKNal2zMN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UF1rN446M5VGt5BjoKNal2zMN.size(); i++)
		{
			if (0 != cx_strcmp(sbt_UF1rN446M5VGt5BjoKNal2zMN[i].c_str(), pObject->sbt_UF1rN446M5VGt5BjoKNal2zMN[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_J.size() != pObject->sbt_J.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J.size(); i++)
		{
			if (0 != cx_strcmp(sbt_J[i].c_str(), pObject->sbt_J[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS != pObject->sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS)
		{
			return false;
		}
		if (sbt_2MEIQKMCd371S.size() != pObject->sbt_2MEIQKMCd371S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2MEIQKMCd371S.size(); i++)
		{
			if (sbt_2MEIQKMCd371S[i] != pObject->sbt_2MEIQKMCd371S[i])
			{
				return false;
			}
		}
		if (sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ != pObject->sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ)
		{
			return false;
		}
		if (sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.size() != pObject->sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.size(); i++)
		{
			if (sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf[i] != pObject->sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf[i])
			{
				return false;
			}
		}
		if (sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.size() != pObject->sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.size(); i++)
		{
			if (sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84[i] != pObject->sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84[i])
			{
				return false;
			}
		}
		if (!sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx.Compare(&pObject->sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Qdoek6WH9JW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qdoek6WH9JW = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HXpYXJD3wutHUje78NjhlW7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HXpYXJD3wutHUje78NjhlW7.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sA_2JezB7mV8bSZKcWijNC4LhMF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_2FQ3NCv2RkWhfSmBq", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_2FQ3NCv2RkWhfSmBq = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_zLV08GbijMrIh2FnwsmcG_R14", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zLV08GbijMrIh2FnwsmcG_R14 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_", &sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Px_GzaPSHlMF6FPwrUE3QiH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Px_GzaPSHlMF6FPwrUE3QiH.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectString("sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ", &sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qaRC7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qaRC7.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_P6Wf1d9IOR0xSPmmSVf8Y", &sbt_P6Wf1d9IOR0xSPmmSVf8Y)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UF1rN446M5VGt5BjoKNal2zMN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UF1rN446M5VGt5BjoKNal2zMN.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_J")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2MEIQKMCd371S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2MEIQKMCd371S.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.begin(); iter != sbt_bMTqUqHxCpf4O30CbPLkIx2K9ybxNVmYoKxVY_qapK1mUq13GI7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.begin(); iter != sbt_YfNf7RIzuyKYw5_hmsrhkZK0s_xpr5nTgzKlxgjPUuaYjS5AIMA3LVxOZzNVI8s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Qdoek6WH9JW", (CX::Int64)sbt_Qdoek6WH9JW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.begin(); iter != sbt_gYNIGLBLuNipZCQL4I1fPHWSMErcmSM6xGJXGZLUGrt5yfZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HXpYXJD3wutHUje78NjhlW7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_HXpYXJD3wutHUje78NjhlW7.begin(); iter != sbt_HXpYXJD3wutHUje78NjhlW7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD", (CX::Int64)sbt_G_MUwAM_XX2DSl4NCfvPl4O4Liz1r40IxCJL7x6o0oHQbRAoo3csdD4MD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sA_2JezB7mV8bSZKcWijNC4LhMF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.begin(); iter != sbt_sA_2JezB7mV8bSZKcWijNC4LhMF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA", (CX::Int64)sbt_6gLwWlWzDzwSdIrTFGTYIvKuT6SHNbJHS9aAaXSKp3OoxWtLuJjD8sC_PRniA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH", (CX::Int64)sbt_UfgXoQnwz9mLA4oV4RTbSFPodMpLKqyO5s3OVZIPB1lOjfVp6omPBvH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_2FQ3NCv2RkWhfSmBq", (CX::Double)sbt_2FQ3NCv2RkWhfSmBq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zLV08GbijMrIh2FnwsmcG_R14", (CX::Int64)sbt_zLV08GbijMrIh2FnwsmcG_R14)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_", sbt_g4ET1rtXHl0si4mvHq3TMyZ5qsj7gdaBLQ_0EMoO_.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi", (CX::Int64)sbt_11ph1yUoCBVInyu7M8sENoCmK6u3Z65s7eC7xYfDCSeRoMQwP_rQ4Yi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Px_GzaPSHlMF6FPwrUE3QiH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Px_GzaPSHlMF6FPwrUE3QiH.begin(); iter != sbt_Px_GzaPSHlMF6FPwrUE3QiH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm", (CX::Int64)sbt_y8TLPcIZ95EGlTOaNzQYcz9hS86V0oExBC_toBm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ", sbt_5woliNjqX8T7NJ7Uw2JmHQdzzqZUjqE3jRQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qaRC7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_qaRC7.begin(); iter != sbt_qaRC7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_P6Wf1d9IOR0xSPmmSVf8Y", sbt_P6Wf1d9IOR0xSPmmSVf8Y.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UF1rN446M5VGt5BjoKNal2zMN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_UF1rN446M5VGt5BjoKNal2zMN.begin(); iter != sbt_UF1rN446M5VGt5BjoKNal2zMN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_J.begin(); iter != sbt_J.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS", (CX::Int64)sbt_qvA4DtcWMSR8UAHKoSROw40pjOtgClI3AjC1YfJytnQZfVMK38HsS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2MEIQKMCd371S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_2MEIQKMCd371S.begin(); iter != sbt_2MEIQKMCd371S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ", (CX::Int64)sbt_yYVbAwPMwrG0aCMwAK1eGbTsOaEDGsC5c5SAQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.begin(); iter != sbt_Y6e_wLFxAaiFMFbAwnwLK_U1kS8Dyxnb2pNvDVH_kggz7qPgCJzKREzmItfbf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.begin(); iter != sbt_fNgaU1jVywhq9Sd9NVntrWWgKOM1YYGPYf4kGDZcv84.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_JXazAPEBMn2JPICILdqNXMn5uSmHoso7jlpkWQkZxETHibjTxcx.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8_GxxvYia>::Type sbt_8_GxxvYiaArray;

