
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_3UdYyNZlY8degDivo.hpp"


class sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_U269j;
	CX::IO::SimpleBuffers::WStringArray sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev;
	CX::IO::SimpleBuffers::UInt32Array sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo;
	CX::IO::SimpleBuffers::WStringArray sbt_ogiOaADHruR7ML_zo3oPBuyiAh_;
	CX::IO::SimpleBuffers::DoubleArray sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83;
	CX::UInt32 sbt_IMZ;
	CX::Double sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo;
	CX::UInt64 sbt_cBVEzFQWuB6FuUUE6Pc;
	CX::Int32 sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn;
	CX::IO::SimpleBuffers::StringArray sbt_SyS;
	CX::UInt32 sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8;
	CX::IO::SimpleBuffers::UInt8Array sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE;
	CX::IO::SimpleBuffers::StringArray sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd;
	CX::IO::SimpleBuffers::UInt16Array sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW;
	CX::IO::SimpleBuffers::UInt8Array sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231;
	CX::IO::SimpleBuffers::UInt32Array sbt_6ENUmYFSbtboecP;
	CX::IO::SimpleBuffers::UInt8Array sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE;
	CX::String sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA;
	CX::IO::SimpleBuffers::Int32Array sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge;
	sbt_3UdYyNZlY8degDivo sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm;

	virtual void Reset()
	{
		sbt_U269j.clear();
		sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.clear();
		sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.clear();
		sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.clear();
		sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.clear();
		sbt_IMZ = 0;
		sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo = 0.0;
		sbt_cBVEzFQWuB6FuUUE6Pc = 0;
		sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn = 0;
		sbt_SyS.clear();
		sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8 = 0;
		sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.clear();
		sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.clear();
		sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.clear();
		sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.clear();
		sbt_6ENUmYFSbtboecP.clear();
		sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.clear();
		sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA.clear();
		sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.clear();
		sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_U269j.push_back(0.969187f);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.push_back(L"");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.push_back(687300891);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.push_back(L"5.eP&@gjeu'x3;5E*%TtB\"Me{S\"P+GQW+!>\"!Y6`rZWa-hC-L.'cdKc=MBRcL");
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.push_back(0.136714);
		}
		sbt_IMZ = 2167307471;
		sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo = 0.013566;
		sbt_cBVEzFQWuB6FuUUE6Pc = 14599555555615255710;
		sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn = -1223377415;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_SyS.push_back("aZ*ng@F3ikIA6M+w_CW;oXsvG]$E'");
		}
		sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8 = 754423080;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.push_back(175);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.push_back(46441);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.push_back(236);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_6ENUmYFSbtboecP.push_back(4293053735);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.push_back(187);
		}
		sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA = "|#Ia9QNs#V/y|BbDL>W5mRV\"<yySVZgmJTm";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.push_back(-655129283);
		}
		sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi *pObject = dynamic_cast<const sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_U269j.size() != pObject->sbt_U269j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U269j.size(); i++)
		{
			if (sbt_U269j[i] != pObject->sbt_U269j[i])
			{
				return false;
			}
		}
		if (sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.size() != pObject->sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev[i].c_str(), pObject->sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.size() != pObject->sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.size(); i++)
		{
			if (sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo[i] != pObject->sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo[i])
			{
				return false;
			}
		}
		if (sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.size() != pObject->sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_ogiOaADHruR7ML_zo3oPBuyiAh_[i].c_str(), pObject->sbt_ogiOaADHruR7ML_zo3oPBuyiAh_[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.size() != pObject->sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.size(); i++)
		{
			if (sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83[i] != pObject->sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83[i])
			{
				return false;
			}
		}
		if (sbt_IMZ != pObject->sbt_IMZ)
		{
			return false;
		}
		if (sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo != pObject->sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo)
		{
			return false;
		}
		if (sbt_cBVEzFQWuB6FuUUE6Pc != pObject->sbt_cBVEzFQWuB6FuUUE6Pc)
		{
			return false;
		}
		if (sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn != pObject->sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn)
		{
			return false;
		}
		if (sbt_SyS.size() != pObject->sbt_SyS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SyS.size(); i++)
		{
			if (0 != cx_strcmp(sbt_SyS[i].c_str(), pObject->sbt_SyS[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8 != pObject->sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8)
		{
			return false;
		}
		if (sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.size() != pObject->sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.size(); i++)
		{
			if (sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE[i] != pObject->sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE[i])
			{
				return false;
			}
		}
		if (sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.size() != pObject->sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd[i].c_str(), pObject->sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.size() != pObject->sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.size(); i++)
		{
			if (sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW[i] != pObject->sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW[i])
			{
				return false;
			}
		}
		if (sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.size() != pObject->sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.size(); i++)
		{
			if (sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231[i] != pObject->sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231[i])
			{
				return false;
			}
		}
		if (sbt_6ENUmYFSbtboecP.size() != pObject->sbt_6ENUmYFSbtboecP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6ENUmYFSbtboecP.size(); i++)
		{
			if (sbt_6ENUmYFSbtboecP[i] != pObject->sbt_6ENUmYFSbtboecP[i])
			{
				return false;
			}
		}
		if (sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.size() != pObject->sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.size(); i++)
		{
			if (sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE[i] != pObject->sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA.c_str(), pObject->sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA.c_str()))
		{
			return false;
		}
		if (sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.size() != pObject->sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.size(); i++)
		{
			if (sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge[i] != pObject->sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge[i])
			{
				return false;
			}
		}
		if (!sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm.Compare(&pObject->sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_U269j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U269j.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ogiOaADHruR7ML_zo3oPBuyiAh_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IMZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IMZ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_cBVEzFQWuB6FuUUE6Pc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cBVEzFQWuB6FuUUE6Pc = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SyS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SyS.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6ENUmYFSbtboecP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6ENUmYFSbtboecP.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA", &sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_U269j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_U269j.begin(); iter != sbt_U269j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.begin(); iter != sbt_ZOADwQBt84tj6iMbokPyI0_VF_9dEZvW1DdqoDAqqz0YZRvGQNGc1p2Wgev.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.begin(); iter != sbt_lak2i4pZJIzV17TjX50QSPqET4lXJGcCEGpFo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ogiOaADHruR7ML_zo3oPBuyiAh_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.begin(); iter != sbt_ogiOaADHruR7ML_zo3oPBuyiAh_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.begin(); iter != sbt_8Y8uxuu9OVhGw4qZEy3v6mPLWQP83.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IMZ", (CX::Int64)sbt_IMZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo", (CX::Double)sbt_LfElkGbd67aaNVmSplWseythpBTWuqFfkD3gslh3GI_YhSdkVGo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cBVEzFQWuB6FuUUE6Pc", (CX::Int64)sbt_cBVEzFQWuB6FuUUE6Pc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn", (CX::Int64)sbt_VeWcUsnAiypEEwCaIwGlMNyaR5QS52JiTiwEgoOv3DeERQCCzk9Ptv5JNmn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SyS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_SyS.begin(); iter != sbt_SyS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8", (CX::Int64)sbt_BCJKGOInJSOaVZg47RWYS0XWCBygdcNleMR7a6ury3etWpra8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.begin(); iter != sbt_BhhvKaGtIYxBcBILpojndeZjf0sFBiHCBGflLxmatEU40Aj2jtOvE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.begin(); iter != sbt_ykSIRaZDR2CZNAVGlvLKawifq6GG_5rxe2JaTx5qFkhCd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.begin(); iter != sbt_EPEq1KL8xZKwz82klYGNsxypYrVoW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.begin(); iter != sbt_WlTFQu3SMqilYrIr98WiVS2qm73kuR81NRcwWsUHtz231.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6ENUmYFSbtboecP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_6ENUmYFSbtboecP.begin(); iter != sbt_6ENUmYFSbtboecP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.begin(); iter != sbt_YX9dXNpoLn8vaqSFInZ_QxBE36LXELXhFtVwo9C2nRmRE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA", sbt_eHqggW00maLNKVQc2PJmbafiCaZUFHqQAiGyaUfZ9SsbA.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.begin(); iter != sbt_GzsXuZAuajTZhIdW89_jTrkBRP4xXY7yVoYmSnKz_URJtfaK23eDKge.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_srymre6Pzgc0eLczkaV6QLt5G0DbJK_4J7y6M0zHH1Rk7lpsMZTRzNTyfFzsm.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi>::Type sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKiArray;

