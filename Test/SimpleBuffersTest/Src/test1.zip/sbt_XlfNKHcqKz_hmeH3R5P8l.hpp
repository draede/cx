
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_DYiGJ.hpp"


class sbt_XlfNKHcqKz_hmeH3R5P8l : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R;
	CX::Float sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf;
	CX::IO::SimpleBuffers::StringArray sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf;
	CX::WString sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT;
	CX::IO::SimpleBuffers::FloatArray sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl;
	sbt_DYiGJArray sbt_awZuDqPWi4UwhrNe0;

	virtual void Reset()
	{
		sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.clear();
		sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf = 0.0f;
		sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.clear();
		sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT.clear();
		sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.clear();
		sbt_awZuDqPWi4UwhrNe0.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.push_back(157);
		}
		sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf = 0.850961f;
		sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT = L"Woz#~X'r/U}$IK>HjJ8=o(sCC9NmMU.3RNk";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.push_back(0.341041f);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_DYiGJ v;

			v.SetupWithSomeValues();
			sbt_awZuDqPWi4UwhrNe0.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_XlfNKHcqKz_hmeH3R5P8l *pObject = dynamic_cast<const sbt_XlfNKHcqKz_hmeH3R5P8l *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.size() != pObject->sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.size(); i++)
		{
			if (sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R[i] != pObject->sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R[i])
			{
				return false;
			}
		}
		if (sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf != pObject->sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf)
		{
			return false;
		}
		if (sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.size() != pObject->sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.size(); i++)
		{
			if (0 != cx_strcmp(sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf[i].c_str(), pObject->sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT.c_str(), pObject->sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT.c_str()))
		{
			return false;
		}
		if (sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.size() != pObject->sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.size(); i++)
		{
			if (sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl[i] != pObject->sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl[i])
			{
				return false;
			}
		}
		if (sbt_awZuDqPWi4UwhrNe0.size() != pObject->sbt_awZuDqPWi4UwhrNe0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_awZuDqPWi4UwhrNe0.size(); i++)
		{
			if (!sbt_awZuDqPWi4UwhrNe0[i].Compare(&pObject->sbt_awZuDqPWi4UwhrNe0[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT", &sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_awZuDqPWi4UwhrNe0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_DYiGJ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_awZuDqPWi4UwhrNe0.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.begin(); iter != sbt_pN3gV6IpXEJdyMuExgjduxQ7K6R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf", (CX::Double)sbt__g_Zhb1JhvKi5n3fjrh4Y2Ho8JDHGkf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.begin(); iter != sbt_AHpUj6eY1ragZc1HF_F1igifz1J8k2zyFHaAQ7Zgf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT", sbt_2miZdQul5UtpBFBiPs0D6b7YKmSI_1QfCwDX8nT.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.begin(); iter != sbt_OD_ABIESbOkCIgHksUTv8LNwmol5kepMLgl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_awZuDqPWi4UwhrNe0")).IsNOK())
		{
			return status;
		}
		for (sbt_DYiGJArray::const_iterator iter = sbt_awZuDqPWi4UwhrNe0.begin(); iter != sbt_awZuDqPWi4UwhrNe0.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_XlfNKHcqKz_hmeH3R5P8l>::Type sbt_XlfNKHcqKz_hmeH3R5P8lArray;

