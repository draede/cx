
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_bJ6BPs7vVwBd7yjaT.hpp"


class sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_CMa05UV1ODndcRrNYcYm6SBwlga;
	CX::IO::SimpleBuffers::UInt8Array sbt_06BSkRdq3ES7fS6;
	CX::Double sbt_xm7vMgQZL_8KwwPTcq294spfhZ5;
	CX::Int32 sbt_k1j9XEj0IwmuA;
	CX::Int8 sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95;
	CX::IO::SimpleBuffers::UInt64Array sbt_1xs;
	CX::IO::SimpleBuffers::DoubleArray sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq;
	CX::Bool sbt_GXQ;
	CX::IO::SimpleBuffers::WStringArray sbt_76OVd;
	CX::Int8 sbt_U6LWrRglKI45rRy;
	CX::UInt16 sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL;
	CX::Int32 sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv;
	CX::Bool sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx;
	CX::IO::SimpleBuffers::UInt64Array sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu;
	CX::IO::SimpleBuffers::Int8Array sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF;
	CX::IO::SimpleBuffers::UInt32Array sbt_FSZstnvKKeqbFz2SZqmjxaVpy;
	CX::IO::SimpleBuffers::Int64Array sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd;
	CX::Float sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz;
	CX::UInt32 sbt_ZcRIVs33KHo5ercegFDwrvD;
	CX::IO::SimpleBuffers::StringArray sbt_kaAO0V2;
	CX::Int16 sbt_P;
	sbt_bJ6BPs7vVwBd7yjaTArray sbt_Fyvn3WaQBB6Gi;

	virtual void Reset()
	{
		sbt_CMa05UV1ODndcRrNYcYm6SBwlga = 0.0;
		sbt_06BSkRdq3ES7fS6.clear();
		sbt_xm7vMgQZL_8KwwPTcq294spfhZ5 = 0.0;
		sbt_k1j9XEj0IwmuA = 0;
		sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95 = 0;
		sbt_1xs.clear();
		sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.clear();
		sbt_GXQ = false;
		sbt_76OVd.clear();
		sbt_U6LWrRglKI45rRy = 0;
		sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL = 0;
		sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv = 0;
		sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx = false;
		sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.clear();
		sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.clear();
		sbt_FSZstnvKKeqbFz2SZqmjxaVpy.clear();
		sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.clear();
		sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz = 0.0f;
		sbt_ZcRIVs33KHo5ercegFDwrvD = 0;
		sbt_kaAO0V2.clear();
		sbt_P = 0;
		sbt_Fyvn3WaQBB6Gi.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_CMa05UV1ODndcRrNYcYm6SBwlga = 0.520959;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_06BSkRdq3ES7fS6.push_back(183);
		}
		sbt_xm7vMgQZL_8KwwPTcq294spfhZ5 = 0.697199;
		sbt_k1j9XEj0IwmuA = -1992598173;
		sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95 = -69;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_1xs.push_back(18075430544241903418);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.push_back(0.985908);
		}
		sbt_GXQ = true;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_76OVd.push_back(L"Hh>p[Zlq{^_\\p(JA!)\\En:rY?Hlf;");
		}
		sbt_U6LWrRglKI45rRy = -32;
		sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL = 17381;
		sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv = -2047457628;
		sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx = true;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.push_back(18346112598974235350);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.push_back(16);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_FSZstnvKKeqbFz2SZqmjxaVpy.push_back(803727106);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.push_back(8480537317624491490);
		}
		sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz = 0.400658f;
		sbt_ZcRIVs33KHo5ercegFDwrvD = 2874934211;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_kaAO0V2.push_back("5z'8}>0qD5n_LpWDF0a0YnZbY\"5_rTYu>jb0gn^e_e0lS$cIoxhYM");
		}
		sbt_P = 6261;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_bJ6BPs7vVwBd7yjaT v;

			v.SetupWithSomeValues();
			sbt_Fyvn3WaQBB6Gi.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ *pObject = dynamic_cast<const sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_CMa05UV1ODndcRrNYcYm6SBwlga != pObject->sbt_CMa05UV1ODndcRrNYcYm6SBwlga)
		{
			return false;
		}
		if (sbt_06BSkRdq3ES7fS6.size() != pObject->sbt_06BSkRdq3ES7fS6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_06BSkRdq3ES7fS6.size(); i++)
		{
			if (sbt_06BSkRdq3ES7fS6[i] != pObject->sbt_06BSkRdq3ES7fS6[i])
			{
				return false;
			}
		}
		if (sbt_xm7vMgQZL_8KwwPTcq294spfhZ5 != pObject->sbt_xm7vMgQZL_8KwwPTcq294spfhZ5)
		{
			return false;
		}
		if (sbt_k1j9XEj0IwmuA != pObject->sbt_k1j9XEj0IwmuA)
		{
			return false;
		}
		if (sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95 != pObject->sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95)
		{
			return false;
		}
		if (sbt_1xs.size() != pObject->sbt_1xs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1xs.size(); i++)
		{
			if (sbt_1xs[i] != pObject->sbt_1xs[i])
			{
				return false;
			}
		}
		if (sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.size() != pObject->sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.size(); i++)
		{
			if (sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq[i] != pObject->sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq[i])
			{
				return false;
			}
		}
		if (sbt_GXQ != pObject->sbt_GXQ)
		{
			return false;
		}
		if (sbt_76OVd.size() != pObject->sbt_76OVd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_76OVd.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_76OVd[i].c_str(), pObject->sbt_76OVd[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_U6LWrRglKI45rRy != pObject->sbt_U6LWrRglKI45rRy)
		{
			return false;
		}
		if (sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL != pObject->sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL)
		{
			return false;
		}
		if (sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv != pObject->sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv)
		{
			return false;
		}
		if (sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx != pObject->sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx)
		{
			return false;
		}
		if (sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.size() != pObject->sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.size(); i++)
		{
			if (sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu[i] != pObject->sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu[i])
			{
				return false;
			}
		}
		if (sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.size() != pObject->sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.size(); i++)
		{
			if (sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF[i] != pObject->sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF[i])
			{
				return false;
			}
		}
		if (sbt_FSZstnvKKeqbFz2SZqmjxaVpy.size() != pObject->sbt_FSZstnvKKeqbFz2SZqmjxaVpy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FSZstnvKKeqbFz2SZqmjxaVpy.size(); i++)
		{
			if (sbt_FSZstnvKKeqbFz2SZqmjxaVpy[i] != pObject->sbt_FSZstnvKKeqbFz2SZqmjxaVpy[i])
			{
				return false;
			}
		}
		if (sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.size() != pObject->sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.size(); i++)
		{
			if (sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd[i] != pObject->sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd[i])
			{
				return false;
			}
		}
		if (sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz != pObject->sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz)
		{
			return false;
		}
		if (sbt_ZcRIVs33KHo5ercegFDwrvD != pObject->sbt_ZcRIVs33KHo5ercegFDwrvD)
		{
			return false;
		}
		if (sbt_kaAO0V2.size() != pObject->sbt_kaAO0V2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kaAO0V2.size(); i++)
		{
			if (0 != cx_strcmp(sbt_kaAO0V2[i].c_str(), pObject->sbt_kaAO0V2[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_P != pObject->sbt_P)
		{
			return false;
		}
		if (sbt_Fyvn3WaQBB6Gi.size() != pObject->sbt_Fyvn3WaQBB6Gi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Fyvn3WaQBB6Gi.size(); i++)
		{
			if (!sbt_Fyvn3WaQBB6Gi[i].Compare(&pObject->sbt_Fyvn3WaQBB6Gi[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_CMa05UV1ODndcRrNYcYm6SBwlga", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_CMa05UV1ODndcRrNYcYm6SBwlga = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_06BSkRdq3ES7fS6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_06BSkRdq3ES7fS6.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_xm7vMgQZL_8KwwPTcq294spfhZ5", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_xm7vMgQZL_8KwwPTcq294spfhZ5 = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_k1j9XEj0IwmuA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k1j9XEj0IwmuA = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1xs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1xs.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_GXQ", &sbt_GXQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_76OVd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_76OVd.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_U6LWrRglKI45rRy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_U6LWrRglKI45rRy = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx", &sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FSZstnvKKeqbFz2SZqmjxaVpy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FSZstnvKKeqbFz2SZqmjxaVpy.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_ZcRIVs33KHo5ercegFDwrvD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZcRIVs33KHo5ercegFDwrvD = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_kaAO0V2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kaAO0V2.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Fyvn3WaQBB6Gi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_bJ6BPs7vVwBd7yjaT tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_Fyvn3WaQBB6Gi.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_CMa05UV1ODndcRrNYcYm6SBwlga", (CX::Double)sbt_CMa05UV1ODndcRrNYcYm6SBwlga)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_06BSkRdq3ES7fS6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_06BSkRdq3ES7fS6.begin(); iter != sbt_06BSkRdq3ES7fS6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_xm7vMgQZL_8KwwPTcq294spfhZ5", (CX::Double)sbt_xm7vMgQZL_8KwwPTcq294spfhZ5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k1j9XEj0IwmuA", (CX::Int64)sbt_k1j9XEj0IwmuA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95", (CX::Int64)sbt_R5Kvh1s8qIG10DwS2iNSulzRl6JOiY150OIjt95)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1xs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_1xs.begin(); iter != sbt_1xs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.begin(); iter != sbt_7a8_OeQ50adqZ_tK5OSH3Y_pVJLlS86yq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GXQ", sbt_GXQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_76OVd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_76OVd.begin(); iter != sbt_76OVd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_U6LWrRglKI45rRy", (CX::Int64)sbt_U6LWrRglKI45rRy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL", (CX::Int64)sbt_FPEM3ANoLVLLYZwT289Vn4DYxaUFI56iuT9H7f6x6KSJeNL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv", (CX::Int64)sbt_MygyWJpDQBpel4vrMZIlHOQngS9hCszu_q8uRL42NCG_Jya9LaLOv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx", sbt_w0BuqwfBorwjFFj8uTVdsHRmBIQyVyA6Y2oKG4HCopxy4FdZx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.begin(); iter != sbt_GLX2bWxtbofUBVfdd_SErScusfFyDYusu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.begin(); iter != sbt_dfXSUeYaSu4_HQwV5_NpuBdMHSF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FSZstnvKKeqbFz2SZqmjxaVpy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FSZstnvKKeqbFz2SZqmjxaVpy.begin(); iter != sbt_FSZstnvKKeqbFz2SZqmjxaVpy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.begin(); iter != sbt_r_9qLfJqqU3Ys6RQRt6aM5oTHDd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz", (CX::Double)sbt_zY2zolnSOrT5jeIXGxdjepsfa50P2YnsS75J7U3AKa2mCfSCYnhcz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZcRIVs33KHo5ercegFDwrvD", (CX::Int64)sbt_ZcRIVs33KHo5ercegFDwrvD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kaAO0V2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_kaAO0V2.begin(); iter != sbt_kaAO0V2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P", (CX::Int64)sbt_P)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Fyvn3WaQBB6Gi")).IsNOK())
		{
			return status;
		}
		for (sbt_bJ6BPs7vVwBd7yjaTArray::const_iterator iter = sbt_Fyvn3WaQBB6Gi.begin(); iter != sbt_Fyvn3WaQBB6Gi.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ>::Type sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJArray;

