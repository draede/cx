
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_5lCZz6s7wDo.hpp"


class sbt_aTB : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq;
	CX::IO::SimpleBuffers::UInt32Array sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q;
	CX::IO::SimpleBuffers::UInt8Array sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L;
	CX::IO::SimpleBuffers::DoubleArray sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh;
	CX::IO::SimpleBuffers::UInt8Array sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv;
	CX::IO::SimpleBuffers::UInt16Array sbt_NChR3mXtd;
	CX::IO::SimpleBuffers::UInt32Array sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p;
	CX::IO::SimpleBuffers::UInt8Array sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL;
	CX::IO::SimpleBuffers::FloatArray sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD;
	CX::UInt32 sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye;
	CX::IO::SimpleBuffers::FloatArray sbt_60XmVqZHT2x;
	CX::IO::SimpleBuffers::WStringArray sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC;
	CX::IO::SimpleBuffers::Int64Array sbt_plpP8aiKgsngyaVNh_aAWvh;
	sbt_5lCZz6s7wDo sbt_U9B;

	virtual void Reset()
	{
		sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.clear();
		sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.clear();
		sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.clear();
		sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.clear();
		sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.clear();
		sbt_NChR3mXtd.clear();
		sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.clear();
		sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.clear();
		sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.clear();
		sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye = 0;
		sbt_60XmVqZHT2x.clear();
		sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.clear();
		sbt_plpP8aiKgsngyaVNh_aAWvh.clear();
		sbt_U9B.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.push_back(0.439367);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.push_back(118);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.push_back(727165043);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.push_back(241);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.push_back(0.461507f);
		}
		sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye = 1374126879;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_60XmVqZHT2x.push_back(0.665496f);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.push_back(L"");
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_plpP8aiKgsngyaVNh_aAWvh.push_back(-5994828614517117004);
		}
		sbt_U9B.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_aTB *pObject = dynamic_cast<const sbt_aTB *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.size() != pObject->sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.size(); i++)
		{
			if (sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq[i] != pObject->sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq[i])
			{
				return false;
			}
		}
		if (sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.size() != pObject->sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.size(); i++)
		{
			if (sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q[i] != pObject->sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q[i])
			{
				return false;
			}
		}
		if (sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.size() != pObject->sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.size(); i++)
		{
			if (sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L[i] != pObject->sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L[i])
			{
				return false;
			}
		}
		if (sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.size() != pObject->sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.size(); i++)
		{
			if (sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh[i] != pObject->sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh[i])
			{
				return false;
			}
		}
		if (sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.size() != pObject->sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.size(); i++)
		{
			if (sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv[i] != pObject->sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv[i])
			{
				return false;
			}
		}
		if (sbt_NChR3mXtd.size() != pObject->sbt_NChR3mXtd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NChR3mXtd.size(); i++)
		{
			if (sbt_NChR3mXtd[i] != pObject->sbt_NChR3mXtd[i])
			{
				return false;
			}
		}
		if (sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.size() != pObject->sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.size(); i++)
		{
			if (sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p[i] != pObject->sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p[i])
			{
				return false;
			}
		}
		if (sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.size() != pObject->sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.size(); i++)
		{
			if (sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL[i] != pObject->sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL[i])
			{
				return false;
			}
		}
		if (sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.size() != pObject->sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.size(); i++)
		{
			if (sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD[i] != pObject->sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD[i])
			{
				return false;
			}
		}
		if (sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye != pObject->sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye)
		{
			return false;
		}
		if (sbt_60XmVqZHT2x.size() != pObject->sbt_60XmVqZHT2x.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_60XmVqZHT2x.size(); i++)
		{
			if (sbt_60XmVqZHT2x[i] != pObject->sbt_60XmVqZHT2x[i])
			{
				return false;
			}
		}
		if (sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.size() != pObject->sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC[i].c_str(), pObject->sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_plpP8aiKgsngyaVNh_aAWvh.size() != pObject->sbt_plpP8aiKgsngyaVNh_aAWvh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_plpP8aiKgsngyaVNh_aAWvh.size(); i++)
		{
			if (sbt_plpP8aiKgsngyaVNh_aAWvh[i] != pObject->sbt_plpP8aiKgsngyaVNh_aAWvh[i])
			{
				return false;
			}
		}
		if (!sbt_U9B.Compare(&pObject->sbt_U9B))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NChR3mXtd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NChR3mXtd.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_60XmVqZHT2x")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_60XmVqZHT2x.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_plpP8aiKgsngyaVNh_aAWvh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_plpP8aiKgsngyaVNh_aAWvh.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_U9B")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_U9B.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.begin(); iter != sbt_AnCgQrhKKRV63GA0njZqwGG7TF2bCCJuiBgG3wTzGEUEvMM1OnS0wMq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.begin(); iter != sbt_kbwoFql3drYJKBqI8CULdtw4YTF9SMK5mz86dHdHl6q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.begin(); iter != sbt_ISqPeGTpUs8aJvq95Q_Jnpn0L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.begin(); iter != sbt_f41D9H0m6E233DK0LgHgKND9OeX7Mwh__AixMbvQh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.begin(); iter != sbt_EMJqqj76QN_nmIXtjfr_WpB1qqXdLChjhTzNzFlT_L1veK0zkLv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NChR3mXtd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_NChR3mXtd.begin(); iter != sbt_NChR3mXtd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.begin(); iter != sbt_AX6atUezZ_lPk6P_kvBk4fagbEZmOvq_p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.begin(); iter != sbt_Y3rbQ1BRPMnREUcNxSWdbx_SOkMFBG8KIUKzt1BkcIj_6AL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.begin(); iter != sbt_prsL8m8j9gXSQst9DmTVSGU2VOdEzH_MX0aMZMD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye", (CX::Int64)sbt_aBmcMXWghW8V_I40ZSEYAzpHPyy0OyxsDf7Ye)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_60XmVqZHT2x")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_60XmVqZHT2x.begin(); iter != sbt_60XmVqZHT2x.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.begin(); iter != sbt_dC92g78K28dRaOw_EWi6admVPC2xfiPZHzFBIdC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_plpP8aiKgsngyaVNh_aAWvh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_plpP8aiKgsngyaVNh_aAWvh.begin(); iter != sbt_plpP8aiKgsngyaVNh_aAWvh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_U9B")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_U9B.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_aTB>::Type sbt_aTBArray;

