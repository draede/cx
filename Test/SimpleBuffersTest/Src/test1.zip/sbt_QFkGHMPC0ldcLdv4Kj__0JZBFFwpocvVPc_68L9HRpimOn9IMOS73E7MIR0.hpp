
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_bltZyIWaKHLtLThcOgbXS7A.hpp"


class sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk;
	CX::IO::SimpleBuffers::StringArray sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm;
	CX::Int16 sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j;
	CX::IO::SimpleBuffers::Int8Array sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP;
	CX::IO::SimpleBuffers::UInt16Array sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7;
	CX::Int64 sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS;
	CX::IO::SimpleBuffers::Int16Array sbt_Tfhap;
	CX::String sbt_V3l_Y2K3fNuOgdh;
	CX::Int8 sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0;
	CX::IO::SimpleBuffers::UInt32Array sbt_1DhYb;
	CX::Int64 sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE;
	CX::IO::SimpleBuffers::FloatArray sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj;
	CX::UInt64 sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF;
	CX::UInt32 sbt__DI7O0aKs7T;
	CX::Int8 sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc;
	CX::IO::SimpleBuffers::UInt16Array sbt_lgL0e5zfrWsnbnCKSYd_a;
	CX::Bool sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J;
	CX::UInt16 sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD;
	CX::String sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5;
	CX::UInt16 sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7;
	sbt_bltZyIWaKHLtLThcOgbXS7AArray sbt_dmSzehnco2B;

	virtual void Reset()
	{
		sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk = 0;
		sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.clear();
		sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j = 0;
		sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.clear();
		sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.clear();
		sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS = 0;
		sbt_Tfhap.clear();
		sbt_V3l_Y2K3fNuOgdh.clear();
		sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0 = 0;
		sbt_1DhYb.clear();
		sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE = 0;
		sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.clear();
		sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF = 0;
		sbt__DI7O0aKs7T = 0;
		sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc = 0;
		sbt_lgL0e5zfrWsnbnCKSYd_a.clear();
		sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J = false;
		sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD = 0;
		sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5.clear();
		sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7 = 0;
		sbt_dmSzehnco2B.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk = 7056820316106304612;
		sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j = 24278;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.push_back(-29);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.push_back(55784);
		}
		sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS = -4540656498356232654;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_Tfhap.push_back(-24037);
		}
		sbt_V3l_Y2K3fNuOgdh = "l%;#blIsajKAzj=C&JWi3=Lt2xjXx5K9$oc2qcK>7QNGTA~";
		sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0 = 127;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_1DhYb.push_back(860957901);
		}
		sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE = 4654371774966574106;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.push_back(0.431482f);
		}
		sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF = 6774290524076759332;
		sbt__DI7O0aKs7T = 717963357;
		sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc = 3;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_lgL0e5zfrWsnbnCKSYd_a.push_back(8989);
		}
		sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J = false;
		sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD = 64610;
		sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5 = "]/=ua/!X^n^sUw~E+:D)0VU=S{/e(.xhOxni]Ubbg\"<I~WL*bDR+p6G?#1OaHq3^";
		sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7 = 12116;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_bltZyIWaKHLtLThcOgbXS7A v;

			v.SetupWithSomeValues();
			sbt_dmSzehnco2B.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0 *pObject = dynamic_cast<const sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk != pObject->sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk)
		{
			return false;
		}
		if (sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.size() != pObject->sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.size(); i++)
		{
			if (0 != cx_strcmp(sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm[i].c_str(), pObject->sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j != pObject->sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j)
		{
			return false;
		}
		if (sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.size() != pObject->sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.size(); i++)
		{
			if (sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP[i] != pObject->sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP[i])
			{
				return false;
			}
		}
		if (sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.size() != pObject->sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.size(); i++)
		{
			if (sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7[i] != pObject->sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7[i])
			{
				return false;
			}
		}
		if (sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS != pObject->sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS)
		{
			return false;
		}
		if (sbt_Tfhap.size() != pObject->sbt_Tfhap.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Tfhap.size(); i++)
		{
			if (sbt_Tfhap[i] != pObject->sbt_Tfhap[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_V3l_Y2K3fNuOgdh.c_str(), pObject->sbt_V3l_Y2K3fNuOgdh.c_str()))
		{
			return false;
		}
		if (sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0 != pObject->sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0)
		{
			return false;
		}
		if (sbt_1DhYb.size() != pObject->sbt_1DhYb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1DhYb.size(); i++)
		{
			if (sbt_1DhYb[i] != pObject->sbt_1DhYb[i])
			{
				return false;
			}
		}
		if (sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE != pObject->sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE)
		{
			return false;
		}
		if (sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.size() != pObject->sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.size(); i++)
		{
			if (sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj[i] != pObject->sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj[i])
			{
				return false;
			}
		}
		if (sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF != pObject->sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF)
		{
			return false;
		}
		if (sbt__DI7O0aKs7T != pObject->sbt__DI7O0aKs7T)
		{
			return false;
		}
		if (sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc != pObject->sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc)
		{
			return false;
		}
		if (sbt_lgL0e5zfrWsnbnCKSYd_a.size() != pObject->sbt_lgL0e5zfrWsnbnCKSYd_a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lgL0e5zfrWsnbnCKSYd_a.size(); i++)
		{
			if (sbt_lgL0e5zfrWsnbnCKSYd_a[i] != pObject->sbt_lgL0e5zfrWsnbnCKSYd_a[i])
			{
				return false;
			}
		}
		if (sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J != pObject->sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J)
		{
			return false;
		}
		if (sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD != pObject->sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5.c_str(), pObject->sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5.c_str()))
		{
			return false;
		}
		if (sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7 != pObject->sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7)
		{
			return false;
		}
		if (sbt_dmSzehnco2B.size() != pObject->sbt_dmSzehnco2B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dmSzehnco2B.size(); i++)
		{
			if (!sbt_dmSzehnco2B[i].Compare(&pObject->sbt_dmSzehnco2B[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Tfhap")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Tfhap.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_V3l_Y2K3fNuOgdh", &sbt_V3l_Y2K3fNuOgdh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1DhYb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1DhYb.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt__DI7O0aKs7T", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__DI7O0aKs7T = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lgL0e5zfrWsnbnCKSYd_a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lgL0e5zfrWsnbnCKSYd_a.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J", &sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5", &sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dmSzehnco2B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_bltZyIWaKHLtLThcOgbXS7A tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_dmSzehnco2B.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk", (CX::Int64)sbt_KULiuSNGmJo9Bb9IMRwinaWkqwk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.begin(); iter != sbt_xPpDQCazuadOMk1sDZqR3AKCy3aKarqEY4TfaV2xm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j", (CX::Int64)sbt_N5y7N3jxYbJ7xKBP9cgCww3a7zFVFiWW4Vx6V8ZHTE33AXZgAY5d9zJmJ4mUC9j)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.begin(); iter != sbt_907Bb8IeNuYABMvFD6Mw6QeA7spO7pGT2xlPc5hnCFWK_Aznq5nS9IP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.begin(); iter != sbt_Ae_a5Pkv9SbJL0MjPf6gdshrrOZEEt9TMt8TJdWOXLBmgS7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS", (CX::Int64)sbt_PXJm45JVaCOI0i9B0furtYlbc0nJLSCi8FioqnS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Tfhap")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Tfhap.begin(); iter != sbt_Tfhap.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_V3l_Y2K3fNuOgdh", sbt_V3l_Y2K3fNuOgdh.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0", (CX::Int64)sbt_rH58CskgS_yQqGWixxEKeYBEoyGKCsJlmykM2ZJsAPFv9mkpjUGpoq0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1DhYb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1DhYb.begin(); iter != sbt_1DhYb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE", (CX::Int64)sbt_NI4m4ky_g2tRvdvJWPaIh_epCh9a3oP1pCGfkVE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.begin(); iter != sbt_0kSADNvvPjTRGR1z4JcGK94kYy74fnCS7osfcYTBaQubcqj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF", (CX::Int64)sbt_sYyrKvneofbjrqr7c1v03DPZdZLfeZfodMw6BOfnjQkMAqBA61jyerF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__DI7O0aKs7T", (CX::Int64)sbt__DI7O0aKs7T)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc", (CX::Int64)sbt_4IFBEebRxZQCvZKCe4unlRTTYlzNRUdrc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lgL0e5zfrWsnbnCKSYd_a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_lgL0e5zfrWsnbnCKSYd_a.begin(); iter != sbt_lgL0e5zfrWsnbnCKSYd_a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J", sbt_lL3AAFcOSlKC6ndGSGd3EB_81_avdlt5drxqLSgLq0J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD", (CX::Int64)sbt_jhJasSBXIRJ8e27mdMNUnEMlTIgfv1ywdvFpMeC5WT7J9wsEDtCWh9spOBD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5", sbt_lmGr8cxZ01ixN9ojhXcarRXxxJqTokprCZZ7RBW2mwERkmmFhIyWtN5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7", (CX::Int64)sbt_hcphFgkRpqsd5CH0WuYY1qcpvZPGvkSCGgjk7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dmSzehnco2B")).IsNOK())
		{
			return status;
		}
		for (sbt_bltZyIWaKHLtLThcOgbXS7AArray::const_iterator iter = sbt_dmSzehnco2B.begin(); iter != sbt_dmSzehnco2B.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0>::Type sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0Array;

