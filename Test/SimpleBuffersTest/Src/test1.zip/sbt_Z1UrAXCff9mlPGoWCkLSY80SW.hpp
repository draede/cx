
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X.hpp"


class sbt_Z1UrAXCff9mlPGoWCkLSY80SW : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::WStringArray sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu;
	CX::Double sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN;
	CX::IO::SimpleBuffers::UInt64Array sbt_vIEQvQy8MzNkbriNRRb;
	CX::Float sbt_aBFompDhtkYzEf5Nto2owc7ofoJ;
	CX::Int32 sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un;
	CX::UInt16 sbt_D3drS;
	CX::IO::SimpleBuffers::UInt8Array sbt_33wxu1lHv;
	CX::Int64 sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL;
	CX::String sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh;
	CX::UInt8 sbt_HsEKUAmw23lOsWV9mtM;
	CX::Float sbt_YuvRYPPgsZ3jewl;
	CX::IO::SimpleBuffers::StringArray sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV;
	CX::UInt32 sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh;
	sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096XArray sbt_waG3jt4rZSYJ2P1;

	virtual void Reset()
	{
		sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.clear();
		sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN = 0.0;
		sbt_vIEQvQy8MzNkbriNRRb.clear();
		sbt_aBFompDhtkYzEf5Nto2owc7ofoJ = 0.0f;
		sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un = 0;
		sbt_D3drS = 0;
		sbt_33wxu1lHv.clear();
		sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL = 0;
		sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh.clear();
		sbt_HsEKUAmw23lOsWV9mtM = 0;
		sbt_YuvRYPPgsZ3jewl = 0.0f;
		sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.clear();
		sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh = 0;
		sbt_waG3jt4rZSYJ2P1.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.push_back(L"f4e1kReg{8g(|dE71Yl1z#7;V]`fNAMT\\}RdEY/^cR^&QdES");
		}
		sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN = 0.189438;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_vIEQvQy8MzNkbriNRRb.push_back(11478762430376927264);
		}
		sbt_aBFompDhtkYzEf5Nto2owc7ofoJ = 0.734838f;
		sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un = -319820010;
		sbt_D3drS = 25015;
		sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL = -6846063036321782684;
		sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh = "?Y!=\"oL7RB'OLO<n4{:5'.tvz#J]d:9GQrm;k$;H>T~xn%\\cTY.";
		sbt_HsEKUAmw23lOsWV9mtM = 47;
		sbt_YuvRYPPgsZ3jewl = 0.607933f;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.push_back("uSOG8t2");
		}
		sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh = 4180278907;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Z1UrAXCff9mlPGoWCkLSY80SW *pObject = dynamic_cast<const sbt_Z1UrAXCff9mlPGoWCkLSY80SW *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.size() != pObject->sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu[i].c_str(), pObject->sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN != pObject->sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN)
		{
			return false;
		}
		if (sbt_vIEQvQy8MzNkbriNRRb.size() != pObject->sbt_vIEQvQy8MzNkbriNRRb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vIEQvQy8MzNkbriNRRb.size(); i++)
		{
			if (sbt_vIEQvQy8MzNkbriNRRb[i] != pObject->sbt_vIEQvQy8MzNkbriNRRb[i])
			{
				return false;
			}
		}
		if (sbt_aBFompDhtkYzEf5Nto2owc7ofoJ != pObject->sbt_aBFompDhtkYzEf5Nto2owc7ofoJ)
		{
			return false;
		}
		if (sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un != pObject->sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un)
		{
			return false;
		}
		if (sbt_D3drS != pObject->sbt_D3drS)
		{
			return false;
		}
		if (sbt_33wxu1lHv.size() != pObject->sbt_33wxu1lHv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_33wxu1lHv.size(); i++)
		{
			if (sbt_33wxu1lHv[i] != pObject->sbt_33wxu1lHv[i])
			{
				return false;
			}
		}
		if (sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL != pObject->sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh.c_str(), pObject->sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh.c_str()))
		{
			return false;
		}
		if (sbt_HsEKUAmw23lOsWV9mtM != pObject->sbt_HsEKUAmw23lOsWV9mtM)
		{
			return false;
		}
		if (sbt_YuvRYPPgsZ3jewl != pObject->sbt_YuvRYPPgsZ3jewl)
		{
			return false;
		}
		if (sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.size() != pObject->sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.size(); i++)
		{
			if (0 != cx_strcmp(sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV[i].c_str(), pObject->sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh != pObject->sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh)
		{
			return false;
		}
		if (sbt_waG3jt4rZSYJ2P1.size() != pObject->sbt_waG3jt4rZSYJ2P1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_waG3jt4rZSYJ2P1.size(); i++)
		{
			if (!sbt_waG3jt4rZSYJ2P1[i].Compare(&pObject->sbt_waG3jt4rZSYJ2P1[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_vIEQvQy8MzNkbriNRRb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vIEQvQy8MzNkbriNRRb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_aBFompDhtkYzEf5Nto2owc7ofoJ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_aBFompDhtkYzEf5Nto2owc7ofoJ = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_D3drS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_D3drS = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_33wxu1lHv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_33wxu1lHv.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh", &sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HsEKUAmw23lOsWV9mtM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HsEKUAmw23lOsWV9mtM = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_YuvRYPPgsZ3jewl", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_YuvRYPPgsZ3jewl = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_waG3jt4rZSYJ2P1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_waG3jt4rZSYJ2P1.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.begin(); iter != sbt_CdQeyWepHDA3cR2bVtuE1ppqD5nbPBAW1xu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN", (CX::Double)sbt_YdLJwEJm502YRhfq1KbQXcuantcDYuM_m0BrdKrXFOf5RmCFmoOHN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vIEQvQy8MzNkbriNRRb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vIEQvQy8MzNkbriNRRb.begin(); iter != sbt_vIEQvQy8MzNkbriNRRb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_aBFompDhtkYzEf5Nto2owc7ofoJ", (CX::Double)sbt_aBFompDhtkYzEf5Nto2owc7ofoJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un", (CX::Int64)sbt_03O3cBjLGFv3SYu_ijeJ3RxNDrykNr4wdbhcVYTJX4Ab2un)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_D3drS", (CX::Int64)sbt_D3drS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_33wxu1lHv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_33wxu1lHv.begin(); iter != sbt_33wxu1lHv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL", (CX::Int64)sbt_S_e8v8dDmIotFbvt7Yj_2cHX1DL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh", sbt_cxwd7uzO4HYKM2Hftw0T2YbukRh.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HsEKUAmw23lOsWV9mtM", (CX::Int64)sbt_HsEKUAmw23lOsWV9mtM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_YuvRYPPgsZ3jewl", (CX::Double)sbt_YuvRYPPgsZ3jewl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.begin(); iter != sbt_lFe93kEwgN5ZhwtKf8kXu4YE8ZHwsCtMV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh", (CX::Int64)sbt_3Hxj5oXbgcpaTDK9rRjH5DgYI3uVC1Z20QxaNYbTh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_waG3jt4rZSYJ2P1")).IsNOK())
		{
			return status;
		}
		for (sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096XArray::const_iterator iter = sbt_waG3jt4rZSYJ2P1.begin(); iter != sbt_waG3jt4rZSYJ2P1.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Z1UrAXCff9mlPGoWCkLSY80SW>::Type sbt_Z1UrAXCff9mlPGoWCkLSY80SWArray;

