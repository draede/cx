
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW.hpp"


class sbt_l : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV;
	CX::IO::SimpleBuffers::DoubleArray sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS;
	CX::WString sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX;
	CX::IO::SimpleBuffers::Int64Array sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh;
	CX::Int8 sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1;
	CX::Int32 sbt_o2adp;
	CX::Int64 sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0;
	CX::IO::SimpleBuffers::UInt64Array sbt_I1zuRPTDS5mE0YRzX;
	CX::IO::SimpleBuffers::UInt8Array sbt_f;
	CX::Int16 sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w;
	CX::Int8 sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R;
	CX::IO::SimpleBuffers::FloatArray sbt_NkIGp;
	CX::UInt32 sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb;
	CX::IO::SimpleBuffers::UInt64Array sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8;
	CX::IO::SimpleBuffers::FloatArray sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA;
	sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW sbt_JglKcfXSId7hEfvHSIA;

	virtual void Reset()
	{
		sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.clear();
		sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.clear();
		sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX.clear();
		sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.clear();
		sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1 = 0;
		sbt_o2adp = 0;
		sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0 = 0;
		sbt_I1zuRPTDS5mE0YRzX.clear();
		sbt_f.clear();
		sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w = 0;
		sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R = 0;
		sbt_NkIGp.clear();
		sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb = 0;
		sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.clear();
		sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.clear();
		sbt_JglKcfXSId7hEfvHSIA.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.push_back(15168407600430649374);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.push_back(0.109221);
		}
		sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX = L"f`,fu2EmVbHK[8c)d[OVUx7$zLU2$_DCKM5iC\"kEK}gD*goX=<w";
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.push_back(1982038929917251808);
		}
		sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1 = 123;
		sbt_o2adp = 957037754;
		sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0 = -5889928458234222220;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_I1zuRPTDS5mE0YRzX.push_back(13429250756357633084);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_f.push_back(33);
		}
		sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w = 18323;
		sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R = 62;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_NkIGp.push_back(0.222515f);
		}
		sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb = 785478997;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.push_back(847656683288932014);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.push_back(0.818474f);
		}
		sbt_JglKcfXSId7hEfvHSIA.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_l *pObject = dynamic_cast<const sbt_l *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.size() != pObject->sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.size(); i++)
		{
			if (sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV[i] != pObject->sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV[i])
			{
				return false;
			}
		}
		if (sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.size() != pObject->sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.size(); i++)
		{
			if (sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS[i] != pObject->sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX.c_str(), pObject->sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX.c_str()))
		{
			return false;
		}
		if (sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.size() != pObject->sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.size(); i++)
		{
			if (sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh[i] != pObject->sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh[i])
			{
				return false;
			}
		}
		if (sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1 != pObject->sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1)
		{
			return false;
		}
		if (sbt_o2adp != pObject->sbt_o2adp)
		{
			return false;
		}
		if (sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0 != pObject->sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0)
		{
			return false;
		}
		if (sbt_I1zuRPTDS5mE0YRzX.size() != pObject->sbt_I1zuRPTDS5mE0YRzX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I1zuRPTDS5mE0YRzX.size(); i++)
		{
			if (sbt_I1zuRPTDS5mE0YRzX[i] != pObject->sbt_I1zuRPTDS5mE0YRzX[i])
			{
				return false;
			}
		}
		if (sbt_f.size() != pObject->sbt_f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f.size(); i++)
		{
			if (sbt_f[i] != pObject->sbt_f[i])
			{
				return false;
			}
		}
		if (sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w != pObject->sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w)
		{
			return false;
		}
		if (sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R != pObject->sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R)
		{
			return false;
		}
		if (sbt_NkIGp.size() != pObject->sbt_NkIGp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NkIGp.size(); i++)
		{
			if (sbt_NkIGp[i] != pObject->sbt_NkIGp[i])
			{
				return false;
			}
		}
		if (sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb != pObject->sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb)
		{
			return false;
		}
		if (sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.size() != pObject->sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.size(); i++)
		{
			if (sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8[i] != pObject->sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8[i])
			{
				return false;
			}
		}
		if (sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.size() != pObject->sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.size(); i++)
		{
			if (sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA[i] != pObject->sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA[i])
			{
				return false;
			}
		}
		if (!sbt_JglKcfXSId7hEfvHSIA.Compare(&pObject->sbt_JglKcfXSId7hEfvHSIA))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX", &sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_o2adp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_o2adp = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_I1zuRPTDS5mE0YRzX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I1zuRPTDS5mE0YRzX.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NkIGp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NkIGp.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_JglKcfXSId7hEfvHSIA")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_JglKcfXSId7hEfvHSIA.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.begin(); iter != sbt_71qxr_IFTWwCItI7Kh82N1EvwYs4RcbgYI1WyJRBx5r5_XrsBS7hunDRV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.begin(); iter != sbt_PMR8yfuc3iLiygGuEWRIxLfz6_1_vb5OVGqjO9F3_GWQCfMNS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX", sbt_7eWpJmRhEbFyXGP6kCWrhmUZ1YIqNhEtx6uwY3H3kdAfo2Gmmy6e3wfOS4erX.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.begin(); iter != sbt_EeGTE7EB1nnmzCCi6JiLOZUFC7DwRZrBh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1", (CX::Int64)sbt_4JCR4lRiyGaPI6IWXU239Wdf5gkrpxjG0f1ydzU3JEsv7Z750b2hEKRofavq1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_o2adp", (CX::Int64)sbt_o2adp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0", (CX::Int64)sbt_KZ2nRJMYh6aYOP6CjS7Py9NVcO0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I1zuRPTDS5mE0YRzX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_I1zuRPTDS5mE0YRzX.begin(); iter != sbt_I1zuRPTDS5mE0YRzX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_f.begin(); iter != sbt_f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w", (CX::Int64)sbt_X6PJlIPy6ODVFfoI5n2_rwLUvZaNIFI6RFOgfim0w)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R", (CX::Int64)sbt_3DaA9d8ljbk9wfPd8Dm_x6ETT1ruwCkJ62_HBXKA3zwfO1u0R)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NkIGp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_NkIGp.begin(); iter != sbt_NkIGp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb", (CX::Int64)sbt_UQmMjmet9mTEPk49z06rhOPUDgorrOivRvgUEQMFoEln3E6pnDhwjQu5Chb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.begin(); iter != sbt_3pJxMVZeVtI19VYhw0_jN94QgrCHsVbKqRUqjiyB4AuogJAuBE9f8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.begin(); iter != sbt_MSmuBXmM_Pq_qmvnri51aUjkh0J2ruTLc7wW4uhonDhk9SpYRqHb0k9lEbA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_JglKcfXSId7hEfvHSIA")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_JglKcfXSId7hEfvHSIA.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_l>::Type sbt_lArray;

