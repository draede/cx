
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_akvrSL312EbFm9F_H : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL;
	CX::IO::SimpleBuffers::UInt16Array sbt_dz3xhA0;
	CX::Bool sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq;
	CX::IO::SimpleBuffers::UInt32Array sbt_JVaTaQp1ZJK32;
	CX::IO::SimpleBuffers::UInt64Array sbt_4Wx0rM78dDX;
	CX::Int64 sbt_sB3R7xhNdczgGzWvd35aRsM;
	CX::UInt64 sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH;
	CX::IO::SimpleBuffers::StringArray sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV;
	CX::Int64 sbt_bEjA60y;
	CX::UInt16 sbt_4YdMcCIIW9rY54d;
	CX::IO::SimpleBuffers::BoolArray sbt_rLknDu680bOuKDaiKpSyneo;
	CX::UInt32 sbt_NZZe0aZDjTkXMuD7D2c;
	CX::Bool sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc;
	CX::IO::SimpleBuffers::UInt32Array sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI;
	CX::IO::SimpleBuffers::UInt16Array sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a;
	CX::UInt8 sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU;
	CX::IO::SimpleBuffers::Int32Array sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ;
	CX::IO::SimpleBuffers::Int8Array sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M;
	CX::Int8 sbt_MUKaB;
	CX::IO::SimpleBuffers::StringArray sbt_fODk8vo212U;
	CX::UInt64 sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX;
	CX::UInt64 sbt_zKbA4k02_eSLSO7t7JP1yBT;
	CX::Int8 sbt_4HikkWObIvScUThnRZhg8JBSN_v;
	CX::IO::SimpleBuffers::UInt64Array sbt_R;
	CX::IO::SimpleBuffers::Int16Array sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2;
	CX::Int64 sbt_bI7LAkP3e3ILxhWkefv3Yu9;
	CX::IO::SimpleBuffers::UInt64Array sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H;
	CX::IO::SimpleBuffers::UInt64Array sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN;

	virtual void Reset()
	{
		sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL.clear();
		sbt_dz3xhA0.clear();
		sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq = false;
		sbt_JVaTaQp1ZJK32.clear();
		sbt_4Wx0rM78dDX.clear();
		sbt_sB3R7xhNdczgGzWvd35aRsM = 0;
		sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH = 0;
		sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.clear();
		sbt_bEjA60y = 0;
		sbt_4YdMcCIIW9rY54d = 0;
		sbt_rLknDu680bOuKDaiKpSyneo.clear();
		sbt_NZZe0aZDjTkXMuD7D2c = 0;
		sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc = false;
		sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.clear();
		sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.clear();
		sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU = 0;
		sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.clear();
		sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.clear();
		sbt_MUKaB = 0;
		sbt_fODk8vo212U.clear();
		sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX = 0;
		sbt_zKbA4k02_eSLSO7t7JP1yBT = 0;
		sbt_4HikkWObIvScUThnRZhg8JBSN_v = 0;
		sbt_R.clear();
		sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.clear();
		sbt_bI7LAkP3e3ILxhWkefv3Yu9 = 0;
		sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.clear();
		sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL = "aQ9~)tMNC/NmkR5[uyL'7~i~";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_dz3xhA0.push_back(930);
		}
		sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq = false;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JVaTaQp1ZJK32.push_back(2388393510);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_4Wx0rM78dDX.push_back(5561160160307644518);
		}
		sbt_sB3R7xhNdczgGzWvd35aRsM = -2650203301619212580;
		sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH = 12271072637764265948;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.push_back("wy?2|`E/fgvT\"6cUFJ*jWI(%T>2,FtJ&>cb9qr$6");
		}
		sbt_bEjA60y = -9128942017609458476;
		sbt_4YdMcCIIW9rY54d = 34377;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_rLknDu680bOuKDaiKpSyneo.push_back(false);
		}
		sbt_NZZe0aZDjTkXMuD7D2c = 3741402547;
		sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc = true;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.push_back(3453703837);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.push_back(44485);
		}
		sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU = 213;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.push_back(-2108581678);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.push_back(14);
		}
		sbt_MUKaB = 110;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_fODk8vo212U.push_back("]/@xV^p$\"iV9Z?dIearC$T~S\"9o0F[9\\6o%N+YMM0nrJ5N");
		}
		sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX = 1543961147582998308;
		sbt_zKbA4k02_eSLSO7t7JP1yBT = 13859375676183926408;
		sbt_4HikkWObIvScUThnRZhg8JBSN_v = 74;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_R.push_back(1935059148003831344);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.push_back(-14867);
		}
		sbt_bI7LAkP3e3ILxhWkefv3Yu9 = -8823988247408547794;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.push_back(14623708536354360576);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_akvrSL312EbFm9F_H *pObject = dynamic_cast<const sbt_akvrSL312EbFm9F_H *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL.c_str(), pObject->sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL.c_str()))
		{
			return false;
		}
		if (sbt_dz3xhA0.size() != pObject->sbt_dz3xhA0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dz3xhA0.size(); i++)
		{
			if (sbt_dz3xhA0[i] != pObject->sbt_dz3xhA0[i])
			{
				return false;
			}
		}
		if (sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq != pObject->sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq)
		{
			return false;
		}
		if (sbt_JVaTaQp1ZJK32.size() != pObject->sbt_JVaTaQp1ZJK32.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JVaTaQp1ZJK32.size(); i++)
		{
			if (sbt_JVaTaQp1ZJK32[i] != pObject->sbt_JVaTaQp1ZJK32[i])
			{
				return false;
			}
		}
		if (sbt_4Wx0rM78dDX.size() != pObject->sbt_4Wx0rM78dDX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4Wx0rM78dDX.size(); i++)
		{
			if (sbt_4Wx0rM78dDX[i] != pObject->sbt_4Wx0rM78dDX[i])
			{
				return false;
			}
		}
		if (sbt_sB3R7xhNdczgGzWvd35aRsM != pObject->sbt_sB3R7xhNdczgGzWvd35aRsM)
		{
			return false;
		}
		if (sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH != pObject->sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH)
		{
			return false;
		}
		if (sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.size() != pObject->sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.size(); i++)
		{
			if (0 != cx_strcmp(sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV[i].c_str(), pObject->sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_bEjA60y != pObject->sbt_bEjA60y)
		{
			return false;
		}
		if (sbt_4YdMcCIIW9rY54d != pObject->sbt_4YdMcCIIW9rY54d)
		{
			return false;
		}
		if (sbt_rLknDu680bOuKDaiKpSyneo.size() != pObject->sbt_rLknDu680bOuKDaiKpSyneo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rLknDu680bOuKDaiKpSyneo.size(); i++)
		{
			if (sbt_rLknDu680bOuKDaiKpSyneo[i] != pObject->sbt_rLknDu680bOuKDaiKpSyneo[i])
			{
				return false;
			}
		}
		if (sbt_NZZe0aZDjTkXMuD7D2c != pObject->sbt_NZZe0aZDjTkXMuD7D2c)
		{
			return false;
		}
		if (sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc != pObject->sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc)
		{
			return false;
		}
		if (sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.size() != pObject->sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.size(); i++)
		{
			if (sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI[i] != pObject->sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI[i])
			{
				return false;
			}
		}
		if (sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.size() != pObject->sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.size(); i++)
		{
			if (sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a[i] != pObject->sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a[i])
			{
				return false;
			}
		}
		if (sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU != pObject->sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU)
		{
			return false;
		}
		if (sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.size() != pObject->sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.size(); i++)
		{
			if (sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ[i] != pObject->sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ[i])
			{
				return false;
			}
		}
		if (sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.size() != pObject->sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.size(); i++)
		{
			if (sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M[i] != pObject->sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M[i])
			{
				return false;
			}
		}
		if (sbt_MUKaB != pObject->sbt_MUKaB)
		{
			return false;
		}
		if (sbt_fODk8vo212U.size() != pObject->sbt_fODk8vo212U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fODk8vo212U.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fODk8vo212U[i].c_str(), pObject->sbt_fODk8vo212U[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX != pObject->sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX)
		{
			return false;
		}
		if (sbt_zKbA4k02_eSLSO7t7JP1yBT != pObject->sbt_zKbA4k02_eSLSO7t7JP1yBT)
		{
			return false;
		}
		if (sbt_4HikkWObIvScUThnRZhg8JBSN_v != pObject->sbt_4HikkWObIvScUThnRZhg8JBSN_v)
		{
			return false;
		}
		if (sbt_R.size() != pObject->sbt_R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R.size(); i++)
		{
			if (sbt_R[i] != pObject->sbt_R[i])
			{
				return false;
			}
		}
		if (sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.size() != pObject->sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.size(); i++)
		{
			if (sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2[i] != pObject->sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2[i])
			{
				return false;
			}
		}
		if (sbt_bI7LAkP3e3ILxhWkefv3Yu9 != pObject->sbt_bI7LAkP3e3ILxhWkefv3Yu9)
		{
			return false;
		}
		if (sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.size() != pObject->sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.size(); i++)
		{
			if (sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H[i] != pObject->sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H[i])
			{
				return false;
			}
		}
		if (sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.size() != pObject->sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.size(); i++)
		{
			if (sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN[i] != pObject->sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL", &sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dz3xhA0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dz3xhA0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq", &sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JVaTaQp1ZJK32")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JVaTaQp1ZJK32.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4Wx0rM78dDX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4Wx0rM78dDX.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sB3R7xhNdczgGzWvd35aRsM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sB3R7xhNdczgGzWvd35aRsM = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bEjA60y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bEjA60y = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_4YdMcCIIW9rY54d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4YdMcCIIW9rY54d = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rLknDu680bOuKDaiKpSyneo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rLknDu680bOuKDaiKpSyneo.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NZZe0aZDjTkXMuD7D2c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NZZe0aZDjTkXMuD7D2c = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc", &sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MUKaB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MUKaB = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fODk8vo212U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fODk8vo212U.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zKbA4k02_eSLSO7t7JP1yBT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zKbA4k02_eSLSO7t7JP1yBT = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_4HikkWObIvScUThnRZhg8JBSN_v", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4HikkWObIvScUThnRZhg8JBSN_v = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bI7LAkP3e3ILxhWkefv3Yu9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bI7LAkP3e3ILxhWkefv3Yu9 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL", sbt_btOniJvdlmxQbcTyXvSWUg6aJg1UUJAldStDH7GrmHuo_Bdrb9zSYWE5DoL.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dz3xhA0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_dz3xhA0.begin(); iter != sbt_dz3xhA0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq", sbt_c4DKq0xv4asVQUiz1Z83JU9noKB4MhGairNkGacW4rCNXVq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JVaTaQp1ZJK32")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_JVaTaQp1ZJK32.begin(); iter != sbt_JVaTaQp1ZJK32.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4Wx0rM78dDX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_4Wx0rM78dDX.begin(); iter != sbt_4Wx0rM78dDX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sB3R7xhNdczgGzWvd35aRsM", (CX::Int64)sbt_sB3R7xhNdczgGzWvd35aRsM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH", (CX::Int64)sbt_96SaYjJP6to_vGNEO9U74EQJybSrWoegLfeI_OIdH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.begin(); iter != sbt_b7CBY67q7EBV5Kkkd_Gs_Mc3lEkv145vqF1UFmTYbZtIpxTq14n6pgYDV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bEjA60y", (CX::Int64)sbt_bEjA60y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4YdMcCIIW9rY54d", (CX::Int64)sbt_4YdMcCIIW9rY54d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rLknDu680bOuKDaiKpSyneo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_rLknDu680bOuKDaiKpSyneo.begin(); iter != sbt_rLknDu680bOuKDaiKpSyneo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NZZe0aZDjTkXMuD7D2c", (CX::Int64)sbt_NZZe0aZDjTkXMuD7D2c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc", sbt_uhzXzbBM49cajgkU5yY8zsQbjNmlE7TnQQCB8BwVDyjLojc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.begin(); iter != sbt_IyOBYHu98fFIG3JAb4n6k2tkQ3wTjUnb6kGOyhMhBiag1lbH6tDXFn0m5jGDI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.begin(); iter != sbt_QUkKJ9g02rneAz54bjmmyRPGBPno7H5HtAxTaUGsaZIpQS86a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU", (CX::Int64)sbt_pzV14jrnChxxjB7VQU6_FI5k9kahbbJebL6sITAMhx9EQ8XHhUU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.begin(); iter != sbt_W5G6yBCR5po42yhBvopmC9jdw0kOdZSQV2W3j7SwZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.begin(); iter != sbt_IVsTN07Z7yIpV_6jeficruttm5spi1f85hrqTSsRgO8LV561O2M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MUKaB", (CX::Int64)sbt_MUKaB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fODk8vo212U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fODk8vo212U.begin(); iter != sbt_fODk8vo212U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX", (CX::Int64)sbt_adPidg3cD81Xe392GFTnWqyNn6Y33OAR6dSFaFKCCLHI1XQN94BxjBX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zKbA4k02_eSLSO7t7JP1yBT", (CX::Int64)sbt_zKbA4k02_eSLSO7t7JP1yBT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4HikkWObIvScUThnRZhg8JBSN_v", (CX::Int64)sbt_4HikkWObIvScUThnRZhg8JBSN_v)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_R.begin(); iter != sbt_R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.begin(); iter != sbt_11j4Ez_MANCV0zdRw3_mOH_dFS2iCTngxJEYiKjwVv2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bI7LAkP3e3ILxhWkefv3Yu9", (CX::Int64)sbt_bI7LAkP3e3ILxhWkefv3Yu9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.begin(); iter != sbt_ePXJ2H5iNRWgH3t_g3bl4l03iUT0QExiKi8mhKYiZjl91m52DzpeRsaaW2H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.begin(); iter != sbt_oajFqtpC38I0K0i8KaU6Ldci1m1OmVAay_L6c9iBuKtgpnNgFHkcqfGZdUN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_akvrSL312EbFm9F_H>::Type sbt_akvrSL312EbFm9F_HArray;

