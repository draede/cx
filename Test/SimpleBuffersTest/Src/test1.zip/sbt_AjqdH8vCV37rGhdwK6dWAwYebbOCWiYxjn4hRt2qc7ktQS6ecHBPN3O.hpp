
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW.hpp"


class sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_wGtd6BTdA3c;
	CX::Int8 sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62;
	CX::String sbt_QDh;
	CX::Int16 sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ;
	CX::IO::SimpleBuffers::Int32Array sbt_DSPOGC9eVmD;
	CX::IO::SimpleBuffers::BoolArray sbt_wbPFEcN4J4T26SV2WNKpMpXhH;
	CX::IO::SimpleBuffers::BoolArray sbt_16zndUQz901zV45UJjM9A;
	CX::Int32 sbt_p_zUd37;
	CX::IO::SimpleBuffers::Int16Array sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6;
	CX::String sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK;
	CX::IO::SimpleBuffers::UInt32Array sbt_ZbcacXS;
	CX::IO::SimpleBuffers::BoolArray sbt_Cze9j;
	CX::UInt16 sbt_0lUk_R7JQcDUb;
	CX::IO::SimpleBuffers::Int32Array sbt_d8C6nhFF5wZJGc5FUGK2i;
	CX::IO::SimpleBuffers::FloatArray sbt_bHXC9;
	CX::IO::SimpleBuffers::UInt8Array sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS;
	CX::Int16 sbt_I9Up30aKsRH8EsFAU7Zvp;
	sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW sbt_TOjaB;

	virtual void Reset()
	{
		sbt_wGtd6BTdA3c = 0;
		sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62 = 0;
		sbt_QDh.clear();
		sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ = 0;
		sbt_DSPOGC9eVmD.clear();
		sbt_wbPFEcN4J4T26SV2WNKpMpXhH.clear();
		sbt_16zndUQz901zV45UJjM9A.clear();
		sbt_p_zUd37 = 0;
		sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.clear();
		sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK.clear();
		sbt_ZbcacXS.clear();
		sbt_Cze9j.clear();
		sbt_0lUk_R7JQcDUb = 0;
		sbt_d8C6nhFF5wZJGc5FUGK2i.clear();
		sbt_bHXC9.clear();
		sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.clear();
		sbt_I9Up30aKsRH8EsFAU7Zvp = 0;
		sbt_TOjaB.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_wGtd6BTdA3c = 45;
		sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62 = 117;
		sbt_QDh = "9[xe_.QzK0[`T#1J+TG(ooi>/q~$2|VT:,C%R[";
		sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ = -8957;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_DSPOGC9eVmD.push_back(1285252735);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_wbPFEcN4J4T26SV2WNKpMpXhH.push_back(true);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_16zndUQz901zV45UJjM9A.push_back(true);
		}
		sbt_p_zUd37 = -1106634501;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.push_back(-21316);
		}
		sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK = "[Z87UasTY+";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Cze9j.push_back(true);
		}
		sbt_0lUk_R7JQcDUb = 52792;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_d8C6nhFF5wZJGc5FUGK2i.push_back(1216022509);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_bHXC9.push_back(0.365091f);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.push_back(230);
		}
		sbt_I9Up30aKsRH8EsFAU7Zvp = 15277;
		sbt_TOjaB.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O *pObject = dynamic_cast<const sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_wGtd6BTdA3c != pObject->sbt_wGtd6BTdA3c)
		{
			return false;
		}
		if (sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62 != pObject->sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_QDh.c_str(), pObject->sbt_QDh.c_str()))
		{
			return false;
		}
		if (sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ != pObject->sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ)
		{
			return false;
		}
		if (sbt_DSPOGC9eVmD.size() != pObject->sbt_DSPOGC9eVmD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DSPOGC9eVmD.size(); i++)
		{
			if (sbt_DSPOGC9eVmD[i] != pObject->sbt_DSPOGC9eVmD[i])
			{
				return false;
			}
		}
		if (sbt_wbPFEcN4J4T26SV2WNKpMpXhH.size() != pObject->sbt_wbPFEcN4J4T26SV2WNKpMpXhH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wbPFEcN4J4T26SV2WNKpMpXhH.size(); i++)
		{
			if (sbt_wbPFEcN4J4T26SV2WNKpMpXhH[i] != pObject->sbt_wbPFEcN4J4T26SV2WNKpMpXhH[i])
			{
				return false;
			}
		}
		if (sbt_16zndUQz901zV45UJjM9A.size() != pObject->sbt_16zndUQz901zV45UJjM9A.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_16zndUQz901zV45UJjM9A.size(); i++)
		{
			if (sbt_16zndUQz901zV45UJjM9A[i] != pObject->sbt_16zndUQz901zV45UJjM9A[i])
			{
				return false;
			}
		}
		if (sbt_p_zUd37 != pObject->sbt_p_zUd37)
		{
			return false;
		}
		if (sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.size() != pObject->sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.size(); i++)
		{
			if (sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6[i] != pObject->sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK.c_str(), pObject->sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK.c_str()))
		{
			return false;
		}
		if (sbt_ZbcacXS.size() != pObject->sbt_ZbcacXS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZbcacXS.size(); i++)
		{
			if (sbt_ZbcacXS[i] != pObject->sbt_ZbcacXS[i])
			{
				return false;
			}
		}
		if (sbt_Cze9j.size() != pObject->sbt_Cze9j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Cze9j.size(); i++)
		{
			if (sbt_Cze9j[i] != pObject->sbt_Cze9j[i])
			{
				return false;
			}
		}
		if (sbt_0lUk_R7JQcDUb != pObject->sbt_0lUk_R7JQcDUb)
		{
			return false;
		}
		if (sbt_d8C6nhFF5wZJGc5FUGK2i.size() != pObject->sbt_d8C6nhFF5wZJGc5FUGK2i.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d8C6nhFF5wZJGc5FUGK2i.size(); i++)
		{
			if (sbt_d8C6nhFF5wZJGc5FUGK2i[i] != pObject->sbt_d8C6nhFF5wZJGc5FUGK2i[i])
			{
				return false;
			}
		}
		if (sbt_bHXC9.size() != pObject->sbt_bHXC9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bHXC9.size(); i++)
		{
			if (sbt_bHXC9[i] != pObject->sbt_bHXC9[i])
			{
				return false;
			}
		}
		if (sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.size() != pObject->sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.size(); i++)
		{
			if (sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS[i] != pObject->sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS[i])
			{
				return false;
			}
		}
		if (sbt_I9Up30aKsRH8EsFAU7Zvp != pObject->sbt_I9Up30aKsRH8EsFAU7Zvp)
		{
			return false;
		}
		if (!sbt_TOjaB.Compare(&pObject->sbt_TOjaB))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_wGtd6BTdA3c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wGtd6BTdA3c = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_QDh", &sbt_QDh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_DSPOGC9eVmD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DSPOGC9eVmD.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wbPFEcN4J4T26SV2WNKpMpXhH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wbPFEcN4J4T26SV2WNKpMpXhH.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_16zndUQz901zV45UJjM9A")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_16zndUQz901zV45UJjM9A.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_p_zUd37", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_p_zUd37 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK", &sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZbcacXS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZbcacXS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Cze9j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Cze9j.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0lUk_R7JQcDUb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0lUk_R7JQcDUb = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_d8C6nhFF5wZJGc5FUGK2i")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d8C6nhFF5wZJGc5FUGK2i.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bHXC9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bHXC9.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_I9Up30aKsRH8EsFAU7Zvp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_I9Up30aKsRH8EsFAU7Zvp = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_TOjaB")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TOjaB.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_wGtd6BTdA3c", (CX::Int64)sbt_wGtd6BTdA3c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62", (CX::Int64)sbt_tadogGBNDFUPISf3WM3zLh0c3WVi96GyKPto9dTNMAUVJs7ljfQ62)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_QDh", sbt_QDh.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ", (CX::Int64)sbt_iHukRXm2WXUfvmNecvBwsT8WpjzJNFMNUWzDMb4kIoCHr6lht15XUP3eJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DSPOGC9eVmD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_DSPOGC9eVmD.begin(); iter != sbt_DSPOGC9eVmD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wbPFEcN4J4T26SV2WNKpMpXhH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_wbPFEcN4J4T26SV2WNKpMpXhH.begin(); iter != sbt_wbPFEcN4J4T26SV2WNKpMpXhH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_16zndUQz901zV45UJjM9A")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_16zndUQz901zV45UJjM9A.begin(); iter != sbt_16zndUQz901zV45UJjM9A.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_p_zUd37", (CX::Int64)sbt_p_zUd37)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.begin(); iter != sbt_qSjv4JDP4LrAw4rVsQUBsXx1e5wZnqY611ruTwShg2btQNSdbHuXzulW6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK", sbt_vNliihB77x3WWIQn6k5wfdzDFcY3q3G8Dffq7gPtYqcX4ftPK.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZbcacXS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ZbcacXS.begin(); iter != sbt_ZbcacXS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Cze9j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Cze9j.begin(); iter != sbt_Cze9j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0lUk_R7JQcDUb", (CX::Int64)sbt_0lUk_R7JQcDUb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_d8C6nhFF5wZJGc5FUGK2i")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_d8C6nhFF5wZJGc5FUGK2i.begin(); iter != sbt_d8C6nhFF5wZJGc5FUGK2i.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bHXC9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_bHXC9.begin(); iter != sbt_bHXC9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.begin(); iter != sbt_MpxJ7gg0zOrWj9clJRyT7RpMhgwwV1O8knKpTjfYUjW55Y5sS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_I9Up30aKsRH8EsFAU7Zvp", (CX::Int64)sbt_I9Up30aKsRH8EsFAU7Zvp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_TOjaB")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_TOjaB.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O>::Type sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3OArray;

