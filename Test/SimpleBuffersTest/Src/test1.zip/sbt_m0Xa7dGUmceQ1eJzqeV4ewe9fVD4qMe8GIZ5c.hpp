
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_DtSVJ8rvB4wKgq05Jvx;
	CX::IO::SimpleBuffers::BoolArray sbt_B;
	CX::UInt32 sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC;
	CX::IO::SimpleBuffers::UInt64Array sbt_2sbs1IaLPYKUfKzqQgpbCna;
	CX::Int8 sbt_oeRUcXrYl0sSGIcAQ0s;
	CX::UInt8 sbt_uOL9eyAyBmj;
	CX::IO::SimpleBuffers::Int32Array sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8;
	CX::IO::SimpleBuffers::Int8Array sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_;
	CX::IO::SimpleBuffers::Int8Array sbt_N_f6Q2W;
	CX::Bool sbt_DCNcHgd3J8pjZ4kCc5ko7lL;
	CX::UInt64 sbt_aFO6yYmaXpS3X_Fv6;
	CX::IO::SimpleBuffers::UInt32Array sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK;
	CX::IO::SimpleBuffers::UInt32Array sbt_Y;
	CX::Int64 sbt_s4N4FuonpKq3HpNLr9m7F5IzM;
	CX::IO::SimpleBuffers::Int32Array sbt_zHyEJxf;
	CX::IO::SimpleBuffers::UInt64Array sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b;
	CX::UInt16 sbt_M;
	CX::IO::SimpleBuffers::UInt64Array sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG;
	CX::IO::SimpleBuffers::Int8Array sbt_IGlOq5EQKQIqRX8;
	CX::IO::SimpleBuffers::Int64Array sbt_IxL90z9;
	CX::IO::SimpleBuffers::UInt64Array sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg;

	virtual void Reset()
	{
		sbt_DtSVJ8rvB4wKgq05Jvx = 0;
		sbt_B.clear();
		sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC = 0;
		sbt_2sbs1IaLPYKUfKzqQgpbCna.clear();
		sbt_oeRUcXrYl0sSGIcAQ0s = 0;
		sbt_uOL9eyAyBmj = 0;
		sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.clear();
		sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.clear();
		sbt_N_f6Q2W.clear();
		sbt_DCNcHgd3J8pjZ4kCc5ko7lL = false;
		sbt_aFO6yYmaXpS3X_Fv6 = 0;
		sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.clear();
		sbt_Y.clear();
		sbt_s4N4FuonpKq3HpNLr9m7F5IzM = 0;
		sbt_zHyEJxf.clear();
		sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.clear();
		sbt_M = 0;
		sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.clear();
		sbt_IGlOq5EQKQIqRX8.clear();
		sbt_IxL90z9.clear();
		sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_DtSVJ8rvB4wKgq05Jvx = 53070;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_B.push_back(false);
		}
		sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC = 3583063276;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_2sbs1IaLPYKUfKzqQgpbCna.push_back(5572315550182860324);
		}
		sbt_oeRUcXrYl0sSGIcAQ0s = -75;
		sbt_uOL9eyAyBmj = 174;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.push_back(-816959767);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.push_back(52);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_N_f6Q2W.push_back(-105);
		}
		sbt_DCNcHgd3J8pjZ4kCc5ko7lL = true;
		sbt_aFO6yYmaXpS3X_Fv6 = 15224680645268784438;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.push_back(2691819676);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Y.push_back(4123471062);
		}
		sbt_s4N4FuonpKq3HpNLr9m7F5IzM = 2570054062684439066;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_zHyEJxf.push_back(1630383269);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.push_back(7868286629115948238);
		}
		sbt_M = 50901;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.push_back(9381649744787777708);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_IGlOq5EQKQIqRX8.push_back(-69);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_IxL90z9.push_back(-2287083085876770932);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.push_back(1430843902434246604);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c *pObject = dynamic_cast<const sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_DtSVJ8rvB4wKgq05Jvx != pObject->sbt_DtSVJ8rvB4wKgq05Jvx)
		{
			return false;
		}
		if (sbt_B.size() != pObject->sbt_B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B.size(); i++)
		{
			if (sbt_B[i] != pObject->sbt_B[i])
			{
				return false;
			}
		}
		if (sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC != pObject->sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC)
		{
			return false;
		}
		if (sbt_2sbs1IaLPYKUfKzqQgpbCna.size() != pObject->sbt_2sbs1IaLPYKUfKzqQgpbCna.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2sbs1IaLPYKUfKzqQgpbCna.size(); i++)
		{
			if (sbt_2sbs1IaLPYKUfKzqQgpbCna[i] != pObject->sbt_2sbs1IaLPYKUfKzqQgpbCna[i])
			{
				return false;
			}
		}
		if (sbt_oeRUcXrYl0sSGIcAQ0s != pObject->sbt_oeRUcXrYl0sSGIcAQ0s)
		{
			return false;
		}
		if (sbt_uOL9eyAyBmj != pObject->sbt_uOL9eyAyBmj)
		{
			return false;
		}
		if (sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.size() != pObject->sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.size(); i++)
		{
			if (sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8[i] != pObject->sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8[i])
			{
				return false;
			}
		}
		if (sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.size() != pObject->sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.size(); i++)
		{
			if (sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_[i] != pObject->sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_[i])
			{
				return false;
			}
		}
		if (sbt_N_f6Q2W.size() != pObject->sbt_N_f6Q2W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N_f6Q2W.size(); i++)
		{
			if (sbt_N_f6Q2W[i] != pObject->sbt_N_f6Q2W[i])
			{
				return false;
			}
		}
		if (sbt_DCNcHgd3J8pjZ4kCc5ko7lL != pObject->sbt_DCNcHgd3J8pjZ4kCc5ko7lL)
		{
			return false;
		}
		if (sbt_aFO6yYmaXpS3X_Fv6 != pObject->sbt_aFO6yYmaXpS3X_Fv6)
		{
			return false;
		}
		if (sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.size() != pObject->sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.size(); i++)
		{
			if (sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK[i] != pObject->sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK[i])
			{
				return false;
			}
		}
		if (sbt_Y.size() != pObject->sbt_Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y.size(); i++)
		{
			if (sbt_Y[i] != pObject->sbt_Y[i])
			{
				return false;
			}
		}
		if (sbt_s4N4FuonpKq3HpNLr9m7F5IzM != pObject->sbt_s4N4FuonpKq3HpNLr9m7F5IzM)
		{
			return false;
		}
		if (sbt_zHyEJxf.size() != pObject->sbt_zHyEJxf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zHyEJxf.size(); i++)
		{
			if (sbt_zHyEJxf[i] != pObject->sbt_zHyEJxf[i])
			{
				return false;
			}
		}
		if (sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.size() != pObject->sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.size(); i++)
		{
			if (sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b[i] != pObject->sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b[i])
			{
				return false;
			}
		}
		if (sbt_M != pObject->sbt_M)
		{
			return false;
		}
		if (sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.size() != pObject->sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.size(); i++)
		{
			if (sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG[i] != pObject->sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG[i])
			{
				return false;
			}
		}
		if (sbt_IGlOq5EQKQIqRX8.size() != pObject->sbt_IGlOq5EQKQIqRX8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IGlOq5EQKQIqRX8.size(); i++)
		{
			if (sbt_IGlOq5EQKQIqRX8[i] != pObject->sbt_IGlOq5EQKQIqRX8[i])
			{
				return false;
			}
		}
		if (sbt_IxL90z9.size() != pObject->sbt_IxL90z9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IxL90z9.size(); i++)
		{
			if (sbt_IxL90z9[i] != pObject->sbt_IxL90z9[i])
			{
				return false;
			}
		}
		if (sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.size() != pObject->sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.size(); i++)
		{
			if (sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg[i] != pObject->sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_DtSVJ8rvB4wKgq05Jvx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DtSVJ8rvB4wKgq05Jvx = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2sbs1IaLPYKUfKzqQgpbCna")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2sbs1IaLPYKUfKzqQgpbCna.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_oeRUcXrYl0sSGIcAQ0s", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oeRUcXrYl0sSGIcAQ0s = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_uOL9eyAyBmj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uOL9eyAyBmj = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_N_f6Q2W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N_f6Q2W.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_DCNcHgd3J8pjZ4kCc5ko7lL", &sbt_DCNcHgd3J8pjZ4kCc5ko7lL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aFO6yYmaXpS3X_Fv6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aFO6yYmaXpS3X_Fv6 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_s4N4FuonpKq3HpNLr9m7F5IzM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_s4N4FuonpKq3HpNLr9m7F5IzM = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zHyEJxf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zHyEJxf.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_M", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IGlOq5EQKQIqRX8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IGlOq5EQKQIqRX8.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IxL90z9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IxL90z9.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_DtSVJ8rvB4wKgq05Jvx", (CX::Int64)sbt_DtSVJ8rvB4wKgq05Jvx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_B.begin(); iter != sbt_B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC", (CX::Int64)sbt_dN8TfiPWmtmoKwF8WbHbqKUEYSOvMzxscfeeLLIQQsCOu7wnC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2sbs1IaLPYKUfKzqQgpbCna")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_2sbs1IaLPYKUfKzqQgpbCna.begin(); iter != sbt_2sbs1IaLPYKUfKzqQgpbCna.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oeRUcXrYl0sSGIcAQ0s", (CX::Int64)sbt_oeRUcXrYl0sSGIcAQ0s)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uOL9eyAyBmj", (CX::Int64)sbt_uOL9eyAyBmj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.begin(); iter != sbt_eroA4SMcK0FiBQbXOd1tS0YpMNKarAVZv9yChPgFTS5ps345UEK5Bh8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.begin(); iter != sbt_hMMuej3cpN1muoZeHWq4v6TGuA2V051U2Pg9_m5Cs4VL5i_CVggAwf_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N_f6Q2W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_N_f6Q2W.begin(); iter != sbt_N_f6Q2W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_DCNcHgd3J8pjZ4kCc5ko7lL", sbt_DCNcHgd3J8pjZ4kCc5ko7lL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aFO6yYmaXpS3X_Fv6", (CX::Int64)sbt_aFO6yYmaXpS3X_Fv6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.begin(); iter != sbt_1TmTTTtKHXehMXM9g7XaEWgDlMh2xv_ynNyYK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Y.begin(); iter != sbt_Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_s4N4FuonpKq3HpNLr9m7F5IzM", (CX::Int64)sbt_s4N4FuonpKq3HpNLr9m7F5IzM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zHyEJxf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_zHyEJxf.begin(); iter != sbt_zHyEJxf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.begin(); iter != sbt_S7H0vmMXTdDwO8SST3TP67IP7OLHZRpN7SjVd2z4b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_M", (CX::Int64)sbt_M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.begin(); iter != sbt_36pUr5QlSjm_VVyYQUFEoYLPKbhe9XIANEzppQIWvRqtWs79l5s0gtG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IGlOq5EQKQIqRX8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_IGlOq5EQKQIqRX8.begin(); iter != sbt_IGlOq5EQKQIqRX8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IxL90z9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_IxL90z9.begin(); iter != sbt_IxL90z9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.begin(); iter != sbt_VO0pRC27DEMSt7JZqAEa3Az5mLgri_ReIRmJ7HwEOlD7b_FPTb0SofWDOJymg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c>::Type sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5cArray;

