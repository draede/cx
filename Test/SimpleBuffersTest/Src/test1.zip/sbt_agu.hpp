
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_bltZyIWaKHLtLThcOgbXS7A.hpp"


class sbt_agu : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP;
	CX::IO::SimpleBuffers::BoolArray sbt_t9uoV0mKio_;
	CX::Int16 sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR;
	CX::IO::SimpleBuffers::BoolArray sbt_CmKBBRcYM1GqB;
	CX::UInt8 sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH;
	CX::IO::SimpleBuffers::DoubleArray sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x;
	CX::IO::SimpleBuffers::UInt8Array sbt_V9cWXKDzEPK8W_G8pwJWlBb;
	CX::Int16 sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw;
	CX::IO::SimpleBuffers::WStringArray sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO;
	CX::IO::SimpleBuffers::UInt8Array sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx;
	CX::IO::SimpleBuffers::BoolArray sbt_8vR1FIY;
	CX::IO::SimpleBuffers::BoolArray sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB;
	CX::IO::SimpleBuffers::WStringArray sbt_x6raQuV3KBQzu6Ccl;
	CX::IO::SimpleBuffers::UInt32Array sbt_0H01pRXMII7VN;
	CX::Int8 sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv;
	CX::UInt64 sbt_UHMi28jKe;
	CX::IO::SimpleBuffers::UInt64Array sbt_yD1v_2jtFZExIhTMUMaAnwEIr;
	CX::IO::SimpleBuffers::WStringArray sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy;
	CX::IO::SimpleBuffers::UInt16Array sbt_N;
	CX::IO::SimpleBuffers::UInt32Array sbt_pQ6;
	sbt_bltZyIWaKHLtLThcOgbXS7A sbt_iVAMmXMxtUoDrpM;

	virtual void Reset()
	{
		sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP = 0;
		sbt_t9uoV0mKio_.clear();
		sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR = 0;
		sbt_CmKBBRcYM1GqB.clear();
		sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH = 0;
		sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.clear();
		sbt_V9cWXKDzEPK8W_G8pwJWlBb.clear();
		sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw = 0;
		sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.clear();
		sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.clear();
		sbt_8vR1FIY.clear();
		sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.clear();
		sbt_x6raQuV3KBQzu6Ccl.clear();
		sbt_0H01pRXMII7VN.clear();
		sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv = 0;
		sbt_UHMi28jKe = 0;
		sbt_yD1v_2jtFZExIhTMUMaAnwEIr.clear();
		sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.clear();
		sbt_N.clear();
		sbt_pQ6.clear();
		sbt_iVAMmXMxtUoDrpM.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP = 5174835740619891450;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_t9uoV0mKio_.push_back(false);
		}
		sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR = 26314;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_CmKBBRcYM1GqB.push_back(false);
		}
		sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH = 19;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.push_back(0.283008);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_V9cWXKDzEPK8W_G8pwJWlBb.push_back(215);
		}
		sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw = -3941;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.push_back(L"Ov@?L]27j$K^nWyD1/OB(=sPKp?JEeKxn2lAh%E..MMZN;4+EIUt8C.#3A((CHun");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.push_back(40);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_8vR1FIY.push_back(true);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_x6raQuV3KBQzu6Ccl.push_back(L">5y\"`.?y37XVU~n");
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_0H01pRXMII7VN.push_back(224464228);
		}
		sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv = 83;
		sbt_UHMi28jKe = 10937648909575813128;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_yD1v_2jtFZExIhTMUMaAnwEIr.push_back(12751625570296869404);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.push_back(L"r");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_N.push_back(32763);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_pQ6.push_back(582222850);
		}
		sbt_iVAMmXMxtUoDrpM.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_agu *pObject = dynamic_cast<const sbt_agu *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP != pObject->sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP)
		{
			return false;
		}
		if (sbt_t9uoV0mKio_.size() != pObject->sbt_t9uoV0mKio_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t9uoV0mKio_.size(); i++)
		{
			if (sbt_t9uoV0mKio_[i] != pObject->sbt_t9uoV0mKio_[i])
			{
				return false;
			}
		}
		if (sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR != pObject->sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR)
		{
			return false;
		}
		if (sbt_CmKBBRcYM1GqB.size() != pObject->sbt_CmKBBRcYM1GqB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CmKBBRcYM1GqB.size(); i++)
		{
			if (sbt_CmKBBRcYM1GqB[i] != pObject->sbt_CmKBBRcYM1GqB[i])
			{
				return false;
			}
		}
		if (sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH != pObject->sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH)
		{
			return false;
		}
		if (sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.size() != pObject->sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.size(); i++)
		{
			if (sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x[i] != pObject->sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x[i])
			{
				return false;
			}
		}
		if (sbt_V9cWXKDzEPK8W_G8pwJWlBb.size() != pObject->sbt_V9cWXKDzEPK8W_G8pwJWlBb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_V9cWXKDzEPK8W_G8pwJWlBb.size(); i++)
		{
			if (sbt_V9cWXKDzEPK8W_G8pwJWlBb[i] != pObject->sbt_V9cWXKDzEPK8W_G8pwJWlBb[i])
			{
				return false;
			}
		}
		if (sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw != pObject->sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw)
		{
			return false;
		}
		if (sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.size() != pObject->sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO[i].c_str(), pObject->sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.size() != pObject->sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.size(); i++)
		{
			if (sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx[i] != pObject->sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx[i])
			{
				return false;
			}
		}
		if (sbt_8vR1FIY.size() != pObject->sbt_8vR1FIY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8vR1FIY.size(); i++)
		{
			if (sbt_8vR1FIY[i] != pObject->sbt_8vR1FIY[i])
			{
				return false;
			}
		}
		if (sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.size() != pObject->sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.size(); i++)
		{
			if (sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB[i] != pObject->sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB[i])
			{
				return false;
			}
		}
		if (sbt_x6raQuV3KBQzu6Ccl.size() != pObject->sbt_x6raQuV3KBQzu6Ccl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x6raQuV3KBQzu6Ccl.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_x6raQuV3KBQzu6Ccl[i].c_str(), pObject->sbt_x6raQuV3KBQzu6Ccl[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_0H01pRXMII7VN.size() != pObject->sbt_0H01pRXMII7VN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0H01pRXMII7VN.size(); i++)
		{
			if (sbt_0H01pRXMII7VN[i] != pObject->sbt_0H01pRXMII7VN[i])
			{
				return false;
			}
		}
		if (sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv != pObject->sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv)
		{
			return false;
		}
		if (sbt_UHMi28jKe != pObject->sbt_UHMi28jKe)
		{
			return false;
		}
		if (sbt_yD1v_2jtFZExIhTMUMaAnwEIr.size() != pObject->sbt_yD1v_2jtFZExIhTMUMaAnwEIr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yD1v_2jtFZExIhTMUMaAnwEIr.size(); i++)
		{
			if (sbt_yD1v_2jtFZExIhTMUMaAnwEIr[i] != pObject->sbt_yD1v_2jtFZExIhTMUMaAnwEIr[i])
			{
				return false;
			}
		}
		if (sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.size() != pObject->sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy[i].c_str(), pObject->sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_N.size() != pObject->sbt_N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N.size(); i++)
		{
			if (sbt_N[i] != pObject->sbt_N[i])
			{
				return false;
			}
		}
		if (sbt_pQ6.size() != pObject->sbt_pQ6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pQ6.size(); i++)
		{
			if (sbt_pQ6[i] != pObject->sbt_pQ6[i])
			{
				return false;
			}
		}
		if (!sbt_iVAMmXMxtUoDrpM.Compare(&pObject->sbt_iVAMmXMxtUoDrpM))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_t9uoV0mKio_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t9uoV0mKio_.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CmKBBRcYM1GqB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CmKBBRcYM1GqB.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_V9cWXKDzEPK8W_G8pwJWlBb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_V9cWXKDzEPK8W_G8pwJWlBb.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8vR1FIY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8vR1FIY.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_x6raQuV3KBQzu6Ccl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x6raQuV3KBQzu6Ccl.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0H01pRXMII7VN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0H01pRXMII7VN.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UHMi28jKe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UHMi28jKe = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yD1v_2jtFZExIhTMUMaAnwEIr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yD1v_2jtFZExIhTMUMaAnwEIr.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pQ6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pQ6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_iVAMmXMxtUoDrpM")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iVAMmXMxtUoDrpM.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP", (CX::Int64)sbt_SvT6g2zMTN08b2Fij3N0lLsQk4w3SJAW51DkvP9KcQzKB34HX9s0_IdRSAP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t9uoV0mKio_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_t9uoV0mKio_.begin(); iter != sbt_t9uoV0mKio_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR", (CX::Int64)sbt_5zpHPn9ejfEK29hW0848EF94wBM6810QhanERf7IyoqrP13Hly97PP660CR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CmKBBRcYM1GqB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_CmKBBRcYM1GqB.begin(); iter != sbt_CmKBBRcYM1GqB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH", (CX::Int64)sbt_2ttsbfxqBPyJIcPo54ViQrh3cWTPH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.begin(); iter != sbt_unYH7KGqx3eBiGbtxWIHrdZ9jWZdW1h2SQtGsoH6x.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_V9cWXKDzEPK8W_G8pwJWlBb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_V9cWXKDzEPK8W_G8pwJWlBb.begin(); iter != sbt_V9cWXKDzEPK8W_G8pwJWlBb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw", (CX::Int64)sbt_ZFewnhNLEHJPZ9wV82gTxt1uD5go3vLYKFUDppw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.begin(); iter != sbt_bkmKoYO_i9riPc5pL4xorzBtBKVd5cpU1NVlLiP7x_f6IOArDKFyT1XS3O7ZO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.begin(); iter != sbt_teWT8Y312E5vJgpmfzgFgy8Lb6AZbSudRAQEFTsJkLTXZaVzA0Y8MriGx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8vR1FIY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_8vR1FIY.begin(); iter != sbt_8vR1FIY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.begin(); iter != sbt_TGvDAEtvYWr1YPftF_LwZ6oi1IAdB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_x6raQuV3KBQzu6Ccl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_x6raQuV3KBQzu6Ccl.begin(); iter != sbt_x6raQuV3KBQzu6Ccl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0H01pRXMII7VN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0H01pRXMII7VN.begin(); iter != sbt_0H01pRXMII7VN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv", (CX::Int64)sbt_3hp63WL8rPsHSsub0Z3uskTDRbuP80U3rTpaBk_uUPQwo24j6lTcEFXoJmv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UHMi28jKe", (CX::Int64)sbt_UHMi28jKe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yD1v_2jtFZExIhTMUMaAnwEIr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yD1v_2jtFZExIhTMUMaAnwEIr.begin(); iter != sbt_yD1v_2jtFZExIhTMUMaAnwEIr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.begin(); iter != sbt_M6XMPpKeWOtEdaxIVf8QYcv6OatYt4eu732o1LeS9lAEqR9qrBQfy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_N.begin(); iter != sbt_N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pQ6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_pQ6.begin(); iter != sbt_pQ6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_iVAMmXMxtUoDrpM")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iVAMmXMxtUoDrpM.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_agu>::Type sbt_aguArray;

