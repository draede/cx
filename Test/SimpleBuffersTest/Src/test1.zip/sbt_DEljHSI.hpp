
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw.hpp"


class sbt_DEljHSI : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5;
	CX::UInt32 sbt_P9MdfEeNZqmSmcOow;
	CX::IO::SimpleBuffers::BoolArray sbt_KCJUVk6;
	CX::Bool sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz;
	CX::IO::SimpleBuffers::StringArray sbt_ddiXw6veOnE;
	CX::IO::SimpleBuffers::UInt32Array sbt_03bCXPnAkBjcn3vmCob5sevZibvXr;
	CX::IO::SimpleBuffers::UInt64Array sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu;
	CX::Float sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl;
	CX::IO::SimpleBuffers::UInt8Array sbt_pLXCN7HeEaG;
	CX::String sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3;
	CX::IO::SimpleBuffers::Int32Array sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4;
	CX::Bool sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL;
	CX::UInt16 sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG;
	CX::UInt64 sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF;
	CX::UInt64 sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs;
	CX::IO::SimpleBuffers::Int32Array sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1;
	CX::IO::SimpleBuffers::UInt8Array sbt_ut9DZDe;
	CX::Int32 sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9;
	CX::IO::SimpleBuffers::Int8Array sbt_TQUHA5NOu1ovLQCXEyhRm;
	CX::IO::SimpleBuffers::Int64Array sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV;
	CX::String sbt_dq0w4cOmhizBgj5O3fHwzKt;
	sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCwArray sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK;

	virtual void Reset()
	{
		sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.clear();
		sbt_P9MdfEeNZqmSmcOow = 0;
		sbt_KCJUVk6.clear();
		sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz = false;
		sbt_ddiXw6veOnE.clear();
		sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.clear();
		sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.clear();
		sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl = 0.0f;
		sbt_pLXCN7HeEaG.clear();
		sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3.clear();
		sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.clear();
		sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL = false;
		sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG = 0;
		sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF = 0;
		sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs = 0;
		sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.clear();
		sbt_ut9DZDe.clear();
		sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9 = 0;
		sbt_TQUHA5NOu1ovLQCXEyhRm.clear();
		sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.clear();
		sbt_dq0w4cOmhizBgj5O3fHwzKt.clear();
		sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.push_back(3109);
		}
		sbt_P9MdfEeNZqmSmcOow = 1742524013;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_KCJUVk6.push_back(false);
		}
		sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz = false;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_ddiXw6veOnE.push_back("W4#&+R`$kXvwu");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.push_back(7213978093894690642);
		}
		sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl = 0.256031f;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_pLXCN7HeEaG.push_back(153);
		}
		sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3 = "mngKA)";
		sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL = true;
		sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG = 43675;
		sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF = 1058286382918583556;
		sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs = 14904538843344665502;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.push_back(-479020187);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ut9DZDe.push_back(80);
		}
		sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9 = -837486387;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_TQUHA5NOu1ovLQCXEyhRm.push_back(24);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.push_back(8569492898922681636);
		}
		sbt_dq0w4cOmhizBgj5O3fHwzKt = "Qr";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw v;

			v.SetupWithSomeValues();
			sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_DEljHSI *pObject = dynamic_cast<const sbt_DEljHSI *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.size() != pObject->sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.size(); i++)
		{
			if (sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5[i] != pObject->sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5[i])
			{
				return false;
			}
		}
		if (sbt_P9MdfEeNZqmSmcOow != pObject->sbt_P9MdfEeNZqmSmcOow)
		{
			return false;
		}
		if (sbt_KCJUVk6.size() != pObject->sbt_KCJUVk6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KCJUVk6.size(); i++)
		{
			if (sbt_KCJUVk6[i] != pObject->sbt_KCJUVk6[i])
			{
				return false;
			}
		}
		if (sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz != pObject->sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz)
		{
			return false;
		}
		if (sbt_ddiXw6veOnE.size() != pObject->sbt_ddiXw6veOnE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ddiXw6veOnE.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ddiXw6veOnE[i].c_str(), pObject->sbt_ddiXw6veOnE[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.size() != pObject->sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.size(); i++)
		{
			if (sbt_03bCXPnAkBjcn3vmCob5sevZibvXr[i] != pObject->sbt_03bCXPnAkBjcn3vmCob5sevZibvXr[i])
			{
				return false;
			}
		}
		if (sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.size() != pObject->sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.size(); i++)
		{
			if (sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu[i] != pObject->sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu[i])
			{
				return false;
			}
		}
		if (sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl != pObject->sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl)
		{
			return false;
		}
		if (sbt_pLXCN7HeEaG.size() != pObject->sbt_pLXCN7HeEaG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pLXCN7HeEaG.size(); i++)
		{
			if (sbt_pLXCN7HeEaG[i] != pObject->sbt_pLXCN7HeEaG[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3.c_str(), pObject->sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3.c_str()))
		{
			return false;
		}
		if (sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.size() != pObject->sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.size(); i++)
		{
			if (sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4[i] != pObject->sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4[i])
			{
				return false;
			}
		}
		if (sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL != pObject->sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL)
		{
			return false;
		}
		if (sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG != pObject->sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG)
		{
			return false;
		}
		if (sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF != pObject->sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF)
		{
			return false;
		}
		if (sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs != pObject->sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs)
		{
			return false;
		}
		if (sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.size() != pObject->sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.size(); i++)
		{
			if (sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1[i] != pObject->sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1[i])
			{
				return false;
			}
		}
		if (sbt_ut9DZDe.size() != pObject->sbt_ut9DZDe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ut9DZDe.size(); i++)
		{
			if (sbt_ut9DZDe[i] != pObject->sbt_ut9DZDe[i])
			{
				return false;
			}
		}
		if (sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9 != pObject->sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9)
		{
			return false;
		}
		if (sbt_TQUHA5NOu1ovLQCXEyhRm.size() != pObject->sbt_TQUHA5NOu1ovLQCXEyhRm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TQUHA5NOu1ovLQCXEyhRm.size(); i++)
		{
			if (sbt_TQUHA5NOu1ovLQCXEyhRm[i] != pObject->sbt_TQUHA5NOu1ovLQCXEyhRm[i])
			{
				return false;
			}
		}
		if (sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.size() != pObject->sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.size(); i++)
		{
			if (sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV[i] != pObject->sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_dq0w4cOmhizBgj5O3fHwzKt.c_str(), pObject->sbt_dq0w4cOmhizBgj5O3fHwzKt.c_str()))
		{
			return false;
		}
		if (sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.size() != pObject->sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.size(); i++)
		{
			if (!sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK[i].Compare(&pObject->sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P9MdfEeNZqmSmcOow", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P9MdfEeNZqmSmcOow = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KCJUVk6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KCJUVk6.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz", &sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ddiXw6veOnE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ddiXw6veOnE.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_03bCXPnAkBjcn3vmCob5sevZibvXr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_pLXCN7HeEaG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pLXCN7HeEaG.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3", &sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL", &sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ut9DZDe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ut9DZDe.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TQUHA5NOu1ovLQCXEyhRm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TQUHA5NOu1ovLQCXEyhRm.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_dq0w4cOmhizBgj5O3fHwzKt", &sbt_dq0w4cOmhizBgj5O3fHwzKt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.begin(); iter != sbt_mwCQG45YVzl4bazYJKGxjJGZWOxjcbI3NSZTRESHwP4lPT6bjDBSfX76aDEU5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P9MdfEeNZqmSmcOow", (CX::Int64)sbt_P9MdfEeNZqmSmcOow)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KCJUVk6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_KCJUVk6.begin(); iter != sbt_KCJUVk6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz", sbt_veLHo5sw90K_8e46P66IxFJC5lwmuySvy5HPmZNo1I7sBpYLgcHBJ75Zz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ddiXw6veOnE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ddiXw6veOnE.begin(); iter != sbt_ddiXw6veOnE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_03bCXPnAkBjcn3vmCob5sevZibvXr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.begin(); iter != sbt_03bCXPnAkBjcn3vmCob5sevZibvXr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.begin(); iter != sbt_2IXwBZKdfoTatAVSS2yMjfkR8LmDLJc9JdVZu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl", (CX::Double)sbt_H2pViQxYmXBWdXWfL4WmL1PE3ytUNXOaFt7ERyw8_ijZ_qR42C5wPr2v3TUhl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pLXCN7HeEaG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_pLXCN7HeEaG.begin(); iter != sbt_pLXCN7HeEaG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3", sbt_Kc3NsXDfdHKKy16AvRhyNLzrfyyeopun3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.begin(); iter != sbt_f2tHZqAbCb7uQPkbRcEXJPHrwgyH4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL", sbt_6dllV2vtx9rvIyzqx2Sx8LVDaMVmElYdFRzOFvaSrSParHy7xIEGdU98k5rBL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG", (CX::Int64)sbt_zCoDOLNWgKc6bo439nVpTnHZgnN4A5us3UH627nnOAG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF", (CX::Int64)sbt_rEkHL5vkDQC04ASHmNcrlrTnE_h1ObEX4Srf4rDtrOvxkUqYKwW28YgzJWQfbfF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs", (CX::Int64)sbt_8dpdb5ZidDxwDVdVP_lkK8GkvBFs_1NXntXVkABLwIo2c6i8E4UKIhKvg_iIs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.begin(); iter != sbt_P51Hf43EMFA8KEE2dv6NMevRy8SETC1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ut9DZDe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ut9DZDe.begin(); iter != sbt_ut9DZDe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9", (CX::Int64)sbt_qB7Tj_i3mANmdS4xQgyHgafK503zmKDG5y9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TQUHA5NOu1ovLQCXEyhRm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_TQUHA5NOu1ovLQCXEyhRm.begin(); iter != sbt_TQUHA5NOu1ovLQCXEyhRm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.begin(); iter != sbt_E6u27KE3GNVgWExPyI4fQKlGoK24xsV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_dq0w4cOmhizBgj5O3fHwzKt", sbt_dq0w4cOmhizBgj5O3fHwzKt.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK")).IsNOK())
		{
			return status;
		}
		for (sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCwArray::const_iterator iter = sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.begin(); iter != sbt_VfJ2XdgUvx5HSdVaHJQXfp81KBBTK.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_DEljHSI>::Type sbt_DEljHSIArray;

