
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig.hpp"


class sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t;
	CX::IO::SimpleBuffers::Int16Array sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ;
	CX::IO::SimpleBuffers::UInt64Array sbt_a;
	CX::Int32 sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7;
	CX::Int32 sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC;
	CX::Int16 sbt_PpQiwCyUwBY;
	sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4igArray sbt_9IDGcqanTwtey0t22ojGeiZ;

	virtual void Reset()
	{
		sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t = 0.0;
		sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.clear();
		sbt_a.clear();
		sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7 = 0;
		sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC = 0;
		sbt_PpQiwCyUwBY = 0;
		sbt_9IDGcqanTwtey0t22ojGeiZ.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t = 0.339102;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.push_back(24835);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_a.push_back(6353693253276198322);
		}
		sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7 = 109750240;
		sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC = 566547628;
		sbt_PpQiwCyUwBY = 5984;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig v;

			v.SetupWithSomeValues();
			sbt_9IDGcqanTwtey0t22ojGeiZ.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY *pObject = dynamic_cast<const sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t != pObject->sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t)
		{
			return false;
		}
		if (sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.size() != pObject->sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.size(); i++)
		{
			if (sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ[i] != pObject->sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ[i])
			{
				return false;
			}
		}
		if (sbt_a.size() != pObject->sbt_a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a.size(); i++)
		{
			if (sbt_a[i] != pObject->sbt_a[i])
			{
				return false;
			}
		}
		if (sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7 != pObject->sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7)
		{
			return false;
		}
		if (sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC != pObject->sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC)
		{
			return false;
		}
		if (sbt_PpQiwCyUwBY != pObject->sbt_PpQiwCyUwBY)
		{
			return false;
		}
		if (sbt_9IDGcqanTwtey0t22ojGeiZ.size() != pObject->sbt_9IDGcqanTwtey0t22ojGeiZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9IDGcqanTwtey0t22ojGeiZ.size(); i++)
		{
			if (!sbt_9IDGcqanTwtey0t22ojGeiZ[i].Compare(&pObject->sbt_9IDGcqanTwtey0t22ojGeiZ[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_PpQiwCyUwBY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_PpQiwCyUwBY = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9IDGcqanTwtey0t22ojGeiZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_9IDGcqanTwtey0t22ojGeiZ.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t", (CX::Double)sbt_aO7VwutC71CB4qZEpyMLpcgNr7SxlF4ZJI1ojac_ULk5_xP9cl0NkYk_t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.begin(); iter != sbt_Isiel25zcZW83v0rAPay6S1Rdv8YuoZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_a.begin(); iter != sbt_a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7", (CX::Int64)sbt_lMlXM4C1Cu2ZU7zhchzGc5DH9ATAq_p8K2lmYzqPU1FmnROGTu796lBWRl7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC", (CX::Int64)sbt_nP6lvpLltQAdCT7GdF1fO3txl6JDGsHbflCWEcH5_dERtB_CvU21ixFaugL9HBC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_PpQiwCyUwBY", (CX::Int64)sbt_PpQiwCyUwBY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9IDGcqanTwtey0t22ojGeiZ")).IsNOK())
		{
			return status;
		}
		for (sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4igArray::const_iterator iter = sbt_9IDGcqanTwtey0t22ojGeiZ.begin(); iter != sbt_9IDGcqanTwtey0t22ojGeiZ.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY>::Type sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqYArray;

