
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK.hpp"


class sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS;
	CX::IO::SimpleBuffers::Int16Array sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy;
	CX::IO::SimpleBuffers::UInt32Array sbt_vEFYEEDzUDabDmrle;
	CX::Int8 sbt_Jeji3j9kCGsLki34FPvTXDL8LBN;
	CX::IO::SimpleBuffers::DoubleArray sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN;
	CX::IO::SimpleBuffers::DoubleArray sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2;
	CX::String sbt_0;
	CX::IO::SimpleBuffers::UInt32Array sbt_JxUJR6q6r2qmlbX;
	sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiKArray sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI;

	virtual void Reset()
	{
		sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS = 0;
		sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.clear();
		sbt_vEFYEEDzUDabDmrle.clear();
		sbt_Jeji3j9kCGsLki34FPvTXDL8LBN = 0;
		sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.clear();
		sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.clear();
		sbt_0.clear();
		sbt_JxUJR6q6r2qmlbX.clear();
		sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS = 490840414;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.push_back(9259);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_vEFYEEDzUDabDmrle.push_back(1886548376);
		}
		sbt_Jeji3j9kCGsLki34FPvTXDL8LBN = -114;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.push_back(0.609477);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.push_back(0.254771);
		}
		sbt_0 = "!cD4@{r-8z>]${mO2ls{o`>+fBSG.N@FGB7Y";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JxUJR6q6r2qmlbX.push_back(3464339138);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK v;

			v.SetupWithSomeValues();
			sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0 *pObject = dynamic_cast<const sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS != pObject->sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS)
		{
			return false;
		}
		if (sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.size() != pObject->sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.size(); i++)
		{
			if (sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy[i] != pObject->sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy[i])
			{
				return false;
			}
		}
		if (sbt_vEFYEEDzUDabDmrle.size() != pObject->sbt_vEFYEEDzUDabDmrle.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vEFYEEDzUDabDmrle.size(); i++)
		{
			if (sbt_vEFYEEDzUDabDmrle[i] != pObject->sbt_vEFYEEDzUDabDmrle[i])
			{
				return false;
			}
		}
		if (sbt_Jeji3j9kCGsLki34FPvTXDL8LBN != pObject->sbt_Jeji3j9kCGsLki34FPvTXDL8LBN)
		{
			return false;
		}
		if (sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.size() != pObject->sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.size(); i++)
		{
			if (sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN[i] != pObject->sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN[i])
			{
				return false;
			}
		}
		if (sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.size() != pObject->sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.size(); i++)
		{
			if (sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2[i] != pObject->sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_0.c_str(), pObject->sbt_0.c_str()))
		{
			return false;
		}
		if (sbt_JxUJR6q6r2qmlbX.size() != pObject->sbt_JxUJR6q6r2qmlbX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JxUJR6q6r2qmlbX.size(); i++)
		{
			if (sbt_JxUJR6q6r2qmlbX[i] != pObject->sbt_JxUJR6q6r2qmlbX[i])
			{
				return false;
			}
		}
		if (sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.size() != pObject->sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.size(); i++)
		{
			if (!sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI[i].Compare(&pObject->sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vEFYEEDzUDabDmrle")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vEFYEEDzUDabDmrle.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Jeji3j9kCGsLki34FPvTXDL8LBN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Jeji3j9kCGsLki34FPvTXDL8LBN = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_0", &sbt_0)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JxUJR6q6r2qmlbX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JxUJR6q6r2qmlbX.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS", (CX::Int64)sbt_BxNHBKZ2eLJwt2Kr2NXcpqp6htKOHiQIs5AZS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.begin(); iter != sbt_Eto8S6m1qD_jvUkBPxxuy5NPbxy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vEFYEEDzUDabDmrle")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_vEFYEEDzUDabDmrle.begin(); iter != sbt_vEFYEEDzUDabDmrle.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Jeji3j9kCGsLki34FPvTXDL8LBN", (CX::Int64)sbt_Jeji3j9kCGsLki34FPvTXDL8LBN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.begin(); iter != sbt_C_QoFvMos50jR4jJlCzo5Ugqpug191TEvybWEzgIN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.begin(); iter != sbt_f07q2SqqDMSdk58mwVYlV63GyqtLSckBMzbL5X6shvnhiNIX62yX4zcbZlxk2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_0", sbt_0.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JxUJR6q6r2qmlbX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_JxUJR6q6r2qmlbX.begin(); iter != sbt_JxUJR6q6r2qmlbX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI")).IsNOK())
		{
			return status;
		}
		for (sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiKArray::const_iterator iter = sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.begin(); iter != sbt_c1GIjOqihUq3Y5kEqDg7o8qAMmZaNI8nIbEjzp4MfPeQ6CkBdAQ49Qn0jGI.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0>::Type sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0Array;

