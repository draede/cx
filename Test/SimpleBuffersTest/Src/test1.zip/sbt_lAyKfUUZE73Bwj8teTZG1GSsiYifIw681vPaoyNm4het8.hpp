
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_KLk7BiRPg1DSfA2ezhS;
	CX::IO::SimpleBuffers::UInt8Array sbt_ZIFU0NcPf9Afyldj8NACgmD;
	CX::Bool sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4;
	CX::UInt8 sbt_B2DxwKSOnRv91v9;
	CX::UInt32 sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2;
	CX::Int16 sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT;
	CX::Int64 sbt_kdUCXeG3ev1tqo317TJEa2Ckn;
	CX::Bool sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG;
	CX::IO::SimpleBuffers::Int8Array sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ;
	CX::UInt64 sbt_WcOx5jVyZgf3q;
	CX::IO::SimpleBuffers::UInt8Array sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI;
	CX::Bool sbt_KSOkNJbQwZYGm;
	CX::IO::SimpleBuffers::UInt32Array sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY;

	virtual void Reset()
	{
		sbt_KLk7BiRPg1DSfA2ezhS.clear();
		sbt_ZIFU0NcPf9Afyldj8NACgmD.clear();
		sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4 = false;
		sbt_B2DxwKSOnRv91v9 = 0;
		sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2 = 0;
		sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT = 0;
		sbt_kdUCXeG3ev1tqo317TJEa2Ckn = 0;
		sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG = false;
		sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.clear();
		sbt_WcOx5jVyZgf3q = 0;
		sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.clear();
		sbt_KSOkNJbQwZYGm = false;
		sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_KLk7BiRPg1DSfA2ezhS.push_back(-12);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_ZIFU0NcPf9Afyldj8NACgmD.push_back(168);
		}
		sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4 = false;
		sbt_B2DxwKSOnRv91v9 = 174;
		sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2 = 1063025486;
		sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT = 27007;
		sbt_kdUCXeG3ev1tqo317TJEa2Ckn = -8342386847730275656;
		sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG = true;
		sbt_WcOx5jVyZgf3q = 5528331371056337132;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.push_back(106);
		}
		sbt_KSOkNJbQwZYGm = true;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.push_back(246129477);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8 *pObject = dynamic_cast<const sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_KLk7BiRPg1DSfA2ezhS.size() != pObject->sbt_KLk7BiRPg1DSfA2ezhS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KLk7BiRPg1DSfA2ezhS.size(); i++)
		{
			if (sbt_KLk7BiRPg1DSfA2ezhS[i] != pObject->sbt_KLk7BiRPg1DSfA2ezhS[i])
			{
				return false;
			}
		}
		if (sbt_ZIFU0NcPf9Afyldj8NACgmD.size() != pObject->sbt_ZIFU0NcPf9Afyldj8NACgmD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZIFU0NcPf9Afyldj8NACgmD.size(); i++)
		{
			if (sbt_ZIFU0NcPf9Afyldj8NACgmD[i] != pObject->sbt_ZIFU0NcPf9Afyldj8NACgmD[i])
			{
				return false;
			}
		}
		if (sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4 != pObject->sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4)
		{
			return false;
		}
		if (sbt_B2DxwKSOnRv91v9 != pObject->sbt_B2DxwKSOnRv91v9)
		{
			return false;
		}
		if (sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2 != pObject->sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2)
		{
			return false;
		}
		if (sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT != pObject->sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT)
		{
			return false;
		}
		if (sbt_kdUCXeG3ev1tqo317TJEa2Ckn != pObject->sbt_kdUCXeG3ev1tqo317TJEa2Ckn)
		{
			return false;
		}
		if (sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG != pObject->sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG)
		{
			return false;
		}
		if (sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.size() != pObject->sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.size(); i++)
		{
			if (sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ[i] != pObject->sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ[i])
			{
				return false;
			}
		}
		if (sbt_WcOx5jVyZgf3q != pObject->sbt_WcOx5jVyZgf3q)
		{
			return false;
		}
		if (sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.size() != pObject->sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.size(); i++)
		{
			if (sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI[i] != pObject->sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI[i])
			{
				return false;
			}
		}
		if (sbt_KSOkNJbQwZYGm != pObject->sbt_KSOkNJbQwZYGm)
		{
			return false;
		}
		if (sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.size() != pObject->sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.size(); i++)
		{
			if (sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY[i] != pObject->sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_KLk7BiRPg1DSfA2ezhS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KLk7BiRPg1DSfA2ezhS.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZIFU0NcPf9Afyldj8NACgmD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZIFU0NcPf9Afyldj8NACgmD.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4", &sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_B2DxwKSOnRv91v9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_B2DxwKSOnRv91v9 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kdUCXeG3ev1tqo317TJEa2Ckn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kdUCXeG3ev1tqo317TJEa2Ckn = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG", &sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_WcOx5jVyZgf3q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WcOx5jVyZgf3q = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_KSOkNJbQwZYGm", &sbt_KSOkNJbQwZYGm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_KLk7BiRPg1DSfA2ezhS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_KLk7BiRPg1DSfA2ezhS.begin(); iter != sbt_KLk7BiRPg1DSfA2ezhS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZIFU0NcPf9Afyldj8NACgmD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ZIFU0NcPf9Afyldj8NACgmD.begin(); iter != sbt_ZIFU0NcPf9Afyldj8NACgmD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4", sbt_g29CNyIgBRvXJu_RgPcgie4TfhkZiWqnnt4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_B2DxwKSOnRv91v9", (CX::Int64)sbt_B2DxwKSOnRv91v9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2", (CX::Int64)sbt_YwZTVyfqWTHhicjrSv4Z5G1NDXlnz4MP9L2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT", (CX::Int64)sbt_zzwsPMGhT7ck3aoBciOCYu3PkGjgtAKTMSzhFJQaqWT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kdUCXeG3ev1tqo317TJEa2Ckn", (CX::Int64)sbt_kdUCXeG3ev1tqo317TJEa2Ckn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG", sbt_gemL4WkmWULiO0M7h2TQibl5M_Ty22Qtjn8IB4rM414yG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.begin(); iter != sbt_azUY_EIpCTC24sgJ6z7S8U5R2LJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WcOx5jVyZgf3q", (CX::Int64)sbt_WcOx5jVyZgf3q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.begin(); iter != sbt_yY2_OF2SaMLnsuCae2crtODkqUVD0onvNnWHzh096WMcI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_KSOkNJbQwZYGm", sbt_KSOkNJbQwZYGm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.begin(); iter != sbt_h9bnjdYGLVDQsZnaICtMyIa2fVigiLObA2wfhDijC7nSDe6MEhkHY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8>::Type sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8Array;

