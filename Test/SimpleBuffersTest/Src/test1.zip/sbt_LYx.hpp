
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_LYx : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_Ue3P8FadD1yHKvvvU;
	CX::Int8 sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc;
	CX::UInt8 sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ;
	CX::Int8 sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy;
	CX::IO::SimpleBuffers::Int32Array sbt_rNLKNk4MmFAgKcZgqinEHq7kf;
	CX::UInt64 sbt_9rKH3QyTP;
	CX::IO::SimpleBuffers::Int16Array sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U;
	CX::Int64 sbt_KtowtOwMd;
	CX::IO::SimpleBuffers::Int64Array sbt_DLDC_;
	CX::IO::SimpleBuffers::Int8Array sbt_j;
	CX::IO::SimpleBuffers::UInt64Array sbt_qsyxMLI;
	CX::IO::SimpleBuffers::UInt64Array sbt_mIV3hZ572NYPznu;
	CX::IO::SimpleBuffers::UInt32Array sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo;
	CX::Int8 sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2;
	CX::IO::SimpleBuffers::Int8Array sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO;
	CX::IO::SimpleBuffers::UInt32Array sbt_YqW8NLDaa8lXS;
	CX::IO::SimpleBuffers::Int16Array sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn;
	CX::UInt32 sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev;
	CX::Int8 sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc;
	CX::Int8 sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H;

	virtual void Reset()
	{
		sbt_Ue3P8FadD1yHKvvvU = false;
		sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc = 0;
		sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ = 0;
		sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy = 0;
		sbt_rNLKNk4MmFAgKcZgqinEHq7kf.clear();
		sbt_9rKH3QyTP = 0;
		sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.clear();
		sbt_KtowtOwMd = 0;
		sbt_DLDC_.clear();
		sbt_j.clear();
		sbt_qsyxMLI.clear();
		sbt_mIV3hZ572NYPznu.clear();
		sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.clear();
		sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2 = 0;
		sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.clear();
		sbt_YqW8NLDaa8lXS.clear();
		sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.clear();
		sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev = 0;
		sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc = 0;
		sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Ue3P8FadD1yHKvvvU = true;
		sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc = 126;
		sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ = 88;
		sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy = -48;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_rNLKNk4MmFAgKcZgqinEHq7kf.push_back(-2093579477);
		}
		sbt_9rKH3QyTP = 5737134382138229230;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.push_back(-19119);
		}
		sbt_KtowtOwMd = -6900806106899667508;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_DLDC_.push_back(6453360821944690840);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_j.push_back(-112);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_qsyxMLI.push_back(15614236123745590182);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_mIV3hZ572NYPznu.push_back(10116798709337807902);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.push_back(3479260427);
		}
		sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2 = 125;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.push_back(-96);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_YqW8NLDaa8lXS.push_back(4105417926);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.push_back(-18603);
		}
		sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev = 1404788632;
		sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc = -7;
		sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H = -77;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_LYx *pObject = dynamic_cast<const sbt_LYx *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Ue3P8FadD1yHKvvvU != pObject->sbt_Ue3P8FadD1yHKvvvU)
		{
			return false;
		}
		if (sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc != pObject->sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc)
		{
			return false;
		}
		if (sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ != pObject->sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ)
		{
			return false;
		}
		if (sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy != pObject->sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy)
		{
			return false;
		}
		if (sbt_rNLKNk4MmFAgKcZgqinEHq7kf.size() != pObject->sbt_rNLKNk4MmFAgKcZgqinEHq7kf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rNLKNk4MmFAgKcZgqinEHq7kf.size(); i++)
		{
			if (sbt_rNLKNk4MmFAgKcZgqinEHq7kf[i] != pObject->sbt_rNLKNk4MmFAgKcZgqinEHq7kf[i])
			{
				return false;
			}
		}
		if (sbt_9rKH3QyTP != pObject->sbt_9rKH3QyTP)
		{
			return false;
		}
		if (sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.size() != pObject->sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.size(); i++)
		{
			if (sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U[i] != pObject->sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U[i])
			{
				return false;
			}
		}
		if (sbt_KtowtOwMd != pObject->sbt_KtowtOwMd)
		{
			return false;
		}
		if (sbt_DLDC_.size() != pObject->sbt_DLDC_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DLDC_.size(); i++)
		{
			if (sbt_DLDC_[i] != pObject->sbt_DLDC_[i])
			{
				return false;
			}
		}
		if (sbt_j.size() != pObject->sbt_j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j.size(); i++)
		{
			if (sbt_j[i] != pObject->sbt_j[i])
			{
				return false;
			}
		}
		if (sbt_qsyxMLI.size() != pObject->sbt_qsyxMLI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qsyxMLI.size(); i++)
		{
			if (sbt_qsyxMLI[i] != pObject->sbt_qsyxMLI[i])
			{
				return false;
			}
		}
		if (sbt_mIV3hZ572NYPznu.size() != pObject->sbt_mIV3hZ572NYPznu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mIV3hZ572NYPznu.size(); i++)
		{
			if (sbt_mIV3hZ572NYPznu[i] != pObject->sbt_mIV3hZ572NYPznu[i])
			{
				return false;
			}
		}
		if (sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.size() != pObject->sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.size(); i++)
		{
			if (sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo[i] != pObject->sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo[i])
			{
				return false;
			}
		}
		if (sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2 != pObject->sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2)
		{
			return false;
		}
		if (sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.size() != pObject->sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.size(); i++)
		{
			if (sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO[i] != pObject->sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO[i])
			{
				return false;
			}
		}
		if (sbt_YqW8NLDaa8lXS.size() != pObject->sbt_YqW8NLDaa8lXS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YqW8NLDaa8lXS.size(); i++)
		{
			if (sbt_YqW8NLDaa8lXS[i] != pObject->sbt_YqW8NLDaa8lXS[i])
			{
				return false;
			}
		}
		if (sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.size() != pObject->sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.size(); i++)
		{
			if (sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn[i] != pObject->sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn[i])
			{
				return false;
			}
		}
		if (sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev != pObject->sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev)
		{
			return false;
		}
		if (sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc != pObject->sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc)
		{
			return false;
		}
		if (sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H != pObject->sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_Ue3P8FadD1yHKvvvU", &sbt_Ue3P8FadD1yHKvvvU)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_rNLKNk4MmFAgKcZgqinEHq7kf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rNLKNk4MmFAgKcZgqinEHq7kf.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9rKH3QyTP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9rKH3QyTP = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KtowtOwMd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KtowtOwMd = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_DLDC_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DLDC_.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qsyxMLI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qsyxMLI.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mIV3hZ572NYPznu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mIV3hZ572NYPznu.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YqW8NLDaa8lXS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YqW8NLDaa8lXS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_Ue3P8FadD1yHKvvvU", sbt_Ue3P8FadD1yHKvvvU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc", (CX::Int64)sbt_ezQQzlAScQKhENo7nZWS4wn8ZgF2fxQCc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ", (CX::Int64)sbt_12gwOnkP3IX7r70b1xJuVk0_VgGU7a9mQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy", (CX::Int64)sbt_iNaDXyzwLKcNSKna1iH5gVSsq76jRt1OidcYy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rNLKNk4MmFAgKcZgqinEHq7kf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_rNLKNk4MmFAgKcZgqinEHq7kf.begin(); iter != sbt_rNLKNk4MmFAgKcZgqinEHq7kf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9rKH3QyTP", (CX::Int64)sbt_9rKH3QyTP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.begin(); iter != sbt_YoxUcTtAydww_o542YQJSflyUkYWacYTx_au7AzlrtYYekbWGft8Ldtuyjg8U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KtowtOwMd", (CX::Int64)sbt_KtowtOwMd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DLDC_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_DLDC_.begin(); iter != sbt_DLDC_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_j.begin(); iter != sbt_j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qsyxMLI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_qsyxMLI.begin(); iter != sbt_qsyxMLI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mIV3hZ572NYPznu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_mIV3hZ572NYPznu.begin(); iter != sbt_mIV3hZ572NYPznu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.begin(); iter != sbt_N_jj9wOp_VnlF4h0zwQCX8Vc_8SUA4VK0WUQ1AGlo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2", (CX::Int64)sbt_lz5C045fB9nDi0vt4WTlOTh3A4yflmm3yikmlCup2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.begin(); iter != sbt_ANf7QennU0CIDxWpvmS0tHICW_V55J_l9pQiv1AiX9cHO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YqW8NLDaa8lXS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_YqW8NLDaa8lXS.begin(); iter != sbt_YqW8NLDaa8lXS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.begin(); iter != sbt_EdVmQWGn9WWS_57FaDUwb_ezBc0o5vvf_cJ7Nmt77dp15CSujv0saaU3fRzGn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev", (CX::Int64)sbt_shPJpCayaJQmWQoMNf1U0XS8KiGCbmLJfIrjDev)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc", (CX::Int64)sbt_qWQLBxatg_n6u0kP_H0FJkMlWbiVn1cALUuczYc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H", (CX::Int64)sbt_RlT6xfkAb5nvOI6kAIkFFW7iwgy2dnzxzPK0YhyuWdV9H)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_LYx>::Type sbt_LYxArray;

