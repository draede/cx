
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_GtcIUaYWCt5kAsi2u : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G;
	CX::IO::SimpleBuffers::Int32Array sbt_TKMkBhpjNP5D_2jpAfw9e_99L;
	CX::Bool sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ;
	CX::IO::SimpleBuffers::Int8Array sbt_xdtqEGaDg;
	CX::IO::SimpleBuffers::Int16Array sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn;
	CX::UInt8 sbt_v;
	CX::IO::SimpleBuffers::StringArray sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9;
	CX::Bool sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k;
	CX::UInt32 sbt_4YO7Mx1lEts86AToc4ttfts;
	CX::UInt64 sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig;

	virtual void Reset()
	{
		sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.clear();
		sbt_TKMkBhpjNP5D_2jpAfw9e_99L.clear();
		sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ = false;
		sbt_xdtqEGaDg.clear();
		sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.clear();
		sbt_v = 0;
		sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.clear();
		sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k = false;
		sbt_4YO7Mx1lEts86AToc4ttfts = 0;
		sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.push_back(4393503408481114126);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_TKMkBhpjNP5D_2jpAfw9e_99L.push_back(-928308566);
		}
		sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_xdtqEGaDg.push_back(-91);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.push_back(23790);
		}
		sbt_v = 0;
		sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k = false;
		sbt_4YO7Mx1lEts86AToc4ttfts = 1771345735;
		sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig = 15252919283241618244;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_GtcIUaYWCt5kAsi2u *pObject = dynamic_cast<const sbt_GtcIUaYWCt5kAsi2u *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.size() != pObject->sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.size(); i++)
		{
			if (sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G[i] != pObject->sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G[i])
			{
				return false;
			}
		}
		if (sbt_TKMkBhpjNP5D_2jpAfw9e_99L.size() != pObject->sbt_TKMkBhpjNP5D_2jpAfw9e_99L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TKMkBhpjNP5D_2jpAfw9e_99L.size(); i++)
		{
			if (sbt_TKMkBhpjNP5D_2jpAfw9e_99L[i] != pObject->sbt_TKMkBhpjNP5D_2jpAfw9e_99L[i])
			{
				return false;
			}
		}
		if (sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ != pObject->sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ)
		{
			return false;
		}
		if (sbt_xdtqEGaDg.size() != pObject->sbt_xdtqEGaDg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xdtqEGaDg.size(); i++)
		{
			if (sbt_xdtqEGaDg[i] != pObject->sbt_xdtqEGaDg[i])
			{
				return false;
			}
		}
		if (sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.size() != pObject->sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.size(); i++)
		{
			if (sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn[i] != pObject->sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn[i])
			{
				return false;
			}
		}
		if (sbt_v != pObject->sbt_v)
		{
			return false;
		}
		if (sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.size() != pObject->sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.size(); i++)
		{
			if (0 != cx_strcmp(sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9[i].c_str(), pObject->sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k != pObject->sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k)
		{
			return false;
		}
		if (sbt_4YO7Mx1lEts86AToc4ttfts != pObject->sbt_4YO7Mx1lEts86AToc4ttfts)
		{
			return false;
		}
		if (sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig != pObject->sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_TKMkBhpjNP5D_2jpAfw9e_99L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TKMkBhpjNP5D_2jpAfw9e_99L.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ", &sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xdtqEGaDg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xdtqEGaDg.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_v", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k", &sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4YO7Mx1lEts86AToc4ttfts", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4YO7Mx1lEts86AToc4ttfts = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.begin(); iter != sbt_zciYtWE0T8v4k4A6N2TD2y793L9DFUKVkjvg7mkKT0WXWUa2OSP6G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TKMkBhpjNP5D_2jpAfw9e_99L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_TKMkBhpjNP5D_2jpAfw9e_99L.begin(); iter != sbt_TKMkBhpjNP5D_2jpAfw9e_99L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ", sbt_Arbvt0ngNLB8VHlTlgf1ljwGeyVVmUbUZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xdtqEGaDg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_xdtqEGaDg.begin(); iter != sbt_xdtqEGaDg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.begin(); iter != sbt_7XrjAi3b_P8nOm8qYhQqZl_lkeoDPRy45DSZzMumMDPNgp2ApYekn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v", (CX::Int64)sbt_v)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.begin(); iter != sbt_reyltmaFlTc4YJOABIyj7MzPNfGMVwWJCx9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k", sbt_gwW4Wfkanhg1l8zoSTdkL6K5WVLZccYPrV1uk0k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4YO7Mx1lEts86AToc4ttfts", (CX::Int64)sbt_4YO7Mx1lEts86AToc4ttfts)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig", (CX::Int64)sbt_ezDJqfhX2pxXLu3ipDBdebIK5TjjgreVgm3LVkjEPNm_xXhmAG3jZJdig)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_GtcIUaYWCt5kAsi2u>::Type sbt_GtcIUaYWCt5kAsi2uArray;

