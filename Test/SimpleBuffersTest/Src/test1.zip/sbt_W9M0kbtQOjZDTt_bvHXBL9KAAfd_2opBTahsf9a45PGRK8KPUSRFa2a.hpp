
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo.hpp"


class sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Bool sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at;
	CX::Int16 sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd;
	CX::WString sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV;
	CX::UInt32 sbt_b_4Gcfmg_4IiXgNUhvgM2;
	CX::IO::SimpleBuffers::StringArray sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv;
	CX::Int64 sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY;
	CX::IO::SimpleBuffers::BoolArray sbt__yjdMX7Pd3FAatmL6hf;
	CX::IO::SimpleBuffers::WStringArray sbt_dOr6B5cgNOD44;
	CX::IO::SimpleBuffers::UInt16Array sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0;
	CX::IO::SimpleBuffers::Int32Array sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_;
	CX::UInt16 sbt_zhfceNZKqiisqphxo;
	CX::String sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb;
	CX::IO::SimpleBuffers::Int64Array sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r;
	CX::Int8 sbt_80EPkYStoV6hk;
	CX::Int64 sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m;
	CX::IO::SimpleBuffers::Int32Array sbt_WEFY6s58vBS3z;
	CX::IO::SimpleBuffers::Int8Array sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs;
	CX::IO::SimpleBuffers::Int8Array sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN;
	CX::IO::SimpleBuffers::BoolArray sbt_h5xTxi2ibedSmIc;
	CX::Int32 sbt_4t5iOUkXBNa9glWGvGa753_;
	CX::IO::SimpleBuffers::DoubleArray sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx;
	CX::IO::SimpleBuffers::Int16Array sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr;
	sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL;

	virtual void Reset()
	{
		sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at = false;
		sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd = 0;
		sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV.clear();
		sbt_b_4Gcfmg_4IiXgNUhvgM2 = 0;
		sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.clear();
		sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY = 0;
		sbt__yjdMX7Pd3FAatmL6hf.clear();
		sbt_dOr6B5cgNOD44.clear();
		sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.clear();
		sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.clear();
		sbt_zhfceNZKqiisqphxo = 0;
		sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb.clear();
		sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.clear();
		sbt_80EPkYStoV6hk = 0;
		sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m = 0;
		sbt_WEFY6s58vBS3z.clear();
		sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.clear();
		sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.clear();
		sbt_h5xTxi2ibedSmIc.clear();
		sbt_4t5iOUkXBNa9glWGvGa753_ = 0;
		sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.clear();
		sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.clear();
		sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at = true;
		sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd = -16866;
		sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV = L"jW_iR^f2!&OqT+P#/8o~kFlCTbUw0*1L:wLdC\"dm,";
		sbt_b_4Gcfmg_4IiXgNUhvgM2 = 861175239;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.push_back("Q75@8-FY`>G");
		}
		sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY = 7270957833869643980;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt__yjdMX7Pd3FAatmL6hf.push_back(false);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_dOr6B5cgNOD44.push_back(L"J`lXlAj_&+V2HXgyc}&s");
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.push_back(31170);
		}
		sbt_zhfceNZKqiisqphxo = 45704;
		sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb = "6:\"\\~f*[BLwQC~";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.push_back(-1327305977632872804);
		}
		sbt_80EPkYStoV6hk = 54;
		sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m = 4768180959731338758;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_WEFY6s58vBS3z.push_back(-1774849627);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.push_back(10);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.push_back(84);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_h5xTxi2ibedSmIc.push_back(false);
		}
		sbt_4t5iOUkXBNa9glWGvGa753_ = 1518063385;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.push_back(0.255390);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.push_back(1223);
		}
		sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a *pObject = dynamic_cast<const sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at != pObject->sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at)
		{
			return false;
		}
		if (sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd != pObject->sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV.c_str(), pObject->sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV.c_str()))
		{
			return false;
		}
		if (sbt_b_4Gcfmg_4IiXgNUhvgM2 != pObject->sbt_b_4Gcfmg_4IiXgNUhvgM2)
		{
			return false;
		}
		if (sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.size() != pObject->sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.size(); i++)
		{
			if (0 != cx_strcmp(sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv[i].c_str(), pObject->sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY != pObject->sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY)
		{
			return false;
		}
		if (sbt__yjdMX7Pd3FAatmL6hf.size() != pObject->sbt__yjdMX7Pd3FAatmL6hf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__yjdMX7Pd3FAatmL6hf.size(); i++)
		{
			if (sbt__yjdMX7Pd3FAatmL6hf[i] != pObject->sbt__yjdMX7Pd3FAatmL6hf[i])
			{
				return false;
			}
		}
		if (sbt_dOr6B5cgNOD44.size() != pObject->sbt_dOr6B5cgNOD44.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dOr6B5cgNOD44.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_dOr6B5cgNOD44[i].c_str(), pObject->sbt_dOr6B5cgNOD44[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.size() != pObject->sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.size(); i++)
		{
			if (sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0[i] != pObject->sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0[i])
			{
				return false;
			}
		}
		if (sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.size() != pObject->sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.size(); i++)
		{
			if (sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_[i] != pObject->sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_[i])
			{
				return false;
			}
		}
		if (sbt_zhfceNZKqiisqphxo != pObject->sbt_zhfceNZKqiisqphxo)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb.c_str(), pObject->sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb.c_str()))
		{
			return false;
		}
		if (sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.size() != pObject->sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.size(); i++)
		{
			if (sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r[i] != pObject->sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r[i])
			{
				return false;
			}
		}
		if (sbt_80EPkYStoV6hk != pObject->sbt_80EPkYStoV6hk)
		{
			return false;
		}
		if (sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m != pObject->sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m)
		{
			return false;
		}
		if (sbt_WEFY6s58vBS3z.size() != pObject->sbt_WEFY6s58vBS3z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WEFY6s58vBS3z.size(); i++)
		{
			if (sbt_WEFY6s58vBS3z[i] != pObject->sbt_WEFY6s58vBS3z[i])
			{
				return false;
			}
		}
		if (sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.size() != pObject->sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.size(); i++)
		{
			if (sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs[i] != pObject->sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs[i])
			{
				return false;
			}
		}
		if (sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.size() != pObject->sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.size(); i++)
		{
			if (sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN[i] != pObject->sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN[i])
			{
				return false;
			}
		}
		if (sbt_h5xTxi2ibedSmIc.size() != pObject->sbt_h5xTxi2ibedSmIc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h5xTxi2ibedSmIc.size(); i++)
		{
			if (sbt_h5xTxi2ibedSmIc[i] != pObject->sbt_h5xTxi2ibedSmIc[i])
			{
				return false;
			}
		}
		if (sbt_4t5iOUkXBNa9glWGvGa753_ != pObject->sbt_4t5iOUkXBNa9glWGvGa753_)
		{
			return false;
		}
		if (sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.size() != pObject->sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.size(); i++)
		{
			if (sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx[i] != pObject->sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx[i])
			{
				return false;
			}
		}
		if (sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.size() != pObject->sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.size(); i++)
		{
			if (sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr[i] != pObject->sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr[i])
			{
				return false;
			}
		}
		if (!sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL.Compare(&pObject->sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectBool("sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at", &sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV", &sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_b_4Gcfmg_4IiXgNUhvgM2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b_4Gcfmg_4IiXgNUhvgM2 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt__yjdMX7Pd3FAatmL6hf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__yjdMX7Pd3FAatmL6hf.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dOr6B5cgNOD44")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dOr6B5cgNOD44.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zhfceNZKqiisqphxo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zhfceNZKqiisqphxo = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb", &sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_80EPkYStoV6hk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_80EPkYStoV6hk = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_WEFY6s58vBS3z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WEFY6s58vBS3z.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h5xTxi2ibedSmIc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h5xTxi2ibedSmIc.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4t5iOUkXBNa9glWGvGa753_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4t5iOUkXBNa9glWGvGa753_ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectBool("sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at", sbt_sfo_zgUk92gjS0OvEyRiIrXZabuBEXmvEIgHvg7dCe9at)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd", (CX::Int64)sbt_so1rmJ2OORlFBsKhLp0CyQJ8u9WAl6BwEnKT8bd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV", sbt_L_JlEZYncgpVwihkmqZ2nbIyS0P1ZWNixSDmTsvyOmUx5rrfgUV.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b_4Gcfmg_4IiXgNUhvgM2", (CX::Int64)sbt_b_4Gcfmg_4IiXgNUhvgM2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.begin(); iter != sbt_2u0cuHdWo5NrVhgj4RqWCS5Qd_IgAT2EHYBMldv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY", (CX::Int64)sbt_VIqXunBXLzuK70E4onFDDh5piQ8eHx45c5by5tY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__yjdMX7Pd3FAatmL6hf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt__yjdMX7Pd3FAatmL6hf.begin(); iter != sbt__yjdMX7Pd3FAatmL6hf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dOr6B5cgNOD44")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_dOr6B5cgNOD44.begin(); iter != sbt_dOr6B5cgNOD44.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.begin(); iter != sbt_541yikuHcawffO8EujYb_T4q56CDmaPdpfM5MScifGWMeV2hEpGmnqLH0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.begin(); iter != sbt_p3o8GVqg4w8RCGN2_ppW2mVVN7qL7XYs6K_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zhfceNZKqiisqphxo", (CX::Int64)sbt_zhfceNZKqiisqphxo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb", sbt_CgJuzd7qNMcBNSAxI9r_h1tFVhHcf3bAFCHN13iiibb.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.begin(); iter != sbt_KQ6kmi2H6OUUkiVt2n796qFcafggeMNLUlzZpMd0VkBVMBb6r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_80EPkYStoV6hk", (CX::Int64)sbt_80EPkYStoV6hk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m", (CX::Int64)sbt_fwPWFy2bEPrGp9jq4ezQlM88vYxUalXvauQ02onJ_IsBm446m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WEFY6s58vBS3z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_WEFY6s58vBS3z.begin(); iter != sbt_WEFY6s58vBS3z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.begin(); iter != sbt_ERnT6PtxjS1wh_6zeTxEEZcM3XbLVsWnG_P2pAiZs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.begin(); iter != sbt_zNa1cps499RcUMfXZYbQW33HTkMZdrl0LvI1WlPOqoxDm1Z_yz5peqxjr8fiN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h5xTxi2ibedSmIc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_h5xTxi2ibedSmIc.begin(); iter != sbt_h5xTxi2ibedSmIc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4t5iOUkXBNa9glWGvGa753_", (CX::Int64)sbt_4t5iOUkXBNa9glWGvGa753_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.begin(); iter != sbt_ASTP7NanSYfPGATa3dpkjKF2CDBdPaR5uFMBmaip9jeHLobwpkRJHMdYkRNsx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.begin(); iter != sbt_hZrz4UqoJQT1Q16NOWPOgvzAETE5dpHnekMaPaowqEi03MfHQMoeHhgn2cFlnQr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iKnuwmgXjKgCVIvi8ROBTOrAYnMHL.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a>::Type sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2aArray;

