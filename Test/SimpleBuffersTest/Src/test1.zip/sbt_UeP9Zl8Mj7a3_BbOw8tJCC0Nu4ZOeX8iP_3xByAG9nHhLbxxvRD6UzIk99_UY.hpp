
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_aMTJj;
	CX::IO::SimpleBuffers::Int32Array sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA;
	CX::IO::SimpleBuffers::BoolArray sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z;
	CX::Int32 sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9;
	CX::IO::SimpleBuffers::UInt64Array sbt_BUBiG;

	virtual void Reset()
	{
		sbt_aMTJj.clear();
		sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.clear();
		sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.clear();
		sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9 = 0;
		sbt_BUBiG.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_aMTJj.push_back(6796425497602789092);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.push_back(-509166707);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.push_back(true);
		}
		sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9 = -185141538;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_BUBiG.push_back(16447122891604593596);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY *pObject = dynamic_cast<const sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_aMTJj.size() != pObject->sbt_aMTJj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aMTJj.size(); i++)
		{
			if (sbt_aMTJj[i] != pObject->sbt_aMTJj[i])
			{
				return false;
			}
		}
		if (sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.size() != pObject->sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.size(); i++)
		{
			if (sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA[i] != pObject->sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA[i])
			{
				return false;
			}
		}
		if (sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.size() != pObject->sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.size(); i++)
		{
			if (sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z[i] != pObject->sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z[i])
			{
				return false;
			}
		}
		if (sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9 != pObject->sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9)
		{
			return false;
		}
		if (sbt_BUBiG.size() != pObject->sbt_BUBiG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BUBiG.size(); i++)
		{
			if (sbt_BUBiG[i] != pObject->sbt_BUBiG[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_aMTJj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aMTJj.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BUBiG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BUBiG.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_aMTJj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_aMTJj.begin(); iter != sbt_aMTJj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.begin(); iter != sbt_kdzL4qSjvEShDso6LSXrncGdfvAOQTqPudoGTJJKseqDRyA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.begin(); iter != sbt_pVc2YllOCoz_9n0eejlSNlJv3V0YHoFY_PD2gW0Oic99ALAnpbQblXf6Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9", (CX::Int64)sbt_vhI9TdH32Xr0N8aUNz2kgT_6s0tBKsvx9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BUBiG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BUBiG.begin(); iter != sbt_BUBiG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY>::Type sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UYArray;

