
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw;
	CX::IO::SimpleBuffers::UInt32Array sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu;
	CX::IO::SimpleBuffers::Int16Array sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q;
	CX::IO::SimpleBuffers::Int32Array sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij;
	CX::IO::SimpleBuffers::Int8Array sbt_HZxrEIOTuTN;
	CX::UInt64 sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY;
	CX::UInt16 sbt_IMW6UQxQpfyMybOidMo55sj;
	CX::UInt64 sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_;
	CX::UInt32 sbt_wVnmvJiDfaBc_g2wE;
	CX::IO::SimpleBuffers::StringArray sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl;
	CX::IO::SimpleBuffers::UInt32Array sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt;
	CX::Int64 sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ;

	virtual void Reset()
	{
		sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.clear();
		sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.clear();
		sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.clear();
		sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.clear();
		sbt_HZxrEIOTuTN.clear();
		sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY = 0;
		sbt_IMW6UQxQpfyMybOidMo55sj = 0;
		sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_ = 0;
		sbt_wVnmvJiDfaBc_g2wE = 0;
		sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.clear();
		sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.clear();
		sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.push_back(579301085);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.push_back(23059749);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.push_back(-8064);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.push_back(1711772706);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_HZxrEIOTuTN.push_back(32);
		}
		sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY = 10315582186352242248;
		sbt_IMW6UQxQpfyMybOidMo55sj = 42692;
		sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_ = 16396263389067543518;
		sbt_wVnmvJiDfaBc_g2wE = 2248937879;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.push_back("Eo/juN}$!wX3%w\"VdDX*'XD?.q'\"bVqo]EuZ.q$W9PDAVIC2M9\\");
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.push_back(2994255214);
		}
		sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ = -5472300752794614544;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61 *pObject = dynamic_cast<const sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.size() != pObject->sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.size(); i++)
		{
			if (sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw[i] != pObject->sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw[i])
			{
				return false;
			}
		}
		if (sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.size() != pObject->sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.size(); i++)
		{
			if (sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu[i] != pObject->sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu[i])
			{
				return false;
			}
		}
		if (sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.size() != pObject->sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.size(); i++)
		{
			if (sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q[i] != pObject->sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q[i])
			{
				return false;
			}
		}
		if (sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.size() != pObject->sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.size(); i++)
		{
			if (sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij[i] != pObject->sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij[i])
			{
				return false;
			}
		}
		if (sbt_HZxrEIOTuTN.size() != pObject->sbt_HZxrEIOTuTN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HZxrEIOTuTN.size(); i++)
		{
			if (sbt_HZxrEIOTuTN[i] != pObject->sbt_HZxrEIOTuTN[i])
			{
				return false;
			}
		}
		if (sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY != pObject->sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY)
		{
			return false;
		}
		if (sbt_IMW6UQxQpfyMybOidMo55sj != pObject->sbt_IMW6UQxQpfyMybOidMo55sj)
		{
			return false;
		}
		if (sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_ != pObject->sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_)
		{
			return false;
		}
		if (sbt_wVnmvJiDfaBc_g2wE != pObject->sbt_wVnmvJiDfaBc_g2wE)
		{
			return false;
		}
		if (sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.size() != pObject->sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.size(); i++)
		{
			if (0 != cx_strcmp(sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl[i].c_str(), pObject->sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.size() != pObject->sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.size(); i++)
		{
			if (sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt[i] != pObject->sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt[i])
			{
				return false;
			}
		}
		if (sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ != pObject->sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HZxrEIOTuTN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HZxrEIOTuTN.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_IMW6UQxQpfyMybOidMo55sj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IMW6UQxQpfyMybOidMo55sj = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wVnmvJiDfaBc_g2wE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wVnmvJiDfaBc_g2wE = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ = (CX::Int64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.begin(); iter != sbt_qJBOphNQ6ocR0df_EIgWQXTy0hS6yqY8gpchEhw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.begin(); iter != sbt_JnfMiQ2pGvLpCkJkSaw8amVeRLwrwvMqWHO0bSTwneK6B_SLDeViv1glfnu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.begin(); iter != sbt_ODlqqLXqGzLS8LAtWkZ9aEN86b6tR06obkcn18S8Q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.begin(); iter != sbt_WJMzcmZ2wRiKpvQxTpfoLVqPLaqzQGU6qTj3Rz3BUlnij.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HZxrEIOTuTN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_HZxrEIOTuTN.begin(); iter != sbt_HZxrEIOTuTN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY", (CX::Int64)sbt_DlpQyCC8OLq_l2cJjGCjjLWCJjTlQW8mRpp6HZNXCWD4WkcXyBY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IMW6UQxQpfyMybOidMo55sj", (CX::Int64)sbt_IMW6UQxQpfyMybOidMo55sj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_", (CX::Int64)sbt_H6h7vhJZg3Xmd3YqeLygELttaci4FHY6jNkVTokyhwPtISgGbWUewkeG_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wVnmvJiDfaBc_g2wE", (CX::Int64)sbt_wVnmvJiDfaBc_g2wE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.begin(); iter != sbt_ghubKYT6eu7INLd5NLc6rTuMevAbzmpnxpSMEMuSGHasCFYBwEd2aOErFZl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.begin(); iter != sbt_tPR8jg2PElpw_65O5PTZ0wwV14rGQ3G4EIvFRjdTwLk63SqTz6JBt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ", (CX::Int64)sbt_4ZEKwE0uLfcz30S3ekztu7FbhzB0pw64hs2bFkJ)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61>::Type sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61Array;

