
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Tb75_HdXsxT7w : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_8VnpvpibErWLR;
	CX::IO::SimpleBuffers::Int32Array sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH;
	CX::Int16 sbt_Tn93phcJ_kL8Q6PeZ;
	CX::String sbt_BUG;
	CX::Int8 sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx;
	CX::Int8 sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs;
	CX::Int64 sbt_uF32CVVVbqmHMtFyjmiGIdD;
	CX::IO::SimpleBuffers::BoolArray sbt_zWN;
	CX::UInt16 sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe;
	CX::UInt64 sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO;
	CX::Bool sbt_6Ewhb6rBuKuWSZh;
	CX::UInt8 sbt_0hlJl;
	CX::IO::SimpleBuffers::UInt8Array sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e;

	virtual void Reset()
	{
		sbt_8VnpvpibErWLR.clear();
		sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.clear();
		sbt_Tn93phcJ_kL8Q6PeZ = 0;
		sbt_BUG.clear();
		sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx = 0;
		sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs = 0;
		sbt_uF32CVVVbqmHMtFyjmiGIdD = 0;
		sbt_zWN.clear();
		sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe = 0;
		sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO = 0;
		sbt_6Ewhb6rBuKuWSZh = false;
		sbt_0hlJl = 0;
		sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.push_back(-427237328);
		}
		sbt_Tn93phcJ_kL8Q6PeZ = -25498;
		sbt_BUG = ">$o9TiOpQaC.D";
		sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx = 61;
		sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs = -113;
		sbt_uF32CVVVbqmHMtFyjmiGIdD = 4057265395136746232;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_zWN.push_back(false);
		}
		sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe = 7824;
		sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO = 13265673924515570602;
		sbt_6Ewhb6rBuKuWSZh = false;
		sbt_0hlJl = 76;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.push_back(141);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Tb75_HdXsxT7w *pObject = dynamic_cast<const sbt_Tb75_HdXsxT7w *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_8VnpvpibErWLR.size() != pObject->sbt_8VnpvpibErWLR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8VnpvpibErWLR.size(); i++)
		{
			if (sbt_8VnpvpibErWLR[i] != pObject->sbt_8VnpvpibErWLR[i])
			{
				return false;
			}
		}
		if (sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.size() != pObject->sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.size(); i++)
		{
			if (sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH[i] != pObject->sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH[i])
			{
				return false;
			}
		}
		if (sbt_Tn93phcJ_kL8Q6PeZ != pObject->sbt_Tn93phcJ_kL8Q6PeZ)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_BUG.c_str(), pObject->sbt_BUG.c_str()))
		{
			return false;
		}
		if (sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx != pObject->sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx)
		{
			return false;
		}
		if (sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs != pObject->sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs)
		{
			return false;
		}
		if (sbt_uF32CVVVbqmHMtFyjmiGIdD != pObject->sbt_uF32CVVVbqmHMtFyjmiGIdD)
		{
			return false;
		}
		if (sbt_zWN.size() != pObject->sbt_zWN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zWN.size(); i++)
		{
			if (sbt_zWN[i] != pObject->sbt_zWN[i])
			{
				return false;
			}
		}
		if (sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe != pObject->sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe)
		{
			return false;
		}
		if (sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO != pObject->sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO)
		{
			return false;
		}
		if (sbt_6Ewhb6rBuKuWSZh != pObject->sbt_6Ewhb6rBuKuWSZh)
		{
			return false;
		}
		if (sbt_0hlJl != pObject->sbt_0hlJl)
		{
			return false;
		}
		if (sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.size() != pObject->sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.size(); i++)
		{
			if (sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e[i] != pObject->sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_8VnpvpibErWLR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8VnpvpibErWLR.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Tn93phcJ_kL8Q6PeZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Tn93phcJ_kL8Q6PeZ = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_BUG", &sbt_BUG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_uF32CVVVbqmHMtFyjmiGIdD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_uF32CVVVbqmHMtFyjmiGIdD = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zWN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zWN.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_6Ewhb6rBuKuWSZh", &sbt_6Ewhb6rBuKuWSZh)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0hlJl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0hlJl = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_8VnpvpibErWLR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_8VnpvpibErWLR.begin(); iter != sbt_8VnpvpibErWLR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.begin(); iter != sbt_ZXez1RDz5lLbYSgSRWpBXmlTsLDN59cS0lqHtGiexeMFR3Q59NstIjH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Tn93phcJ_kL8Q6PeZ", (CX::Int64)sbt_Tn93phcJ_kL8Q6PeZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_BUG", sbt_BUG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx", (CX::Int64)sbt_nMKbp3AL3EaPaG0r0xHFvx_0N0lenprABqiQEbx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs", (CX::Int64)sbt_DyLyvJDC7_JCBwFE7Pj5YC1zaVDm7fx2PkpzktA59kk5uvLkOe9BOVs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_uF32CVVVbqmHMtFyjmiGIdD", (CX::Int64)sbt_uF32CVVVbqmHMtFyjmiGIdD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zWN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_zWN.begin(); iter != sbt_zWN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe", (CX::Int64)sbt_EbYDQE53tcMWecNB94ghQqhQfZjzqoAYe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO", (CX::Int64)sbt_b9IRqB94nhDk4hT9Tqnm9O5oQ9iEC34k4aRCw8kICnBwO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_6Ewhb6rBuKuWSZh", sbt_6Ewhb6rBuKuWSZh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0hlJl", (CX::Int64)sbt_0hlJl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.begin(); iter != sbt_LezLFINGUCua7QBTb96lFIImR9vrZC4V36e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Tb75_HdXsxT7w>::Type sbt_Tb75_HdXsxT7wArray;

