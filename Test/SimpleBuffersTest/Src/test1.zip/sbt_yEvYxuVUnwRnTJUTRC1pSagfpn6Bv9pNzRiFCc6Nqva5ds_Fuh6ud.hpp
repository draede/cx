
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_0Mk8Rck1rfINzZy.hpp"


class sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm;
	CX::Int64 sbt_D;
	CX::UInt64 sbt_hjtYnwMpYOPubA1;
	CX::Int32 sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ;
	CX::Double sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V;
	CX::IO::SimpleBuffers::UInt8Array sbt_U80;
	CX::IO::SimpleBuffers::Int64Array sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq;
	CX::IO::SimpleBuffers::WStringArray sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne;
	CX::String sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ;
	CX::IO::SimpleBuffers::UInt8Array sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj;
	CX::UInt16 sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD;
	CX::Int64 sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ;
	CX::Int32 sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y;
	CX::IO::SimpleBuffers::Int8Array sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV;
	CX::UInt32 sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx;
	CX::IO::SimpleBuffers::StringArray sbt_j;
	CX::IO::SimpleBuffers::Int8Array sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer;
	CX::IO::SimpleBuffers::UInt8Array sbt_wGLmogwTEB5UdRmQA_mrs;
	CX::Int32 sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_;
	CX::UInt32 sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p;
	CX::Int64 sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc;
	CX::Int8 sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp;
	CX::IO::SimpleBuffers::DoubleArray sbt_t1jPgzF3Og_kd6ETT7N;
	CX::IO::SimpleBuffers::Int32Array sbt_t;
	sbt_0Mk8Rck1rfINzZy sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq;

	virtual void Reset()
	{
		sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm = 0.0f;
		sbt_D = 0;
		sbt_hjtYnwMpYOPubA1 = 0;
		sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ = 0;
		sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V = 0.0;
		sbt_U80.clear();
		sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.clear();
		sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.clear();
		sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ.clear();
		sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.clear();
		sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD = 0;
		sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ = 0;
		sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y = 0;
		sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.clear();
		sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx = 0;
		sbt_j.clear();
		sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.clear();
		sbt_wGLmogwTEB5UdRmQA_mrs.clear();
		sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_ = 0;
		sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p = 0;
		sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc = 0;
		sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp = 0;
		sbt_t1jPgzF3Og_kd6ETT7N.clear();
		sbt_t.clear();
		sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm = 0.777587f;
		sbt_D = -2670353248935211552;
		sbt_hjtYnwMpYOPubA1 = 10009402019496971836;
		sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ = 299050669;
		sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V = 0.348220;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_U80.push_back(118);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.push_back(8198336421518762926);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.push_back(L"hp!${2ErH^8T_@Hb_.8m5?,UdB%hU^s\\a@59T^`A");
		}
		sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ = "dBaC&s`N?gn`dr0\"b&3H~iv_a4RVwvbUGJ_0+6@IUPMc";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.push_back(122);
		}
		sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD = 28636;
		sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ = 5356790522493326258;
		sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y = -1208000029;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.push_back(-103);
		}
		sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx = 1288731572;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_j.push_back("l2_N5*!bN=f>s&}KA,`g=8\"e");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.push_back(115);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_wGLmogwTEB5UdRmQA_mrs.push_back(222);
		}
		sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_ = 105090277;
		sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p = 1352431644;
		sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc = -2570279396276596224;
		sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp = 52;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_t1jPgzF3Og_kd6ETT7N.push_back(0.919315);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_t.push_back(-1344472094);
		}
		sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud *pObject = dynamic_cast<const sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm != pObject->sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm)
		{
			return false;
		}
		if (sbt_D != pObject->sbt_D)
		{
			return false;
		}
		if (sbt_hjtYnwMpYOPubA1 != pObject->sbt_hjtYnwMpYOPubA1)
		{
			return false;
		}
		if (sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ != pObject->sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ)
		{
			return false;
		}
		if (sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V != pObject->sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V)
		{
			return false;
		}
		if (sbt_U80.size() != pObject->sbt_U80.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U80.size(); i++)
		{
			if (sbt_U80[i] != pObject->sbt_U80[i])
			{
				return false;
			}
		}
		if (sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.size() != pObject->sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.size(); i++)
		{
			if (sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq[i] != pObject->sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq[i])
			{
				return false;
			}
		}
		if (sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.size() != pObject->sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne[i].c_str(), pObject->sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ.c_str(), pObject->sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ.c_str()))
		{
			return false;
		}
		if (sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.size() != pObject->sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.size(); i++)
		{
			if (sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj[i] != pObject->sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj[i])
			{
				return false;
			}
		}
		if (sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD != pObject->sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD)
		{
			return false;
		}
		if (sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ != pObject->sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ)
		{
			return false;
		}
		if (sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y != pObject->sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y)
		{
			return false;
		}
		if (sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.size() != pObject->sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.size(); i++)
		{
			if (sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV[i] != pObject->sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV[i])
			{
				return false;
			}
		}
		if (sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx != pObject->sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx)
		{
			return false;
		}
		if (sbt_j.size() != pObject->sbt_j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j.size(); i++)
		{
			if (0 != cx_strcmp(sbt_j[i].c_str(), pObject->sbt_j[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.size() != pObject->sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.size(); i++)
		{
			if (sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer[i] != pObject->sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer[i])
			{
				return false;
			}
		}
		if (sbt_wGLmogwTEB5UdRmQA_mrs.size() != pObject->sbt_wGLmogwTEB5UdRmQA_mrs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wGLmogwTEB5UdRmQA_mrs.size(); i++)
		{
			if (sbt_wGLmogwTEB5UdRmQA_mrs[i] != pObject->sbt_wGLmogwTEB5UdRmQA_mrs[i])
			{
				return false;
			}
		}
		if (sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_ != pObject->sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_)
		{
			return false;
		}
		if (sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p != pObject->sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p)
		{
			return false;
		}
		if (sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc != pObject->sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc)
		{
			return false;
		}
		if (sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp != pObject->sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp)
		{
			return false;
		}
		if (sbt_t1jPgzF3Og_kd6ETT7N.size() != pObject->sbt_t1jPgzF3Og_kd6ETT7N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t1jPgzF3Og_kd6ETT7N.size(); i++)
		{
			if (sbt_t1jPgzF3Og_kd6ETT7N[i] != pObject->sbt_t1jPgzF3Og_kd6ETT7N[i])
			{
				return false;
			}
		}
		if (sbt_t.size() != pObject->sbt_t.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_t.size(); i++)
		{
			if (sbt_t[i] != pObject->sbt_t[i])
			{
				return false;
			}
		}
		if (!sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq.Compare(&pObject->sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_D", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_D = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hjtYnwMpYOPubA1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hjtYnwMpYOPubA1 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_U80")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U80.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ", &sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wGLmogwTEB5UdRmQA_mrs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wGLmogwTEB5UdRmQA_mrs.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_ = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_t1jPgzF3Og_kd6ETT7N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t1jPgzF3Og_kd6ETT7N.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_t")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_t.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm", (CX::Double)sbt_ut4Td6TlTHAnUDHabAJwrOQyO1k2gFaAJXcz56EHRj0tWZm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_D", (CX::Int64)sbt_D)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hjtYnwMpYOPubA1", (CX::Int64)sbt_hjtYnwMpYOPubA1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ", (CX::Int64)sbt_ugorlqv5FJllIyvIq76n9YokwCjdb_9_6rHTN4ULTrtQU4x_AS9FMdZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V", (CX::Double)sbt_lY7Siaha0u7dn8oi4pioCIygpzXfWDcFeoMD9a7070tmLdrJoFsNUZ37V)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U80")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_U80.begin(); iter != sbt_U80.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.begin(); iter != sbt_8aHFNiWKnLP5mSVNbmMYoKwht6BZv9uIL94QHfCsxCq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.begin(); iter != sbt_St1Ef4yp0LWHgvNd9kkVEyRcN15g7Ne.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ", sbt_LE_KxGQLatg8wJIYalZ7VXwP47jhPPqpulJ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.begin(); iter != sbt_zshi6M3IiBrdnzsmfF2kOMdNk3c4BCMTvc_9ZG8uJATR4L17lJj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD", (CX::Int64)sbt_AGe3tRMaRmT671xiVmJXmOF9CfXfilD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ", (CX::Int64)sbt_KQtH1SvJ_rxntXrIt0G1Qu8c7p7XpcTrUGfezF800Peia0Ljom1sJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y", (CX::Int64)sbt_nhi7eAhnsOgVKtc8L9EFClRchwQ4o4Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.begin(); iter != sbt_jwxJDUtz7iMF3S1ZyyAn2LIRV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx", (CX::Int64)sbt_XgL9Fq2r7CurV_tcA_iQucgrBZ3stXx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_j.begin(); iter != sbt_j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.begin(); iter != sbt_obIzcvsp1HoO1ti5PC5xyC4DwgeX7ebIsnKFbmeUH0K9VqAjkbxqYwl6rOMer.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wGLmogwTEB5UdRmQA_mrs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_wGLmogwTEB5UdRmQA_mrs.begin(); iter != sbt_wGLmogwTEB5UdRmQA_mrs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_", (CX::Int64)sbt_cX7pNELv7FLOnw4YbiTIm8ZM0wSDU4EISVeLTvoXTdn6nGWDrv81_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p", (CX::Int64)sbt_p2NoDem1SGCMtWtUhN1t6BCQgbNUjcoZAYEpkXnQyUe09UA9p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc", (CX::Int64)sbt_U_yCbShVBizF8xGg3nO_N5DR6O5vc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp", (CX::Int64)sbt_oKgLnxnxcWXUXh_35WxMxUXYdpvnbURjA8bItsp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t1jPgzF3Og_kd6ETT7N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_t1jPgzF3Og_kd6ETT7N.begin(); iter != sbt_t1jPgzF3Og_kd6ETT7N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_t")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_t.begin(); iter != sbt_t.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ZHOCNVtAizFyVcdgNHHUKgI4HvN2EnwugpQQq.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud>::Type sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6udArray;

