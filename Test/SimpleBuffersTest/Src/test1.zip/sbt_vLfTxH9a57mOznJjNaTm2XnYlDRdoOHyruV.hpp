
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz.hpp"


class sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7;
	CX::Int32 sbt_J_JJj;
	CX::UInt32 sbt_A7Z1GopApnKhAApwrBQtJ;
	CX::WString sbt_akq2gkWbELV4hsZADvh51;
	CX::IO::SimpleBuffers::WStringArray sbt_M5Hm80jfNyi8NFEuJUO;
	CX::Double sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8;
	CX::Int8 sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV;
	CX::Float sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj;
	CX::Bool sbt_Wn4;
	CX::IO::SimpleBuffers::DoubleArray sbt_vNOGKVZoDvixM7yrzoOse_P3O;
	CX::IO::SimpleBuffers::UInt8Array sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp;
	CX::IO::SimpleBuffers::Int8Array sbt_eum6YLyv7P1qKau;
	CX::IO::SimpleBuffers::WStringArray sbt_AhTGO2t;
	CX::IO::SimpleBuffers::DoubleArray sbt_P69F8zMWCZQfGgD;
	CX::IO::SimpleBuffers::UInt32Array sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl;
	sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSzArray sbt_EVc;

	virtual void Reset()
	{
		sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.clear();
		sbt_J_JJj = 0;
		sbt_A7Z1GopApnKhAApwrBQtJ = 0;
		sbt_akq2gkWbELV4hsZADvh51.clear();
		sbt_M5Hm80jfNyi8NFEuJUO.clear();
		sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8 = 0.0;
		sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV = 0;
		sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj = 0.0f;
		sbt_Wn4 = false;
		sbt_vNOGKVZoDvixM7yrzoOse_P3O.clear();
		sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.clear();
		sbt_eum6YLyv7P1qKau.clear();
		sbt_AhTGO2t.clear();
		sbt_P69F8zMWCZQfGgD.clear();
		sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.clear();
		sbt_EVc.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.push_back(845561873057538268);
		}
		sbt_J_JJj = -35914747;
		sbt_A7Z1GopApnKhAApwrBQtJ = 793717040;
		sbt_akq2gkWbELV4hsZADvh51 = L"aC)ItNU-NvJK8fjiY0~!ij?ZgRP4+1eb<C{DfDT9\"4(CZ";
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_M5Hm80jfNyi8NFEuJUO.push_back(L"DSCKV)Hj*j:m52>+}nK7lsPB7-\"g=leJN@0,7psx+'\"ZyV(t\"F{zK!AtV");
		}
		sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8 = 0.258498;
		sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV = -17;
		sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj = 0.495719f;
		sbt_Wn4 = false;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_vNOGKVZoDvixM7yrzoOse_P3O.push_back(0.394875);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.push_back(50);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_eum6YLyv7P1qKau.push_back(-125);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_AhTGO2t.push_back(L"WJy~WN#Gp;A[ksn6-)yf^*Z.nW01(HJ3jRns,ACA\\&_ulz`^ex}-'Ai*cu1f{c");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_P69F8zMWCZQfGgD.push_back(0.880038);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.push_back(324904667);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz v;

			v.SetupWithSomeValues();
			sbt_EVc.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV *pObject = dynamic_cast<const sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.size() != pObject->sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.size(); i++)
		{
			if (sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7[i] != pObject->sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7[i])
			{
				return false;
			}
		}
		if (sbt_J_JJj != pObject->sbt_J_JJj)
		{
			return false;
		}
		if (sbt_A7Z1GopApnKhAApwrBQtJ != pObject->sbt_A7Z1GopApnKhAApwrBQtJ)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_akq2gkWbELV4hsZADvh51.c_str(), pObject->sbt_akq2gkWbELV4hsZADvh51.c_str()))
		{
			return false;
		}
		if (sbt_M5Hm80jfNyi8NFEuJUO.size() != pObject->sbt_M5Hm80jfNyi8NFEuJUO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M5Hm80jfNyi8NFEuJUO.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_M5Hm80jfNyi8NFEuJUO[i].c_str(), pObject->sbt_M5Hm80jfNyi8NFEuJUO[i].c_str()))
			{
				return false;
			}
		}
		if (sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8 != pObject->sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8)
		{
			return false;
		}
		if (sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV != pObject->sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV)
		{
			return false;
		}
		if (sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj != pObject->sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj)
		{
			return false;
		}
		if (sbt_Wn4 != pObject->sbt_Wn4)
		{
			return false;
		}
		if (sbt_vNOGKVZoDvixM7yrzoOse_P3O.size() != pObject->sbt_vNOGKVZoDvixM7yrzoOse_P3O.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vNOGKVZoDvixM7yrzoOse_P3O.size(); i++)
		{
			if (sbt_vNOGKVZoDvixM7yrzoOse_P3O[i] != pObject->sbt_vNOGKVZoDvixM7yrzoOse_P3O[i])
			{
				return false;
			}
		}
		if (sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.size() != pObject->sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.size(); i++)
		{
			if (sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp[i] != pObject->sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp[i])
			{
				return false;
			}
		}
		if (sbt_eum6YLyv7P1qKau.size() != pObject->sbt_eum6YLyv7P1qKau.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eum6YLyv7P1qKau.size(); i++)
		{
			if (sbt_eum6YLyv7P1qKau[i] != pObject->sbt_eum6YLyv7P1qKau[i])
			{
				return false;
			}
		}
		if (sbt_AhTGO2t.size() != pObject->sbt_AhTGO2t.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AhTGO2t.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_AhTGO2t[i].c_str(), pObject->sbt_AhTGO2t[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_P69F8zMWCZQfGgD.size() != pObject->sbt_P69F8zMWCZQfGgD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P69F8zMWCZQfGgD.size(); i++)
		{
			if (sbt_P69F8zMWCZQfGgD[i] != pObject->sbt_P69F8zMWCZQfGgD[i])
			{
				return false;
			}
		}
		if (sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.size() != pObject->sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.size(); i++)
		{
			if (sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl[i] != pObject->sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl[i])
			{
				return false;
			}
		}
		if (sbt_EVc.size() != pObject->sbt_EVc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EVc.size(); i++)
		{
			if (!sbt_EVc[i].Compare(&pObject->sbt_EVc[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J_JJj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J_JJj = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_A7Z1GopApnKhAApwrBQtJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A7Z1GopApnKhAApwrBQtJ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectWString("sbt_akq2gkWbELV4hsZADvh51", &sbt_akq2gkWbELV4hsZADvh51)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M5Hm80jfNyi8NFEuJUO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M5Hm80jfNyi8NFEuJUO.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8 = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_Wn4", &sbt_Wn4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vNOGKVZoDvixM7yrzoOse_P3O")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vNOGKVZoDvixM7yrzoOse_P3O.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eum6YLyv7P1qKau")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eum6YLyv7P1qKau.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AhTGO2t")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AhTGO2t.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P69F8zMWCZQfGgD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P69F8zMWCZQfGgD.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EVc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_EVc.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.begin(); iter != sbt_OXCx6e0ziJTNngX_ThzfduL0VhNX580MXojQOKvc7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J_JJj", (CX::Int64)sbt_J_JJj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A7Z1GopApnKhAApwrBQtJ", (CX::Int64)sbt_A7Z1GopApnKhAApwrBQtJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_akq2gkWbELV4hsZADvh51", sbt_akq2gkWbELV4hsZADvh51.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M5Hm80jfNyi8NFEuJUO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_M5Hm80jfNyi8NFEuJUO.begin(); iter != sbt_M5Hm80jfNyi8NFEuJUO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8", (CX::Double)sbt__CJBCm0GyFqHn16E3bfLW10d8mToF_Jcipuq6wao9c8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV", (CX::Int64)sbt_N0zJFuWWxVm56gb_BjM6ubS3LQA_X_xgV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj", (CX::Double)sbt_KtHhSXGqyke5ol7cfME_zTM5VEVvWurhhcRGDxbMUcPb4tEffNj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Wn4", sbt_Wn4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vNOGKVZoDvixM7yrzoOse_P3O")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_vNOGKVZoDvixM7yrzoOse_P3O.begin(); iter != sbt_vNOGKVZoDvixM7yrzoOse_P3O.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.begin(); iter != sbt_wyLfEC4hp5PDaJR4G4fmtWN8pkJEYRPF1UeLGANE2RQsp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eum6YLyv7P1qKau")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_eum6YLyv7P1qKau.begin(); iter != sbt_eum6YLyv7P1qKau.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AhTGO2t")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_AhTGO2t.begin(); iter != sbt_AhTGO2t.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P69F8zMWCZQfGgD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_P69F8zMWCZQfGgD.begin(); iter != sbt_P69F8zMWCZQfGgD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.begin(); iter != sbt_Zq5aUhNggQtgutYy12Le7CYr4zmaa8dO74FFy3GMl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EVc")).IsNOK())
		{
			return status;
		}
		for (sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSzArray::const_iterator iter = sbt_EVc.begin(); iter != sbt_EVc.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV>::Type sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruVArray;

