
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_5lCZz6s7wDo : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_dDCDPSeuQO2ZcER;
	CX::String sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2;
	CX::UInt32 sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb;
	CX::UInt8 sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E;
	CX::IO::SimpleBuffers::BoolArray sbt_zcn;
	CX::IO::SimpleBuffers::UInt8Array sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4;
	CX::IO::SimpleBuffers::UInt8Array sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe;
	CX::IO::SimpleBuffers::UInt32Array sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm;
	CX::String sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE;
	CX::String sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT;
	CX::Int8 sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89;
	CX::UInt32 sbt_Cy1aqHXVRjaO7AZdVUE3pl7;
	CX::Bool sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_;
	CX::Int8 sbt_P6a;
	CX::IO::SimpleBuffers::UInt32Array sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6;
	CX::UInt64 sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h;
	CX::Bool sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8;
	CX::UInt32 sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm;
	CX::IO::SimpleBuffers::Int64Array sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_;

	virtual void Reset()
	{
		sbt_dDCDPSeuQO2ZcER = 0;
		sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2.clear();
		sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb = 0;
		sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E = 0;
		sbt_zcn.clear();
		sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.clear();
		sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.clear();
		sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.clear();
		sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE.clear();
		sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT.clear();
		sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89 = 0;
		sbt_Cy1aqHXVRjaO7AZdVUE3pl7 = 0;
		sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_ = false;
		sbt_P6a = 0;
		sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.clear();
		sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h = 0;
		sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8 = false;
		sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm = 0;
		sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_dDCDPSeuQO2ZcER = 15148830272020532896;
		sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2 = "{Ma\\@Gnd\"{i.r?4m#1w?'j?7K3C58O>>(<Y<0_+?!d9*b~aX+BA";
		sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb = 3201879990;
		sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E = 174;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_zcn.push_back(true);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.push_back(164);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.push_back(4263543218);
		}
		sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE = "`6tq;/kBol=N<,9S@S";
		sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT = "aZXP^jC7a=b2a?U#wEm#kx";
		sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89 = -9;
		sbt_Cy1aqHXVRjaO7AZdVUE3pl7 = 3656810019;
		sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_ = true;
		sbt_P6a = 90;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.push_back(2217733145);
		}
		sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h = 1761648108682886174;
		sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8 = true;
		sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm = 820788369;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.push_back(-477065696519211538);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_5lCZz6s7wDo *pObject = dynamic_cast<const sbt_5lCZz6s7wDo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_dDCDPSeuQO2ZcER != pObject->sbt_dDCDPSeuQO2ZcER)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2.c_str(), pObject->sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2.c_str()))
		{
			return false;
		}
		if (sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb != pObject->sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb)
		{
			return false;
		}
		if (sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E != pObject->sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E)
		{
			return false;
		}
		if (sbt_zcn.size() != pObject->sbt_zcn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zcn.size(); i++)
		{
			if (sbt_zcn[i] != pObject->sbt_zcn[i])
			{
				return false;
			}
		}
		if (sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.size() != pObject->sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.size(); i++)
		{
			if (sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4[i] != pObject->sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4[i])
			{
				return false;
			}
		}
		if (sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.size() != pObject->sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.size(); i++)
		{
			if (sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe[i] != pObject->sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe[i])
			{
				return false;
			}
		}
		if (sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.size() != pObject->sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.size(); i++)
		{
			if (sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm[i] != pObject->sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE.c_str(), pObject->sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE.c_str()))
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT.c_str(), pObject->sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT.c_str()))
		{
			return false;
		}
		if (sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89 != pObject->sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89)
		{
			return false;
		}
		if (sbt_Cy1aqHXVRjaO7AZdVUE3pl7 != pObject->sbt_Cy1aqHXVRjaO7AZdVUE3pl7)
		{
			return false;
		}
		if (sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_ != pObject->sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_)
		{
			return false;
		}
		if (sbt_P6a != pObject->sbt_P6a)
		{
			return false;
		}
		if (sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.size() != pObject->sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.size(); i++)
		{
			if (sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6[i] != pObject->sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6[i])
			{
				return false;
			}
		}
		if (sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h != pObject->sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h)
		{
			return false;
		}
		if (sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8 != pObject->sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8)
		{
			return false;
		}
		if (sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm != pObject->sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm)
		{
			return false;
		}
		if (sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.size() != pObject->sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.size(); i++)
		{
			if (sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_[i] != pObject->sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_dDCDPSeuQO2ZcER", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dDCDPSeuQO2ZcER = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2", &sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_zcn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zcn.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE", &sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT", &sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Cy1aqHXVRjaO7AZdVUE3pl7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Cy1aqHXVRjaO7AZdVUE3pl7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_", &sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_P6a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P6a = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8", &sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_dDCDPSeuQO2ZcER", (CX::Int64)sbt_dDCDPSeuQO2ZcER)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2", sbt_FaKLKW8vXzDke0UfE9A6uWoutUKdyzrq_nHOZ99sbywDGRXrtl2.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb", (CX::Int64)sbt_WoyWHhIgTLMCxiG2lq6H3knJfXbVJQNhBdX7DgdnXyb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E", (CX::Int64)sbt_3CJKggtv93MSNwdXvD27rjfxPoDP__nmxGTwybjGiUS4DORR4Qg5qY7DY9E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zcn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_zcn.begin(); iter != sbt_zcn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.begin(); iter != sbt_f2HWzbS6w5YKNAp_yd_iUFAr5OagCwWsheHTu8TgLZ4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.begin(); iter != sbt_9hYXy4S1dnFwHC9DlSVHns75jETZe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.begin(); iter != sbt_fttQjBwQkDSZoUI00hBw4SlA_35u9UrGMjDdrHIFj21kytcywGm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE", sbt_Qavrr6LHV7KiXIahQ84v87mrKYhDfcE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT", sbt_2g1WEa5qNoD846kl069685BO53bGRSAe5CT.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89", (CX::Int64)sbt_cQNIFmgR7RCZ0mCqDCEXd_ci9n6PAenb5saj9C2T67QSTbLhB89)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Cy1aqHXVRjaO7AZdVUE3pl7", (CX::Int64)sbt_Cy1aqHXVRjaO7AZdVUE3pl7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_", sbt_SLz6YRqLGahqvwyPHbqUNj9ssIYqtry7W8UON6hj_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P6a", (CX::Int64)sbt_P6a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.begin(); iter != sbt_TVQA0dwbnDKZQoxcTcHRpPRPep724a8ox7HnbcX1rM0NX2Dr4IEvUo6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h", (CX::Int64)sbt_zFGI0dpR5y5n6KRlg3d1LmbTIn45GzyzzSW5cydwIDDJjlBwxaFtbKmMu_h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8", sbt_yBioiXbonJfpPbbqIVqCfFjwjkw88O8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm", (CX::Int64)sbt_eDk5nWS_G4Cs0ngLp0KmqZe8KLNtAn1dm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.begin(); iter != sbt_vvo_aERyZhK1KAt2HWguXgw3OICW61k1g3nj1rk5X4iTXkWKf_43HyLd_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_5lCZz6s7wDo>::Type sbt_5lCZz6s7wDoArray;

