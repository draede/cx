
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_0VDSUx7CiZIi0aij7 : public CX::IO::SimpleBuffers::IObject
{
public:


	virtual void Reset()
	{
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_0VDSUx7CiZIi0aij7 *pObject = dynamic_cast<const sbt_0VDSUx7CiZIi0aij7 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;


		return CX::Status();
	}

};

typedef CX::Vector<sbt_0VDSUx7CiZIi0aij7>::Type sbt_0VDSUx7CiZIi0aij7Array;

