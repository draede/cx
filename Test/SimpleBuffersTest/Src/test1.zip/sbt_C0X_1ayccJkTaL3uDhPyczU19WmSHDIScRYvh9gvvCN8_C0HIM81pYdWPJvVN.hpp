
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO;
	CX::IO::SimpleBuffers::UInt64Array sbt_IJGcBnM2WBDBWvzMfOc8ZyH;
	CX::IO::SimpleBuffers::Int8Array sbt_2vO;
	CX::IO::SimpleBuffers::Int64Array sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN;

	virtual void Reset()
	{
		sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.clear();
		sbt_IJGcBnM2WBDBWvzMfOc8ZyH.clear();
		sbt_2vO.clear();
		sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.push_back(55885);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_IJGcBnM2WBDBWvzMfOc8ZyH.push_back(17611379120578347846);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_2vO.push_back(63);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.push_back(6378053964749117986);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN *pObject = dynamic_cast<const sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.size() != pObject->sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.size(); i++)
		{
			if (sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO[i] != pObject->sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO[i])
			{
				return false;
			}
		}
		if (sbt_IJGcBnM2WBDBWvzMfOc8ZyH.size() != pObject->sbt_IJGcBnM2WBDBWvzMfOc8ZyH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IJGcBnM2WBDBWvzMfOc8ZyH.size(); i++)
		{
			if (sbt_IJGcBnM2WBDBWvzMfOc8ZyH[i] != pObject->sbt_IJGcBnM2WBDBWvzMfOc8ZyH[i])
			{
				return false;
			}
		}
		if (sbt_2vO.size() != pObject->sbt_2vO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2vO.size(); i++)
		{
			if (sbt_2vO[i] != pObject->sbt_2vO[i])
			{
				return false;
			}
		}
		if (sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.size() != pObject->sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.size(); i++)
		{
			if (sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN[i] != pObject->sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IJGcBnM2WBDBWvzMfOc8ZyH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IJGcBnM2WBDBWvzMfOc8ZyH.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2vO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2vO.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.begin(); iter != sbt_tRx_hvFceLwmesAUOvKPH8OPnur8TXVHARgoKzO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IJGcBnM2WBDBWvzMfOc8ZyH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_IJGcBnM2WBDBWvzMfOc8ZyH.begin(); iter != sbt_IJGcBnM2WBDBWvzMfOc8ZyH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2vO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_2vO.begin(); iter != sbt_2vO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.begin(); iter != sbt_P1R19xNoNZUwN1A5W6IA1UjVkPifi4boi4wdTzS1P86rvAIB7HN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN>::Type sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVNArray;

