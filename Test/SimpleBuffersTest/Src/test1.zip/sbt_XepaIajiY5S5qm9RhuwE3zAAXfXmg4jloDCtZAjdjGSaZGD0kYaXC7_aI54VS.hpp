
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_LeZoYnWlPD9T3MyZvtAF6.hpp"


class sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr;
	CX::Int32 sbt_2CGsY8EiatWX3;
	CX::IO::SimpleBuffers::StringArray sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K;
	CX::IO::SimpleBuffers::Int16Array sbt_4ktWW664UCFcgLQW7wK2u9cYqHA;
	CX::IO::SimpleBuffers::Int16Array sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD;
	CX::WString sbt_5rRzQb7z3;
	CX::Int32 sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR;
	CX::IO::SimpleBuffers::UInt8Array sbt_dCtj0uvST;
	CX::IO::SimpleBuffers::Int16Array sbt_S;
	CX::IO::SimpleBuffers::StringArray sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk;
	CX::Int16 sbt_E0G2d4m;
	CX::IO::SimpleBuffers::UInt8Array sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP;
	CX::UInt16 sbt_4wdOUQx_xj8HiQR;
	CX::UInt32 sbt_DoHzgfwFVRTzG62WYstXs;
	CX::IO::SimpleBuffers::WStringArray sbt_GQoTbzNla4oWEebxA;
	CX::IO::SimpleBuffers::WStringArray sbt_ECwweOgjD77AL;
	CX::IO::SimpleBuffers::BoolArray sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV;
	CX::Double sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV;
	CX::IO::SimpleBuffers::UInt64Array sbt_plG3Ns5Ot1M9pEFQLmzEpVEye;
	CX::IO::SimpleBuffers::BoolArray sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1;
	CX::IO::SimpleBuffers::BoolArray sbt__5La3YQqmNtsWg9_E;
	CX::IO::SimpleBuffers::Int64Array sbt_Rbl4khX4_1XWPZvE9iihx7e;
	CX::Int8 sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA;
	CX::Int16 sbt_Myg;
	CX::IO::SimpleBuffers::UInt32Array sbt_JPiYQJAhGcY;
	sbt_LeZoYnWlPD9T3MyZvtAF6 sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax;

	virtual void Reset()
	{
		sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr = 0;
		sbt_2CGsY8EiatWX3 = 0;
		sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.clear();
		sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.clear();
		sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.clear();
		sbt_5rRzQb7z3.clear();
		sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR = 0;
		sbt_dCtj0uvST.clear();
		sbt_S.clear();
		sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.clear();
		sbt_E0G2d4m = 0;
		sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.clear();
		sbt_4wdOUQx_xj8HiQR = 0;
		sbt_DoHzgfwFVRTzG62WYstXs = 0;
		sbt_GQoTbzNla4oWEebxA.clear();
		sbt_ECwweOgjD77AL.clear();
		sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.clear();
		sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV = 0.0;
		sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.clear();
		sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.clear();
		sbt__5La3YQqmNtsWg9_E.clear();
		sbt_Rbl4khX4_1XWPZvE9iihx7e.clear();
		sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA = 0;
		sbt_Myg = 0;
		sbt_JPiYQJAhGcY.clear();
		sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr = -6980121104054033850;
		sbt_2CGsY8EiatWX3 = -1498528432;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.push_back("Ak{d|nhXHs7<sh]&JQo]rBu4`l}%~WIi+K!Odd9A}_EEnE;'(gI,s0R]<]Fg]@/'");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.push_back(14958);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.push_back(9910);
		}
		sbt_5rRzQb7z3 = L"xGx&7vm{:\\,kWg1x^;wc`O1CN7lOK^";
		sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR = -1267883923;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_dCtj0uvST.push_back(132);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_S.push_back(-16705);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.push_back("Z`8lSh\"Guit8of#3p!Yv99DiIE=-Z^jF4b,[Be1w6^}2ZA(Fu%");
		}
		sbt_E0G2d4m = 20832;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.push_back(117);
		}
		sbt_4wdOUQx_xj8HiQR = 24993;
		sbt_DoHzgfwFVRTzG62WYstXs = 3178834856;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_GQoTbzNla4oWEebxA.push_back(L"MYN_X>)8cb");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_ECwweOgjD77AL.push_back(L"[>eJ$8E(U#");
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.push_back(false);
		}
		sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV = 0.146288;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.push_back(1868744657132319978);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.push_back(true);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt__5La3YQqmNtsWg9_E.push_back(false);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Rbl4khX4_1XWPZvE9iihx7e.push_back(-3851815381528339800);
		}
		sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA = 124;
		sbt_Myg = -23397;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_JPiYQJAhGcY.push_back(1658842849);
		}
		sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS *pObject = dynamic_cast<const sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr != pObject->sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr)
		{
			return false;
		}
		if (sbt_2CGsY8EiatWX3 != pObject->sbt_2CGsY8EiatWX3)
		{
			return false;
		}
		if (sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.size() != pObject->sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.size(); i++)
		{
			if (0 != cx_strcmp(sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K[i].c_str(), pObject->sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.size() != pObject->sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.size(); i++)
		{
			if (sbt_4ktWW664UCFcgLQW7wK2u9cYqHA[i] != pObject->sbt_4ktWW664UCFcgLQW7wK2u9cYqHA[i])
			{
				return false;
			}
		}
		if (sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.size() != pObject->sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.size(); i++)
		{
			if (sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD[i] != pObject->sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_5rRzQb7z3.c_str(), pObject->sbt_5rRzQb7z3.c_str()))
		{
			return false;
		}
		if (sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR != pObject->sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR)
		{
			return false;
		}
		if (sbt_dCtj0uvST.size() != pObject->sbt_dCtj0uvST.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dCtj0uvST.size(); i++)
		{
			if (sbt_dCtj0uvST[i] != pObject->sbt_dCtj0uvST[i])
			{
				return false;
			}
		}
		if (sbt_S.size() != pObject->sbt_S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S.size(); i++)
		{
			if (sbt_S[i] != pObject->sbt_S[i])
			{
				return false;
			}
		}
		if (sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.size() != pObject->sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk[i].c_str(), pObject->sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_E0G2d4m != pObject->sbt_E0G2d4m)
		{
			return false;
		}
		if (sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.size() != pObject->sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.size(); i++)
		{
			if (sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP[i] != pObject->sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP[i])
			{
				return false;
			}
		}
		if (sbt_4wdOUQx_xj8HiQR != pObject->sbt_4wdOUQx_xj8HiQR)
		{
			return false;
		}
		if (sbt_DoHzgfwFVRTzG62WYstXs != pObject->sbt_DoHzgfwFVRTzG62WYstXs)
		{
			return false;
		}
		if (sbt_GQoTbzNla4oWEebxA.size() != pObject->sbt_GQoTbzNla4oWEebxA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GQoTbzNla4oWEebxA.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_GQoTbzNla4oWEebxA[i].c_str(), pObject->sbt_GQoTbzNla4oWEebxA[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ECwweOgjD77AL.size() != pObject->sbt_ECwweOgjD77AL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ECwweOgjD77AL.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_ECwweOgjD77AL[i].c_str(), pObject->sbt_ECwweOgjD77AL[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.size() != pObject->sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.size(); i++)
		{
			if (sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV[i] != pObject->sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV[i])
			{
				return false;
			}
		}
		if (sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV != pObject->sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV)
		{
			return false;
		}
		if (sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.size() != pObject->sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.size(); i++)
		{
			if (sbt_plG3Ns5Ot1M9pEFQLmzEpVEye[i] != pObject->sbt_plG3Ns5Ot1M9pEFQLmzEpVEye[i])
			{
				return false;
			}
		}
		if (sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.size() != pObject->sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.size(); i++)
		{
			if (sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1[i] != pObject->sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1[i])
			{
				return false;
			}
		}
		if (sbt__5La3YQqmNtsWg9_E.size() != pObject->sbt__5La3YQqmNtsWg9_E.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__5La3YQqmNtsWg9_E.size(); i++)
		{
			if (sbt__5La3YQqmNtsWg9_E[i] != pObject->sbt__5La3YQqmNtsWg9_E[i])
			{
				return false;
			}
		}
		if (sbt_Rbl4khX4_1XWPZvE9iihx7e.size() != pObject->sbt_Rbl4khX4_1XWPZvE9iihx7e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Rbl4khX4_1XWPZvE9iihx7e.size(); i++)
		{
			if (sbt_Rbl4khX4_1XWPZvE9iihx7e[i] != pObject->sbt_Rbl4khX4_1XWPZvE9iihx7e[i])
			{
				return false;
			}
		}
		if (sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA != pObject->sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA)
		{
			return false;
		}
		if (sbt_Myg != pObject->sbt_Myg)
		{
			return false;
		}
		if (sbt_JPiYQJAhGcY.size() != pObject->sbt_JPiYQJAhGcY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JPiYQJAhGcY.size(); i++)
		{
			if (sbt_JPiYQJAhGcY[i] != pObject->sbt_JPiYQJAhGcY[i])
			{
				return false;
			}
		}
		if (!sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax.Compare(&pObject->sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_2CGsY8EiatWX3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2CGsY8EiatWX3 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4ktWW664UCFcgLQW7wK2u9cYqHA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_5rRzQb7z3", &sbt_5rRzQb7z3)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dCtj0uvST")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dCtj0uvST.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_E0G2d4m", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E0G2d4m = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4wdOUQx_xj8HiQR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4wdOUQx_xj8HiQR = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DoHzgfwFVRTzG62WYstXs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DoHzgfwFVRTzG62WYstXs = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GQoTbzNla4oWEebxA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GQoTbzNla4oWEebxA.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ECwweOgjD77AL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ECwweOgjD77AL.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_plG3Ns5Ot1M9pEFQLmzEpVEye")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__5La3YQqmNtsWg9_E")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__5La3YQqmNtsWg9_E.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Rbl4khX4_1XWPZvE9iihx7e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Rbl4khX4_1XWPZvE9iihx7e.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Myg", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Myg = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JPiYQJAhGcY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JPiYQJAhGcY.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr", (CX::Int64)sbt_t4anTBzXbkxh1zBiBILLjnvOeZsME40P4wrs5twO_ojh7HWOZb92QZcPckr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2CGsY8EiatWX3", (CX::Int64)sbt_2CGsY8EiatWX3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.begin(); iter != sbt_5kadPlInAGMzW0xHkNRiOIhgY87RM3K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4ktWW664UCFcgLQW7wK2u9cYqHA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.begin(); iter != sbt_4ktWW664UCFcgLQW7wK2u9cYqHA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.begin(); iter != sbt_ZkiD19ZB5G5SOEyZfD2FiKG9vRbistDvhplb16OSQi5sSPWVGE10BNDxsAExMdD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_5rRzQb7z3", sbt_5rRzQb7z3.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR", (CX::Int64)sbt_ZOLJ0oC9D0Oh_b2uGuPFLTVXVgytUjmGpY0Mf_kvcYorQmmwUIyKmtyMR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dCtj0uvST")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_dCtj0uvST.begin(); iter != sbt_dCtj0uvST.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_S.begin(); iter != sbt_S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.begin(); iter != sbt_tQ5QEQ8ULR_tKtTwwWjJdyCVDufZ_UVi4C0lJGuUT90MkxjClvk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_E0G2d4m", (CX::Int64)sbt_E0G2d4m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.begin(); iter != sbt_E1G0PG7VVK7lAFxLVq2fCuzRrWP1uoP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4wdOUQx_xj8HiQR", (CX::Int64)sbt_4wdOUQx_xj8HiQR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DoHzgfwFVRTzG62WYstXs", (CX::Int64)sbt_DoHzgfwFVRTzG62WYstXs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GQoTbzNla4oWEebxA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_GQoTbzNla4oWEebxA.begin(); iter != sbt_GQoTbzNla4oWEebxA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ECwweOgjD77AL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_ECwweOgjD77AL.begin(); iter != sbt_ECwweOgjD77AL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.begin(); iter != sbt_cChc30xmtZ9LkWBBEaBcpGQJ3kVlzSGSV_pSKTINZQc5vTjfZOjNr21rWzq9KPV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV", (CX::Double)sbt_AN8gYWkb3S2UXuAtmQeJvjKq6aEoSyjL8Tyuz_OaqfetV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_plG3Ns5Ot1M9pEFQLmzEpVEye")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.begin(); iter != sbt_plG3Ns5Ot1M9pEFQLmzEpVEye.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.begin(); iter != sbt_Xd24lGm5pVKJ1QlpDuWgb2iJRG1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__5La3YQqmNtsWg9_E")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt__5La3YQqmNtsWg9_E.begin(); iter != sbt__5La3YQqmNtsWg9_E.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Rbl4khX4_1XWPZvE9iihx7e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Rbl4khX4_1XWPZvE9iihx7e.begin(); iter != sbt_Rbl4khX4_1XWPZvE9iihx7e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA", (CX::Int64)sbt_1bQRJiD3MSiqEQAT3b_nNInikZZzI50pA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Myg", (CX::Int64)sbt_Myg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JPiYQJAhGcY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_JPiYQJAhGcY.begin(); iter != sbt_JPiYQJAhGcY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_0Agy3iEZDPYvXerfqJ24i_kHaPUIumDax.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS>::Type sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VSArray;

