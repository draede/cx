
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_1bKpClsxiQ4rCkQUESEfPgg;
	CX::IO::SimpleBuffers::UInt16Array sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P;
	CX::Int64 sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2;
	CX::UInt8 sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5;
	CX::Bool sbt_HkQYec3Lk;
	CX::IO::SimpleBuffers::Int32Array sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv;
	CX::IO::SimpleBuffers::Int32Array sbt_GvD;
	CX::IO::SimpleBuffers::UInt32Array sbt_k9bb_4CiidZb2tN4IRE;
	CX::IO::SimpleBuffers::UInt32Array sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh;
	CX::IO::SimpleBuffers::Int32Array sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6;
	CX::IO::SimpleBuffers::Int64Array sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6;
	CX::UInt8 sbt_tywyTheEVCHMAD2PG9DvP5Eeo;
	CX::IO::SimpleBuffers::UInt8Array sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6;
	CX::IO::SimpleBuffers::BoolArray sbt_WH1coxms87MGp3KneABlSSqEcokceEo;
	CX::UInt8 sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb;
	CX::UInt32 sbt_EGm;
	CX::IO::SimpleBuffers::StringArray sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn;
	CX::Int32 sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk;
	CX::IO::SimpleBuffers::Int16Array sbt_Wq2xrvgLlKk;
	CX::IO::SimpleBuffers::UInt64Array sbt_l2NGuRpzqm6G_ot;
	CX::IO::SimpleBuffers::StringArray sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG;

	virtual void Reset()
	{
		sbt_1bKpClsxiQ4rCkQUESEfPgg.clear();
		sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.clear();
		sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2 = 0;
		sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5 = 0;
		sbt_HkQYec3Lk = false;
		sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.clear();
		sbt_GvD.clear();
		sbt_k9bb_4CiidZb2tN4IRE.clear();
		sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.clear();
		sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.clear();
		sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.clear();
		sbt_tywyTheEVCHMAD2PG9DvP5Eeo = 0;
		sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.clear();
		sbt_WH1coxms87MGp3KneABlSSqEcokceEo.clear();
		sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb = 0;
		sbt_EGm = 0;
		sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.clear();
		sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk = 0;
		sbt_Wq2xrvgLlKk.clear();
		sbt_l2NGuRpzqm6G_ot.clear();
		sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_1bKpClsxiQ4rCkQUESEfPgg.push_back(1475920444);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.push_back(59351);
		}
		sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2 = -5178681065278696902;
		sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5 = 91;
		sbt_HkQYec3Lk = false;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.push_back(-621426895);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_GvD.push_back(-97412805);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_k9bb_4CiidZb2tN4IRE.push_back(3634470376);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.push_back(1029240212);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.push_back(-545547308);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.push_back(-1400324541901883586);
		}
		sbt_tywyTheEVCHMAD2PG9DvP5Eeo = 50;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.push_back(68);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_WH1coxms87MGp3KneABlSSqEcokceEo.push_back(false);
		}
		sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb = 152;
		sbt_EGm = 3916493249;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.push_back("Az_B@%z>ccU,z=~xjPrZ.\"aKx2pv#&4\\43\\y!bs6?=|LKfJZ&i'SUcdyyh");
		}
		sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk = 502889648;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Wq2xrvgLlKk.push_back(-22653);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_l2NGuRpzqm6G_ot.push_back(3408120882784792510);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.push_back("8E=T0-4|G&/z|tupcrtuVx3m:6BK)N@zIs$q5*,c\"oN\"T5i<_X");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK *pObject = dynamic_cast<const sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_1bKpClsxiQ4rCkQUESEfPgg.size() != pObject->sbt_1bKpClsxiQ4rCkQUESEfPgg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1bKpClsxiQ4rCkQUESEfPgg.size(); i++)
		{
			if (sbt_1bKpClsxiQ4rCkQUESEfPgg[i] != pObject->sbt_1bKpClsxiQ4rCkQUESEfPgg[i])
			{
				return false;
			}
		}
		if (sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.size() != pObject->sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.size(); i++)
		{
			if (sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P[i] != pObject->sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P[i])
			{
				return false;
			}
		}
		if (sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2 != pObject->sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2)
		{
			return false;
		}
		if (sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5 != pObject->sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5)
		{
			return false;
		}
		if (sbt_HkQYec3Lk != pObject->sbt_HkQYec3Lk)
		{
			return false;
		}
		if (sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.size() != pObject->sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.size(); i++)
		{
			if (sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv[i] != pObject->sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv[i])
			{
				return false;
			}
		}
		if (sbt_GvD.size() != pObject->sbt_GvD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GvD.size(); i++)
		{
			if (sbt_GvD[i] != pObject->sbt_GvD[i])
			{
				return false;
			}
		}
		if (sbt_k9bb_4CiidZb2tN4IRE.size() != pObject->sbt_k9bb_4CiidZb2tN4IRE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k9bb_4CiidZb2tN4IRE.size(); i++)
		{
			if (sbt_k9bb_4CiidZb2tN4IRE[i] != pObject->sbt_k9bb_4CiidZb2tN4IRE[i])
			{
				return false;
			}
		}
		if (sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.size() != pObject->sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.size(); i++)
		{
			if (sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh[i] != pObject->sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh[i])
			{
				return false;
			}
		}
		if (sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.size() != pObject->sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.size(); i++)
		{
			if (sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6[i] != pObject->sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6[i])
			{
				return false;
			}
		}
		if (sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.size() != pObject->sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.size(); i++)
		{
			if (sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6[i] != pObject->sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6[i])
			{
				return false;
			}
		}
		if (sbt_tywyTheEVCHMAD2PG9DvP5Eeo != pObject->sbt_tywyTheEVCHMAD2PG9DvP5Eeo)
		{
			return false;
		}
		if (sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.size() != pObject->sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.size(); i++)
		{
			if (sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6[i] != pObject->sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6[i])
			{
				return false;
			}
		}
		if (sbt_WH1coxms87MGp3KneABlSSqEcokceEo.size() != pObject->sbt_WH1coxms87MGp3KneABlSSqEcokceEo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WH1coxms87MGp3KneABlSSqEcokceEo.size(); i++)
		{
			if (sbt_WH1coxms87MGp3KneABlSSqEcokceEo[i] != pObject->sbt_WH1coxms87MGp3KneABlSSqEcokceEo[i])
			{
				return false;
			}
		}
		if (sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb != pObject->sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb)
		{
			return false;
		}
		if (sbt_EGm != pObject->sbt_EGm)
		{
			return false;
		}
		if (sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.size() != pObject->sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.size(); i++)
		{
			if (0 != cx_strcmp(sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn[i].c_str(), pObject->sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk != pObject->sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk)
		{
			return false;
		}
		if (sbt_Wq2xrvgLlKk.size() != pObject->sbt_Wq2xrvgLlKk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wq2xrvgLlKk.size(); i++)
		{
			if (sbt_Wq2xrvgLlKk[i] != pObject->sbt_Wq2xrvgLlKk[i])
			{
				return false;
			}
		}
		if (sbt_l2NGuRpzqm6G_ot.size() != pObject->sbt_l2NGuRpzqm6G_ot.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l2NGuRpzqm6G_ot.size(); i++)
		{
			if (sbt_l2NGuRpzqm6G_ot[i] != pObject->sbt_l2NGuRpzqm6G_ot[i])
			{
				return false;
			}
		}
		if (sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.size() != pObject->sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.size(); i++)
		{
			if (0 != cx_strcmp(sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG[i].c_str(), pObject->sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_1bKpClsxiQ4rCkQUESEfPgg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1bKpClsxiQ4rCkQUESEfPgg.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2 = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_HkQYec3Lk", &sbt_HkQYec3Lk)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GvD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GvD.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_k9bb_4CiidZb2tN4IRE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k9bb_4CiidZb2tN4IRE.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tywyTheEVCHMAD2PG9DvP5Eeo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tywyTheEVCHMAD2PG9DvP5Eeo = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WH1coxms87MGp3KneABlSSqEcokceEo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WH1coxms87MGp3KneABlSSqEcokceEo.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EGm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EGm = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Wq2xrvgLlKk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wq2xrvgLlKk.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_l2NGuRpzqm6G_ot")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l2NGuRpzqm6G_ot.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_1bKpClsxiQ4rCkQUESEfPgg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_1bKpClsxiQ4rCkQUESEfPgg.begin(); iter != sbt_1bKpClsxiQ4rCkQUESEfPgg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.begin(); iter != sbt_bAKbRhQsEpafz3J2crpizLz6KPckJkLcoA1o1eLuxv2unhGrOeNigSBUQ1P.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2", (CX::Int64)sbt_9iA8SiF_yLfOxwptHlwaN30QVgq7erEoMCJD0ejZ_pWchZfO2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5", (CX::Int64)sbt_dyrtAOALf28apNyfg2qPHFNyYnLCEk5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_HkQYec3Lk", sbt_HkQYec3Lk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.begin(); iter != sbt_xgKcakMf48v0NHyVqqWw79NuBhirY5gbMnQBBIjBZJThlcl4hvr9feFFyXv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GvD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_GvD.begin(); iter != sbt_GvD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k9bb_4CiidZb2tN4IRE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_k9bb_4CiidZb2tN4IRE.begin(); iter != sbt_k9bb_4CiidZb2tN4IRE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.begin(); iter != sbt__Nc5xWNeJzy5MTwnv7VAoFghB2hbqryjFHOReC6CIiFGfN71cNubs4q4Qu6Fh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.begin(); iter != sbt_Aze8x64cs4A2L7vxcZJNOemNfOXDVZRsLon4khiDaq2pte4eeIIe79rwuF6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.begin(); iter != sbt_mhZGOSNWbgLCQ5fMGn_ARB5M6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tywyTheEVCHMAD2PG9DvP5Eeo", (CX::Int64)sbt_tywyTheEVCHMAD2PG9DvP5Eeo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.begin(); iter != sbt_DIfg4IHbIOc69fE9DDBAgX8w9rFiGE6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WH1coxms87MGp3KneABlSSqEcokceEo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_WH1coxms87MGp3KneABlSSqEcokceEo.begin(); iter != sbt_WH1coxms87MGp3KneABlSSqEcokceEo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb", (CX::Int64)sbt_WtC6FKqft4rR9OqHpbrJ5i5oYAXdSIujb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EGm", (CX::Int64)sbt_EGm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.begin(); iter != sbt_AqROACd34WbesZJk7BqPo9IXyVM3Gm41_ksIbhMNn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk", (CX::Int64)sbt_ZcsYia3B79P4cp8jFJKQ_1A2uUISvkhAJs75NjJpF2fQI_5QZyonkhk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wq2xrvgLlKk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Wq2xrvgLlKk.begin(); iter != sbt_Wq2xrvgLlKk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l2NGuRpzqm6G_ot")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_l2NGuRpzqm6G_ot.begin(); iter != sbt_l2NGuRpzqm6G_ot.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.begin(); iter != sbt_U1FKhpTmFnnJdq5rR3s2DDzPDCHUOZnfdYFfpNYrtcsKAEpHxVx00WCWMA1lG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK>::Type sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTKArray;

