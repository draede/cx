
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_6St.hpp"


class sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_V_u2wLO;
	CX::Int8 sbt_yx4GQICSGIYox4kYAHAj98Nrzy9;
	CX::IO::SimpleBuffers::StringArray sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC;
	CX::IO::SimpleBuffers::BoolArray sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2;
	CX::WString sbt_SdTxtsSlZnSpgrZHK4Az9gRJs;
	CX::IO::SimpleBuffers::StringArray sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS;
	CX::IO::SimpleBuffers::BoolArray sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU;
	sbt_6StArray sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p;

	virtual void Reset()
	{
		sbt_V_u2wLO = 0;
		sbt_yx4GQICSGIYox4kYAHAj98Nrzy9 = 0;
		sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.clear();
		sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.clear();
		sbt_SdTxtsSlZnSpgrZHK4Az9gRJs.clear();
		sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.clear();
		sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.clear();
		sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_V_u2wLO = 45963;
		sbt_yx4GQICSGIYox4kYAHAj98Nrzy9 = -88;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.push_back("TS86;o\\");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.push_back(true);
		}
		sbt_SdTxtsSlZnSpgrZHK4Az9gRJs = L"ZIrk\\Z>~=.KqWhd0`NA~I8uLpXL'|c1ozbY1JU':+dHA\"(NmTL?kxO};";
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.push_back("[nJmCxUMf=r0]Ik^-");
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_6St v;

			v.SetupWithSomeValues();
			sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH *pObject = dynamic_cast<const sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_V_u2wLO != pObject->sbt_V_u2wLO)
		{
			return false;
		}
		if (sbt_yx4GQICSGIYox4kYAHAj98Nrzy9 != pObject->sbt_yx4GQICSGIYox4kYAHAj98Nrzy9)
		{
			return false;
		}
		if (sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.size() != pObject->sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.size(); i++)
		{
			if (0 != cx_strcmp(sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC[i].c_str(), pObject->sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.size() != pObject->sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.size(); i++)
		{
			if (sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2[i] != pObject->sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_SdTxtsSlZnSpgrZHK4Az9gRJs.c_str(), pObject->sbt_SdTxtsSlZnSpgrZHK4Az9gRJs.c_str()))
		{
			return false;
		}
		if (sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.size() != pObject->sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS[i].c_str(), pObject->sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.size() != pObject->sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.size(); i++)
		{
			if (sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU[i] != pObject->sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU[i])
			{
				return false;
			}
		}
		if (sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.size() != pObject->sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.size(); i++)
		{
			if (!sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p[i].Compare(&pObject->sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_V_u2wLO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_V_u2wLO = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_yx4GQICSGIYox4kYAHAj98Nrzy9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yx4GQICSGIYox4kYAHAj98Nrzy9 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_SdTxtsSlZnSpgrZHK4Az9gRJs", &sbt_SdTxtsSlZnSpgrZHK4Az9gRJs)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_6St tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_V_u2wLO", (CX::Int64)sbt_V_u2wLO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yx4GQICSGIYox4kYAHAj98Nrzy9", (CX::Int64)sbt_yx4GQICSGIYox4kYAHAj98Nrzy9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.begin(); iter != sbt_7CbP9hPC6dArMTQSziYl5ZcFjzJ8gKW_27NXC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.begin(); iter != sbt_oonBAaq5qUHb9XijIQ_etiOTz75bhil17Ikt3dIxAdtWhkanGvve_PtbIG2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_SdTxtsSlZnSpgrZHK4Az9gRJs", sbt_SdTxtsSlZnSpgrZHK4Az9gRJs.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.begin(); iter != sbt_Ojv6V7tymad0NLBSHT3wsafZMsA6YgJZP8ZC_XS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.begin(); iter != sbt_RYxX4wozuM8KNBUCYfO1oaCmk2nDOPGv4K1cibZZlkU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p")).IsNOK())
		{
			return status;
		}
		for (sbt_6StArray::const_iterator iter = sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.begin(); iter != sbt_81wBEacMMsP5gbr9cLkJXlc2brxMvaVQX4p.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH>::Type sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyHArray;

