
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_1JenunJxgM3mB2IZN5RnJol.hpp"


class sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW;
	CX::IO::SimpleBuffers::UInt32Array sbt_HMpFCAUcg;
	CX::UInt8 sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw;
	CX::Int64 sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB;
	CX::WString sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg;
	CX::Int32 sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z;
	CX::IO::SimpleBuffers::Int16Array sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn;
	CX::IO::SimpleBuffers::UInt16Array sbt_LcOVSXoseDMNrj6farMCr35;
	CX::IO::SimpleBuffers::Int8Array sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m;
	CX::Int32 sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe;
	CX::WString sbt_u5lZ_atpuxHaFv_NDKsJ42u3O;
	CX::IO::SimpleBuffers::Int64Array sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl;
	CX::Bool sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT;
	CX::IO::SimpleBuffers::Int16Array sbt_Oxuz5erTRRBPN7YuLD32w;
	CX::IO::SimpleBuffers::Int64Array sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa;
	CX::WString sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM;
	CX::IO::SimpleBuffers::WStringArray sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T;
	CX::IO::SimpleBuffers::BoolArray sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N;
	CX::IO::SimpleBuffers::StringArray sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D;
	CX::IO::SimpleBuffers::BoolArray sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD;
	CX::Bool sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP;
	CX::IO::SimpleBuffers::FloatArray sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc;
	CX::Int64 sbt_vNEYP;
	CX::UInt16 sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8;
	CX::String sbt_ot4Ef20_9L7fBQN;
	CX::Double sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG;
	CX::IO::SimpleBuffers::UInt64Array sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L;
	sbt_1JenunJxgM3mB2IZN5RnJol sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7;

	virtual void Reset()
	{
		sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW = 0;
		sbt_HMpFCAUcg.clear();
		sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw = 0;
		sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB = 0;
		sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg.clear();
		sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z = 0;
		sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.clear();
		sbt_LcOVSXoseDMNrj6farMCr35.clear();
		sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.clear();
		sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe = 0;
		sbt_u5lZ_atpuxHaFv_NDKsJ42u3O.clear();
		sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.clear();
		sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT = false;
		sbt_Oxuz5erTRRBPN7YuLD32w.clear();
		sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.clear();
		sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM.clear();
		sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.clear();
		sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.clear();
		sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.clear();
		sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.clear();
		sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP = false;
		sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.clear();
		sbt_vNEYP = 0;
		sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8 = 0;
		sbt_ot4Ef20_9L7fBQN.clear();
		sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG = 0.0;
		sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.clear();
		sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW = -30280;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_HMpFCAUcg.push_back(4221504907);
		}
		sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw = 251;
		sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB = -1569207301659448432;
		sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg = L"-w%7R!LZ4&`laVC1x6Y|U\"0.~rgbOeA{l";
		sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z = -416991891;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_LcOVSXoseDMNrj6farMCr35.push_back(55555);
		}
		sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe = 1597970690;
		sbt_u5lZ_atpuxHaFv_NDKsJ42u3O = L"~l[\"";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.push_back(-5608334426007650612);
		}
		sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT = false;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_Oxuz5erTRRBPN7YuLD32w.push_back(6380);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.push_back(-4075681336951792356);
		}
		sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM = L"]0|WOU$?x]C0+`SI#T{|1[Zi:`)m*_2nW!4v_}WJ327YOk&cgR[eKHuF[]AP]YP";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.push_back(L":{Gri|#gn@JWInS$7]VW0i`{2wMHV-+XZ/`S2AU'zSn+j@ja");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.push_back("I?UPNr&H8'8cN6.");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.push_back(false);
		}
		sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP = false;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.push_back(0.254882f);
		}
		sbt_vNEYP = -6639964606726163394;
		sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8 = 21970;
		sbt_ot4Ef20_9L7fBQN = "AOgBhue<;/a#AD2-SiwRGY\\<j;g1_'ILg~.dP)P1T";
		sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG = 0.303157;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.push_back(96515934963278982);
		}
		sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz *pObject = dynamic_cast<const sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW != pObject->sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW)
		{
			return false;
		}
		if (sbt_HMpFCAUcg.size() != pObject->sbt_HMpFCAUcg.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HMpFCAUcg.size(); i++)
		{
			if (sbt_HMpFCAUcg[i] != pObject->sbt_HMpFCAUcg[i])
			{
				return false;
			}
		}
		if (sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw != pObject->sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw)
		{
			return false;
		}
		if (sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB != pObject->sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg.c_str(), pObject->sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg.c_str()))
		{
			return false;
		}
		if (sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z != pObject->sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z)
		{
			return false;
		}
		if (sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.size() != pObject->sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.size(); i++)
		{
			if (sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn[i] != pObject->sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn[i])
			{
				return false;
			}
		}
		if (sbt_LcOVSXoseDMNrj6farMCr35.size() != pObject->sbt_LcOVSXoseDMNrj6farMCr35.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LcOVSXoseDMNrj6farMCr35.size(); i++)
		{
			if (sbt_LcOVSXoseDMNrj6farMCr35[i] != pObject->sbt_LcOVSXoseDMNrj6farMCr35[i])
			{
				return false;
			}
		}
		if (sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.size() != pObject->sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.size(); i++)
		{
			if (sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m[i] != pObject->sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m[i])
			{
				return false;
			}
		}
		if (sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe != pObject->sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_u5lZ_atpuxHaFv_NDKsJ42u3O.c_str(), pObject->sbt_u5lZ_atpuxHaFv_NDKsJ42u3O.c_str()))
		{
			return false;
		}
		if (sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.size() != pObject->sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.size(); i++)
		{
			if (sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl[i] != pObject->sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl[i])
			{
				return false;
			}
		}
		if (sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT != pObject->sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT)
		{
			return false;
		}
		if (sbt_Oxuz5erTRRBPN7YuLD32w.size() != pObject->sbt_Oxuz5erTRRBPN7YuLD32w.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Oxuz5erTRRBPN7YuLD32w.size(); i++)
		{
			if (sbt_Oxuz5erTRRBPN7YuLD32w[i] != pObject->sbt_Oxuz5erTRRBPN7YuLD32w[i])
			{
				return false;
			}
		}
		if (sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.size() != pObject->sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.size(); i++)
		{
			if (sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa[i] != pObject->sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM.c_str(), pObject->sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM.c_str()))
		{
			return false;
		}
		if (sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.size() != pObject->sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T[i].c_str(), pObject->sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.size() != pObject->sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.size(); i++)
		{
			if (sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N[i] != pObject->sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N[i])
			{
				return false;
			}
		}
		if (sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.size() != pObject->sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.size(); i++)
		{
			if (0 != cx_strcmp(sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D[i].c_str(), pObject->sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.size() != pObject->sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.size(); i++)
		{
			if (sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD[i] != pObject->sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD[i])
			{
				return false;
			}
		}
		if (sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP != pObject->sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP)
		{
			return false;
		}
		if (sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.size() != pObject->sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.size(); i++)
		{
			if (sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc[i] != pObject->sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc[i])
			{
				return false;
			}
		}
		if (sbt_vNEYP != pObject->sbt_vNEYP)
		{
			return false;
		}
		if (sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8 != pObject->sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_ot4Ef20_9L7fBQN.c_str(), pObject->sbt_ot4Ef20_9L7fBQN.c_str()))
		{
			return false;
		}
		if (sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG != pObject->sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG)
		{
			return false;
		}
		if (sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.size() != pObject->sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.size(); i++)
		{
			if (sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L[i] != pObject->sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L[i])
			{
				return false;
			}
		}
		if (!sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7.Compare(&pObject->sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HMpFCAUcg")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HMpFCAUcg.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg", &sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LcOVSXoseDMNrj6farMCr35")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LcOVSXoseDMNrj6farMCr35.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectWString("sbt_u5lZ_atpuxHaFv_NDKsJ42u3O", &sbt_u5lZ_atpuxHaFv_NDKsJ42u3O)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT", &sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Oxuz5erTRRBPN7YuLD32w")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Oxuz5erTRRBPN7YuLD32w.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM", &sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP", &sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vNEYP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vNEYP = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_ot4Ef20_9L7fBQN", &sbt_ot4Ef20_9L7fBQN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW", (CX::Int64)sbt_gpKgJqiGjAbK1JkBZW2DQKrBEJlDms9Gb7pxXWtjHyAMzN8WzQqgrRW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HMpFCAUcg")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_HMpFCAUcg.begin(); iter != sbt_HMpFCAUcg.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw", (CX::Int64)sbt_tjcgO9daH0L2rB2gxNBh0GxQHkfHHKz2DcINew7T0stTw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB", (CX::Int64)sbt_tGG4Pu0mjphWqV62JS86gwDZN0ncxx8nxpX90nB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg", sbt_igaeV9LfDssmDQa8162shVKSsxTOyhKnze8KRctQsAmYg.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z", (CX::Int64)sbt_n5ZGY7HtTkK3dz3sopr6jIkK8aUkJGcnf0emewaKm2RAcym0zbCOeUtqnLQDT4Z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.begin(); iter != sbt_7STv8dA3XG_ZANsD4tyEcaoL_epVpUgpqG4Pn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LcOVSXoseDMNrj6farMCr35")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_LcOVSXoseDMNrj6farMCr35.begin(); iter != sbt_LcOVSXoseDMNrj6farMCr35.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.begin(); iter != sbt_awU1En4FXvgfPBI3N6cmSIJ9dgZVtOAU0iB9m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe", (CX::Int64)sbt_rdmooaGGzic20hOCb_0RGAWjNQbPW5oPe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_u5lZ_atpuxHaFv_NDKsJ42u3O", sbt_u5lZ_atpuxHaFv_NDKsJ42u3O.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.begin(); iter != sbt_eb1zHfKJfvus9dSdGwLpEyTjTN_e_QbNAKsBQHwjdfBpDHD_3T4MAJl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT", sbt_5M4yPBYJnSkvJaBVO_IhDNycV5MBiRGNa36kNUSXT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Oxuz5erTRRBPN7YuLD32w")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Oxuz5erTRRBPN7YuLD32w.begin(); iter != sbt_Oxuz5erTRRBPN7YuLD32w.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.begin(); iter != sbt_6NXK8pnADuw_YBHNu1GfbjknY1PMT2ZIRdF79unWKyKvtHOGLEbDa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM", sbt_YYI43P4VlRzpV8t7oUKj7CKq8N21Gsqu2Vll2vKnoSsKSK9y2CRf26giM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.begin(); iter != sbt_9dg8WyGrxYComEa1kcqQt53Hy9QjGM0lN7T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.begin(); iter != sbt_0dHcqUfPvuQrzPMWAg5X2fiwzYsWaWmmhutb0Vf1N.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.begin(); iter != sbt_HF81sEIwdUHVvns83NSjvTVzyqtiQiP7D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.begin(); iter != sbt_NR3451EyLYEo3pUcQyYtQyAgh3oSLciKmaGDTm7KHeaiD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP", sbt_jLEAvNKYxXN9J1p7HOxq4fbVU9rtyfYW1Kn3W9y3dXTfP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.begin(); iter != sbt_SR5DHE7eJBQqeiL5kNGDjyRcdqc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vNEYP", (CX::Int64)sbt_vNEYP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8", (CX::Int64)sbt_ZQ1UWeFW2OT7npzO0VgJ5HLDahsyauOn5SRmXvxI4k8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ot4Ef20_9L7fBQN", sbt_ot4Ef20_9L7fBQN.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG", (CX::Double)sbt_2cpX4WkdTjACUkWc8q6z2BrQNCOqQTW7jsIkIoDJRjzyG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.begin(); iter != sbt_oEvKE7YP3JSBuhzkuZqOS2wcyC1jW04ofKzNS7I3L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_XuGGV1_RNPH8E1ggdI8DdD26nyq6XnJZca7.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz>::Type sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSzArray;

