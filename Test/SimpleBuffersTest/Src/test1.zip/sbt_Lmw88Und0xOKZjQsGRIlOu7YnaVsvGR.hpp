
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_9h59uZ7jl8JjupNu2P9;
	CX::UInt32 sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24;
	CX::String sbt_y9ScuYzxQ1X7lHXJ8Owq_jN;
	CX::UInt32 sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu;
	CX::UInt64 sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk;
	CX::IO::SimpleBuffers::BoolArray sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ;
	CX::IO::SimpleBuffers::Int16Array sbt_bcFuCBGAAV3OwJ7If;
	CX::Bool sbt_OIoqTS9OuQxnVg5AolF;
	CX::IO::SimpleBuffers::UInt32Array sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze;
	CX::Bool sbt_aTVYxYJxJp4em7D2e1XPuDx;
	CX::Int32 sbt_o71zebbzESEe8BsGX;
	CX::UInt16 sbt_NmUg4xxX1eGYCcI6XbY;
	CX::UInt8 sbt_6Ib;
	CX::Bool sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl;
	CX::UInt8 sbt_w3aB5hgUa;
	CX::IO::SimpleBuffers::UInt8Array sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi;
	CX::Int8 sbt_DSMAruwvV6i4f;
	CX::UInt32 sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p;
	CX::IO::SimpleBuffers::StringArray sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2;
	CX::IO::SimpleBuffers::StringArray sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6;
	CX::IO::SimpleBuffers::UInt16Array sbt_mvtUtUWB1GSVNGVkJI66QQp;
	CX::IO::SimpleBuffers::Int32Array sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc;
	CX::IO::SimpleBuffers::UInt16Array sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK;
	CX::IO::SimpleBuffers::Int16Array sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT;
	CX::String sbt_hdu5671LvO7VKvAcqQq3Rj_ao;
	CX::UInt8 sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD;

	virtual void Reset()
	{
		sbt_9h59uZ7jl8JjupNu2P9 = 0;
		sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24 = 0;
		sbt_y9ScuYzxQ1X7lHXJ8Owq_jN.clear();
		sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu = 0;
		sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk = 0;
		sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.clear();
		sbt_bcFuCBGAAV3OwJ7If.clear();
		sbt_OIoqTS9OuQxnVg5AolF = false;
		sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.clear();
		sbt_aTVYxYJxJp4em7D2e1XPuDx = false;
		sbt_o71zebbzESEe8BsGX = 0;
		sbt_NmUg4xxX1eGYCcI6XbY = 0;
		sbt_6Ib = 0;
		sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl = false;
		sbt_w3aB5hgUa = 0;
		sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.clear();
		sbt_DSMAruwvV6i4f = 0;
		sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p = 0;
		sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.clear();
		sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.clear();
		sbt_mvtUtUWB1GSVNGVkJI66QQp.clear();
		sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.clear();
		sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.clear();
		sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.clear();
		sbt_hdu5671LvO7VKvAcqQq3Rj_ao.clear();
		sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_9h59uZ7jl8JjupNu2P9 = -24712;
		sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24 = 3357860869;
		sbt_y9ScuYzxQ1X7lHXJ8Owq_jN = "inQ.C9LD}:<GbSS_^05bsm()";
		sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu = 3871016961;
		sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk = 8200918924335456054;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.push_back(true);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_bcFuCBGAAV3OwJ7If.push_back(-27669);
		}
		sbt_OIoqTS9OuQxnVg5AolF = false;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.push_back(774640156);
		}
		sbt_aTVYxYJxJp4em7D2e1XPuDx = false;
		sbt_o71zebbzESEe8BsGX = 204754631;
		sbt_NmUg4xxX1eGYCcI6XbY = 10308;
		sbt_6Ib = 106;
		sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl = false;
		sbt_w3aB5hgUa = 254;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.push_back(151);
		}
		sbt_DSMAruwvV6i4f = -98;
		sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p = 3277653313;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.push_back("a*t+Gk3[5-P3+T|Jwz(n.A9U<reg9t");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.push_back("@z_w%wr#Ts7K%)`3t570]Te");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_mvtUtUWB1GSVNGVkJI66QQp.push_back(25387);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.push_back(-109104507);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.push_back(62381);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.push_back(-8005);
		}
		sbt_hdu5671LvO7VKvAcqQq3Rj_ao = "ia28s|S3qk;l)e1Ypu@bGcL+ThV]A\\B-&@*|mOUDKWSp6Jj";
		sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD = 82;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR *pObject = dynamic_cast<const sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9h59uZ7jl8JjupNu2P9 != pObject->sbt_9h59uZ7jl8JjupNu2P9)
		{
			return false;
		}
		if (sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24 != pObject->sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_y9ScuYzxQ1X7lHXJ8Owq_jN.c_str(), pObject->sbt_y9ScuYzxQ1X7lHXJ8Owq_jN.c_str()))
		{
			return false;
		}
		if (sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu != pObject->sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu)
		{
			return false;
		}
		if (sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk != pObject->sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk)
		{
			return false;
		}
		if (sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.size() != pObject->sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.size(); i++)
		{
			if (sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ[i] != pObject->sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ[i])
			{
				return false;
			}
		}
		if (sbt_bcFuCBGAAV3OwJ7If.size() != pObject->sbt_bcFuCBGAAV3OwJ7If.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bcFuCBGAAV3OwJ7If.size(); i++)
		{
			if (sbt_bcFuCBGAAV3OwJ7If[i] != pObject->sbt_bcFuCBGAAV3OwJ7If[i])
			{
				return false;
			}
		}
		if (sbt_OIoqTS9OuQxnVg5AolF != pObject->sbt_OIoqTS9OuQxnVg5AolF)
		{
			return false;
		}
		if (sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.size() != pObject->sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.size(); i++)
		{
			if (sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze[i] != pObject->sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze[i])
			{
				return false;
			}
		}
		if (sbt_aTVYxYJxJp4em7D2e1XPuDx != pObject->sbt_aTVYxYJxJp4em7D2e1XPuDx)
		{
			return false;
		}
		if (sbt_o71zebbzESEe8BsGX != pObject->sbt_o71zebbzESEe8BsGX)
		{
			return false;
		}
		if (sbt_NmUg4xxX1eGYCcI6XbY != pObject->sbt_NmUg4xxX1eGYCcI6XbY)
		{
			return false;
		}
		if (sbt_6Ib != pObject->sbt_6Ib)
		{
			return false;
		}
		if (sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl != pObject->sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl)
		{
			return false;
		}
		if (sbt_w3aB5hgUa != pObject->sbt_w3aB5hgUa)
		{
			return false;
		}
		if (sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.size() != pObject->sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.size(); i++)
		{
			if (sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi[i] != pObject->sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi[i])
			{
				return false;
			}
		}
		if (sbt_DSMAruwvV6i4f != pObject->sbt_DSMAruwvV6i4f)
		{
			return false;
		}
		if (sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p != pObject->sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p)
		{
			return false;
		}
		if (sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.size() != pObject->sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.size(); i++)
		{
			if (0 != cx_strcmp(sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2[i].c_str(), pObject->sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.size() != pObject->sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.size(); i++)
		{
			if (0 != cx_strcmp(sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6[i].c_str(), pObject->sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_mvtUtUWB1GSVNGVkJI66QQp.size() != pObject->sbt_mvtUtUWB1GSVNGVkJI66QQp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mvtUtUWB1GSVNGVkJI66QQp.size(); i++)
		{
			if (sbt_mvtUtUWB1GSVNGVkJI66QQp[i] != pObject->sbt_mvtUtUWB1GSVNGVkJI66QQp[i])
			{
				return false;
			}
		}
		if (sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.size() != pObject->sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.size(); i++)
		{
			if (sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc[i] != pObject->sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc[i])
			{
				return false;
			}
		}
		if (sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.size() != pObject->sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.size(); i++)
		{
			if (sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK[i] != pObject->sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK[i])
			{
				return false;
			}
		}
		if (sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.size() != pObject->sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.size(); i++)
		{
			if (sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT[i] != pObject->sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_hdu5671LvO7VKvAcqQq3Rj_ao.c_str(), pObject->sbt_hdu5671LvO7VKvAcqQq3Rj_ao.c_str()))
		{
			return false;
		}
		if (sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD != pObject->sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_9h59uZ7jl8JjupNu2P9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9h59uZ7jl8JjupNu2P9 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_y9ScuYzxQ1X7lHXJ8Owq_jN", &sbt_y9ScuYzxQ1X7lHXJ8Owq_jN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bcFuCBGAAV3OwJ7If")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bcFuCBGAAV3OwJ7If.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_OIoqTS9OuQxnVg5AolF", &sbt_OIoqTS9OuQxnVg5AolF)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_aTVYxYJxJp4em7D2e1XPuDx", &sbt_aTVYxYJxJp4em7D2e1XPuDx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_o71zebbzESEe8BsGX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_o71zebbzESEe8BsGX = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_NmUg4xxX1eGYCcI6XbY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NmUg4xxX1eGYCcI6XbY = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_6Ib", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6Ib = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl", &sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_w3aB5hgUa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_w3aB5hgUa = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_DSMAruwvV6i4f", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DSMAruwvV6i4f = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mvtUtUWB1GSVNGVkJI66QQp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mvtUtUWB1GSVNGVkJI66QQp.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_hdu5671LvO7VKvAcqQq3Rj_ao", &sbt_hdu5671LvO7VKvAcqQq3Rj_ao)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD = (CX::UInt8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_9h59uZ7jl8JjupNu2P9", (CX::Int64)sbt_9h59uZ7jl8JjupNu2P9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24", (CX::Int64)sbt_zUqs3YpGRX2c53xKaQqkqHHm_jvAoQ065oAICIS24)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_y9ScuYzxQ1X7lHXJ8Owq_jN", sbt_y9ScuYzxQ1X7lHXJ8Owq_jN.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu", (CX::Int64)sbt_jhyD9D4mHyyy76C_UuMmuRHnKo3lu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk", (CX::Int64)sbt_29ouwNqRYScWTqNQxYzdAUzeGWdEFHzWcE0yYcI9Ebx8hnqK2Pk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.begin(); iter != sbt_CgFyJNXbObLprv7DJKDggMrHnG2fjTORZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bcFuCBGAAV3OwJ7If")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_bcFuCBGAAV3OwJ7If.begin(); iter != sbt_bcFuCBGAAV3OwJ7If.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_OIoqTS9OuQxnVg5AolF", sbt_OIoqTS9OuQxnVg5AolF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.begin(); iter != sbt_7pvmHc8_KQi6_feBviFOo9568jKFrFKxhekCs8jS0z_Q3RQUaze.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_aTVYxYJxJp4em7D2e1XPuDx", sbt_aTVYxYJxJp4em7D2e1XPuDx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_o71zebbzESEe8BsGX", (CX::Int64)sbt_o71zebbzESEe8BsGX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NmUg4xxX1eGYCcI6XbY", (CX::Int64)sbt_NmUg4xxX1eGYCcI6XbY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6Ib", (CX::Int64)sbt_6Ib)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl", sbt_KtaiwkRHfncxsNmZ3LKlQWk0C6YsI9ZNLCX1n9wpVzUvrZ2dnUOb9shYJKshl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_w3aB5hgUa", (CX::Int64)sbt_w3aB5hgUa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.begin(); iter != sbt_C60qCRYARL93paj5Ma8h3LIYr8OjqFiyJdYWdBuKL4lbDOU69azDnNl2JDqW4qi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DSMAruwvV6i4f", (CX::Int64)sbt_DSMAruwvV6i4f)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p", (CX::Int64)sbt_EJICmJvfXXeqwGdoFJojpI5kIhHBf4mzbf53p)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.begin(); iter != sbt_B6hqAJda1rBtKrFdivbqfQnSW22CgcOB76hUsnDzuAKX2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.begin(); iter != sbt_GKsvIqRFDReF02H9fpHNn4Z2gEBFVKLhqb19IX6zvA0_ke9f1YK95lZLMZzcGB6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mvtUtUWB1GSVNGVkJI66QQp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_mvtUtUWB1GSVNGVkJI66QQp.begin(); iter != sbt_mvtUtUWB1GSVNGVkJI66QQp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.begin(); iter != sbt_X6R3z2Su7ospyPjYWZTMb2SokeEriTc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.begin(); iter != sbt_QT1SUJHoQB6n4QYjgpepjRz8oFdICDeI5AeI29KFGCFtmut7BRZI4Mq3VepcK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.begin(); iter != sbt_owSPoe1W9egLwXFkMqVzcq6tlLaKxIKAVy3ZtLT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_hdu5671LvO7VKvAcqQq3Rj_ao", sbt_hdu5671LvO7VKvAcqQq3Rj_ao.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD", (CX::Int64)sbt_hnF7vFMmZ_x9L2x82xQjIx1dXJw6JjwAEQXX5zwoQocFd18ULIRLsS0vSmqzPKD)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR>::Type sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGRArray;

