
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0;
	CX::IO::SimpleBuffers::UInt32Array sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO;
	CX::UInt64 sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh;
	CX::IO::SimpleBuffers::Int64Array sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp;
	CX::Int16 sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU;
	CX::UInt32 sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU;
	CX::IO::SimpleBuffers::StringArray sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk;
	CX::IO::SimpleBuffers::StringArray sbt_6azI8pO6PmNLoJCEt1Y6u;
	CX::UInt64 sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8;
	CX::Bool sbt_iRy;
	CX::IO::SimpleBuffers::UInt16Array sbt_WyU;
	CX::IO::SimpleBuffers::Int64Array sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn;
	CX::IO::SimpleBuffers::UInt8Array sbt_oz7j7eoneB0ytnwezK5QEPH4X;
	CX::IO::SimpleBuffers::Int8Array sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_;

	virtual void Reset()
	{
		sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.clear();
		sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.clear();
		sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh = 0;
		sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.clear();
		sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU = 0;
		sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU = 0;
		sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.clear();
		sbt_6azI8pO6PmNLoJCEt1Y6u.clear();
		sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8 = 0;
		sbt_iRy = false;
		sbt_WyU.clear();
		sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.clear();
		sbt_oz7j7eoneB0ytnwezK5QEPH4X.clear();
		sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.push_back(17317);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.push_back(266065089);
		}
		sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh = 6011176622214563562;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.push_back(3473066917525478598);
		}
		sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU = -1718;
		sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU = 2123592213;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.push_back(".ufL!KAOBjlUcj33bbv\\K");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_6azI8pO6PmNLoJCEt1Y6u.push_back("C93%JV*,Ml{;gU#R^6X'A|>aDBp/YQOe-!2<}y9OO<eZtjV,fK");
		}
		sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8 = 622941892304342910;
		sbt_iRy = false;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_WyU.push_back(4480);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.push_back(1688438497121575784);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_oz7j7eoneB0ytnwezK5QEPH4X.push_back(177);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.push_back(42);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB *pObject = dynamic_cast<const sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.size() != pObject->sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.size(); i++)
		{
			if (sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0[i] != pObject->sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0[i])
			{
				return false;
			}
		}
		if (sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.size() != pObject->sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.size(); i++)
		{
			if (sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO[i] != pObject->sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO[i])
			{
				return false;
			}
		}
		if (sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh != pObject->sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh)
		{
			return false;
		}
		if (sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.size() != pObject->sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.size(); i++)
		{
			if (sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp[i] != pObject->sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp[i])
			{
				return false;
			}
		}
		if (sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU != pObject->sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU)
		{
			return false;
		}
		if (sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU != pObject->sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU)
		{
			return false;
		}
		if (sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.size() != pObject->sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.size(); i++)
		{
			if (0 != cx_strcmp(sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk[i].c_str(), pObject->sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_6azI8pO6PmNLoJCEt1Y6u.size() != pObject->sbt_6azI8pO6PmNLoJCEt1Y6u.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6azI8pO6PmNLoJCEt1Y6u.size(); i++)
		{
			if (0 != cx_strcmp(sbt_6azI8pO6PmNLoJCEt1Y6u[i].c_str(), pObject->sbt_6azI8pO6PmNLoJCEt1Y6u[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8 != pObject->sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8)
		{
			return false;
		}
		if (sbt_iRy != pObject->sbt_iRy)
		{
			return false;
		}
		if (sbt_WyU.size() != pObject->sbt_WyU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WyU.size(); i++)
		{
			if (sbt_WyU[i] != pObject->sbt_WyU[i])
			{
				return false;
			}
		}
		if (sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.size() != pObject->sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.size(); i++)
		{
			if (sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn[i] != pObject->sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn[i])
			{
				return false;
			}
		}
		if (sbt_oz7j7eoneB0ytnwezK5QEPH4X.size() != pObject->sbt_oz7j7eoneB0ytnwezK5QEPH4X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oz7j7eoneB0ytnwezK5QEPH4X.size(); i++)
		{
			if (sbt_oz7j7eoneB0ytnwezK5QEPH4X[i] != pObject->sbt_oz7j7eoneB0ytnwezK5QEPH4X[i])
			{
				return false;
			}
		}
		if (sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.size() != pObject->sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.size(); i++)
		{
			if (sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_[i] != pObject->sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6azI8pO6PmNLoJCEt1Y6u")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6azI8pO6PmNLoJCEt1Y6u.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_iRy", &sbt_iRy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WyU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WyU.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oz7j7eoneB0ytnwezK5QEPH4X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oz7j7eoneB0ytnwezK5QEPH4X.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.begin(); iter != sbt_QV_NokobutvMfS0iUpoctn0tkSbn5T4htKUaXZTz0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.begin(); iter != sbt_O0YMHbHNBHbQlOsZ50S79dIbIKfcAfDCHj8nL0jbhg4yO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh", (CX::Int64)sbt_pRt6arAqUx34_muqvU0Rz7ENRKhCwo89tjTMezpSkGDGh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.begin(); iter != sbt_M8gJlxiPhb7vdTNXVBvnAjkBsn1xV80qhF3J3m7ytaqxgyVNBnldp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU", (CX::Int64)sbt_tds8hLABIJtWp5k3r0H5QmazJm6zuOGfT966DKrWkkWr08kw5YhpU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU", (CX::Int64)sbt_31X_5lbQFC3_jcHFbtKctZHnlRhdyRU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.begin(); iter != sbt_5V1ZS7xq5PJv5GAtQNyRtI2eqgyIPOlh_0Go0ClWJK6YwiOr1MKqFNobk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6azI8pO6PmNLoJCEt1Y6u")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_6azI8pO6PmNLoJCEt1Y6u.begin(); iter != sbt_6azI8pO6PmNLoJCEt1Y6u.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8", (CX::Int64)sbt_QPtlOxaQs9G2I97NNPKo4_cBYOhv9hJ8DO6Y7sug8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_iRy", sbt_iRy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WyU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_WyU.begin(); iter != sbt_WyU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.begin(); iter != sbt_STzTKGlBIc1lbnKyfsijg54iIE3mUc13I0Gw0k_LOLJj3fHEspn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oz7j7eoneB0ytnwezK5QEPH4X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_oz7j7eoneB0ytnwezK5QEPH4X.begin(); iter != sbt_oz7j7eoneB0ytnwezK5QEPH4X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.begin(); iter != sbt_VwH9QGd4j_VnedNSG39d59ANYfWxjhhtqD657UKqavytkE_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB>::Type sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdBArray;

