
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj;
	CX::Int64 sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa;
	CX::IO::SimpleBuffers::StringArray sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3;
	CX::Int32 sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ;
	CX::IO::SimpleBuffers::StringArray sbt_q9ZNws9RaQChJv5N_UVVw90OxNU;
	CX::Int64 sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz;
	CX::IO::SimpleBuffers::UInt32Array sbt_D5QHuciDFvsikR9vkj4BadoP8;

	virtual void Reset()
	{
		sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj = 0;
		sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa = 0;
		sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.clear();
		sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ = 0;
		sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.clear();
		sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz = 0;
		sbt_D5QHuciDFvsikR9vkj4BadoP8.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj = 175;
		sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa = -2862612410132248546;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.push_back("A~q(Yo9~H5{Hy@F|IauS}\"!4`#M.HKMS*1f~bCq");
		}
		sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ = -854869467;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.push_back("#fb76?LR/O\"]JDUc0~HG@C");
		}
		sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz = 7271014795870052910;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_D5QHuciDFvsikR9vkj4BadoP8.push_back(1923828136);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2 *pObject = dynamic_cast<const sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj != pObject->sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj)
		{
			return false;
		}
		if (sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa != pObject->sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa)
		{
			return false;
		}
		if (sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.size() != pObject->sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.size(); i++)
		{
			if (0 != cx_strcmp(sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3[i].c_str(), pObject->sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ != pObject->sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ)
		{
			return false;
		}
		if (sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.size() != pObject->sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.size(); i++)
		{
			if (0 != cx_strcmp(sbt_q9ZNws9RaQChJv5N_UVVw90OxNU[i].c_str(), pObject->sbt_q9ZNws9RaQChJv5N_UVVw90OxNU[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz != pObject->sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz)
		{
			return false;
		}
		if (sbt_D5QHuciDFvsikR9vkj4BadoP8.size() != pObject->sbt_D5QHuciDFvsikR9vkj4BadoP8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D5QHuciDFvsikR9vkj4BadoP8.size(); i++)
		{
			if (sbt_D5QHuciDFvsikR9vkj4BadoP8[i] != pObject->sbt_D5QHuciDFvsikR9vkj4BadoP8[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_q9ZNws9RaQChJv5N_UVVw90OxNU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_D5QHuciDFvsikR9vkj4BadoP8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D5QHuciDFvsikR9vkj4BadoP8.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj", (CX::Int64)sbt__iJKNeJ1EHkrJFqtuBQv87RQoL3cvunu2VwALrWjYOfC8KsVs1kmj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa", (CX::Int64)sbt_XvYyv3gImHS3iXYWxXE6g5BIofIhW5xjIUGbSSf_SbKyV3HRa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.begin(); iter != sbt_wne2XkhCrjTr_mCzgKCfUfsgSLggeAV7WQfF6BG1Mktwxn8L3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ", (CX::Int64)sbt_XhJ_uWZCLNsYaapuisSUzwSDt3fN6kfwe3881gznyAQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_q9ZNws9RaQChJv5N_UVVw90OxNU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.begin(); iter != sbt_q9ZNws9RaQChJv5N_UVVw90OxNU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz", (CX::Int64)sbt_1e4jV8qNuQ1Q4Tpy5Q8EFMGFDlH91Mi8_G3ST_e5HaguQiKb7vQtvgz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D5QHuciDFvsikR9vkj4BadoP8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_D5QHuciDFvsikR9vkj4BadoP8.begin(); iter != sbt_D5QHuciDFvsikR9vkj4BadoP8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2>::Type sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2Array;

