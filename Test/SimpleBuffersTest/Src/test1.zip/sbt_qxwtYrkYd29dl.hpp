
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_zhJORZFLhQEym0l.hpp"


class sbt_qxwtYrkYd29dl : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj;
	CX::IO::SimpleBuffers::UInt32Array sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY;
	CX::IO::SimpleBuffers::Int8Array sbt_k;
	CX::Float sbt_RpG;
	CX::IO::SimpleBuffers::UInt8Array sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC;
	CX::String sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi;
	CX::IO::SimpleBuffers::WStringArray sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx;
	CX::Int32 sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop;
	CX::Int32 sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko;
	CX::Int64 sbt_kwUJIwG8sPxe3;
	CX::IO::SimpleBuffers::Int8Array sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B;
	CX::IO::SimpleBuffers::WStringArray sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC;
	CX::Int64 sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME;
	CX::Int16 sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc;
	CX::IO::SimpleBuffers::UInt32Array sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw;
	CX::Int8 sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6;
	CX::IO::SimpleBuffers::Int64Array sbt_sKQftG8kumabRmS_Sak;
	CX::Bool sbt_Pzw1WfNScbBhB;
	sbt_zhJORZFLhQEym0l sbt_XuCH49y_KF8yqrL2s_FBb;

	virtual void Reset()
	{
		sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.clear();
		sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.clear();
		sbt_k.clear();
		sbt_RpG = 0.0f;
		sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.clear();
		sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi.clear();
		sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.clear();
		sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop = 0;
		sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko = 0;
		sbt_kwUJIwG8sPxe3 = 0;
		sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.clear();
		sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.clear();
		sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME = 0;
		sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc = 0;
		sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.clear();
		sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6 = 0;
		sbt_sKQftG8kumabRmS_Sak.clear();
		sbt_Pzw1WfNScbBhB = false;
		sbt_XuCH49y_KF8yqrL2s_FBb.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.push_back(0.621172f);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.push_back(3371827419);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_k.push_back(-89);
		}
		sbt_RpG = 0.256200f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.push_back(221);
		}
		sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi = "?l\"^*#B+\"UD=yt*@68;cwJ%uShncg.re0^Ij6CNDoPancQp4%eI*3ssjd$";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.push_back(L"=Td(R!@Gfn,hA^H\"'@\"1/Z{V+`jNP%tCy|3jg92q&i}lZ*LQN$'");
		}
		sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop = -1050111885;
		sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko = -666638174;
		sbt_kwUJIwG8sPxe3 = -43146581461052300;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.push_back(22);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.push_back(L"MN'6?0J\"7V7R]l$iwJ-[OLWn07;g<QqDm%rM_'\\7(Z#{A0=k/w%v;{\"5FJBKr");
		}
		sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME = 5737465561785128512;
		sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc = -8917;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.push_back(1203935401);
		}
		sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6 = 96;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_sKQftG8kumabRmS_Sak.push_back(-2052483207938166538);
		}
		sbt_Pzw1WfNScbBhB = true;
		sbt_XuCH49y_KF8yqrL2s_FBb.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_qxwtYrkYd29dl *pObject = dynamic_cast<const sbt_qxwtYrkYd29dl *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.size() != pObject->sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.size(); i++)
		{
			if (sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj[i] != pObject->sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj[i])
			{
				return false;
			}
		}
		if (sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.size() != pObject->sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.size(); i++)
		{
			if (sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY[i] != pObject->sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY[i])
			{
				return false;
			}
		}
		if (sbt_k.size() != pObject->sbt_k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k.size(); i++)
		{
			if (sbt_k[i] != pObject->sbt_k[i])
			{
				return false;
			}
		}
		if (sbt_RpG != pObject->sbt_RpG)
		{
			return false;
		}
		if (sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.size() != pObject->sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.size(); i++)
		{
			if (sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC[i] != pObject->sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi.c_str(), pObject->sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi.c_str()))
		{
			return false;
		}
		if (sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.size() != pObject->sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx[i].c_str(), pObject->sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop != pObject->sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop)
		{
			return false;
		}
		if (sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko != pObject->sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko)
		{
			return false;
		}
		if (sbt_kwUJIwG8sPxe3 != pObject->sbt_kwUJIwG8sPxe3)
		{
			return false;
		}
		if (sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.size() != pObject->sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.size(); i++)
		{
			if (sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B[i] != pObject->sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B[i])
			{
				return false;
			}
		}
		if (sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.size() != pObject->sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC[i].c_str(), pObject->sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME != pObject->sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME)
		{
			return false;
		}
		if (sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc != pObject->sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc)
		{
			return false;
		}
		if (sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.size() != pObject->sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.size(); i++)
		{
			if (sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw[i] != pObject->sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw[i])
			{
				return false;
			}
		}
		if (sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6 != pObject->sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6)
		{
			return false;
		}
		if (sbt_sKQftG8kumabRmS_Sak.size() != pObject->sbt_sKQftG8kumabRmS_Sak.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sKQftG8kumabRmS_Sak.size(); i++)
		{
			if (sbt_sKQftG8kumabRmS_Sak[i] != pObject->sbt_sKQftG8kumabRmS_Sak[i])
			{
				return false;
			}
		}
		if (sbt_Pzw1WfNScbBhB != pObject->sbt_Pzw1WfNScbBhB)
		{
			return false;
		}
		if (!sbt_XuCH49y_KF8yqrL2s_FBb.Compare(&pObject->sbt_XuCH49y_KF8yqrL2s_FBb))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_RpG", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_RpG = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi", &sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kwUJIwG8sPxe3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kwUJIwG8sPxe3 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sKQftG8kumabRmS_Sak")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sKQftG8kumabRmS_Sak.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Pzw1WfNScbBhB", &sbt_Pzw1WfNScbBhB)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_XuCH49y_KF8yqrL2s_FBb")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_XuCH49y_KF8yqrL2s_FBb.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.begin(); iter != sbt_zsg34PbPbJBHddcXWBFmruw2BeMccybM_pwKfs_AFjj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.begin(); iter != sbt_2t_eNnhJYL8XCsNn1qUJFFZnPOi79jnTzhZKbh6uY7rTRR2nY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_k.begin(); iter != sbt_k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_RpG", (CX::Double)sbt_RpG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.begin(); iter != sbt_sVoVThy5qgjRt1CKYJTe99KwFwlFj9AArDwlMIqPBYnRwyBuKSC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi", sbt_x858XzGK0Brynk1cJGnHczHTrEyTChi.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.begin(); iter != sbt_khvSyXiVYe0Mlqzh8dOxtVacQRDjFHoTvgw_CKkRVrQb7ReC5nNAx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop", (CX::Int64)sbt_XHW8ZZ5lecL_RNNO1M3f0GRa2HvhpfdhyHIc76BbPU2l3Mx2AkcVP3NBG9rop)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko", (CX::Int64)sbt_1c6henFYY5g8RFn2I1HpIOqdL42FTzq0c3y785u0Dt8u7CWeZko)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kwUJIwG8sPxe3", (CX::Int64)sbt_kwUJIwG8sPxe3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.begin(); iter != sbt_SymLWxscLLRkWxAwZUEnbFw4FNaSSFPACEV4pGE2B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.begin(); iter != sbt_Y9k6aN19dbm9B35cZ0JndSS9eW2yC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME", (CX::Int64)sbt_IHxrslZD63XYpjhtP0Jo426HWCWLM9j4V5wPaJgME)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc", (CX::Int64)sbt_Y7yfB10KUBOj1mcBzlv892LaCuY8WtgcLSc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.begin(); iter != sbt_Y8FPEqZonSUO0_a_TindqPd9q4EUMoKmTz4sFM2dfXLjt4kAgKBLwblJw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6", (CX::Int64)sbt_qj9OjijY3Ws6h5VXBPzznjTVjorkXfTAFaiFK4E9w8F3HXBpoXuvyx6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sKQftG8kumabRmS_Sak")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_sKQftG8kumabRmS_Sak.begin(); iter != sbt_sKQftG8kumabRmS_Sak.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Pzw1WfNScbBhB", sbt_Pzw1WfNScbBhB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_XuCH49y_KF8yqrL2s_FBb")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_XuCH49y_KF8yqrL2s_FBb.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_qxwtYrkYd29dl>::Type sbt_qxwtYrkYd29dlArray;

