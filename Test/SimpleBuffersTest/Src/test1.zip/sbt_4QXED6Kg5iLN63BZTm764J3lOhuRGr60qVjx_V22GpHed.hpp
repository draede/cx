
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_kA8FyEwnZJJ.hpp"


class sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM;
	CX::Float sbt_B7W3oEf15Xy2FlfMXEqLIdD;
	CX::IO::SimpleBuffers::Int32Array sbt_x6U;
	CX::IO::SimpleBuffers::Int16Array sbt_NryLi;
	CX::IO::SimpleBuffers::UInt32Array sbt_NKFVcVtLWmLmS;
	CX::IO::SimpleBuffers::UInt32Array sbt_I10_D5Lzahz;
	CX::UInt8 sbt_5RU;
	CX::Int16 sbt_5OlK1ym;
	CX::String sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu;
	CX::Int8 sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2;
	CX::IO::SimpleBuffers::Int16Array sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3;
	CX::Int8 sbt_awnRq_gEPetm5NTmsSrzCNG;
	CX::IO::SimpleBuffers::UInt32Array sbt_coUZv;
	CX::IO::SimpleBuffers::UInt32Array sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso;
	CX::String sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW;
	CX::UInt16 sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS;
	CX::UInt8 sbt_jICcHk3cllPVujHNI4QWA;
	CX::UInt8 sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e;
	sbt_kA8FyEwnZJJArray sbt_6WjfWHr4t;

	virtual void Reset()
	{
		sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM = 0;
		sbt_B7W3oEf15Xy2FlfMXEqLIdD = 0.0f;
		sbt_x6U.clear();
		sbt_NryLi.clear();
		sbt_NKFVcVtLWmLmS.clear();
		sbt_I10_D5Lzahz.clear();
		sbt_5RU = 0;
		sbt_5OlK1ym = 0;
		sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu.clear();
		sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2 = 0;
		sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.clear();
		sbt_awnRq_gEPetm5NTmsSrzCNG = 0;
		sbt_coUZv.clear();
		sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.clear();
		sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW.clear();
		sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS = 0;
		sbt_jICcHk3cllPVujHNI4QWA = 0;
		sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e = 0;
		sbt_6WjfWHr4t.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM = 122;
		sbt_B7W3oEf15Xy2FlfMXEqLIdD = 0.810139f;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_x6U.push_back(-1369527405);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_NryLi.push_back(2377);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_NKFVcVtLWmLmS.push_back(4226492276);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_I10_D5Lzahz.push_back(55358984);
		}
		sbt_5RU = 61;
		sbt_5OlK1ym = 14711;
		sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu = "J}T:1fZacsTg_ttiSF[ldd@QVPSv{\"-\\fJll^U:pM0O\"r:K";
		sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2 = -64;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.push_back(-32602);
		}
		sbt_awnRq_gEPetm5NTmsSrzCNG = -41;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_coUZv.push_back(3303495275);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.push_back(2066285926);
		}
		sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW = "Xp}L7+^Y%ebGGz~u5abhW1!b$p?";
		sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS = 60547;
		sbt_jICcHk3cllPVujHNI4QWA = 82;
		sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e = 129;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_kA8FyEwnZJJ v;

			v.SetupWithSomeValues();
			sbt_6WjfWHr4t.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed *pObject = dynamic_cast<const sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM != pObject->sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM)
		{
			return false;
		}
		if (sbt_B7W3oEf15Xy2FlfMXEqLIdD != pObject->sbt_B7W3oEf15Xy2FlfMXEqLIdD)
		{
			return false;
		}
		if (sbt_x6U.size() != pObject->sbt_x6U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_x6U.size(); i++)
		{
			if (sbt_x6U[i] != pObject->sbt_x6U[i])
			{
				return false;
			}
		}
		if (sbt_NryLi.size() != pObject->sbt_NryLi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NryLi.size(); i++)
		{
			if (sbt_NryLi[i] != pObject->sbt_NryLi[i])
			{
				return false;
			}
		}
		if (sbt_NKFVcVtLWmLmS.size() != pObject->sbt_NKFVcVtLWmLmS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NKFVcVtLWmLmS.size(); i++)
		{
			if (sbt_NKFVcVtLWmLmS[i] != pObject->sbt_NKFVcVtLWmLmS[i])
			{
				return false;
			}
		}
		if (sbt_I10_D5Lzahz.size() != pObject->sbt_I10_D5Lzahz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_I10_D5Lzahz.size(); i++)
		{
			if (sbt_I10_D5Lzahz[i] != pObject->sbt_I10_D5Lzahz[i])
			{
				return false;
			}
		}
		if (sbt_5RU != pObject->sbt_5RU)
		{
			return false;
		}
		if (sbt_5OlK1ym != pObject->sbt_5OlK1ym)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu.c_str(), pObject->sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu.c_str()))
		{
			return false;
		}
		if (sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2 != pObject->sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2)
		{
			return false;
		}
		if (sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.size() != pObject->sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.size(); i++)
		{
			if (sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3[i] != pObject->sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3[i])
			{
				return false;
			}
		}
		if (sbt_awnRq_gEPetm5NTmsSrzCNG != pObject->sbt_awnRq_gEPetm5NTmsSrzCNG)
		{
			return false;
		}
		if (sbt_coUZv.size() != pObject->sbt_coUZv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_coUZv.size(); i++)
		{
			if (sbt_coUZv[i] != pObject->sbt_coUZv[i])
			{
				return false;
			}
		}
		if (sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.size() != pObject->sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.size(); i++)
		{
			if (sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso[i] != pObject->sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW.c_str(), pObject->sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW.c_str()))
		{
			return false;
		}
		if (sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS != pObject->sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS)
		{
			return false;
		}
		if (sbt_jICcHk3cllPVujHNI4QWA != pObject->sbt_jICcHk3cllPVujHNI4QWA)
		{
			return false;
		}
		if (sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e != pObject->sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e)
		{
			return false;
		}
		if (sbt_6WjfWHr4t.size() != pObject->sbt_6WjfWHr4t.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6WjfWHr4t.size(); i++)
		{
			if (!sbt_6WjfWHr4t[i].Compare(&pObject->sbt_6WjfWHr4t[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_B7W3oEf15Xy2FlfMXEqLIdD", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_B7W3oEf15Xy2FlfMXEqLIdD = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_x6U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_x6U.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NryLi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NryLi.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NKFVcVtLWmLmS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NKFVcVtLWmLmS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_I10_D5Lzahz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_I10_D5Lzahz.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5RU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5RU = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_5OlK1ym", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5OlK1ym = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu", &sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_awnRq_gEPetm5NTmsSrzCNG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_awnRq_gEPetm5NTmsSrzCNG = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_coUZv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_coUZv.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW", &sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jICcHk3cllPVujHNI4QWA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jICcHk3cllPVujHNI4QWA = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_6WjfWHr4t")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_kA8FyEwnZJJ tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_6WjfWHr4t.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM", (CX::Int64)sbt_7tVO3BFmv9bdmkITGyjPHJkN0V0KM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_B7W3oEf15Xy2FlfMXEqLIdD", (CX::Double)sbt_B7W3oEf15Xy2FlfMXEqLIdD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_x6U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_x6U.begin(); iter != sbt_x6U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NryLi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_NryLi.begin(); iter != sbt_NryLi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NKFVcVtLWmLmS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_NKFVcVtLWmLmS.begin(); iter != sbt_NKFVcVtLWmLmS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_I10_D5Lzahz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_I10_D5Lzahz.begin(); iter != sbt_I10_D5Lzahz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5RU", (CX::Int64)sbt_5RU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5OlK1ym", (CX::Int64)sbt_5OlK1ym)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu", sbt_Rr7Y6CDIqlUzK4d7cFUVK2jHJYe2R0qMl3NCR6UfoNhfu.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2", (CX::Int64)sbt_emVQkORkaBS_uvL9JztIBQA5Acw4xQ7ZIh2xlvXO_n4Y4lWNYcYB2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.begin(); iter != sbt_mINwoPnANmXVK7uktryXs7o4kxvxBCG2zBKJAnt1SWxW3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_awnRq_gEPetm5NTmsSrzCNG", (CX::Int64)sbt_awnRq_gEPetm5NTmsSrzCNG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_coUZv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_coUZv.begin(); iter != sbt_coUZv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.begin(); iter != sbt_Mhei1QhXf6NoFISv1eXvnyvtBG4XLA5hP_C5Z1QS_SoNxHN0BDEE_Ajso.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW", sbt_E7UtGPeRQx7q_otL1VnXEPFHIoX_4gJRGJI8YraDW.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS", (CX::Int64)sbt_bh9YbeefGHIMtw3NYOqu0BP7y3lvS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jICcHk3cllPVujHNI4QWA", (CX::Int64)sbt_jICcHk3cllPVujHNI4QWA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e", (CX::Int64)sbt_Jcn3H0c_qdpEiSmEaO9q0tq6MczIJdbiD6e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6WjfWHr4t")).IsNOK())
		{
			return status;
		}
		for (sbt_kA8FyEwnZJJArray::const_iterator iter = sbt_6WjfWHr4t.begin(); iter != sbt_6WjfWHr4t.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed>::Type sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHedArray;

