
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg.hpp"


class sbt_DYiGJ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_IexHk005FCRInaAZn;
	CX::UInt16 sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4;
	CX::IO::SimpleBuffers::Int16Array sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs;
	CX::WString sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5;
	CX::IO::SimpleBuffers::StringArray sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w;
	CX::IO::SimpleBuffers::UInt32Array sbt_l;
	CX::IO::SimpleBuffers::UInt32Array sbt_KxvQkMAJPg6hcc0;
	CX::Float sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI;
	CX::IO::SimpleBuffers::WStringArray sbt_eWXVS;
	CX::Int64 sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq;
	CX::Float sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf;
	CX::Int16 sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge;
	CX::IO::SimpleBuffers::WStringArray sbt_5p9q0X1Xo;
	CX::IO::SimpleBuffers::StringArray sbt_T9GltFB__SdFJwN9F8B;
	CX::IO::SimpleBuffers::BoolArray sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm;
	sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMgArray sbt_CuO66yNi7gQ;

	virtual void Reset()
	{
		sbt_IexHk005FCRInaAZn = 0;
		sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4 = 0;
		sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.clear();
		sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5.clear();
		sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.clear();
		sbt_l.clear();
		sbt_KxvQkMAJPg6hcc0.clear();
		sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI = 0.0f;
		sbt_eWXVS.clear();
		sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq = 0;
		sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf = 0.0f;
		sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge = 0;
		sbt_5p9q0X1Xo.clear();
		sbt_T9GltFB__SdFJwN9F8B.clear();
		sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.clear();
		sbt_CuO66yNi7gQ.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_IexHk005FCRInaAZn = -894836885203855096;
		sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4 = 16986;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.push_back(-2721);
		}
		sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5 = L"ci<'C%GMF<8sz!Ddx#i9|N8Dr0`p=imeT`<wVo4A?Db0'f\"0|!_%Bl[Jv\\6";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.push_back("43?<eM7ge<0<a");
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_l.push_back(1493525976);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_KxvQkMAJPg6hcc0.push_back(247687339);
		}
		sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI = 0.906342f;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_eWXVS.push_back(L"l&YGBls[;IO\\o.Z*qd)\"R%}L\"E/j");
		}
		sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq = -8024293141207386910;
		sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf = 0.017728f;
		sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge = -7457;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_5p9q0X1Xo.push_back(L")aF](uo6Q{!UobF`1sE");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_T9GltFB__SdFJwN9F8B.push_back("T[6|0T");
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.push_back(false);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg v;

			v.SetupWithSomeValues();
			sbt_CuO66yNi7gQ.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_DYiGJ *pObject = dynamic_cast<const sbt_DYiGJ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_IexHk005FCRInaAZn != pObject->sbt_IexHk005FCRInaAZn)
		{
			return false;
		}
		if (sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4 != pObject->sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4)
		{
			return false;
		}
		if (sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.size() != pObject->sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.size(); i++)
		{
			if (sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs[i] != pObject->sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5.c_str(), pObject->sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5.c_str()))
		{
			return false;
		}
		if (sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.size() != pObject->sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w[i].c_str(), pObject->sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_l.size() != pObject->sbt_l.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l.size(); i++)
		{
			if (sbt_l[i] != pObject->sbt_l[i])
			{
				return false;
			}
		}
		if (sbt_KxvQkMAJPg6hcc0.size() != pObject->sbt_KxvQkMAJPg6hcc0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KxvQkMAJPg6hcc0.size(); i++)
		{
			if (sbt_KxvQkMAJPg6hcc0[i] != pObject->sbt_KxvQkMAJPg6hcc0[i])
			{
				return false;
			}
		}
		if (sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI != pObject->sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI)
		{
			return false;
		}
		if (sbt_eWXVS.size() != pObject->sbt_eWXVS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_eWXVS.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_eWXVS[i].c_str(), pObject->sbt_eWXVS[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq != pObject->sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq)
		{
			return false;
		}
		if (sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf != pObject->sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf)
		{
			return false;
		}
		if (sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge != pObject->sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge)
		{
			return false;
		}
		if (sbt_5p9q0X1Xo.size() != pObject->sbt_5p9q0X1Xo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5p9q0X1Xo.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_5p9q0X1Xo[i].c_str(), pObject->sbt_5p9q0X1Xo[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_T9GltFB__SdFJwN9F8B.size() != pObject->sbt_T9GltFB__SdFJwN9F8B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_T9GltFB__SdFJwN9F8B.size(); i++)
		{
			if (0 != cx_strcmp(sbt_T9GltFB__SdFJwN9F8B[i].c_str(), pObject->sbt_T9GltFB__SdFJwN9F8B[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.size() != pObject->sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.size(); i++)
		{
			if (sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm[i] != pObject->sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm[i])
			{
				return false;
			}
		}
		if (sbt_CuO66yNi7gQ.size() != pObject->sbt_CuO66yNi7gQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CuO66yNi7gQ.size(); i++)
		{
			if (!sbt_CuO66yNi7gQ[i].Compare(&pObject->sbt_CuO66yNi7gQ[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_IexHk005FCRInaAZn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IexHk005FCRInaAZn = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5", &sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_l")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_KxvQkMAJPg6hcc0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KxvQkMAJPg6hcc0.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_eWXVS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_eWXVS.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectReal("sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5p9q0X1Xo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5p9q0X1Xo.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_T9GltFB__SdFJwN9F8B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_T9GltFB__SdFJwN9F8B.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CuO66yNi7gQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_CuO66yNi7gQ.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_IexHk005FCRInaAZn", (CX::Int64)sbt_IexHk005FCRInaAZn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4", (CX::Int64)sbt_8KoinudaZzC6gNoSh3da1dkLR1LVVfBnnOWiEkEJhAdGHMhOFfMTec4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.begin(); iter != sbt_tQOZhH2dJ1At2IBlNAqdVk8Qs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5", sbt_m4sJHoHQuYdwNAGbI33Ze8oywxm5PxIDYfqXOg5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.begin(); iter != sbt_Ti3jIJzFhv5b85AsVUl3W1miqwOhPKNfL8sTcZb3w.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_l.begin(); iter != sbt_l.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KxvQkMAJPg6hcc0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_KxvQkMAJPg6hcc0.begin(); iter != sbt_KxvQkMAJPg6hcc0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI", (CX::Double)sbt_AgncmQ3O5L0cUZexAUOqqCLOty_kkNksaxBeI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_eWXVS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_eWXVS.begin(); iter != sbt_eWXVS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq", (CX::Int64)sbt_pgh4kxErJegbyOsYKlb6k8N8DOxWQHHIrr_ZamUvKFq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf", (CX::Double)sbt_fEOh_OkcxCjcYBYkqaIkW1Iz9u9AwaRBcxhmimXi22z8ZiMCJIf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge", (CX::Int64)sbt_Ww8DF2lmO17sUjl0aQKCLvpE2sUpILFbElLBB8chpQcDQsjsvp_rL4qq4i6ckge)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5p9q0X1Xo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_5p9q0X1Xo.begin(); iter != sbt_5p9q0X1Xo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_T9GltFB__SdFJwN9F8B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_T9GltFB__SdFJwN9F8B.begin(); iter != sbt_T9GltFB__SdFJwN9F8B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.begin(); iter != sbt_hI581Z74m7a32sWUA93w6ZNCz4vRVM19a8FJm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CuO66yNi7gQ")).IsNOK())
		{
			return status;
		}
		for (sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMgArray::const_iterator iter = sbt_CuO66yNi7gQ.begin(); iter != sbt_CuO66yNi7gQ.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_DYiGJ>::Type sbt_DYiGJArray;

