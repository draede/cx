
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_myQJmArRECa46.hpp"


class sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D;
	CX::Int32 sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J;
	CX::Int64 sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW;
	CX::UInt16 sbt_fizFj;
	CX::UInt32 sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI;
	CX::IO::SimpleBuffers::UInt64Array sbt_vGv31ub;
	CX::UInt64 sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a;
	CX::IO::SimpleBuffers::Int64Array sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh;
	CX::IO::SimpleBuffers::WStringArray sbt_SyzJLfbtgRIkt;
	CX::Int8 sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN;
	CX::IO::SimpleBuffers::UInt64Array sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7;
	CX::IO::SimpleBuffers::FloatArray sbt_WlBEcQNk594QhltbbtlAem_RGhI;
	CX::String sbt_fI2L2l99eUVf1zJkX;
	CX::IO::SimpleBuffers::UInt8Array sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g;
	sbt_myQJmArRECa46Array sbt_lXZOPhBJX;

	virtual void Reset()
	{
		sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.clear();
		sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J = 0;
		sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW = 0;
		sbt_fizFj = 0;
		sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI = 0;
		sbt_vGv31ub.clear();
		sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a = 0;
		sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.clear();
		sbt_SyzJLfbtgRIkt.clear();
		sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN = 0;
		sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.clear();
		sbt_WlBEcQNk594QhltbbtlAem_RGhI.clear();
		sbt_fI2L2l99eUVf1zJkX.clear();
		sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.clear();
		sbt_lXZOPhBJX.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.push_back(0.313653f);
		}
		sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J = 1587099836;
		sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW = 7218794526951156344;
		sbt_fizFj = 48035;
		sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI = 3800828339;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_vGv31ub.push_back(11124621018712185538);
		}
		sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a = 6190722083301851376;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.push_back(5300801476045301336);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_SyzJLfbtgRIkt.push_back(L"s\\xvwYu20!ghI%_^{^!XN)@G+a/Ui9b\\#A4{CvC>L$5CJ");
		}
		sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN = -14;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.push_back(12444962173598212956);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_WlBEcQNk594QhltbbtlAem_RGhI.push_back(0.422035f);
		}
		sbt_fI2L2l99eUVf1zJkX = "Z$&";
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.push_back(109);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_myQJmArRECa46 v;

			v.SetupWithSomeValues();
			sbt_lXZOPhBJX.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G *pObject = dynamic_cast<const sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.size() != pObject->sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.size(); i++)
		{
			if (sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D[i] != pObject->sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D[i])
			{
				return false;
			}
		}
		if (sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J != pObject->sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J)
		{
			return false;
		}
		if (sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW != pObject->sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW)
		{
			return false;
		}
		if (sbt_fizFj != pObject->sbt_fizFj)
		{
			return false;
		}
		if (sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI != pObject->sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI)
		{
			return false;
		}
		if (sbt_vGv31ub.size() != pObject->sbt_vGv31ub.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vGv31ub.size(); i++)
		{
			if (sbt_vGv31ub[i] != pObject->sbt_vGv31ub[i])
			{
				return false;
			}
		}
		if (sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a != pObject->sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a)
		{
			return false;
		}
		if (sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.size() != pObject->sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.size(); i++)
		{
			if (sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh[i] != pObject->sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh[i])
			{
				return false;
			}
		}
		if (sbt_SyzJLfbtgRIkt.size() != pObject->sbt_SyzJLfbtgRIkt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SyzJLfbtgRIkt.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_SyzJLfbtgRIkt[i].c_str(), pObject->sbt_SyzJLfbtgRIkt[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN != pObject->sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN)
		{
			return false;
		}
		if (sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.size() != pObject->sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.size(); i++)
		{
			if (sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7[i] != pObject->sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7[i])
			{
				return false;
			}
		}
		if (sbt_WlBEcQNk594QhltbbtlAem_RGhI.size() != pObject->sbt_WlBEcQNk594QhltbbtlAem_RGhI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WlBEcQNk594QhltbbtlAem_RGhI.size(); i++)
		{
			if (sbt_WlBEcQNk594QhltbbtlAem_RGhI[i] != pObject->sbt_WlBEcQNk594QhltbbtlAem_RGhI[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_fI2L2l99eUVf1zJkX.c_str(), pObject->sbt_fI2L2l99eUVf1zJkX.c_str()))
		{
			return false;
		}
		if (sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.size() != pObject->sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.size(); i++)
		{
			if (sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g[i] != pObject->sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g[i])
			{
				return false;
			}
		}
		if (sbt_lXZOPhBJX.size() != pObject->sbt_lXZOPhBJX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lXZOPhBJX.size(); i++)
		{
			if (!sbt_lXZOPhBJX[i].Compare(&pObject->sbt_lXZOPhBJX[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fizFj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fizFj = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vGv31ub")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vGv31ub.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SyzJLfbtgRIkt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SyzJLfbtgRIkt.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WlBEcQNk594QhltbbtlAem_RGhI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WlBEcQNk594QhltbbtlAem_RGhI.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_fI2L2l99eUVf1zJkX", &sbt_fI2L2l99eUVf1zJkX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_lXZOPhBJX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_myQJmArRECa46 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_lXZOPhBJX.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.begin(); iter != sbt_vduVseW5j17yPPTXaAysPGcJ_E3an7D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J", (CX::Int64)sbt_nOumOzpoPp6CmfXRne38igQelZawu0qtyoBw1oWstOjFwPu9jZajGZXs017vq2J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW", (CX::Int64)sbt_ShuMvEVcfNUxViLkO9R8b7oBv5QsXuMlWuW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fizFj", (CX::Int64)sbt_fizFj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI", (CX::Int64)sbt_SbqPsZOeypJOmV8ljTIeOculP8hwI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vGv31ub")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vGv31ub.begin(); iter != sbt_vGv31ub.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a", (CX::Int64)sbt_aJB9bOrVg4TGdxoF3UJF_McJ_UxbvenmNlRYaIVmgSHDgoK9m5AqyLLLNvboz9a)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.begin(); iter != sbt_jZkwRyi_hWIZ94F5QbZAKNVJw2x3jgDxTrwr5g2imL1F39R9PgCWu2CNS8bWFuh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SyzJLfbtgRIkt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_SyzJLfbtgRIkt.begin(); iter != sbt_SyzJLfbtgRIkt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN", (CX::Int64)sbt_u_OVh2ZN9t1cAWcUyMd_u4F0aUtsmWUFz_EvuUVJdfEtN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.begin(); iter != sbt_E1prHGV8F0CJLxLG_dlF8pmGeTkggzoWByKN7jQASWwlQyGV2YZy_g3_1Itd7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WlBEcQNk594QhltbbtlAem_RGhI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_WlBEcQNk594QhltbbtlAem_RGhI.begin(); iter != sbt_WlBEcQNk594QhltbbtlAem_RGhI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_fI2L2l99eUVf1zJkX", sbt_fI2L2l99eUVf1zJkX.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.begin(); iter != sbt_c3RxChAGiIs01tYCWhrdaimfkHntzj_XDW56tEpGE4UPwNG4f6g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lXZOPhBJX")).IsNOK())
		{
			return status;
		}
		for (sbt_myQJmArRECa46Array::const_iterator iter = sbt_lXZOPhBJX.begin(); iter != sbt_lXZOPhBJX.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G>::Type sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2GArray;

