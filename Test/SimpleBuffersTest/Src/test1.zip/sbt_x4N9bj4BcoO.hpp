
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_x4N9bj4BcoO : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_Lue15MizsBBSz;
	CX::IO::SimpleBuffers::BoolArray sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe;
	CX::Int16 sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7;
	CX::Int8 sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe;
	CX::UInt64 sbt_sNh;
	CX::UInt64 sbt_MgvOQJLYB;
	CX::Bool sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K;
	CX::UInt32 sbt_YoD9ZP9;
	CX::Int8 sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk;
	CX::IO::SimpleBuffers::Int16Array sbt_Kijkm;
	CX::IO::SimpleBuffers::UInt32Array sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X;
	CX::Int8 sbt_OiSF3NHSaRea4LIL0imUHf89z;
	CX::IO::SimpleBuffers::Int16Array sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK;
	CX::IO::SimpleBuffers::Int64Array sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq;
	CX::IO::SimpleBuffers::Int8Array sbt_WsxGZ_PXmis;
	CX::IO::SimpleBuffers::StringArray sbt_VSI;
	CX::IO::SimpleBuffers::UInt32Array sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R;
	CX::Int16 sbt_mnaiI3gbh;
	CX::UInt32 sbt_bRF2L7nH3;
	CX::Int32 sbt_1vdn_HRay;
	CX::UInt64 sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR;
	CX::IO::SimpleBuffers::Int16Array sbt_k;
	CX::IO::SimpleBuffers::UInt16Array sbt_R6VPdl3L0;

	virtual void Reset()
	{
		sbt_Lue15MizsBBSz = 0;
		sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.clear();
		sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7 = 0;
		sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe = 0;
		sbt_sNh = 0;
		sbt_MgvOQJLYB = 0;
		sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K = false;
		sbt_YoD9ZP9 = 0;
		sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk = 0;
		sbt_Kijkm.clear();
		sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.clear();
		sbt_OiSF3NHSaRea4LIL0imUHf89z = 0;
		sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.clear();
		sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.clear();
		sbt_WsxGZ_PXmis.clear();
		sbt_VSI.clear();
		sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.clear();
		sbt_mnaiI3gbh = 0;
		sbt_bRF2L7nH3 = 0;
		sbt_1vdn_HRay = 0;
		sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR = 0;
		sbt_k.clear();
		sbt_R6VPdl3L0.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Lue15MizsBBSz = 11245686403999234956;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.push_back(true);
		}
		sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7 = 30858;
		sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe = 112;
		sbt_sNh = 10075401710036062192;
		sbt_MgvOQJLYB = 2168691704258979000;
		sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K = false;
		sbt_YoD9ZP9 = 3926688520;
		sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk = -79;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_Kijkm.push_back(18832);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.push_back(1158318221);
		}
		sbt_OiSF3NHSaRea4LIL0imUHf89z = -49;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.push_back(19265344730159464);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_WsxGZ_PXmis.push_back(-95);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VSI.push_back("%6NJ;9tY\"~,KVGmPEEW6k>5g9dWd)xc12vMQ)~&6}7qvh_/loOloQg+=#czBE8^:");
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.push_back(1575432714);
		}
		sbt_mnaiI3gbh = 1046;
		sbt_bRF2L7nH3 = 711171910;
		sbt_1vdn_HRay = 920625659;
		sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR = 14472792063733462670;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_k.push_back(17475);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_R6VPdl3L0.push_back(10156);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_x4N9bj4BcoO *pObject = dynamic_cast<const sbt_x4N9bj4BcoO *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Lue15MizsBBSz != pObject->sbt_Lue15MizsBBSz)
		{
			return false;
		}
		if (sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.size() != pObject->sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.size(); i++)
		{
			if (sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe[i] != pObject->sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe[i])
			{
				return false;
			}
		}
		if (sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7 != pObject->sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7)
		{
			return false;
		}
		if (sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe != pObject->sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe)
		{
			return false;
		}
		if (sbt_sNh != pObject->sbt_sNh)
		{
			return false;
		}
		if (sbt_MgvOQJLYB != pObject->sbt_MgvOQJLYB)
		{
			return false;
		}
		if (sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K != pObject->sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K)
		{
			return false;
		}
		if (sbt_YoD9ZP9 != pObject->sbt_YoD9ZP9)
		{
			return false;
		}
		if (sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk != pObject->sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk)
		{
			return false;
		}
		if (sbt_Kijkm.size() != pObject->sbt_Kijkm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Kijkm.size(); i++)
		{
			if (sbt_Kijkm[i] != pObject->sbt_Kijkm[i])
			{
				return false;
			}
		}
		if (sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.size() != pObject->sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.size(); i++)
		{
			if (sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X[i] != pObject->sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X[i])
			{
				return false;
			}
		}
		if (sbt_OiSF3NHSaRea4LIL0imUHf89z != pObject->sbt_OiSF3NHSaRea4LIL0imUHf89z)
		{
			return false;
		}
		if (sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.size() != pObject->sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.size(); i++)
		{
			if (sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK[i] != pObject->sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK[i])
			{
				return false;
			}
		}
		if (sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.size() != pObject->sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.size(); i++)
		{
			if (sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq[i] != pObject->sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq[i])
			{
				return false;
			}
		}
		if (sbt_WsxGZ_PXmis.size() != pObject->sbt_WsxGZ_PXmis.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WsxGZ_PXmis.size(); i++)
		{
			if (sbt_WsxGZ_PXmis[i] != pObject->sbt_WsxGZ_PXmis[i])
			{
				return false;
			}
		}
		if (sbt_VSI.size() != pObject->sbt_VSI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VSI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_VSI[i].c_str(), pObject->sbt_VSI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.size() != pObject->sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.size(); i++)
		{
			if (sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R[i] != pObject->sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R[i])
			{
				return false;
			}
		}
		if (sbt_mnaiI3gbh != pObject->sbt_mnaiI3gbh)
		{
			return false;
		}
		if (sbt_bRF2L7nH3 != pObject->sbt_bRF2L7nH3)
		{
			return false;
		}
		if (sbt_1vdn_HRay != pObject->sbt_1vdn_HRay)
		{
			return false;
		}
		if (sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR != pObject->sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR)
		{
			return false;
		}
		if (sbt_k.size() != pObject->sbt_k.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_k.size(); i++)
		{
			if (sbt_k[i] != pObject->sbt_k[i])
			{
				return false;
			}
		}
		if (sbt_R6VPdl3L0.size() != pObject->sbt_R6VPdl3L0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R6VPdl3L0.size(); i++)
		{
			if (sbt_R6VPdl3L0[i] != pObject->sbt_R6VPdl3L0[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_Lue15MizsBBSz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Lue15MizsBBSz = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sNh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sNh = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MgvOQJLYB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MgvOQJLYB = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K", &sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_YoD9ZP9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YoD9ZP9 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Kijkm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Kijkm.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OiSF3NHSaRea4LIL0imUHf89z", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OiSF3NHSaRea4LIL0imUHf89z = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WsxGZ_PXmis")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WsxGZ_PXmis.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VSI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VSI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mnaiI3gbh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mnaiI3gbh = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bRF2L7nH3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bRF2L7nH3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1vdn_HRay", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1vdn_HRay = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_k")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_k.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R6VPdl3L0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R6VPdl3L0.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_Lue15MizsBBSz", (CX::Int64)sbt_Lue15MizsBBSz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.begin(); iter != sbt_0fMKTimFG9Ijlyi78pDAugZR502mBlUkompgfDcuC9PVEwe.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7", (CX::Int64)sbt_NK2A2OiMRkML7WAhqdmnGwTk7_nylVem5tpNOZjM7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe", (CX::Int64)sbt_pQhTx87Bgv1I6r7mUARK8yl0eEe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sNh", (CX::Int64)sbt_sNh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MgvOQJLYB", (CX::Int64)sbt_MgvOQJLYB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K", sbt_wDiJ1AQgeFT_oTk6glQcMaQzDEVB35pHML3_LjGMOTEOzxOm6NCFR5QT43K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YoD9ZP9", (CX::Int64)sbt_YoD9ZP9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk", (CX::Int64)sbt_UV5JAJ8rnxvDJq5zKpShmCo4NnQFl0ppRUKmk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Kijkm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Kijkm.begin(); iter != sbt_Kijkm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.begin(); iter != sbt_IkfYovuMFkYtFGd_9la2h_9wJl5T5iC7g1gY6W73X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OiSF3NHSaRea4LIL0imUHf89z", (CX::Int64)sbt_OiSF3NHSaRea4LIL0imUHf89z)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.begin(); iter != sbt__5DcflaTOEWSEPhw6Unln3xR6RPpby8nsCPtK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.begin(); iter != sbt_zIg5wkvKnP_yg6uMQ9dZCharljmq99tx1dwHdb9DEqEQnpRh7WNWIpZXMeq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WsxGZ_PXmis")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_WsxGZ_PXmis.begin(); iter != sbt_WsxGZ_PXmis.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VSI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_VSI.begin(); iter != sbt_VSI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.begin(); iter != sbt_LsRQCmKiCAlY3eN3rnLG9X2LOGPtx6R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mnaiI3gbh", (CX::Int64)sbt_mnaiI3gbh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bRF2L7nH3", (CX::Int64)sbt_bRF2L7nH3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1vdn_HRay", (CX::Int64)sbt_1vdn_HRay)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR", (CX::Int64)sbt_fbGBaCPd6zy7XaTNL3uFTwBo8UkH42nMiB2stSPXuBB5I_eDR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_k")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_k.begin(); iter != sbt_k.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R6VPdl3L0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_R6VPdl3L0.begin(); iter != sbt_R6VPdl3L0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_x4N9bj4BcoO>::Type sbt_x4N9bj4BcoOArray;

