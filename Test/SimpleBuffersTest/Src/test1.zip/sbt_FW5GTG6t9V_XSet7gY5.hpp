
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_FW5GTG6t9V_XSet7gY5 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj;
	CX::IO::SimpleBuffers::Int64Array sbt_th_5B;
	CX::IO::SimpleBuffers::BoolArray sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw;
	CX::Int16 sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO;
	CX::IO::SimpleBuffers::StringArray sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_;
	CX::UInt32 sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT;
	CX::UInt64 sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl;
	CX::IO::SimpleBuffers::BoolArray sbt_1oo56NPgX_3;
	CX::Int64 sbt_T_aisGkrhbjRyLZbfrJ;
	CX::IO::SimpleBuffers::UInt8Array sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB;
	CX::IO::SimpleBuffers::Int32Array sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d;
	CX::UInt32 sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf;
	CX::IO::SimpleBuffers::UInt32Array sbt_96XXWvMu4;
	CX::IO::SimpleBuffers::UInt16Array sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c;
	CX::Int8 sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u;
	CX::Bool sbt_n;
	CX::Int32 sbt_LpeIDDf;
	CX::IO::SimpleBuffers::Int32Array sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c;
	CX::IO::SimpleBuffers::Int32Array sbt_rEwA2;
	CX::IO::SimpleBuffers::UInt8Array sbt_cgNvw7CuZlorUEl;
	CX::IO::SimpleBuffers::UInt32Array sbt_5jZ8yUM;
	CX::Int64 sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm;
	CX::Int16 sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd;

	virtual void Reset()
	{
		sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.clear();
		sbt_th_5B.clear();
		sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.clear();
		sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO = 0;
		sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.clear();
		sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT = 0;
		sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl = 0;
		sbt_1oo56NPgX_3.clear();
		sbt_T_aisGkrhbjRyLZbfrJ = 0;
		sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.clear();
		sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.clear();
		sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf = 0;
		sbt_96XXWvMu4.clear();
		sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.clear();
		sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u = 0;
		sbt_n = false;
		sbt_LpeIDDf = 0;
		sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.clear();
		sbt_rEwA2.clear();
		sbt_cgNvw7CuZlorUEl.clear();
		sbt_5jZ8yUM.clear();
		sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm = 0;
		sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.push_back(-6930055434102459808);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_th_5B.push_back(4989813675693985992);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.push_back(false);
		}
		sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO = 2411;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.push_back("q!FivWL56mcXL[#492)4O");
		}
		sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT = 2553713540;
		sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl = 7433369554158636826;
		sbt_T_aisGkrhbjRyLZbfrJ = 5789342710651535160;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.push_back(211);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.push_back(-946871004);
		}
		sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf = 431875766;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_96XXWvMu4.push_back(423993456);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.push_back(46022);
		}
		sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u = -85;
		sbt_n = true;
		sbt_LpeIDDf = 2143251185;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.push_back(927857730);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_rEwA2.push_back(-742845028);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_cgNvw7CuZlorUEl.push_back(163);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_5jZ8yUM.push_back(2139490550);
		}
		sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm = 3432813112083326020;
		sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd = 5542;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_FW5GTG6t9V_XSet7gY5 *pObject = dynamic_cast<const sbt_FW5GTG6t9V_XSet7gY5 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.size() != pObject->sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.size(); i++)
		{
			if (sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj[i] != pObject->sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj[i])
			{
				return false;
			}
		}
		if (sbt_th_5B.size() != pObject->sbt_th_5B.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_th_5B.size(); i++)
		{
			if (sbt_th_5B[i] != pObject->sbt_th_5B[i])
			{
				return false;
			}
		}
		if (sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.size() != pObject->sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.size(); i++)
		{
			if (sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw[i] != pObject->sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw[i])
			{
				return false;
			}
		}
		if (sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO != pObject->sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO)
		{
			return false;
		}
		if (sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.size() != pObject->sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.size(); i++)
		{
			if (0 != cx_strcmp(sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_[i].c_str(), pObject->sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT != pObject->sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT)
		{
			return false;
		}
		if (sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl != pObject->sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl)
		{
			return false;
		}
		if (sbt_1oo56NPgX_3.size() != pObject->sbt_1oo56NPgX_3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1oo56NPgX_3.size(); i++)
		{
			if (sbt_1oo56NPgX_3[i] != pObject->sbt_1oo56NPgX_3[i])
			{
				return false;
			}
		}
		if (sbt_T_aisGkrhbjRyLZbfrJ != pObject->sbt_T_aisGkrhbjRyLZbfrJ)
		{
			return false;
		}
		if (sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.size() != pObject->sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.size(); i++)
		{
			if (sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB[i] != pObject->sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB[i])
			{
				return false;
			}
		}
		if (sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.size() != pObject->sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.size(); i++)
		{
			if (sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d[i] != pObject->sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d[i])
			{
				return false;
			}
		}
		if (sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf != pObject->sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf)
		{
			return false;
		}
		if (sbt_96XXWvMu4.size() != pObject->sbt_96XXWvMu4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_96XXWvMu4.size(); i++)
		{
			if (sbt_96XXWvMu4[i] != pObject->sbt_96XXWvMu4[i])
			{
				return false;
			}
		}
		if (sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.size() != pObject->sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.size(); i++)
		{
			if (sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c[i] != pObject->sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c[i])
			{
				return false;
			}
		}
		if (sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u != pObject->sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u)
		{
			return false;
		}
		if (sbt_n != pObject->sbt_n)
		{
			return false;
		}
		if (sbt_LpeIDDf != pObject->sbt_LpeIDDf)
		{
			return false;
		}
		if (sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.size() != pObject->sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.size(); i++)
		{
			if (sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c[i] != pObject->sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c[i])
			{
				return false;
			}
		}
		if (sbt_rEwA2.size() != pObject->sbt_rEwA2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rEwA2.size(); i++)
		{
			if (sbt_rEwA2[i] != pObject->sbt_rEwA2[i])
			{
				return false;
			}
		}
		if (sbt_cgNvw7CuZlorUEl.size() != pObject->sbt_cgNvw7CuZlorUEl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cgNvw7CuZlorUEl.size(); i++)
		{
			if (sbt_cgNvw7CuZlorUEl[i] != pObject->sbt_cgNvw7CuZlorUEl[i])
			{
				return false;
			}
		}
		if (sbt_5jZ8yUM.size() != pObject->sbt_5jZ8yUM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5jZ8yUM.size(); i++)
		{
			if (sbt_5jZ8yUM[i] != pObject->sbt_5jZ8yUM[i])
			{
				return false;
			}
		}
		if (sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm != pObject->sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm)
		{
			return false;
		}
		if (sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd != pObject->sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_th_5B")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_th_5B.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1oo56NPgX_3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1oo56NPgX_3.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_T_aisGkrhbjRyLZbfrJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T_aisGkrhbjRyLZbfrJ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_96XXWvMu4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_96XXWvMu4.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_n", &sbt_n)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LpeIDDf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LpeIDDf = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rEwA2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rEwA2.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cgNvw7CuZlorUEl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cgNvw7CuZlorUEl.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5jZ8yUM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5jZ8yUM.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd = (CX::Int16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.begin(); iter != sbt_lT4Dphs5UI6Z28Yqvbv6yxABmM5M1ZltcmpQeHj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_th_5B")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_th_5B.begin(); iter != sbt_th_5B.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.begin(); iter != sbt_60oCA4dFrRtPNQeKjQaXNX8KWpxXa0UTe6Ama2bQpr96pMUD1iHV4mQVaeXdw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO", (CX::Int64)sbt_i0cv_tbldnWksZPWEs1wgnrAL06CO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.begin(); iter != sbt_sny5W7_qNHlG4bXRywuSHD9EtDREuM_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT", (CX::Int64)sbt_G4cNdxR0r6RltV2_EHN4g17Fn1KL2dCZ4x0payT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl", (CX::Int64)sbt_maSFNSRFW0Gyl3pLsqVgNk1cJlxv4wiOExX2SAmgtdlrpYewuq6kegANTZdlPyl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1oo56NPgX_3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_1oo56NPgX_3.begin(); iter != sbt_1oo56NPgX_3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T_aisGkrhbjRyLZbfrJ", (CX::Int64)sbt_T_aisGkrhbjRyLZbfrJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.begin(); iter != sbt_Z0O7PgLQ_kweYFS55b7CB9K0siB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.begin(); iter != sbt_NS09Ek52VLpoJG0J2s5rldfAUfi8zooUpwTmQC511SaGj9LD35d.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf", (CX::Int64)sbt_wp00aF5e5IzRqPs65FmHs64jqYzyf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_96XXWvMu4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_96XXWvMu4.begin(); iter != sbt_96XXWvMu4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.begin(); iter != sbt_dAdiYUO4In1ggrHOpGk_pSo1h_05c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u", (CX::Int64)sbt_O51cX93pS6E4y19GMJH7DSA2YeXOnKlsMV91u)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_n", sbt_n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LpeIDDf", (CX::Int64)sbt_LpeIDDf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.begin(); iter != sbt_LlvbVp4XkTOTvSB6PFoHLtPGdW9dhQYId8c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rEwA2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_rEwA2.begin(); iter != sbt_rEwA2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cgNvw7CuZlorUEl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_cgNvw7CuZlorUEl.begin(); iter != sbt_cgNvw7CuZlorUEl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5jZ8yUM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5jZ8yUM.begin(); iter != sbt_5jZ8yUM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm", (CX::Int64)sbt_b1YVid5QOURKpYcsF2A2YIkcRJ2lgMdvOw3OAWCpYr2XivTvETRBm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd", (CX::Int64)sbt_KzTZDZjHA0LAYPDLSqmJ8_gs1SCuTcgksuLVF4Lg20A2Ibshw7_Yd)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_FW5GTG6t9V_XSet7gY5>::Type sbt_FW5GTG6t9V_XSet7gY5Array;

