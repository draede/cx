
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_gFaoed8jU0GqChtq6B3S3 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt16Array sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP;
	CX::IO::SimpleBuffers::Int64Array sbt_dkJ9cmTiX;
	CX::UInt64 sbt_2;
	CX::IO::SimpleBuffers::UInt32Array sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9;
	CX::IO::SimpleBuffers::UInt64Array sbt_s10bx_DHiNTKSHz;
	CX::IO::SimpleBuffers::UInt32Array sbt_kJ5wvIeIIsUWTK1CfmfhycP;
	CX::String sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM;
	CX::IO::SimpleBuffers::Int8Array sbt_MQbtMyM;
	CX::UInt64 sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM;
	CX::Int16 sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL;
	CX::IO::SimpleBuffers::UInt64Array sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G;
	CX::UInt32 sbt_McBHaB3uoc3IMk20fiY;
	CX::UInt16 sbt_bZSJ0kzetKFAIVjL11u0iofcF;
	CX::IO::SimpleBuffers::Int8Array sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo;
	CX::UInt64 sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5;
	CX::String sbt_ebuPUTmxn;
	CX::Int32 sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44;
	CX::IO::SimpleBuffers::UInt8Array sbt_u;
	CX::UInt32 sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF;
	CX::IO::SimpleBuffers::UInt64Array sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji;
	CX::Int16 sbt_lTu;
	CX::IO::SimpleBuffers::Int32Array sbt_KusgtpuZaIATgAk;
	CX::IO::SimpleBuffers::UInt16Array sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR;
	CX::IO::SimpleBuffers::Int16Array sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr;
	CX::Int64 sbt_LkAKkFiGxO3k4Ss0pQZf71J;
	CX::UInt16 sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7;
	CX::Int32 sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq;
	CX::Int8 sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3;

	virtual void Reset()
	{
		sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.clear();
		sbt_dkJ9cmTiX.clear();
		sbt_2 = 0;
		sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.clear();
		sbt_s10bx_DHiNTKSHz.clear();
		sbt_kJ5wvIeIIsUWTK1CfmfhycP.clear();
		sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM.clear();
		sbt_MQbtMyM.clear();
		sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM = 0;
		sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL = 0;
		sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.clear();
		sbt_McBHaB3uoc3IMk20fiY = 0;
		sbt_bZSJ0kzetKFAIVjL11u0iofcF = 0;
		sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.clear();
		sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5 = 0;
		sbt_ebuPUTmxn.clear();
		sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44 = 0;
		sbt_u.clear();
		sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF = 0;
		sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.clear();
		sbt_lTu = 0;
		sbt_KusgtpuZaIATgAk.clear();
		sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.clear();
		sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.clear();
		sbt_LkAKkFiGxO3k4Ss0pQZf71J = 0;
		sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7 = 0;
		sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq = 0;
		sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.push_back(42956);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_dkJ9cmTiX.push_back(3469366865647881974);
		}
		sbt_2 = 3950256899786283824;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.push_back(4011747397);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_s10bx_DHiNTKSHz.push_back(9482174186775536846);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_kJ5wvIeIIsUWTK1CfmfhycP.push_back(1925533313);
		}
		sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM = ")JX%[Z";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_MQbtMyM.push_back(-29);
		}
		sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM = 695032712681401074;
		sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL = 4747;
		sbt_McBHaB3uoc3IMk20fiY = 3079242735;
		sbt_bZSJ0kzetKFAIVjL11u0iofcF = 14853;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.push_back(48);
		}
		sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5 = 12149036628551381336;
		sbt_ebuPUTmxn = "jU32:Gg\"xUq{:iK&jt@CO!Z5C^";
		sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44 = -1820830249;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_u.push_back(21);
		}
		sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF = 2840107051;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.push_back(4288705488683611068);
		}
		sbt_lTu = -8431;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_KusgtpuZaIATgAk.push_back(817520628);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.push_back(64411);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.push_back(21664);
		}
		sbt_LkAKkFiGxO3k4Ss0pQZf71J = 8166471455660029628;
		sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7 = 52754;
		sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq = -1549149551;
		sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3 = -94;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gFaoed8jU0GqChtq6B3S3 *pObject = dynamic_cast<const sbt_gFaoed8jU0GqChtq6B3S3 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.size() != pObject->sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.size(); i++)
		{
			if (sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP[i] != pObject->sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP[i])
			{
				return false;
			}
		}
		if (sbt_dkJ9cmTiX.size() != pObject->sbt_dkJ9cmTiX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dkJ9cmTiX.size(); i++)
		{
			if (sbt_dkJ9cmTiX[i] != pObject->sbt_dkJ9cmTiX[i])
			{
				return false;
			}
		}
		if (sbt_2 != pObject->sbt_2)
		{
			return false;
		}
		if (sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.size() != pObject->sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.size(); i++)
		{
			if (sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9[i] != pObject->sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9[i])
			{
				return false;
			}
		}
		if (sbt_s10bx_DHiNTKSHz.size() != pObject->sbt_s10bx_DHiNTKSHz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s10bx_DHiNTKSHz.size(); i++)
		{
			if (sbt_s10bx_DHiNTKSHz[i] != pObject->sbt_s10bx_DHiNTKSHz[i])
			{
				return false;
			}
		}
		if (sbt_kJ5wvIeIIsUWTK1CfmfhycP.size() != pObject->sbt_kJ5wvIeIIsUWTK1CfmfhycP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kJ5wvIeIIsUWTK1CfmfhycP.size(); i++)
		{
			if (sbt_kJ5wvIeIIsUWTK1CfmfhycP[i] != pObject->sbt_kJ5wvIeIIsUWTK1CfmfhycP[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM.c_str(), pObject->sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM.c_str()))
		{
			return false;
		}
		if (sbt_MQbtMyM.size() != pObject->sbt_MQbtMyM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MQbtMyM.size(); i++)
		{
			if (sbt_MQbtMyM[i] != pObject->sbt_MQbtMyM[i])
			{
				return false;
			}
		}
		if (sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM != pObject->sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM)
		{
			return false;
		}
		if (sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL != pObject->sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL)
		{
			return false;
		}
		if (sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.size() != pObject->sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.size(); i++)
		{
			if (sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G[i] != pObject->sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G[i])
			{
				return false;
			}
		}
		if (sbt_McBHaB3uoc3IMk20fiY != pObject->sbt_McBHaB3uoc3IMk20fiY)
		{
			return false;
		}
		if (sbt_bZSJ0kzetKFAIVjL11u0iofcF != pObject->sbt_bZSJ0kzetKFAIVjL11u0iofcF)
		{
			return false;
		}
		if (sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.size() != pObject->sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.size(); i++)
		{
			if (sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo[i] != pObject->sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo[i])
			{
				return false;
			}
		}
		if (sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5 != pObject->sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_ebuPUTmxn.c_str(), pObject->sbt_ebuPUTmxn.c_str()))
		{
			return false;
		}
		if (sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44 != pObject->sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44)
		{
			return false;
		}
		if (sbt_u.size() != pObject->sbt_u.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_u.size(); i++)
		{
			if (sbt_u[i] != pObject->sbt_u[i])
			{
				return false;
			}
		}
		if (sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF != pObject->sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF)
		{
			return false;
		}
		if (sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.size() != pObject->sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.size(); i++)
		{
			if (sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji[i] != pObject->sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji[i])
			{
				return false;
			}
		}
		if (sbt_lTu != pObject->sbt_lTu)
		{
			return false;
		}
		if (sbt_KusgtpuZaIATgAk.size() != pObject->sbt_KusgtpuZaIATgAk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KusgtpuZaIATgAk.size(); i++)
		{
			if (sbt_KusgtpuZaIATgAk[i] != pObject->sbt_KusgtpuZaIATgAk[i])
			{
				return false;
			}
		}
		if (sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.size() != pObject->sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.size(); i++)
		{
			if (sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR[i] != pObject->sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR[i])
			{
				return false;
			}
		}
		if (sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.size() != pObject->sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.size(); i++)
		{
			if (sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr[i] != pObject->sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr[i])
			{
				return false;
			}
		}
		if (sbt_LkAKkFiGxO3k4Ss0pQZf71J != pObject->sbt_LkAKkFiGxO3k4Ss0pQZf71J)
		{
			return false;
		}
		if (sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7 != pObject->sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7)
		{
			return false;
		}
		if (sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq != pObject->sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq)
		{
			return false;
		}
		if (sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3 != pObject->sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dkJ9cmTiX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dkJ9cmTiX.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s10bx_DHiNTKSHz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s10bx_DHiNTKSHz.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kJ5wvIeIIsUWTK1CfmfhycP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kJ5wvIeIIsUWTK1CfmfhycP.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM", &sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MQbtMyM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MQbtMyM.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_McBHaB3uoc3IMk20fiY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_McBHaB3uoc3IMk20fiY = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bZSJ0kzetKFAIVjL11u0iofcF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bZSJ0kzetKFAIVjL11u0iofcF = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_ebuPUTmxn", &sbt_ebuPUTmxn)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_u")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_u.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lTu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lTu = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KusgtpuZaIATgAk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KusgtpuZaIATgAk.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_LkAKkFiGxO3k4Ss0pQZf71J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LkAKkFiGxO3k4Ss0pQZf71J = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3 = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.begin(); iter != sbt_WUR__tCeLHc1QVNFI7KWmCyXKTwJcka161k83PudWdP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dkJ9cmTiX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_dkJ9cmTiX.begin(); iter != sbt_dkJ9cmTiX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2", (CX::Int64)sbt_2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.begin(); iter != sbt_7BBXO4yXoKea2pYKnalQ6NgOnHGkn3ICKjwV9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s10bx_DHiNTKSHz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_s10bx_DHiNTKSHz.begin(); iter != sbt_s10bx_DHiNTKSHz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kJ5wvIeIIsUWTK1CfmfhycP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_kJ5wvIeIIsUWTK1CfmfhycP.begin(); iter != sbt_kJ5wvIeIIsUWTK1CfmfhycP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM", sbt_VgCfvy5fqNtUzU6jrHhOaiMOkPRBiPFcvKM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MQbtMyM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_MQbtMyM.begin(); iter != sbt_MQbtMyM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM", (CX::Int64)sbt_Jn9eIAE_W0g59BF2jVMy0d41dfnQ9dKdS7Bt_73a2uoMXzdlM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL", (CX::Int64)sbt_1n1454N9H7F4u5SdYKQeIcehzjZxK3YF_sMM0o3ucqgXL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.begin(); iter != sbt_ts4tIi3VWBnTt4Rxd7SdrpnhEF0FIiDik8jTQiOeo1YKVOzsc9G.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_McBHaB3uoc3IMk20fiY", (CX::Int64)sbt_McBHaB3uoc3IMk20fiY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bZSJ0kzetKFAIVjL11u0iofcF", (CX::Int64)sbt_bZSJ0kzetKFAIVjL11u0iofcF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.begin(); iter != sbt_a9fCP5vWZ9hoTIkdccV9lSjCPdclRMrF6e6jcIi9UyA2K2RXNwzoo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5", (CX::Int64)sbt_k0Irql5ngN7mvYJAJL3o9RdhjFBdbXopsvcaHXevlULmuRZpo2d8XhojhwqGQF5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_ebuPUTmxn", sbt_ebuPUTmxn.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44", (CX::Int64)sbt_pCWjF5pIIDji_Yg1U0IGOA8HT9GZE44)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_u")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_u.begin(); iter != sbt_u.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF", (CX::Int64)sbt_yqM4wX6yA9Q6qbAycxnRFccH_WQid_HEEADeXXnAtvl83VF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.begin(); iter != sbt_Z89dQkxNA5diF5u0I21z7yS7rMnKvevGGQYp_3Xji.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lTu", (CX::Int64)sbt_lTu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KusgtpuZaIATgAk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_KusgtpuZaIATgAk.begin(); iter != sbt_KusgtpuZaIATgAk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.begin(); iter != sbt_j4kkvWMEwnSvOLoFjHgYJbS2erwvulO0nKDAhriWR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.begin(); iter != sbt_NL9yFL8SWwK3m5Ijg0L66VM1V0RT_T5lOg0XPJjitJ_p7Vdu6HlU7Fr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LkAKkFiGxO3k4Ss0pQZf71J", (CX::Int64)sbt_LkAKkFiGxO3k4Ss0pQZf71J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7", (CX::Int64)sbt_YePWftM_qOq4Ete4AaPOM7yN8n4u2g36LyBIdmDBWltndQHlc7HIy_NwK2JX7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq", (CX::Int64)sbt_pKfM5NHDOfOf99yqzDUbHONTd8R3Uc1Lq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3", (CX::Int64)sbt_h_ZDBKDjg13Rrt_jA5dKQbNNd31uPthBmr4qR0UvJOr8iZ3)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gFaoed8jU0GqChtq6B3S3>::Type sbt_gFaoed8jU0GqChtq6B3S3Array;

