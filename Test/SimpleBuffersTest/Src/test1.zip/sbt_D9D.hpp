
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2.hpp"


class sbt_D9D : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR;
	CX::Int16 sbt_J34Ig;
	CX::IO::SimpleBuffers::WStringArray sbt_7E9qTrjKepOgMR4PVCF0lhu;
	CX::WString sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h;
	CX::IO::SimpleBuffers::UInt16Array sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ;
	CX::IO::SimpleBuffers::UInt32Array sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN;
	CX::IO::SimpleBuffers::Int16Array sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA;
	CX::Int8 sbt_Q;
	CX::IO::SimpleBuffers::UInt32Array sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp;
	CX::IO::SimpleBuffers::UInt8Array sbt_RbW1gV1pBkXoV6q;
	CX::String sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e;
	CX::Int32 sbt_A;
	CX::Float sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL;
	CX::Int32 sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E;
	CX::IO::SimpleBuffers::UInt8Array sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE;
	CX::Int64 sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN;
	CX::Int16 sbt_qjlVbywJct4MP;
	CX::Float sbt_bOQBE1zX3;
	CX::Bool sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ;
	CX::Int64 sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0;
	CX::IO::SimpleBuffers::Int16Array sbt_f9PXg82weD7nTc9eWIsu6;
	CX::IO::SimpleBuffers::BoolArray sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz;
	CX::IO::SimpleBuffers::WStringArray sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY;
	CX::String sbt_UchIppoBtSRKtH91e8Mms;
	CX::IO::SimpleBuffers::Int64Array sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz;
	CX::Int8 sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw;
	CX::Double sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5;
	CX::IO::SimpleBuffers::UInt8Array sbt_CGb5Z;
	CX::IO::SimpleBuffers::UInt32Array sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA;
	sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 sbt_oAvTc_MA13y49iT7OzZcL6T7hO4;

	virtual void Reset()
	{
		sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.clear();
		sbt_J34Ig = 0;
		sbt_7E9qTrjKepOgMR4PVCF0lhu.clear();
		sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h.clear();
		sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.clear();
		sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.clear();
		sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.clear();
		sbt_Q = 0;
		sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.clear();
		sbt_RbW1gV1pBkXoV6q.clear();
		sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e.clear();
		sbt_A = 0;
		sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL = 0.0f;
		sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E = 0;
		sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.clear();
		sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN = 0;
		sbt_qjlVbywJct4MP = 0;
		sbt_bOQBE1zX3 = 0.0f;
		sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ = false;
		sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0 = 0;
		sbt_f9PXg82weD7nTc9eWIsu6.clear();
		sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.clear();
		sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.clear();
		sbt_UchIppoBtSRKtH91e8Mms.clear();
		sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.clear();
		sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw = 0;
		sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5 = 0.0;
		sbt_CGb5Z.clear();
		sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.clear();
		sbt_oAvTc_MA13y49iT7OzZcL6T7hO4.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.push_back(84);
		}
		sbt_J34Ig = 20240;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_7E9qTrjKepOgMR4PVCF0lhu.push_back(L"}");
		}
		sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h = L"&DUwB/[KZ2mzD-.*u6PbkjG42hsV;\\6L";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.push_back(38211);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.push_back(3475035587);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.push_back(15660);
		}
		sbt_Q = 97;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.push_back(1364433669);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_RbW1gV1pBkXoV6q.push_back(250);
		}
		sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e = ".nIE|+n+";
		sbt_A = 1285950785;
		sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL = 0.870828f;
		sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E = 1362409311;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.push_back(50);
		}
		sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN = -2677550539883527814;
		sbt_qjlVbywJct4MP = -6743;
		sbt_bOQBE1zX3 = 0.738527f;
		sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ = false;
		sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0 = -7293004684883377838;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_f9PXg82weD7nTc9eWIsu6.push_back(4983);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.push_back(true);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.push_back(L"PSfedA/UmpBq&-~4C.0Pt_B$^-dct,ayopCqnb1{Ho2GPWSEsq");
		}
		sbt_UchIppoBtSRKtH91e8Mms = "WV=iuxMd*IoN5$V%NudS@%lV";
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.push_back(-2624330221017524020);
		}
		sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw = -64;
		sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5 = 0.060811;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.push_back(3931933015);
		}
		sbt_oAvTc_MA13y49iT7OzZcL6T7hO4.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_D9D *pObject = dynamic_cast<const sbt_D9D *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.size() != pObject->sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.size(); i++)
		{
			if (sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR[i] != pObject->sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR[i])
			{
				return false;
			}
		}
		if (sbt_J34Ig != pObject->sbt_J34Ig)
		{
			return false;
		}
		if (sbt_7E9qTrjKepOgMR4PVCF0lhu.size() != pObject->sbt_7E9qTrjKepOgMR4PVCF0lhu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7E9qTrjKepOgMR4PVCF0lhu.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_7E9qTrjKepOgMR4PVCF0lhu[i].c_str(), pObject->sbt_7E9qTrjKepOgMR4PVCF0lhu[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h.c_str(), pObject->sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h.c_str()))
		{
			return false;
		}
		if (sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.size() != pObject->sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.size(); i++)
		{
			if (sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ[i] != pObject->sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ[i])
			{
				return false;
			}
		}
		if (sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.size() != pObject->sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.size(); i++)
		{
			if (sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN[i] != pObject->sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN[i])
			{
				return false;
			}
		}
		if (sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.size() != pObject->sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.size(); i++)
		{
			if (sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA[i] != pObject->sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA[i])
			{
				return false;
			}
		}
		if (sbt_Q != pObject->sbt_Q)
		{
			return false;
		}
		if (sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.size() != pObject->sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.size(); i++)
		{
			if (sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp[i] != pObject->sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp[i])
			{
				return false;
			}
		}
		if (sbt_RbW1gV1pBkXoV6q.size() != pObject->sbt_RbW1gV1pBkXoV6q.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RbW1gV1pBkXoV6q.size(); i++)
		{
			if (sbt_RbW1gV1pBkXoV6q[i] != pObject->sbt_RbW1gV1pBkXoV6q[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e.c_str(), pObject->sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e.c_str()))
		{
			return false;
		}
		if (sbt_A != pObject->sbt_A)
		{
			return false;
		}
		if (sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL != pObject->sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL)
		{
			return false;
		}
		if (sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E != pObject->sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E)
		{
			return false;
		}
		if (sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.size() != pObject->sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.size(); i++)
		{
			if (sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE[i] != pObject->sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE[i])
			{
				return false;
			}
		}
		if (sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN != pObject->sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN)
		{
			return false;
		}
		if (sbt_qjlVbywJct4MP != pObject->sbt_qjlVbywJct4MP)
		{
			return false;
		}
		if (sbt_bOQBE1zX3 != pObject->sbt_bOQBE1zX3)
		{
			return false;
		}
		if (sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ != pObject->sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ)
		{
			return false;
		}
		if (sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0 != pObject->sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0)
		{
			return false;
		}
		if (sbt_f9PXg82weD7nTc9eWIsu6.size() != pObject->sbt_f9PXg82weD7nTc9eWIsu6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_f9PXg82weD7nTc9eWIsu6.size(); i++)
		{
			if (sbt_f9PXg82weD7nTc9eWIsu6[i] != pObject->sbt_f9PXg82weD7nTc9eWIsu6[i])
			{
				return false;
			}
		}
		if (sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.size() != pObject->sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.size(); i++)
		{
			if (sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz[i] != pObject->sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz[i])
			{
				return false;
			}
		}
		if (sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.size() != pObject->sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY[i].c_str(), pObject->sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY[i].c_str()))
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_UchIppoBtSRKtH91e8Mms.c_str(), pObject->sbt_UchIppoBtSRKtH91e8Mms.c_str()))
		{
			return false;
		}
		if (sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.size() != pObject->sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.size(); i++)
		{
			if (sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz[i] != pObject->sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz[i])
			{
				return false;
			}
		}
		if (sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw != pObject->sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw)
		{
			return false;
		}
		if (sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5 != pObject->sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5)
		{
			return false;
		}
		if (sbt_CGb5Z.size() != pObject->sbt_CGb5Z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CGb5Z.size(); i++)
		{
			if (sbt_CGb5Z[i] != pObject->sbt_CGb5Z[i])
			{
				return false;
			}
		}
		if (sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.size() != pObject->sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.size(); i++)
		{
			if (sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA[i] != pObject->sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA[i])
			{
				return false;
			}
		}
		if (!sbt_oAvTc_MA13y49iT7OzZcL6T7hO4.Compare(&pObject->sbt_oAvTc_MA13y49iT7OzZcL6T7hO4))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J34Ig", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J34Ig = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7E9qTrjKepOgMR4PVCF0lhu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7E9qTrjKepOgMR4PVCF0lhu.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h", &sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Q", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Q = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RbW1gV1pBkXoV6q")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RbW1gV1pBkXoV6q.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e", &sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_A", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectReal("sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qjlVbywJct4MP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qjlVbywJct4MP = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_bOQBE1zX3", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_bOQBE1zX3 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectBool("sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ", &sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_f9PXg82weD7nTc9eWIsu6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_f9PXg82weD7nTc9eWIsu6.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_UchIppoBtSRKtH91e8Mms", &sbt_UchIppoBtSRKtH91e8Mms)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5 = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_CGb5Z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CGb5Z.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_oAvTc_MA13y49iT7OzZcL6T7hO4")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_oAvTc_MA13y49iT7OzZcL6T7hO4.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.begin(); iter != sbt_xATMAMMrDV3Ne_B3ESqpfiJk9xFuXiKE6JpHSbI1fdCmpV41OxlMiex0XfCzVeR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J34Ig", (CX::Int64)sbt_J34Ig)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7E9qTrjKepOgMR4PVCF0lhu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_7E9qTrjKepOgMR4PVCF0lhu.begin(); iter != sbt_7E9qTrjKepOgMR4PVCF0lhu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h", sbt_x7U5dzaSfiK5lMg2SKfyYdMUZSRd4gOxkjhO5ZXej1_x0E5qv9h.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.begin(); iter != sbt_cvxjRR2SdNdP5NcMCChytVrZ2O69TIHftgscUl5ijATEJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.begin(); iter != sbt_7Pmq5QBQJHBOVMcRGxY775H5ukfcAHCWUQClddN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.begin(); iter != sbt_dYTW9HCf3gdT8dsvPtUihMHPXndnA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Q", (CX::Int64)sbt_Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.begin(); iter != sbt_VQNBHAppidtVQwCLKb_xQ_9ymNECt8QWbKp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RbW1gV1pBkXoV6q")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_RbW1gV1pBkXoV6q.begin(); iter != sbt_RbW1gV1pBkXoV6q.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e", sbt_oXDt03Pd_qhaDqHNx77hs1QibGvrCVN9e.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A", (CX::Int64)sbt_A)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL", (CX::Double)sbt_Jo5XQiWjLNQcSitfrgcyR41WOV9P0P3QnQs8VQL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E", (CX::Int64)sbt_xJaMlyenNZnWApQLayc6aDL4AxNpaXX7WRsvr1ZvLgdm9tMdwzsMsXoOICx_E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.begin(); iter != sbt_GPjARErfodDvXusi_zePXGpJbBFiCjRXTLE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN", (CX::Int64)sbt_vKGtPsSqcslDmEbhqakyP9Es7MlR4jDm83z7QPB6MbeP5PFrglAiaADUVzpMN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qjlVbywJct4MP", (CX::Int64)sbt_qjlVbywJct4MP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_bOQBE1zX3", (CX::Double)sbt_bOQBE1zX3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ", sbt_X2wF2HTA8Aukhiv_V8OwWF8QtPd8e2NXAJRk8vxdBfQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0", (CX::Int64)sbt_wGyGYL5R8X5lmrszrP97FQpbETygJY0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_f9PXg82weD7nTc9eWIsu6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_f9PXg82weD7nTc9eWIsu6.begin(); iter != sbt_f9PXg82weD7nTc9eWIsu6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.begin(); iter != sbt_Wz7wm5KvRnDZ6oHDx0tEUC3CdcCbyMdghfAcsxBHTrUDjyTSOB7X_Wz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.begin(); iter != sbt_72B_D8wFa1MjzcFBefSsgtewsGj315cCKsEBGEL1OMiBZut5mWyS_jbbY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_UchIppoBtSRKtH91e8Mms", sbt_UchIppoBtSRKtH91e8Mms.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.begin(); iter != sbt_5RLe2oVCMrJuMwyaOUd3a5O59mTaHU3cj2Mqz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw", (CX::Int64)sbt_Aj5EZ5bH0l2Tkmj3C4qDuHKmrBxOvqpBZj6omD7kPoxc92cwuQXSw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5", (CX::Double)sbt_jzRfqCXyv6yK2zreSdVb9EAHPoxSmGba5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CGb5Z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_CGb5Z.begin(); iter != sbt_CGb5Z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.begin(); iter != sbt_0aI2p_bzsdNivev2wKyJP3Fn7WFzPpA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_oAvTc_MA13y49iT7OzZcL6T7hO4")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_oAvTc_MA13y49iT7OzZcL6T7hO4.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_D9D>::Type sbt_D9DArray;

