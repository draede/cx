
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW.hpp"


class sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo : public CX::IO::SimpleBuffers::IObject
{
public:

	sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsWArray sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m;

	virtual void Reset()
	{
		sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW v;

			v.SetupWithSomeValues();
			sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo *pObject = dynamic_cast<const sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.size() != pObject->sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.size(); i++)
		{
			if (!sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m[i].Compare(&pObject->sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m")).IsNOK())
		{
			return status;
		}
		for (sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsWArray::const_iterator iter = sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.begin(); iter != sbt_4oPasw0O43eIjBSU393z3puGbzZN5Ilj0yYDp8m.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo>::Type sbt_PEqTCGVLy7zt8zaBpyjcHsJzKooArray;

