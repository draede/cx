
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_q : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC;
	CX::IO::SimpleBuffers::UInt64Array sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr;
	CX::String sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq;
	CX::IO::SimpleBuffers::Int8Array sbt_DUq;
	CX::UInt32 sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3;
	CX::UInt64 sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ;
	CX::Int32 sbt_w1boSuR7QwZQexLXnOSfxuGjCbW;

	virtual void Reset()
	{
		sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC = 0;
		sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.clear();
		sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq.clear();
		sbt_DUq.clear();
		sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3 = 0;
		sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ = 0;
		sbt_w1boSuR7QwZQexLXnOSfxuGjCbW = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC = 267587663;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.push_back(3449451459453488520);
		}
		sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq = "Zk+eO6`fxW:>[y%yU}(\"<5";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_DUq.push_back(-74);
		}
		sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3 = 1350400739;
		sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ = 15198219058896538054;
		sbt_w1boSuR7QwZQexLXnOSfxuGjCbW = 2076599762;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_q *pObject = dynamic_cast<const sbt_q *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC != pObject->sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC)
		{
			return false;
		}
		if (sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.size() != pObject->sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.size(); i++)
		{
			if (sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr[i] != pObject->sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq.c_str(), pObject->sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq.c_str()))
		{
			return false;
		}
		if (sbt_DUq.size() != pObject->sbt_DUq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_DUq.size(); i++)
		{
			if (sbt_DUq[i] != pObject->sbt_DUq[i])
			{
				return false;
			}
		}
		if (sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3 != pObject->sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3)
		{
			return false;
		}
		if (sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ != pObject->sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ)
		{
			return false;
		}
		if (sbt_w1boSuR7QwZQexLXnOSfxuGjCbW != pObject->sbt_w1boSuR7QwZQexLXnOSfxuGjCbW)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq", &sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_DUq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_DUq.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_w1boSuR7QwZQexLXnOSfxuGjCbW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_w1boSuR7QwZQexLXnOSfxuGjCbW = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC", (CX::Int64)sbt_rf5xVgnU1irq_fhKE9ffjHTH7GHchjFTDcg6QoqWGJvvPN_4sI8pDrTfutfHfxC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.begin(); iter != sbt_9i_yo3aGmCim8UmRrdOYKVWrEnf3OcMX4HimJYr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq", sbt_8jxGYi5WptzvHsQeh6naL7uTPcqHLaExTscCXDVaUGVFZIROq.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_DUq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_DUq.begin(); iter != sbt_DUq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3", (CX::Int64)sbt_BIClE54hfuwF7qMpFj4LQ1z9exAL4uGigmT6DEH0ozBdUVpNVlmlK5hBSq3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ", (CX::Int64)sbt_1APzB9bOWjX_zEXHyWh8ZwIxEpQ6z6f87KAkZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_w1boSuR7QwZQexLXnOSfxuGjCbW", (CX::Int64)sbt_w1boSuR7QwZQexLXnOSfxuGjCbW)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_q>::Type sbt_qArray;

