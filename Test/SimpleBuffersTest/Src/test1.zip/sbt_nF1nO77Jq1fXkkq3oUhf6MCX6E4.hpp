
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib.hpp"


class sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_j1QfMBtphme;
	CX::UInt64 sbt_VczERf6oDmh8ELWsSpl2OQO8Y;
	CX::UInt8 sbt_adscPBcnWIeIX;
	CX::Bool sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda;
	CX::WString sbt_lubc7xIIGCnvM;
	CX::IO::SimpleBuffers::StringArray sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t;
	CX::Int8 sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_;
	CX::String sbt_04TFSElpl6BhVDJ_besuc0aiLFZ;
	CX::UInt16 sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7;
	CX::IO::SimpleBuffers::UInt16Array sbt_FcM3so4dJ;
	CX::IO::SimpleBuffers::StringArray sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo;
	CX::IO::SimpleBuffers::FloatArray sbt_Q0ttiZBLM8iHL0X;
	CX::IO::SimpleBuffers::StringArray sbt_9mJ6v2bVDdzVm;
	CX::Int64 sbt_EQUiO28DrdOSN6y;
	CX::IO::SimpleBuffers::Int8Array sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53;
	CX::Int16 sbt_dX7lNVRMf9WU_MwhKqSdHaF1R;
	CX::WString sbt_tvDEojCLAsSqIrMuPjGCt;
	CX::IO::SimpleBuffers::Int64Array sbt__Y4GqPEGU;
	CX::IO::SimpleBuffers::UInt64Array sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET;
	CX::WString sbt_JIFiKc7rJCY2t;
	CX::Bool sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt;
	CX::IO::SimpleBuffers::Int32Array sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr;
	CX::Double sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ;
	CX::IO::SimpleBuffers::BoolArray sbt_uzHL7oxkzk59f;
	CX::UInt64 sbt_t;
	CX::Int64 sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb;
	CX::IO::SimpleBuffers::Int64Array sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b;
	CX::IO::SimpleBuffers::FloatArray sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC;
	sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib sbt_XlTRJ9d;

	virtual void Reset()
	{
		sbt_j1QfMBtphme.clear();
		sbt_VczERf6oDmh8ELWsSpl2OQO8Y = 0;
		sbt_adscPBcnWIeIX = 0;
		sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda = false;
		sbt_lubc7xIIGCnvM.clear();
		sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.clear();
		sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_ = 0;
		sbt_04TFSElpl6BhVDJ_besuc0aiLFZ.clear();
		sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7 = 0;
		sbt_FcM3so4dJ.clear();
		sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.clear();
		sbt_Q0ttiZBLM8iHL0X.clear();
		sbt_9mJ6v2bVDdzVm.clear();
		sbt_EQUiO28DrdOSN6y = 0;
		sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.clear();
		sbt_dX7lNVRMf9WU_MwhKqSdHaF1R = 0;
		sbt_tvDEojCLAsSqIrMuPjGCt.clear();
		sbt__Y4GqPEGU.clear();
		sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.clear();
		sbt_JIFiKc7rJCY2t.clear();
		sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt = false;
		sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.clear();
		sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ = 0.0;
		sbt_uzHL7oxkzk59f.clear();
		sbt_t = 0;
		sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb = 0;
		sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.clear();
		sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.clear();
		sbt_XlTRJ9d.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_j1QfMBtphme.push_back(false);
		}
		sbt_VczERf6oDmh8ELWsSpl2OQO8Y = 16611411245389253284;
		sbt_adscPBcnWIeIX = 31;
		sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda = false;
		sbt_lubc7xIIGCnvM = L"+{rM^Z;c{DW+>/\\?M!<38u%A7v}f";
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.push_back("R^OV.u=W^9t");
		}
		sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_ = -127;
		sbt_04TFSElpl6BhVDJ_besuc0aiLFZ = "l-%`L|%OWo/g]RI;$pH|Yp|jdton[";
		sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7 = 33777;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_FcM3so4dJ.push_back(3477);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.push_back("ipuy>e;(b}5!yK!:Cn41/Lh'?`bYQdR[r");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_Q0ttiZBLM8iHL0X.push_back(0.860971f);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_9mJ6v2bVDdzVm.push_back("#0\"d^|}@](Vw\\o'3LV~w#ffX0-fae6@:2$Tv=hEbV;@&U:C)<{d");
		}
		sbt_EQUiO28DrdOSN6y = -8942927057404028682;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.push_back(-36);
		}
		sbt_dX7lNVRMf9WU_MwhKqSdHaF1R = -30035;
		sbt_tvDEojCLAsSqIrMuPjGCt = L"G_gs<IzGguHOdG`\\a*&w9Xbap'lzD#h&9Bx`akmKpoN/I&EBpZ)lvhlF;";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt__Y4GqPEGU.push_back(-6019879525944406216);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.push_back(98433275276374440);
		}
		sbt_JIFiKc7rJCY2t = L"YVY";
		sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt = true;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.push_back(-1050351061);
		}
		sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ = 0.340021;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_uzHL7oxkzk59f.push_back(false);
		}
		sbt_t = 2949131387231217328;
		sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb = 6496928051663129964;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.push_back(2902169045964924996);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.push_back(0.042893f);
		}
		sbt_XlTRJ9d.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4 *pObject = dynamic_cast<const sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_j1QfMBtphme.size() != pObject->sbt_j1QfMBtphme.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_j1QfMBtphme.size(); i++)
		{
			if (sbt_j1QfMBtphme[i] != pObject->sbt_j1QfMBtphme[i])
			{
				return false;
			}
		}
		if (sbt_VczERf6oDmh8ELWsSpl2OQO8Y != pObject->sbt_VczERf6oDmh8ELWsSpl2OQO8Y)
		{
			return false;
		}
		if (sbt_adscPBcnWIeIX != pObject->sbt_adscPBcnWIeIX)
		{
			return false;
		}
		if (sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda != pObject->sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_lubc7xIIGCnvM.c_str(), pObject->sbt_lubc7xIIGCnvM.c_str()))
		{
			return false;
		}
		if (sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.size() != pObject->sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.size(); i++)
		{
			if (0 != cx_strcmp(sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t[i].c_str(), pObject->sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_ != pObject->sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_04TFSElpl6BhVDJ_besuc0aiLFZ.c_str(), pObject->sbt_04TFSElpl6BhVDJ_besuc0aiLFZ.c_str()))
		{
			return false;
		}
		if (sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7 != pObject->sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7)
		{
			return false;
		}
		if (sbt_FcM3so4dJ.size() != pObject->sbt_FcM3so4dJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FcM3so4dJ.size(); i++)
		{
			if (sbt_FcM3so4dJ[i] != pObject->sbt_FcM3so4dJ[i])
			{
				return false;
			}
		}
		if (sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.size() != pObject->sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.size(); i++)
		{
			if (0 != cx_strcmp(sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo[i].c_str(), pObject->sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Q0ttiZBLM8iHL0X.size() != pObject->sbt_Q0ttiZBLM8iHL0X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q0ttiZBLM8iHL0X.size(); i++)
		{
			if (sbt_Q0ttiZBLM8iHL0X[i] != pObject->sbt_Q0ttiZBLM8iHL0X[i])
			{
				return false;
			}
		}
		if (sbt_9mJ6v2bVDdzVm.size() != pObject->sbt_9mJ6v2bVDdzVm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9mJ6v2bVDdzVm.size(); i++)
		{
			if (0 != cx_strcmp(sbt_9mJ6v2bVDdzVm[i].c_str(), pObject->sbt_9mJ6v2bVDdzVm[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_EQUiO28DrdOSN6y != pObject->sbt_EQUiO28DrdOSN6y)
		{
			return false;
		}
		if (sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.size() != pObject->sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.size(); i++)
		{
			if (sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53[i] != pObject->sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53[i])
			{
				return false;
			}
		}
		if (sbt_dX7lNVRMf9WU_MwhKqSdHaF1R != pObject->sbt_dX7lNVRMf9WU_MwhKqSdHaF1R)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_tvDEojCLAsSqIrMuPjGCt.c_str(), pObject->sbt_tvDEojCLAsSqIrMuPjGCt.c_str()))
		{
			return false;
		}
		if (sbt__Y4GqPEGU.size() != pObject->sbt__Y4GqPEGU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__Y4GqPEGU.size(); i++)
		{
			if (sbt__Y4GqPEGU[i] != pObject->sbt__Y4GqPEGU[i])
			{
				return false;
			}
		}
		if (sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.size() != pObject->sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.size(); i++)
		{
			if (sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET[i] != pObject->sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_JIFiKc7rJCY2t.c_str(), pObject->sbt_JIFiKc7rJCY2t.c_str()))
		{
			return false;
		}
		if (sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt != pObject->sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt)
		{
			return false;
		}
		if (sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.size() != pObject->sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.size(); i++)
		{
			if (sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr[i] != pObject->sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr[i])
			{
				return false;
			}
		}
		if (sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ != pObject->sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ)
		{
			return false;
		}
		if (sbt_uzHL7oxkzk59f.size() != pObject->sbt_uzHL7oxkzk59f.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uzHL7oxkzk59f.size(); i++)
		{
			if (sbt_uzHL7oxkzk59f[i] != pObject->sbt_uzHL7oxkzk59f[i])
			{
				return false;
			}
		}
		if (sbt_t != pObject->sbt_t)
		{
			return false;
		}
		if (sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb != pObject->sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb)
		{
			return false;
		}
		if (sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.size() != pObject->sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.size(); i++)
		{
			if (sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b[i] != pObject->sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b[i])
			{
				return false;
			}
		}
		if (sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.size() != pObject->sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.size(); i++)
		{
			if (sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC[i] != pObject->sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC[i])
			{
				return false;
			}
		}
		if (!sbt_XlTRJ9d.Compare(&pObject->sbt_XlTRJ9d))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_j1QfMBtphme")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_j1QfMBtphme.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VczERf6oDmh8ELWsSpl2OQO8Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VczERf6oDmh8ELWsSpl2OQO8Y = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_adscPBcnWIeIX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_adscPBcnWIeIX = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda", &sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_lubc7xIIGCnvM", &sbt_lubc7xIIGCnvM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_04TFSElpl6BhVDJ_besuc0aiLFZ", &sbt_04TFSElpl6BhVDJ_besuc0aiLFZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FcM3so4dJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FcM3so4dJ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Q0ttiZBLM8iHL0X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q0ttiZBLM8iHL0X.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9mJ6v2bVDdzVm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9mJ6v2bVDdzVm.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EQUiO28DrdOSN6y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EQUiO28DrdOSN6y = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dX7lNVRMf9WU_MwhKqSdHaF1R", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dX7lNVRMf9WU_MwhKqSdHaF1R = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectWString("sbt_tvDEojCLAsSqIrMuPjGCt", &sbt_tvDEojCLAsSqIrMuPjGCt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__Y4GqPEGU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__Y4GqPEGU.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_JIFiKc7rJCY2t", &sbt_JIFiKc7rJCY2t)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt", &sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_uzHL7oxkzk59f")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uzHL7oxkzk59f.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_XlTRJ9d")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_XlTRJ9d.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_j1QfMBtphme")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_j1QfMBtphme.begin(); iter != sbt_j1QfMBtphme.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VczERf6oDmh8ELWsSpl2OQO8Y", (CX::Int64)sbt_VczERf6oDmh8ELWsSpl2OQO8Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_adscPBcnWIeIX", (CX::Int64)sbt_adscPBcnWIeIX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda", sbt_AfcMJm8OXsmCmyeOS05qD2_dvqwEiNxwmar0eLYda)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_lubc7xIIGCnvM", sbt_lubc7xIIGCnvM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.begin(); iter != sbt_xfa1T9vk_SaD9tcyPRsNH8QMW_djQm_6C8t.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_", (CX::Int64)sbt_yne_Q8QAxmQn6rqOwycEgpZByqZJayIB5t1frdRyzX_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_04TFSElpl6BhVDJ_besuc0aiLFZ", sbt_04TFSElpl6BhVDJ_besuc0aiLFZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7", (CX::Int64)sbt_OlMJPAqZqfjN26vCY8CNIt73_mHUADZo1EOe7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FcM3so4dJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_FcM3so4dJ.begin(); iter != sbt_FcM3so4dJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.begin(); iter != sbt_nLuQiGSWjt7u95c6SHxA6LT6HFuSXG2DgsFEQuZyOXCGo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q0ttiZBLM8iHL0X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_Q0ttiZBLM8iHL0X.begin(); iter != sbt_Q0ttiZBLM8iHL0X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9mJ6v2bVDdzVm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_9mJ6v2bVDdzVm.begin(); iter != sbt_9mJ6v2bVDdzVm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EQUiO28DrdOSN6y", (CX::Int64)sbt_EQUiO28DrdOSN6y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.begin(); iter != sbt_vcng2om9OC0PV75_789dYYKn_L9iJv7_H2pl6V4Ug2XGVaqDniQari56H53.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dX7lNVRMf9WU_MwhKqSdHaF1R", (CX::Int64)sbt_dX7lNVRMf9WU_MwhKqSdHaF1R)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_tvDEojCLAsSqIrMuPjGCt", sbt_tvDEojCLAsSqIrMuPjGCt.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__Y4GqPEGU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt__Y4GqPEGU.begin(); iter != sbt__Y4GqPEGU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.begin(); iter != sbt_ct5sSw6RUyaA472ro8ppHJvgogYdYJqJFmDolykSUjht51YqmOueTET.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_JIFiKc7rJCY2t", sbt_JIFiKc7rJCY2t.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt", sbt_GDeYI7jvO0D0OJLq78Z9sLcr8Qu0bJ66FZ0yzP4alDxQS89a6bIxO5M_UdiSt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.begin(); iter != sbt_7JvOtugLpqqDI8u_mXX5TUEbnqTLCRE1E76U7PB5gE870UIbbQzvr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ", (CX::Double)sbt_W3F2Hslvs3hUzFedp16bEvKtAJKgUsDS1a2TWYrkK4oMooAwcaQ8kseo4s3UJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uzHL7oxkzk59f")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_uzHL7oxkzk59f.begin(); iter != sbt_uzHL7oxkzk59f.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t", (CX::Int64)sbt_t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb", (CX::Int64)sbt_etWIYT8IsF1MKgt0pfIUqCCIi3XkuaDNpSqDX9fPwcGphsb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.begin(); iter != sbt_czPWaAdaoFYhvDsdnavu58TRQEk9b.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.begin(); iter != sbt_s2CiqhCqsYXxUxWVhtlps6VzZOCAbq7RUy63dNQkS3XIAHPHmeqazEC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_XlTRJ9d")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_XlTRJ9d.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4>::Type sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4Array;

