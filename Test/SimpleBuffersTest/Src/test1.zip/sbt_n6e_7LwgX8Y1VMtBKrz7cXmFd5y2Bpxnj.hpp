
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD;
	CX::String sbt_RLw;
	CX::Int16 sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2;
	CX::Int32 sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz;
	CX::UInt32 sbt_v6oFxK_IB4eYojj;
	CX::Int16 sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx;
	CX::UInt16 sbt_nhktyqcz2hkE4KKhD;
	CX::Int64 sbt_1BMFn2ESoiWiRduNk8be4;
	CX::IO::SimpleBuffers::Int8Array sbt_PWYI9coE5uCvTcvyFIHctdkf70udx;
	CX::IO::SimpleBuffers::Int16Array sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK;
	CX::UInt32 sbt_QFOnMvAWrE0_gXFh3jxZ30goj;
	CX::Bool sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm;
	CX::Int32 sbt_SeO;
	CX::IO::SimpleBuffers::Int8Array sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu;
	CX::IO::SimpleBuffers::Int32Array sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2;
	CX::IO::SimpleBuffers::StringArray sbt_fPp018aj9VPLG_gBdW9;
	CX::UInt16 sbt_n0fIO7PXJup28aksKDpW6SKHkB0;
	CX::UInt32 sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8;
	CX::UInt16 sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji;
	CX::Int32 sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH;
	CX::IO::SimpleBuffers::UInt32Array sbt_1ak1y0CFBw4Nj3Xi2opxCh7;
	CX::Int32 sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t;
	CX::Int32 sbt_99hc4sEiePfDBBFW_dElo;
	CX::IO::SimpleBuffers::UInt64Array sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn;
	CX::UInt64 sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF;
	CX::Int8 sbt_G4tKolJ7cfFaHyJxOysoTLL9L;
	CX::IO::SimpleBuffers::UInt32Array sbt_FDLzmZiCs5WjfUCWr;

	virtual void Reset()
	{
		sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.clear();
		sbt_RLw.clear();
		sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2 = 0;
		sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz = 0;
		sbt_v6oFxK_IB4eYojj = 0;
		sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx = 0;
		sbt_nhktyqcz2hkE4KKhD = 0;
		sbt_1BMFn2ESoiWiRduNk8be4 = 0;
		sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.clear();
		sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.clear();
		sbt_QFOnMvAWrE0_gXFh3jxZ30goj = 0;
		sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm = false;
		sbt_SeO = 0;
		sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.clear();
		sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.clear();
		sbt_fPp018aj9VPLG_gBdW9.clear();
		sbt_n0fIO7PXJup28aksKDpW6SKHkB0 = 0;
		sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8 = 0;
		sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji = 0;
		sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH = 0;
		sbt_1ak1y0CFBw4Nj3Xi2opxCh7.clear();
		sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t = 0;
		sbt_99hc4sEiePfDBBFW_dElo = 0;
		sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.clear();
		sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF = 0;
		sbt_G4tKolJ7cfFaHyJxOysoTLL9L = 0;
		sbt_FDLzmZiCs5WjfUCWr.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.push_back(-3744);
		}
		sbt_RLw = "dK~kd@jH%!!Fs?OkOi~r}bLT!}(t@ON99ai?M<r-t,PCm72:I>*=(jK]";
		sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2 = -6840;
		sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz = -22791053;
		sbt_v6oFxK_IB4eYojj = 1574971012;
		sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx = -11800;
		sbt_nhktyqcz2hkE4KKhD = 33621;
		sbt_1BMFn2ESoiWiRduNk8be4 = 1392423206031218894;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.push_back(-96);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.push_back(23072);
		}
		sbt_QFOnMvAWrE0_gXFh3jxZ30goj = 3780427920;
		sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm = true;
		sbt_SeO = 1416638434;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.push_back(-100);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.push_back(1758308588);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fPp018aj9VPLG_gBdW9.push_back("2,+D7#5Zd}\\B8\"a8K&hVv9");
		}
		sbt_n0fIO7PXJup28aksKDpW6SKHkB0 = 21648;
		sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8 = 2165122627;
		sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji = 53384;
		sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH = 2086526303;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_1ak1y0CFBw4Nj3Xi2opxCh7.push_back(3616077173);
		}
		sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t = 1950196075;
		sbt_99hc4sEiePfDBBFW_dElo = 3354894;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.push_back(16775886237082477310);
		}
		sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF = 11141059650324847922;
		sbt_G4tKolJ7cfFaHyJxOysoTLL9L = -101;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_FDLzmZiCs5WjfUCWr.push_back(1482850156);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj *pObject = dynamic_cast<const sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.size() != pObject->sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.size(); i++)
		{
			if (sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD[i] != pObject->sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_RLw.c_str(), pObject->sbt_RLw.c_str()))
		{
			return false;
		}
		if (sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2 != pObject->sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2)
		{
			return false;
		}
		if (sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz != pObject->sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz)
		{
			return false;
		}
		if (sbt_v6oFxK_IB4eYojj != pObject->sbt_v6oFxK_IB4eYojj)
		{
			return false;
		}
		if (sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx != pObject->sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx)
		{
			return false;
		}
		if (sbt_nhktyqcz2hkE4KKhD != pObject->sbt_nhktyqcz2hkE4KKhD)
		{
			return false;
		}
		if (sbt_1BMFn2ESoiWiRduNk8be4 != pObject->sbt_1BMFn2ESoiWiRduNk8be4)
		{
			return false;
		}
		if (sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.size() != pObject->sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.size(); i++)
		{
			if (sbt_PWYI9coE5uCvTcvyFIHctdkf70udx[i] != pObject->sbt_PWYI9coE5uCvTcvyFIHctdkf70udx[i])
			{
				return false;
			}
		}
		if (sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.size() != pObject->sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.size(); i++)
		{
			if (sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK[i] != pObject->sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK[i])
			{
				return false;
			}
		}
		if (sbt_QFOnMvAWrE0_gXFh3jxZ30goj != pObject->sbt_QFOnMvAWrE0_gXFh3jxZ30goj)
		{
			return false;
		}
		if (sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm != pObject->sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm)
		{
			return false;
		}
		if (sbt_SeO != pObject->sbt_SeO)
		{
			return false;
		}
		if (sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.size() != pObject->sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.size(); i++)
		{
			if (sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu[i] != pObject->sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu[i])
			{
				return false;
			}
		}
		if (sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.size() != pObject->sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.size(); i++)
		{
			if (sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2[i] != pObject->sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2[i])
			{
				return false;
			}
		}
		if (sbt_fPp018aj9VPLG_gBdW9.size() != pObject->sbt_fPp018aj9VPLG_gBdW9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fPp018aj9VPLG_gBdW9.size(); i++)
		{
			if (0 != cx_strcmp(sbt_fPp018aj9VPLG_gBdW9[i].c_str(), pObject->sbt_fPp018aj9VPLG_gBdW9[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_n0fIO7PXJup28aksKDpW6SKHkB0 != pObject->sbt_n0fIO7PXJup28aksKDpW6SKHkB0)
		{
			return false;
		}
		if (sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8 != pObject->sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8)
		{
			return false;
		}
		if (sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji != pObject->sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji)
		{
			return false;
		}
		if (sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH != pObject->sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH)
		{
			return false;
		}
		if (sbt_1ak1y0CFBw4Nj3Xi2opxCh7.size() != pObject->sbt_1ak1y0CFBw4Nj3Xi2opxCh7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1ak1y0CFBw4Nj3Xi2opxCh7.size(); i++)
		{
			if (sbt_1ak1y0CFBw4Nj3Xi2opxCh7[i] != pObject->sbt_1ak1y0CFBw4Nj3Xi2opxCh7[i])
			{
				return false;
			}
		}
		if (sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t != pObject->sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t)
		{
			return false;
		}
		if (sbt_99hc4sEiePfDBBFW_dElo != pObject->sbt_99hc4sEiePfDBBFW_dElo)
		{
			return false;
		}
		if (sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.size() != pObject->sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.size(); i++)
		{
			if (sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn[i] != pObject->sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn[i])
			{
				return false;
			}
		}
		if (sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF != pObject->sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF)
		{
			return false;
		}
		if (sbt_G4tKolJ7cfFaHyJxOysoTLL9L != pObject->sbt_G4tKolJ7cfFaHyJxOysoTLL9L)
		{
			return false;
		}
		if (sbt_FDLzmZiCs5WjfUCWr.size() != pObject->sbt_FDLzmZiCs5WjfUCWr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FDLzmZiCs5WjfUCWr.size(); i++)
		{
			if (sbt_FDLzmZiCs5WjfUCWr[i] != pObject->sbt_FDLzmZiCs5WjfUCWr[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_RLw", &sbt_RLw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_v6oFxK_IB4eYojj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_v6oFxK_IB4eYojj = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nhktyqcz2hkE4KKhD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nhktyqcz2hkE4KKhD = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1BMFn2ESoiWiRduNk8be4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1BMFn2ESoiWiRduNk8be4 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PWYI9coE5uCvTcvyFIHctdkf70udx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_QFOnMvAWrE0_gXFh3jxZ30goj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QFOnMvAWrE0_gXFh3jxZ30goj = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm", &sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_SeO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SeO = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_fPp018aj9VPLG_gBdW9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fPp018aj9VPLG_gBdW9.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_n0fIO7PXJup28aksKDpW6SKHkB0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_n0fIO7PXJup28aksKDpW6SKHkB0 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1ak1y0CFBw4Nj3Xi2opxCh7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1ak1y0CFBw4Nj3Xi2opxCh7.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_99hc4sEiePfDBBFW_dElo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_99hc4sEiePfDBBFW_dElo = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_G4tKolJ7cfFaHyJxOysoTLL9L", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G4tKolJ7cfFaHyJxOysoTLL9L = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_FDLzmZiCs5WjfUCWr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FDLzmZiCs5WjfUCWr.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.begin(); iter != sbt_d_226tuTktoMPlfUWrmtAgmkdyY4_UetkkY4MPuM7oFPSlZFFx0tzY0v0_WX5YD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_RLw", sbt_RLw.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2", (CX::Int64)sbt_1GQ36UKy4ofBwg5LCjx8ElT39HV3x4NIQWYJ2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz", (CX::Int64)sbt_pvkcSZN76Mh43qpRKS4w1BtW0lHi_iqPavF5KsYEibFvfYcf4D1PX4lcz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_v6oFxK_IB4eYojj", (CX::Int64)sbt_v6oFxK_IB4eYojj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx", (CX::Int64)sbt_XaytkONrpg9WjRsgJZvst7uTwEVDmO5Hx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nhktyqcz2hkE4KKhD", (CX::Int64)sbt_nhktyqcz2hkE4KKhD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1BMFn2ESoiWiRduNk8be4", (CX::Int64)sbt_1BMFn2ESoiWiRduNk8be4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PWYI9coE5uCvTcvyFIHctdkf70udx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.begin(); iter != sbt_PWYI9coE5uCvTcvyFIHctdkf70udx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.begin(); iter != sbt_U5kdngiDIre5h8IZZRSwq0NtQOKRoAb8SVpta5knylUC2FK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QFOnMvAWrE0_gXFh3jxZ30goj", (CX::Int64)sbt_QFOnMvAWrE0_gXFh3jxZ30goj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm", sbt_MktZMTrAXznWL2aaKScytG0knnngqLxwMTU0WfOn2goFm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SeO", (CX::Int64)sbt_SeO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.begin(); iter != sbt_vcetHINm18mY4xKZqZiwjFr5Xx4S4ZaFLCdyEO4Lu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.begin(); iter != sbt_1pjT_xIVN_8e3Z6R2VnmH7n07Mo7GoqMc3aNlc2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fPp018aj9VPLG_gBdW9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_fPp018aj9VPLG_gBdW9.begin(); iter != sbt_fPp018aj9VPLG_gBdW9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_n0fIO7PXJup28aksKDpW6SKHkB0", (CX::Int64)sbt_n0fIO7PXJup28aksKDpW6SKHkB0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8", (CX::Int64)sbt_r61cAChhM63VNv9_QcDNNk599CEwAbOzRG8wQEWxQHYGf9eXqn9s8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji", (CX::Int64)sbt_QjZEIcHFZTGhTJtl1C8hGT89MqeQP_jaFgkFJooji)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH", (CX::Int64)sbt_51eQuUaWXGtsRtA4Rn5AqK_PEJ5eVBH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1ak1y0CFBw4Nj3Xi2opxCh7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1ak1y0CFBw4Nj3Xi2opxCh7.begin(); iter != sbt_1ak1y0CFBw4Nj3Xi2opxCh7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t", (CX::Int64)sbt_w4nDggRXLOAn0wLhGPBCetTVNVk_cpKYFOgprMILtHdg0nIsJLNP4zZSeDY3t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_99hc4sEiePfDBBFW_dElo", (CX::Int64)sbt_99hc4sEiePfDBBFW_dElo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.begin(); iter != sbt_BAS3mWNKWALaC8qzOTLoXhQXUZl2PULomkxoJwMl7Sn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF", (CX::Int64)sbt_dGEvSDD2y7SAjZavNx8bPjjcOHwiaUMhUszi52rWsAhcqZhTA3TNF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G4tKolJ7cfFaHyJxOysoTLL9L", (CX::Int64)sbt_G4tKolJ7cfFaHyJxOysoTLL9L)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FDLzmZiCs5WjfUCWr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FDLzmZiCs5WjfUCWr.begin(); iter != sbt_FDLzmZiCs5WjfUCWr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj>::Type sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2BpxnjArray;

