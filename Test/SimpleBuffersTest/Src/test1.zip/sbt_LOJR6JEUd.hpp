
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_LOJR6JEUd : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ;
	CX::IO::SimpleBuffers::UInt16Array sbt_1iN9Uum1gQqRez_0M;
	CX::Int8 sbt_d;
	CX::UInt64 sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX;
	CX::Int32 sbt_r22oaipJa5krzyiTKvfi38MFSOa;
	CX::Int16 sbt_aXOL6SPFgsU5OdhyHIVFa1y;
	CX::UInt8 sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT;
	CX::IO::SimpleBuffers::Int16Array sbt_s8R6r6ct1;
	CX::String sbt_XM6;
	CX::Int64 sbt_J7wD0DZVZFao1vXqn;
	CX::Bool sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb;
	CX::IO::SimpleBuffers::BoolArray sbt_Guq3eJNhPbc;

	virtual void Reset()
	{
		sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ.clear();
		sbt_1iN9Uum1gQqRez_0M.clear();
		sbt_d = 0;
		sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX = 0;
		sbt_r22oaipJa5krzyiTKvfi38MFSOa = 0;
		sbt_aXOL6SPFgsU5OdhyHIVFa1y = 0;
		sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT = 0;
		sbt_s8R6r6ct1.clear();
		sbt_XM6.clear();
		sbt_J7wD0DZVZFao1vXqn = 0;
		sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb = false;
		sbt_Guq3eJNhPbc.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ = "V2NdE:T9K:2kMBH^Pwkua5qSayChiZ1yd.";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_1iN9Uum1gQqRez_0M.push_back(50960);
		}
		sbt_d = -65;
		sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX = 16322309931744016864;
		sbt_r22oaipJa5krzyiTKvfi38MFSOa = -421044854;
		sbt_aXOL6SPFgsU5OdhyHIVFa1y = -9555;
		sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT = 168;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_s8R6r6ct1.push_back(-9706);
		}
		sbt_XM6 = "Vp}Q";
		sbt_J7wD0DZVZFao1vXqn = 4470465514406100804;
		sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb = true;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Guq3eJNhPbc.push_back(true);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_LOJR6JEUd *pObject = dynamic_cast<const sbt_LOJR6JEUd *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ.c_str(), pObject->sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ.c_str()))
		{
			return false;
		}
		if (sbt_1iN9Uum1gQqRez_0M.size() != pObject->sbt_1iN9Uum1gQqRez_0M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1iN9Uum1gQqRez_0M.size(); i++)
		{
			if (sbt_1iN9Uum1gQqRez_0M[i] != pObject->sbt_1iN9Uum1gQqRez_0M[i])
			{
				return false;
			}
		}
		if (sbt_d != pObject->sbt_d)
		{
			return false;
		}
		if (sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX != pObject->sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX)
		{
			return false;
		}
		if (sbt_r22oaipJa5krzyiTKvfi38MFSOa != pObject->sbt_r22oaipJa5krzyiTKvfi38MFSOa)
		{
			return false;
		}
		if (sbt_aXOL6SPFgsU5OdhyHIVFa1y != pObject->sbt_aXOL6SPFgsU5OdhyHIVFa1y)
		{
			return false;
		}
		if (sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT != pObject->sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT)
		{
			return false;
		}
		if (sbt_s8R6r6ct1.size() != pObject->sbt_s8R6r6ct1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s8R6r6ct1.size(); i++)
		{
			if (sbt_s8R6r6ct1[i] != pObject->sbt_s8R6r6ct1[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_XM6.c_str(), pObject->sbt_XM6.c_str()))
		{
			return false;
		}
		if (sbt_J7wD0DZVZFao1vXqn != pObject->sbt_J7wD0DZVZFao1vXqn)
		{
			return false;
		}
		if (sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb != pObject->sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb)
		{
			return false;
		}
		if (sbt_Guq3eJNhPbc.size() != pObject->sbt_Guq3eJNhPbc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Guq3eJNhPbc.size(); i++)
		{
			if (sbt_Guq3eJNhPbc[i] != pObject->sbt_Guq3eJNhPbc[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ", &sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1iN9Uum1gQqRez_0M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1iN9Uum1gQqRez_0M.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_d = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_r22oaipJa5krzyiTKvfi38MFSOa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r22oaipJa5krzyiTKvfi38MFSOa = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_aXOL6SPFgsU5OdhyHIVFa1y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aXOL6SPFgsU5OdhyHIVFa1y = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_s8R6r6ct1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s8R6r6ct1.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_XM6", &sbt_XM6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_J7wD0DZVZFao1vXqn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_J7wD0DZVZFao1vXqn = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb", &sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Guq3eJNhPbc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Guq3eJNhPbc.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ", sbt_Ot1pjaFhBCwU2Iw5pEhhyuhEWJNzQ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1iN9Uum1gQqRez_0M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_1iN9Uum1gQqRez_0M.begin(); iter != sbt_1iN9Uum1gQqRez_0M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_d", (CX::Int64)sbt_d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX", (CX::Int64)sbt_HfGhmqn6e5RY5wY3rxn16RL0jpY8BmtwbdX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_r22oaipJa5krzyiTKvfi38MFSOa", (CX::Int64)sbt_r22oaipJa5krzyiTKvfi38MFSOa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aXOL6SPFgsU5OdhyHIVFa1y", (CX::Int64)sbt_aXOL6SPFgsU5OdhyHIVFa1y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT", (CX::Int64)sbt_ZbOkw_kFTgrKGQBPT1gMInIvEjoEuu_NpfiY7wT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s8R6r6ct1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_s8R6r6ct1.begin(); iter != sbt_s8R6r6ct1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_XM6", sbt_XM6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_J7wD0DZVZFao1vXqn", (CX::Int64)sbt_J7wD0DZVZFao1vXqn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb", sbt_ZHOvdfx9XpabyDAuE4lBlVvZObPQv_CoBopVb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Guq3eJNhPbc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Guq3eJNhPbc.begin(); iter != sbt_Guq3eJNhPbc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_LOJR6JEUd>::Type sbt_LOJR6JEUdArray;

