
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Okt : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_nDuh2;
	CX::Int8 sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky;
	CX::Int32 sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g;
	CX::IO::SimpleBuffers::UInt32Array sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S;
	CX::Bool sbt_2EspDVTHlYZYi;

	virtual void Reset()
	{
		sbt_nDuh2 = 0;
		sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky = 0;
		sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g = 0;
		sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.clear();
		sbt_2EspDVTHlYZYi = false;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_nDuh2 = 413031245;
		sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky = 95;
		sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g = 1924528608;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.push_back(684461187);
		}
		sbt_2EspDVTHlYZYi = true;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Okt *pObject = dynamic_cast<const sbt_Okt *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_nDuh2 != pObject->sbt_nDuh2)
		{
			return false;
		}
		if (sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky != pObject->sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky)
		{
			return false;
		}
		if (sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g != pObject->sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g)
		{
			return false;
		}
		if (sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.size() != pObject->sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.size(); i++)
		{
			if (sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S[i] != pObject->sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S[i])
			{
				return false;
			}
		}
		if (sbt_2EspDVTHlYZYi != pObject->sbt_2EspDVTHlYZYi)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_nDuh2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nDuh2 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_2EspDVTHlYZYi", &sbt_2EspDVTHlYZYi)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_nDuh2", (CX::Int64)sbt_nDuh2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky", (CX::Int64)sbt_zL_89f2_3WZaivj4lxYAjlWbFLpQ6FR5TakUBJg8jIDIxyUbSyon3ky)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g", (CX::Int64)sbt_8cZxxYwL2njTYunIGgyb5EOyhKeej_g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.begin(); iter != sbt_ln8qjWVU1DhqK8F9ztNOpHkTT6S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_2EspDVTHlYZYi", sbt_2EspDVTHlYZYi)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Okt>::Type sbt_OktArray;

