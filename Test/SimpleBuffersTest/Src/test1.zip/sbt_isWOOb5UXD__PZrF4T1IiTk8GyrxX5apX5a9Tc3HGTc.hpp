
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH.hpp"


class sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::FloatArray sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ;
	CX::IO::SimpleBuffers::UInt64Array sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN;
	CX::IO::SimpleBuffers::UInt32Array sbt_i9Nm9Cao8t7;
	sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I;

	virtual void Reset()
	{
		sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.clear();
		sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.clear();
		sbt_i9Nm9Cao8t7.clear();
		sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.push_back(0.894506f);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.push_back(11775457005968799412);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_i9Nm9Cao8t7.push_back(1595273471);
		}
		sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc *pObject = dynamic_cast<const sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.size() != pObject->sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.size(); i++)
		{
			if (sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ[i] != pObject->sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ[i])
			{
				return false;
			}
		}
		if (sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.size() != pObject->sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.size(); i++)
		{
			if (sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN[i] != pObject->sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN[i])
			{
				return false;
			}
		}
		if (sbt_i9Nm9Cao8t7.size() != pObject->sbt_i9Nm9Cao8t7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i9Nm9Cao8t7.size(); i++)
		{
			if (sbt_i9Nm9Cao8t7[i] != pObject->sbt_i9Nm9Cao8t7[i])
			{
				return false;
			}
		}
		if (!sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I.Compare(&pObject->sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_i9Nm9Cao8t7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_i9Nm9Cao8t7.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.begin(); iter != sbt_NKsthE9mhAWFpb52XMkp0lOJnpeaE4rqY4JBwyZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.begin(); iter != sbt_i9oMro9a9SlnQgvUDDNTLJatqBZSUw2pLkRMbDew46pLeSaPt3f45kcdxM8aN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i9Nm9Cao8t7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_i9Nm9Cao8t7.begin(); iter != sbt_i9Nm9Cao8t7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_srnSGSM89SGwTu6sYwGUI4K_PjViezBIvYUut4ckC7I.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc>::Type sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTcArray;

