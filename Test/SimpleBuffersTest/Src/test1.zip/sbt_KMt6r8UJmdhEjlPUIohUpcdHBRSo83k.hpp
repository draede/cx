
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz.hpp"


class sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU;
	CX::UInt32 sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G;
	CX::IO::SimpleBuffers::Int32Array sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l;
	CX::UInt16 sbt_bmT;
	CX::IO::SimpleBuffers::UInt8Array sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD;
	CX::WString sbt_pfPlheK9wrX;
	CX::Double sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt;
	CX::IO::SimpleBuffers::UInt16Array sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw;
	CX::WString sbt__I7iKYhLagdLi52;
	CX::UInt8 sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB;
	CX::IO::SimpleBuffers::UInt16Array sbt_bV_rlZNVQ8xwFx2vRpW17DcNf;
	sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP;

	virtual void Reset()
	{
		sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU = 0;
		sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G = 0;
		sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.clear();
		sbt_bmT = 0;
		sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.clear();
		sbt_pfPlheK9wrX.clear();
		sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt = 0.0;
		sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.clear();
		sbt__I7iKYhLagdLi52.clear();
		sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB = 0;
		sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.clear();
		sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU = 151;
		sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G = 4005486009;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.push_back(932275901);
		}
		sbt_bmT = 4218;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.push_back(178);
		}
		sbt_pfPlheK9wrX = L"[9{m3K<}(D,[5I;{A:F0B%,qb3V3|iXs^mA;@'8aGV#9N8s-_Y]<qOSWf";
		sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt = 0.392653;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.push_back(53276);
		}
		sbt__I7iKYhLagdLi52 = L"Nlz05Ch,$hgk).s!2KE0n~VS)$Cf2=_[g_F,,d2|6R@4";
		sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB = 117;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.push_back(33460);
		}
		sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k *pObject = dynamic_cast<const sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU != pObject->sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU)
		{
			return false;
		}
		if (sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G != pObject->sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G)
		{
			return false;
		}
		if (sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.size() != pObject->sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.size(); i++)
		{
			if (sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l[i] != pObject->sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l[i])
			{
				return false;
			}
		}
		if (sbt_bmT != pObject->sbt_bmT)
		{
			return false;
		}
		if (sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.size() != pObject->sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.size(); i++)
		{
			if (sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD[i] != pObject->sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_pfPlheK9wrX.c_str(), pObject->sbt_pfPlheK9wrX.c_str()))
		{
			return false;
		}
		if (sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt != pObject->sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt)
		{
			return false;
		}
		if (sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.size() != pObject->sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.size(); i++)
		{
			if (sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw[i] != pObject->sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt__I7iKYhLagdLi52.c_str(), pObject->sbt__I7iKYhLagdLi52.c_str()))
		{
			return false;
		}
		if (sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB != pObject->sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB)
		{
			return false;
		}
		if (sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.size() != pObject->sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.size(); i++)
		{
			if (sbt_bV_rlZNVQ8xwFx2vRpW17DcNf[i] != pObject->sbt_bV_rlZNVQ8xwFx2vRpW17DcNf[i])
			{
				return false;
			}
		}
		if (!sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP.Compare(&pObject->sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bmT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bmT = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_pfPlheK9wrX", &sbt_pfPlheK9wrX)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt__I7iKYhLagdLi52", &sbt__I7iKYhLagdLi52)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bV_rlZNVQ8xwFx2vRpW17DcNf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU", (CX::Int64)sbt_VZZKF3vn3c0u0_hHGNORcsOtTsmDLSJspjvDmYDZG9FPJrHxU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G", (CX::Int64)sbt_YTXl0_vbMu1c4QtOEUPwc9pNSCYZvJ5fKomGD5KYieB8rei6fXXm93W6G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.begin(); iter != sbt_c00EgZ0tk86lF9uf1TzUlBPDAjt4jcg4ANDY32uPsULo3da3Ipv5l.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bmT", (CX::Int64)sbt_bmT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.begin(); iter != sbt_9OB4m0wzhYyq__rPoHp2o0q8Z0oHLoh0qZhBI6bIMHDyj3NXD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_pfPlheK9wrX", sbt_pfPlheK9wrX.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt", (CX::Double)sbt_Q0vDqzjqQmFn7jEFdRZkwyYAj4hBySQXsUMjt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.begin(); iter != sbt_mt510tXUHevnsM_BZZ2_cEGfSuqYrZVwaxmNw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt__I7iKYhLagdLi52", sbt__I7iKYhLagdLi52.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB", (CX::Int64)sbt_l5uzPkJ2ubKFeMuf2Tos4FOid_oBJiU7QnB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bV_rlZNVQ8xwFx2vRpW17DcNf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.begin(); iter != sbt_bV_rlZNVQ8xwFx2vRpW17DcNf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_LCJqka5SFt5bl_9OGAvj7VvQxEjWYxSXpu7SER1wvughQgyNIUP.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k>::Type sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83kArray;

