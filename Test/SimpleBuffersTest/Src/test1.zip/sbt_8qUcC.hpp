
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jVSCkaD5dp1.hpp"


class sbt_8qUcC : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj;
	CX::IO::SimpleBuffers::WStringArray sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0;
	CX::IO::SimpleBuffers::UInt16Array sbt_s;
	CX::IO::SimpleBuffers::UInt16Array sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7;
	CX::UInt8 sbt_EVkfM7CDQZzQvx2;
	CX::IO::SimpleBuffers::DoubleArray sbt_J;
	CX::IO::SimpleBuffers::UInt32Array sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY;
	CX::IO::SimpleBuffers::Int16Array sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx;
	CX::UInt64 sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ;
	CX::Bool sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL;
	CX::UInt32 sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY;
	CX::UInt32 sbt_FkSN29JaHPwx9u9QXvna3;
	CX::Int64 sbt_aP1;
	CX::IO::SimpleBuffers::UInt8Array sbt_10Krn;
	CX::Bool sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e;
	CX::Int8 sbt_G;
	CX::IO::SimpleBuffers::StringArray sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo;
	CX::IO::SimpleBuffers::StringArray sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH;
	CX::UInt16 sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq;
	sbt_jVSCkaD5dp1Array sbt_i;

	virtual void Reset()
	{
		sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj = 0;
		sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.clear();
		sbt_s.clear();
		sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.clear();
		sbt_EVkfM7CDQZzQvx2 = 0;
		sbt_J.clear();
		sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.clear();
		sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.clear();
		sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ = 0;
		sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL = false;
		sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY = 0;
		sbt_FkSN29JaHPwx9u9QXvna3 = 0;
		sbt_aP1 = 0;
		sbt_10Krn.clear();
		sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e = false;
		sbt_G = 0;
		sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.clear();
		sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.clear();
		sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq = 0;
		sbt_i.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj = -1139788972;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.push_back(L"sarGAVa(]*YVA~lLYiUGi|W|N\\gZ}3`YTb2;p?.fW[n7d2%]w/867a]xG)^zrZz");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_s.push_back(9776);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.push_back(59179);
		}
		sbt_EVkfM7CDQZzQvx2 = 242;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_J.push_back(0.711833);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.push_back(1790605115);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.push_back(11101);
		}
		sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ = 11872536247728255838;
		sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL = false;
		sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY = 3511478602;
		sbt_FkSN29JaHPwx9u9QXvna3 = 4280641944;
		sbt_aP1 = 6251223406531406022;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_10Krn.push_back(33);
		}
		sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e = true;
		sbt_G = 9;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.push_back("RN',oJjy\"*6)R{b&8R6-0_<fu;2!`T~$m>n$kt3<9P+)TNog3$$9VU");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.push_back("/ldpwrPt7uHvwjK7]JM8]!3O&d3CbX");
		}
		sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq = 6776;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_jVSCkaD5dp1 v;

			v.SetupWithSomeValues();
			sbt_i.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8qUcC *pObject = dynamic_cast<const sbt_8qUcC *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj != pObject->sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj)
		{
			return false;
		}
		if (sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.size() != pObject->sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0[i].c_str(), pObject->sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_s.size() != pObject->sbt_s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s.size(); i++)
		{
			if (sbt_s[i] != pObject->sbt_s[i])
			{
				return false;
			}
		}
		if (sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.size() != pObject->sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.size(); i++)
		{
			if (sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7[i] != pObject->sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7[i])
			{
				return false;
			}
		}
		if (sbt_EVkfM7CDQZzQvx2 != pObject->sbt_EVkfM7CDQZzQvx2)
		{
			return false;
		}
		if (sbt_J.size() != pObject->sbt_J.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_J.size(); i++)
		{
			if (sbt_J[i] != pObject->sbt_J[i])
			{
				return false;
			}
		}
		if (sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.size() != pObject->sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.size(); i++)
		{
			if (sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY[i] != pObject->sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY[i])
			{
				return false;
			}
		}
		if (sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.size() != pObject->sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.size(); i++)
		{
			if (sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx[i] != pObject->sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx[i])
			{
				return false;
			}
		}
		if (sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ != pObject->sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ)
		{
			return false;
		}
		if (sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL != pObject->sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL)
		{
			return false;
		}
		if (sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY != pObject->sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY)
		{
			return false;
		}
		if (sbt_FkSN29JaHPwx9u9QXvna3 != pObject->sbt_FkSN29JaHPwx9u9QXvna3)
		{
			return false;
		}
		if (sbt_aP1 != pObject->sbt_aP1)
		{
			return false;
		}
		if (sbt_10Krn.size() != pObject->sbt_10Krn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_10Krn.size(); i++)
		{
			if (sbt_10Krn[i] != pObject->sbt_10Krn[i])
			{
				return false;
			}
		}
		if (sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e != pObject->sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e)
		{
			return false;
		}
		if (sbt_G != pObject->sbt_G)
		{
			return false;
		}
		if (sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.size() != pObject->sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.size(); i++)
		{
			if (0 != cx_strcmp(sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo[i].c_str(), pObject->sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.size() != pObject->sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.size(); i++)
		{
			if (0 != cx_strcmp(sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH[i].c_str(), pObject->sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq != pObject->sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq)
		{
			return false;
		}
		if (sbt_i.size() != pObject->sbt_i.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_i.size(); i++)
		{
			if (!sbt_i[i].Compare(&pObject->sbt_i[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EVkfM7CDQZzQvx2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EVkfM7CDQZzQvx2 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_J")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_J.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL", &sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_FkSN29JaHPwx9u9QXvna3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FkSN29JaHPwx9u9QXvna3 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_aP1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aP1 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_10Krn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_10Krn.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e", &sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_i")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_jVSCkaD5dp1 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_i.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj", (CX::Int64)sbt_KGlRwvagElnBGxO3GwV0Ol5YCLxNogk94BKQgE_FlqjJS_8TFRj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.begin(); iter != sbt_1sSupuPYyyJGf9O2Y1oRiU2U4rgPNEZD0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_s.begin(); iter != sbt_s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.begin(); iter != sbt_F5iChGFuFoP1HqJ1D5QhTYOzQJNwGyaI6bQabv6yC4VW7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EVkfM7CDQZzQvx2", (CX::Int64)sbt_EVkfM7CDQZzQvx2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_J")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_J.begin(); iter != sbt_J.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.begin(); iter != sbt_9psDdasMRd0tW8_IXqA87dCyLNEiCO4AzzLcHu72v5DdwF0xMBISjFY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.begin(); iter != sbt_MduoOdIr1y1JarkD1oyawfWw60y0PPGczQzXLZ8GweuylSUEJbXgOLWs5Hx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ", (CX::Int64)sbt_kzCcCg2PWMysVVwbmVTeRfeoMCJY0uvmGN7QA7w640wcNmO6qbUcapVPZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL", sbt_zzRBUNhd8govAxG1ImA1izF3Zv07pREm_v4iypFQntGZOPiqNL4EobyJ1SHC3yL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY", (CX::Int64)sbt_VS17o6ze94Yka7_PgxG6nYfmQbcitnjDY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FkSN29JaHPwx9u9QXvna3", (CX::Int64)sbt_FkSN29JaHPwx9u9QXvna3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aP1", (CX::Int64)sbt_aP1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_10Krn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_10Krn.begin(); iter != sbt_10Krn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e", sbt_4DNwNymKlm0f9tcnlwOt39dzqGAzqtgk3RC8DtVjuhz5e)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G", (CX::Int64)sbt_G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.begin(); iter != sbt_SNWzArk9ZDyENw6mZBCgKBhvONUPponSeZGyRWkIPldI1sjnePo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.begin(); iter != sbt_HOYcccp_bv6snw8Zu4_f3kO6xTjgb09d_iH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq", (CX::Int64)sbt_7Sg16fJy_L6ALfx_ZFIHLQc5YqGjlMviZict4l_rJuaqK0EZZ2K3wqOPq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_i")).IsNOK())
		{
			return status;
		}
		for (sbt_jVSCkaD5dp1Array::const_iterator iter = sbt_i.begin(); iter != sbt_i.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8qUcC>::Type sbt_8qUcCArray;

