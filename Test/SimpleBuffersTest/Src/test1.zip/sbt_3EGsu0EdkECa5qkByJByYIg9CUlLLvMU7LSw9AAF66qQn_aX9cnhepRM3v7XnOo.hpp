
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_;
	CX::Bool sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA;
	CX::UInt8 sbt_f40rfWdBn;
	CX::IO::SimpleBuffers::UInt32Array sbt_PnQjPhl;
	CX::IO::SimpleBuffers::UInt64Array sbt_rgU0T;
	CX::IO::SimpleBuffers::Int32Array sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY;
	CX::IO::SimpleBuffers::UInt32Array sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU;
	CX::UInt16 sbt_FjCLE_E;
	CX::IO::SimpleBuffers::UInt64Array sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN;
	CX::Int8 sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6;
	CX::IO::SimpleBuffers::Int8Array sbt_Y_iwBSq;
	CX::Int16 sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ;
	CX::IO::SimpleBuffers::UInt32Array sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS;
	CX::Int8 sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ;
	CX::IO::SimpleBuffers::UInt32Array sbt_4SU;
	CX::IO::SimpleBuffers::Int16Array sbt_rWIM8_j;

	virtual void Reset()
	{
		sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_ = 0;
		sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA = false;
		sbt_f40rfWdBn = 0;
		sbt_PnQjPhl.clear();
		sbt_rgU0T.clear();
		sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.clear();
		sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.clear();
		sbt_FjCLE_E = 0;
		sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.clear();
		sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6 = 0;
		sbt_Y_iwBSq.clear();
		sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ = 0;
		sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.clear();
		sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ = 0;
		sbt_4SU.clear();
		sbt_rWIM8_j.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_ = 3430518205;
		sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA = true;
		sbt_f40rfWdBn = 137;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_PnQjPhl.push_back(2285085946);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_rgU0T.push_back(13283556658864806232);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.push_back(1283652732);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.push_back(1590305126);
		}
		sbt_FjCLE_E = 58338;
		sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6 = 100;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Y_iwBSq.push_back(-100);
		}
		sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ = 13447;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.push_back(4250276038);
		}
		sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ = 123;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_4SU.push_back(3422318847);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_rWIM8_j.push_back(-29382);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo *pObject = dynamic_cast<const sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_ != pObject->sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_)
		{
			return false;
		}
		if (sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA != pObject->sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA)
		{
			return false;
		}
		if (sbt_f40rfWdBn != pObject->sbt_f40rfWdBn)
		{
			return false;
		}
		if (sbt_PnQjPhl.size() != pObject->sbt_PnQjPhl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PnQjPhl.size(); i++)
		{
			if (sbt_PnQjPhl[i] != pObject->sbt_PnQjPhl[i])
			{
				return false;
			}
		}
		if (sbt_rgU0T.size() != pObject->sbt_rgU0T.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rgU0T.size(); i++)
		{
			if (sbt_rgU0T[i] != pObject->sbt_rgU0T[i])
			{
				return false;
			}
		}
		if (sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.size() != pObject->sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.size(); i++)
		{
			if (sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY[i] != pObject->sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY[i])
			{
				return false;
			}
		}
		if (sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.size() != pObject->sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.size(); i++)
		{
			if (sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU[i] != pObject->sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU[i])
			{
				return false;
			}
		}
		if (sbt_FjCLE_E != pObject->sbt_FjCLE_E)
		{
			return false;
		}
		if (sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.size() != pObject->sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.size(); i++)
		{
			if (sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN[i] != pObject->sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN[i])
			{
				return false;
			}
		}
		if (sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6 != pObject->sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6)
		{
			return false;
		}
		if (sbt_Y_iwBSq.size() != pObject->sbt_Y_iwBSq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Y_iwBSq.size(); i++)
		{
			if (sbt_Y_iwBSq[i] != pObject->sbt_Y_iwBSq[i])
			{
				return false;
			}
		}
		if (sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ != pObject->sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ)
		{
			return false;
		}
		if (sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.size() != pObject->sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.size(); i++)
		{
			if (sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS[i] != pObject->sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS[i])
			{
				return false;
			}
		}
		if (sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ != pObject->sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ)
		{
			return false;
		}
		if (sbt_4SU.size() != pObject->sbt_4SU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4SU.size(); i++)
		{
			if (sbt_4SU[i] != pObject->sbt_4SU[i])
			{
				return false;
			}
		}
		if (sbt_rWIM8_j.size() != pObject->sbt_rWIM8_j.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rWIM8_j.size(); i++)
		{
			if (sbt_rWIM8_j[i] != pObject->sbt_rWIM8_j[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA", &sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_f40rfWdBn", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_f40rfWdBn = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PnQjPhl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PnQjPhl.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rgU0T")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rgU0T.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_FjCLE_E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_FjCLE_E = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Y_iwBSq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Y_iwBSq.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4SU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4SU.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rWIM8_j")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rWIM8_j.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_", (CX::Int64)sbt_dpxXebJHBBoYbbJJH1GujzOxQW70SGn8yK_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA", sbt_vWXZGW_cT60tiMf4mdZMmnzHAb37IcJGVJqDuGLpYqIkiVrsqqA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_f40rfWdBn", (CX::Int64)sbt_f40rfWdBn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PnQjPhl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_PnQjPhl.begin(); iter != sbt_PnQjPhl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rgU0T")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_rgU0T.begin(); iter != sbt_rgU0T.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.begin(); iter != sbt_PvMzJbKIfRyl7GpAFDUid5uVgfhNpsVmY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.begin(); iter != sbt_QwGca8ztC9k6wMcxnN50hbIa6Q7jhCU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_FjCLE_E", (CX::Int64)sbt_FjCLE_E)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.begin(); iter != sbt_BHSEJXkSqxZgFXMYDAUSHC9d0PN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6", (CX::Int64)sbt_gPoAh18v7FKknJiDZUGIO14fRRa1dSDc4Ypr6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Y_iwBSq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Y_iwBSq.begin(); iter != sbt_Y_iwBSq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ", (CX::Int64)sbt_6Waq8ZQw0lg90iLzPhTqVK6YMKRlbzJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.begin(); iter != sbt_iK3N1KlQMoZmhJWLuzK8DBPuRdGLEsQeC919HP76KVE8RPXVoqs1gl8sS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ", (CX::Int64)sbt_HikO3YNynP9MTqZ5J2xlapVEPvTW85kDLQ3GYW1zzj2s0MSmQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4SU")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_4SU.begin(); iter != sbt_4SU.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rWIM8_j")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_rWIM8_j.begin(); iter != sbt_rWIM8_j.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo>::Type sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOoArray;

