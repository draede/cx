
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv.hpp"


class sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF;
	CX::UInt64 sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ;
	CX::UInt8 sbt_sE5NRj_M3BZj1dLRP54;
	CX::Bool sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m;
	CX::IO::SimpleBuffers::UInt64Array sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk;
	CX::WString sbt_7nSvCdutL4kvX9_Nx;
	CX::IO::SimpleBuffers::UInt8Array sbt_PkgGbHJdPDCZDQ5gQymxT;
	CX::IO::SimpleBuffers::UInt8Array sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF;
	CX::UInt16 sbt_soN7APRXliqxAXHqSUuIeEKKm;
	CX::UInt16 sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa;
	CX::Float sbt_zwMvt83RXgu8b3LPp;
	CX::WString sbt_fS0lugikO0aMKg6TXZ5;
	CX::Double sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs;
	CX::UInt8 sbt_RKk0NPZ2VDoHMiR9m8l_mL7;
	sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr;

	virtual void Reset()
	{
		sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF = 0;
		sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ = 0;
		sbt_sE5NRj_M3BZj1dLRP54 = 0;
		sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m = false;
		sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.clear();
		sbt_7nSvCdutL4kvX9_Nx.clear();
		sbt_PkgGbHJdPDCZDQ5gQymxT.clear();
		sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.clear();
		sbt_soN7APRXliqxAXHqSUuIeEKKm = 0;
		sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa = 0;
		sbt_zwMvt83RXgu8b3LPp = 0.0f;
		sbt_fS0lugikO0aMKg6TXZ5.clear();
		sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs = 0.0;
		sbt_RKk0NPZ2VDoHMiR9m8l_mL7 = 0;
		sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF = 14159;
		sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ = 8795234844615262262;
		sbt_sE5NRj_M3BZj1dLRP54 = 90;
		sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m = true;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.push_back(16928512119174768228);
		}
		sbt_7nSvCdutL4kvX9_Nx = L"M>WhVr+3AX/n1-$i`hbh[gsBs6nro&cXP:-D*glUFv)cdQP%^";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_PkgGbHJdPDCZDQ5gQymxT.push_back(230);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.push_back(108);
		}
		sbt_soN7APRXliqxAXHqSUuIeEKKm = 59927;
		sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa = 59142;
		sbt_zwMvt83RXgu8b3LPp = 0.328626f;
		sbt_fS0lugikO0aMKg6TXZ5 = L".I\\rkaNq5v?P+m#@VU#V|RtW*xuX:gvq;~%\"q|'F_yyy`y8Q<c\\<;";
		sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs = 0.168853;
		sbt_RKk0NPZ2VDoHMiR9m8l_mL7 = 54;
		sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp *pObject = dynamic_cast<const sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF != pObject->sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF)
		{
			return false;
		}
		if (sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ != pObject->sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ)
		{
			return false;
		}
		if (sbt_sE5NRj_M3BZj1dLRP54 != pObject->sbt_sE5NRj_M3BZj1dLRP54)
		{
			return false;
		}
		if (sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m != pObject->sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m)
		{
			return false;
		}
		if (sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.size() != pObject->sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.size(); i++)
		{
			if (sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk[i] != pObject->sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_7nSvCdutL4kvX9_Nx.c_str(), pObject->sbt_7nSvCdutL4kvX9_Nx.c_str()))
		{
			return false;
		}
		if (sbt_PkgGbHJdPDCZDQ5gQymxT.size() != pObject->sbt_PkgGbHJdPDCZDQ5gQymxT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PkgGbHJdPDCZDQ5gQymxT.size(); i++)
		{
			if (sbt_PkgGbHJdPDCZDQ5gQymxT[i] != pObject->sbt_PkgGbHJdPDCZDQ5gQymxT[i])
			{
				return false;
			}
		}
		if (sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.size() != pObject->sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.size(); i++)
		{
			if (sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF[i] != pObject->sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF[i])
			{
				return false;
			}
		}
		if (sbt_soN7APRXliqxAXHqSUuIeEKKm != pObject->sbt_soN7APRXliqxAXHqSUuIeEKKm)
		{
			return false;
		}
		if (sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa != pObject->sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa)
		{
			return false;
		}
		if (sbt_zwMvt83RXgu8b3LPp != pObject->sbt_zwMvt83RXgu8b3LPp)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_fS0lugikO0aMKg6TXZ5.c_str(), pObject->sbt_fS0lugikO0aMKg6TXZ5.c_str()))
		{
			return false;
		}
		if (sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs != pObject->sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs)
		{
			return false;
		}
		if (sbt_RKk0NPZ2VDoHMiR9m8l_mL7 != pObject->sbt_RKk0NPZ2VDoHMiR9m8l_mL7)
		{
			return false;
		}
		if (!sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr.Compare(&pObject->sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sE5NRj_M3BZj1dLRP54", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sE5NRj_M3BZj1dLRP54 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m", &sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_7nSvCdutL4kvX9_Nx", &sbt_7nSvCdutL4kvX9_Nx)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PkgGbHJdPDCZDQ5gQymxT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PkgGbHJdPDCZDQ5gQymxT.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_soN7APRXliqxAXHqSUuIeEKKm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_soN7APRXliqxAXHqSUuIeEKKm = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectReal("sbt_zwMvt83RXgu8b3LPp", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_zwMvt83RXgu8b3LPp = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_fS0lugikO0aMKg6TXZ5", &sbt_fS0lugikO0aMKg6TXZ5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_RKk0NPZ2VDoHMiR9m8l_mL7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RKk0NPZ2VDoHMiR9m8l_mL7 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF", (CX::Int64)sbt_TD2xdPbtp67P6bSxZyjqEenPujcS1bF)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ", (CX::Int64)sbt_b_IaGWssEv025ix09JogMPQGCmXdqjGH0aa0wUWeXU8yjqLFQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sE5NRj_M3BZj1dLRP54", (CX::Int64)sbt_sE5NRj_M3BZj1dLRP54)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m", sbt_q8Imet5d2twKbflYzt9Ghmr71QYh__m)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.begin(); iter != sbt_OyD2h4wpvBzMN89oPaTd3h5wMJ5qk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_7nSvCdutL4kvX9_Nx", sbt_7nSvCdutL4kvX9_Nx.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PkgGbHJdPDCZDQ5gQymxT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_PkgGbHJdPDCZDQ5gQymxT.begin(); iter != sbt_PkgGbHJdPDCZDQ5gQymxT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.begin(); iter != sbt_MYy4Ku3RoatnTeC5Psu7tmwp5kQL59ou4h4dmo3JdSBzvssiejBK56BdF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_soN7APRXliqxAXHqSUuIeEKKm", (CX::Int64)sbt_soN7APRXliqxAXHqSUuIeEKKm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa", (CX::Int64)sbt_a5tCK4NAiRYxj7rrgpTFgM7xYSRWZ28mG5rl7qf5SQY9BYylNxhXyAh9vEhNa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_zwMvt83RXgu8b3LPp", (CX::Double)sbt_zwMvt83RXgu8b3LPp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_fS0lugikO0aMKg6TXZ5", sbt_fS0lugikO0aMKg6TXZ5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs", (CX::Double)sbt_D3gz0WQ7koFlgN_WuNiHV2Xk0QfkpdgS0ThmHlWnrEs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RKk0NPZ2VDoHMiR9m8l_mL7", (CX::Int64)sbt_RKk0NPZ2VDoHMiR9m8l_mL7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_iYMG8O3sl4hdJV7a1StLXI3Y3d_irb32TNexrqox3hr.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp>::Type sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58XpArray;

