
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_sAccXmCocRm4NkkyuxK419Ipt.hpp"


class sbt_RMQXtDjk8C4FIYZTU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy;
	CX::IO::SimpleBuffers::BoolArray sbt_3MSUfuG;
	CX::Int32 sbt_8NBVmqrNT;
	CX::IO::SimpleBuffers::UInt64Array sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj;
	CX::Double sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY;
	CX::IO::SimpleBuffers::UInt32Array sbt_H;
	CX::UInt16 sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8;
	CX::UInt8 sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x;
	CX::Int32 sbt_T6J;
	CX::Int64 sbt_SMfMuEoaNenx0xkTm;
	CX::Int8 sbt_BobaZzSbNEy;
	CX::IO::SimpleBuffers::BoolArray sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS;
	CX::Int32 sbt_3;
	CX::IO::SimpleBuffers::UInt16Array sbt_iFL50_7SOjX4PtRCu01x9t8LS;
	CX::WString sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck;
	CX::IO::SimpleBuffers::UInt16Array sbt_wFlzA4W7hl6yx46vRcW9a;
	CX::UInt32 sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2;
	sbt_sAccXmCocRm4NkkyuxK419Ipt sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO;

	virtual void Reset()
	{
		sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy = 0;
		sbt_3MSUfuG.clear();
		sbt_8NBVmqrNT = 0;
		sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.clear();
		sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY = 0.0;
		sbt_H.clear();
		sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8 = 0;
		sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x = 0;
		sbt_T6J = 0;
		sbt_SMfMuEoaNenx0xkTm = 0;
		sbt_BobaZzSbNEy = 0;
		sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.clear();
		sbt_3 = 0;
		sbt_iFL50_7SOjX4PtRCu01x9t8LS.clear();
		sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck.clear();
		sbt_wFlzA4W7hl6yx46vRcW9a.clear();
		sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2 = 0;
		sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy = -12026;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_3MSUfuG.push_back(true);
		}
		sbt_8NBVmqrNT = 1785257471;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.push_back(17640751864183635176);
		}
		sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY = 0.079092;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_H.push_back(3366957889);
		}
		sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8 = 34468;
		sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x = 75;
		sbt_T6J = 725932366;
		sbt_SMfMuEoaNenx0xkTm = -6356528574698229558;
		sbt_BobaZzSbNEy = 31;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.push_back(true);
		}
		sbt_3 = -1327991696;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_iFL50_7SOjX4PtRCu01x9t8LS.push_back(25913);
		}
		sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck = L"f`oO\\NbwY3ke(";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_wFlzA4W7hl6yx46vRcW9a.push_back(24836);
		}
		sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2 = 1213400780;
		sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_RMQXtDjk8C4FIYZTU *pObject = dynamic_cast<const sbt_RMQXtDjk8C4FIYZTU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy != pObject->sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy)
		{
			return false;
		}
		if (sbt_3MSUfuG.size() != pObject->sbt_3MSUfuG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3MSUfuG.size(); i++)
		{
			if (sbt_3MSUfuG[i] != pObject->sbt_3MSUfuG[i])
			{
				return false;
			}
		}
		if (sbt_8NBVmqrNT != pObject->sbt_8NBVmqrNT)
		{
			return false;
		}
		if (sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.size() != pObject->sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.size(); i++)
		{
			if (sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj[i] != pObject->sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj[i])
			{
				return false;
			}
		}
		if (sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY != pObject->sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY)
		{
			return false;
		}
		if (sbt_H.size() != pObject->sbt_H.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_H.size(); i++)
		{
			if (sbt_H[i] != pObject->sbt_H[i])
			{
				return false;
			}
		}
		if (sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8 != pObject->sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8)
		{
			return false;
		}
		if (sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x != pObject->sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x)
		{
			return false;
		}
		if (sbt_T6J != pObject->sbt_T6J)
		{
			return false;
		}
		if (sbt_SMfMuEoaNenx0xkTm != pObject->sbt_SMfMuEoaNenx0xkTm)
		{
			return false;
		}
		if (sbt_BobaZzSbNEy != pObject->sbt_BobaZzSbNEy)
		{
			return false;
		}
		if (sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.size() != pObject->sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.size(); i++)
		{
			if (sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS[i] != pObject->sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS[i])
			{
				return false;
			}
		}
		if (sbt_3 != pObject->sbt_3)
		{
			return false;
		}
		if (sbt_iFL50_7SOjX4PtRCu01x9t8LS.size() != pObject->sbt_iFL50_7SOjX4PtRCu01x9t8LS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iFL50_7SOjX4PtRCu01x9t8LS.size(); i++)
		{
			if (sbt_iFL50_7SOjX4PtRCu01x9t8LS[i] != pObject->sbt_iFL50_7SOjX4PtRCu01x9t8LS[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck.c_str(), pObject->sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck.c_str()))
		{
			return false;
		}
		if (sbt_wFlzA4W7hl6yx46vRcW9a.size() != pObject->sbt_wFlzA4W7hl6yx46vRcW9a.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wFlzA4W7hl6yx46vRcW9a.size(); i++)
		{
			if (sbt_wFlzA4W7hl6yx46vRcW9a[i] != pObject->sbt_wFlzA4W7hl6yx46vRcW9a[i])
			{
				return false;
			}
		}
		if (sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2 != pObject->sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2)
		{
			return false;
		}
		if (!sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO.Compare(&pObject->sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3MSUfuG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3MSUfuG.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8NBVmqrNT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8NBVmqrNT = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_H.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8 = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_T6J", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T6J = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SMfMuEoaNenx0xkTm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SMfMuEoaNenx0xkTm = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_BobaZzSbNEy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BobaZzSbNEy = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3 = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iFL50_7SOjX4PtRCu01x9t8LS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iFL50_7SOjX4PtRCu01x9t8LS.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck", &sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wFlzA4W7hl6yx46vRcW9a")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wFlzA4W7hl6yx46vRcW9a.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectObject("sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy", (CX::Int64)sbt_9eNH36ILKlUmSbVh2T_DXIc_uYOzy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3MSUfuG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_3MSUfuG.begin(); iter != sbt_3MSUfuG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8NBVmqrNT", (CX::Int64)sbt_8NBVmqrNT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.begin(); iter != sbt_3B6H7Vy3E1MNtCq84qhJOcLKtP7Yb47FNLpQGncvbZsybr0MCJAAj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY", (CX::Double)sbt_hAv4C7QoK4oz7gmcJVA6LyhAwdY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_H")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_H.begin(); iter != sbt_H.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8", (CX::Int64)sbt_xW0OYGFZDyAjzIMgrEiAhnsrdHBaQ6RDWv8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x", (CX::Int64)sbt_oD41jpyAS88H8y8KSXHSE9N09Rn6z_8XoGTqWBWDtnq6x)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T6J", (CX::Int64)sbt_T6J)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SMfMuEoaNenx0xkTm", (CX::Int64)sbt_SMfMuEoaNenx0xkTm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BobaZzSbNEy", (CX::Int64)sbt_BobaZzSbNEy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.begin(); iter != sbt_8cJUBp1MMSXi_rzluszSnZGlnNhF9KvlDSO2Csnz5f0jBWS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3", (CX::Int64)sbt_3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iFL50_7SOjX4PtRCu01x9t8LS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_iFL50_7SOjX4PtRCu01x9t8LS.begin(); iter != sbt_iFL50_7SOjX4PtRCu01x9t8LS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck", sbt_unyHk9eqwifUJwSibWq_bI1Tzz_ck.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wFlzA4W7hl6yx46vRcW9a")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_wFlzA4W7hl6yx46vRcW9a.begin(); iter != sbt_wFlzA4W7hl6yx46vRcW9a.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2", (CX::Int64)sbt_Zhy9n81lzudaEcDcemKjrubPp2oLBi8UykoND9gATI2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_ujY9AnBXMXtgADA0KkfM74f9jqYV5dwYqHgpo_REZkWpeLiKO65uO.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_RMQXtDjk8C4FIYZTU>::Type sbt_RMQXtDjk8C4FIYZTUArray;

