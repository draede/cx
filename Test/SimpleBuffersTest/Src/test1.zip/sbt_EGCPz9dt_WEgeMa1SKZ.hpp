
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_EGCPz9dt_WEgeMa1SKZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w;
	CX::IO::SimpleBuffers::Int32Array sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z;
	CX::IO::SimpleBuffers::Int64Array sbt_FrcXn824tjfmREm8S3Wtsrm;
	CX::Int16 sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46;
	CX::String sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75;
	CX::Int32 sbt_2mgASeLAx60;
	CX::UInt32 sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b;
	CX::String sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5;
	CX::IO::SimpleBuffers::UInt8Array sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns;
	CX::IO::SimpleBuffers::UInt16Array sbt_L;
	CX::IO::SimpleBuffers::UInt8Array sbt_E0cIm5y4cgYXtiifV4zHttUhG;
	CX::UInt32 sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0;
	CX::UInt8 sbt_F8CEquPTm5v64UKk7;
	CX::IO::SimpleBuffers::UInt64Array sbt_bJmxO;
	CX::IO::SimpleBuffers::UInt8Array sbt_AIUNdzUdS;
	CX::IO::SimpleBuffers::UInt64Array sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL;
	CX::IO::SimpleBuffers::UInt8Array sbt_s;
	CX::IO::SimpleBuffers::UInt32Array sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn;
	CX::IO::SimpleBuffers::UInt64Array sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL;
	CX::IO::SimpleBuffers::UInt64Array sbt_BopSLHq;
	CX::IO::SimpleBuffers::UInt64Array sbt_yw8U5q4OGB8Ok;
	CX::IO::SimpleBuffers::Int8Array sbt_PrSf1nyL1uKsUewOW;
	CX::IO::SimpleBuffers::Int64Array sbt_BUQBitv5kVccpqj2F;
	CX::IO::SimpleBuffers::Int64Array sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M;
	CX::UInt32 sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO;

	virtual void Reset()
	{
		sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.clear();
		sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.clear();
		sbt_FrcXn824tjfmREm8S3Wtsrm.clear();
		sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46 = 0;
		sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75.clear();
		sbt_2mgASeLAx60 = 0;
		sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b = 0;
		sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5.clear();
		sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.clear();
		sbt_L.clear();
		sbt_E0cIm5y4cgYXtiifV4zHttUhG.clear();
		sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0 = 0;
		sbt_F8CEquPTm5v64UKk7 = 0;
		sbt_bJmxO.clear();
		sbt_AIUNdzUdS.clear();
		sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.clear();
		sbt_s.clear();
		sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.clear();
		sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.clear();
		sbt_BopSLHq.clear();
		sbt_yw8U5q4OGB8Ok.clear();
		sbt_PrSf1nyL1uKsUewOW.clear();
		sbt_BUQBitv5kVccpqj2F.clear();
		sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.clear();
		sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.push_back(17911237683168038802);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.push_back(-1527812687);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_FrcXn824tjfmREm8S3Wtsrm.push_back(3998404114909130944);
		}
		sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46 = 3924;
		sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75 = "I/J+!(Cq1B1`&_sj]H{&W^wO~D~GH_b07KH$32k57L>YK%x_Si";
		sbt_2mgASeLAx60 = -301989282;
		sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b = 3310398994;
		sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5 = "#|Nsd{rT|~XJ5\"2%;wD>UAuC99)].5aU\"Y&:+d:\"5>c%";
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.push_back(154);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_L.push_back(39208);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_E0cIm5y4cgYXtiifV4zHttUhG.push_back(180);
		}
		sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0 = 2867952187;
		sbt_F8CEquPTm5v64UKk7 = 223;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_bJmxO.push_back(6055463102588435194);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_AIUNdzUdS.push_back(188);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.push_back(8329502133611029294);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_s.push_back(107);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.push_back(1104735989);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.push_back(17905664009846435978);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_BopSLHq.push_back(17168448471825929174);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_yw8U5q4OGB8Ok.push_back(4592525896459124944);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_PrSf1nyL1uKsUewOW.push_back(-34);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_BUQBitv5kVccpqj2F.push_back(-622749011137820278);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.push_back(-5958244924995072226);
		}
		sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO = 1213445724;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_EGCPz9dt_WEgeMa1SKZ *pObject = dynamic_cast<const sbt_EGCPz9dt_WEgeMa1SKZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.size() != pObject->sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.size(); i++)
		{
			if (sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w[i] != pObject->sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w[i])
			{
				return false;
			}
		}
		if (sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.size() != pObject->sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.size(); i++)
		{
			if (sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z[i] != pObject->sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z[i])
			{
				return false;
			}
		}
		if (sbt_FrcXn824tjfmREm8S3Wtsrm.size() != pObject->sbt_FrcXn824tjfmREm8S3Wtsrm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FrcXn824tjfmREm8S3Wtsrm.size(); i++)
		{
			if (sbt_FrcXn824tjfmREm8S3Wtsrm[i] != pObject->sbt_FrcXn824tjfmREm8S3Wtsrm[i])
			{
				return false;
			}
		}
		if (sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46 != pObject->sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75.c_str(), pObject->sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75.c_str()))
		{
			return false;
		}
		if (sbt_2mgASeLAx60 != pObject->sbt_2mgASeLAx60)
		{
			return false;
		}
		if (sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b != pObject->sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5.c_str(), pObject->sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5.c_str()))
		{
			return false;
		}
		if (sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.size() != pObject->sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.size(); i++)
		{
			if (sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns[i] != pObject->sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns[i])
			{
				return false;
			}
		}
		if (sbt_L.size() != pObject->sbt_L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L.size(); i++)
		{
			if (sbt_L[i] != pObject->sbt_L[i])
			{
				return false;
			}
		}
		if (sbt_E0cIm5y4cgYXtiifV4zHttUhG.size() != pObject->sbt_E0cIm5y4cgYXtiifV4zHttUhG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_E0cIm5y4cgYXtiifV4zHttUhG.size(); i++)
		{
			if (sbt_E0cIm5y4cgYXtiifV4zHttUhG[i] != pObject->sbt_E0cIm5y4cgYXtiifV4zHttUhG[i])
			{
				return false;
			}
		}
		if (sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0 != pObject->sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0)
		{
			return false;
		}
		if (sbt_F8CEquPTm5v64UKk7 != pObject->sbt_F8CEquPTm5v64UKk7)
		{
			return false;
		}
		if (sbt_bJmxO.size() != pObject->sbt_bJmxO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bJmxO.size(); i++)
		{
			if (sbt_bJmxO[i] != pObject->sbt_bJmxO[i])
			{
				return false;
			}
		}
		if (sbt_AIUNdzUdS.size() != pObject->sbt_AIUNdzUdS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_AIUNdzUdS.size(); i++)
		{
			if (sbt_AIUNdzUdS[i] != pObject->sbt_AIUNdzUdS[i])
			{
				return false;
			}
		}
		if (sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.size() != pObject->sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.size(); i++)
		{
			if (sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL[i] != pObject->sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL[i])
			{
				return false;
			}
		}
		if (sbt_s.size() != pObject->sbt_s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_s.size(); i++)
		{
			if (sbt_s[i] != pObject->sbt_s[i])
			{
				return false;
			}
		}
		if (sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.size() != pObject->sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.size(); i++)
		{
			if (sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn[i] != pObject->sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn[i])
			{
				return false;
			}
		}
		if (sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.size() != pObject->sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.size(); i++)
		{
			if (sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL[i] != pObject->sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL[i])
			{
				return false;
			}
		}
		if (sbt_BopSLHq.size() != pObject->sbt_BopSLHq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BopSLHq.size(); i++)
		{
			if (sbt_BopSLHq[i] != pObject->sbt_BopSLHq[i])
			{
				return false;
			}
		}
		if (sbt_yw8U5q4OGB8Ok.size() != pObject->sbt_yw8U5q4OGB8Ok.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yw8U5q4OGB8Ok.size(); i++)
		{
			if (sbt_yw8U5q4OGB8Ok[i] != pObject->sbt_yw8U5q4OGB8Ok[i])
			{
				return false;
			}
		}
		if (sbt_PrSf1nyL1uKsUewOW.size() != pObject->sbt_PrSf1nyL1uKsUewOW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PrSf1nyL1uKsUewOW.size(); i++)
		{
			if (sbt_PrSf1nyL1uKsUewOW[i] != pObject->sbt_PrSf1nyL1uKsUewOW[i])
			{
				return false;
			}
		}
		if (sbt_BUQBitv5kVccpqj2F.size() != pObject->sbt_BUQBitv5kVccpqj2F.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BUQBitv5kVccpqj2F.size(); i++)
		{
			if (sbt_BUQBitv5kVccpqj2F[i] != pObject->sbt_BUQBitv5kVccpqj2F[i])
			{
				return false;
			}
		}
		if (sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.size() != pObject->sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.size(); i++)
		{
			if (sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M[i] != pObject->sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M[i])
			{
				return false;
			}
		}
		if (sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO != pObject->sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FrcXn824tjfmREm8S3Wtsrm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FrcXn824tjfmREm8S3Wtsrm.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46 = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75", &sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2mgASeLAx60", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2mgASeLAx60 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5", &sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_E0cIm5y4cgYXtiifV4zHttUhG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_E0cIm5y4cgYXtiifV4zHttUhG.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_F8CEquPTm5v64UKk7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F8CEquPTm5v64UKk7 = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_bJmxO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bJmxO.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_AIUNdzUdS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_AIUNdzUdS.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_s.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BopSLHq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BopSLHq.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yw8U5q4OGB8Ok")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yw8U5q4OGB8Ok.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PrSf1nyL1uKsUewOW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PrSf1nyL1uKsUewOW.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BUQBitv5kVccpqj2F")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BUQBitv5kVccpqj2F.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.begin(); iter != sbt_LLTD12nzPkUOFgc6P5o9zsiJ8vfh9FSFFeqJ5BaQIpx6w.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.begin(); iter != sbt_UrSaB6Fzdjy_RnFw_zCtBu97j7yH6vlvYygLKEzYe4Qit9z.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FrcXn824tjfmREm8S3Wtsrm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_FrcXn824tjfmREm8S3Wtsrm.begin(); iter != sbt_FrcXn824tjfmREm8S3Wtsrm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46", (CX::Int64)sbt_hiCCLTdpwFXxUZ2L1u8hEtcZGue46)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75", sbt_oOlGOh8EM0vixBk1bErRtriaahyc91lnH9yfaY3lteiB8C9VdzSti_L75.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2mgASeLAx60", (CX::Int64)sbt_2mgASeLAx60)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b", (CX::Int64)sbt_nNucn5GQyWUf8lousFjErf0MqJmg3rMJPLKq5Ya3b)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5", sbt_8WS1BJE1UMzXE57xqO2NLgxRb1X1EAD26yTwiCMHtUY6VOpL7o2Ghu5.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.begin(); iter != sbt_moxx8V02SpDy_tyVt_ZfTOyjEg847bMjsHvp52LaRhlns.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_L.begin(); iter != sbt_L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_E0cIm5y4cgYXtiifV4zHttUhG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_E0cIm5y4cgYXtiifV4zHttUhG.begin(); iter != sbt_E0cIm5y4cgYXtiifV4zHttUhG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0", (CX::Int64)sbt_eVIZJ9bwBYzK22hPILyct8N7kL_nSU0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F8CEquPTm5v64UKk7", (CX::Int64)sbt_F8CEquPTm5v64UKk7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bJmxO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_bJmxO.begin(); iter != sbt_bJmxO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_AIUNdzUdS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_AIUNdzUdS.begin(); iter != sbt_AIUNdzUdS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.begin(); iter != sbt_iPhwKtTZjF0Uv8xCYwga0W6vQ9AUifvVB5Dx9HN0s7SEpImCXFCpL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_s.begin(); iter != sbt_s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.begin(); iter != sbt_Of1K6b1VpsHPUBpou_caeH43C_4Z5VEAn.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.begin(); iter != sbt_YBAp8WlO4YPX2gcUl3nn4ELOteGPojY_OqSXFVSgQJc6MM8ZVg3nL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BopSLHq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BopSLHq.begin(); iter != sbt_BopSLHq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yw8U5q4OGB8Ok")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_yw8U5q4OGB8Ok.begin(); iter != sbt_yw8U5q4OGB8Ok.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PrSf1nyL1uKsUewOW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_PrSf1nyL1uKsUewOW.begin(); iter != sbt_PrSf1nyL1uKsUewOW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BUQBitv5kVccpqj2F")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_BUQBitv5kVccpqj2F.begin(); iter != sbt_BUQBitv5kVccpqj2F.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.begin(); iter != sbt_tDDz5YRl0DAJjfok79r8Vig74qVy84EKItuuQU5_M.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO", (CX::Int64)sbt_eFahs8KRFBxTG7mwjePVKGwsVVvRJtOdeuDo5D06Y7AEt8aIeeC3qS8kQYnvO)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_EGCPz9dt_WEgeMa1SKZ>::Type sbt_EGCPz9dt_WEgeMa1SKZArray;

