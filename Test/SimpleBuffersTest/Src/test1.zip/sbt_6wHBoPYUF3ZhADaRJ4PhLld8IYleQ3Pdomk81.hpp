
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig.hpp"


class sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_sgqTM2yC7o4rB5eZAhzxwpr;
	CX::String sbt_tS2ljc7wA0HZNrHJK70yN;
	CX::Double sbt_0F275oTU4qxTD;
	CX::UInt64 sbt_mFTuYrD;
	CX::IO::SimpleBuffers::UInt8Array sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL;
	CX::Bool sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt;
	CX::IO::SimpleBuffers::UInt64Array sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu;
	sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4igArray sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI;

	virtual void Reset()
	{
		sbt_sgqTM2yC7o4rB5eZAhzxwpr = 0;
		sbt_tS2ljc7wA0HZNrHJK70yN.clear();
		sbt_0F275oTU4qxTD = 0.0;
		sbt_mFTuYrD = 0;
		sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.clear();
		sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt = false;
		sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.clear();
		sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_sgqTM2yC7o4rB5eZAhzxwpr = 246;
		sbt_tS2ljc7wA0HZNrHJK70yN = ".AiYA!4_Vjz1CEZ9Ja7XNXjA'l/Q\\tB~e68+4kRa";
		sbt_0F275oTU4qxTD = 0.921135;
		sbt_mFTuYrD = 11423785077232994046;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.push_back(93);
		}
		sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.push_back(6841719417574955128);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig v;

			v.SetupWithSomeValues();
			sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81 *pObject = dynamic_cast<const sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_sgqTM2yC7o4rB5eZAhzxwpr != pObject->sbt_sgqTM2yC7o4rB5eZAhzxwpr)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_tS2ljc7wA0HZNrHJK70yN.c_str(), pObject->sbt_tS2ljc7wA0HZNrHJK70yN.c_str()))
		{
			return false;
		}
		if (sbt_0F275oTU4qxTD != pObject->sbt_0F275oTU4qxTD)
		{
			return false;
		}
		if (sbt_mFTuYrD != pObject->sbt_mFTuYrD)
		{
			return false;
		}
		if (sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.size() != pObject->sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.size(); i++)
		{
			if (sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL[i] != pObject->sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL[i])
			{
				return false;
			}
		}
		if (sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt != pObject->sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt)
		{
			return false;
		}
		if (sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.size() != pObject->sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.size(); i++)
		{
			if (sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu[i] != pObject->sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu[i])
			{
				return false;
			}
		}
		if (sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.size() != pObject->sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.size(); i++)
		{
			if (!sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI[i].Compare(&pObject->sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_sgqTM2yC7o4rB5eZAhzxwpr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sgqTM2yC7o4rB5eZAhzxwpr = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectString("sbt_tS2ljc7wA0HZNrHJK70yN", &sbt_tS2ljc7wA0HZNrHJK70yN)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_0F275oTU4qxTD", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_0F275oTU4qxTD = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_mFTuYrD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mFTuYrD = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt", &sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_sgqTM2yC7o4rB5eZAhzxwpr", (CX::Int64)sbt_sgqTM2yC7o4rB5eZAhzxwpr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_tS2ljc7wA0HZNrHJK70yN", sbt_tS2ljc7wA0HZNrHJK70yN.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_0F275oTU4qxTD", (CX::Double)sbt_0F275oTU4qxTD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mFTuYrD", (CX::Int64)sbt_mFTuYrD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.begin(); iter != sbt_VZrzZPNZm7NcjjqbaOSvPIeBGXlH2YQyL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt", sbt_PP7aV4xOjUWCAP5rtVuqu3vRhOEpbwbRddt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.begin(); iter != sbt_QwgG4D649Yw2YIZeBgvTBv0ZJJ39mlLou4k479EFS5KJ3h60lnO2oyHfu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI")).IsNOK())
		{
			return status;
		}
		for (sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4igArray::const_iterator iter = sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.begin(); iter != sbt_oviQl0mKuWBsrXyTMmNdfTiwtT_BAFI.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81>::Type sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81Array;

