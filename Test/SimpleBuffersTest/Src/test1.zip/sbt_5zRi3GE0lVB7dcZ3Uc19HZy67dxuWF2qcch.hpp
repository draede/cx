
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_jtAif;
	CX::IO::SimpleBuffers::Int16Array sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L;
	CX::Int64 sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F;
	CX::Int16 sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n;
	CX::IO::SimpleBuffers::Int32Array sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT;
	CX::Int16 sbt_0;
	CX::IO::SimpleBuffers::Int8Array sbt_yCduvfIRzoPXkDcRXjBSzgFAT;
	CX::IO::SimpleBuffers::UInt32Array sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4;
	CX::Int16 sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa;
	CX::UInt32 sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S;
	CX::UInt16 sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9;

	virtual void Reset()
	{
		sbt_jtAif = 0;
		sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.clear();
		sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F = 0;
		sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n = 0;
		sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.clear();
		sbt_0 = 0;
		sbt_yCduvfIRzoPXkDcRXjBSzgFAT.clear();
		sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.clear();
		sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa = 0;
		sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S = 0;
		sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9 = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_jtAif = 127;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.push_back(-13224);
		}
		sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F = 3454038814841715444;
		sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n = -16740;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.push_back(2127440207);
		}
		sbt_0 = -25856;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_yCduvfIRzoPXkDcRXjBSzgFAT.push_back(78);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.push_back(218887421);
		}
		sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa = -11956;
		sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S = 2106254625;
		sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9 = 53832;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch *pObject = dynamic_cast<const sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_jtAif != pObject->sbt_jtAif)
		{
			return false;
		}
		if (sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.size() != pObject->sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.size(); i++)
		{
			if (sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L[i] != pObject->sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L[i])
			{
				return false;
			}
		}
		if (sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F != pObject->sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F)
		{
			return false;
		}
		if (sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n != pObject->sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n)
		{
			return false;
		}
		if (sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.size() != pObject->sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.size(); i++)
		{
			if (sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT[i] != pObject->sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT[i])
			{
				return false;
			}
		}
		if (sbt_0 != pObject->sbt_0)
		{
			return false;
		}
		if (sbt_yCduvfIRzoPXkDcRXjBSzgFAT.size() != pObject->sbt_yCduvfIRzoPXkDcRXjBSzgFAT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yCduvfIRzoPXkDcRXjBSzgFAT.size(); i++)
		{
			if (sbt_yCduvfIRzoPXkDcRXjBSzgFAT[i] != pObject->sbt_yCduvfIRzoPXkDcRXjBSzgFAT[i])
			{
				return false;
			}
		}
		if (sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.size() != pObject->sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.size(); i++)
		{
			if (sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4[i] != pObject->sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4[i])
			{
				return false;
			}
		}
		if (sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa != pObject->sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa)
		{
			return false;
		}
		if (sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S != pObject->sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S)
		{
			return false;
		}
		if (sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9 != pObject->sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_jtAif", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jtAif = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0 = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yCduvfIRzoPXkDcRXjBSzgFAT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yCduvfIRzoPXkDcRXjBSzgFAT.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9 = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_jtAif", (CX::Int64)sbt_jtAif)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.begin(); iter != sbt_19MvOd9Oo_Nq5Vu0Z37VgbbzRDpPew0tXSZY8YZnqc35193ny4L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F", (CX::Int64)sbt_Uz5tA9d_PVfGK8DZDcCcbxiy8MdQLty0n1grS6ol5e9A3ycN_Ei6kEpaL4F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n", (CX::Int64)sbt_T5z8AAbRzMo2W6mN6_6eRronE8fxTcnZLysYvImww3WENVJHaKcl_7n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.begin(); iter != sbt_TRSEmVWJ7l0r7w_0Lq7y9wbCT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0", (CX::Int64)sbt_0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yCduvfIRzoPXkDcRXjBSzgFAT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_yCduvfIRzoPXkDcRXjBSzgFAT.begin(); iter != sbt_yCduvfIRzoPXkDcRXjBSzgFAT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.begin(); iter != sbt_PdJHD6izG1umIsrZyfIv8tsUmFSH1VjBpr3wIrAOJvWo2QeFYrv8iHcctGso4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa", (CX::Int64)sbt_8Az8ayOnrSpdvuG_4W_KeHYA15TTqk2nWiXSa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S", (CX::Int64)sbt_UA8Gdgy7z7QVNN12A9V8ombjpLrPTabYmhg_ox8TJfR6_rQnAKBji9Xi14S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9", (CX::Int64)sbt_0sY7UlChUoitb3AvtBd02bV5na1w4GzKddIvxM9)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch>::Type sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcchArray;

