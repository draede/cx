
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_XqG : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_;
	CX::IO::SimpleBuffers::UInt32Array sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2;
	CX::IO::SimpleBuffers::UInt64Array sbt_9Kv0SMQZLlnpLNM;
	CX::UInt16 sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf;
	CX::UInt64 sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD;
	CX::IO::SimpleBuffers::UInt64Array sbt_vAWX9m9;
	CX::IO::SimpleBuffers::Int64Array sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw;
	CX::UInt32 sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK;
	CX::IO::SimpleBuffers::UInt64Array sbt_hEd0YRFpZ;
	CX::IO::SimpleBuffers::Int16Array sbt_kyBxzUBSD;
	CX::UInt64 sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4;
	CX::UInt64 sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX;
	CX::Bool sbt_wgHZGXz3sOHTu;
	CX::UInt64 sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB;
	CX::String sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE;
	CX::IO::SimpleBuffers::UInt64Array sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo;
	CX::String sbt_DVLKdT9ksbwRWQdbRqjqxPjPG;
	CX::Int8 sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h;
	CX::Int16 sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA;
	CX::IO::SimpleBuffers::Int8Array sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy;
	CX::Bool sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l;
	CX::IO::SimpleBuffers::UInt64Array sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp;
	CX::UInt32 sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N;
	CX::IO::SimpleBuffers::BoolArray sbt_Yg7vQrkqmBQOy;

	virtual void Reset()
	{
		sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_ = 0;
		sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.clear();
		sbt_9Kv0SMQZLlnpLNM.clear();
		sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf = 0;
		sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD = 0;
		sbt_vAWX9m9.clear();
		sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.clear();
		sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK = 0;
		sbt_hEd0YRFpZ.clear();
		sbt_kyBxzUBSD.clear();
		sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4 = 0;
		sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX = 0;
		sbt_wgHZGXz3sOHTu = false;
		sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB = 0;
		sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE.clear();
		sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.clear();
		sbt_DVLKdT9ksbwRWQdbRqjqxPjPG.clear();
		sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h = 0;
		sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA = 0;
		sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.clear();
		sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l = false;
		sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.clear();
		sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N = 0;
		sbt_Yg7vQrkqmBQOy.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_ = 3731648858640614930;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.push_back(128812606);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_9Kv0SMQZLlnpLNM.push_back(8755786186855204902);
		}
		sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf = 54039;
		sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD = 11035645568842261690;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_vAWX9m9.push_back(14162358195155865986);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.push_back(-5096538354688718578);
		}
		sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK = 2257921654;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_hEd0YRFpZ.push_back(9456903134938335962);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_kyBxzUBSD.push_back(-13081);
		}
		sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4 = 14836154538733873902;
		sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX = 17003542512393512716;
		sbt_wgHZGXz3sOHTu = true;
		sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB = 3398344721112618896;
		sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE = "hf>z&h*20DP4+URXshbeoXvbk5,?)dO4m4R6Wx_;+hA$";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.push_back(16974372384735473212);
		}
		sbt_DVLKdT9ksbwRWQdbRqjqxPjPG = "I!w7:J?osbJ'ssMXU/Sj6P6stWsLDiL";
		sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h = -18;
		sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA = 24074;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.push_back(117);
		}
		sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l = true;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.push_back(9253795604380460710);
		}
		sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N = 3454264940;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Yg7vQrkqmBQOy.push_back(false);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_XqG *pObject = dynamic_cast<const sbt_XqG *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_ != pObject->sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_)
		{
			return false;
		}
		if (sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.size() != pObject->sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.size(); i++)
		{
			if (sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2[i] != pObject->sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2[i])
			{
				return false;
			}
		}
		if (sbt_9Kv0SMQZLlnpLNM.size() != pObject->sbt_9Kv0SMQZLlnpLNM.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9Kv0SMQZLlnpLNM.size(); i++)
		{
			if (sbt_9Kv0SMQZLlnpLNM[i] != pObject->sbt_9Kv0SMQZLlnpLNM[i])
			{
				return false;
			}
		}
		if (sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf != pObject->sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf)
		{
			return false;
		}
		if (sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD != pObject->sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD)
		{
			return false;
		}
		if (sbt_vAWX9m9.size() != pObject->sbt_vAWX9m9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vAWX9m9.size(); i++)
		{
			if (sbt_vAWX9m9[i] != pObject->sbt_vAWX9m9[i])
			{
				return false;
			}
		}
		if (sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.size() != pObject->sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.size(); i++)
		{
			if (sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw[i] != pObject->sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw[i])
			{
				return false;
			}
		}
		if (sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK != pObject->sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK)
		{
			return false;
		}
		if (sbt_hEd0YRFpZ.size() != pObject->sbt_hEd0YRFpZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_hEd0YRFpZ.size(); i++)
		{
			if (sbt_hEd0YRFpZ[i] != pObject->sbt_hEd0YRFpZ[i])
			{
				return false;
			}
		}
		if (sbt_kyBxzUBSD.size() != pObject->sbt_kyBxzUBSD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kyBxzUBSD.size(); i++)
		{
			if (sbt_kyBxzUBSD[i] != pObject->sbt_kyBxzUBSD[i])
			{
				return false;
			}
		}
		if (sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4 != pObject->sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4)
		{
			return false;
		}
		if (sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX != pObject->sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX)
		{
			return false;
		}
		if (sbt_wgHZGXz3sOHTu != pObject->sbt_wgHZGXz3sOHTu)
		{
			return false;
		}
		if (sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB != pObject->sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE.c_str(), pObject->sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE.c_str()))
		{
			return false;
		}
		if (sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.size() != pObject->sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.size(); i++)
		{
			if (sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo[i] != pObject->sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_DVLKdT9ksbwRWQdbRqjqxPjPG.c_str(), pObject->sbt_DVLKdT9ksbwRWQdbRqjqxPjPG.c_str()))
		{
			return false;
		}
		if (sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h != pObject->sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h)
		{
			return false;
		}
		if (sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA != pObject->sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA)
		{
			return false;
		}
		if (sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.size() != pObject->sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.size(); i++)
		{
			if (sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy[i] != pObject->sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy[i])
			{
				return false;
			}
		}
		if (sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l != pObject->sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l)
		{
			return false;
		}
		if (sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.size() != pObject->sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.size(); i++)
		{
			if (sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp[i] != pObject->sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp[i])
			{
				return false;
			}
		}
		if (sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N != pObject->sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N)
		{
			return false;
		}
		if (sbt_Yg7vQrkqmBQOy.size() != pObject->sbt_Yg7vQrkqmBQOy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Yg7vQrkqmBQOy.size(); i++)
		{
			if (sbt_Yg7vQrkqmBQOy[i] != pObject->sbt_Yg7vQrkqmBQOy[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_ = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9Kv0SMQZLlnpLNM")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9Kv0SMQZLlnpLNM.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vAWX9m9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vAWX9m9.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_hEd0YRFpZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_hEd0YRFpZ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kyBxzUBSD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kyBxzUBSD.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4 = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_wgHZGXz3sOHTu", &sbt_wgHZGXz3sOHTu)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectString("sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE", &sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_DVLKdT9ksbwRWQdbRqjqxPjPG", &sbt_DVLKdT9ksbwRWQdbRqjqxPjPG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l", &sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Yg7vQrkqmBQOy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Yg7vQrkqmBQOy.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_", (CX::Int64)sbt_Qyttd0QFl56U6T8DI3wPfy1UU8o_cvO455_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.begin(); iter != sbt_NjH6OfjVFEqjJWVyJXc2Bw4jHb0pTjNjgxYgnCWOyFpZPxmxtibeV87Q2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9Kv0SMQZLlnpLNM")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_9Kv0SMQZLlnpLNM.begin(); iter != sbt_9Kv0SMQZLlnpLNM.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf", (CX::Int64)sbt_7mDuR_vd9gbpid_FlO4PQgZ68DaMrUS0oCKrC_Aw7ZBEYR91u4_PkCf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD", (CX::Int64)sbt_kYvyaoegYzfwLhGIUVOdtWlhdYGxkzPAatFdaNY2j40teykWnArCVkpjD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vAWX9m9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_vAWX9m9.begin(); iter != sbt_vAWX9m9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.begin(); iter != sbt_JIcgAhta94NWBvyvKAxxJ5m9xh0KPhU4pqZnasvNWYw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK", (CX::Int64)sbt_xUY0kwSmxBLz2pgdLY4BAiOijvaGGwzqpgtwJJyLZ0v29BouQhpgVEarJmK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_hEd0YRFpZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_hEd0YRFpZ.begin(); iter != sbt_hEd0YRFpZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kyBxzUBSD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_kyBxzUBSD.begin(); iter != sbt_kyBxzUBSD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4", (CX::Int64)sbt_F5KJrGJ1ldiWP1PX1ipXgZ44MEOWBmUg4j592_7APYMttHJTtHmU4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX", (CX::Int64)sbt_wXViQ8XM7Slh0AsuwNI6I_iHKzy4Yj3I2MqzEwiTHsWRZOTw3lkM6NpBX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_wgHZGXz3sOHTu", sbt_wgHZGXz3sOHTu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB", (CX::Int64)sbt_nywQQkMwXeC_l4TlZOWm40oJ_NZzY96l2AB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE", sbt_Lz2c0s0lSOw2icoXmSr1p9XnDk9iYmKj1puVmoTvQFFtSgsxffF019_o7oE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.begin(); iter != sbt_h5J4fszEUgI1KeqSkwKQCS_tpkv4H2DzZxo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_DVLKdT9ksbwRWQdbRqjqxPjPG", sbt_DVLKdT9ksbwRWQdbRqjqxPjPG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h", (CX::Int64)sbt_EE_LEtaLWL57QaxWNtGcwPME7WU90mQ5TI2ZmAjnD0F4EIlUZ_h_h)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA", (CX::Int64)sbt_7oDMlNFA2fzB_QLKeXDZc3cPepHLcLMqIHqdnTGo8DIJBh9B85KkyNA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.begin(); iter != sbt_jrfAfrPEK7F4ujthprRYdgPopYBY0lWOaZJwdxnOuEX7iNpI7NoaZeuukmy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l", sbt_ErR19baPTsgBhCkGWam1K3I1KxI0ykK9l)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.begin(); iter != sbt_FONbfPrGxXJnEKc1dxqOCiRYxwG7CQp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N", (CX::Int64)sbt_22GHEEvE5fIRGToEEErKGX4TXrIy97v8N)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Yg7vQrkqmBQOy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Yg7vQrkqmBQOy.begin(); iter != sbt_Yg7vQrkqmBQOy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_XqG>::Type sbt_XqGArray;

