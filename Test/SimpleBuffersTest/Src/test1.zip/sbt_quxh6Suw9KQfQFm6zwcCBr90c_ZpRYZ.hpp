
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_VObl_aJHQlryKj5mpk6g9I1;
	CX::UInt32 sbt_glT8IAvXH;

	virtual void Reset()
	{
		sbt_VObl_aJHQlryKj5mpk6g9I1.clear();
		sbt_glT8IAvXH = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_VObl_aJHQlryKj5mpk6g9I1.push_back(3446459627);
		}
		sbt_glT8IAvXH = 2862201139;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ *pObject = dynamic_cast<const sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_VObl_aJHQlryKj5mpk6g9I1.size() != pObject->sbt_VObl_aJHQlryKj5mpk6g9I1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VObl_aJHQlryKj5mpk6g9I1.size(); i++)
		{
			if (sbt_VObl_aJHQlryKj5mpk6g9I1[i] != pObject->sbt_VObl_aJHQlryKj5mpk6g9I1[i])
			{
				return false;
			}
		}
		if (sbt_glT8IAvXH != pObject->sbt_glT8IAvXH)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_VObl_aJHQlryKj5mpk6g9I1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VObl_aJHQlryKj5mpk6g9I1.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_glT8IAvXH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_glT8IAvXH = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_VObl_aJHQlryKj5mpk6g9I1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_VObl_aJHQlryKj5mpk6g9I1.begin(); iter != sbt_VObl_aJHQlryKj5mpk6g9I1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_glT8IAvXH", (CX::Int64)sbt_glT8IAvXH)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ>::Type sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZArray;

