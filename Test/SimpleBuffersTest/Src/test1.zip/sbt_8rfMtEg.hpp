
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_8rfMtEg : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_6h0QUVkU8QzRz_n;
	CX::IO::SimpleBuffers::UInt32Array sbt_8RLIl;
	CX::IO::SimpleBuffers::Int32Array sbt_aQ8JJnaN2FUj8E7zUrk;
	CX::UInt16 sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW;
	CX::IO::SimpleBuffers::StringArray sbt_JsmVRQLmkGViKwZQYvPBW;
	CX::IO::SimpleBuffers::Int16Array sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r;
	CX::Int32 sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n;
	CX::IO::SimpleBuffers::UInt64Array sbt_0VWRgY0LTbzyD;
	CX::IO::SimpleBuffers::UInt8Array sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6;
	CX::UInt64 sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM;
	CX::UInt16 sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3;
	CX::IO::SimpleBuffers::UInt8Array sbt_iQb;
	CX::IO::SimpleBuffers::UInt32Array sbt_0KQ5mQF;
	CX::IO::SimpleBuffers::UInt64Array sbt_kl1n5O4eVi_JN;
	CX::Int16 sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D;
	CX::Int16 sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu;
	CX::Int8 sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ;
	CX::UInt16 sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC;
	CX::Int8 sbt_61PG8_S;
	CX::IO::SimpleBuffers::UInt64Array sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR;
	CX::UInt8 sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp;
	CX::IO::SimpleBuffers::UInt64Array sbt_lBVXvu6APZLiVQZvmoN_m;
	CX::IO::SimpleBuffers::UInt64Array sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY;
	CX::UInt8 sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv;
	CX::Int32 sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm;
	CX::UInt16 sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh;
	CX::UInt16 sbt_f1c;
	CX::UInt32 sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm;

	virtual void Reset()
	{
		sbt_6h0QUVkU8QzRz_n.clear();
		sbt_8RLIl.clear();
		sbt_aQ8JJnaN2FUj8E7zUrk.clear();
		sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW = 0;
		sbt_JsmVRQLmkGViKwZQYvPBW.clear();
		sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.clear();
		sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n = 0;
		sbt_0VWRgY0LTbzyD.clear();
		sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.clear();
		sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM = 0;
		sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3 = 0;
		sbt_iQb.clear();
		sbt_0KQ5mQF.clear();
		sbt_kl1n5O4eVi_JN.clear();
		sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D = 0;
		sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu = 0;
		sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ = 0;
		sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC = 0;
		sbt_61PG8_S = 0;
		sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.clear();
		sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp = 0;
		sbt_lBVXvu6APZLiVQZvmoN_m.clear();
		sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.clear();
		sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv = 0;
		sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm = 0;
		sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh = 0;
		sbt_f1c = 0;
		sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_6h0QUVkU8QzRz_n.push_back(11687555655681144260);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_8RLIl.push_back(547694854);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_aQ8JJnaN2FUj8E7zUrk.push_back(-1930401342);
		}
		sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW = 27396;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_JsmVRQLmkGViKwZQYvPBW.push_back("4Vic6;go_l2p?yaXa>%7pRB#\\B[rr^/*rl*zS%a.s");
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.push_back(8437);
		}
		sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n = -46649870;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_0VWRgY0LTbzyD.push_back(1469957266204140274);
		}
		sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM = 16950371612385339990;
		sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3 = 17;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_iQb.push_back(122);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_0KQ5mQF.push_back(2135901609);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_kl1n5O4eVi_JN.push_back(12043942408709006070);
		}
		sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D = 25132;
		sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu = 4680;
		sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ = -2;
		sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC = 21855;
		sbt_61PG8_S = -100;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.push_back(6620049645414323476);
		}
		sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp = 99;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_lBVXvu6APZLiVQZvmoN_m.push_back(9097750170224733846);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.push_back(7830969260904456);
		}
		sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv = 9;
		sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm = -2116073517;
		sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh = 19832;
		sbt_f1c = 12976;
		sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm = 1234269836;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_8rfMtEg *pObject = dynamic_cast<const sbt_8rfMtEg *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_6h0QUVkU8QzRz_n.size() != pObject->sbt_6h0QUVkU8QzRz_n.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6h0QUVkU8QzRz_n.size(); i++)
		{
			if (sbt_6h0QUVkU8QzRz_n[i] != pObject->sbt_6h0QUVkU8QzRz_n[i])
			{
				return false;
			}
		}
		if (sbt_8RLIl.size() != pObject->sbt_8RLIl.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8RLIl.size(); i++)
		{
			if (sbt_8RLIl[i] != pObject->sbt_8RLIl[i])
			{
				return false;
			}
		}
		if (sbt_aQ8JJnaN2FUj8E7zUrk.size() != pObject->sbt_aQ8JJnaN2FUj8E7zUrk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aQ8JJnaN2FUj8E7zUrk.size(); i++)
		{
			if (sbt_aQ8JJnaN2FUj8E7zUrk[i] != pObject->sbt_aQ8JJnaN2FUj8E7zUrk[i])
			{
				return false;
			}
		}
		if (sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW != pObject->sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW)
		{
			return false;
		}
		if (sbt_JsmVRQLmkGViKwZQYvPBW.size() != pObject->sbt_JsmVRQLmkGViKwZQYvPBW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JsmVRQLmkGViKwZQYvPBW.size(); i++)
		{
			if (0 != cx_strcmp(sbt_JsmVRQLmkGViKwZQYvPBW[i].c_str(), pObject->sbt_JsmVRQLmkGViKwZQYvPBW[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.size() != pObject->sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.size(); i++)
		{
			if (sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r[i] != pObject->sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r[i])
			{
				return false;
			}
		}
		if (sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n != pObject->sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n)
		{
			return false;
		}
		if (sbt_0VWRgY0LTbzyD.size() != pObject->sbt_0VWRgY0LTbzyD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0VWRgY0LTbzyD.size(); i++)
		{
			if (sbt_0VWRgY0LTbzyD[i] != pObject->sbt_0VWRgY0LTbzyD[i])
			{
				return false;
			}
		}
		if (sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.size() != pObject->sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.size(); i++)
		{
			if (sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6[i] != pObject->sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6[i])
			{
				return false;
			}
		}
		if (sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM != pObject->sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM)
		{
			return false;
		}
		if (sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3 != pObject->sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3)
		{
			return false;
		}
		if (sbt_iQb.size() != pObject->sbt_iQb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iQb.size(); i++)
		{
			if (sbt_iQb[i] != pObject->sbt_iQb[i])
			{
				return false;
			}
		}
		if (sbt_0KQ5mQF.size() != pObject->sbt_0KQ5mQF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0KQ5mQF.size(); i++)
		{
			if (sbt_0KQ5mQF[i] != pObject->sbt_0KQ5mQF[i])
			{
				return false;
			}
		}
		if (sbt_kl1n5O4eVi_JN.size() != pObject->sbt_kl1n5O4eVi_JN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kl1n5O4eVi_JN.size(); i++)
		{
			if (sbt_kl1n5O4eVi_JN[i] != pObject->sbt_kl1n5O4eVi_JN[i])
			{
				return false;
			}
		}
		if (sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D != pObject->sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D)
		{
			return false;
		}
		if (sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu != pObject->sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu)
		{
			return false;
		}
		if (sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ != pObject->sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ)
		{
			return false;
		}
		if (sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC != pObject->sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC)
		{
			return false;
		}
		if (sbt_61PG8_S != pObject->sbt_61PG8_S)
		{
			return false;
		}
		if (sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.size() != pObject->sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.size(); i++)
		{
			if (sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR[i] != pObject->sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR[i])
			{
				return false;
			}
		}
		if (sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp != pObject->sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp)
		{
			return false;
		}
		if (sbt_lBVXvu6APZLiVQZvmoN_m.size() != pObject->sbt_lBVXvu6APZLiVQZvmoN_m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lBVXvu6APZLiVQZvmoN_m.size(); i++)
		{
			if (sbt_lBVXvu6APZLiVQZvmoN_m[i] != pObject->sbt_lBVXvu6APZLiVQZvmoN_m[i])
			{
				return false;
			}
		}
		if (sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.size() != pObject->sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.size(); i++)
		{
			if (sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY[i] != pObject->sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY[i])
			{
				return false;
			}
		}
		if (sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv != pObject->sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv)
		{
			return false;
		}
		if (sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm != pObject->sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm)
		{
			return false;
		}
		if (sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh != pObject->sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh)
		{
			return false;
		}
		if (sbt_f1c != pObject->sbt_f1c)
		{
			return false;
		}
		if (sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm != pObject->sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_6h0QUVkU8QzRz_n")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6h0QUVkU8QzRz_n.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8RLIl")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8RLIl.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aQ8JJnaN2FUj8E7zUrk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aQ8JJnaN2FUj8E7zUrk.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JsmVRQLmkGViKwZQYvPBW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JsmVRQLmkGViKwZQYvPBW.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0VWRgY0LTbzyD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0VWRgY0LTbzyD.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iQb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iQb.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0KQ5mQF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0KQ5mQF.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kl1n5O4eVi_JN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kl1n5O4eVi_JN.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_61PG8_S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_61PG8_S = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_lBVXvu6APZLiVQZvmoN_m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lBVXvu6APZLiVQZvmoN_m.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_f1c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_f1c = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_6h0QUVkU8QzRz_n")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_6h0QUVkU8QzRz_n.begin(); iter != sbt_6h0QUVkU8QzRz_n.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8RLIl")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_8RLIl.begin(); iter != sbt_8RLIl.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aQ8JJnaN2FUj8E7zUrk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_aQ8JJnaN2FUj8E7zUrk.begin(); iter != sbt_aQ8JJnaN2FUj8E7zUrk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW", (CX::Int64)sbt_JWkfTMTJzLDRmuFx1A9QzCy_24LwUNW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JsmVRQLmkGViKwZQYvPBW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_JsmVRQLmkGViKwZQYvPBW.begin(); iter != sbt_JsmVRQLmkGViKwZQYvPBW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.begin(); iter != sbt_gd3_wgoe_MNXTlLP8Y3tom2Z3XPXs_3JEiZURBhwwFYd1Ia4r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n", (CX::Int64)sbt_frJmTLKJ4R6Twg0ywAvlw2888g_p0ANbtx3PvQJ5i2n)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0VWRgY0LTbzyD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_0VWRgY0LTbzyD.begin(); iter != sbt_0VWRgY0LTbzyD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.begin(); iter != sbt_xBT08ULuTaVTc077UmScL8lhD1UfWXYwjQyCEH5M0lGwXG6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM", (CX::Int64)sbt_8eovPzwi55rfzIYXS7pNWSBaNrq56yvz2tM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3", (CX::Int64)sbt_vTeCsSRVUqWZcjoEyaF0LE4udyvItX4tg4CZ3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iQb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_iQb.begin(); iter != sbt_iQb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0KQ5mQF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0KQ5mQF.begin(); iter != sbt_0KQ5mQF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kl1n5O4eVi_JN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_kl1n5O4eVi_JN.begin(); iter != sbt_kl1n5O4eVi_JN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D", (CX::Int64)sbt_ZwPU5UrBIsQ8eXbGvQKQfjxMZHmIjEIm3_vOKU5exaxAOdxN1JD7z7D)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu", (CX::Int64)sbt_1B2dSMutq4Bn4vzFIJFLj0TvEV1q64K6FvwOtkJTLtc9d0rhbcCozsu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ", (CX::Int64)sbt_9YZwLPn5I7aSLrjofvHz4OaOALYeJuHqDmVR1xs6oHZ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC", (CX::Int64)sbt_fv5Cyp10s3TMTE4q7lUFEYjFR3ffLdsgX9Sl_uLN3srdJ5nbWaHYC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_61PG8_S", (CX::Int64)sbt_61PG8_S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.begin(); iter != sbt_uNC8YIUQqXIhqfa8PZWuJlai8X5E9pfHR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp", (CX::Int64)sbt_HotmVtfCElKhfCuQOP8rWPOZjlT0ZvRHiw5edLp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_lBVXvu6APZLiVQZvmoN_m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_lBVXvu6APZLiVQZvmoN_m.begin(); iter != sbt_lBVXvu6APZLiVQZvmoN_m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.begin(); iter != sbt_EgQBh__XLO0cy5LsWloKPWPIERnFY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv", (CX::Int64)sbt_g_4jJoiwL2kVOitiLoSoSCBtl2DWWzLZv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm", (CX::Int64)sbt_RChI2aaGzQU6mRx9jfHZsgoP3JALsPCFh8Yjm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh", (CX::Int64)sbt_AOywPy1Ywvv3hgSVYr2c04VmfAFddELG0giHC31tdF3QJT_phPeIcw_aixh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_f1c", (CX::Int64)sbt_f1c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm", (CX::Int64)sbt_lZ0WHjtyXbNt1nNMAnqffCsrxIKQTpTEUYmICy3_Dfm)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_8rfMtEg>::Type sbt_8rfMtEgArray;

