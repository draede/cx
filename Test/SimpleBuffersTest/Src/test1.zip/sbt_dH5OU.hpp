
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_dH5OU : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_IEoojxZA5JHVaoi;
	CX::IO::SimpleBuffers::StringArray sbt_tBSOliTFP;
	CX::UInt64 sbt_lbOOwqcXd5AyRUAt1CJMHDc;
	CX::IO::SimpleBuffers::UInt64Array sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd;
	CX::Int64 sbt_OWzmhatrsldM3Ebph;
	CX::IO::SimpleBuffers::UInt8Array sbt_wv6;
	CX::IO::SimpleBuffers::BoolArray sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S;
	CX::UInt8 sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX;
	CX::UInt8 sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU;
	CX::IO::SimpleBuffers::Int16Array sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC;
	CX::UInt16 sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR;
	CX::Int32 sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L;
	CX::UInt8 sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj;
	CX::IO::SimpleBuffers::Int8Array sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6;
	CX::Int16 sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju;
	CX::IO::SimpleBuffers::UInt64Array sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa;
	CX::IO::SimpleBuffers::UInt32Array sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK;
	CX::UInt64 sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy;
	CX::Bool sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1;
	CX::Int32 sbt_WMjvoFWP3a12NyDBK4RpFAQ;

	virtual void Reset()
	{
		sbt_IEoojxZA5JHVaoi = 0;
		sbt_tBSOliTFP.clear();
		sbt_lbOOwqcXd5AyRUAt1CJMHDc = 0;
		sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.clear();
		sbt_OWzmhatrsldM3Ebph = 0;
		sbt_wv6.clear();
		sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.clear();
		sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX = 0;
		sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU = 0;
		sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.clear();
		sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR = 0;
		sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L = 0;
		sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj = 0;
		sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.clear();
		sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju = 0;
		sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.clear();
		sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.clear();
		sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy = 0;
		sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1 = false;
		sbt_WMjvoFWP3a12NyDBK4RpFAQ = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_IEoojxZA5JHVaoi = -753321026;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_tBSOliTFP.push_back("14c-:ccak0Z<Bv%M5tcE[u9\"2In!UX2'}N&Juacd\"n'qr2%Yr'7I$T=[t4H3");
		}
		sbt_lbOOwqcXd5AyRUAt1CJMHDc = 3118841288432378884;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.push_back(10675108591235140288);
		}
		sbt_OWzmhatrsldM3Ebph = 891286425108260672;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_wv6.push_back(161);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.push_back(true);
		}
		sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX = 140;
		sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU = 173;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.push_back(-24327);
		}
		sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR = 59372;
		sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L = 259026890;
		sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj = 109;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.push_back(113);
		}
		sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju = -787;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.push_back(8645000162007561514);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.push_back(3644913930);
		}
		sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy = 5194119588136798948;
		sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1 = false;
		sbt_WMjvoFWP3a12NyDBK4RpFAQ = 141844094;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_dH5OU *pObject = dynamic_cast<const sbt_dH5OU *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_IEoojxZA5JHVaoi != pObject->sbt_IEoojxZA5JHVaoi)
		{
			return false;
		}
		if (sbt_tBSOliTFP.size() != pObject->sbt_tBSOliTFP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tBSOliTFP.size(); i++)
		{
			if (0 != cx_strcmp(sbt_tBSOliTFP[i].c_str(), pObject->sbt_tBSOliTFP[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_lbOOwqcXd5AyRUAt1CJMHDc != pObject->sbt_lbOOwqcXd5AyRUAt1CJMHDc)
		{
			return false;
		}
		if (sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.size() != pObject->sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.size(); i++)
		{
			if (sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd[i] != pObject->sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd[i])
			{
				return false;
			}
		}
		if (sbt_OWzmhatrsldM3Ebph != pObject->sbt_OWzmhatrsldM3Ebph)
		{
			return false;
		}
		if (sbt_wv6.size() != pObject->sbt_wv6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wv6.size(); i++)
		{
			if (sbt_wv6[i] != pObject->sbt_wv6[i])
			{
				return false;
			}
		}
		if (sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.size() != pObject->sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.size(); i++)
		{
			if (sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S[i] != pObject->sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S[i])
			{
				return false;
			}
		}
		if (sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX != pObject->sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX)
		{
			return false;
		}
		if (sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU != pObject->sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU)
		{
			return false;
		}
		if (sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.size() != pObject->sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.size(); i++)
		{
			if (sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC[i] != pObject->sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC[i])
			{
				return false;
			}
		}
		if (sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR != pObject->sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR)
		{
			return false;
		}
		if (sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L != pObject->sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L)
		{
			return false;
		}
		if (sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj != pObject->sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj)
		{
			return false;
		}
		if (sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.size() != pObject->sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.size(); i++)
		{
			if (sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6[i] != pObject->sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6[i])
			{
				return false;
			}
		}
		if (sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju != pObject->sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju)
		{
			return false;
		}
		if (sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.size() != pObject->sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.size(); i++)
		{
			if (sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa[i] != pObject->sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa[i])
			{
				return false;
			}
		}
		if (sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.size() != pObject->sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.size(); i++)
		{
			if (sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK[i] != pObject->sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK[i])
			{
				return false;
			}
		}
		if (sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy != pObject->sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy)
		{
			return false;
		}
		if (sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1 != pObject->sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1)
		{
			return false;
		}
		if (sbt_WMjvoFWP3a12NyDBK4RpFAQ != pObject->sbt_WMjvoFWP3a12NyDBK4RpFAQ)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_IEoojxZA5JHVaoi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_IEoojxZA5JHVaoi = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tBSOliTFP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tBSOliTFP.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_lbOOwqcXd5AyRUAt1CJMHDc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lbOOwqcXd5AyRUAt1CJMHDc = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OWzmhatrsldM3Ebph", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OWzmhatrsldM3Ebph = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wv6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wv6.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1", &sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_WMjvoFWP3a12NyDBK4RpFAQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_WMjvoFWP3a12NyDBK4RpFAQ = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_IEoojxZA5JHVaoi", (CX::Int64)sbt_IEoojxZA5JHVaoi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tBSOliTFP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_tBSOliTFP.begin(); iter != sbt_tBSOliTFP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lbOOwqcXd5AyRUAt1CJMHDc", (CX::Int64)sbt_lbOOwqcXd5AyRUAt1CJMHDc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.begin(); iter != sbt_RWfH3GVN6ufvADKCrEFfJnbJieKvTxErjmd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OWzmhatrsldM3Ebph", (CX::Int64)sbt_OWzmhatrsldM3Ebph)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wv6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_wv6.begin(); iter != sbt_wv6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.begin(); iter != sbt_mbafiIwhdeZzXlZDlyERnPFWRfetxCZmKLSaomHpsGmgbkZZC8S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX", (CX::Int64)sbt_noVW10qavBQ8X38KNrd1wTJ4dEkYEU2cJ5R8zEQiLMCuUZ_CTpX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU", (CX::Int64)sbt_WQz3DBKOFM26IizWkMbFa146HTzDd53_pwmEqXrP1yKJIzCtaSUdO6HhU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.begin(); iter != sbt_m27HcMNrHZu_aPGOnEjbWlVQ5yLHVIbefu8AH_WL15JAQoC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR", (CX::Int64)sbt_yh2NQue_PEWn8pEYrdm8sjstYSfwJ8F27796QcPBanTfR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L", (CX::Int64)sbt_bMYxpaarJuJM5uUboGoJ2gF1TIaWbSepriGL9e6Iw2ZK0WP1L)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj", (CX::Int64)sbt_vnfVP782xOOQ1zuda3GPZ_ru2fj)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.begin(); iter != sbt_MSrWfOOwV6v7hkUqrYx5_P5FqkjZk_lCZCudgfHGKjOI2yThYjsE6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju", (CX::Int64)sbt_7H0rGJ7G6s0FjVJplZ9vYt7RBCjQJC5SeL5WTioE_Ju)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.begin(); iter != sbt_tnjvKFCul2n0u7uyPo3CP1ofrCz3yb6HGXa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.begin(); iter != sbt_uzA5l_dyxE1_o7X2iKwQd51NgMILxeXbJqODQK9RmTIXPP4arqK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy", (CX::Int64)sbt_ClHO_gvD_k6z7G9bS419pSFUOR3fwXb3O72xHv58QB2Dy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1", sbt_tUYL6UFE0AKpYddf86rQ_0JVEi1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_WMjvoFWP3a12NyDBK4RpFAQ", (CX::Int64)sbt_WMjvoFWP3a12NyDBK4RpFAQ)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_dH5OU>::Type sbt_dH5OUArray;

