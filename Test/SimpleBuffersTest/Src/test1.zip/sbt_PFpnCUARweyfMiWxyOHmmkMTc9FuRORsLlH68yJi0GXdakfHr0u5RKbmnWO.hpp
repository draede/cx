
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_lAakdvN7vZFYi3BVt.hpp"


class sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV;
	CX::UInt16 sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd;
	CX::String sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W;
	CX::IO::SimpleBuffers::UInt16Array sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh;
	CX::IO::SimpleBuffers::UInt64Array sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80;
	CX::IO::SimpleBuffers::BoolArray sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS;
	CX::UInt32 sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum;
	CX::Int32 sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM;
	CX::IO::SimpleBuffers::UInt8Array sbt_cbY3UB0bfxD0X;
	CX::UInt32 sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq;
	CX::IO::SimpleBuffers::DoubleArray sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3;
	CX::IO::SimpleBuffers::DoubleArray sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ;
	sbt_lAakdvN7vZFYi3BVt sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e;

	virtual void Reset()
	{
		sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV = 0;
		sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd = 0;
		sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W.clear();
		sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.clear();
		sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.clear();
		sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.clear();
		sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum = 0;
		sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM = 0;
		sbt_cbY3UB0bfxD0X.clear();
		sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq = 0;
		sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.clear();
		sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.clear();
		sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV = -1082017438;
		sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd = 22276;
		sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W = "fFxVWHP\"'^^Z(,P:jO*_bO[c";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.push_back(58735);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.push_back(6873536851347766752);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.push_back(false);
		}
		sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum = 3618265272;
		sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM = 834261285;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_cbY3UB0bfxD0X.push_back(88);
		}
		sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq = 3495671136;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.push_back(0.658457);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.push_back(0.452398);
		}
		sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO *pObject = dynamic_cast<const sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV != pObject->sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV)
		{
			return false;
		}
		if (sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd != pObject->sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W.c_str(), pObject->sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W.c_str()))
		{
			return false;
		}
		if (sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.size() != pObject->sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.size(); i++)
		{
			if (sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh[i] != pObject->sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh[i])
			{
				return false;
			}
		}
		if (sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.size() != pObject->sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.size(); i++)
		{
			if (sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80[i] != pObject->sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80[i])
			{
				return false;
			}
		}
		if (sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.size() != pObject->sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.size(); i++)
		{
			if (sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS[i] != pObject->sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS[i])
			{
				return false;
			}
		}
		if (sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum != pObject->sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum)
		{
			return false;
		}
		if (sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM != pObject->sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM)
		{
			return false;
		}
		if (sbt_cbY3UB0bfxD0X.size() != pObject->sbt_cbY3UB0bfxD0X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cbY3UB0bfxD0X.size(); i++)
		{
			if (sbt_cbY3UB0bfxD0X[i] != pObject->sbt_cbY3UB0bfxD0X[i])
			{
				return false;
			}
		}
		if (sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq != pObject->sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq)
		{
			return false;
		}
		if (sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.size() != pObject->sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.size(); i++)
		{
			if (sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3[i] != pObject->sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3[i])
			{
				return false;
			}
		}
		if (sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.size() != pObject->sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.size(); i++)
		{
			if (sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ[i] != pObject->sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ[i])
			{
				return false;
			}
		}
		if (!sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e.Compare(&pObject->sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectString("sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W", &sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cbY3UB0bfxD0X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cbY3UB0bfxD0X.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV", (CX::Int64)sbt_EF9nPCUfKmhrjIWkahYTO29PNaPtSIPiDfvOnnUI7Ht4L5u5ArXPGJc_p6TuONV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd", (CX::Int64)sbt_Ptbv6AzJ6z48Y_QSt5u4QqemxqCK8LcE630bLv4HAEI3CWMQhxDQoaCdd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W", sbt_9sH_yK8SBTztX_TQm0HiQru5KkHaJ_W.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.begin(); iter != sbt_pIwA8QFOambGB5c8OmTqeb9TwPKVh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.begin(); iter != sbt_wVSrbzXrIWomQh3mPr0hpwIToXGmh7CRaOZGmtSD9Db80.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.begin(); iter != sbt_vIHSzTGNKeZ3G8aOuR0FOVNUDxaH_l9rqH2RNHyrH8W3RcgYwR6df6olS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum", (CX::Int64)sbt_AEuG5rR3hCKUg895ZSpkT1EmV19Stum)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM", (CX::Int64)sbt_bFZrBkoCmY09azdwFR__9ZraGN_o3of0zCm2lyQ4IFM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cbY3UB0bfxD0X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_cbY3UB0bfxD0X.begin(); iter != sbt_cbY3UB0bfxD0X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq", (CX::Int64)sbt_2go586fHEDElJe2IRxtaULC4f7ZnSVlLmRpN69o2IT2yHVkWq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.begin(); iter != sbt_PCVuX75gJQTJvrzZvAc7GLmP7ppwV3Bs2HjkHjbMCHYiz3LuWd7lWpkF3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.begin(); iter != sbt_Z00CJvBr7kaR78dbidmNEbilhE0NGwDAoP6y5QlzjiZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_sOGxbtD1kOyDKn7nMMNNsms07IeAOMu8e.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO>::Type sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWOArray;

