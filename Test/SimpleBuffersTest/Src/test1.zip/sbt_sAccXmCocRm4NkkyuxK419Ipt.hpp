
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_sAccXmCocRm4NkkyuxK419Ipt : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S;

	virtual void Reset()
	{
		sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.push_back(3686613483);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_sAccXmCocRm4NkkyuxK419Ipt *pObject = dynamic_cast<const sbt_sAccXmCocRm4NkkyuxK419Ipt *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.size() != pObject->sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.size(); i++)
		{
			if (sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S[i] != pObject->sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.begin(); iter != sbt_gG0C__UDNsvJrc_rrpwa0dnWzw8dR7AkHdvxKHascT92S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_sAccXmCocRm4NkkyuxK419Ipt>::Type sbt_sAccXmCocRm4NkkyuxK419IptArray;

