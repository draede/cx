
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke.hpp"


class sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::String sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP;
	CX::IO::SimpleBuffers::Int64Array sbt_WPUn58MeNRZQ08DmchrGGqJtjrm;
	CX::WString sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw;
	CX::Int64 sbt_NmXl9aCVS;
	CX::UInt16 sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY;
	CX::Int64 sbt_cJ0RMUXjRW9dAAYYzsem7KNzG;
	CX::IO::SimpleBuffers::FloatArray sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K;
	CX::Int16 sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS;
	CX::IO::SimpleBuffers::UInt32Array sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF;
	CX::Int16 sbt__ddibjDuVYEFYUSV1t9KE;
	CX::IO::SimpleBuffers::UInt64Array sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW;
	CX::WString sbt_rE4LXxpdZgVrukz37mMV5ZY;
	CX::IO::SimpleBuffers::Int16Array sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP;
	CX::IO::SimpleBuffers::Int8Array sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p;
	CX::Float sbt_x1ir3;
	CX::WString sbt_LDi95T617MPqpmiL2nA_caoCA;
	CX::UInt64 sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq;
	CX::UInt16 sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8;
	sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rkeArray sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV;

	virtual void Reset()
	{
		sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP.clear();
		sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.clear();
		sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw.clear();
		sbt_NmXl9aCVS = 0;
		sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY = 0;
		sbt_cJ0RMUXjRW9dAAYYzsem7KNzG = 0;
		sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.clear();
		sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS = 0;
		sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.clear();
		sbt__ddibjDuVYEFYUSV1t9KE = 0;
		sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.clear();
		sbt_rE4LXxpdZgVrukz37mMV5ZY.clear();
		sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.clear();
		sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.clear();
		sbt_x1ir3 = 0.0f;
		sbt_LDi95T617MPqpmiL2nA_caoCA.clear();
		sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq = 0;
		sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8 = 0;
		sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP = "ek_3UdbjX@4h/^VcO2!b-1iQWW/4MG^C`<^w";
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.push_back(5796251079649858078);
		}
		sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw = L"M\"Y]l4{~Y/Atp4J9a?R)Q1DAz#qU{7B";
		sbt_NmXl9aCVS = 3553927493073515286;
		sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY = 36416;
		sbt_cJ0RMUXjRW9dAAYYzsem7KNzG = 4752906555725689290;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.push_back(0.454396f);
		}
		sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS = 31808;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.push_back(311370368);
		}
		sbt__ddibjDuVYEFYUSV1t9KE = 30365;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.push_back(10679881112405201610);
		}
		sbt_rE4LXxpdZgVrukz37mMV5ZY = L"cY8h(WlcN*vL`mQ'{+TAi\\+n6fR;7e3}r==.U_Nm7>y]*njJ,Rt1@";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.push_back(19120);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.push_back(-111);
		}
		sbt_x1ir3 = 0.413465f;
		sbt_LDi95T617MPqpmiL2nA_caoCA = L"IW26D&WN[_{NBG}e/W'bu12wEUA?eECRU";
		sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq = 16258148852618781054;
		sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8 = 12625;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke v;

			v.SetupWithSomeValues();
			sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD *pObject = dynamic_cast<const sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP.c_str(), pObject->sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP.c_str()))
		{
			return false;
		}
		if (sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.size() != pObject->sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.size(); i++)
		{
			if (sbt_WPUn58MeNRZQ08DmchrGGqJtjrm[i] != pObject->sbt_WPUn58MeNRZQ08DmchrGGqJtjrm[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw.c_str(), pObject->sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw.c_str()))
		{
			return false;
		}
		if (sbt_NmXl9aCVS != pObject->sbt_NmXl9aCVS)
		{
			return false;
		}
		if (sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY != pObject->sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY)
		{
			return false;
		}
		if (sbt_cJ0RMUXjRW9dAAYYzsem7KNzG != pObject->sbt_cJ0RMUXjRW9dAAYYzsem7KNzG)
		{
			return false;
		}
		if (sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.size() != pObject->sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.size(); i++)
		{
			if (sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K[i] != pObject->sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K[i])
			{
				return false;
			}
		}
		if (sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS != pObject->sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS)
		{
			return false;
		}
		if (sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.size() != pObject->sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.size(); i++)
		{
			if (sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF[i] != pObject->sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF[i])
			{
				return false;
			}
		}
		if (sbt__ddibjDuVYEFYUSV1t9KE != pObject->sbt__ddibjDuVYEFYUSV1t9KE)
		{
			return false;
		}
		if (sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.size() != pObject->sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.size(); i++)
		{
			if (sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW[i] != pObject->sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_rE4LXxpdZgVrukz37mMV5ZY.c_str(), pObject->sbt_rE4LXxpdZgVrukz37mMV5ZY.c_str()))
		{
			return false;
		}
		if (sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.size() != pObject->sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.size(); i++)
		{
			if (sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP[i] != pObject->sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP[i])
			{
				return false;
			}
		}
		if (sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.size() != pObject->sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.size(); i++)
		{
			if (sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p[i] != pObject->sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p[i])
			{
				return false;
			}
		}
		if (sbt_x1ir3 != pObject->sbt_x1ir3)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_LDi95T617MPqpmiL2nA_caoCA.c_str(), pObject->sbt_LDi95T617MPqpmiL2nA_caoCA.c_str()))
		{
			return false;
		}
		if (sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq != pObject->sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq)
		{
			return false;
		}
		if (sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8 != pObject->sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8)
		{
			return false;
		}
		if (sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.size() != pObject->sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.size(); i++)
		{
			if (!sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV[i].Compare(&pObject->sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectString("sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP", &sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WPUn58MeNRZQ08DmchrGGqJtjrm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw", &sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_NmXl9aCVS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_NmXl9aCVS = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_cJ0RMUXjRW9dAAYYzsem7KNzG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cJ0RMUXjRW9dAAYYzsem7KNzG = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__ddibjDuVYEFYUSV1t9KE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__ddibjDuVYEFYUSV1t9KE = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_rE4LXxpdZgVrukz37mMV5ZY", &sbt_rE4LXxpdZgVrukz37mMV5ZY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_x1ir3", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_x1ir3 = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectWString("sbt_LDi95T617MPqpmiL2nA_caoCA", &sbt_LDi95T617MPqpmiL2nA_caoCA)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectString("sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP", sbt_zbT5B8oQwneEsCD8eIilFVsgpOspWwD7b7IIc1Z49PKsdO0hP.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WPUn58MeNRZQ08DmchrGGqJtjrm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.begin(); iter != sbt_WPUn58MeNRZQ08DmchrGGqJtjrm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw", sbt_8oe6mletnexz3_NQQ6oPsI_7MWByeWswXzEdnqkLrXw.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_NmXl9aCVS", (CX::Int64)sbt_NmXl9aCVS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY", (CX::Int64)sbt_fFOIbdpajgyBU2v_jq86miKoYGyCY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cJ0RMUXjRW9dAAYYzsem7KNzG", (CX::Int64)sbt_cJ0RMUXjRW9dAAYYzsem7KNzG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.begin(); iter != sbt_z8Wvd8hdtLSorJOXBQ1Zi1AjP_kARzq_Sh0yc0K.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS", (CX::Int64)sbt_cydqT7MMtBtYCqPPqRLhmaB7cQQxjrmAmGMCUc7EzM5dakst7SuB0gRg6jS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.begin(); iter != sbt_7Xs64JBmgQESDbqH_gTz9iKMyPLZ4T0LkJcUnR7DTuF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__ddibjDuVYEFYUSV1t9KE", (CX::Int64)sbt__ddibjDuVYEFYUSV1t9KE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.begin(); iter != sbt_RViGKUTfm7x0ujxMhwI5Et3lQETFMNc2TXY8wkNtbuUiar_r0UkiW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_rE4LXxpdZgVrukz37mMV5ZY", sbt_rE4LXxpdZgVrukz37mMV5ZY.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.begin(); iter != sbt_tVJeISZHKurBdQXlvmvUU4TZaQCzNTbcynmjfOi_fdpiP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.begin(); iter != sbt_UEjJ_Xc9mxfce8mD9g9LvXvZh55Bze79EQXt6246p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_x1ir3", (CX::Double)sbt_x1ir3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_LDi95T617MPqpmiL2nA_caoCA", sbt_LDi95T617MPqpmiL2nA_caoCA.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq", (CX::Int64)sbt_gCdG9nNdC2OKv4mcyv0js9YbwEIyCEoZEBr2eRtZZSx5tZvZq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8", (CX::Int64)sbt_40rxMn8S5mf32pJg87b4T1xXffDT4j_87WQSCf8)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV")).IsNOK())
		{
			return status;
		}
		for (sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rkeArray::const_iterator iter = sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.begin(); iter != sbt_UbmVUQusqLlhDR0AI30fztj48VnweRGb4WubcYc6PKV.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD>::Type sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCDArray;

