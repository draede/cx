
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_dNMvvc8oEEfvlTC.hpp"


class sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_EPx_MpNEkmii5bQM61nvR;
	CX::Float sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv;
	CX::UInt16 sbt_rA74W5zWyca9B;
	CX::IO::SimpleBuffers::Int64Array sbt_4gmRsoQfxQBTIowsftgaofP;
	CX::IO::SimpleBuffers::Int32Array sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7;
	CX::IO::SimpleBuffers::DoubleArray sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12;
	CX::UInt64 sbt_udV;
	CX::IO::SimpleBuffers::Int64Array sbt_sFV8fl6bEjgHqhQZ83_BuX241;
	CX::Int32 sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7;
	CX::UInt8 sbt_DMLqN8MTOf0N0OnHL;
	CX::IO::SimpleBuffers::Int32Array sbt_n7cgqY4qNgb;
	sbt_dNMvvc8oEEfvlTCArray sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0;

	virtual void Reset()
	{
		sbt_EPx_MpNEkmii5bQM61nvR.clear();
		sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv = 0.0f;
		sbt_rA74W5zWyca9B = 0;
		sbt_4gmRsoQfxQBTIowsftgaofP.clear();
		sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.clear();
		sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.clear();
		sbt_udV = 0;
		sbt_sFV8fl6bEjgHqhQZ83_BuX241.clear();
		sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7 = 0;
		sbt_DMLqN8MTOf0N0OnHL = 0;
		sbt_n7cgqY4qNgb.clear();
		sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_EPx_MpNEkmii5bQM61nvR.push_back(285718772);
		}
		sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv = 0.381727f;
		sbt_rA74W5zWyca9B = 49238;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_4gmRsoQfxQBTIowsftgaofP.push_back(-1305738379259020000);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.push_back(638471397);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.push_back(0.104630);
		}
		sbt_udV = 12216967222728898784;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_sFV8fl6bEjgHqhQZ83_BuX241.push_back(-1750342713190475238);
		}
		sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7 = 269023317;
		sbt_DMLqN8MTOf0N0OnHL = 33;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_n7cgqY4qNgb.push_back(-1595212438);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_dNMvvc8oEEfvlTC v;

			v.SetupWithSomeValues();
			sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww *pObject = dynamic_cast<const sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_EPx_MpNEkmii5bQM61nvR.size() != pObject->sbt_EPx_MpNEkmii5bQM61nvR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_EPx_MpNEkmii5bQM61nvR.size(); i++)
		{
			if (sbt_EPx_MpNEkmii5bQM61nvR[i] != pObject->sbt_EPx_MpNEkmii5bQM61nvR[i])
			{
				return false;
			}
		}
		if (sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv != pObject->sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv)
		{
			return false;
		}
		if (sbt_rA74W5zWyca9B != pObject->sbt_rA74W5zWyca9B)
		{
			return false;
		}
		if (sbt_4gmRsoQfxQBTIowsftgaofP.size() != pObject->sbt_4gmRsoQfxQBTIowsftgaofP.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4gmRsoQfxQBTIowsftgaofP.size(); i++)
		{
			if (sbt_4gmRsoQfxQBTIowsftgaofP[i] != pObject->sbt_4gmRsoQfxQBTIowsftgaofP[i])
			{
				return false;
			}
		}
		if (sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.size() != pObject->sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.size(); i++)
		{
			if (sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7[i] != pObject->sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7[i])
			{
				return false;
			}
		}
		if (sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.size() != pObject->sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.size(); i++)
		{
			if (sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12[i] != pObject->sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12[i])
			{
				return false;
			}
		}
		if (sbt_udV != pObject->sbt_udV)
		{
			return false;
		}
		if (sbt_sFV8fl6bEjgHqhQZ83_BuX241.size() != pObject->sbt_sFV8fl6bEjgHqhQZ83_BuX241.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sFV8fl6bEjgHqhQZ83_BuX241.size(); i++)
		{
			if (sbt_sFV8fl6bEjgHqhQZ83_BuX241[i] != pObject->sbt_sFV8fl6bEjgHqhQZ83_BuX241[i])
			{
				return false;
			}
		}
		if (sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7 != pObject->sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7)
		{
			return false;
		}
		if (sbt_DMLqN8MTOf0N0OnHL != pObject->sbt_DMLqN8MTOf0N0OnHL)
		{
			return false;
		}
		if (sbt_n7cgqY4qNgb.size() != pObject->sbt_n7cgqY4qNgb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n7cgqY4qNgb.size(); i++)
		{
			if (sbt_n7cgqY4qNgb[i] != pObject->sbt_n7cgqY4qNgb[i])
			{
				return false;
			}
		}
		if (sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.size() != pObject->sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.size(); i++)
		{
			if (!sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0[i].Compare(&pObject->sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_EPx_MpNEkmii5bQM61nvR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_EPx_MpNEkmii5bQM61nvR.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_rA74W5zWyca9B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rA74W5zWyca9B = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4gmRsoQfxQBTIowsftgaofP")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4gmRsoQfxQBTIowsftgaofP.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_udV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_udV = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_sFV8fl6bEjgHqhQZ83_BuX241")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sFV8fl6bEjgHqhQZ83_BuX241.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7 = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_DMLqN8MTOf0N0OnHL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_DMLqN8MTOf0N0OnHL = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_n7cgqY4qNgb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n7cgqY4qNgb.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_dNMvvc8oEEfvlTC tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_EPx_MpNEkmii5bQM61nvR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_EPx_MpNEkmii5bQM61nvR.begin(); iter != sbt_EPx_MpNEkmii5bQM61nvR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv", (CX::Double)sbt_gspfdqKDS6HYXlTYKCLfI5OLfkLGDzhwqFsOxTG8UrpHDnmoLGwahdv)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rA74W5zWyca9B", (CX::Int64)sbt_rA74W5zWyca9B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4gmRsoQfxQBTIowsftgaofP")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_4gmRsoQfxQBTIowsftgaofP.begin(); iter != sbt_4gmRsoQfxQBTIowsftgaofP.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.begin(); iter != sbt_HH4nlMQXzbPF9XA5HiLSONdki00DAmpQ0V_SkHRVobwApgKIE_jhgzSw7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.begin(); iter != sbt_SURlpXUwYPWi5EN_I1jeFRA5fozeNPZN4EQiUBz8KALcYRqUyzI7Mzm12.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_udV", (CX::Int64)sbt_udV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sFV8fl6bEjgHqhQZ83_BuX241")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_sFV8fl6bEjgHqhQZ83_BuX241.begin(); iter != sbt_sFV8fl6bEjgHqhQZ83_BuX241.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7", (CX::Int64)sbt_fYkhPDQUd2oTIJoY_TtdB6rqNdxna5gLcZg81X_u9IK_w6xS8NLeuu7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_DMLqN8MTOf0N0OnHL", (CX::Int64)sbt_DMLqN8MTOf0N0OnHL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n7cgqY4qNgb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_n7cgqY4qNgb.begin(); iter != sbt_n7cgqY4qNgb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0")).IsNOK())
		{
			return status;
		}
		for (sbt_dNMvvc8oEEfvlTCArray::const_iterator iter = sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.begin(); iter != sbt_gVxtJBM7MPCcZxu5Y1RcMV1eSC1QMU0.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww>::Type sbt_b8758G0VoZ1XbrlyloOLKwJ4JwwArray;

