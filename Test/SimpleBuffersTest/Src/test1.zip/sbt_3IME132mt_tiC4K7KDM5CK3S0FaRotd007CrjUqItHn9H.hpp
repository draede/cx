
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4;

	virtual void Reset()
	{
		sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H *pObject = dynamic_cast<const sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.size() != pObject->sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.size(); i++)
		{
			if (sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4[i] != pObject->sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.begin(); iter != sbt_NVAe7Q4FQuxXdBfFE2BTu9r4vZd7j5s7hF4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H>::Type sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9HArray;

