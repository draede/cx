
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_W5cdNUzMn : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int32Array sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR;
	CX::IO::SimpleBuffers::UInt8Array sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X;
	CX::IO::SimpleBuffers::Int8Array sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6;
	CX::UInt64 sbt_L58RNehouhdhrIgOoujskS25Da7;
	CX::IO::SimpleBuffers::Int8Array sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr;
	CX::IO::SimpleBuffers::UInt64Array sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm;
	CX::IO::SimpleBuffers::Int16Array sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp;
	CX::IO::SimpleBuffers::UInt64Array sbt_97a6VIsvYwc8s;
	CX::String sbt_RXZhtQFQj;
	CX::Int16 sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc;
	CX::IO::SimpleBuffers::StringArray sbt_Z6JSQ;
	CX::UInt32 sbt_fBVFtJX;
	CX::UInt64 sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL;

	virtual void Reset()
	{
		sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.clear();
		sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.clear();
		sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.clear();
		sbt_L58RNehouhdhrIgOoujskS25Da7 = 0;
		sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.clear();
		sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.clear();
		sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.clear();
		sbt_97a6VIsvYwc8s.clear();
		sbt_RXZhtQFQj.clear();
		sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc = 0;
		sbt_Z6JSQ.clear();
		sbt_fBVFtJX = 0;
		sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.push_back(-1244533675);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.push_back(133);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.push_back(111);
		}
		sbt_L58RNehouhdhrIgOoujskS25Da7 = 4061198502264649432;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.push_back(24);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.push_back(10257291906553816622);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_97a6VIsvYwc8s.push_back(5044363107344046704);
		}
		sbt_RXZhtQFQj = "8P{oPo\"hHAQA_H~0oz$SE!9";
		sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc = 30378;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_Z6JSQ.push_back("r,c#^y");
		}
		sbt_fBVFtJX = 1573450834;
		sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL = 1449504546375785918;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_W5cdNUzMn *pObject = dynamic_cast<const sbt_W5cdNUzMn *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.size() != pObject->sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.size(); i++)
		{
			if (sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR[i] != pObject->sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR[i])
			{
				return false;
			}
		}
		if (sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.size() != pObject->sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.size(); i++)
		{
			if (sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X[i] != pObject->sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X[i])
			{
				return false;
			}
		}
		if (sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.size() != pObject->sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.size(); i++)
		{
			if (sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6[i] != pObject->sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6[i])
			{
				return false;
			}
		}
		if (sbt_L58RNehouhdhrIgOoujskS25Da7 != pObject->sbt_L58RNehouhdhrIgOoujskS25Da7)
		{
			return false;
		}
		if (sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.size() != pObject->sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.size(); i++)
		{
			if (sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr[i] != pObject->sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr[i])
			{
				return false;
			}
		}
		if (sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.size() != pObject->sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.size(); i++)
		{
			if (sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm[i] != pObject->sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm[i])
			{
				return false;
			}
		}
		if (sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.size() != pObject->sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.size(); i++)
		{
			if (sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp[i] != pObject->sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp[i])
			{
				return false;
			}
		}
		if (sbt_97a6VIsvYwc8s.size() != pObject->sbt_97a6VIsvYwc8s.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_97a6VIsvYwc8s.size(); i++)
		{
			if (sbt_97a6VIsvYwc8s[i] != pObject->sbt_97a6VIsvYwc8s[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_RXZhtQFQj.c_str(), pObject->sbt_RXZhtQFQj.c_str()))
		{
			return false;
		}
		if (sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc != pObject->sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc)
		{
			return false;
		}
		if (sbt_Z6JSQ.size() != pObject->sbt_Z6JSQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Z6JSQ.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Z6JSQ[i].c_str(), pObject->sbt_Z6JSQ[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_fBVFtJX != pObject->sbt_fBVFtJX)
		{
			return false;
		}
		if (sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL != pObject->sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_L58RNehouhdhrIgOoujskS25Da7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_L58RNehouhdhrIgOoujskS25Da7 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_97a6VIsvYwc8s")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_97a6VIsvYwc8s.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_RXZhtQFQj", &sbt_RXZhtQFQj)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Z6JSQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Z6JSQ.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fBVFtJX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fBVFtJX = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.begin(); iter != sbt_a6vh32HF7ZJ4TKBbFDe6NyvhR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.begin(); iter != sbt_FRMhSx1gEfI8exmLpe7U_FzFvzY0X.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.begin(); iter != sbt_NTRTh3dJhXOvvrOYOm8ncBuAmGG8992cWOC0c0RCaRoUgf745c6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_L58RNehouhdhrIgOoujskS25Da7", (CX::Int64)sbt_L58RNehouhdhrIgOoujskS25Da7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.begin(); iter != sbt_uHox47PLi7Xgw90XzdNe_81YQMQLMTZxCy37FZjDwQDLLeQaiUEgv7iKgjr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.begin(); iter != sbt_gYzvv4xgm9Il8cACp1K4YtqN2QGgXHkEo9HuVzTqRfFivbLvHKm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.begin(); iter != sbt_legyGDqinzEkxWQgPEV0G_4_X4V5fsb2w_IWqQ5f0KR_NOcJp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_97a6VIsvYwc8s")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_97a6VIsvYwc8s.begin(); iter != sbt_97a6VIsvYwc8s.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_RXZhtQFQj", sbt_RXZhtQFQj.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc", (CX::Int64)sbt_Pm3vvA71xki77c06z_AY5Nx8sF2zbAcYJzOtPuc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Z6JSQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Z6JSQ.begin(); iter != sbt_Z6JSQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fBVFtJX", (CX::Int64)sbt_fBVFtJX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL", (CX::Int64)sbt_d2afKsfMawiftnQLux9BhEyBRrZpFIMf3fULzY7fL)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_W5cdNUzMn>::Type sbt_W5cdNUzMnArray;

