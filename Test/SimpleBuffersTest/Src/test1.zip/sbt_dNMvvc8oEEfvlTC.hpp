
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_dNMvvc8oEEfvlTC : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5;
	CX::UInt8 sbt_y2rQx;
	CX::UInt8 sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX;
	CX::IO::SimpleBuffers::UInt16Array sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr;
	CX::IO::SimpleBuffers::Int16Array sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH;
	CX::Int8 sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi;
	CX::IO::SimpleBuffers::Int16Array sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv;
	CX::IO::SimpleBuffers::UInt32Array sbt_bbUGFOGwGNkF8DsW2;
	CX::Bool sbt_Ye53ZEdEQTy;
	CX::IO::SimpleBuffers::UInt64Array sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw;
	CX::IO::SimpleBuffers::Int32Array sbt_Yz0GjZc;
	CX::UInt16 sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv;

	virtual void Reset()
	{
		sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.clear();
		sbt_y2rQx = 0;
		sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX = 0;
		sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.clear();
		sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.clear();
		sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi = 0;
		sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.clear();
		sbt_bbUGFOGwGNkF8DsW2.clear();
		sbt_Ye53ZEdEQTy = false;
		sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.clear();
		sbt_Yz0GjZc.clear();
		sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.push_back(10972341149394301462);
		}
		sbt_y2rQx = 19;
		sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX = 222;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.push_back(54105);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.push_back(-30510);
		}
		sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi = 45;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.push_back(14072);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_bbUGFOGwGNkF8DsW2.push_back(2341664837);
		}
		sbt_Ye53ZEdEQTy = true;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.push_back(16957704569785225784);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Yz0GjZc.push_back(1544846235);
		}
		sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv = 50549;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_dNMvvc8oEEfvlTC *pObject = dynamic_cast<const sbt_dNMvvc8oEEfvlTC *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.size() != pObject->sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.size(); i++)
		{
			if (sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5[i] != pObject->sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5[i])
			{
				return false;
			}
		}
		if (sbt_y2rQx != pObject->sbt_y2rQx)
		{
			return false;
		}
		if (sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX != pObject->sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX)
		{
			return false;
		}
		if (sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.size() != pObject->sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.size(); i++)
		{
			if (sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr[i] != pObject->sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr[i])
			{
				return false;
			}
		}
		if (sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.size() != pObject->sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.size(); i++)
		{
			if (sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH[i] != pObject->sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH[i])
			{
				return false;
			}
		}
		if (sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi != pObject->sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi)
		{
			return false;
		}
		if (sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.size() != pObject->sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.size(); i++)
		{
			if (sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv[i] != pObject->sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv[i])
			{
				return false;
			}
		}
		if (sbt_bbUGFOGwGNkF8DsW2.size() != pObject->sbt_bbUGFOGwGNkF8DsW2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bbUGFOGwGNkF8DsW2.size(); i++)
		{
			if (sbt_bbUGFOGwGNkF8DsW2[i] != pObject->sbt_bbUGFOGwGNkF8DsW2[i])
			{
				return false;
			}
		}
		if (sbt_Ye53ZEdEQTy != pObject->sbt_Ye53ZEdEQTy)
		{
			return false;
		}
		if (sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.size() != pObject->sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.size(); i++)
		{
			if (sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw[i] != pObject->sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw[i])
			{
				return false;
			}
		}
		if (sbt_Yz0GjZc.size() != pObject->sbt_Yz0GjZc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Yz0GjZc.size(); i++)
		{
			if (sbt_Yz0GjZc[i] != pObject->sbt_Yz0GjZc[i])
			{
				return false;
			}
		}
		if (sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv != pObject->sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_y2rQx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_y2rQx = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bbUGFOGwGNkF8DsW2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bbUGFOGwGNkF8DsW2.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Ye53ZEdEQTy", &sbt_Ye53ZEdEQTy)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Yz0GjZc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Yz0GjZc.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv = (CX::UInt16)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.begin(); iter != sbt_5WXYtCgqrdKAPgnrZqz00WEpDRYB0V5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_y2rQx", (CX::Int64)sbt_y2rQx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX", (CX::Int64)sbt_P8PUwYuKOI1ZihdZDXEF4AtEFhg53qor6VF4BEtusUpuoxYg9rX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.begin(); iter != sbt_KzlKimqY1wJJjVUGZTAXfe1aCB3wfz2x8OdbPtlzhdr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.begin(); iter != sbt_g88Pz5PHYlL_4NQ6vHl4goWhHq45wNAgH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi", (CX::Int64)sbt_3j1o6iKhIcHnYPYEsMiCVuExI0v7h9ITZNnCzFtlZNk2sUNxuSxHwVNT32Msi)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.begin(); iter != sbt_UEdEY7sgcsoTnKREi7D4i8c8U3fm60KLaYLzv.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bbUGFOGwGNkF8DsW2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_bbUGFOGwGNkF8DsW2.begin(); iter != sbt_bbUGFOGwGNkF8DsW2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Ye53ZEdEQTy", sbt_Ye53ZEdEQTy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.begin(); iter != sbt_ZY17tmXua1sGxgY_WgUaCu0RycdcFhDr1l7ttCTycZc94K9XqVVHYYw.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Yz0GjZc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Yz0GjZc.begin(); iter != sbt_Yz0GjZc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv", (CX::Int64)sbt_ehsEFeVmovEzdslQ7S8U3XmPabs6mFptgkHeJIL2B4UompeRv)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_dNMvvc8oEEfvlTC>::Type sbt_dNMvvc8oEEfvlTCArray;

