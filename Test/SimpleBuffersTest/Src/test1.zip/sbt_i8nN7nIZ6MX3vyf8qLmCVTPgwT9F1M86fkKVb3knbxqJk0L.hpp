
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L : public CX::IO::SimpleBuffers::IObject
{
public:


	virtual void Reset()
	{
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L *pObject = dynamic_cast<const sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Status status;

		Reset();

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;


		return CX::Status();
	}

};

typedef CX::Vector<sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L>::Type sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0LArray;

