
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_jgDm6sWUw.hpp"


class sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_ : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::WString sbt_hv172BTupewMY;
	CX::UInt8 sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy;
	CX::Bool sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ;
	CX::Int16 sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp;
	CX::IO::SimpleBuffers::Int16Array sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL;
	CX::UInt64 sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA;
	CX::IO::SimpleBuffers::Int8Array sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb;
	CX::IO::SimpleBuffers::WStringArray sbt_W;
	CX::UInt16 sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl;
	CX::Bool sbt_lDZapEYjb;
	CX::IO::SimpleBuffers::BoolArray sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81;
	CX::Int8 sbt_enT8r9BxogXDpVZRNukRtnwsg8r;
	CX::IO::SimpleBuffers::UInt16Array sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW;
	CX::IO::SimpleBuffers::FloatArray sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y;
	CX::IO::SimpleBuffers::DoubleArray sbt_uQ4fKX6HvIqsBMN;
	CX::IO::SimpleBuffers::UInt32Array sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB;
	CX::IO::SimpleBuffers::Int64Array sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL;
	CX::IO::SimpleBuffers::Int32Array sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6;
	CX::IO::SimpleBuffers::Int8Array sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D;
	CX::UInt8 sbt_syudhfEwX;
	CX::IO::SimpleBuffers::BoolArray sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs;
	CX::IO::SimpleBuffers::Int32Array sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1;
	CX::UInt8 sbt_aZT3ZBE6oIU;
	CX::IO::SimpleBuffers::DoubleArray sbt_HX8zf;
	sbt_jgDm6sWUwArray sbt_MdwecFxYL7kRIq4Ve;

	virtual void Reset()
	{
		sbt_hv172BTupewMY.clear();
		sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy = 0;
		sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ = false;
		sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp = 0;
		sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.clear();
		sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA = 0;
		sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.clear();
		sbt_W.clear();
		sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl = 0;
		sbt_lDZapEYjb = false;
		sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.clear();
		sbt_enT8r9BxogXDpVZRNukRtnwsg8r = 0;
		sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.clear();
		sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.clear();
		sbt_uQ4fKX6HvIqsBMN.clear();
		sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.clear();
		sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.clear();
		sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.clear();
		sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.clear();
		sbt_syudhfEwX = 0;
		sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.clear();
		sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.clear();
		sbt_aZT3ZBE6oIU = 0;
		sbt_HX8zf.clear();
		sbt_MdwecFxYL7kRIq4Ve.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_hv172BTupewMY = L"_>=6l";
		sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy = 38;
		sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ = true;
		sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp = 26040;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.push_back(12520);
		}
		sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA = 9623476457506449698;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.push_back(47);
		}
		sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl = 18670;
		sbt_lDZapEYjb = true;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.push_back(false);
		}
		sbt_enT8r9BxogXDpVZRNukRtnwsg8r = -99;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.push_back(45121);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.push_back(0.921182f);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_uQ4fKX6HvIqsBMN.push_back(0.783130);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.push_back(111733433);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.push_back(6625786461829998412);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.push_back(-2063675591);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.push_back(-85);
		}
		sbt_syudhfEwX = 117;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.push_back(false);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.push_back(-1252132727);
		}
		sbt_aZT3ZBE6oIU = 80;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_HX8zf.push_back(0.816681);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_jgDm6sWUw v;

			v.SetupWithSomeValues();
			sbt_MdwecFxYL7kRIq4Ve.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_ *pObject = dynamic_cast<const sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_ *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_hv172BTupewMY.c_str(), pObject->sbt_hv172BTupewMY.c_str()))
		{
			return false;
		}
		if (sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy != pObject->sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy)
		{
			return false;
		}
		if (sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ != pObject->sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ)
		{
			return false;
		}
		if (sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp != pObject->sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp)
		{
			return false;
		}
		if (sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.size() != pObject->sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.size(); i++)
		{
			if (sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL[i] != pObject->sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL[i])
			{
				return false;
			}
		}
		if (sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA != pObject->sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA)
		{
			return false;
		}
		if (sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.size() != pObject->sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.size(); i++)
		{
			if (sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb[i] != pObject->sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb[i])
			{
				return false;
			}
		}
		if (sbt_W.size() != pObject->sbt_W.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_W.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_W[i].c_str(), pObject->sbt_W[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl != pObject->sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl)
		{
			return false;
		}
		if (sbt_lDZapEYjb != pObject->sbt_lDZapEYjb)
		{
			return false;
		}
		if (sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.size() != pObject->sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.size(); i++)
		{
			if (sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81[i] != pObject->sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81[i])
			{
				return false;
			}
		}
		if (sbt_enT8r9BxogXDpVZRNukRtnwsg8r != pObject->sbt_enT8r9BxogXDpVZRNukRtnwsg8r)
		{
			return false;
		}
		if (sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.size() != pObject->sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.size(); i++)
		{
			if (sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW[i] != pObject->sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW[i])
			{
				return false;
			}
		}
		if (sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.size() != pObject->sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.size(); i++)
		{
			if (sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y[i] != pObject->sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y[i])
			{
				return false;
			}
		}
		if (sbt_uQ4fKX6HvIqsBMN.size() != pObject->sbt_uQ4fKX6HvIqsBMN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uQ4fKX6HvIqsBMN.size(); i++)
		{
			if (sbt_uQ4fKX6HvIqsBMN[i] != pObject->sbt_uQ4fKX6HvIqsBMN[i])
			{
				return false;
			}
		}
		if (sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.size() != pObject->sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.size(); i++)
		{
			if (sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB[i] != pObject->sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB[i])
			{
				return false;
			}
		}
		if (sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.size() != pObject->sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.size(); i++)
		{
			if (sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL[i] != pObject->sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL[i])
			{
				return false;
			}
		}
		if (sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.size() != pObject->sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.size(); i++)
		{
			if (sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6[i] != pObject->sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6[i])
			{
				return false;
			}
		}
		if (sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.size() != pObject->sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.size(); i++)
		{
			if (sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D[i] != pObject->sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D[i])
			{
				return false;
			}
		}
		if (sbt_syudhfEwX != pObject->sbt_syudhfEwX)
		{
			return false;
		}
		if (sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.size() != pObject->sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.size(); i++)
		{
			if (sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs[i] != pObject->sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs[i])
			{
				return false;
			}
		}
		if (sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.size() != pObject->sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.size(); i++)
		{
			if (sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1[i] != pObject->sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1[i])
			{
				return false;
			}
		}
		if (sbt_aZT3ZBE6oIU != pObject->sbt_aZT3ZBE6oIU)
		{
			return false;
		}
		if (sbt_HX8zf.size() != pObject->sbt_HX8zf.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HX8zf.size(); i++)
		{
			if (sbt_HX8zf[i] != pObject->sbt_HX8zf[i])
			{
				return false;
			}
		}
		if (sbt_MdwecFxYL7kRIq4Ve.size() != pObject->sbt_MdwecFxYL7kRIq4Ve.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MdwecFxYL7kRIq4Ve.size(); i++)
		{
			if (!sbt_MdwecFxYL7kRIq4Ve[i].Compare(&pObject->sbt_MdwecFxYL7kRIq4Ve[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectWString("sbt_hv172BTupewMY", &sbt_hv172BTupewMY)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ", &sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_W")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_W.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_lDZapEYjb", &sbt_lDZapEYjb)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_enT8r9BxogXDpVZRNukRtnwsg8r", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_enT8r9BxogXDpVZRNukRtnwsg8r = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uQ4fKX6HvIqsBMN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uQ4fKX6HvIqsBMN.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_syudhfEwX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_syudhfEwX = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_aZT3ZBE6oIU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_aZT3ZBE6oIU = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_HX8zf")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HX8zf.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_MdwecFxYL7kRIq4Ve")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_jgDm6sWUw tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_MdwecFxYL7kRIq4Ve.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectWString("sbt_hv172BTupewMY", sbt_hv172BTupewMY.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy", (CX::Int64)sbt_X22ggQ7Yyu0u5UPrlzk9NK3E7mEJioTY6MlOkupBGPNHPmy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ", sbt_c6Ph61jHpk7G471lGFV6MMsvTFq71lzNQ6eMwYIhVEh3XMVBJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp", (CX::Int64)sbt_pT0PHb_0KsnNXggPUmNhwCLUtCEFWlO8RMXRLmCEsl1R3cp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.begin(); iter != sbt_8vqlcQSkAHg3yHEkOT7NXRpNnWFDtQuiL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA", (CX::Int64)sbt_TR4Ht20TTgQV9umR904OpijONr8zxEtheGxCnOAxDx_N40vacKy79Kqq_0qBYYA)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.begin(); iter != sbt_Gm1IX_fFG_b0bjF4hjkKQa0yGjOG8a6X4ynUDpb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_W")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_W.begin(); iter != sbt_W.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl", (CX::Int64)sbt_4ZEYVqnoYkQtHQX2j4NGxiEKqAFl4yXcuicfk4Kkgzj781tXvseL66ddTLl)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_lDZapEYjb", sbt_lDZapEYjb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.begin(); iter != sbt_O9cnfgM9rOUaSVpaURWTpB1JxJy6ubVshZvMD4Sfh81.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_enT8r9BxogXDpVZRNukRtnwsg8r", (CX::Int64)sbt_enT8r9BxogXDpVZRNukRtnwsg8r)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.begin(); iter != sbt_IHbLCcSey6YlwnpOi2dZfq8xcjif9n0zW_cIRc2T1utApJJGs_KVW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.begin(); iter != sbt_yEWIqM3f2Unj4xLHcyjANmz3M2DxfAz3g5y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uQ4fKX6HvIqsBMN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_uQ4fKX6HvIqsBMN.begin(); iter != sbt_uQ4fKX6HvIqsBMN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.begin(); iter != sbt_P8TeqdD0DFqnTQzuc_s29pL8sxydB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.begin(); iter != sbt_Ymj8wM31O3FyT3t7Nps4pRE3pOte9Ffo1iBCyNMRJqKHbjL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.begin(); iter != sbt_Tdeq7owmyUhHXFt7ujP_CRiGGOnSREjr5WGRXNPJxcV28Y6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.begin(); iter != sbt_8e6xGnu3TwNwaRIDj4iP6Uhut1jMVLdYaPmwAYqOvh43gAQcjjb3V7Kyb5A6D.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_syudhfEwX", (CX::Int64)sbt_syudhfEwX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.begin(); iter != sbt_jWHI2Cf3SmYRLDdsuWRKdQ9nTgC6ywoFs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.begin(); iter != sbt_WFMAuCQB2atLJYreUPuYjR3OegBFDlTdxpsUXo_JZvKlW_VK3Ka3noTLLUfk1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_aZT3ZBE6oIU", (CX::Int64)sbt_aZT3ZBE6oIU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HX8zf")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_HX8zf.begin(); iter != sbt_HX8zf.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MdwecFxYL7kRIq4Ve")).IsNOK())
		{
			return status;
		}
		for (sbt_jgDm6sWUwArray::const_iterator iter = sbt_MdwecFxYL7kRIq4Ve.begin(); iter != sbt_MdwecFxYL7kRIq4Ve.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_>::Type sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_Array;

