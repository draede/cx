
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt64 sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr;

	virtual void Reset()
	{
		sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr = 1594203801853694940;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf *pObject = dynamic_cast<const sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr != pObject->sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr = (CX::UInt64)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr", (CX::Int64)sbt_ikUcRfSDjHEMyzUw8AxYpXmqYm4BHL2nnkkxODnwUUE9BLsgTyr)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf>::Type sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbfArray;

