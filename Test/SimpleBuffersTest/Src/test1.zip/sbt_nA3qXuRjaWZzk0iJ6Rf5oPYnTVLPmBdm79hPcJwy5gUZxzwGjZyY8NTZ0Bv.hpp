
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int32 sbt_b1l2kOXAd6F;
	CX::String sbt_o0B3PDtdE;
	CX::IO::SimpleBuffers::Int16Array sbt_kojxbIcf1mTGxFPhQ;
	CX::Int16 sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz;
	CX::String sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1;
	CX::Int32 sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP;
	CX::Int8 sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy;
	CX::IO::SimpleBuffers::Int64Array sbt_800HnTFJJAGajqO;
	CX::IO::SimpleBuffers::UInt8Array sbt_JAxm7;
	CX::IO::SimpleBuffers::UInt16Array sbt_BGqKMMwh1qqPwB2;
	CX::IO::SimpleBuffers::Int16Array sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ;
	CX::UInt64 sbt__uT63JKv8eRfG;
	CX::IO::SimpleBuffers::UInt16Array sbt_wAzFZK5kCfSzDLXVcntQlB8;
	CX::Int8 sbt_Y;
	CX::String sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip;
	CX::IO::SimpleBuffers::UInt64Array sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U;
	CX::IO::SimpleBuffers::UInt8Array sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu;

	virtual void Reset()
	{
		sbt_b1l2kOXAd6F = 0;
		sbt_o0B3PDtdE.clear();
		sbt_kojxbIcf1mTGxFPhQ.clear();
		sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz = 0;
		sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1.clear();
		sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP = 0;
		sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy = 0;
		sbt_800HnTFJJAGajqO.clear();
		sbt_JAxm7.clear();
		sbt_BGqKMMwh1qqPwB2.clear();
		sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.clear();
		sbt__uT63JKv8eRfG = 0;
		sbt_wAzFZK5kCfSzDLXVcntQlB8.clear();
		sbt_Y = 0;
		sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip.clear();
		sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.clear();
		sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_b1l2kOXAd6F = -583176056;
		sbt_o0B3PDtdE = "?woN)-S@m[,p7mb2_piVf.aA5[|#baD+w/);Jt_r>l^J&a\":eU";
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_kojxbIcf1mTGxFPhQ.push_back(9116);
		}
		sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz = -24878;
		sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1 = "eX<@H+O~[\\H!Yzd28EBTzr+a+92";
		sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP = 97158863;
		sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy = 93;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_800HnTFJJAGajqO.push_back(7446870901468226030);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_JAxm7.push_back(90);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_BGqKMMwh1qqPwB2.push_back(39693);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.push_back(-19151);
		}
		sbt__uT63JKv8eRfG = 12029310205391290234;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_wAzFZK5kCfSzDLXVcntQlB8.push_back(4104);
		}
		sbt_Y = 45;
		sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip = "VrtgA[wwg*oBHc=[STaNZS:k";
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.push_back(11261820208377907660);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.push_back(242);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv *pObject = dynamic_cast<const sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_b1l2kOXAd6F != pObject->sbt_b1l2kOXAd6F)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_o0B3PDtdE.c_str(), pObject->sbt_o0B3PDtdE.c_str()))
		{
			return false;
		}
		if (sbt_kojxbIcf1mTGxFPhQ.size() != pObject->sbt_kojxbIcf1mTGxFPhQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kojxbIcf1mTGxFPhQ.size(); i++)
		{
			if (sbt_kojxbIcf1mTGxFPhQ[i] != pObject->sbt_kojxbIcf1mTGxFPhQ[i])
			{
				return false;
			}
		}
		if (sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz != pObject->sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1.c_str(), pObject->sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1.c_str()))
		{
			return false;
		}
		if (sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP != pObject->sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP)
		{
			return false;
		}
		if (sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy != pObject->sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy)
		{
			return false;
		}
		if (sbt_800HnTFJJAGajqO.size() != pObject->sbt_800HnTFJJAGajqO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_800HnTFJJAGajqO.size(); i++)
		{
			if (sbt_800HnTFJJAGajqO[i] != pObject->sbt_800HnTFJJAGajqO[i])
			{
				return false;
			}
		}
		if (sbt_JAxm7.size() != pObject->sbt_JAxm7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JAxm7.size(); i++)
		{
			if (sbt_JAxm7[i] != pObject->sbt_JAxm7[i])
			{
				return false;
			}
		}
		if (sbt_BGqKMMwh1qqPwB2.size() != pObject->sbt_BGqKMMwh1qqPwB2.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BGqKMMwh1qqPwB2.size(); i++)
		{
			if (sbt_BGqKMMwh1qqPwB2[i] != pObject->sbt_BGqKMMwh1qqPwB2[i])
			{
				return false;
			}
		}
		if (sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.size() != pObject->sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.size(); i++)
		{
			if (sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ[i] != pObject->sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ[i])
			{
				return false;
			}
		}
		if (sbt__uT63JKv8eRfG != pObject->sbt__uT63JKv8eRfG)
		{
			return false;
		}
		if (sbt_wAzFZK5kCfSzDLXVcntQlB8.size() != pObject->sbt_wAzFZK5kCfSzDLXVcntQlB8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wAzFZK5kCfSzDLXVcntQlB8.size(); i++)
		{
			if (sbt_wAzFZK5kCfSzDLXVcntQlB8[i] != pObject->sbt_wAzFZK5kCfSzDLXVcntQlB8[i])
			{
				return false;
			}
		}
		if (sbt_Y != pObject->sbt_Y)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip.c_str(), pObject->sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip.c_str()))
		{
			return false;
		}
		if (sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.size() != pObject->sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.size(); i++)
		{
			if (sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U[i] != pObject->sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U[i])
			{
				return false;
			}
		}
		if (sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.size() != pObject->sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.size(); i++)
		{
			if (sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu[i] != pObject->sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_b1l2kOXAd6F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b1l2kOXAd6F = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectString("sbt_o0B3PDtdE", &sbt_o0B3PDtdE)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kojxbIcf1mTGxFPhQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kojxbIcf1mTGxFPhQ.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectString("sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1", &sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_800HnTFJJAGajqO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_800HnTFJJAGajqO.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_JAxm7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JAxm7.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BGqKMMwh1qqPwB2")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BGqKMMwh1qqPwB2.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt__uT63JKv8eRfG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__uT63JKv8eRfG = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_wAzFZK5kCfSzDLXVcntQlB8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wAzFZK5kCfSzDLXVcntQlB8.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip", &sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_b1l2kOXAd6F", (CX::Int64)sbt_b1l2kOXAd6F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_o0B3PDtdE", sbt_o0B3PDtdE.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kojxbIcf1mTGxFPhQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_kojxbIcf1mTGxFPhQ.begin(); iter != sbt_kojxbIcf1mTGxFPhQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz", (CX::Int64)sbt_x76fXS4uDkTlMmN7k2YYGYFXVRz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1", sbt_d8yDiXEnYrhlz8VOgKIyeheQSWYlhN_64PqehoBv5RjDOMw7X9YzY_yehkmx1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP", (CX::Int64)sbt_gPip6FYoBnosx96CiKa4G506gYLZZbyh4JiSFR22ZiLDBtG5PEFY4EQN8C7TP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy", (CX::Int64)sbt___95AbXsDFIQtMBCeB5GhGSLWo4LDT4njrZhy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_800HnTFJJAGajqO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_800HnTFJJAGajqO.begin(); iter != sbt_800HnTFJJAGajqO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JAxm7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_JAxm7.begin(); iter != sbt_JAxm7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BGqKMMwh1qqPwB2")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_BGqKMMwh1qqPwB2.begin(); iter != sbt_BGqKMMwh1qqPwB2.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.begin(); iter != sbt_1GraoQztegXmHmlo4KW7ISuVCtJVsw1y3B_BqJQ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__uT63JKv8eRfG", (CX::Int64)sbt__uT63JKv8eRfG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wAzFZK5kCfSzDLXVcntQlB8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_wAzFZK5kCfSzDLXVcntQlB8.begin(); iter != sbt_wAzFZK5kCfSzDLXVcntQlB8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y", (CX::Int64)sbt_Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip", sbt_r9pKTKizbsh9K_Ww9X8miLzYtuNR9D5OpQFnA0c2KlDflkFjtDbxiip.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.begin(); iter != sbt_0QvausQrCAImGAjScOQYeaLi669mwpWABUZtqLRa82U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.begin(); iter != sbt_HhAqOa_jQrqfWhtEXnZJckYt8GuskOpbxlGSIGzpkrxYwMr4nLp74urYLVu.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv>::Type sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0BvArray;

