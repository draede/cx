
#pragma once


#include "CX/IO/SimpleBuffers/ObjectTester.hpp"
#include "sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1.hpp"
#include "sbt_1a8ss7O616bqBSA0o.hpp"
#include "sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos.hpp"
#include "sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ.hpp"
#include "sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o.hpp"
#include "sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw.hpp"
#include "sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo.hpp"
#include "sbt_3GQkqLx8D.hpp"
#include "sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H.hpp"
#include "sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C.hpp"
#include "sbt_3cmksv9geLsONvo.hpp"
#include "sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU.hpp"
#include "sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o.hpp"
#include "sbt_4WlGd9_LehN8dLwRaQS.hpp"
#include "sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru.hpp"
#include "sbt_4uITTZHRL.hpp"
#include "sbt_5lCZz6s7wDo.hpp"
#include "sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch.hpp"
#include "sbt_6La1NvPRjxJcnkV.hpp"
#include "sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe.hpp"
#include "sbt_6mSKrq1ZBtodU8N.hpp"
#include "sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD.hpp"
#include "sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld.hpp"
#include "sbt_790qxxKesrw8JhTCk6JKh.hpp"
#include "sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB.hpp"
#include "sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t.hpp"
#include "sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6.hpp"
#include "sbt_8PrAD02NP2Mys9wp7957F.hpp"
#include "sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2.hpp"
#include "sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i.hpp"
#include "sbt_8rfMtEg.hpp"
#include "sbt_AcEqwQ57zeaissKeO.hpp"
#include "sbt_AfkSTpU1y.hpp"
#include "sbt_AjpZVa2qtd2oY.hpp"
#include "sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ.hpp"
#include "sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED.hpp"
#include "sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN.hpp"
#include "sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf.hpp"
#include "sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l.hpp"
#include "sbt_CUxWjwt.hpp"
#include "sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC.hpp"
#include "sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9.hpp"
#include "sbt_DSCkd6Sc31NxTW7.hpp"
#include "sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b.hpp"
#include "sbt_EGCPz9dt_WEgeMa1SKZ.hpp"
#include "sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf.hpp"
#include "sbt_EwUR103N00K.hpp"
#include "sbt_F1HEPEiQDJ1M5hlke.hpp"
#include "sbt_F37TR5tQnzaqiIY.hpp"
#include "sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD.hpp"
#include "sbt_FW5GTG6t9V_XSet7gY5.hpp"
#include "sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j.hpp"
#include "sbt_GtcIUaYWCt5kAsi2u.hpp"
#include "sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu.hpp"
#include "sbt_HNAQoVIBEDIwlsBdK.hpp"
#include "sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10.hpp"
#include "sbt_IEcPBwJwXG83EtM1Q2f.hpp"
#include "sbt_Isma3WO4mKz.hpp"
#include "sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X.hpp"
#include "sbt_JGr8WaY.hpp"
#include "sbt_JNQMeDiFBg8c0.hpp"
#include "sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M.hpp"
#include "sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv.hpp"
#include "sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp.hpp"
#include "sbt_KWIixjWKwnIDmuwm8.hpp"
#include "sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_.hpp"
#include "sbt_LOJR6JEUd.hpp"
#include "sbt_LYx.hpp"
#include "sbt_LeZoYnWlPD9T3MyZvtAF6.hpp"
#include "sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x.hpp"
#include "sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR.hpp"
#include "sbt_MB9ykZMXMVlFYrw.hpp"
#include "sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz.hpp"
#include "sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s.hpp"
#include "sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm.hpp"
#include "sbt_NBxyqWHcZuXZ9BFH4Jmdwathu.hpp"
#include "sbt_N_n0Grp5_2dTTTlFuVjOezBdT.hpp"
#include "sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5.hpp"
#include "sbt_OfTs8AqcrGZXthD.hpp"
#include "sbt_Okt.hpp"
#include "sbt_Pl1G7KOQyDq0chahR.hpp"
#include "sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq.hpp"
#include "sbt_QAL.hpp"
#include "sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU.hpp"
#include "sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW.hpp"
#include "sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2.hpp"
#include "sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I.hpp"
#include "sbt_SCONjR3uVv1OkwHTOiBiF_h.hpp"
#include "sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js.hpp"
#include "sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL.hpp"
#include "sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d.hpp"
#include "sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D.hpp"
#include "sbt_Tb75_HdXsxT7w.hpp"
#include "sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9.hpp"
#include "sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK.hpp"
#include "sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY.hpp"
#include "sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg.hpp"
#include "sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA.hpp"
#include "sbt_VP0m3dgugE01WmgaA6z.hpp"
#include "sbt_W5cdNUzMn.hpp"
#include "sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM.hpp"
#include "sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema.hpp"
#include "sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8.hpp"
#include "sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s.hpp"
#include "sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW.hpp"
#include "sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox.hpp"
#include "sbt_XqG.hpp"
#include "sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm.hpp"
#include "sbt_Y_Kf0R5IH5gCetrT3yAnj.hpp"
#include "sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9.hpp"
#include "sbt_Z.hpp"
#include "sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel.hpp"
#include "sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw.hpp"
#include "sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM.hpp"
#include "sbt__O0rzbe7K5DbY.hpp"
#include "sbt__dcrb7tOhPTt76Ux7s8iO.hpp"
#include "sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig.hpp"
#include "sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf.hpp"
#include "sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6.hpp"
#include "sbt_akvrSL312EbFm9F_H.hpp"
#include "sbt_ay3sSPIe8H7XoNbLaPobJRRSrBfJTjI1N6pKnK7dMrQPJfhJb0_aF1KdD.hpp"
#include "sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07.hpp"
#include "sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn.hpp"
#include "sbt_c.hpp"
#include "sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V.hpp"
#include "sbt_cYxfyXlT2u5kIewZ3To16AL61.hpp"
#include "sbt_chS2XwPcNdHG4.hpp"
#include "sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA.hpp"
#include "sbt_d7J.hpp"
#include "sbt_dH5OU.hpp"
#include "sbt_dNMvvc8oEEfvlTC.hpp"
#include "sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw.hpp"
#include "sbt_eRQEzrT6icmjXvB.hpp"
#include "sbt_eb3QS.hpp"
#include "sbt_ed0TyoV0DhYbr7TeWHk.hpp"
#include "sbt_fJSeP6Q4mlycPpoy_psMOYdj6Uq2LdANhoVUw4ObOuxv1ymQOYtnHONrI.hpp"
#include "sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz.hpp"
#include "sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3.hpp"
#include "sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy.hpp"
#include "sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P.hpp"
#include "sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE.hpp"
#include "sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc.hpp"
#include "sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r.hpp"
#include "sbt_gFaoed8jU0GqChtq6B3S3.hpp"
#include "sbt_gVagUy3.hpp"
#include "sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq.hpp"
#include "sbt_hl6ou.hpp"
#include "sbt_iiIaGp3w4dOzEOtO3ZBKdVRSBs2KeqdT9_kn2jod_JLoMYz.hpp"
#include "sbt_jVSCkaD5dp1.hpp"
#include "sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61.hpp"
#include "sbt_jgDm6sWUw.hpp"
#include "sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV.hpp"
#include "sbt_lAakdvN7vZFYi3BVt.hpp"
#include "sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8.hpp"
#include "sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW.hpp"
#include "sbt_m.hpp"
#include "sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c.hpp"
#include "sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3.hpp"
#include "sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp.hpp"
#include "sbt_mpTru.hpp"
#include "sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj.hpp"
#include "sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv.hpp"
#include "sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC.hpp"
#include "sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N.hpp"
#include "sbt_nckrD.hpp"
#include "sbt_o.hpp"
#include "sbt_o2fQv0E1teA4PJ2EmUSNtlc9a.hpp"
#include "sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX.hpp"
#include "sbt_oGQc9MTwA.hpp"
#include "sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw.hpp"
#include "sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP.hpp"
#include "sbt_q.hpp"
#include "sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo.hpp"
#include "sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ.hpp"
#include "sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA.hpp"
#include "sbt_r.hpp"
#include "sbt_sAccXmCocRm4NkkyuxK419Ipt.hpp"
#include "sbt_sJasUxO9i7amfCZprSmGy30.hpp"
#include "sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu.hpp"
#include "sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ.hpp"
#include "sbt_tCa9Hj0t6hLbmvzztOVk5bPU2.hpp"
#include "sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA.hpp"
#include "sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH.hpp"
#include "sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh.hpp"
#include "sbt_v8y.hpp"
#include "sbt_vIyeUTez_AIQhbcO6qaJK1GZk.hpp"
#include "sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4.hpp"
#include "sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca.hpp"
#include "sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl.hpp"
#include "sbt_x4N9bj4BcoO.hpp"
#include "sbt_x6tWbffuGKf.hpp"
#include "sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q.hpp"
#include "sbt_y.hpp"
#include "sbt_yP41Ndp.hpp"
#include "sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib.hpp"
#include "sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY.hpp"
#include "sbt_yjnlVxwXS3ejxjxjiuOVP.hpp"
#include "sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5.hpp"
#include "sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q.hpp"
#include "sbt_zbqLrepQMdLCJuk.hpp"
#include "sbt_0Mk8Rck1rfINzZy.hpp"
#include "sbt_0VDSUx7CiZIi0aij7.hpp"
#include "sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf.hpp"
#include "sbt_0tczk3ENzCH1OGE.hpp"
#include "sbt_0uCXiph9R2MT1pEZxqZlDVP.hpp"
#include "sbt_1JenunJxgM3mB2IZN5RnJol.hpp"
#include "sbt_1StwG513J36GaFhBP.hpp"
#include "sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ.hpp"
#include "sbt_2hPj9wyuJ.hpp"
#include "sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_.hpp"
#include "sbt_2nlE9M6VIZbAZqORGbUniQ_.hpp"
#include "sbt_331VBWiLJQSGaFc5Vf1qIWKbE.hpp"
#include "sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz.hpp"
#include "sbt_3UdYyNZlY8degDivo.hpp"
#include "sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5.hpp"
#include "sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U.hpp"
#include "sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed.hpp"
#include "sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD.hpp"
#include "sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf.hpp"
#include "sbt_4cSI_FlZV.hpp"
#include "sbt_4fXNpeqibRq0CYZ.hpp"
#include "sbt_4scTekdA5BAIdYB.hpp"
#include "sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2.hpp"
#include "sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP.hpp"
#include "sbt_5hVHTBsND_PpC_8rJzrElet.hpp"
#include "sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME.hpp"
#include "sbt_6St.hpp"
#include "sbt_6VsjZsRtbhp1gQ3Grjlcf.hpp"
#include "sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81.hpp"
#include "sbt_6yrElCpv9.hpp"
#include "sbt_88aVQDurN.hpp"
#include "sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH.hpp"
#include "sbt_8Hp.hpp"
#include "sbt_8RPVncJytCFj2kP.hpp"
#include "sbt_8_GxxvYia.hpp"
#include "sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX.hpp"
#include "sbt_8qUcC.hpp"
#include "sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz.hpp"
#include "sbt_91GK4C_VGqoHL65UK.hpp"
#include "sbt_9BLgCl9IRtR.hpp"
#include "sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M.hpp"
#include "sbt_A703ar5QLQQ5r.hpp"
#include "sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv.hpp"
#include "sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg.hpp"
#include "sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O.hpp"
#include "sbt_BUBzAS4Tx76Bc.hpp"
#include "sbt_BWK8Ke0sOoi4Keznrh6IjBU.hpp"
#include "sbt_B_DiPRSc3DU.hpp"
#include "sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD.hpp"
#include "sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w.hpp"
#include "sbt_C.hpp"
#include "sbt_D2lgRi655HoJQnFlCbXM6T3AtbE.hpp"
#include "sbt_D9D.hpp"
#include "sbt_DEljHSI.hpp"
#include "sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw.hpp"
#include "sbt_DVOyoWXSWuYPXMo_m7a.hpp"
#include "sbt_DYiGJ.hpp"
#include "sbt_DaYnmt3HzS2qSsGL_.hpp"
#include "sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j.hpp"
#include "sbt_DifMvh7RnTajStwKeak2e9wkOE26cCS4ZxyQIIEUTbMJKwj0M.hpp"
#include "sbt_Divi_eaOepx9zXHZWLF.hpp"
#include "sbt_E.hpp"
#include "sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB.hpp"
#include "sbt_EZ9.hpp"
#include "sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj.hpp"
#include "sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0.hpp"
#include "sbt_FBJGedd.hpp"
#include "sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr.hpp"
#include "sbt_Fxu3FQkTl3BJionNv6S.hpp"
#include "sbt_GHHVqF1RWIWEE.hpp"
#include "sbt_HLTF_vOHD2xgzZVQMatt200jNZdABGtxM.hpp"
#include "sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka.hpp"
#include "sbt_JHwNfHR7s8H3MB151.hpp"
#include "sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R.hpp"
#include "sbt_KDSyEE7NWzT4L.hpp"
#include "sbt_KINqCPj7699u_roummPniPC3amZ.hpp"
#include "sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k.hpp"
#include "sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G.hpp"
#include "sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO.hpp"
#include "sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn.hpp"
#include "sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ.hpp"
#include "sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl.hpp"
#include "sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7.hpp"
#include "sbt_NQxGsg1KCYRiWwuOnjAoWocKp.hpp"
#include "sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK.hpp"
#include "sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX.hpp"
#include "sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8.hpp"
#include "sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo.hpp"
#include "sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO.hpp"
#include "sbt_PJX93_f6gxUmsnqEk_TZN.hpp"
#include "sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI.hpp"
#include "sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ.hpp"
#include "sbt_QEU.hpp"
#include "sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0.hpp"
#include "sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW.hpp"
#include "sbt_RMQXtDjk8C4FIYZTU.hpp"
#include "sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke.hpp"
#include "sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi.hpp"
#include "sbt_SkBThSottdxsBldfWuB0_fXIQ.hpp"
#include "sbt_TANkjQOoxk4nsL0H63fzmm5.hpp"
#include "sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD.hpp"
#include "sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY.hpp"
#include "sbt_USEHjC3o8yvTt8_CGExNNTI.hpp"
#include "sbt_VNUKx.hpp"
#include "sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK.hpp"
#include "sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a.hpp"
#include "sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B.hpp"
#include "sbt_WfhAXizRFE8BuwKem5QYM.hpp"
#include "sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E.hpp"
#include "sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_.hpp"
#include "sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH.hpp"
#include "sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS.hpp"
#include "sbt_XlfNKHcqKz_hmeH3R5P8l.hpp"
#include "sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W.hpp"
#include "sbt_YC56TP18W.hpp"
#include "sbt_YQe.hpp"
#include "sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh.hpp"
#include "sbt_Z1UrAXCff9mlPGoWCkLSY80SW.hpp"
#include "sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY.hpp"
#include "sbt__9Qwo.hpp"
#include "sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5.hpp"
#include "sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf.hpp"
#include "sbt_a0uNasF2Sm0nnVey5DvZq.hpp"
#include "sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ.hpp"
#include "sbt_aTB.hpp"
#include "sbt_ae6G2.hpp"
#include "sbt_agu.hpp"
#include "sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH.hpp"
#include "sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww.hpp"
#include "sbt_bB7pJ06ZbTwktgOlX6ab2F_tK.hpp"
#include "sbt_bJ6BPs7vVwBd7yjaT.hpp"
#include "sbt_bltZyIWaKHLtLThcOgbXS7A.hpp"
#include "sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw.hpp"
#include "sbt_cOeLQAg366GjPE6SHlT.hpp"
#include "sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg.hpp"
#include "sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD.hpp"
#include "sbt_dkt2XL6q8TCNK7zSBzNEj.hpp"
#include "sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK.hpp"
#include "sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF.hpp"
#include "sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6.hpp"
#include "sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD.hpp"
#include "sbt_ebD2YgyqSIxzwq4eQrvNF.hpp"
#include "sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj.hpp"
#include "sbt_fRywTQ_Zjl3M8Psxm.hpp"
#include "sbt_g8dOw6ykyiVJImhB8zO.hpp"
#include "sbt_gEFFmQ6.hpp"
#include "sbt_gLiumf3.hpp"
#include "sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV.hpp"
#include "sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp.hpp"
#include "sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H.hpp"
#include "sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L.hpp"
#include "sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc.hpp"
#include "sbt_j110sfDS2NJVocY.hpp"
#include "sbt_jJLkD5_dC2e60AtetoWG4Vg.hpp"
#include "sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz.hpp"
#include "sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26.hpp"
#include "sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K.hpp"
#include "sbt_kA8FyEwnZJJ.hpp"
#include "sbt_kNLSYOvUrP9WT4OdNGmZM.hpp"
#include "sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf.hpp"
#include "sbt_l.hpp"
#include "sbt_l7KvLKCNYC5.hpp"
#include "sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_.hpp"
#include "sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp.hpp"
#include "sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_.hpp"
#include "sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh.hpp"
#include "sbt_myQJmArRECa46.hpp"
#include "sbt_n9bzv9w.hpp"
#include "sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4.hpp"
#include "sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p.hpp"
#include "sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0.hpp"
#include "sbt_oc_ySyrOZajC8Hz27rA.hpp"
#include "sbt_p.hpp"
#include "sbt_pW8e9.hpp"
#include "sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ.hpp"
#include "sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp.hpp"
#include "sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N.hpp"
#include "sbt_qxwtYrkYd29dl.hpp"
#include "sbt_qz3n8_Tu_Ua4lTcpAtorz.hpp"
#include "sbt_rHak30F5CXp.hpp"
#include "sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL.hpp"
#include "sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp.hpp"
#include "sbt_s8Xk5_MtSOD.hpp"
#include "sbt_t0c6dIriuWz7Uu6ddtSvc.hpp"
#include "sbt_uYjGrmz9SVs.hpp"
#include "sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV.hpp"
#include "sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f.hpp"
#include "sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE.hpp"
#include "sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2.hpp"
#include "sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa.hpp"
#include "sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX.hpp"
#include "sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud.hpp"
#include "sbt_z2tPz.hpp"
#include "sbt_z7V7j2R83fWj7sZN7YRoI.hpp"
#include "sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32.hpp"
#include "sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx.hpp"
#include "sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb.hpp"
#include "sbt_zhJORZFLhQEym0l.hpp"
#include "sbt_zkiylTSK5zkai9CW4I_wsLY83qn.hpp"
#include "sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP.hpp"


void DoSimpleBuffersTest()
{
	CX::String sDetail;
	CX::Bool bOK = true;

	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_0j3pWgu7lamkv1EFhO7pV7sovZvK41lkgtNua4mTQO4nFP1 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_1a8ss7O616bqBSA0o>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_1a8ss7O616bqBSA0o test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2aS0RPZN30FGBCeMfPl6DWv8Fe_ddD3WmkKfSTKluu2no6u8ffq1aqBos test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2di3th_LB6niDtXEJ6W3Jt4S_v5dCfEzmTnvqHyGKKKKFDm6NgId2fQ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2vgoqhqzLtu3lZQghkPJb_V2wLLEyOk3OIRddo9axABkVpg7lOI8o test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2yoR04yvrznbO8Sbsf0Nq1clSzVqQvlRRXm8eLmuk_urw2r9RjRDvN9Tw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3EGsu0EdkECa5qkByJByYIg9CUlLLvMU7LSw9AAF66qQn_aX9cnhepRM3v7XnOo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3GQkqLx8D>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3GQkqLx8D test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3IME132mt_tiC4K7KDM5CK3S0FaRotd007CrjUqItHn9H test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3LfWWR8JOO6IEr6_2x6eoI3XV_v_C test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3cmksv9geLsONvo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3cmksv9geLsONvo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4Lb9FrkhAuv7vNB3fbh4hAG2n6ItkbPzU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4TlFf0MbMmvxhrzhWVqleM3Oj1o test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4WlGd9_LehN8dLwRaQS>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4WlGd9_LehN8dLwRaQS test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4ji81swsXouNZoY46zs_pIzOHSTU4fw1jgCWbiCGCJGru test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4uITTZHRL>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4uITTZHRL test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_5lCZz6s7wDo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_5lCZz6s7wDo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_5zRi3GE0lVB7dcZ3Uc19HZy67dxuWF2qcch test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6La1NvPRjxJcnkV>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6La1NvPRjxJcnkV test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6ddYV5aXDqNbJx7VJvdfDPtdGnQRkLe test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6mSKrq1ZBtodU8N>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6mSKrq1ZBtodU8N test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_72wDk7LkxpJFjYEIhQFs_VzR_ZNc45uJFZI6mvkcD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_73Z8jkxhg8MHnYIyocEbTRQilC_Ax_HFuSDSm5aUC7p8JvZQYIBPhld test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_790qxxKesrw8JhTCk6JKh>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_790qxxKesrw8JhTCk6JKh test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_7A_NqR5N2PpUctTbqJwa5yUFeTkQRdB test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_7Uk56wUb30MU9b98hAdPz73r9KueKKV6t test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8PrAD02NP2Mys9wp7957F>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8PrAD02NP2Mys9wp7957F test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8Y07raMf5Dcn_mMnHtflbWnJGxe8LdUkcyjvQ2VooR4Adw2 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8jr5YQ_oN_ILPEwNRyLauZnOiAHeBUN4i test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8rfMtEg>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8rfMtEg test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_AcEqwQ57zeaissKeO>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_AcEqwQ57zeaissKeO test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_AfkSTpU1y>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_AfkSTpU1y test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_AjpZVa2qtd2oY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_AjpZVa2qtd2oY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_B7JqN9d4Dr2tC3J5jIRd4SOvELfJ4boVTz7DZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_C0X_1ayccJkTaL3uDhPyczU19WmSHDIScRYvh9gvvCN8_C0HIM81pYdWPJvVN test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_C57RItcaPZeZd_8fR4Gf_JAspyW5RmcehddEbs8rf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_CT4pPG5SwdsVYjc5aOThZKC1v0l test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_CUxWjwt>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_CUxWjwt test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_CZFmDASp6Vh_CRVmuNRpLRwLkU6j_Gfu8lQeCip9ZCA11NQVsNC test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_D6YXH_NddLBCcuzTS2z9o2VL4Vx33KW02NrRZLcnv0Y43u9 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DSCkd6Sc31NxTW7>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DSCkd6Sc31NxTW7 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_E4MngaqHLMpEqNa0UvoWOhaqz_xP21SpS4S4TTWVgbTIldpiVDi_v2b test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_EGCPz9dt_WEgeMa1SKZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_EGCPz9dt_WEgeMa1SKZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_EYConMa6hYJxF0WAcmr5xYi92q0dfqf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_EwUR103N00K>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_EwUR103N00K test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_F1HEPEiQDJ1M5hlke>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_F1HEPEiQDJ1M5hlke test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_F37TR5tQnzaqiIY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_F37TR5tQnzaqiIY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_FGruSuOiEzIFYZRJBQlPNIwKw4GYcUO6i0XtVfD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_FW5GTG6t9V_XSet7gY5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_FW5GTG6t9V_XSet7gY5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_FsCIFNWxA90Va7EreZPLZcJ_oqlSTVjOJ3K4JzhxY8P1j test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_GtcIUaYWCt5kAsi2u>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_GtcIUaYWCt5kAsi2u test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_HE4NElmnkFvdurwfdoQ0KWAuYPiFkQfWewnY2BurbW8Qlf740en7IPu test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_HNAQoVIBEDIwlsBdK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_HNAQoVIBEDIwlsBdK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_HmbxfWjFMcsBBkoeta9fSrdUdh7aJzIXYaEuR92aKrdV2ybvM10 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_IEcPBwJwXG83EtM1Q2f>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_IEcPBwJwXG83EtM1Q2f test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Isma3WO4mKz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Isma3WO4mKz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Iv4ll2Bzv3JtPS5fD2d2rJym4KvPP096X test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_JGr8WaY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_JGr8WaY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_JNQMeDiFBg8c0>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_JNQMeDiFBg8c0 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_K5_DvF3UawwHUinJULmRRLYO17C2nUCwoEIR32AKC7PMB4dKAdFfB4v0M test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KCXmBF8G9QFDp1L689qDdz2KR3AVv test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KJY5tzcZmXc_aLg5X_2HQjYJHuckpeKwqBR1hsZxUBqn8IEfxk1YHd3jp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KWIixjWKwnIDmuwm8>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KWIixjWKwnIDmuwm8 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KXmRFPkWbmewwvWYXorTwV7g2PmQ4JePFh52oElM72FWYimdRCfMypoc_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_LOJR6JEUd>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_LOJR6JEUd test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_LYx>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_LYx test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_LeZoYnWlPD9T3MyZvtAF6>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_LeZoYnWlPD9T3MyZvtAF6 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Lkm2NxVYdu_AP8m5AVRyIrbXmugcY7x test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Lmw88Und0xOKZjQsGRIlOu7YnaVsvGR test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_MB9ykZMXMVlFYrw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_MB9ykZMXMVlFYrw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_MVraj4lvahSXdDEBHK6CHLAMdQo_Xi2EGKjv9caFF7JfR4gTXRc2TlEAjVz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_MXBXN24KbUVVdtSgPhkH3ypaW_k9s test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_N8DFrKdak4nBDQByfRAUBKl9dbcCm test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_NBxyqWHcZuXZ9BFH4Jmdwathu>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_NBxyqWHcZuXZ9BFH4Jmdwathu test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_N_n0Grp5_2dTTTlFuVjOezBdT>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_N_n0Grp5_2dTTTlFuVjOezBdT test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_OSF0mmFj99GiOuRy1bVx8bbJV97D5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_OfTs8AqcrGZXthD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_OfTs8AqcrGZXthD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Okt>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Okt test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Pl1G7KOQyDq0chahR>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Pl1G7KOQyDq0chahR test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PwDkMSOglzXktnItzLXSyk6w9Oj90zojq test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_QAL>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_QAL test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_QPysLhCaKTgWgYnqxRCu4PlqYFpj0MnscQBJU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_QzuYiQHdvNsDxYc5zRJY24abgZumnpeXj0_Ro0hrW test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_RMbe7l2_uPMXfaLJBdUHNUt82Ky8LR2 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_RdfblX9W4gXS9osxTD3xCQZo4BH0I test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_SCONjR3uVv1OkwHTOiBiF_h>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_SCONjR3uVv1OkwHTOiBiF_h test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Sqn_XfFMclAG7bpcFHWtG0OfTbOZN0uSm9Kfk4c5lEL test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_TAVnrot9MRUnBE1sVSGF4IYO9knEfuJ_DbeyoQV0d test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_TZ_fwQKPMNnwWAzu13SyRHuMXFPV0G3XM9Dwvb49Xa6jeQG6ry64TQWeBFV4D test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Tb75_HdXsxT7w>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Tb75_HdXsxT7w test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_TxxAiHy46B3xULYBSYOzaUUItzjOBdZkpVHQDGIL7pot9 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_UQpJuYtATto3u3Vxne3t1Y9z3UPct9imM40f2TmGyIhWAGAl_C76FCLTK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_UeP9Zl8Mj7a3_BbOw8tJCC0Nu4ZOeX8iP_3xByAG9nHhLbxxvRD6UzIk99_UY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_UrlXJOIT7sKcZBplDxIskm7H5TJaV9IWSnJZAvoytF4ctWADD3hQEfU2AMg test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_VP0m3dgugE01WmgaA6z>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_VP0m3dgugE01WmgaA6z test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_W5cdNUzMn>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_W5cdNUzMn test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_W7Zh1v9f9UoWsheaqtkZ75uLIRSIi1w4qGN4hD6jgpHvLCM test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_WVBJXMUDPhuDVUWi9cXhNohPhxwc1FJ7znWq1quY77ema test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Wim7g3ZvERqCNyw_fTn2z8WoXDQox20N8 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_WpvSItaeLoyMWUhE66QnTRQ99UaTSj_d2HzNZinpjTbui3s test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Wxae8hAazcL1DXcRkrrMZLiIDy_jU61dmBW test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_XnLqcUDd69RQUT5oF_GDVqLI5e7OXVIHk5JrNM8D_VrUwJLQuox test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_XqG>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_XqG test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Y_Kf0R5IH5gCetrT3yAnj>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Y_Kf0R5IH5gCetrT3yAnj test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_YaC72DFopNfD1vkHFqG_fB11roxFSQDbcREfgr8u4mkpQ9ZMNEMOkO9 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Z>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Z test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Zcv2guXbD66urmDrVTjWlqOiHF48dcXgyYAZ9Rubc54oJxnIct80HPmIM test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__O0rzbe7K5DbY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__O0rzbe7K5DbY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__dcrb7tOhPTt76Ux7s8iO>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__dcrb7tOhPTt76Ux7s8iO test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__wTmpOdtdxzKr6Ttmi6OmZRBoOUU3ODxYtkSdXu4uk827DOdyRRguJlR4P4ig test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__wZbT1ZLdF6J2jdSIeGUpt1ypg8tlDDeaO40WlEpzyUC4GKIx6XNYbf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_adoXB8QMN1VnbIkcxoWWAjZTnKzj_6ArhbFij9gv6 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_akvrSL312EbFm9F_H>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_akvrSL312EbFm9F_H test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ay3sSPIe8H7XoNbLaPobJRRSrBfJTjI1N6pKnK7dMrQPJfhJb0_aF1KdD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ay3sSPIe8H7XoNbLaPobJRRSrBfJTjI1N6pKnK7dMrQPJfhJb0_aF1KdD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_bT1OR43UWD0KNgVRSt4Ww209KNBiWrEJN_IGegn test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_cYxfyXlT2u5kIewZ3To16AL61>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_cYxfyXlT2u5kIewZ3To16AL61 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_chS2XwPcNdHG4>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_chS2XwPcNdHG4 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ckU0oqGbpyMbwo7j0AFJw92Nl9zaolc85f7UZLym428HA test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_d7J>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_d7J test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_dH5OU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_dH5OU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_dNMvvc8oEEfvlTC>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_dNMvvc8oEEfvlTC test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_eI4GYtAAMBwGvL7qTGF7qrcdjhvQxht2eKwlw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_eRQEzrT6icmjXvB>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_eRQEzrT6icmjXvB test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_eb3QS>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_eb3QS test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ed0TyoV0DhYbr7TeWHk>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ed0TyoV0DhYbr7TeWHk test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_fJSeP6Q4mlycPpoy_psMOYdj6Uq2LdANhoVUw4ObOuxv1ymQOYtnHONrI>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_fJSeP6Q4mlycPpoy_psMOYdj6Uq2LdANhoVUw4ObOuxv1ymQOYtnHONrI test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_feBYF_BAZOYMn3gdZEnVEPbUEunuaNodx5ee8ViJQiHsKE3kaWhj9yX4_rz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_fiktR0c4WBmvu4G1LNMEkPvP_pCuW1mXDE6yLF4_YRiZ9wLDYrzbAETzMxO94D3 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ftcg3TLFmgyvhpFV_Ep3oiF0PXxdy test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_fxx0LHpM69Z4prZ4ppveeZJiGqgTVtfljTDqbWLcKfax7MQRD9P test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_g2js4xzB6RzXfQhrudfAk4fHaefHhcUpe9FiYmluBIDsYNOYE test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_g9l5TdnkHWLbHWcSTJcnNc1GjdnCDQc test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gAH_dSn2j0bI4YtTnrzsdIoAprlF7XXnhGFm1uCvGyPmtKkuQrLDch7udEO972r test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gFaoed8jU0GqChtq6B3S3>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gFaoed8jU0GqChtq6B3S3 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gVagUy3>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gVagUy3 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_geQSeC5Jgrj6fdHTr3YOH9yCBg8EQmq test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_hl6ou>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_hl6ou test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_iiIaGp3w4dOzEOtO3ZBKdVRSBs2KeqdT9_kn2jod_JLoMYz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_iiIaGp3w4dOzEOtO3ZBKdVRSBs2KeqdT9_kn2jod_JLoMYz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_jVSCkaD5dp1>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_jVSCkaD5dp1 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_jeIO4_7Dn2sBxT4qDZOzlR4QUy4e0hOPxN6uRqnakA986_M1ikmJk61 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_jgDm6sWUw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_jgDm6sWUw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_lAakdvN7vZFYi3BVt>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_lAakdvN7vZFYi3BVt test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_lAyKfUUZE73Bwj8teTZG1GSsiYifIw681vPaoyNm4het8 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_lfbU3AX6miTuYD0UXsoUD3fDAhwKEYPkmrKoHC0Y8hSMobCxCAzo1_kvbsW test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_m>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_m test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_m0Xa7dGUmceQ1eJzqeV4ewe9fVD4qMe8GIZ5c test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_mC9v2u4d6nuAzZDey98TyDXcEe79epcfyRLNYU0wi9LOZn3 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_mpTru>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_mpTru test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_n6e_7LwgX8Y1VMtBKrz7cXmFd5y2Bpxnj test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_nA3qXuRjaWZzk0iJ6Rf5oPYnTVLPmBdm79hPcJwy5gUZxzwGjZyY8NTZ0Bv test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_n_4cjxuppmDE0TFozqv3grBbsDM4N test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_nckrD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_nckrD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_o>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_o test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_o2fQv0E1teA4PJ2EmUSNtlc9a>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_o2fQv0E1teA4PJ2EmUSNtlc9a test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_o4WuJBYanvBoToiU6VrzdbpM2V7gX test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_oGQc9MTwA>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_oGQc9MTwA test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ooaz5jN7Um93iqbDqfmHrhbRFnw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_pwA5PPrc_nZSRC623JZjqeM47UXbtUKaP test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_q>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_q test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_q7AWhOd69tImaN0dvAReKxhv5blYKZ_4mBKxHJo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_quxh6Suw9KQfQFm6zwcCBr90c_ZpRYZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_qwLRTo56bRrGh4bL5kkowaNSdxENC_xCL5igb_HQINzAktOo2WA test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_r>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_r test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_sAccXmCocRm4NkkyuxK419Ipt>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_sAccXmCocRm4NkkyuxK419Ipt test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_sJasUxO9i7amfCZprSmGy30>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_sJasUxO9i7amfCZprSmGy30 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_sXeSKXP89x3PHVXLR6ftFkT96JOfXqu test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_tBrZTvaLWLCXDeahvGpUKX5POYqkBUqTr1Lt0mZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_tCa9Hj0t6hLbmvzztOVk5bPU2>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_tCa9Hj0t6hLbmvzztOVk5bPU2 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_tzALSMj3pkANpZ2HJSlwE8SqstX7DtQ63pA test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_uDl7bxurh95FbFv_VaSRVsb62I5y6hRp_VpaVI43M3OU1zv_14TuH7mQH test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_uasTqAovLJOfH2cuBG8aHYn_73SsQUWumKzKD2J7BCecHYz0oJhLg8OGGL165Yh test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_v8y>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_v8y test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_vIyeUTez_AIQhbcO6qaJK1GZk>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_vIyeUTez_AIQhbcO6qaJK1GZk test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_w0fORs8aqMmibjwqrsMJMUf6y_iZrVIahBRF1k2i9j4 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_w72KyKFaC2yiDqMCqeMP3x2_77yHkCND_ca test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_wf3SH7lniBVlf2vsqYUV85FoaNNo4LkDz_WIl test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_x4N9bj4BcoO>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_x4N9bj4BcoO test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_x6tWbffuGKf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_x6tWbffuGKf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_xZX3w1ttGMrTwqeNGIimRGaeMWJ5axUjY6ShAwznV3PFnI19fZvY67Q test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_y>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_y test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_yP41Ndp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_yP41Ndp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_yj4fvr7zfZVoeh6hR8tgiOJoGrBdm31C_U9V4E1dLQ8Ib test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_yjhYtKBYCkPZS8XBgOLZ8AVAcOfzhUQTErRODxvjWEY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_yjnlVxwXS3ejxjxjiuOVP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_yjnlVxwXS3ejxjxjiuOVP test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_yn2X64nlradevqmEyRvYdmwkZBmZBXpH5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ytiEGmqydKSIKNTPj_sNEf3VhEypWvb7VVxsC1zVk3Fj_sZ1q test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zbqLrepQMdLCJuk>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zbqLrepQMdLCJuk test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_0Mk8Rck1rfINzZy>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_0Mk8Rck1rfINzZy test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_0VDSUx7CiZIi0aij7>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_0VDSUx7CiZIi0aij7 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_0tczk3ENzCH1OGE>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_0tczk3ENzCH1OGE test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_0uCXiph9R2MT1pEZxqZlDVP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_0uCXiph9R2MT1pEZxqZlDVP test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_1JenunJxgM3mB2IZN5RnJol>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_1JenunJxgM3mB2IZN5RnJol test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_1StwG513J36GaFhBP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_1StwG513J36GaFhBP test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_1d2jOY_OBkrsJNzdmG76RN9OOZ_GbjA6gUzrWtdrfbQjJhYOHDz5fUYLZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2hPj9wyuJ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2hPj9wyuJ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2kBvJuDUXk6PdNs7yrPYQpeYucHtTn1gMVXzIJgWpL9reUSiN7_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_2nlE9M6VIZbAZqORGbUniQ_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_2nlE9M6VIZbAZqORGbUniQ_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_331VBWiLJQSGaFc5Vf1qIWKbE>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_331VBWiLJQSGaFc5Vf1qIWKbE test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3PTpEXTIhiL1zVDQtWFHUcrFaYlXlSz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3UdYyNZlY8degDivo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3UdYyNZlY8degDivo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_3xr1Cpa92o8MQkcZa_GPp25Si4GJLl5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_47AmDhp0wDdrT1xMISN56MPqljYZ7f3wA9hnzJogRrUV7gyXPNZeYbYxSaF0U test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4QXED6Kg5iLN63BZTm764J3lOhuRGr60qVjx_V22GpHed test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4RvPl_32awhJ0XL3oZZUgq3922NiVDjyhQGgXYQEYf6pYXD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4YmXux2Gvb1G4u1JCzk5IkLvMVf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4cSI_FlZV>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4cSI_FlZV test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4fXNpeqibRq0CYZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4fXNpeqibRq0CYZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_4scTekdA5BAIdYB>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_4scTekdA5BAIdYB test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_5FjyYtorqzW240ay6GdTrORi6ZCYEPG2GrKCYjjfKZ2 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_5JxpywowNAzdutOyQ1fkzs3jvKAsv4QAH24XlQkDUOjOYTImR07kP45NP test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_5hVHTBsND_PpC_8rJzrElet>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_5hVHTBsND_PpC_8rJzrElet test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_5lI6cf4OTpsk9sXdKMEkvSm_X51tj_uworJwQTfiiZovElcUyLOJz1vIWXKME test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6St>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6St test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6VsjZsRtbhp1gQ3Grjlcf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6VsjZsRtbhp1gQ3Grjlcf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6wHBoPYUF3ZhADaRJ4PhLld8IYleQ3Pdomk81 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_6yrElCpv9>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_6yrElCpv9 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_88aVQDurN>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_88aVQDurN test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_89zGk7UV5fFmxtzvRKgJ2CcM63dcu8WFvzH test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8Hp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8Hp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8RPVncJytCFj2kP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8RPVncJytCFj2kP test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8_GxxvYia>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8_GxxvYia test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8lwqswdpTjYv9VbG5l2zUg9yTLH4sMN70nkgcxX test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8qUcC>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8qUcC test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_8vj6F0UigN0M2BQRjKQBnR8EXr8UzAux7UmtLL6GCyz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_91GK4C_VGqoHL65UK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_91GK4C_VGqoHL65UK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_9BLgCl9IRtR>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_9BLgCl9IRtR test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_9j7NDCbwTLkIAHaXNhU5AVxpkGe0M test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_A703ar5QLQQ5r>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_A703ar5QLQQ5r test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ALzYSpKOBy7FonIx_BVw9JBwQs8mZEIzv test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_AYcmjmndNda6qgQehZtiDOPFrkpiOjWPl7zWMvz0mt1HqY8jx4KahxYRg test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_AjqdH8vCV37rGhdwK6dWAwYebbOCWiYxjn4hRt2qc7ktQS6ecHBPN3O test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_BUBzAS4Tx76Bc>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_BUBzAS4Tx76Bc test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_BWK8Ke0sOoi4Keznrh6IjBU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_BWK8Ke0sOoi4Keznrh6IjBU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_B_DiPRSc3DU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_B_DiPRSc3DU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_BmDI_1hUGDNsQG1wFnzYkGYBDhByo2Ly87j0tAXhQ7HUNDUVdwIdBwOOQl1BjCD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_BpjuqQTRW3OiwoZnJnMYpUojKuF7DX69vf8pjvv8w1hMSyGKm1w test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_C>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_C test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_D2lgRi655HoJQnFlCbXM6T3AtbE>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_D2lgRi655HoJQnFlCbXM6T3AtbE test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_D9D>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_D9D test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DEljHSI>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DEljHSI test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DFNMXUdOOUNpzz1Wxh3yA0E78RvL4NThl9xKYXuTvk6PhAx80ETCiSLROkRCw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DVOyoWXSWuYPXMo_m7a>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DVOyoWXSWuYPXMo_m7a test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DYiGJ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DYiGJ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DaYnmt3HzS2qSsGL_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DaYnmt3HzS2qSsGL_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Db14yQO1fP5sQR1VP_t367rOQmHW80XyhdLJ35po2vEetL7SuQhqUVBcHJ2bA1j test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_DifMvh7RnTajStwKeak2e9wkOE26cCS4ZxyQIIEUTbMJKwj0M>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_DifMvh7RnTajStwKeak2e9wkOE26cCS4ZxyQIIEUTbMJKwj0M test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Divi_eaOepx9zXHZWLF>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Divi_eaOepx9zXHZWLF test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_E>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_E test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_EM5o1dHr_7UdD4xbXOY5U1K_nAfJ8lB test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_EZ9>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_EZ9 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_EiyFStzaEOF3s0bzjEMxd7NI4QHgHSbDhFnJd8yznC4kedbVssm0DP3jGqj test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Exxe5W3BuROmm6UOV0YLmVeK6AwaywAa4_XIInpHf20ry6Rh0 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_FBJGedd>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_FBJGedd test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Fio0kX2PINCMhLRtQc8ghryfrbDCXpkxh4FOcq7L6_TBmmsLr test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Fxu3FQkTl3BJionNv6S>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Fxu3FQkTl3BJionNv6S test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_GHHVqF1RWIWEE>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_GHHVqF1RWIWEE test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_HLTF_vOHD2xgzZVQMatt200jNZdABGtxM>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_HLTF_vOHD2xgzZVQMatt200jNZdABGtxM test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_IMU2U83vkmZxNwF38CoyqJlQYGKrak2lCjwfVka test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_JHwNfHR7s8H3MB151>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_JHwNfHR7s8H3MB151 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Jybo5gIc35IDlwZeQKabUKaiB_wzh1R test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KDSyEE7NWzT4L>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KDSyEE7NWzT4L test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KINqCPj7699u_roummPniPC3amZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KINqCPj7699u_roummPniPC3amZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_KMt6r8UJmdhEjlPUIohUpcdHBRSo83k test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_LJnkXmECVyLvAsdQEDF3Xe9IcMiOE12TSmdZutrbVeqodzrBMudc93tIU2G test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Le8_Wsw3dAoK6zl9HECZmbkTWGjLPfMrcVP2yCAN2LrQHYbIUkGOqvO test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_LicQ6to6Fe1bMVkWKUz20TOJw5BxexyRO6T1lPEwpY6XBonc2YLhIgn test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_LsE8XCCSj2rn6KQ0hHSNKJR3IXM7mYIgYc5LC9IZmNW6ONdiJ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_N38SGUfGHdE5QLH9vcz6bKXSwfuoucbn9RCA9naxl test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_NPUXG1wa4kEZrX6zKORcFbNvW_vaQIFVoaZ9XbPw5PCwlRbxCg7 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_NQxGsg1KCYRiWwuOnjAoWocKp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_NQxGsg1KCYRiWwuOnjAoWocKp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Opzbj6HacUsNyYMURUYfXZcGfIyNSTXmlk5CxUuzDHaspeK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_P28QACFUToZRzgAV1h1ZTiW8anRQ6mAZbcxlZrJnAh47NUYQhOX test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PBWaiWpsFrhBg2NS5hlVdVznCy8 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PEqTCGVLy7zt8zaBpyjcHsJzKoo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PFpnCUARweyfMiWxyOHmmkMTc9FuRORsLlH68yJi0GXdakfHr0u5RKbmnWO test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PJX93_f6gxUmsnqEk_TZN>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PJX93_f6gxUmsnqEk_TZN test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PQkCLS3DYvwL1LUwek07tirK5KK3EA0Mab1rrC7Rnj8_2Bs_goI test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_PzDT_yrYew2teSsrXMZIuUAqrYyGdYJQGYOjIwc4S3MogtC7GGqfKSKnIHB37oJ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_QEU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_QEU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_QFkGHMPC0ldcLdv4Kj__0JZBFFwpocvVPc_68L9HRpimOn9IMOS73E7MIR0 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_QizSZxz1HMHiFKj1TCqJzalI0YEGW test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_RMQXtDjk8C4FIYZTU>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_RMQXtDjk8C4FIYZTU test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_S2fouIGH4Za3s8m195WC9YWGYFil8xaiUwNhwollGrGE4Rze3fgI3mThP0rke test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_SWxMB1lExfuzULVV7Y3ImJysx_PlSUXBOTY3ZKi test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_SkBThSottdxsBldfWuB0_fXIQ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_SkBThSottdxsBldfWuB0_fXIQ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_TANkjQOoxk4nsL0H63fzmm5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_TANkjQOoxk4nsL0H63fzmm5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Tuf9HvAeoAWJNMtdm7nA4_RmfNKVStnwBNU7YjdJ2r1BjrD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_UJ2Z_KdLUMwcG2HzvV88Cvg1snF8WDHZc4RaObfg0F98SuMAZ0LqY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_USEHjC3o8yvTt8_CGExNNTI>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_USEHjC3o8yvTt8_CGExNNTI test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_VNUKx>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_VNUKx test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Vtnh8WrBcPuhZc2eOQUsoACod4Ni2yWxNgr8lxV4wTDlbP2GwFlSUJxyK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_W9M0kbtQOjZDTt_bvHXBL9KAAfd_2opBTahsf9a45PGRK8KPUSRFa2a test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_WOPPsOudOE0FuA0HQXP6QX_q4JsStMhUFDK_B test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_WfhAXizRFE8BuwKem5QYM>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_WfhAXizRFE8BuwKem5QYM test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Wz4BOVEzlpPoY63cbX3Ksx_q79t7E test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_XOPPcPLGdVVQTMXqM5gu1KvxI1_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_XTSeZhoAjqRxX_BpdIJcVEjkrD_QhHNRRJaOONGAVJrXCdtJuY37z7BwH test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_XepaIajiY5S5qm9RhuwE3zAAXfXmg4jloDCtZAjdjGSaZGD0kYaXC7_aI54VS test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_XlfNKHcqKz_hmeH3R5P8l>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_XlfNKHcqKz_hmeH3R5P8l test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_YAQzuw3IdILLyYdSofwNLvpoYpmYEkYyCIBMs1W test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_YC56TP18W>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_YC56TP18W test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_YQe>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_YQe test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_YuZroTxdRL5OKe7vLstthG6msBPrBGTk6ExlWwjuhOTOdj2gh test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_Z1UrAXCff9mlPGoWCkLSY80SW>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_Z1UrAXCff9mlPGoWCkLSY80SW test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ZZM2H7uzS53FEhWQOo1VvG1cYKY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__9Qwo>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__9Qwo test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__ysdILu7X1mhU6mS1j7wq0LmNWIcnXaw9evyHA4jkprDuTmVjFfR5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt__zrEpU_LdZIreBUXpCclILK7Cv1rxuJzVmozGlytf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_a0uNasF2Sm0nnVey5DvZq>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_a0uNasF2Sm0nnVey5DvZq test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_aMpcSKnQ6n5sTfkrjDu2IqMMiaF80wRmZ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_aTB>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_aTB test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ae6G2>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ae6G2 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_agu>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_agu test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_b7BTMG7qv0345i406oXXuChQ5GbFs2arWSzsEd0Vao7c5msyH test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_b8758G0VoZ1XbrlyloOLKwJ4Jww test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_bB7pJ06ZbTwktgOlX6ab2F_tK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_bB7pJ06ZbTwktgOlX6ab2F_tK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_bJ6BPs7vVwBd7yjaT>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_bJ6BPs7vVwBd7yjaT test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_bltZyIWaKHLtLThcOgbXS7A>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_bltZyIWaKHLtLThcOgbXS7A test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_cO8lWu2INHarzlKfy_2dRWH29BhaKjCmgY7XZ9DXSDiPbnHFw test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_cOeLQAg366GjPE6SHlT>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_cOeLQAg366GjPE6SHlT test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_cPseHrLkUCTSuPNxLhyJ_oZWWoaRF9aGX_1vRJQplsqYsAeyKsynQfUZGMJJg test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_cx4eT7PO2ScVRthDXJ8vF8XWXSYIwleT48ITD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_dkt2XL6q8TCNK7zSBzNEj>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_dkt2XL6q8TCNK7zSBzNEj test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_dx2hyg1nqLQ7m2ZysTCXUwHRbGqFqsJBZiK test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_dyRIDUw0732RMpmge_xKG6QsBKssENXU5D4R4GzLMCsnrHehR9zuQuExgOF test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_e4dGIXjZyJd_BZZVlStreJCco4AG5uLTH5a54ha4jVIMxRaL6 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_ebD2YgyqSIxzwq4eQrvNF>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_ebD2YgyqSIxzwq4eQrvNF test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_fMatY3J340V2FTki1Jy8I_MZ2Cj test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_fRywTQ_Zjl3M8Psxm>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_fRywTQ_Zjl3M8Psxm test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_g8dOw6ykyiVJImhB8zO>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_g8dOw6ykyiVJImhB8zO test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gEFFmQ6>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gEFFmQ6 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gLiumf3>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gLiumf3 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gM7LWnBj1DoX2LU5g4j955BNoh3xPxHpcdMYOaSjhVkPjy9nmOBYV test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gVWaLMRYM8BKqsheVRB28GcBcC3sVq4A_9dSryM6zZvpkMnxCHQ58Xp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_gnon1aXai2GxcwIf_kgV3XiaUEwKeqYgASdrn1kscZgKQim9l_H test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_i8nN7nIZ6MX3vyf8qLmCVTPgwT9F1M86fkKVb3knbxqJk0L test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_isWOOb5UXD__PZrF4T1IiTk8GyrxX5apX5a9Tc3HGTc test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_j110sfDS2NJVocY>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_j110sfDS2NJVocY test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_jJLkD5_dC2e60AtetoWG4Vg>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_jJLkD5_dC2e60AtetoWG4Vg test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_jcqgsm4lXJ1mX12Y1PQsu4D3_G_iWcz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_joxhNZ_0x1ZWnzlZFanqYjlS2mtwDPc_9VZCQaY26 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_k0Xz29Mn1J47swiu7xzoTOOcvV2n59K test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_kA8FyEwnZJJ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_kA8FyEwnZJJ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_kNLSYOvUrP9WT4OdNGmZM>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_kNLSYOvUrP9WT4OdNGmZM test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_kwhQu2KhoDSzqR4cSJrZLq_ORxcCvIKAklPHKcxAuEMHywR2iFiXj0hecKKlf test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_l>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_l test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_l7KvLKCNYC5>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_l7KvLKCNYC5 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_lDcYBE9ZV7PbxjQ_JHHoAvFof0OcRlROvnzhT9MBbiEWZxkIVxL7kDRqZoh8_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_lhqBg8JjcXKQvJ8jxqtzzzKNhdmmPeJhVDTUr_fKjOFXn4UGAfQbcWPDHFfikRp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_lkBugN5V_eibGAqPB5ms1yTkyaqeATzVvXyqkgjTRAiZZa_ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_mtYjTKaCXwJ28GpDlZOI3K71nWt2wwh test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_myQJmArRECa46>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_myQJmArRECa46 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_n9bzv9w>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_n9bzv9w test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_nF1nO77Jq1fXkkq3oUhf6MCX6E4 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_nJLuvbGPcgj5FH6Q9rsjOTKh6OaZf1p test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_nYCNjsiEq2rmpsKoYhZdoZa9OyMEX3trkr5nkraRblFnAIwjyd0MFQHiIvPg0 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_oc_ySyrOZajC8Hz27rA>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_oc_ySyrOZajC8Hz27rA test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_p>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_p test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_pW8e9>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_pW8e9 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_pdr0xd4_Os1Z8HjB_CYAvKjm_y2ZhWt2BtA4_r7bfzxmaHWa66axZaOpQ test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_q3r6OE7o9QYyiqlbUvPddV6MGXmJ9dSwAvvS7FvA3Rp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_qL6BhDJCsLS4cr9F0Wp9naN66ycAbFaiVgPTroU8a9RGEx43N test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_qxwtYrkYd29dl>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_qxwtYrkYd29dl test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_qz3n8_Tu_Ua4lTcpAtorz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_qz3n8_Tu_Ua4lTcpAtorz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_rHak30F5CXp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_rHak30F5CXp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_rcxloYNacjfpPzd6ZALgu7yN_z6NXehKa0qSYBsyzbrGnHU88swO36PX5fL test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_rt4mBmGRgZTZn5f3TfRqqIPENYCicSVbP1GMfKErp test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_s8Xk5_MtSOD>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_s8Xk5_MtSOD test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_t0c6dIriuWz7Uu6ddtSvc>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_t0c6dIriuWz7Uu6ddtSvc test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_uYjGrmz9SVs>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_uYjGrmz9SVs test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_vLfTxH9a57mOznJjNaTm2XnYlDRdoOHyruV test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_vUw9aB_d0Gg5Av1oGII569Ze_DZDveNP2F7tDkIfEcnuf2FFZrgKuiaenIp_d0f test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_vtf26VDgbcfNcJUboi8r8hEv1x5VcQFYmLBka_g38vE test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_xaig3AcO9C98HKB9WyMAyL0hftRRpBgWU5inhqDRyMvirllqDE2 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_xeAUskGYKCy92B2m5tbyQGp66cc63aoNFasXEPoPEuh8LL47VYZUa test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_xyNlxQ5SPzTf9qgZWIBbzLuKzWiO8XOoJOCMYiLzWq885pPzSUFgypd9rcilX test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_yEvYxuVUnwRnTJUTRC1pSagfpn6Bv9pNzRiFCc6Nqva5ds_Fuh6ud test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_z2tPz>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_z2tPz test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_z7V7j2R83fWj7sZN7YRoI>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_z7V7j2R83fWj7sZN7YRoI test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zGbNwXRZA9a2NVnixKwvvOba9VZxM4ivQ32 test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zPDCc2ufMFsileJlNM9_uX4dzpJlx test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zPWSlWeb4aRdq9uNl6WeeDO7B1cmWJsgeaRK5XKrb test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zhJORZFLhQEym0l>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zhJORZFLhQEym0l test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zkiylTSK5zkai9CW4I_wsLY83qn>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zkiylTSK5zkai9CW4I_wsLY83qn test failed: {1}", sDetail);
	}
	if (!CX::IO::SimpleBuffers::ObjectTester::Test<sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP>(&sDetail))
	{
		bOK = false;
		CX::Print(stdout, "sbt_zvAzDOIMx93Z8tpsE3tupPVws47JBbTQ6DdxP test failed: {1}", sDetail);
	}
	if (bOK)
	{
		CX::Print(stdout, "ALL OK");
	}
}

