
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Y_Kf0R5IH5gCetrT3yAnj : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_jOaezOYasT8GghX;
	CX::Int32 sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC;
	CX::IO::SimpleBuffers::UInt8Array sbt_vo_HiUvGZOxwyi29PjHQm;
	CX::IO::SimpleBuffers::UInt8Array sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE;
	CX::UInt64 sbt_Zon1YJLvNYrffZB7dKq;
	CX::IO::SimpleBuffers::BoolArray sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb;
	CX::IO::SimpleBuffers::Int64Array sbt_9Y2ETpLPqcwW4zZ_SlD8L;
	CX::UInt64 sbt_CrO3kJipDVM8fFfq7uNzM;
	CX::Int16 sbt_T8qwJrSj_mBuU8j7XbyZu;
	CX::UInt32 sbt_Hur;
	CX::IO::SimpleBuffers::UInt8Array sbt_Esl9jtlYmdbSe_9Ki;
	CX::IO::SimpleBuffers::StringArray sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta;
	CX::IO::SimpleBuffers::UInt64Array sbt_Tzx;
	CX::Int8 sbt_mvVzVT9;
	CX::IO::SimpleBuffers::Int16Array sbt_XgOdrIo;

	virtual void Reset()
	{
		sbt_jOaezOYasT8GghX = 0;
		sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC = 0;
		sbt_vo_HiUvGZOxwyi29PjHQm.clear();
		sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.clear();
		sbt_Zon1YJLvNYrffZB7dKq = 0;
		sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.clear();
		sbt_9Y2ETpLPqcwW4zZ_SlD8L.clear();
		sbt_CrO3kJipDVM8fFfq7uNzM = 0;
		sbt_T8qwJrSj_mBuU8j7XbyZu = 0;
		sbt_Hur = 0;
		sbt_Esl9jtlYmdbSe_9Ki.clear();
		sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.clear();
		sbt_Tzx.clear();
		sbt_mvVzVT9 = 0;
		sbt_XgOdrIo.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_jOaezOYasT8GghX = -39;
		sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC = -756880457;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_vo_HiUvGZOxwyi29PjHQm.push_back(110);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.push_back(191);
		}
		sbt_Zon1YJLvNYrffZB7dKq = 4811363307626684286;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.push_back(false);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_9Y2ETpLPqcwW4zZ_SlD8L.push_back(-7359886609533826036);
		}
		sbt_CrO3kJipDVM8fFfq7uNzM = 4570592197693705976;
		sbt_T8qwJrSj_mBuU8j7XbyZu = 23243;
		sbt_Hur = 3569313964;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Esl9jtlYmdbSe_9Ki.push_back(138);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.push_back("$aAf\"P@xu_t<'h\"kd|ebU*?uMR%UUhiWRM+Ow~cg{T#<p#:>!ksn");
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_Tzx.push_back(3303121702080700970);
		}
		sbt_mvVzVT9 = -51;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_XgOdrIo.push_back(-772);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Y_Kf0R5IH5gCetrT3yAnj *pObject = dynamic_cast<const sbt_Y_Kf0R5IH5gCetrT3yAnj *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_jOaezOYasT8GghX != pObject->sbt_jOaezOYasT8GghX)
		{
			return false;
		}
		if (sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC != pObject->sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC)
		{
			return false;
		}
		if (sbt_vo_HiUvGZOxwyi29PjHQm.size() != pObject->sbt_vo_HiUvGZOxwyi29PjHQm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vo_HiUvGZOxwyi29PjHQm.size(); i++)
		{
			if (sbt_vo_HiUvGZOxwyi29PjHQm[i] != pObject->sbt_vo_HiUvGZOxwyi29PjHQm[i])
			{
				return false;
			}
		}
		if (sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.size() != pObject->sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.size(); i++)
		{
			if (sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE[i] != pObject->sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE[i])
			{
				return false;
			}
		}
		if (sbt_Zon1YJLvNYrffZB7dKq != pObject->sbt_Zon1YJLvNYrffZB7dKq)
		{
			return false;
		}
		if (sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.size() != pObject->sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.size(); i++)
		{
			if (sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb[i] != pObject->sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb[i])
			{
				return false;
			}
		}
		if (sbt_9Y2ETpLPqcwW4zZ_SlD8L.size() != pObject->sbt_9Y2ETpLPqcwW4zZ_SlD8L.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9Y2ETpLPqcwW4zZ_SlD8L.size(); i++)
		{
			if (sbt_9Y2ETpLPqcwW4zZ_SlD8L[i] != pObject->sbt_9Y2ETpLPqcwW4zZ_SlD8L[i])
			{
				return false;
			}
		}
		if (sbt_CrO3kJipDVM8fFfq7uNzM != pObject->sbt_CrO3kJipDVM8fFfq7uNzM)
		{
			return false;
		}
		if (sbt_T8qwJrSj_mBuU8j7XbyZu != pObject->sbt_T8qwJrSj_mBuU8j7XbyZu)
		{
			return false;
		}
		if (sbt_Hur != pObject->sbt_Hur)
		{
			return false;
		}
		if (sbt_Esl9jtlYmdbSe_9Ki.size() != pObject->sbt_Esl9jtlYmdbSe_9Ki.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Esl9jtlYmdbSe_9Ki.size(); i++)
		{
			if (sbt_Esl9jtlYmdbSe_9Ki[i] != pObject->sbt_Esl9jtlYmdbSe_9Ki[i])
			{
				return false;
			}
		}
		if (sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.size() != pObject->sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.size(); i++)
		{
			if (0 != cx_strcmp(sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta[i].c_str(), pObject->sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Tzx.size() != pObject->sbt_Tzx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Tzx.size(); i++)
		{
			if (sbt_Tzx[i] != pObject->sbt_Tzx[i])
			{
				return false;
			}
		}
		if (sbt_mvVzVT9 != pObject->sbt_mvVzVT9)
		{
			return false;
		}
		if (sbt_XgOdrIo.size() != pObject->sbt_XgOdrIo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XgOdrIo.size(); i++)
		{
			if (sbt_XgOdrIo[i] != pObject->sbt_XgOdrIo[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_jOaezOYasT8GghX", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jOaezOYasT8GghX = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vo_HiUvGZOxwyi29PjHQm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vo_HiUvGZOxwyi29PjHQm.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Zon1YJLvNYrffZB7dKq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Zon1YJLvNYrffZB7dKq = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_9Y2ETpLPqcwW4zZ_SlD8L")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9Y2ETpLPqcwW4zZ_SlD8L.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_CrO3kJipDVM8fFfq7uNzM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CrO3kJipDVM8fFfq7uNzM = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_T8qwJrSj_mBuU8j7XbyZu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T8qwJrSj_mBuU8j7XbyZu = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Hur", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Hur = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Esl9jtlYmdbSe_9Ki")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Esl9jtlYmdbSe_9Ki.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Tzx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Tzx.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_mvVzVT9", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_mvVzVT9 = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_XgOdrIo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XgOdrIo.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_jOaezOYasT8GghX", (CX::Int64)sbt_jOaezOYasT8GghX)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC", (CX::Int64)sbt_CUhvMJrDdVr5RuOjGGI7dxzEvpULXDxpzTEStQC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vo_HiUvGZOxwyi29PjHQm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_vo_HiUvGZOxwyi29PjHQm.begin(); iter != sbt_vo_HiUvGZOxwyi29PjHQm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.begin(); iter != sbt_aIUjk4aEbFgcCISFfFNLL4u5F01Yx8mKOkE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Zon1YJLvNYrffZB7dKq", (CX::Int64)sbt_Zon1YJLvNYrffZB7dKq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.begin(); iter != sbt_iBFwTQ_BQ9kcJwCvQhA61M4zulJuxi8ST8t1pABXrUyERtfO7rPkKcpZHWkhb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9Y2ETpLPqcwW4zZ_SlD8L")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_9Y2ETpLPqcwW4zZ_SlD8L.begin(); iter != sbt_9Y2ETpLPqcwW4zZ_SlD8L.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CrO3kJipDVM8fFfq7uNzM", (CX::Int64)sbt_CrO3kJipDVM8fFfq7uNzM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T8qwJrSj_mBuU8j7XbyZu", (CX::Int64)sbt_T8qwJrSj_mBuU8j7XbyZu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Hur", (CX::Int64)sbt_Hur)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Esl9jtlYmdbSe_9Ki")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Esl9jtlYmdbSe_9Ki.begin(); iter != sbt_Esl9jtlYmdbSe_9Ki.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.begin(); iter != sbt_bm0BxAdr6vjRhmYXU8hoUTL0ESLfBWQDJoP7boWTYJ_36GvFXfTvhtdBEMvkWta.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Tzx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Tzx.begin(); iter != sbt_Tzx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_mvVzVT9", (CX::Int64)sbt_mvVzVT9)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XgOdrIo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_XgOdrIo.begin(); iter != sbt_XgOdrIo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Y_Kf0R5IH5gCetrT3yAnj>::Type sbt_Y_Kf0R5IH5gCetrT3yAnjArray;

