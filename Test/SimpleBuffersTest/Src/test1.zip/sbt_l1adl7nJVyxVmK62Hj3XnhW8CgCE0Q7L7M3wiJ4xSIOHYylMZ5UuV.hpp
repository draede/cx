
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT;
	CX::IO::SimpleBuffers::StringArray sbt_Ehu_lyVnf9zclBsyPJK0GH5;
	CX::Int16 sbt_j;
	CX::UInt32 sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW;
	CX::Int32 sbt_rwY;
	CX::Bool sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G;
	CX::IO::SimpleBuffers::UInt64Array sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA;
	CX::UInt64 sbt_rpT15;
	CX::IO::SimpleBuffers::BoolArray sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6;
	CX::IO::SimpleBuffers::UInt8Array sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW;
	CX::UInt64 sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F;
	CX::UInt8 sbt_pLSPn1X9x8rzYVSa0;
	CX::UInt32 sbt__ybe83o2wnU5AuGBuvQ2uyN;
	CX::IO::SimpleBuffers::Int16Array sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla;
	CX::IO::SimpleBuffers::Int64Array sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot;
	CX::Int8 sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d;
	CX::String sbt_35zPMh1DpjMDae4;
	CX::Int64 sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV;
	CX::Int8 sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw;
	CX::IO::SimpleBuffers::UInt32Array sbt_YEFhhFaeuPcXWqosZ243PwElVIc;
	CX::IO::SimpleBuffers::Int64Array sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i;
	CX::UInt32 sbt_jFdnH5YUm9Luj7AaE_zfJ;
	CX::Int8 sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC;
	CX::UInt64 sbt_iYPye0AgefP;
	CX::UInt32 sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD;
	CX::Bool sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW;
	CX::Int8 sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE;

	virtual void Reset()
	{
		sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.clear();
		sbt_Ehu_lyVnf9zclBsyPJK0GH5.clear();
		sbt_j = 0;
		sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW = 0;
		sbt_rwY = 0;
		sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G = false;
		sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.clear();
		sbt_rpT15 = 0;
		sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.clear();
		sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.clear();
		sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F = 0;
		sbt_pLSPn1X9x8rzYVSa0 = 0;
		sbt__ybe83o2wnU5AuGBuvQ2uyN = 0;
		sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.clear();
		sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.clear();
		sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d = 0;
		sbt_35zPMh1DpjMDae4.clear();
		sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV = 0;
		sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw = 0;
		sbt_YEFhhFaeuPcXWqosZ243PwElVIc.clear();
		sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.clear();
		sbt_jFdnH5YUm9Luj7AaE_zfJ = 0;
		sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC = 0;
		sbt_iYPye0AgefP = 0;
		sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD = 0;
		sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW = false;
		sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.push_back(false);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_Ehu_lyVnf9zclBsyPJK0GH5.push_back("O1E70wVxB#B9pAx-&l/LLrpQT}s__1\\/:~");
		}
		sbt_j = -24507;
		sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW = 3906497091;
		sbt_rwY = -660074282;
		sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G = true;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.push_back(7697395879595875938);
		}
		sbt_rpT15 = 3289211039983733760;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.push_back(82);
		}
		sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F = 2943774865363958136;
		sbt_pLSPn1X9x8rzYVSa0 = 17;
		sbt__ybe83o2wnU5AuGBuvQ2uyN = 3555402681;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.push_back(-19664);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.push_back(-4257292222940853112);
		}
		sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d = 115;
		sbt_35zPMh1DpjMDae4 = "p}Lz,Gs1#U|*E\"U`{0wo.?;LgrYcnFF^rMGL|CI|GK@S:rcvQ[|_hD";
		sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV = 1468709472093601436;
		sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw = -109;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_YEFhhFaeuPcXWqosZ243PwElVIc.push_back(1447399338);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.push_back(926499690824401680);
		}
		sbt_jFdnH5YUm9Luj7AaE_zfJ = 232683451;
		sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC = 46;
		sbt_iYPye0AgefP = 11106154077003054580;
		sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD = 792589196;
		sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW = true;
		sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE = -44;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV *pObject = dynamic_cast<const sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.size() != pObject->sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.size(); i++)
		{
			if (sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT[i] != pObject->sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT[i])
			{
				return false;
			}
		}
		if (sbt_Ehu_lyVnf9zclBsyPJK0GH5.size() != pObject->sbt_Ehu_lyVnf9zclBsyPJK0GH5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Ehu_lyVnf9zclBsyPJK0GH5.size(); i++)
		{
			if (0 != cx_strcmp(sbt_Ehu_lyVnf9zclBsyPJK0GH5[i].c_str(), pObject->sbt_Ehu_lyVnf9zclBsyPJK0GH5[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_j != pObject->sbt_j)
		{
			return false;
		}
		if (sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW != pObject->sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW)
		{
			return false;
		}
		if (sbt_rwY != pObject->sbt_rwY)
		{
			return false;
		}
		if (sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G != pObject->sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G)
		{
			return false;
		}
		if (sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.size() != pObject->sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.size(); i++)
		{
			if (sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA[i] != pObject->sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA[i])
			{
				return false;
			}
		}
		if (sbt_rpT15 != pObject->sbt_rpT15)
		{
			return false;
		}
		if (sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.size() != pObject->sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.size(); i++)
		{
			if (sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6[i] != pObject->sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6[i])
			{
				return false;
			}
		}
		if (sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.size() != pObject->sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.size(); i++)
		{
			if (sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW[i] != pObject->sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW[i])
			{
				return false;
			}
		}
		if (sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F != pObject->sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F)
		{
			return false;
		}
		if (sbt_pLSPn1X9x8rzYVSa0 != pObject->sbt_pLSPn1X9x8rzYVSa0)
		{
			return false;
		}
		if (sbt__ybe83o2wnU5AuGBuvQ2uyN != pObject->sbt__ybe83o2wnU5AuGBuvQ2uyN)
		{
			return false;
		}
		if (sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.size() != pObject->sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.size(); i++)
		{
			if (sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla[i] != pObject->sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla[i])
			{
				return false;
			}
		}
		if (sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.size() != pObject->sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.size(); i++)
		{
			if (sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot[i] != pObject->sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot[i])
			{
				return false;
			}
		}
		if (sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d != pObject->sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_35zPMh1DpjMDae4.c_str(), pObject->sbt_35zPMh1DpjMDae4.c_str()))
		{
			return false;
		}
		if (sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV != pObject->sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV)
		{
			return false;
		}
		if (sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw != pObject->sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw)
		{
			return false;
		}
		if (sbt_YEFhhFaeuPcXWqosZ243PwElVIc.size() != pObject->sbt_YEFhhFaeuPcXWqosZ243PwElVIc.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YEFhhFaeuPcXWqosZ243PwElVIc.size(); i++)
		{
			if (sbt_YEFhhFaeuPcXWqosZ243PwElVIc[i] != pObject->sbt_YEFhhFaeuPcXWqosZ243PwElVIc[i])
			{
				return false;
			}
		}
		if (sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.size() != pObject->sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.size(); i++)
		{
			if (sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i[i] != pObject->sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i[i])
			{
				return false;
			}
		}
		if (sbt_jFdnH5YUm9Luj7AaE_zfJ != pObject->sbt_jFdnH5YUm9Luj7AaE_zfJ)
		{
			return false;
		}
		if (sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC != pObject->sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC)
		{
			return false;
		}
		if (sbt_iYPye0AgefP != pObject->sbt_iYPye0AgefP)
		{
			return false;
		}
		if (sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD != pObject->sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD)
		{
			return false;
		}
		if (sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW != pObject->sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW)
		{
			return false;
		}
		if (sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE != pObject->sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Ehu_lyVnf9zclBsyPJK0GH5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Ehu_lyVnf9zclBsyPJK0GH5.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_j", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_j = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rwY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rwY = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G", &sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rpT15", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rpT15 = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pLSPn1X9x8rzYVSa0", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pLSPn1X9x8rzYVSa0 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__ybe83o2wnU5AuGBuvQ2uyN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__ybe83o2wnU5AuGBuvQ2uyN = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_35zPMh1DpjMDae4", &sbt_35zPMh1DpjMDae4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_YEFhhFaeuPcXWqosZ243PwElVIc")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YEFhhFaeuPcXWqosZ243PwElVIc.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jFdnH5YUm9Luj7AaE_zfJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jFdnH5YUm9Luj7AaE_zfJ = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_iYPye0AgefP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_iYPye0AgefP = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW", &sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.begin(); iter != sbt_vD63J0sOzrB8XFGi2wz8sdT8PepklDaVKeO7w2PsT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Ehu_lyVnf9zclBsyPJK0GH5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_Ehu_lyVnf9zclBsyPJK0GH5.begin(); iter != sbt_Ehu_lyVnf9zclBsyPJK0GH5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_j", (CX::Int64)sbt_j)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW", (CX::Int64)sbt_wWtONBPg_xhWT0CW23fhA_RZeuhBZwjPO_1Po4J6pHajW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rwY", (CX::Int64)sbt_rwY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G", sbt_uudelS3aaJcqNT8dCJe1d5Y76VVomzKn13G)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.begin(); iter != sbt_nRg6T1Gj_bXWMeHW6J0jtaORr0fdAryIumTbEYpNA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rpT15", (CX::Int64)sbt_rpT15)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.begin(); iter != sbt_emnJCDuxCGOjN7axVx4yryA_J47ui46bZqt4o3SL_NJ_iOGRxu09flxi6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.begin(); iter != sbt_D8G0WnvOMaQIDRT2lm2GHwO2T0N1LWA7yutj8L3jHvC6WwmVi7q5jzQFYIwWW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F", (CX::Int64)sbt_L84zE99QYY_fLt0ZSGqqnhv2dbV0ryR_zqeF44j104F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pLSPn1X9x8rzYVSa0", (CX::Int64)sbt_pLSPn1X9x8rzYVSa0)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__ybe83o2wnU5AuGBuvQ2uyN", (CX::Int64)sbt__ybe83o2wnU5AuGBuvQ2uyN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.begin(); iter != sbt_n1YuoPwIdS_HIUFYcfQrb7GnoQMDv1EEhWYweUmG11CTJbrIEHBla.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.begin(); iter != sbt_N7Zc5wTGx72NYnAuJRf6DRypeseradGX66CNtGWZpot.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d", (CX::Int64)sbt_fXFFO2lx4tcGyI6vTNDHqD4VK2ugWDC8d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_35zPMh1DpjMDae4", sbt_35zPMh1DpjMDae4.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV", (CX::Int64)sbt_AUhrRgQpm2dQmTCyFf5QnXPQddZGyC2xTJ0yAHZJOUlMZf2e4CwVQibb8tV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw", (CX::Int64)sbt_T0K9ogeYIs58LCqZQ2hPuH04GUPQKCyMmZliJvJf3WDHEcw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YEFhhFaeuPcXWqosZ243PwElVIc")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_YEFhhFaeuPcXWqosZ243PwElVIc.begin(); iter != sbt_YEFhhFaeuPcXWqosZ243PwElVIc.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.begin(); iter != sbt_Qh3oRdf4oQvbJ_XSylui1zi0Zz07tWIJGrGHr1a_R_xzvzOMDz3L8jO5i.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jFdnH5YUm9Luj7AaE_zfJ", (CX::Int64)sbt_jFdnH5YUm9Luj7AaE_zfJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC", (CX::Int64)sbt_rgbpRLkgyEKXiJwSK2_yK1qSEl9ouBfhC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_iYPye0AgefP", (CX::Int64)sbt_iYPye0AgefP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD", (CX::Int64)sbt_XcDnfRL3hCGOUKjlSEj4s4euX5KKiRa49HDgRIayBCHcu7Ku6ENbD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW", sbt_bEbexzvBfBI0RZZTP1nC7lRQzanq4X4pW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE", (CX::Int64)sbt_xyyyzcYweCl8FAY5Hzolmv6wi3bl4MHBF3tj4XIDJ8kxE)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuV>::Type sbt_l1adl7nJVyxVmK62Hj3XnhW8CgCE0Q7L7M3wiJ4xSIOHYylMZ5UuVArray;

