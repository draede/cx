
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6.hpp"


class sbt_uYjGrmz9SVs : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_OhBRVVTm8WBl0DQ6QokYc0Y;
	CX::IO::SimpleBuffers::BoolArray sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt;
	CX::IO::SimpleBuffers::WStringArray sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs;
	CX::Double sbt_P;
	sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6Array sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4;

	virtual void Reset()
	{
		sbt_OhBRVVTm8WBl0DQ6QokYc0Y.clear();
		sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.clear();
		sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.clear();
		sbt_P = 0.0;
		sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_OhBRVVTm8WBl0DQ6QokYc0Y.push_back(6419001732848906704);
		}
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.push_back(false);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.push_back(L"0FI-'S*4z4^v?$.:Tb'3J^@B',$kxrLt2(3-r-AUo(sjue\"*)uT//K6Ob\\~5ezB");
		}
		sbt_P = 0.677872;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 v;

			v.SetupWithSomeValues();
			sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_uYjGrmz9SVs *pObject = dynamic_cast<const sbt_uYjGrmz9SVs *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_OhBRVVTm8WBl0DQ6QokYc0Y.size() != pObject->sbt_OhBRVVTm8WBl0DQ6QokYc0Y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OhBRVVTm8WBl0DQ6QokYc0Y.size(); i++)
		{
			if (sbt_OhBRVVTm8WBl0DQ6QokYc0Y[i] != pObject->sbt_OhBRVVTm8WBl0DQ6QokYc0Y[i])
			{
				return false;
			}
		}
		if (sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.size() != pObject->sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.size(); i++)
		{
			if (sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt[i] != pObject->sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt[i])
			{
				return false;
			}
		}
		if (sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.size() != pObject->sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs[i].c_str(), pObject->sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_P != pObject->sbt_P)
		{
			return false;
		}
		if (sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.size() != pObject->sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.size(); i++)
		{
			if (!sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4[i].Compare(&pObject->sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_OhBRVVTm8WBl0DQ6QokYc0Y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OhBRVVTm8WBl0DQ6QokYc0Y.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_P", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_P = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6 tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_OhBRVVTm8WBl0DQ6QokYc0Y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_OhBRVVTm8WBl0DQ6QokYc0Y.begin(); iter != sbt_OhBRVVTm8WBl0DQ6QokYc0Y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.begin(); iter != sbt_gRyJaHVoe5DVbmn6TZ1lTAO3HIt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.begin(); iter != sbt_wbr2CQA6kwM_p_4tiXTRxsWyoqhfbOKHgbXMN9RKiSE8WW1FUDs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_P", (CX::Double)sbt_P)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4")).IsNOK())
		{
			return status;
		}
		for (sbt_7WHk2R3SCvwU5BPW1j_jDySPi0VlfEg2bDKTGR6Array::const_iterator iter = sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.begin(); iter != sbt_GbNNUWPNrwM8oSq2BVlyQG_5T9kkY__AErhl7DyFLQciPraX4.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_uYjGrmz9SVs>::Type sbt_uYjGrmz9SVsArray;

