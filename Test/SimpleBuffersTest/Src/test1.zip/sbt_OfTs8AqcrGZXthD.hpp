
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_OfTs8AqcrGZXthD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt8Array sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx;
	CX::UInt32 sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d;
	CX::String sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG;
	CX::UInt16 sbt_ZAuEW3rUVf2ni;
	CX::Int64 sbt_xpN0F;
	CX::String sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ;
	CX::IO::SimpleBuffers::UInt64Array sbt_wycMALFS_qz3uWn5OWythT9;
	CX::IO::SimpleBuffers::BoolArray sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3;
	CX::IO::SimpleBuffers::BoolArray sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi;
	CX::UInt32 sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV;
	CX::IO::SimpleBuffers::BoolArray sbt_gRYxbVxpo;
	CX::IO::SimpleBuffers::BoolArray sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373;
	CX::IO::SimpleBuffers::BoolArray sbt_CTrBmEL;
	CX::IO::SimpleBuffers::UInt32Array sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c;
	CX::Int8 sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD;
	CX::IO::SimpleBuffers::Int8Array sbt_yXtOzeClGVMzSQ4Z_WvjbUt;
	CX::IO::SimpleBuffers::Int64Array sbt_g8wTGx0s9dsDhdOPP2r;
	CX::Int32 sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp;
	CX::UInt64 sbt_j_yjPNC;
	CX::UInt32 sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK;
	CX::UInt16 sbt_TkH5U7Ttr2wmE;
	CX::Int16 sbt_ugdktn8CDReNLmrK3Sk_Het1g;
	CX::UInt16 sbt_t34rbWZ7HzBdmidos;
	CX::IO::SimpleBuffers::UInt8Array sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt;
	CX::UInt16 sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI;
	CX::IO::SimpleBuffers::Int32Array sbt_Wg8312yeptE;
	CX::IO::SimpleBuffers::UInt32Array sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj;

	virtual void Reset()
	{
		sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.clear();
		sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d = 0;
		sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG.clear();
		sbt_ZAuEW3rUVf2ni = 0;
		sbt_xpN0F = 0;
		sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ.clear();
		sbt_wycMALFS_qz3uWn5OWythT9.clear();
		sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.clear();
		sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.clear();
		sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV = 0;
		sbt_gRYxbVxpo.clear();
		sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.clear();
		sbt_CTrBmEL.clear();
		sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.clear();
		sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD = 0;
		sbt_yXtOzeClGVMzSQ4Z_WvjbUt.clear();
		sbt_g8wTGx0s9dsDhdOPP2r.clear();
		sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp = 0;
		sbt_j_yjPNC = 0;
		sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK = 0;
		sbt_TkH5U7Ttr2wmE = 0;
		sbt_ugdktn8CDReNLmrK3Sk_Het1g = 0;
		sbt_t34rbWZ7HzBdmidos = 0;
		sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.clear();
		sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI = 0;
		sbt_Wg8312yeptE.clear();
		sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.push_back(226);
		}
		sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d = 3202017038;
		sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG = ">0L?Xf,<+zEkX[76fVt3wRLj,\"p<5(BXV\\1~\\Yx)eG=DcMZt<k4_Q_";
		sbt_ZAuEW3rUVf2ni = 18384;
		sbt_xpN0F = 8848106066308522812;
		sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ = "fEVo5oF]*mK8}&{MuT,du\"5VU4jnDq!Go@sab-2?B;@Ff.jHrI$CeJlDyUk0be";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_wycMALFS_qz3uWn5OWythT9.push_back(3476157317432839942);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.push_back(true);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.push_back(false);
		}
		sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV = 3008694032;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_gRYxbVxpo.push_back(false);
		}
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.push_back(false);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_CTrBmEL.push_back(false);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.push_back(626316992);
		}
		sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD = -60;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_yXtOzeClGVMzSQ4Z_WvjbUt.push_back(105);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_g8wTGx0s9dsDhdOPP2r.push_back(-3463421334628660474);
		}
		sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp = -1389009857;
		sbt_j_yjPNC = 5426135343429185210;
		sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK = 3717854935;
		sbt_TkH5U7Ttr2wmE = 17731;
		sbt_ugdktn8CDReNLmrK3Sk_Het1g = 3649;
		sbt_t34rbWZ7HzBdmidos = 54923;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.push_back(34);
		}
		sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI = 27072;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_Wg8312yeptE.push_back(1586759756);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.push_back(375043098);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_OfTs8AqcrGZXthD *pObject = dynamic_cast<const sbt_OfTs8AqcrGZXthD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.size() != pObject->sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.size(); i++)
		{
			if (sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx[i] != pObject->sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx[i])
			{
				return false;
			}
		}
		if (sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d != pObject->sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG.c_str(), pObject->sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG.c_str()))
		{
			return false;
		}
		if (sbt_ZAuEW3rUVf2ni != pObject->sbt_ZAuEW3rUVf2ni)
		{
			return false;
		}
		if (sbt_xpN0F != pObject->sbt_xpN0F)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ.c_str(), pObject->sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ.c_str()))
		{
			return false;
		}
		if (sbt_wycMALFS_qz3uWn5OWythT9.size() != pObject->sbt_wycMALFS_qz3uWn5OWythT9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_wycMALFS_qz3uWn5OWythT9.size(); i++)
		{
			if (sbt_wycMALFS_qz3uWn5OWythT9[i] != pObject->sbt_wycMALFS_qz3uWn5OWythT9[i])
			{
				return false;
			}
		}
		if (sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.size() != pObject->sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.size(); i++)
		{
			if (sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3[i] != pObject->sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3[i])
			{
				return false;
			}
		}
		if (sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.size() != pObject->sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.size(); i++)
		{
			if (sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi[i] != pObject->sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi[i])
			{
				return false;
			}
		}
		if (sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV != pObject->sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV)
		{
			return false;
		}
		if (sbt_gRYxbVxpo.size() != pObject->sbt_gRYxbVxpo.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gRYxbVxpo.size(); i++)
		{
			if (sbt_gRYxbVxpo[i] != pObject->sbt_gRYxbVxpo[i])
			{
				return false;
			}
		}
		if (sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.size() != pObject->sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.size(); i++)
		{
			if (sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373[i] != pObject->sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373[i])
			{
				return false;
			}
		}
		if (sbt_CTrBmEL.size() != pObject->sbt_CTrBmEL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CTrBmEL.size(); i++)
		{
			if (sbt_CTrBmEL[i] != pObject->sbt_CTrBmEL[i])
			{
				return false;
			}
		}
		if (sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.size() != pObject->sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.size(); i++)
		{
			if (sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c[i] != pObject->sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c[i])
			{
				return false;
			}
		}
		if (sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD != pObject->sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD)
		{
			return false;
		}
		if (sbt_yXtOzeClGVMzSQ4Z_WvjbUt.size() != pObject->sbt_yXtOzeClGVMzSQ4Z_WvjbUt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yXtOzeClGVMzSQ4Z_WvjbUt.size(); i++)
		{
			if (sbt_yXtOzeClGVMzSQ4Z_WvjbUt[i] != pObject->sbt_yXtOzeClGVMzSQ4Z_WvjbUt[i])
			{
				return false;
			}
		}
		if (sbt_g8wTGx0s9dsDhdOPP2r.size() != pObject->sbt_g8wTGx0s9dsDhdOPP2r.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_g8wTGx0s9dsDhdOPP2r.size(); i++)
		{
			if (sbt_g8wTGx0s9dsDhdOPP2r[i] != pObject->sbt_g8wTGx0s9dsDhdOPP2r[i])
			{
				return false;
			}
		}
		if (sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp != pObject->sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp)
		{
			return false;
		}
		if (sbt_j_yjPNC != pObject->sbt_j_yjPNC)
		{
			return false;
		}
		if (sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK != pObject->sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK)
		{
			return false;
		}
		if (sbt_TkH5U7Ttr2wmE != pObject->sbt_TkH5U7Ttr2wmE)
		{
			return false;
		}
		if (sbt_ugdktn8CDReNLmrK3Sk_Het1g != pObject->sbt_ugdktn8CDReNLmrK3Sk_Het1g)
		{
			return false;
		}
		if (sbt_t34rbWZ7HzBdmidos != pObject->sbt_t34rbWZ7HzBdmidos)
		{
			return false;
		}
		if (sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.size() != pObject->sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.size(); i++)
		{
			if (sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt[i] != pObject->sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt[i])
			{
				return false;
			}
		}
		if (sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI != pObject->sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI)
		{
			return false;
		}
		if (sbt_Wg8312yeptE.size() != pObject->sbt_Wg8312yeptE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Wg8312yeptE.size(); i++)
		{
			if (sbt_Wg8312yeptE[i] != pObject->sbt_Wg8312yeptE[i])
			{
				return false;
			}
		}
		if (sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.size() != pObject->sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.size(); i++)
		{
			if (sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj[i] != pObject->sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG", &sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ZAuEW3rUVf2ni", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ZAuEW3rUVf2ni = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_xpN0F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_xpN0F = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectString("sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ", &sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_wycMALFS_qz3uWn5OWythT9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_wycMALFS_qz3uWn5OWythT9.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_gRYxbVxpo")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gRYxbVxpo.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CTrBmEL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CTrBmEL.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yXtOzeClGVMzSQ4Z_WvjbUt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yXtOzeClGVMzSQ4Z_WvjbUt.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_g8wTGx0s9dsDhdOPP2r")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_g8wTGx0s9dsDhdOPP2r.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_j_yjPNC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_j_yjPNC = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_TkH5U7Ttr2wmE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TkH5U7Ttr2wmE = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_ugdktn8CDReNLmrK3Sk_Het1g", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ugdktn8CDReNLmrK3Sk_Het1g = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_t34rbWZ7HzBdmidos", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_t34rbWZ7HzBdmidos = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Wg8312yeptE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Wg8312yeptE.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.begin(); iter != sbt_XVUVVNowL2Iv9Dn_lJI86iJNV6M1PybWJ5tSszl3znRQcsuHx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d", (CX::Int64)sbt_owBHlzri3zB3Q8rQlDvVz05Sex4tIDDanuPxlujs8YA3y3JdZ7d)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG", sbt_FReszOwy_rXOOOm7tdcTbZtplV2TeXIh0SilG.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ZAuEW3rUVf2ni", (CX::Int64)sbt_ZAuEW3rUVf2ni)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_xpN0F", (CX::Int64)sbt_xpN0F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ", sbt_5LAkdF2Jgoj0XPvXXLZysP729QbZK9VTE6t6YSe9jFuQJUZxN6GpUMXIZ.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_wycMALFS_qz3uWn5OWythT9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_wycMALFS_qz3uWn5OWythT9.begin(); iter != sbt_wycMALFS_qz3uWn5OWythT9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.begin(); iter != sbt_bRA8it3nB3dwfjdXrwbZpjiTYviwvp8yaGFZdMGiX8XC3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.begin(); iter != sbt_h7KN3v9I83a1KBiZ7LKkdQFCCOzlZiXvo5ppMDIDgQi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV", (CX::Int64)sbt_rGpPzk55XPzTQSTfDgxEfgNW7asOqzPv55HY4RBmNCV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gRYxbVxpo")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_gRYxbVxpo.begin(); iter != sbt_gRYxbVxpo.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.begin(); iter != sbt_sa5BNXrbU7nuq90XjqE32qBZsU4xlt0YuChLR0BetHUgndko373.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CTrBmEL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_CTrBmEL.begin(); iter != sbt_CTrBmEL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.begin(); iter != sbt_OlKOW01a2UAgQ1q1uimvGDmyCF_xq8FbXlUvgaW36rEB4yh1c.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD", (CX::Int64)sbt_0CXOfjerx8K9HeUrOdiShaPsvP1SWE9PPaWaoFa7fUfheLagkQrxD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yXtOzeClGVMzSQ4Z_WvjbUt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_yXtOzeClGVMzSQ4Z_WvjbUt.begin(); iter != sbt_yXtOzeClGVMzSQ4Z_WvjbUt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_g8wTGx0s9dsDhdOPP2r")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_g8wTGx0s9dsDhdOPP2r.begin(); iter != sbt_g8wTGx0s9dsDhdOPP2r.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp", (CX::Int64)sbt_3sKi2khvPdCS1kXQRCG7NWXVxG2UI9aMMTpiwDY9cAPiYi2MCzAP9OP2abp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_j_yjPNC", (CX::Int64)sbt_j_yjPNC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK", (CX::Int64)sbt_rzM8z4YT0Ni29Ltp_c30Y5PqYTPbeLMuY7F_r2rVZEQQkvFshASeLpmAdOK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TkH5U7Ttr2wmE", (CX::Int64)sbt_TkH5U7Ttr2wmE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ugdktn8CDReNLmrK3Sk_Het1g", (CX::Int64)sbt_ugdktn8CDReNLmrK3Sk_Het1g)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_t34rbWZ7HzBdmidos", (CX::Int64)sbt_t34rbWZ7HzBdmidos)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.begin(); iter != sbt_nAnynxpj4yvm1IbWeXRHuve_NHkaaT4gaqFoH3Xwaoc_xEpWt.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI", (CX::Int64)sbt_tA24BuDMHjN45oc5ZDXtv_uUqWNcd1U2Lcl_KJX2fTCiJkb05ocYI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Wg8312yeptE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_Wg8312yeptE.begin(); iter != sbt_Wg8312yeptE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.begin(); iter != sbt_BqoLr1ZooNXVWu32hRWprOtdI7L1VlsM8ZTtSzNd6eAgRGBe5MsbX8U4gO0vj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_OfTs8AqcrGZXthD>::Type sbt_OfTs8AqcrGZXthDArray;

