
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7;
	CX::UInt64 sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S;
	CX::Bool sbt_4;
	CX::IO::SimpleBuffers::Int32Array sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_;
	CX::Int8 sbt_G4LBpRgxCtJEK;
	CX::Int8 sbt_BxkgGAYtYsVF9T5amH9X8uuNL;
	CX::IO::SimpleBuffers::BoolArray sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr;
	CX::IO::SimpleBuffers::Int64Array sbt_vTj4vKZxpkK;
	CX::UInt32 sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ;
	CX::IO::SimpleBuffers::UInt32Array sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq;
	CX::IO::SimpleBuffers::UInt64Array sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK;
	CX::IO::SimpleBuffers::UInt64Array sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34;

	virtual void Reset()
	{
		sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7 = 0;
		sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S = 0;
		sbt_4 = false;
		sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.clear();
		sbt_G4LBpRgxCtJEK = 0;
		sbt_BxkgGAYtYsVF9T5amH9X8uuNL = 0;
		sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.clear();
		sbt_vTj4vKZxpkK.clear();
		sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ = 0;
		sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.clear();
		sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.clear();
		sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7 = -106;
		sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S = 5454509926709393830;
		sbt_4 = false;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.push_back(308554874);
		}
		sbt_G4LBpRgxCtJEK = -111;
		sbt_BxkgGAYtYsVF9T5amH9X8uuNL = -54;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.push_back(true);
		}
		sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ = 2024497130;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.push_back(1155874683);
		}
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.push_back(599655275315911540);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.push_back(15783087607056200202);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel *pObject = dynamic_cast<const sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7 != pObject->sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7)
		{
			return false;
		}
		if (sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S != pObject->sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S)
		{
			return false;
		}
		if (sbt_4 != pObject->sbt_4)
		{
			return false;
		}
		if (sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.size() != pObject->sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.size(); i++)
		{
			if (sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_[i] != pObject->sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_[i])
			{
				return false;
			}
		}
		if (sbt_G4LBpRgxCtJEK != pObject->sbt_G4LBpRgxCtJEK)
		{
			return false;
		}
		if (sbt_BxkgGAYtYsVF9T5amH9X8uuNL != pObject->sbt_BxkgGAYtYsVF9T5amH9X8uuNL)
		{
			return false;
		}
		if (sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.size() != pObject->sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.size(); i++)
		{
			if (sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr[i] != pObject->sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr[i])
			{
				return false;
			}
		}
		if (sbt_vTj4vKZxpkK.size() != pObject->sbt_vTj4vKZxpkK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vTj4vKZxpkK.size(); i++)
		{
			if (sbt_vTj4vKZxpkK[i] != pObject->sbt_vTj4vKZxpkK[i])
			{
				return false;
			}
		}
		if (sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ != pObject->sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ)
		{
			return false;
		}
		if (sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.size() != pObject->sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.size(); i++)
		{
			if (sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq[i] != pObject->sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq[i])
			{
				return false;
			}
		}
		if (sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.size() != pObject->sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.size(); i++)
		{
			if (sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK[i] != pObject->sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK[i])
			{
				return false;
			}
		}
		if (sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.size() != pObject->sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.size(); i++)
		{
			if (sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34[i] != pObject->sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_4", &sbt_4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_G4LBpRgxCtJEK", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_G4LBpRgxCtJEK = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_BxkgGAYtYsVF9T5amH9X8uuNL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_BxkgGAYtYsVF9T5amH9X8uuNL = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_vTj4vKZxpkK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_vTj4vKZxpkK.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7", (CX::Int64)sbt_E4K2NWX21DPyOkfugA0JTgxRh2i9jg1hhCYjTHxO_V80Ur11dj7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S", (CX::Int64)sbt_Nlu941K66ayFD1QO5csdaZjocBX4KQBnT2S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_4", sbt_4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.begin(); iter != sbt_LBuejE7Mju_9sRDiivJX40UvCuaw2XYX2J8wk1O5dVlABk_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_G4LBpRgxCtJEK", (CX::Int64)sbt_G4LBpRgxCtJEK)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_BxkgGAYtYsVF9T5amH9X8uuNL", (CX::Int64)sbt_BxkgGAYtYsVF9T5amH9X8uuNL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.begin(); iter != sbt_B4JUcC6ZVNSq2T0sPzcYlVRM3bEUr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vTj4vKZxpkK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_vTj4vKZxpkK.begin(); iter != sbt_vTj4vKZxpkK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ", (CX::Int64)sbt_qx8SxcSxulUESUM64lfDLcgjM4LVCsg1Fi1xp0NFGotmQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.begin(); iter != sbt_UkbgeydoWJGSPjHU0vz3xC1BrB9qq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.begin(); iter != sbt_oqhlm0oxbn4iOTx9h4JdbmrorEyoQQLvK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.begin(); iter != sbt_CRK8hl5899GHwNvmJDDq1mzmfzB6Ojz3Vp1YVoz21NnvcHswLFG34.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNel>::Type sbt_Z7l9RH0qTyds2hbUgVu1OvrKxTGQ9h2LbLsIieuJNsoAfXNelArray;

