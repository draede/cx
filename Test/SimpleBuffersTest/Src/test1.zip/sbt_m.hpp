
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_m : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt32Array sbt_FvuiJatioOzYfiMJis20p;
	CX::UInt64 sbt_krzgsLCDT;
	CX::IO::SimpleBuffers::Int16Array sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h;
	CX::IO::SimpleBuffers::UInt64Array sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ;
	CX::UInt64 sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B;
	CX::UInt16 sbt_Tc7LBEDxLyD;
	CX::Int8 sbt_jn5xzxa4y;
	CX::UInt64 sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS;
	CX::UInt32 sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN;
	CX::String sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl;
	CX::Bool sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz;
	CX::Int32 sbt_OBWGsGHLMabkH3sD4Fy;
	CX::IO::SimpleBuffers::UInt32Array sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6;
	CX::UInt32 sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV;
	CX::Bool sbt_Q2aze6sXd25xKPD;
	CX::IO::SimpleBuffers::UInt64Array sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh;
	CX::Bool sbt_9xcbMKiiIX9aTAnakflicoa;
	CX::IO::SimpleBuffers::UInt8Array sbt_e1rjFcovx46ZjyXQUk_AjVe05v4;
	CX::IO::SimpleBuffers::UInt64Array sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90;
	CX::IO::SimpleBuffers::UInt64Array sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1;

	virtual void Reset()
	{
		sbt_FvuiJatioOzYfiMJis20p.clear();
		sbt_krzgsLCDT = 0;
		sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.clear();
		sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.clear();
		sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B = 0;
		sbt_Tc7LBEDxLyD = 0;
		sbt_jn5xzxa4y = 0;
		sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS = 0;
		sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN = 0;
		sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl.clear();
		sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz = false;
		sbt_OBWGsGHLMabkH3sD4Fy = 0;
		sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.clear();
		sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV = 0;
		sbt_Q2aze6sXd25xKPD = false;
		sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.clear();
		sbt_9xcbMKiiIX9aTAnakflicoa = false;
		sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.clear();
		sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.clear();
		sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_FvuiJatioOzYfiMJis20p.push_back(1087634342);
		}
		sbt_krzgsLCDT = 126140746031998502;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.push_back(-12842);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.push_back(9475709217480130796);
		}
		sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B = 1712176206494954944;
		sbt_Tc7LBEDxLyD = 56322;
		sbt_jn5xzxa4y = -38;
		sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS = 11558263966514578430;
		sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN = 178775696;
		sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl = "t+E-D";
		sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz = false;
		sbt_OBWGsGHLMabkH3sD4Fy = -2101204898;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.push_back(1425158446);
		}
		sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV = 1877518104;
		sbt_Q2aze6sXd25xKPD = true;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.push_back(18329681763758204824);
		}
		sbt_9xcbMKiiIX9aTAnakflicoa = true;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.push_back(94);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.push_back(5212351507331535116);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.push_back(3636489645695454972);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_m *pObject = dynamic_cast<const sbt_m *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_FvuiJatioOzYfiMJis20p.size() != pObject->sbt_FvuiJatioOzYfiMJis20p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_FvuiJatioOzYfiMJis20p.size(); i++)
		{
			if (sbt_FvuiJatioOzYfiMJis20p[i] != pObject->sbt_FvuiJatioOzYfiMJis20p[i])
			{
				return false;
			}
		}
		if (sbt_krzgsLCDT != pObject->sbt_krzgsLCDT)
		{
			return false;
		}
		if (sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.size() != pObject->sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.size(); i++)
		{
			if (sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h[i] != pObject->sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h[i])
			{
				return false;
			}
		}
		if (sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.size() != pObject->sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.size(); i++)
		{
			if (sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ[i] != pObject->sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ[i])
			{
				return false;
			}
		}
		if (sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B != pObject->sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B)
		{
			return false;
		}
		if (sbt_Tc7LBEDxLyD != pObject->sbt_Tc7LBEDxLyD)
		{
			return false;
		}
		if (sbt_jn5xzxa4y != pObject->sbt_jn5xzxa4y)
		{
			return false;
		}
		if (sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS != pObject->sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS)
		{
			return false;
		}
		if (sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN != pObject->sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl.c_str(), pObject->sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl.c_str()))
		{
			return false;
		}
		if (sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz != pObject->sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz)
		{
			return false;
		}
		if (sbt_OBWGsGHLMabkH3sD4Fy != pObject->sbt_OBWGsGHLMabkH3sD4Fy)
		{
			return false;
		}
		if (sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.size() != pObject->sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.size(); i++)
		{
			if (sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6[i] != pObject->sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6[i])
			{
				return false;
			}
		}
		if (sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV != pObject->sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV)
		{
			return false;
		}
		if (sbt_Q2aze6sXd25xKPD != pObject->sbt_Q2aze6sXd25xKPD)
		{
			return false;
		}
		if (sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.size() != pObject->sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.size(); i++)
		{
			if (sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh[i] != pObject->sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh[i])
			{
				return false;
			}
		}
		if (sbt_9xcbMKiiIX9aTAnakflicoa != pObject->sbt_9xcbMKiiIX9aTAnakflicoa)
		{
			return false;
		}
		if (sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.size() != pObject->sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.size(); i++)
		{
			if (sbt_e1rjFcovx46ZjyXQUk_AjVe05v4[i] != pObject->sbt_e1rjFcovx46ZjyXQUk_AjVe05v4[i])
			{
				return false;
			}
		}
		if (sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.size() != pObject->sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.size(); i++)
		{
			if (sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90[i] != pObject->sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90[i])
			{
				return false;
			}
		}
		if (sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.size() != pObject->sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.size(); i++)
		{
			if (sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1[i] != pObject->sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_FvuiJatioOzYfiMJis20p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_FvuiJatioOzYfiMJis20p.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_krzgsLCDT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_krzgsLCDT = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Tc7LBEDxLyD", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Tc7LBEDxLyD = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_jn5xzxa4y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jn5xzxa4y = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectString("sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl", &sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz", &sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_OBWGsGHLMabkH3sD4Fy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_OBWGsGHLMabkH3sD4Fy = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_Q2aze6sXd25xKPD", &sbt_Q2aze6sXd25xKPD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_9xcbMKiiIX9aTAnakflicoa", &sbt_9xcbMKiiIX9aTAnakflicoa)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_e1rjFcovx46ZjyXQUk_AjVe05v4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_FvuiJatioOzYfiMJis20p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_FvuiJatioOzYfiMJis20p.begin(); iter != sbt_FvuiJatioOzYfiMJis20p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_krzgsLCDT", (CX::Int64)sbt_krzgsLCDT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.begin(); iter != sbt_pSjcfdGDhrLiglSTYuh3toSaLB22_BCY9SL8h.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.begin(); iter != sbt_dVamgkbpj_gvVXjONsIMsnCVtqVIn2bs6pEjaBJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B", (CX::Int64)sbt_TLCCWn8kIgC2GJInsfM0_bLg_JyFq_KY0_34B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Tc7LBEDxLyD", (CX::Int64)sbt_Tc7LBEDxLyD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jn5xzxa4y", (CX::Int64)sbt_jn5xzxa4y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS", (CX::Int64)sbt_sZsmrNn2BD0NEB1ZpF69Rf9SYdh5rEsEuUJtIOzvPvsp2SdwSIr0q0RqmiYkUyS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN", (CX::Int64)sbt_wWz_nPoWBdIiIHekvdEwXQ547RwgygzwxEN)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl", sbt__VFs0QKCScLpcQkx49mUSphsLNRnFKl.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz", sbt_Jct7hD7YSfNaOaIl96x_YthgbgNajdftIDLMtlhDnT5OEeTjz)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_OBWGsGHLMabkH3sD4Fy", (CX::Int64)sbt_OBWGsGHLMabkH3sD4Fy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.begin(); iter != sbt_5PBIITvwfnDGnlfcDQ671OZ_JwcXcWME6t6ohTYGXCgEZPm3BhD6Z6nZfgmq6.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV", (CX::Int64)sbt_5p5FFxYErBWWstL2Z61jJpAd3qs7vGV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Q2aze6sXd25xKPD", sbt_Q2aze6sXd25xKPD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.begin(); iter != sbt_191zKCQQke2MF7GpRKf3jsMHPJOePvmDh.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_9xcbMKiiIX9aTAnakflicoa", sbt_9xcbMKiiIX9aTAnakflicoa)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_e1rjFcovx46ZjyXQUk_AjVe05v4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.begin(); iter != sbt_e1rjFcovx46ZjyXQUk_AjVe05v4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.begin(); iter != sbt_sYGPW5fifjCBx0yk5Fh9igWvUml8CVNeN2P4BqvYOYf90.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.begin(); iter != sbt_A8FN8YuA16HjzJ8oH36JFwXFdH1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_m>::Type sbt_mArray;

