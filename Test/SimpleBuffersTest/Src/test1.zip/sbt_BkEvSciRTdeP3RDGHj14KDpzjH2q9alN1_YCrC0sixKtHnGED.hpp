
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt16 sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd;
	CX::IO::SimpleBuffers::UInt16Array sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK;
	CX::Int32 sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU;
	CX::UInt32 sbt_EmfuQP1;
	CX::IO::SimpleBuffers::BoolArray sbt_jtWsjHaWNbG;
	CX::Int8 sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL;
	CX::IO::SimpleBuffers::UInt8Array sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL;
	CX::IO::SimpleBuffers::BoolArray sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE;
	CX::UInt16 sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW;
	CX::IO::SimpleBuffers::Int16Array sbt_ekZK90egVQKQ2d4NYQ67m5pLx;
	CX::UInt64 sbt_XuvCjBm;
	CX::Bool sbt_eW5;
	CX::Bool sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t;
	CX::IO::SimpleBuffers::Int8Array sbt_7iaHpntQp;
	CX::IO::SimpleBuffers::UInt8Array sbt_T0CxcvpAB8uy9QCbiHfYPx4;
	CX::IO::SimpleBuffers::Int32Array sbt_qPEX4l0ag;
	CX::Int64 sbt_pPHVcLIoIJbWcj3LiYdjuxKEe;
	CX::UInt16 sbt__XLx7YnsI3S;
	CX::Int16 sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo;
	CX::UInt64 sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane;
	CX::IO::SimpleBuffers::UInt8Array sbt_2FBQIYjRU5yMKTJw25w;
	CX::Int32 sbt_6YQpUHgiL;
	CX::IO::SimpleBuffers::Int16Array sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE;

	virtual void Reset()
	{
		sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd = 0;
		sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.clear();
		sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU = 0;
		sbt_EmfuQP1 = 0;
		sbt_jtWsjHaWNbG.clear();
		sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL = 0;
		sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.clear();
		sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.clear();
		sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW = 0;
		sbt_ekZK90egVQKQ2d4NYQ67m5pLx.clear();
		sbt_XuvCjBm = 0;
		sbt_eW5 = false;
		sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t = false;
		sbt_7iaHpntQp.clear();
		sbt_T0CxcvpAB8uy9QCbiHfYPx4.clear();
		sbt_qPEX4l0ag.clear();
		sbt_pPHVcLIoIJbWcj3LiYdjuxKEe = 0;
		sbt__XLx7YnsI3S = 0;
		sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo = 0;
		sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane = 0;
		sbt_2FBQIYjRU5yMKTJw25w.clear();
		sbt_6YQpUHgiL = 0;
		sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd = 61789;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.push_back(46952);
		}
		sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU = 434248890;
		sbt_EmfuQP1 = 4075462793;
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_jtWsjHaWNbG.push_back(true);
		}
		sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL = 2;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.push_back(78);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.push_back(true);
		}
		sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW = 14253;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ekZK90egVQKQ2d4NYQ67m5pLx.push_back(10695);
		}
		sbt_XuvCjBm = 8873680217842101510;
		sbt_eW5 = false;
		sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t = true;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_T0CxcvpAB8uy9QCbiHfYPx4.push_back(57);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_qPEX4l0ag.push_back(-1317859094);
		}
		sbt_pPHVcLIoIJbWcj3LiYdjuxKEe = 6665720572405121840;
		sbt__XLx7YnsI3S = 63109;
		sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo = -14720;
		sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane = 5010088301596933956;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_2FBQIYjRU5yMKTJw25w.push_back(61);
		}
		sbt_6YQpUHgiL = -658300632;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.push_back(-1061);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED *pObject = dynamic_cast<const sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd != pObject->sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd)
		{
			return false;
		}
		if (sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.size() != pObject->sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.size(); i++)
		{
			if (sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK[i] != pObject->sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK[i])
			{
				return false;
			}
		}
		if (sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU != pObject->sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU)
		{
			return false;
		}
		if (sbt_EmfuQP1 != pObject->sbt_EmfuQP1)
		{
			return false;
		}
		if (sbt_jtWsjHaWNbG.size() != pObject->sbt_jtWsjHaWNbG.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jtWsjHaWNbG.size(); i++)
		{
			if (sbt_jtWsjHaWNbG[i] != pObject->sbt_jtWsjHaWNbG[i])
			{
				return false;
			}
		}
		if (sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL != pObject->sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL)
		{
			return false;
		}
		if (sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.size() != pObject->sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.size(); i++)
		{
			if (sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL[i] != pObject->sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL[i])
			{
				return false;
			}
		}
		if (sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.size() != pObject->sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.size(); i++)
		{
			if (sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE[i] != pObject->sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE[i])
			{
				return false;
			}
		}
		if (sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW != pObject->sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW)
		{
			return false;
		}
		if (sbt_ekZK90egVQKQ2d4NYQ67m5pLx.size() != pObject->sbt_ekZK90egVQKQ2d4NYQ67m5pLx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ekZK90egVQKQ2d4NYQ67m5pLx.size(); i++)
		{
			if (sbt_ekZK90egVQKQ2d4NYQ67m5pLx[i] != pObject->sbt_ekZK90egVQKQ2d4NYQ67m5pLx[i])
			{
				return false;
			}
		}
		if (sbt_XuvCjBm != pObject->sbt_XuvCjBm)
		{
			return false;
		}
		if (sbt_eW5 != pObject->sbt_eW5)
		{
			return false;
		}
		if (sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t != pObject->sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t)
		{
			return false;
		}
		if (sbt_7iaHpntQp.size() != pObject->sbt_7iaHpntQp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7iaHpntQp.size(); i++)
		{
			if (sbt_7iaHpntQp[i] != pObject->sbt_7iaHpntQp[i])
			{
				return false;
			}
		}
		if (sbt_T0CxcvpAB8uy9QCbiHfYPx4.size() != pObject->sbt_T0CxcvpAB8uy9QCbiHfYPx4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_T0CxcvpAB8uy9QCbiHfYPx4.size(); i++)
		{
			if (sbt_T0CxcvpAB8uy9QCbiHfYPx4[i] != pObject->sbt_T0CxcvpAB8uy9QCbiHfYPx4[i])
			{
				return false;
			}
		}
		if (sbt_qPEX4l0ag.size() != pObject->sbt_qPEX4l0ag.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qPEX4l0ag.size(); i++)
		{
			if (sbt_qPEX4l0ag[i] != pObject->sbt_qPEX4l0ag[i])
			{
				return false;
			}
		}
		if (sbt_pPHVcLIoIJbWcj3LiYdjuxKEe != pObject->sbt_pPHVcLIoIJbWcj3LiYdjuxKEe)
		{
			return false;
		}
		if (sbt__XLx7YnsI3S != pObject->sbt__XLx7YnsI3S)
		{
			return false;
		}
		if (sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo != pObject->sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo)
		{
			return false;
		}
		if (sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane != pObject->sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane)
		{
			return false;
		}
		if (sbt_2FBQIYjRU5yMKTJw25w.size() != pObject->sbt_2FBQIYjRU5yMKTJw25w.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_2FBQIYjRU5yMKTJw25w.size(); i++)
		{
			if (sbt_2FBQIYjRU5yMKTJw25w[i] != pObject->sbt_2FBQIYjRU5yMKTJw25w[i])
			{
				return false;
			}
		}
		if (sbt_6YQpUHgiL != pObject->sbt_6YQpUHgiL)
		{
			return false;
		}
		if (sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.size() != pObject->sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.size(); i++)
		{
			if (sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE[i] != pObject->sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU = (CX::Int32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_EmfuQP1", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EmfuQP1 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jtWsjHaWNbG")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jtWsjHaWNbG.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ekZK90egVQKQ2d4NYQ67m5pLx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ekZK90egVQKQ2d4NYQ67m5pLx.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_XuvCjBm", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_XuvCjBm = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_eW5", &sbt_eW5)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t", &sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_7iaHpntQp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7iaHpntQp.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_T0CxcvpAB8uy9QCbiHfYPx4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_T0CxcvpAB8uy9QCbiHfYPx4.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qPEX4l0ag")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qPEX4l0ag.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_pPHVcLIoIJbWcj3LiYdjuxKEe", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pPHVcLIoIJbWcj3LiYdjuxKEe = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt__XLx7YnsI3S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__XLx7YnsI3S = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_2FBQIYjRU5yMKTJw25w")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_2FBQIYjRU5yMKTJw25w.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6YQpUHgiL", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6YQpUHgiL = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd", (CX::Int64)sbt_U94Barl5P6CHDwP6jAILpil1trSjYQnDmRd)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.begin(); iter != sbt_9et1Lf3IH40GG4GKUxTcwpyMMhLvCCoukXK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU", (CX::Int64)sbt_gTPhMr6Fu6gtF53WmQsyf28JbiBRzXTIU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EmfuQP1", (CX::Int64)sbt_EmfuQP1)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jtWsjHaWNbG")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_jtWsjHaWNbG.begin(); iter != sbt_jtWsjHaWNbG.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL", (CX::Int64)sbt_zKGv_7gOVnEit0QkmcI2ohDsjQ7LTWnfTRWHPeiTL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.begin(); iter != sbt_qUDeAv1kc9TVrQJSDu7yX3bQPOzaGFDyE0hjctSZHM2XqNicL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.begin(); iter != sbt_BLvMLAZkv1hk2Wnj5GE4Lyu3mIH8ASYiPMxFE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW", (CX::Int64)sbt_fLOE0odc9XwaHnw0419A27pgDrSI9oGTxBLcukmd5rsTbogNlJm6u7NyW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ekZK90egVQKQ2d4NYQ67m5pLx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ekZK90egVQKQ2d4NYQ67m5pLx.begin(); iter != sbt_ekZK90egVQKQ2d4NYQ67m5pLx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_XuvCjBm", (CX::Int64)sbt_XuvCjBm)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_eW5", sbt_eW5)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t", sbt_xBmXw8HUlzC0j3efh3Pf_ad6sQq7Z4AxU7kw6fIEATlfg0olCN49t)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7iaHpntQp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_7iaHpntQp.begin(); iter != sbt_7iaHpntQp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_T0CxcvpAB8uy9QCbiHfYPx4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_T0CxcvpAB8uy9QCbiHfYPx4.begin(); iter != sbt_T0CxcvpAB8uy9QCbiHfYPx4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qPEX4l0ag")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_qPEX4l0ag.begin(); iter != sbt_qPEX4l0ag.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pPHVcLIoIJbWcj3LiYdjuxKEe", (CX::Int64)sbt_pPHVcLIoIJbWcj3LiYdjuxKEe)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__XLx7YnsI3S", (CX::Int64)sbt__XLx7YnsI3S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo", (CX::Int64)sbt_Y5vhAL3zwLGOVtWs7iJsfdVKvKobwFnuo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane", (CX::Int64)sbt_8GHstQ8EP6sYxBcyy2QhfqFjZA6_2c0sNZsLJhYdq5qUUqVBnJ2N0riZyNQqane)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_2FBQIYjRU5yMKTJw25w")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_2FBQIYjRU5yMKTJw25w.begin(); iter != sbt_2FBQIYjRU5yMKTJw25w.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6YQpUHgiL", (CX::Int64)sbt_6YQpUHgiL)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.begin(); iter != sbt_MtOGVoSTu0fwERDxUb9ZnbFSOSLwKTw6pU5ulAvUmSE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGED>::Type sbt_BkEvSciRTdeP3RDGHj14KDpzjH2q9alN1_YCrC0sixKtHnGEDArray;

