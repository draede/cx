
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_AcEqwQ57zeaissKeO : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx;
	CX::UInt64 sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og;
	CX::IO::SimpleBuffers::Int64Array sbt_CC7KL2e;
	CX::IO::SimpleBuffers::UInt32Array sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH;
	CX::IO::SimpleBuffers::Int16Array sbt_WYPBlc7;
	CX::IO::SimpleBuffers::Int8Array sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD;
	CX::UInt64 sbt_nMY_q4c;
	CX::Int8 sbt_Xflluf8joygibvbdDqjHPvs;
	CX::IO::SimpleBuffers::UInt32Array sbt_b29VL;
	CX::UInt32 sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN;

	virtual void Reset()
	{
		sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.clear();
		sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og = 0;
		sbt_CC7KL2e.clear();
		sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.clear();
		sbt_WYPBlc7.clear();
		sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.clear();
		sbt_nMY_q4c = 0;
		sbt_Xflluf8joygibvbdDqjHPvs = 0;
		sbt_b29VL.clear();
		sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.push_back("NRk90]={^n`bNerce}-hr(8c/B7to4#P&8;_p\"rq");
		}
		sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og = 5591133219408186522;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_CC7KL2e.push_back(-6131032260717993504);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.push_back(781989010);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_WYPBlc7.push_back(1660);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.push_back(41);
		}
		sbt_nMY_q4c = 6393213904042458612;
		sbt_Xflluf8joygibvbdDqjHPvs = -107;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_b29VL.push_back(2912210357);
		}
		sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN = 2215963686;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_AcEqwQ57zeaissKeO *pObject = dynamic_cast<const sbt_AcEqwQ57zeaissKeO *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.size() != pObject->sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.size(); i++)
		{
			if (0 != cx_strcmp(sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx[i].c_str(), pObject->sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og != pObject->sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og)
		{
			return false;
		}
		if (sbt_CC7KL2e.size() != pObject->sbt_CC7KL2e.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_CC7KL2e.size(); i++)
		{
			if (sbt_CC7KL2e[i] != pObject->sbt_CC7KL2e[i])
			{
				return false;
			}
		}
		if (sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.size() != pObject->sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.size(); i++)
		{
			if (sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH[i] != pObject->sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH[i])
			{
				return false;
			}
		}
		if (sbt_WYPBlc7.size() != pObject->sbt_WYPBlc7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_WYPBlc7.size(); i++)
		{
			if (sbt_WYPBlc7[i] != pObject->sbt_WYPBlc7[i])
			{
				return false;
			}
		}
		if (sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.size() != pObject->sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.size(); i++)
		{
			if (sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD[i] != pObject->sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD[i])
			{
				return false;
			}
		}
		if (sbt_nMY_q4c != pObject->sbt_nMY_q4c)
		{
			return false;
		}
		if (sbt_Xflluf8joygibvbdDqjHPvs != pObject->sbt_Xflluf8joygibvbdDqjHPvs)
		{
			return false;
		}
		if (sbt_b29VL.size() != pObject->sbt_b29VL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b29VL.size(); i++)
		{
			if (sbt_b29VL[i] != pObject->sbt_b29VL[i])
			{
				return false;
			}
		}
		if (sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN != pObject->sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_CC7KL2e")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_CC7KL2e.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_WYPBlc7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_WYPBlc7.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_nMY_q4c", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_nMY_q4c = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Xflluf8joygibvbdDqjHPvs", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Xflluf8joygibvbdDqjHPvs = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_b29VL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b29VL.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN = (CX::UInt32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.begin(); iter != sbt_amcTb0FjHz83hnHNzEWr4Q1Ub7JYHzxwhgItowBtrl_J7dVjicgGx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og", (CX::Int64)sbt_MvW0xSCAD6LHmfYvrafdVR4MKyov8og)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_CC7KL2e")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_CC7KL2e.begin(); iter != sbt_CC7KL2e.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.begin(); iter != sbt_kviaexSO47tN9wrFR2LytPb4GS5DY1UCrAr_3bJHA4yU7O0i6wxtH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_WYPBlc7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_WYPBlc7.begin(); iter != sbt_WYPBlc7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.begin(); iter != sbt_upwbdHlBaN9jwKEBcCcSI6JJeTyUaBCzRV4Xqb6hVsL9OHeaD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_nMY_q4c", (CX::Int64)sbt_nMY_q4c)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Xflluf8joygibvbdDqjHPvs", (CX::Int64)sbt_Xflluf8joygibvbdDqjHPvs)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b29VL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_b29VL.begin(); iter != sbt_b29VL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN", (CX::Int64)sbt_MoxfzAQhUH7AuvUYROO5ViRZgIF3P02pN)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_AcEqwQ57zeaissKeO>::Type sbt_AcEqwQ57zeaissKeOArray;

