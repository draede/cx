
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int8Array sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS;
	CX::IO::SimpleBuffers::UInt8Array sbt_ysDE8f5pO;
	CX::Int16 sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu;
	CX::UInt64 sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_;
	CX::Int16 sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG;
	CX::IO::SimpleBuffers::Int32Array sbt_TbTWlsrHQHsYc514QxK;
	CX::Int64 sbt_EtUlOJxi7;
	CX::IO::SimpleBuffers::Int8Array sbt_R;
	CX::IO::SimpleBuffers::BoolArray sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr;
	CX::IO::SimpleBuffers::UInt16Array sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p;

	virtual void Reset()
	{
		sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.clear();
		sbt_ysDE8f5pO.clear();
		sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu = 0;
		sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_ = 0;
		sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG = 0;
		sbt_TbTWlsrHQHsYc514QxK.clear();
		sbt_EtUlOJxi7 = 0;
		sbt_R.clear();
		sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.clear();
		sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.push_back(-43);
		}
		sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu = 14166;
		sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_ = 938238286697293398;
		sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG = -31738;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_TbTWlsrHQHsYc514QxK.push_back(1131072540);
		}
		sbt_EtUlOJxi7 = -8395028559033569698;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.push_back(true);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.push_back(24572);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js *pObject = dynamic_cast<const sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.size() != pObject->sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.size(); i++)
		{
			if (sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS[i] != pObject->sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS[i])
			{
				return false;
			}
		}
		if (sbt_ysDE8f5pO.size() != pObject->sbt_ysDE8f5pO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ysDE8f5pO.size(); i++)
		{
			if (sbt_ysDE8f5pO[i] != pObject->sbt_ysDE8f5pO[i])
			{
				return false;
			}
		}
		if (sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu != pObject->sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu)
		{
			return false;
		}
		if (sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_ != pObject->sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_)
		{
			return false;
		}
		if (sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG != pObject->sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG)
		{
			return false;
		}
		if (sbt_TbTWlsrHQHsYc514QxK.size() != pObject->sbt_TbTWlsrHQHsYc514QxK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_TbTWlsrHQHsYc514QxK.size(); i++)
		{
			if (sbt_TbTWlsrHQHsYc514QxK[i] != pObject->sbt_TbTWlsrHQHsYc514QxK[i])
			{
				return false;
			}
		}
		if (sbt_EtUlOJxi7 != pObject->sbt_EtUlOJxi7)
		{
			return false;
		}
		if (sbt_R.size() != pObject->sbt_R.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R.size(); i++)
		{
			if (sbt_R[i] != pObject->sbt_R[i])
			{
				return false;
			}
		}
		if (sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.size() != pObject->sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.size(); i++)
		{
			if (sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr[i] != pObject->sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr[i])
			{
				return false;
			}
		}
		if (sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.size() != pObject->sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.size(); i++)
		{
			if (sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p[i] != pObject->sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ysDE8f5pO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ysDE8f5pO.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_ = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_TbTWlsrHQHsYc514QxK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_TbTWlsrHQHsYc514QxK.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_EtUlOJxi7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_EtUlOJxi7 = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.begin(); iter != sbt_nPFGA7PsUfE8tthVlPvHPtBflPPrS.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ysDE8f5pO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ysDE8f5pO.begin(); iter != sbt_ysDE8f5pO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu", (CX::Int64)sbt_jGcNwQI_6n_uV7mhW8tGZCd4j0G23maA4f5nvdngu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_", (CX::Int64)sbt_3FAUw35TmjnEW6pvPFRqqwkPnvdosomb_)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG", (CX::Int64)sbt_8BQQEBU8LFkLotMtlRkWJcgioMKSQw5Z1dFC1hl8S_RFeuNxbUG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_TbTWlsrHQHsYc514QxK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_TbTWlsrHQHsYc514QxK.begin(); iter != sbt_TbTWlsrHQHsYc514QxK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_EtUlOJxi7", (CX::Int64)sbt_EtUlOJxi7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_R.begin(); iter != sbt_R.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.begin(); iter != sbt__eAtShdF5XqYoVmHstzQCe6JTFkPFl2r9dHSr.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.begin(); iter != sbt_v28kxmmeVUtFU_XpBLrsIWKOvZL5yrxomvs4TNu2xyZkpDbbaTCLwj46p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44js>::Type sbt_SWRPJ4O9DjHCWundWMsvLmF1yBoaIl_q5EqEPnS2P44jsArray;

