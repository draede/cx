
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int64 sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu;
	CX::Int64 sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP;
	CX::UInt32 sbt_hYl_OQcyY0w1GhaYewV;
	CX::UInt32 sbt_A7L7d1Ze8vm1RQ__A;
	CX::IO::SimpleBuffers::UInt8Array sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m;
	CX::IO::SimpleBuffers::Int16Array sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL;
	CX::UInt8 sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k;
	CX::Int8 sbt_LktmB5_As0qQMH1yPVSVrN3;
	CX::UInt8 sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt;
	CX::IO::SimpleBuffers::UInt32Array sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO;
	CX::IO::SimpleBuffers::StringArray sbt_RyxlaXz6cen;
	CX::Int8 sbt_E;

	virtual void Reset()
	{
		sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu = 0;
		sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP = 0;
		sbt_hYl_OQcyY0w1GhaYewV = 0;
		sbt_A7L7d1Ze8vm1RQ__A = 0;
		sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.clear();
		sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.clear();
		sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k = 0;
		sbt_LktmB5_As0qQMH1yPVSVrN3 = 0;
		sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt = 0;
		sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.clear();
		sbt_RyxlaXz6cen.clear();
		sbt_E = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu = -8721303128960249180;
		sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP = -2006822013461808304;
		sbt_hYl_OQcyY0w1GhaYewV = 4214597017;
		sbt_A7L7d1Ze8vm1RQ__A = 2071672228;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.push_back(36);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.push_back(-6353);
		}
		sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k = 103;
		sbt_LktmB5_As0qQMH1yPVSVrN3 = 104;
		sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt = 217;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.push_back(2371525925);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_RyxlaXz6cen.push_back("");
		}
		sbt_E = -87;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA *pObject = dynamic_cast<const sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu != pObject->sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu)
		{
			return false;
		}
		if (sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP != pObject->sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP)
		{
			return false;
		}
		if (sbt_hYl_OQcyY0w1GhaYewV != pObject->sbt_hYl_OQcyY0w1GhaYewV)
		{
			return false;
		}
		if (sbt_A7L7d1Ze8vm1RQ__A != pObject->sbt_A7L7d1Ze8vm1RQ__A)
		{
			return false;
		}
		if (sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.size() != pObject->sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.size(); i++)
		{
			if (sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m[i] != pObject->sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m[i])
			{
				return false;
			}
		}
		if (sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.size() != pObject->sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.size(); i++)
		{
			if (sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL[i] != pObject->sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL[i])
			{
				return false;
			}
		}
		if (sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k != pObject->sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k)
		{
			return false;
		}
		if (sbt_LktmB5_As0qQMH1yPVSVrN3 != pObject->sbt_LktmB5_As0qQMH1yPVSVrN3)
		{
			return false;
		}
		if (sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt != pObject->sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt)
		{
			return false;
		}
		if (sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.size() != pObject->sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.size(); i++)
		{
			if (sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO[i] != pObject->sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO[i])
			{
				return false;
			}
		}
		if (sbt_RyxlaXz6cen.size() != pObject->sbt_RyxlaXz6cen.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_RyxlaXz6cen.size(); i++)
		{
			if (0 != cx_strcmp(sbt_RyxlaXz6cen[i].c_str(), pObject->sbt_RyxlaXz6cen[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_E != pObject->sbt_E)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_hYl_OQcyY0w1GhaYewV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hYl_OQcyY0w1GhaYewV = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_A7L7d1Ze8vm1RQ__A", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_A7L7d1Ze8vm1RQ__A = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_LktmB5_As0qQMH1yPVSVrN3", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_LktmB5_As0qQMH1yPVSVrN3 = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_RyxlaXz6cen")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_RyxlaXz6cen.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_E", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_E = (CX::Int8)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu", (CX::Int64)sbt_8uti0cTygfK8TAFpuwiZ_IEEgOLUu)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP", (CX::Int64)sbt_Sm_e3CQOS6dIkPEk9fVy4M55uvB9Sy6CY29I5paCo9a6uT4DrVFvITP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hYl_OQcyY0w1GhaYewV", (CX::Int64)sbt_hYl_OQcyY0w1GhaYewV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_A7L7d1Ze8vm1RQ__A", (CX::Int64)sbt_A7L7d1Ze8vm1RQ__A)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.begin(); iter != sbt_QtJCtJqhQvP_Ke0ntO5WZcn9kmdTapxKGYNNqsG9m.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.begin(); iter != sbt_ONWQHfkJ6R_qWJErOg247Mv5Yzq_8mAbgiqF4DXQ6U0wvNB_VfaPIAVunhJQjpL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k", (CX::Int64)sbt_sEsExHIhfmD1ljVqEMcPTkbeTH83k)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_LktmB5_As0qQMH1yPVSVrN3", (CX::Int64)sbt_LktmB5_As0qQMH1yPVSVrN3)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt", (CX::Int64)sbt_Uv4huxYYLQmwJ0v4nLhMu6UzaUUCXnjJ0IgWmGElTJQvo88aodD0zewvlSt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.begin(); iter != sbt_5laaONxPk2pX_OwvaSRNuhavZs3KO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_RyxlaXz6cen")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_RyxlaXz6cen.begin(); iter != sbt_RyxlaXz6cen.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_E", (CX::Int64)sbt_E)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYA>::Type sbt_VDiGLtC9ikjqL4IwqzeuZp97jdXRaYAArray;

