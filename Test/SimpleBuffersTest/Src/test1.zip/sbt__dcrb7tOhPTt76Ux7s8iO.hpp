
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt__dcrb7tOhPTt76Ux7s8iO : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt8 sbt_UzT;
	CX::IO::SimpleBuffers::UInt16Array sbt_aU9;
	CX::String sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1;
	CX::UInt64 sbt_bRhfWihiouLBhj_onE6XcRH;
	CX::UInt8 sbt_HMF2je9kr;
	CX::UInt32 sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S;
	CX::UInt32 sbt_lyDXSQk;
	CX::IO::SimpleBuffers::UInt16Array sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd;
	CX::IO::SimpleBuffers::Int16Array sbt_gXClqiIO9zR_jINJj;
	CX::IO::SimpleBuffers::Int32Array sbt_HjJ;
	CX::IO::SimpleBuffers::UInt16Array sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq;
	CX::IO::SimpleBuffers::UInt16Array sbt_GkDnLWnJP86wquR;
	CX::IO::SimpleBuffers::UInt32Array sbt_PyosMW808;
	CX::IO::SimpleBuffers::StringArray sbt_dqoSZBtYtWKMC0YSK;
	CX::IO::SimpleBuffers::StringArray sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI;
	CX::IO::SimpleBuffers::Int16Array sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF;
	CX::Int32 sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR;

	virtual void Reset()
	{
		sbt_UzT = 0;
		sbt_aU9.clear();
		sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1.clear();
		sbt_bRhfWihiouLBhj_onE6XcRH = 0;
		sbt_HMF2je9kr = 0;
		sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S = 0;
		sbt_lyDXSQk = 0;
		sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.clear();
		sbt_gXClqiIO9zR_jINJj.clear();
		sbt_HjJ.clear();
		sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.clear();
		sbt_GkDnLWnJP86wquR.clear();
		sbt_PyosMW808.clear();
		sbt_dqoSZBtYtWKMC0YSK.clear();
		sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.clear();
		sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.clear();
		sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR = 0;
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_UzT = 148;
		sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1 = "Hr.r2z+'l+Sy$XpM5EfWd07^Ps";
		sbt_bRhfWihiouLBhj_onE6XcRH = 667620631461917166;
		sbt_HMF2je9kr = 211;
		sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S = 2181462645;
		sbt_lyDXSQk = 1304571596;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.push_back(54380);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_gXClqiIO9zR_jINJj.push_back(10971);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_HjJ.push_back(1509255784);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.push_back(22634);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_PyosMW808.push_back(1076389986);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_dqoSZBtYtWKMC0YSK.push_back("Y>=5\\kEn]`Os]");
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.push_back("?r0S%{/-cvmp+J>AaJqKRwGBgz~{3HRxW`c9ytv23*2^JY");
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.push_back(8320);
		}
		sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR = -817104920;
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt__dcrb7tOhPTt76Ux7s8iO *pObject = dynamic_cast<const sbt__dcrb7tOhPTt76Ux7s8iO *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_UzT != pObject->sbt_UzT)
		{
			return false;
		}
		if (sbt_aU9.size() != pObject->sbt_aU9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_aU9.size(); i++)
		{
			if (sbt_aU9[i] != pObject->sbt_aU9[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1.c_str(), pObject->sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1.c_str()))
		{
			return false;
		}
		if (sbt_bRhfWihiouLBhj_onE6XcRH != pObject->sbt_bRhfWihiouLBhj_onE6XcRH)
		{
			return false;
		}
		if (sbt_HMF2je9kr != pObject->sbt_HMF2je9kr)
		{
			return false;
		}
		if (sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S != pObject->sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S)
		{
			return false;
		}
		if (sbt_lyDXSQk != pObject->sbt_lyDXSQk)
		{
			return false;
		}
		if (sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.size() != pObject->sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.size(); i++)
		{
			if (sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd[i] != pObject->sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd[i])
			{
				return false;
			}
		}
		if (sbt_gXClqiIO9zR_jINJj.size() != pObject->sbt_gXClqiIO9zR_jINJj.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gXClqiIO9zR_jINJj.size(); i++)
		{
			if (sbt_gXClqiIO9zR_jINJj[i] != pObject->sbt_gXClqiIO9zR_jINJj[i])
			{
				return false;
			}
		}
		if (sbt_HjJ.size() != pObject->sbt_HjJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_HjJ.size(); i++)
		{
			if (sbt_HjJ[i] != pObject->sbt_HjJ[i])
			{
				return false;
			}
		}
		if (sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.size() != pObject->sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.size(); i++)
		{
			if (sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq[i] != pObject->sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq[i])
			{
				return false;
			}
		}
		if (sbt_GkDnLWnJP86wquR.size() != pObject->sbt_GkDnLWnJP86wquR.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GkDnLWnJP86wquR.size(); i++)
		{
			if (sbt_GkDnLWnJP86wquR[i] != pObject->sbt_GkDnLWnJP86wquR[i])
			{
				return false;
			}
		}
		if (sbt_PyosMW808.size() != pObject->sbt_PyosMW808.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_PyosMW808.size(); i++)
		{
			if (sbt_PyosMW808[i] != pObject->sbt_PyosMW808[i])
			{
				return false;
			}
		}
		if (sbt_dqoSZBtYtWKMC0YSK.size() != pObject->sbt_dqoSZBtYtWKMC0YSK.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dqoSZBtYtWKMC0YSK.size(); i++)
		{
			if (0 != cx_strcmp(sbt_dqoSZBtYtWKMC0YSK[i].c_str(), pObject->sbt_dqoSZBtYtWKMC0YSK[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.size() != pObject->sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.size(); i++)
		{
			if (0 != cx_strcmp(sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI[i].c_str(), pObject->sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.size() != pObject->sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.size(); i++)
		{
			if (sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF[i] != pObject->sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF[i])
			{
				return false;
			}
		}
		if (sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR != pObject->sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR)
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_UzT", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_UzT = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_aU9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_aU9.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1", &sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_bRhfWihiouLBhj_onE6XcRH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bRhfWihiouLBhj_onE6XcRH = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HMF2je9kr", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HMF2je9kr = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_lyDXSQk", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_lyDXSQk = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gXClqiIO9zR_jINJj")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gXClqiIO9zR_jINJj.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_HjJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_HjJ.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_GkDnLWnJP86wquR")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GkDnLWnJP86wquR.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_PyosMW808")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_PyosMW808.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dqoSZBtYtWKMC0YSK")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dqoSZBtYtWKMC0YSK.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR = (CX::Int32)nValue;

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_UzT", (CX::Int64)sbt_UzT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_aU9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_aU9.begin(); iter != sbt_aU9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1", sbt_NWf1FlC_oAV0FBE4L9wO5T77oTAD_qGkX_UA6aUsCX1Dc6mE8U1.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bRhfWihiouLBhj_onE6XcRH", (CX::Int64)sbt_bRhfWihiouLBhj_onE6XcRH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HMF2je9kr", (CX::Int64)sbt_HMF2je9kr)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S", (CX::Int64)sbt_SbdgOveRAO0U4CPmhL7v_jTMSnRELXn8mLoum2cEJYuT7zS9S)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_lyDXSQk", (CX::Int64)sbt_lyDXSQk)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.begin(); iter != sbt_O5_wM76t7QN_mlKhsJ_0T5qOY77vjRQOJNkuGJdaUdzl99qAqUYllGu4KcyBd.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gXClqiIO9zR_jINJj")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_gXClqiIO9zR_jINJj.begin(); iter != sbt_gXClqiIO9zR_jINJj.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_HjJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_HjJ.begin(); iter != sbt_HjJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.begin(); iter != sbt_StYuvVOdfnp06k4sTL6poneT6skj1QIR9ijqKCO9VRXOmj0CG33Hq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GkDnLWnJP86wquR")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_GkDnLWnJP86wquR.begin(); iter != sbt_GkDnLWnJP86wquR.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_PyosMW808")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_PyosMW808.begin(); iter != sbt_PyosMW808.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dqoSZBtYtWKMC0YSK")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_dqoSZBtYtWKMC0YSK.begin(); iter != sbt_dqoSZBtYtWKMC0YSK.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.begin(); iter != sbt_UtOcPR_0KXYwOBEfJ1OB01RbHpz6Rlr3pJUqNHsKkSosNUCPaKe_0p68hQvDjoI.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.begin(); iter != sbt_65aakvfCY1tYdW7dlHzASi_M42Im8dNuyvjbIQpB6H2eATEjH2NG8n00llzeF.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR", (CX::Int64)sbt_TVmrv39a_2bHCbjRbK4_2J1EHXt3u9ukR)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt__dcrb7tOhPTt76Ux7s8iO>::Type sbt__dcrb7tOhPTt76Ux7s8iOArray;

