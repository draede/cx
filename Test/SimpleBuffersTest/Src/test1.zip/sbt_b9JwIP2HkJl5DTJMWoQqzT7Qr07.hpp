
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::BoolArray sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX;
	CX::IO::SimpleBuffers::Int64Array sbt_uebPWa6Z9V_;
	CX::IO::SimpleBuffers::UInt32Array sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL;
	CX::UInt8 sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq;
	CX::IO::SimpleBuffers::UInt8Array sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB;
	CX::IO::SimpleBuffers::UInt32Array sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm;
	CX::IO::SimpleBuffers::StringArray sbt_4YX9Gpy;
	CX::Int8 sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii;
	CX::IO::SimpleBuffers::Int8Array sbt_LuacurR3C6MwWFxY8;
	CX::UInt64 sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B;
	CX::UInt32 sbt_kvxX1ZqjK2toVLdyVi7;
	CX::Bool sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4;
	CX::UInt32 sbt_Qjx;
	CX::Int8 sbt_3x2U276pHPgF148Yf;
	CX::IO::SimpleBuffers::UInt8Array sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC;
	CX::UInt64 sbt_qXM;
	CX::Int8 sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC;
	CX::String sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze;
	CX::IO::SimpleBuffers::UInt16Array sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei;
	CX::IO::SimpleBuffers::UInt16Array sbt_nJYCZ664JEaA1U8wdHlLa;

	virtual void Reset()
	{
		sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.clear();
		sbt_uebPWa6Z9V_.clear();
		sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.clear();
		sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq = 0;
		sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.clear();
		sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.clear();
		sbt_4YX9Gpy.clear();
		sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii = 0;
		sbt_LuacurR3C6MwWFxY8.clear();
		sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B = 0;
		sbt_kvxX1ZqjK2toVLdyVi7 = 0;
		sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4 = false;
		sbt_Qjx = 0;
		sbt_3x2U276pHPgF148Yf = 0;
		sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.clear();
		sbt_qXM = 0;
		sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC = 0;
		sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze.clear();
		sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.clear();
		sbt_nJYCZ664JEaA1U8wdHlLa.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.push_back(true);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_uebPWa6Z9V_.push_back(1644538316093109874);
		}
		sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq = 232;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.push_back(60);
		}
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.push_back(4228470903);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_4YX9Gpy.push_back("#A81-iow7u26M,(FQH1n");
		}
		sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii = 97;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_LuacurR3C6MwWFxY8.push_back(-108);
		}
		sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B = 17460074504687885236;
		sbt_kvxX1ZqjK2toVLdyVi7 = 2095501167;
		sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4 = false;
		sbt_Qjx = 919100296;
		sbt_3x2U276pHPgF148Yf = 27;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.push_back(209);
		}
		sbt_qXM = 10936377321583445022;
		sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC = -69;
		sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze = "hg\\j.'Msyj3q3%_B<^@JD88a[5H`wZ.6=m_SY=6;%5";
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.push_back(16838);
		}
		for (CX::Size i = 0; i < 1; i++)
		{
			sbt_nJYCZ664JEaA1U8wdHlLa.push_back(8258);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07 *pObject = dynamic_cast<const sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.size() != pObject->sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.size(); i++)
		{
			if (sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX[i] != pObject->sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX[i])
			{
				return false;
			}
		}
		if (sbt_uebPWa6Z9V_.size() != pObject->sbt_uebPWa6Z9V_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uebPWa6Z9V_.size(); i++)
		{
			if (sbt_uebPWa6Z9V_[i] != pObject->sbt_uebPWa6Z9V_[i])
			{
				return false;
			}
		}
		if (sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.size() != pObject->sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.size(); i++)
		{
			if (sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL[i] != pObject->sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL[i])
			{
				return false;
			}
		}
		if (sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq != pObject->sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq)
		{
			return false;
		}
		if (sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.size() != pObject->sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.size(); i++)
		{
			if (sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB[i] != pObject->sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB[i])
			{
				return false;
			}
		}
		if (sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.size() != pObject->sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.size(); i++)
		{
			if (sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm[i] != pObject->sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm[i])
			{
				return false;
			}
		}
		if (sbt_4YX9Gpy.size() != pObject->sbt_4YX9Gpy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4YX9Gpy.size(); i++)
		{
			if (0 != cx_strcmp(sbt_4YX9Gpy[i].c_str(), pObject->sbt_4YX9Gpy[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii != pObject->sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii)
		{
			return false;
		}
		if (sbt_LuacurR3C6MwWFxY8.size() != pObject->sbt_LuacurR3C6MwWFxY8.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_LuacurR3C6MwWFxY8.size(); i++)
		{
			if (sbt_LuacurR3C6MwWFxY8[i] != pObject->sbt_LuacurR3C6MwWFxY8[i])
			{
				return false;
			}
		}
		if (sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B != pObject->sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B)
		{
			return false;
		}
		if (sbt_kvxX1ZqjK2toVLdyVi7 != pObject->sbt_kvxX1ZqjK2toVLdyVi7)
		{
			return false;
		}
		if (sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4 != pObject->sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4)
		{
			return false;
		}
		if (sbt_Qjx != pObject->sbt_Qjx)
		{
			return false;
		}
		if (sbt_3x2U276pHPgF148Yf != pObject->sbt_3x2U276pHPgF148Yf)
		{
			return false;
		}
		if (sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.size() != pObject->sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.size(); i++)
		{
			if (sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC[i] != pObject->sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC[i])
			{
				return false;
			}
		}
		if (sbt_qXM != pObject->sbt_qXM)
		{
			return false;
		}
		if (sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC != pObject->sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze.c_str(), pObject->sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze.c_str()))
		{
			return false;
		}
		if (sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.size() != pObject->sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.size(); i++)
		{
			if (sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei[i] != pObject->sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei[i])
			{
				return false;
			}
		}
		if (sbt_nJYCZ664JEaA1U8wdHlLa.size() != pObject->sbt_nJYCZ664JEaA1U8wdHlLa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_nJYCZ664JEaA1U8wdHlLa.size(); i++)
		{
			if (sbt_nJYCZ664JEaA1U8wdHlLa[i] != pObject->sbt_nJYCZ664JEaA1U8wdHlLa[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_uebPWa6Z9V_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uebPWa6Z9V_.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4YX9Gpy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4YX9Gpy.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_LuacurR3C6MwWFxY8")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_LuacurR3C6MwWFxY8.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_kvxX1ZqjK2toVLdyVi7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kvxX1ZqjK2toVLdyVi7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectBool("sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4", &sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Qjx", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qjx = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectInt("sbt_3x2U276pHPgF148Yf", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_3x2U276pHPgF148Yf = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_qXM", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qXM = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectString("sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze", &sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_nJYCZ664JEaA1U8wdHlLa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_nJYCZ664JEaA1U8wdHlLa.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.begin(); iter != sbt_pGwSQpngM_CPiZk4hykSb5op3EJC4RPaX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uebPWa6Z9V_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_uebPWa6Z9V_.begin(); iter != sbt_uebPWa6Z9V_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.begin(); iter != sbt_cNXsmvOSd43vZ24t5AcXwIHjnU9Ps1hk0TlKfCAkS_nsVvKHL.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq", (CX::Int64)sbt_knZZDqZaqy5KvgM9BVjOetAugZl39Lnoes6XCIq)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.begin(); iter != sbt_ZOFo2GaYCiG_KAwEVYMUw67rFL2oqzjq7zlA9WXacjGyMLidjS7IptGBB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.begin(); iter != sbt_sLi8b75Q70cgAnurgdC9N_VDmzIIBYFYvQKL6GtMMRm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4YX9Gpy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_4YX9Gpy.begin(); iter != sbt_4YX9Gpy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii", (CX::Int64)sbt_kaiaukMwT1p7kEotz9FNOeUVAtGii)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_LuacurR3C6MwWFxY8")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_LuacurR3C6MwWFxY8.begin(); iter != sbt_LuacurR3C6MwWFxY8.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B", (CX::Int64)sbt_p3af8ZjHW0FFUWxbYI5YQrXEvYU_J6PZKtXsfxOeYXzWz4B)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kvxX1ZqjK2toVLdyVi7", (CX::Int64)sbt_kvxX1ZqjK2toVLdyVi7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4", sbt_pfRCiMvwNwCQqb_QXOwbDBXT6qbjr8B2QCyQyvNKinlgc7oWpjUL4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Qjx", (CX::Int64)sbt_Qjx)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_3x2U276pHPgF148Yf", (CX::Int64)sbt_3x2U276pHPgF148Yf)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.begin(); iter != sbt_KulhcYR9eLRyOPQF54VusV5QAycxaLrLfgUyLYijrtC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qXM", (CX::Int64)sbt_qXM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC", (CX::Int64)sbt_HBLrQc1NKdSw542Ghd1bY0OpiOQCAaIpxFf4IVKWC)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze", sbt_IpRp6VC7QccXJ8z3lrXQopLrQqkX8zUyGWcqIze.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.begin(); iter != sbt_o1EwkRdwd3BTAQ_BIywRrHjdaei.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_nJYCZ664JEaA1U8wdHlLa")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_nJYCZ664JEaA1U8wdHlLa.begin(); iter != sbt_nJYCZ664JEaA1U8wdHlLa.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07>::Type sbt_b9JwIP2HkJl5DTJMWoQqzT7Qr07Array;

