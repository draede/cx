
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V.hpp"


class sbt_GHHVqF1RWIWEE : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Float sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j;
	CX::IO::SimpleBuffers::UInt16Array sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta;
	CX::Double sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V;
	CX::Int32 sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F;
	CX::IO::SimpleBuffers::Int64Array sbt_VtDNk;
	CX::IO::SimpleBuffers::Int16Array sbt_pOWyVCAkW0Iw6v64c2Gn_;
	CX::Int64 sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU;
	CX::Int64 sbt_8gX7MHmVoGJ_3gebgjvBDbvvY;
	CX::IO::SimpleBuffers::WStringArray sbt_cj3ac;
	CX::Int8 sbt_KQYsIpjrCnI;
	CX::Bool sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc;
	CX::IO::SimpleBuffers::BoolArray sbt_T5ETc48dhELd6vtgaRwz6CX3p;
	CX::IO::SimpleBuffers::UInt8Array sbt_Uy1cOMDVi;
	CX::WString sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc;
	CX::IO::SimpleBuffers::UInt8Array sbt_rLjs0;
	CX::Int8 sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ;
	CX::Double sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU;
	CX::Float sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg;
	CX::IO::SimpleBuffers::StringArray sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye;
	CX::Int8 sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV;
	CX::IO::SimpleBuffers::WStringArray sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4;
	CX::Int8 sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO;
	CX::IO::SimpleBuffers::Int8Array sbt_4Uh8G6gljxKf1YJqcMlYs;
	sbt_cMNjJXDfEDVKhjQhPa0cDK15rwg1V sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr;

	virtual void Reset()
	{
		sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j = 0.0f;
		sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.clear();
		sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V = 0.0;
		sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F = 0;
		sbt_VtDNk.clear();
		sbt_pOWyVCAkW0Iw6v64c2Gn_.clear();
		sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU = 0;
		sbt_8gX7MHmVoGJ_3gebgjvBDbvvY = 0;
		sbt_cj3ac.clear();
		sbt_KQYsIpjrCnI = 0;
		sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc = false;
		sbt_T5ETc48dhELd6vtgaRwz6CX3p.clear();
		sbt_Uy1cOMDVi.clear();
		sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc.clear();
		sbt_rLjs0.clear();
		sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ = 0;
		sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU = 0.0;
		sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg = 0.0f;
		sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.clear();
		sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV = 0;
		sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.clear();
		sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO = 0;
		sbt_4Uh8G6gljxKf1YJqcMlYs.clear();
		sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j = 0.826162f;
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.push_back(48385);
		}
		sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V = 0.578421;
		sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F = -1340217685;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_VtDNk.push_back(3719447436101270934);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_pOWyVCAkW0Iw6v64c2Gn_.push_back(-32396);
		}
		sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU = -8068148552748379040;
		sbt_8gX7MHmVoGJ_3gebgjvBDbvvY = -7973180538103963636;
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_cj3ac.push_back(L"NFXL?p$*^=MTg`{lZ1bI{Ks27NH$0a/");
		}
		sbt_KQYsIpjrCnI = -30;
		sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc = true;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_T5ETc48dhELd6vtgaRwz6CX3p.push_back(true);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_Uy1cOMDVi.push_back(233);
		}
		sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc = L"I3n1Y{)>si8(*?bzx";
		sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ = -40;
		sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU = 0.717371;
		sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg = 0.008376f;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.push_back("}?aqgC\\Pyu[W,h)*[k4Zm*flQO;6s~y9D6Y!>b\\e1qt+$<]=LVjB]");
		}
		sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV = 49;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.push_back(L"HYqy5>7wYx]f\"7l4{)Vo<AfrEpC7]y1j:>4=,L6R>b<Z?:8u7?7-xd`H&qo");
		}
		sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO = 94;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_4Uh8G6gljxKf1YJqcMlYs.push_back(124);
		}
		sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_GHHVqF1RWIWEE *pObject = dynamic_cast<const sbt_GHHVqF1RWIWEE *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j != pObject->sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j)
		{
			return false;
		}
		if (sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.size() != pObject->sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.size(); i++)
		{
			if (sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta[i] != pObject->sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta[i])
			{
				return false;
			}
		}
		if (sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V != pObject->sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V)
		{
			return false;
		}
		if (sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F != pObject->sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F)
		{
			return false;
		}
		if (sbt_VtDNk.size() != pObject->sbt_VtDNk.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VtDNk.size(); i++)
		{
			if (sbt_VtDNk[i] != pObject->sbt_VtDNk[i])
			{
				return false;
			}
		}
		if (sbt_pOWyVCAkW0Iw6v64c2Gn_.size() != pObject->sbt_pOWyVCAkW0Iw6v64c2Gn_.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pOWyVCAkW0Iw6v64c2Gn_.size(); i++)
		{
			if (sbt_pOWyVCAkW0Iw6v64c2Gn_[i] != pObject->sbt_pOWyVCAkW0Iw6v64c2Gn_[i])
			{
				return false;
			}
		}
		if (sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU != pObject->sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU)
		{
			return false;
		}
		if (sbt_8gX7MHmVoGJ_3gebgjvBDbvvY != pObject->sbt_8gX7MHmVoGJ_3gebgjvBDbvvY)
		{
			return false;
		}
		if (sbt_cj3ac.size() != pObject->sbt_cj3ac.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_cj3ac.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_cj3ac[i].c_str(), pObject->sbt_cj3ac[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_KQYsIpjrCnI != pObject->sbt_KQYsIpjrCnI)
		{
			return false;
		}
		if (sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc != pObject->sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc)
		{
			return false;
		}
		if (sbt_T5ETc48dhELd6vtgaRwz6CX3p.size() != pObject->sbt_T5ETc48dhELd6vtgaRwz6CX3p.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_T5ETc48dhELd6vtgaRwz6CX3p.size(); i++)
		{
			if (sbt_T5ETc48dhELd6vtgaRwz6CX3p[i] != pObject->sbt_T5ETc48dhELd6vtgaRwz6CX3p[i])
			{
				return false;
			}
		}
		if (sbt_Uy1cOMDVi.size() != pObject->sbt_Uy1cOMDVi.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Uy1cOMDVi.size(); i++)
		{
			if (sbt_Uy1cOMDVi[i] != pObject->sbt_Uy1cOMDVi[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc.c_str(), pObject->sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc.c_str()))
		{
			return false;
		}
		if (sbt_rLjs0.size() != pObject->sbt_rLjs0.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_rLjs0.size(); i++)
		{
			if (sbt_rLjs0[i] != pObject->sbt_rLjs0[i])
			{
				return false;
			}
		}
		if (sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ != pObject->sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ)
		{
			return false;
		}
		if (sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU != pObject->sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU)
		{
			return false;
		}
		if (sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg != pObject->sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg)
		{
			return false;
		}
		if (sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.size() != pObject->sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.size(); i++)
		{
			if (0 != cx_strcmp(sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye[i].c_str(), pObject->sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV != pObject->sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV)
		{
			return false;
		}
		if (sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.size() != pObject->sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4[i].c_str(), pObject->sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO != pObject->sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO)
		{
			return false;
		}
		if (sbt_4Uh8G6gljxKf1YJqcMlYs.size() != pObject->sbt_4Uh8G6gljxKf1YJqcMlYs.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4Uh8G6gljxKf1YJqcMlYs.size(); i++)
		{
			if (sbt_4Uh8G6gljxKf1YJqcMlYs[i] != pObject->sbt_4Uh8G6gljxKf1YJqcMlYs[i])
			{
				return false;
			}
		}
		if (!sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr.Compare(&pObject->sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_VtDNk")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VtDNk.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pOWyVCAkW0Iw6v64c2Gn_")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pOWyVCAkW0Iw6v64c2Gn_.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_8gX7MHmVoGJ_3gebgjvBDbvvY", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8gX7MHmVoGJ_3gebgjvBDbvvY = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_cj3ac")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_cj3ac.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KQYsIpjrCnI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KQYsIpjrCnI = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc", &sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_T5ETc48dhELd6vtgaRwz6CX3p")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_T5ETc48dhELd6vtgaRwz6CX3p.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Uy1cOMDVi")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Uy1cOMDVi.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc", &sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_rLjs0")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_rLjs0.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectReal("sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectReal("sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_4Uh8G6gljxKf1YJqcMlYs")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4Uh8G6gljxKf1YJqcMlYs.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectObject("sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j", (CX::Double)sbt_xrhxN8QjoOm4qRqET4nzzsfuoWJqvoxlmMPbsaFrgZ_ET3M9LMipe4j)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.begin(); iter != sbt_uCo257adwzXaoFQHMFCox2droth_Vd3S43PJ2H4fTXMta.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V", (CX::Double)sbt_sUnvNCxMHk4hfG99oZ83AUsvtNrMxeI03Om8i2K43Lu1V)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F", (CX::Int64)sbt_kULyCAAf74YeQVYcN0x4ONjmxhqu5fL94mqNts0dY9gN6UJMrCJm9UspWvF6F)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VtDNk")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_VtDNk.begin(); iter != sbt_VtDNk.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pOWyVCAkW0Iw6v64c2Gn_")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_pOWyVCAkW0Iw6v64c2Gn_.begin(); iter != sbt_pOWyVCAkW0Iw6v64c2Gn_.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU", (CX::Int64)sbt_GLVSp1nbmz_m8esrPl1FrwGAJxlkYfqi_D_ZqEG8yOtmBB5qU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8gX7MHmVoGJ_3gebgjvBDbvvY", (CX::Int64)sbt_8gX7MHmVoGJ_3gebgjvBDbvvY)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_cj3ac")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_cj3ac.begin(); iter != sbt_cj3ac.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KQYsIpjrCnI", (CX::Int64)sbt_KQYsIpjrCnI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc", sbt_ZEfHZT_Hst6uhInFhpNioWMkBcAwp4YCdbQy_MVRhHCrFsLP2YiKdDIJAHc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_T5ETc48dhELd6vtgaRwz6CX3p")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_T5ETc48dhELd6vtgaRwz6CX3p.begin(); iter != sbt_T5ETc48dhELd6vtgaRwz6CX3p.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Uy1cOMDVi")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_Uy1cOMDVi.begin(); iter != sbt_Uy1cOMDVi.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc", sbt_3tQz2FusVZ3ckorzCYf4kmHuOY2AoC94ZiYlLPsP_aHh6dUpc.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_rLjs0")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_rLjs0.begin(); iter != sbt_rLjs0.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ", (CX::Int64)sbt_b4xZ3xsTMUOzbzUBSadgbtFHwPhOefjlgesdTWrJcdU9qJPAJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU", (CX::Double)sbt_NYiuwciZpQNN5dtaxCWDynJoFlevl9TA41vPQOZ3lBPJrd53sQ0ypMU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg", (CX::Double)sbt_ruDqbetFlVKO383dov_vynJD_M_DAHSgg)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.begin(); iter != sbt_b2hENVPPE8OG8OpYiIwMXwNEwzzs_zn9WJunphUBj0Rxk7nM_ye.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV", (CX::Int64)sbt_V6OFXIhjvH8QqxLL9Y0IQQ1xjk3Vsvu1hUGfan6BrLu1OxBX8ADiSWV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.begin(); iter != sbt_T25uzjjQbaxK7CfE9u6fhOn5mOTX0chHGIm_PauETaPJGVOTqKdSywcJOG4.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO", (CX::Int64)sbt_hfZHxPmKhZMB3c5iVjPaDQBSayHRkyojKnQ7tHhtkgn1NysM0rO)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4Uh8G6gljxKf1YJqcMlYs")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_4Uh8G6gljxKf1YJqcMlYs.begin(); iter != sbt_4Uh8G6gljxKf1YJqcMlYs.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_MMJZBsOfsqaS0A0xv7Sw8qwowDNq8wjkbcIana9bqBWeBZnmr.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_GHHVqF1RWIWEE>::Type sbt_GHHVqF1RWIWEEArray;

