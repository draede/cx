
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_rHak30F5CXp.hpp"


class sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Double sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW;
	CX::IO::SimpleBuffers::FloatArray sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD;
	CX::IO::SimpleBuffers::UInt64Array sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb;
	CX::WString sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM;
	CX::Double sbt_Q;
	CX::String sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6;
	CX::Float sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn;
	CX::IO::SimpleBuffers::UInt8Array sbt_7wdihvRKu2o4o7Tlpj7;
	CX::IO::SimpleBuffers::StringArray sbt_bl9Pp;
	CX::Int64 sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh;
	CX::Int8 sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ;
	CX::IO::SimpleBuffers::WStringArray sbt_JM9zGKcbtbk7g;
	CX::UInt8 sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw;
	CX::Int16 sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ;
	sbt_rHak30F5CXp sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h;

	virtual void Reset()
	{
		sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW = 0.0;
		sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.clear();
		sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.clear();
		sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM.clear();
		sbt_Q = 0.0;
		sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6.clear();
		sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn = 0.0f;
		sbt_7wdihvRKu2o4o7Tlpj7.clear();
		sbt_bl9Pp.clear();
		sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh = 0;
		sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ = 0;
		sbt_JM9zGKcbtbk7g.clear();
		sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw = 0;
		sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ = 0;
		sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW = 0.719054;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.push_back(0.458761f);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.push_back(15476485013252487490);
		}
		sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM = L"q])3^i/kBz:Fw?3qal?GhFQ*o=@Q)yANn`LC%FQy#+Z?%BLxrWtUs>W(f!";
		sbt_Q = 0.723388;
		sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6 = "\\EWMsNF|I_Cgjkj}RQ)}0UsN9Q4+3mF]Cr;[\"C'c'm23C'^w^(-<&";
		sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn = 0.518480f;
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_7wdihvRKu2o4o7Tlpj7.push_back(236);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_bl9Pp.push_back("A1|L1wYIN0>o<t0<7Cbiz\"&QbZ]HSq2dENuct/DG}*\"Ts{~X,");
		}
		sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh = 4879783830187812638;
		sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ = -84;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_JM9zGKcbtbk7g.push_back(L"aY6}");
		}
		sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw = 99;
		sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ = -31248;
		sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD *pObject = dynamic_cast<const sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW != pObject->sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW)
		{
			return false;
		}
		if (sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.size() != pObject->sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.size(); i++)
		{
			if (sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD[i] != pObject->sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD[i])
			{
				return false;
			}
		}
		if (sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.size() != pObject->sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.size(); i++)
		{
			if (sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb[i] != pObject->sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM.c_str(), pObject->sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM.c_str()))
		{
			return false;
		}
		if (sbt_Q != pObject->sbt_Q)
		{
			return false;
		}
		if (0 != cx_strcmp(sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6.c_str(), pObject->sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6.c_str()))
		{
			return false;
		}
		if (sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn != pObject->sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn)
		{
			return false;
		}
		if (sbt_7wdihvRKu2o4o7Tlpj7.size() != pObject->sbt_7wdihvRKu2o4o7Tlpj7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_7wdihvRKu2o4o7Tlpj7.size(); i++)
		{
			if (sbt_7wdihvRKu2o4o7Tlpj7[i] != pObject->sbt_7wdihvRKu2o4o7Tlpj7[i])
			{
				return false;
			}
		}
		if (sbt_bl9Pp.size() != pObject->sbt_bl9Pp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bl9Pp.size(); i++)
		{
			if (0 != cx_strcmp(sbt_bl9Pp[i].c_str(), pObject->sbt_bl9Pp[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh != pObject->sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh)
		{
			return false;
		}
		if (sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ != pObject->sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ)
		{
			return false;
		}
		if (sbt_JM9zGKcbtbk7g.size() != pObject->sbt_JM9zGKcbtbk7g.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_JM9zGKcbtbk7g.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_JM9zGKcbtbk7g[i].c_str(), pObject->sbt_JM9zGKcbtbk7g[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw != pObject->sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw)
		{
			return false;
		}
		if (sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ != pObject->sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ)
		{
			return false;
		}
		if (!sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h.Compare(&pObject->sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectReal("sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM", &sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_Q", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_Q = (CX::Double)lfValue;
		if ((status = pReader->ReadObjectString("sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6", &sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn = (CX::Float)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_7wdihvRKu2o4o7Tlpj7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_7wdihvRKu2o4o7Tlpj7.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bl9Pp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bl9Pp.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_JM9zGKcbtbk7g")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_JM9zGKcbtbk7g.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectObject("sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectReal("sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW", (CX::Double)sbt_u4KRr4DbwzkJQEYb8FDvBHm3honJSlW)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.begin(); iter != sbt_L0UIxaNgyfb_9rY_FrY6O7FkTfFTJ1FkUHF6OnjyXSexDh3OqJb0bxaa3jOkiKD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.begin(); iter != sbt_BK7t8K4ZyiuFRmrwSebTsQ6wzA6vaRS7JjydbdpofsLs15lwaddmExxDfEJGMqb.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM", sbt_SJ0MrkcqjeCb5RQRD1kYF0vzlbrdMwUbaTnCp9baCqP43UTopp_eUBmLM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_Q", (CX::Double)sbt_Q)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6", sbt_o4Q_yyTMfobpVzLcCmAhA8AIVOa3FaQSbzRIqatJ3hPWfaoQCc6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn", (CX::Double)sbt_2EoG9VVSFbesIoUNAwSUbTSf_osfnWDyQsn)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_7wdihvRKu2o4o7Tlpj7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_7wdihvRKu2o4o7Tlpj7.begin(); iter != sbt_7wdihvRKu2o4o7Tlpj7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bl9Pp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_bl9Pp.begin(); iter != sbt_bl9Pp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh", (CX::Int64)sbt_2QEPkMA_JddM5cqYNJ4PlJdrJm09bq2ZOaY7yB3CgrekgXGyti5jh)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ", (CX::Int64)sbt_qcPiRXaSPOwWd4YBkJhvzUsbaiWBSdsAY79FNRtS7BOLvHMXhwV6Q5_mJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_JM9zGKcbtbk7g")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_JM9zGKcbtbk7g.begin(); iter != sbt_JM9zGKcbtbk7g.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw", (CX::Int64)sbt_9xbCRK0dyJrvQZzRNF7SnkWcWvABQUxgllrdwtDt2697YR67tRvoBZjrRFYC2Vw)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ", (CX::Int64)sbt_zSqBELGBbBgRdMbSzBU4JnlkHVZtixtmnImgQp2SMIzLo7ZmnANovU1NPeJ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_kR6xWXAKw0qveYAusym0gWq0xi0tn0NMN9yCJXFLYblhC8h.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXD>::Type sbt_eayUNK6GmB4yJncUvFDEvOjLccf3RGlWuJOKZtQtWRWC6EQSf07d1ZBXDArray;

