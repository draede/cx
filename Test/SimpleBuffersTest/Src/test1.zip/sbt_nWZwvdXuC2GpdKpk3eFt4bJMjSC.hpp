
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int64Array sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT;
	CX::Bool sbt_mJLonyPmSjLdH;
	CX::IO::SimpleBuffers::BoolArray sbt_1qUqi1qoF4Ff7;
	CX::IO::SimpleBuffers::UInt64Array sbt_kTQDE;
	CX::IO::SimpleBuffers::StringArray sbt_gGRop0jNUTMx0YXKMtC;

	virtual void Reset()
	{
		sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.clear();
		sbt_mJLonyPmSjLdH = false;
		sbt_1qUqi1qoF4Ff7.clear();
		sbt_kTQDE.clear();
		sbt_gGRop0jNUTMx0YXKMtC.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_mJLonyPmSjLdH = true;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_1qUqi1qoF4Ff7.push_back(true);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_kTQDE.push_back(12808904494137970734);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_gGRop0jNUTMx0YXKMtC.push_back("~^KE\"u4SqU\\hULPd{63?_,y/,'B<pO#M.fZR.C~K");
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC *pObject = dynamic_cast<const sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.size() != pObject->sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.size(); i++)
		{
			if (sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT[i] != pObject->sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT[i])
			{
				return false;
			}
		}
		if (sbt_mJLonyPmSjLdH != pObject->sbt_mJLonyPmSjLdH)
		{
			return false;
		}
		if (sbt_1qUqi1qoF4Ff7.size() != pObject->sbt_1qUqi1qoF4Ff7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1qUqi1qoF4Ff7.size(); i++)
		{
			if (sbt_1qUqi1qoF4Ff7[i] != pObject->sbt_1qUqi1qoF4Ff7[i])
			{
				return false;
			}
		}
		if (sbt_kTQDE.size() != pObject->sbt_kTQDE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_kTQDE.size(); i++)
		{
			if (sbt_kTQDE[i] != pObject->sbt_kTQDE[i])
			{
				return false;
			}
		}
		if (sbt_gGRop0jNUTMx0YXKMtC.size() != pObject->sbt_gGRop0jNUTMx0YXKMtC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_gGRop0jNUTMx0YXKMtC.size(); i++)
		{
			if (0 != cx_strcmp(sbt_gGRop0jNUTMx0YXKMtC[i].c_str(), pObject->sbt_gGRop0jNUTMx0YXKMtC[i].c_str()))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_mJLonyPmSjLdH", &sbt_mJLonyPmSjLdH)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1qUqi1qoF4Ff7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1qUqi1qoF4Ff7.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_kTQDE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_kTQDE.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_gGRop0jNUTMx0YXKMtC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_gGRop0jNUTMx0YXKMtC.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.begin(); iter != sbt__pluKkwpnduwgussPlmcgPVPhP0ebopzGTEj5fEEa7QUcsT.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_mJLonyPmSjLdH", sbt_mJLonyPmSjLdH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1qUqi1qoF4Ff7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_1qUqi1qoF4Ff7.begin(); iter != sbt_1qUqi1qoF4Ff7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_kTQDE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_kTQDE.begin(); iter != sbt_kTQDE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_gGRop0jNUTMx0YXKMtC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_gGRop0jNUTMx0YXKMtC.begin(); iter != sbt_gGRop0jNUTMx0YXKMtC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSC>::Type sbt_nWZwvdXuC2GpdKpk3eFt4bJMjSCArray;

