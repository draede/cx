
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_IEcPBwJwXG83EtM1Q2f.hpp"


class sbt_ae6G2 : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::StringArray sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz;
	CX::Int16 sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp;
	CX::Int16 sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la;
	CX::UInt16 sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67;
	CX::IO::SimpleBuffers::DoubleArray sbt_GYsJx;
	CX::IO::SimpleBuffers::Int32Array sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih;
	CX::IO::SimpleBuffers::StringArray sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w;
	CX::UInt16 sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb;
	CX::IO::SimpleBuffers::UInt32Array sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ;
	CX::IO::SimpleBuffers::UInt16Array sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO;
	CX::IO::SimpleBuffers::BoolArray sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y;
	CX::Double sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP;
	CX::IO::SimpleBuffers::BoolArray sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3;
	CX::IO::SimpleBuffers::UInt32Array sbt_xyZUJzXi6Q7L5LmG4Oajrlutx;
	CX::UInt16 sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo;
	CX::Bool sbt_Eyo;
	CX::Double sbt_JVPH5xkTtgPM28RxfQSusyB;
	CX::IO::SimpleBuffers::FloatArray sbt_ISvA1;
	CX::Int8 sbt_KSYumpW2s9L0cJTwuFRm8hWGR;
	CX::IO::SimpleBuffers::FloatArray sbt_ivH;
	CX::Bool sbt_AFzUgdy12xEQQ;
	CX::IO::SimpleBuffers::StringArray sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV;
	CX::Int8 sbt_Ce8sXjrUcYciFrRyyiw9sTIMy;
	sbt_IEcPBwJwXG83EtM1Q2f sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j;

	virtual void Reset()
	{
		sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.clear();
		sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp = 0;
		sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la = 0;
		sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67 = 0;
		sbt_GYsJx.clear();
		sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.clear();
		sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.clear();
		sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb = 0;
		sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.clear();
		sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.clear();
		sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.clear();
		sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP = 0.0;
		sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.clear();
		sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.clear();
		sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo = 0;
		sbt_Eyo = false;
		sbt_JVPH5xkTtgPM28RxfQSusyB = 0.0;
		sbt_ISvA1.clear();
		sbt_KSYumpW2s9L0cJTwuFRm8hWGR = 0;
		sbt_ivH.clear();
		sbt_AFzUgdy12xEQQ = false;
		sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.clear();
		sbt_Ce8sXjrUcYciFrRyyiw9sTIMy = 0;
		sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j.Reset();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.push_back("<zMYc[Uix!pW!_/(0BpG!,cc%)SP)45UBSG|QX#R:");
		}
		sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp = -1468;
		sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la = -14824;
		sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67 = 36879;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_GYsJx.push_back(0.755554);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.push_back(-716834590);
		}
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.push_back("<:4&4WU?rxXkQEiNI}Mwx}%");
		}
		sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb = 49462;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.push_back(634477489);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.push_back(16280);
		}
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.push_back(false);
		}
		sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP = 0.701103;
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.push_back(true);
		}
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.push_back(2224481300);
		}
		sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo = 18704;
		sbt_Eyo = false;
		sbt_JVPH5xkTtgPM28RxfQSusyB = 0.848343;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_ISvA1.push_back(0.106390f);
		}
		sbt_KSYumpW2s9L0cJTwuFRm8hWGR = -6;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_ivH.push_back(0.486397f);
		}
		sbt_AFzUgdy12xEQQ = false;
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.push_back("e=HDMm\"Q<@xN-Nj`k_`B}gEv?>B'x<lf_|-9qZ3hq\\~:V*M'UOF,C");
		}
		sbt_Ce8sXjrUcYciFrRyyiw9sTIMy = 116;
		sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j.SetupWithSomeValues();
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ae6G2 *pObject = dynamic_cast<const sbt_ae6G2 *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.size() != pObject->sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.size(); i++)
		{
			if (0 != cx_strcmp(sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz[i].c_str(), pObject->sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp != pObject->sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp)
		{
			return false;
		}
		if (sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la != pObject->sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la)
		{
			return false;
		}
		if (sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67 != pObject->sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67)
		{
			return false;
		}
		if (sbt_GYsJx.size() != pObject->sbt_GYsJx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_GYsJx.size(); i++)
		{
			if (sbt_GYsJx[i] != pObject->sbt_GYsJx[i])
			{
				return false;
			}
		}
		if (sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.size() != pObject->sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.size(); i++)
		{
			if (sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih[i] != pObject->sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih[i])
			{
				return false;
			}
		}
		if (sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.size() != pObject->sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.size(); i++)
		{
			if (0 != cx_strcmp(sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w[i].c_str(), pObject->sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb != pObject->sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb)
		{
			return false;
		}
		if (sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.size() != pObject->sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.size(); i++)
		{
			if (sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ[i] != pObject->sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ[i])
			{
				return false;
			}
		}
		if (sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.size() != pObject->sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.size(); i++)
		{
			if (sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO[i] != pObject->sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO[i])
			{
				return false;
			}
		}
		if (sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.size() != pObject->sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.size(); i++)
		{
			if (sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y[i] != pObject->sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y[i])
			{
				return false;
			}
		}
		if (sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP != pObject->sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP)
		{
			return false;
		}
		if (sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.size() != pObject->sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.size(); i++)
		{
			if (sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3[i] != pObject->sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3[i])
			{
				return false;
			}
		}
		if (sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.size() != pObject->sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.size(); i++)
		{
			if (sbt_xyZUJzXi6Q7L5LmG4Oajrlutx[i] != pObject->sbt_xyZUJzXi6Q7L5LmG4Oajrlutx[i])
			{
				return false;
			}
		}
		if (sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo != pObject->sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo)
		{
			return false;
		}
		if (sbt_Eyo != pObject->sbt_Eyo)
		{
			return false;
		}
		if (sbt_JVPH5xkTtgPM28RxfQSusyB != pObject->sbt_JVPH5xkTtgPM28RxfQSusyB)
		{
			return false;
		}
		if (sbt_ISvA1.size() != pObject->sbt_ISvA1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ISvA1.size(); i++)
		{
			if (sbt_ISvA1[i] != pObject->sbt_ISvA1[i])
			{
				return false;
			}
		}
		if (sbt_KSYumpW2s9L0cJTwuFRm8hWGR != pObject->sbt_KSYumpW2s9L0cJTwuFRm8hWGR)
		{
			return false;
		}
		if (sbt_ivH.size() != pObject->sbt_ivH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ivH.size(); i++)
		{
			if (sbt_ivH[i] != pObject->sbt_ivH[i])
			{
				return false;
			}
		}
		if (sbt_AFzUgdy12xEQQ != pObject->sbt_AFzUgdy12xEQQ)
		{
			return false;
		}
		if (sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.size() != pObject->sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.size(); i++)
		{
			if (0 != cx_strcmp(sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV[i].c_str(), pObject->sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_Ce8sXjrUcYciFrRyyiw9sTIMy != pObject->sbt_Ce8sXjrUcYciFrRyyiw9sTIMy)
		{
			return false;
		}
		if (!sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j.Compare(&pObject->sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67 = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_GYsJx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_GYsJx.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb = (CX::UInt16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_xyZUJzXi6Q7L5LmG4Oajrlutx")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo = (CX::UInt16)nValue;
		if ((status = pReader->ReadObjectBool("sbt_Eyo", &sbt_Eyo)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_JVPH5xkTtgPM28RxfQSusyB", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_JVPH5xkTtgPM28RxfQSusyB = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_ISvA1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ISvA1.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_KSYumpW2s9L0cJTwuFRm8hWGR", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_KSYumpW2s9L0cJTwuFRm8hWGR = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_ivH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ivH.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectBool("sbt_AFzUgdy12xEQQ", &sbt_AFzUgdy12xEQQ)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Ce8sXjrUcYciFrRyyiw9sTIMy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ce8sXjrUcYciFrRyyiw9sTIMy = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectObject("sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j.Read(pReader)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.begin(); iter != sbt_3yJgmgIbRd7y4PXOifgNMB8rSghKBU2sncuDPMGGz.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp", (CX::Int64)sbt_5qsYPpyABjOOyUOtdfN0TB97je2jFGbC_WuYnUp)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la", (CX::Int64)sbt_MuyBluUpGD7u0BGQCDliLbAYkzNvusnghof0NwOLs2pM88dZE68la)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67", (CX::Int64)sbt_bGmeA9zMAcYqk41Gv8iHFj74A5RurEcVxFosTJvrUdu_c37WbnvfuJAtBz8Hn67)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_GYsJx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_GYsJx.begin(); iter != sbt_GYsJx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.begin(); iter != sbt_ow8v1w_OJrJmm9XtGYkxMYSw6wBsy6dfOcqD2urCF3lku_5Sva2ih.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.begin(); iter != sbt_6Kyx6ZFsWx3ZxH6HpBOFbg5l0XkrpbDaNfUCrrjmf8fhsA33LeB0w.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb", (CX::Int64)sbt_Mm0kHaVozoDzTABRtkOW7cwoj2j2Kaz2tVTN5jHipeyWf69SELGB0tb)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.begin(); iter != sbt_0b31QFHH2IzCdX4rO6DIkaz8mCbesLyPI2VipWiUH7zdl3GUZ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.begin(); iter != sbt_VvWWaJmb_UKmNu5iNTlRSpoaVYffc6yG757kHzgTO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.begin(); iter != sbt_qjsU2IHJHSth21idenYyeJ5RyBxl4FgYvNgh_Qy1c_RgfcfWHt48d9y.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP", (CX::Double)sbt_HZagL9Ug9Z708TSaNPkvdo6pZjVH7z_4DmfckKgHNm3uP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.begin(); iter != sbt_OCIjPftz7UDf6vpP7NLl1TxlmF3.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xyZUJzXi6Q7L5LmG4Oajrlutx")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.begin(); iter != sbt_xyZUJzXi6Q7L5LmG4Oajrlutx.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo", (CX::Int64)sbt_ubgcl8_SgFlxojfDWMQPMP2a5_LiWm2dTHdSo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_Eyo", sbt_Eyo)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_JVPH5xkTtgPM28RxfQSusyB", (CX::Double)sbt_JVPH5xkTtgPM28RxfQSusyB)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ISvA1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_ISvA1.begin(); iter != sbt_ISvA1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_KSYumpW2s9L0cJTwuFRm8hWGR", (CX::Int64)sbt_KSYumpW2s9L0cJTwuFRm8hWGR)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ivH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_ivH.begin(); iter != sbt_ivH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_AFzUgdy12xEQQ", sbt_AFzUgdy12xEQQ)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.begin(); iter != sbt_8rSUu3cSZx31rsQV9JXSETaJ1aaVanJMaeV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ce8sXjrUcYciFrRyyiw9sTIMy", (CX::Int64)sbt_Ce8sXjrUcYciFrRyyiw9sTIMy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectObject("sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j")).IsNOK())
		{
			return status;
		}
		if ((status = sbt_P1o1MyCpmVnl1quoh9tZVcvjv4Q857KQ6yH0N2pDul0OBTnxLojfdVV0j.Write(pWriter)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->EndObjectObject()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ae6G2>::Type sbt_ae6G2Array;

