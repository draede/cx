
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int16 sbt_M;
	CX::IO::SimpleBuffers::Int32Array sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY;
	CX::Int64 sbt_04YMcAbqUCzkFNJ9aUkvaaQpI;
	CX::Bool sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6;
	CX::UInt8 sbt_Srcy9DSGk_XXx7jiDAc;
	CX::Bool sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS;
	CX::UInt64 sbt_8zl2A;
	CX::UInt8 sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt;
	CX::IO::SimpleBuffers::UInt8Array sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN;
	CX::String sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL;

	virtual void Reset()
	{
		sbt_M = 0;
		sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.clear();
		sbt_04YMcAbqUCzkFNJ9aUkvaaQpI = 0;
		sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6 = false;
		sbt_Srcy9DSGk_XXx7jiDAc = 0;
		sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS = false;
		sbt_8zl2A = 0;
		sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt = 0;
		sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.clear();
		sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_M = 8354;
		for (CX::Size i = 0; i < 13; i++)
		{
			sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.push_back(-1187225955);
		}
		sbt_04YMcAbqUCzkFNJ9aUkvaaQpI = 1315308126997544592;
		sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6 = false;
		sbt_Srcy9DSGk_XXx7jiDAc = 230;
		sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS = false;
		sbt_8zl2A = 9605104477577898724;
		sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt = 199;
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.push_back(222);
		}
		sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL = "IT$bY{kWy|h7(q2qC{|5ZSN1Xs^sM8x/^$m[;dWCYGEg.}ZPX;JAB'\"\"H1M";
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm *pObject = dynamic_cast<const sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_M != pObject->sbt_M)
		{
			return false;
		}
		if (sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.size() != pObject->sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.size(); i++)
		{
			if (sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY[i] != pObject->sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY[i])
			{
				return false;
			}
		}
		if (sbt_04YMcAbqUCzkFNJ9aUkvaaQpI != pObject->sbt_04YMcAbqUCzkFNJ9aUkvaaQpI)
		{
			return false;
		}
		if (sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6 != pObject->sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6)
		{
			return false;
		}
		if (sbt_Srcy9DSGk_XXx7jiDAc != pObject->sbt_Srcy9DSGk_XXx7jiDAc)
		{
			return false;
		}
		if (sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS != pObject->sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS)
		{
			return false;
		}
		if (sbt_8zl2A != pObject->sbt_8zl2A)
		{
			return false;
		}
		if (sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt != pObject->sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt)
		{
			return false;
		}
		if (sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.size() != pObject->sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.size(); i++)
		{
			if (sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN[i] != pObject->sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL.c_str(), pObject->sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL.c_str()))
		{
			return false;
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_M", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_M = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.push_back((CX::Int32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_04YMcAbqUCzkFNJ9aUkvaaQpI", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_04YMcAbqUCzkFNJ9aUkvaaQpI = (CX::Int64)nValue;
		if ((status = pReader->ReadObjectBool("sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6", &sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Srcy9DSGk_XXx7jiDAc", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Srcy9DSGk_XXx7jiDAc = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectBool("sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS", &sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_8zl2A", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_8zl2A = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectInt("sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt = (CX::UInt8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.push_back((CX::UInt8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL", &sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL)).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_M", (CX::Int64)sbt_M)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int32Array::const_iterator iter = sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.begin(); iter != sbt_c1e1Oy5qSXl4d0AutOR3_mK6mBPgea6p5j1QuPIIsrY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_04YMcAbqUCzkFNJ9aUkvaaQpI", (CX::Int64)sbt_04YMcAbqUCzkFNJ9aUkvaaQpI)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6", sbt_2otpd9WE50gkAjTw4vxtoNACtLweROz23k3dvdy6MAtSKz7cEejBEXgOMZ6)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Srcy9DSGk_XXx7jiDAc", (CX::Int64)sbt_Srcy9DSGk_XXx7jiDAc)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectBool("sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS", sbt_zDAqJlFXKXyIfSXO7u_k9jIBMKKqYBxtqVPuY9cvS)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_8zl2A", (CX::Int64)sbt_8zl2A)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt", (CX::Int64)sbt_pWWuAZRjGcWRB16El1yMw3kBVHGGBT3txTlOvUqpQzHY2Bt)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt8Array::const_iterator iter = sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.begin(); iter != sbt_xWe2puSxUpl87AWl8c0p7mdZ1pk8CmmQly5KxyMxGccIevbUc5UkN.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL", sbt_Z4rQrPDmJwyYjlQ7EE54IwDFEgNIR6tP3dsabFATkKiRL.c_str())).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNm>::Type sbt_Y5d3PlPgzwvKadL8yD1gduz2va2vI9Krmm6TWwvGRMTHyKKCmb3NWmx3ATVNmArray;

