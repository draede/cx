
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::UInt64Array sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5;

	virtual void Reset()
	{
		sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.push_back(18045659666337922334);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw *pObject = dynamic_cast<const sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.size() != pObject->sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.size(); i++)
		{
			if (sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5[i] != pObject->sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.begin(); iter != sbt_lyGp2bcpHwxK_PM33p0FIuDR_Lcxyr5.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNw>::Type sbt_ZFMyaBxti4PSKF56WwL0dJZYx6t1B0l7SJ8q4TCmOND8JNwArray;

