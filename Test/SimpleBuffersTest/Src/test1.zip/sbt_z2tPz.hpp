
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp.hpp"


class sbt_z2tPz : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::IO::SimpleBuffers::Int16Array sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou;
	CX::IO::SimpleBuffers::FloatArray sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO;
	CX::IO::SimpleBuffers::Int8Array sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC;
	CX::IO::SimpleBuffers::Int16Array sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ;
	CX::IO::SimpleBuffers::Int64Array sbt_bMfJsEA;
	CX::Int8 sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV;
	CX::Int16 sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks;
	CX::IO::SimpleBuffers::BoolArray sbt_fj15pqxtH1YinilgzOfcq;
	CX::IO::SimpleBuffers::StringArray sbt_S;
	CX::Int16 sbt_6R3uPLSnSPFQQpTyzWfMWHG;
	CX::Int32 sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K;
	sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzpArray sbt_dW4fibU;

	virtual void Reset()
	{
		sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.clear();
		sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.clear();
		sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.clear();
		sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.clear();
		sbt_bMfJsEA.clear();
		sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV = 0;
		sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks = 0;
		sbt_fj15pqxtH1YinilgzOfcq.clear();
		sbt_S.clear();
		sbt_6R3uPLSnSPFQQpTyzWfMWHG = 0;
		sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K = 0;
		sbt_dW4fibU.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.push_back(-3497);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.push_back(0.659840f);
		}
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.push_back(126);
		}
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.push_back(29679);
		}
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_bMfJsEA.push_back(-2542301362142016672);
		}
		sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV = 126;
		sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks = 28229;
		for (CX::Size i = 0; i < 16; i++)
		{
			sbt_fj15pqxtH1YinilgzOfcq.push_back(false);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_S.push_back("^y7}:r'+88i[sFO:N6R%6dSNN\"C!vsD2m?M*;&-R");
		}
		sbt_6R3uPLSnSPFQQpTyzWfMWHG = 11433;
		sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K = -1864508800;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp v;

			v.SetupWithSomeValues();
			sbt_dW4fibU.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_z2tPz *pObject = dynamic_cast<const sbt_z2tPz *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.size() != pObject->sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.size(); i++)
		{
			if (sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou[i] != pObject->sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou[i])
			{
				return false;
			}
		}
		if (sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.size() != pObject->sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.size(); i++)
		{
			if (sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO[i] != pObject->sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO[i])
			{
				return false;
			}
		}
		if (sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.size() != pObject->sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.size(); i++)
		{
			if (sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC[i] != pObject->sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC[i])
			{
				return false;
			}
		}
		if (sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.size() != pObject->sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.size(); i++)
		{
			if (sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ[i] != pObject->sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ[i])
			{
				return false;
			}
		}
		if (sbt_bMfJsEA.size() != pObject->sbt_bMfJsEA.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_bMfJsEA.size(); i++)
		{
			if (sbt_bMfJsEA[i] != pObject->sbt_bMfJsEA[i])
			{
				return false;
			}
		}
		if (sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV != pObject->sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV)
		{
			return false;
		}
		if (sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks != pObject->sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks)
		{
			return false;
		}
		if (sbt_fj15pqxtH1YinilgzOfcq.size() != pObject->sbt_fj15pqxtH1YinilgzOfcq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_fj15pqxtH1YinilgzOfcq.size(); i++)
		{
			if (sbt_fj15pqxtH1YinilgzOfcq[i] != pObject->sbt_fj15pqxtH1YinilgzOfcq[i])
			{
				return false;
			}
		}
		if (sbt_S.size() != pObject->sbt_S.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_S.size(); i++)
		{
			if (0 != cx_strcmp(sbt_S[i].c_str(), pObject->sbt_S[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_6R3uPLSnSPFQQpTyzWfMWHG != pObject->sbt_6R3uPLSnSPFQQpTyzWfMWHG)
		{
			return false;
		}
		if (sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K != pObject->sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K)
		{
			return false;
		}
		if (sbt_dW4fibU.size() != pObject->sbt_dW4fibU.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dW4fibU.size(); i++)
		{
			if (!sbt_dW4fibU[i].Compare(&pObject->sbt_dW4fibU[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::String sValue;
		CX::Status status;

		Reset();
		if ((status = pReader->BeginObjectArray("sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.push_back((CX::Float)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.push_back((CX::Int8)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_bMfJsEA")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_bMfJsEA.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks", &nValue)).IsNOK())
		{
			return status;
		}
		sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks = (CX::Int16)nValue;
		if ((status = pReader->BeginObjectArray("sbt_fj15pqxtH1YinilgzOfcq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_fj15pqxtH1YinilgzOfcq.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayString(&sValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_S.push_back(sValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_6R3uPLSnSPFQQpTyzWfMWHG", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_6R3uPLSnSPFQQpTyzWfMWHG = (CX::Int16)nValue;
		if ((status = pReader->ReadObjectInt("sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K = (CX::Int32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_dW4fibU")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzp tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_dW4fibU.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->BeginObjectArray("sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.begin(); iter != sbt_Cd9JHon_pJqv5sA9I9ixLI4IfltMS56Ou.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::FloatArray::const_iterator iter = sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.begin(); iter != sbt_XgQyqcz8NxoeBmieF3lgFztNFZMry02z3YegFxdvrSPZ42dWO.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int8Array::const_iterator iter = sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.begin(); iter != sbt_M1qQJ8x8GfOfsrmccNmVbDaJMwQI3Xjib4Gwt669Tb7judK6eZYtC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.begin(); iter != sbt_ByJIoLJZO07UsD6J7Rh6MDtA5jInu9nTzRaX5hZk0WW4XhJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_bMfJsEA")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_bMfJsEA.begin(); iter != sbt_bMfJsEA.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV", (CX::Int64)sbt_e_GmALVLh2OnHeoeG77p6oDK1aWq1k7qLINNFGgqiSy5R79ClZyawh9k1T2eV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks", (CX::Int64)sbt__6gmwOGZg1CKRckacGJYGsmenQkMVIqxe4yXQEVzxpHsuc5gsEvj1bRYfLSks)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_fj15pqxtH1YinilgzOfcq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_fj15pqxtH1YinilgzOfcq.begin(); iter != sbt_fj15pqxtH1YinilgzOfcq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_S")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::StringArray::const_iterator iter = sbt_S.begin(); iter != sbt_S.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_6R3uPLSnSPFQQpTyzWfMWHG", (CX::Int64)sbt_6R3uPLSnSPFQQpTyzWfMWHG)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K", (CX::Int64)sbt_r0N2uw8K4THB5_lwzO4afdLI7BddAPf8fLEr0CwLwaAhkQ88K)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dW4fibU")).IsNOK())
		{
			return status;
		}
		for (sbt_mh7ASXTe1m8K47JkDjtxxxZ9ffRSUZYkxqUSUr7JzPbrC4UgVzpArray::const_iterator iter = sbt_dW4fibU.begin(); iter != sbt_dW4fibU.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_z2tPz>::Type sbt_z2tPzArray;

