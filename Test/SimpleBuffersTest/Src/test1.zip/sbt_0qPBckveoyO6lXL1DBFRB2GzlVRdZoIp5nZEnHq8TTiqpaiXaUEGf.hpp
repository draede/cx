
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"
#include "sbt_F37TR5tQnzaqiIY.hpp"


class sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::UInt32 sbt_d0uNsu5jy3SNJizmntW17OPArC7;
	CX::WString sbt_NRBumNm87lp;
	CX::IO::SimpleBuffers::UInt32Array sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm;
	CX::String sbt_pJ6;
	CX::IO::SimpleBuffers::UInt32Array sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV;
	CX::IO::SimpleBuffers::UInt64Array sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1;
	CX::String sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD;
	CX::IO::SimpleBuffers::UInt64Array sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH;
	CX::UInt64 sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE;
	CX::WString sbt_5pZ_GvF8J_8qup08ArRcadq3ref;
	CX::IO::SimpleBuffers::DoubleArray sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7;
	CX::Double sbt_7Q0dhi6mqA1e2ffaLbibBnT;
	CX::IO::SimpleBuffers::WStringArray sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX;
	CX::Float sbt_d_5rAwMcV1gk4DJTC7kW8spyM;
	CX::Int8 sbt_CSueNSmUGIxXx3KvakVBLch_Y;
	CX::IO::SimpleBuffers::Int16Array sbt_xCjjWQT0ApdCy;
	CX::WString sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK;
	CX::Float sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD;
	CX::UInt32 sbt_rStozXxX6EH;
	CX::IO::SimpleBuffers::BoolArray sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW;
	CX::IO::SimpleBuffers::DoubleArray sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY;
	CX::Int8 sbt_TuhWsk4FP;
	sbt_F37TR5tQnzaqiIYArray sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa;

	virtual void Reset()
	{
		sbt_d0uNsu5jy3SNJizmntW17OPArC7 = 0;
		sbt_NRBumNm87lp.clear();
		sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.clear();
		sbt_pJ6.clear();
		sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.clear();
		sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.clear();
		sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD.clear();
		sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.clear();
		sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE = 0;
		sbt_5pZ_GvF8J_8qup08ArRcadq3ref.clear();
		sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.clear();
		sbt_7Q0dhi6mqA1e2ffaLbibBnT = 0.0;
		sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.clear();
		sbt_d_5rAwMcV1gk4DJTC7kW8spyM = 0.0f;
		sbt_CSueNSmUGIxXx3KvakVBLch_Y = 0;
		sbt_xCjjWQT0ApdCy.clear();
		sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK.clear();
		sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD = 0.0f;
		sbt_rStozXxX6EH = 0;
		sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.clear();
		sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.clear();
		sbt_TuhWsk4FP = 0;
		sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_d0uNsu5jy3SNJizmntW17OPArC7 = 1074173283;
		sbt_NRBumNm87lp = L"t?)hM2XC]1CE@wmJ)<Cu*>(l$Hv)6J<EHnm9E!uJp?9lkBJl90PKcF]9";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.push_back(4115237490);
		}
		sbt_pJ6 = "R4*)u(IzNVgD!UZGeQ|j-=V";
		for (CX::Size i = 0; i < 2; i++)
		{
			sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.push_back(1683915844);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.push_back(732318250697970228);
		}
		sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD = "kT$Iov<5?*OPb'9<.v@^gDlyTNtR\\Zxc/-6.olcyT({}rzHJF*js304?";
		for (CX::Size i = 0; i < 12; i++)
		{
			sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.push_back(13270853946691558156);
		}
		sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE = 17566748361026809450;
		sbt_5pZ_GvF8J_8qup08ArRcadq3ref = L"]1vh@^|~oVC]32e?5=n\\~Fycf\"EcS#aYLljEEj|@u/>NTp6}QC|U'Fp";
		for (CX::Size i = 0; i < 15; i++)
		{
			sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.push_back(0.932997);
		}
		sbt_7Q0dhi6mqA1e2ffaLbibBnT = 0.842949;
		for (CX::Size i = 0; i < 3; i++)
		{
			sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.push_back(L"QHe4P,C~/S8c9nv?NJ@lIQ");
		}
		sbt_d_5rAwMcV1gk4DJTC7kW8spyM = 0.642275f;
		sbt_CSueNSmUGIxXx3KvakVBLch_Y = -36;
		for (CX::Size i = 0; i < 5; i++)
		{
			sbt_xCjjWQT0ApdCy.push_back(-26949);
		}
		sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK = L"o7b:Kff}an~H?^c_|bMm*Fg1Vi]NIs/\\C!jY&H[wUJ~PW7\\]`7U2sij0;";
		sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD = 0.601418f;
		sbt_rStozXxX6EH = 3052080128;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.push_back(true);
		}
		for (CX::Size i = 0; i < 6; i++)
		{
			sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.push_back(0.451361);
		}
		sbt_TuhWsk4FP = 8;
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_F37TR5tQnzaqiIY v;

			v.SetupWithSomeValues();
			sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.push_back(v);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf *pObject = dynamic_cast<const sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_d0uNsu5jy3SNJizmntW17OPArC7 != pObject->sbt_d0uNsu5jy3SNJizmntW17OPArC7)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_NRBumNm87lp.c_str(), pObject->sbt_NRBumNm87lp.c_str()))
		{
			return false;
		}
		if (sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.size() != pObject->sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.size(); i++)
		{
			if (sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm[i] != pObject->sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_pJ6.c_str(), pObject->sbt_pJ6.c_str()))
		{
			return false;
		}
		if (sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.size() != pObject->sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.size(); i++)
		{
			if (sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV[i] != pObject->sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV[i])
			{
				return false;
			}
		}
		if (sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.size() != pObject->sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.size(); i++)
		{
			if (sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1[i] != pObject->sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD.c_str(), pObject->sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD.c_str()))
		{
			return false;
		}
		if (sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.size() != pObject->sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.size(); i++)
		{
			if (sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH[i] != pObject->sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH[i])
			{
				return false;
			}
		}
		if (sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE != pObject->sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE)
		{
			return false;
		}
		if (0 != cxw_strcmp(sbt_5pZ_GvF8J_8qup08ArRcadq3ref.c_str(), pObject->sbt_5pZ_GvF8J_8qup08ArRcadq3ref.c_str()))
		{
			return false;
		}
		if (sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.size() != pObject->sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.size(); i++)
		{
			if (sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7[i] != pObject->sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7[i])
			{
				return false;
			}
		}
		if (sbt_7Q0dhi6mqA1e2ffaLbibBnT != pObject->sbt_7Q0dhi6mqA1e2ffaLbibBnT)
		{
			return false;
		}
		if (sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.size() != pObject->sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.size(); i++)
		{
			if (0 != cxw_strcmp(sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX[i].c_str(), pObject->sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX[i].c_str()))
			{
				return false;
			}
		}
		if (sbt_d_5rAwMcV1gk4DJTC7kW8spyM != pObject->sbt_d_5rAwMcV1gk4DJTC7kW8spyM)
		{
			return false;
		}
		if (sbt_CSueNSmUGIxXx3KvakVBLch_Y != pObject->sbt_CSueNSmUGIxXx3KvakVBLch_Y)
		{
			return false;
		}
		if (sbt_xCjjWQT0ApdCy.size() != pObject->sbt_xCjjWQT0ApdCy.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_xCjjWQT0ApdCy.size(); i++)
		{
			if (sbt_xCjjWQT0ApdCy[i] != pObject->sbt_xCjjWQT0ApdCy[i])
			{
				return false;
			}
		}
		if (0 != cxw_strcmp(sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK.c_str(), pObject->sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK.c_str()))
		{
			return false;
		}
		if (sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD != pObject->sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD)
		{
			return false;
		}
		if (sbt_rStozXxX6EH != pObject->sbt_rStozXxX6EH)
		{
			return false;
		}
		if (sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.size() != pObject->sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.size(); i++)
		{
			if (sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW[i] != pObject->sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW[i])
			{
				return false;
			}
		}
		if (sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.size() != pObject->sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.size(); i++)
		{
			if (sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY[i] != pObject->sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY[i])
			{
				return false;
			}
		}
		if (sbt_TuhWsk4FP != pObject->sbt_TuhWsk4FP)
		{
			return false;
		}
		if (sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.size() != pObject->sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.size(); i++)
		{
			if (!sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa[i].Compare(&pObject->sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa[i]))
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Double lfValue;
		CX::WString wsValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_d0uNsu5jy3SNJizmntW17OPArC7", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_d0uNsu5jy3SNJizmntW17OPArC7 = (CX::UInt32)nValue;
		if ((status = pReader->ReadObjectWString("sbt_NRBumNm87lp", &sbt_NRBumNm87lp)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_pJ6", &sbt_pJ6)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD", &sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE = (CX::UInt64)nValue;
		if ((status = pReader->ReadObjectWString("sbt_5pZ_GvF8J_8qup08ArRcadq3ref", &sbt_5pZ_GvF8J_8qup08ArRcadq3ref)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_7Q0dhi6mqA1e2ffaLbibBnT", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_7Q0dhi6mqA1e2ffaLbibBnT = (CX::Double)lfValue;
		if ((status = pReader->BeginObjectArray("sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayWString(&wsValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.push_back(wsValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_d_5rAwMcV1gk4DJTC7kW8spyM", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_d_5rAwMcV1gk4DJTC7kW8spyM = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_CSueNSmUGIxXx3KvakVBLch_Y", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_CSueNSmUGIxXx3KvakVBLch_Y = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_xCjjWQT0ApdCy")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_xCjjWQT0ApdCy.push_back((CX::Int16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectWString("sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK", &sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectReal("sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD", &lfValue)).IsNOK())
		{
			return status;
		}
		sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD = (CX::Float)lfValue;
		if ((status = pReader->ReadObjectInt("sbt_rStozXxX6EH", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_rStozXxX6EH = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayReal(&lfValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.push_back((CX::Double)lfValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_TuhWsk4FP", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_TuhWsk4FP = (CX::Int8)nValue;
		if ((status = pReader->BeginObjectArray("sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			sbt_F37TR5tQnzaqiIY tmp;

			if ((status = pReader->BeginArrayObject()).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			if ((status = tmp.Read(pReader)).IsNOK())
			{
				return status;
			}
			sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.push_back(tmp);
			if ((status = pReader->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_d0uNsu5jy3SNJizmntW17OPArC7", (CX::Int64)sbt_d0uNsu5jy3SNJizmntW17OPArC7)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_NRBumNm87lp", sbt_NRBumNm87lp.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.begin(); iter != sbt_YSYVrph1uAJP3VZtakn3MXKH9vekPIsCzx6Z1Mc6XG_PHjm.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_pJ6", sbt_pJ6.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.begin(); iter != sbt_4ml2TPlnu1kFX7EUYdvGh6MaPRubYfSHV.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.begin(); iter != sbt_ZZt9ayZGc5C1FSWXlfuAM04KsWVIERvVAqlPaA4JcWJWp0namo1.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD", sbt_0TNsn5Gf8a2IaXJnJzohVBoCw4HMD.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.begin(); iter != sbt_R5xwLEALG8JXH9QWzu8ATH8GW5a57M4m6Eg27CH.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE", (CX::Int64)sbt_H98l52rT8FUL3sN_eibEEj2zoGO_bF1bE)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_5pZ_GvF8J_8qup08ArRcadq3ref", sbt_5pZ_GvF8J_8qup08ArRcadq3ref.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.begin(); iter != sbt_dyQhfzv9j8vzzgcudIop9UZJxFhjEfy7N9AeYA0plSbFAz7.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_7Q0dhi6mqA1e2ffaLbibBnT", (CX::Double)sbt_7Q0dhi6mqA1e2ffaLbibBnT)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::WStringArray::const_iterator iter = sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.begin(); iter != sbt_6RzGtEzkHUF3THpmoPkIjgNfiofzX9dDX.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayWString((*iter).c_str())).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_d_5rAwMcV1gk4DJTC7kW8spyM", (CX::Double)sbt_d_5rAwMcV1gk4DJTC7kW8spyM)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_CSueNSmUGIxXx3KvakVBLch_Y", (CX::Int64)sbt_CSueNSmUGIxXx3KvakVBLch_Y)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_xCjjWQT0ApdCy")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int16Array::const_iterator iter = sbt_xCjjWQT0ApdCy.begin(); iter != sbt_xCjjWQT0ApdCy.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectWString("sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK", sbt_WHol5MpVZNOZxktT4ndiqlqeVtI7v6F4rQvlj_CNqLEEK.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectReal("sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD", (CX::Double)sbt_IxAXXT4q3DrvKStWh2JaIRr_2S8D0FM1BvkKeUD)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_rStozXxX6EH", (CX::Int64)sbt_rStozXxX6EH)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.begin(); iter != sbt_Buh3fS33PLZBYq9sIrrRdeJbE1rnIkXLN_ijnD82aGjaoVKaW.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::DoubleArray::const_iterator iter = sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.begin(); iter != sbt_IRtE_YhWrUI01fu4HDX97TG2lgQNNbVWkoGnFvo2S1ZuY.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayReal((CX::Double)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_TuhWsk4FP", (CX::Int64)sbt_TuhWsk4FP)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa")).IsNOK())
		{
			return status;
		}
		for (sbt_F37TR5tQnzaqiIYArray::const_iterator iter = sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.begin(); iter != sbt_vttpWC6r9fK_NjXaSHvM3yTgTEyQa.end(); ++iter)
		{
			if ((status = pWriter->BeginArrayObject()).IsNOK())
			{
				return status;
			}
			if ((status = (*iter).Write(pWriter)).IsNOK())
			{
				return status;
			}
			if ((status = pWriter->EndArrayObject()).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGf>::Type sbt_0qPBckveoyO6lXL1DBFRB2GzlVRdZoIp5nZEnHq8TTiqpaiXaUEGfArray;

