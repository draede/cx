
#pragma once


#include "CX/IO/SimpleBuffers/Types.hpp"
#include "CX/C/string.h"


class sbt_yP41Ndp : public CX::IO::SimpleBuffers::IObject
{
public:

	CX::Int8 sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy;
	CX::UInt64 sbt_YxV;
	CX::IO::SimpleBuffers::UInt32Array sbt_yJgOyK59d5U;
	CX::IO::SimpleBuffers::UInt16Array sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w;
	CX::IO::SimpleBuffers::UInt64Array sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq;
	CX::IO::SimpleBuffers::UInt64Array sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC;
	CX::String sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM;
	CX::IO::SimpleBuffers::UInt16Array sbt_l;
	CX::IO::SimpleBuffers::UInt64Array sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB;
	CX::UInt32 sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4;
	CX::IO::SimpleBuffers::UInt64Array sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE;
	CX::IO::SimpleBuffers::Int64Array sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD;
	CX::UInt8 sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2;
	CX::UInt64 sbt_Ffn_bRpYU;
	CX::IO::SimpleBuffers::UInt16Array sbt_jfkqgXHETaq7RKXApZndJ;
	CX::Int64 sbt_AYiaX4_8HgyWV;
	CX::IO::SimpleBuffers::BoolArray sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp;
	CX::IO::SimpleBuffers::UInt32Array sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9;

	virtual void Reset()
	{
		sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy = 0;
		sbt_YxV = 0;
		sbt_yJgOyK59d5U.clear();
		sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.clear();
		sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.clear();
		sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.clear();
		sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM.clear();
		sbt_l.clear();
		sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.clear();
		sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4 = 0;
		sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.clear();
		sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.clear();
		sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2 = 0;
		sbt_Ffn_bRpYU = 0;
		sbt_jfkqgXHETaq7RKXApZndJ.clear();
		sbt_AYiaX4_8HgyWV = 0;
		sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.clear();
		sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.clear();
	}

	virtual void SetupWithSomeValues()
	{
		Reset();
		sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy = -111;
		sbt_YxV = 9895222354164118816;
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_yJgOyK59d5U.push_back(2760266115);
		}
		for (CX::Size i = 0; i < 9; i++)
		{
			sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.push_back(2808);
		}
		for (CX::Size i = 0; i < 7; i++)
		{
			sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.push_back(10816913265557856346);
		}
		sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM = "^R|Tm!4gwN{@@jkZ/Aoby.?wPrFgq/(Ao!<BAZ|o";
		for (CX::Size i = 0; i < 14; i++)
		{
			sbt_l.push_back(23427);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.push_back(8012688207753093232);
		}
		sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4 = 2693891476;
		for (CX::Size i = 0; i < 4; i++)
		{
			sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.push_back(15704279002762476758);
		}
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.push_back(-6092800352583788568);
		}
		sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2 = 57;
		sbt_Ffn_bRpYU = 4346065484644785580;
		for (CX::Size i = 0; i < 8; i++)
		{
			sbt_jfkqgXHETaq7RKXApZndJ.push_back(21369);
		}
		sbt_AYiaX4_8HgyWV = 5281399282088571672;
		for (CX::Size i = 0; i < 11; i++)
		{
			sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.push_back(false);
		}
		for (CX::Size i = 0; i < 10; i++)
		{
			sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.push_back(2897150596);
		}
	}

	virtual bool Compare(const CX::IO::SimpleBuffers::IObject *pObj)
	{
		const sbt_yP41Ndp *pObject = dynamic_cast<const sbt_yP41Ndp *>(pObj);
	
		if (NULL == pObject)
		{
			return false;
		}
		if (sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy != pObject->sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy)
		{
			return false;
		}
		if (sbt_YxV != pObject->sbt_YxV)
		{
			return false;
		}
		if (sbt_yJgOyK59d5U.size() != pObject->sbt_yJgOyK59d5U.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_yJgOyK59d5U.size(); i++)
		{
			if (sbt_yJgOyK59d5U[i] != pObject->sbt_yJgOyK59d5U[i])
			{
				return false;
			}
		}
		if (sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.size() != pObject->sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.size(); i++)
		{
			if (sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w[i] != pObject->sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w[i])
			{
				return false;
			}
		}
		if (sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.size() != pObject->sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.size(); i++)
		{
			if (sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq[i] != pObject->sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq[i])
			{
				return false;
			}
		}
		if (sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.size() != pObject->sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.size(); i++)
		{
			if (sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC[i] != pObject->sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC[i])
			{
				return false;
			}
		}
		if (0 != cx_strcmp(sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM.c_str(), pObject->sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM.c_str()))
		{
			return false;
		}
		if (sbt_l.size() != pObject->sbt_l.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_l.size(); i++)
		{
			if (sbt_l[i] != pObject->sbt_l[i])
			{
				return false;
			}
		}
		if (sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.size() != pObject->sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.size(); i++)
		{
			if (sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB[i] != pObject->sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB[i])
			{
				return false;
			}
		}
		if (sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4 != pObject->sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4)
		{
			return false;
		}
		if (sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.size() != pObject->sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.size(); i++)
		{
			if (sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE[i] != pObject->sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE[i])
			{
				return false;
			}
		}
		if (sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.size() != pObject->sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.size(); i++)
		{
			if (sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD[i] != pObject->sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD[i])
			{
				return false;
			}
		}
		if (sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2 != pObject->sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2)
		{
			return false;
		}
		if (sbt_Ffn_bRpYU != pObject->sbt_Ffn_bRpYU)
		{
			return false;
		}
		if (sbt_jfkqgXHETaq7RKXApZndJ.size() != pObject->sbt_jfkqgXHETaq7RKXApZndJ.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_jfkqgXHETaq7RKXApZndJ.size(); i++)
		{
			if (sbt_jfkqgXHETaq7RKXApZndJ[i] != pObject->sbt_jfkqgXHETaq7RKXApZndJ[i])
			{
				return false;
			}
		}
		if (sbt_AYiaX4_8HgyWV != pObject->sbt_AYiaX4_8HgyWV)
		{
			return false;
		}
		if (sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.size() != pObject->sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.size(); i++)
		{
			if (sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp[i] != pObject->sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp[i])
			{
				return false;
			}
		}
		if (sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.size() != pObject->sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.size())
		{
			return false;
		}
		for (CX::Size i = 0; i < sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.size(); i++)
		{
			if (sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9[i] != pObject->sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9[i])
			{
				return false;
			}
		}

		return true;
	}

	virtual CX::Status Read(CX::IO::IDataReader *pReader)
	{
		CX::Bool bValue;
		CX::Int64 nValue;
		CX::Status status;

		Reset();
		if ((status = pReader->ReadObjectInt("sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy = (CX::Int8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_YxV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_YxV = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_yJgOyK59d5U")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_yJgOyK59d5U.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectString("sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM", &sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM)).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_l")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_l.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4 = (CX::UInt32)nValue;
		if ((status = pReader->BeginObjectArray("sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.push_back((CX::UInt64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.push_back((CX::Int64)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2 = (CX::UInt8)nValue;
		if ((status = pReader->ReadObjectInt("sbt_Ffn_bRpYU", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_Ffn_bRpYU = (CX::UInt64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_jfkqgXHETaq7RKXApZndJ")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_jfkqgXHETaq7RKXApZndJ.push_back((CX::UInt16)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->ReadObjectInt("sbt_AYiaX4_8HgyWV", &nValue)).IsNOK())
		{
			return status;
		}
		sbt_AYiaX4_8HgyWV = (CX::Int64)nValue;
		if ((status = pReader->BeginObjectArray("sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayBool(&bValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.push_back(bValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pReader->BeginObjectArray("sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9")).IsNOK())
		{
			return status;
		}
		for (;;)
		{
			if ((status = pReader->ReadArrayInt(&nValue)).IsNOK())
			{
				if (CX::Status_NoMoreItems == status.GetCode())
				{
					break;
				}
				return status;
			}
			sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.push_back((CX::UInt32)nValue);
		}
		if ((status = pReader->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

	virtual CX::Status Write(CX::IO::IDataWriter *pWriter) const
	{
		CX::Status status;

		if ((status = pWriter->WriteObjectInt("sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy", (CX::Int64)sbt_GeZmrSjveyEBKRRTZUaZIse1gzC82ULIsSICRnnJqz6ajio8ARzY1FHBkehBy)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_YxV", (CX::Int64)sbt_YxV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_yJgOyK59d5U")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_yJgOyK59d5U.begin(); iter != sbt_yJgOyK59d5U.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.begin(); iter != sbt_OjSMQgD52f3YiSDbhqiDxz_vC5w.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.begin(); iter != sbt_4X0O42oqN8LkvI2Ep66Sbqe0QRPavY9b3F9w3bq.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.begin(); iter != sbt_Q8yoXgur_Fq4dIZgMNZfU0VRPIPv78mWbjC.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectString("sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM", sbt_jjDhlg4OTsfODfJIz9yFFQTS2q49gHM.c_str())).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_l")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_l.begin(); iter != sbt_l.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.begin(); iter != sbt_3uDKmcDYnjnsRboWcf6aws2_D56rqWlHaIdpnNITYiFrB.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4", (CX::Int64)sbt_e82mdvwK2z4jl55bG47os3F1BCPVHIP9T_yIDDxlOts7NsaH4)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt64Array::const_iterator iter = sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.begin(); iter != sbt_KeWA72pD_4USV5dn2mwJAFWXoU7nim9V6pE5haUSTj3gtCE.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::Int64Array::const_iterator iter = sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.begin(); iter != sbt_pMgaSOB5gOwfxXLOYn5frziIv27m11xtD.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2", (CX::Int64)sbt_Qgj2Qs6xKNjHUuKd7Kkn0yyraeUFhJt1zXFBtEeb2)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_Ffn_bRpYU", (CX::Int64)sbt_Ffn_bRpYU)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_jfkqgXHETaq7RKXApZndJ")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt16Array::const_iterator iter = sbt_jfkqgXHETaq7RKXApZndJ.begin(); iter != sbt_jfkqgXHETaq7RKXApZndJ.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->WriteObjectInt("sbt_AYiaX4_8HgyWV", (CX::Int64)sbt_AYiaX4_8HgyWV)).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::BoolArray::const_iterator iter = sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.begin(); iter != sbt_8t3creQC1mqafOve5QNawzO3GKcnuJVwxeA7rLCH71DI2Hc9dQJhWrVCljAAp.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayBool(*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}
		if ((status = pWriter->BeginObjectArray("sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9")).IsNOK())
		{
			return status;
		}
		for (CX::IO::SimpleBuffers::UInt32Array::const_iterator iter = sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.begin(); iter != sbt_1kCiWTYRu96SGMPMwT9Hs3QX6QS6K9AyiLUgGOB3rFgH8S6S9.end(); ++iter)
		{
			if ((status = pWriter->WriteArrayInt((CX::Int64)*iter)).IsNOK())
			{
				return status;
			}
		}
		if ((status = pWriter->EndObjectArray()).IsNOK())
		{
			return status;
		}

		return CX::Status();
	}

};

typedef CX::Vector<sbt_yP41Ndp>::Type sbt_yP41NdpArray;

